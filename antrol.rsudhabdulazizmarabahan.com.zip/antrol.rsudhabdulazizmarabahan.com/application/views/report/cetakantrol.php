<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('antrol/data'); ?>">Data Antrol</a></li>
            <li class="breadcrumb-item active" aria-current="page">Export Data</li>
        </ol>
    </nav>

    <form method="get" action="" class="filter-form">
        <div class="row mb-3">
            <div class="col-sm-3 col-md-2">
                <div class="form-group">
                    <label for="filter">Filter Berdasarkan</label>
                    <select name="filter" id="filter" class="form-control">
                        <option value="">Pilih</option>
                        <option value="1">Tanggal</option>
                        <option value="2">Bulan</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="row mb-3" id="form-tanggal">
            <div class="col-sm-3 col-md-2">
                <input type="date" class="form-control datepicker" name="tanggal1" required>
            </div>
            <div class="col-sm-1 d-flex align-items-center justify-content-center">
                <span class="mx-2">s.d.</span>
            </div>
            <div class="col-sm-3 col-md-2">
                <input type="date" class="form-control datepicker" name="tanggal2" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-sm-3 col-md-2" id="form-bulan">
                <div class="form-group">
                    <label for="bulan">Bulan</label>
                    <select name="bulan" id="bulan" class="form-control">
                        <option value="">Pilih</option>
                        <option value="1">Januari</option>
                        <option value="2">Februari</option>
                        <option value="3">Maret</option>
                        <option value="4">April</option>
                        <option value="5">Mei</option>
                        <option value="6">Juni</option>
                        <option value="7">Juli</option>
                        <option value="8">Agustus</option>
                        <option value="9">September</option>
                        <option value="10">Oktober</option>
                        <option value="11">November</option>
                        <option value="12">Desember</option>
                    </select>
                </div>
            </div>
            <div class="col-sm-3 col-md-2" id="form-tahun">
                <div class="form-group">
                    <label for="tahun">Tahun</label>
                    <select name="tahun" id="tahun" class="form-control">
                        <option value="">Pilih</option>
                        <?php foreach($option_tahun as $data): ?>
                            <option value="<?= $data->tahun; ?>"><?= $data->tahun; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-info">Tampilkan</button>
            <a href="index" class="btn btn-warning">Reset Filter</a>
        </div>
    </form>

    <hr />

    <div class="mb-4">
        <a href="<?php echo $url_export; ?>" class="btn btn-success">EXPORT EXCEL <?php echo $label; ?></a>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-bordered" id="tabeldata">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal Periksa</th>
                                <th>No. RM</th>
                                <th>No. Kartu</th>
                                <th>No. Referensi</th>
                                <th>Jenis Kunjungan</th>
                                <th>Status Kirim</th>
                                <th>Keterangan</th>
                                <th>Kode Booking</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach ($Antrol as $jb): ?>
                                <?php $data_array = json_decode(json_encode($jb), true); ?>
                                <tr>
                                    <th scope="row"><?= $i; ?></th>
                                    <td><?= $data_array['tanggal_periksa']; ?></td>
                                    <td><?= $data_array['no_rkm_medis']; ?></td>
                                    <td><?= $data_array['nomor_kartu']; ?></td>
                                    <td><?= $data_array['nomor_referensi']; ?></td>
                                    <td><?= $data_array['jenis_kunjungan']; ?></td>
                                    <td><?= $data_array['status_kirim']; ?></td>
                                    <td><?= $data_array['keterangan']; ?></td>
                                    <td><?= $data_array['kodebooking']; ?></td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- End Page Content -->
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script>
    $(document).ready(function() {
        setDatePicker();
        $('#form-tanggal, #form-bulan, #form-tahun').hide();

        $('#filter').change(function() {
            let value = $(this).val();
            $('#form-tanggal, #form-bulan, #form-tahun').hide();
            if (value == '1') {
                $('#form-tanggal').show();
            } else if (value == '2') {
                $('#form-bulan, #form-tahun').show();
            } else if (value == '3') {
                $('#form-tahun').show();
            }
            $('.datepicker').val('');
            $('#form-bulan select, #form-tahun select').val('');
        });

        function setDatePicker() {
            $(".datepicker").datepicker({
                format: "yyyy-mm-dd",
                todayHighlight: true,
                autoclose: true
            }).attr("readonly", "readonly").css({"cursor": "pointer", "background": "white"});
        }
    });
</script>

<script>
    $(document).ready(function() {
        $('#tabelantrol').DataTable({
            "pageLength": 50,
            "lengthMenu": [10, 25, 50, 100],
            "ordering": true,
            "responsive": true,
            "autoWidth": false,
            "language": {
                "search": "",
                "searchPlaceholder": "Cari..."
            }
        });
    });

    window.onscroll = function() {
        var scrollToTopBtn = document.getElementById("scrollToTopBtn");
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            scrollToTopBtn.style.display = "block";
        } else {
            scrollToTopBtn.style.display = "none";
        }
    };

    document.getElementById("scrollToTopBtn").addEventListener("click", function(e) {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
</script>
