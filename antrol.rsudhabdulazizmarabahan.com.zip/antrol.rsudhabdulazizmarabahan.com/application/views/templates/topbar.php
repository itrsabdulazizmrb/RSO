<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-3 static-top shadow">
            <div class="container-fluid">

                

                <!-- Page Title -->
                <div class="d-flex align-items-center">
                    <h4 class="page-title mb-0">RSUD H. Abdul Aziz Marabahan</h4>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="img-profile rounded-circle" src="<?= base_url('assets/LogoIT.png')?>">
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="<?= base_url('auth/logout'); ?>">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                            <div class="dropdown-divider"></div>
                            
                        </div>
                    </li>

                </ul>
            </div>
        </nav>
        <!-- End of Topbar -->

        <!-- Custom CSS for Better Styling -->
        <style>
            .topbar {
                padding: 0.5rem 1rem;
                background-color: #035F64;
            }
            .page-title {
                font-size: 1.5rem;
                font-weight: 600;
                color: #035F64;
                margin: 0;
            }
            .navbar-nav .nav-item .nav-link img {
                width: 40px;
                height: 40px;
            }
            .dropdown-menu {
                min-width: 150px;
            }
            .dropdown-item {
                display: flex;
                align-items: center;
            }
            .page-title {
                font-family: "Inter", sans-serif;
  font-optical-sizing: auto;
  font-weight: <weight>;
  font-style: normal;
            }
        </style>
