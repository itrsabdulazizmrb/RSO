<?php error_reporting(0); ?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in(); 
        
        $this->load->model("Data_model");
        $this->load->database();
        $this->load->library('form_validation');
    }

    public function Rajal()
    {
        $data['title'] = 'Data User';

        $data['total_sudah'] = $this->Data_model->getTotalKirim('Sudah');
        $data['total_gagal'] = $this->Data_model->getTotalKirim('Gagal');
        $data['total_sep'] = $this->Data_model->getTotalSEP();

        if ($data['total_sep'] > 0) {
            $data['capaian_sudah'] = ($data['total_sudah'] / $data['total_sep']) * 100;
        } else {
            $data['capaian_sudah'] = 0; 
        }

        $data['Rajal'] = $this->Data_model->getRajal();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/rajal', $data);
        $this->load->view('templates/footer');
    }

    public function Ranap()
    {
        $data['title'] = 'Data User';

        $data['total_sudah'] = $this->Data_model->getTotalKirim('Sudah');
        $data['total_gagal'] = $this->Data_model->getTotalKirim('Gagal');
        $data['total_sep'] = $this->Data_model->getTotalSEP();

        if ($data['total_sep'] > 0) {
            $data['capaian_sudah'] = ($data['total_sudah'] / $data['total_sep']) * 100;
        } else {
            $data['capaian_sudah'] = 0; 
        }

        $start_date = $this->input->get('start_date');
        $end_date = $this->input->get('end_date');

        $data['Ranap'] = $this->Data_model->getRanap();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('data/ranap', $data);
        $this->load->view('templates/footer');
    }

}
