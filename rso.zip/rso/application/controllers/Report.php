<?php error_reporting(0); ?>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Report extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        
        $this->load->model("Antrol_model");
        $this->load->database();
        $this->load->library('form_validation');
    }

    
    
public function index(){
    $data['title'] = 'Cetak Data Antrol';

    $start_date = $this->input->get('tanggal1');
    $end_date = $this->input->get('tanggal2');
    $data['Antrol'] = $this->Antrol_model->getAntrol();

    if(isset($_GET['filter']) && ! empty($_GET['filter'])){ 
        $filter = $_GET['filter'];
        if($filter == '1'){ 
            $tanggal1 = $_GET['tanggal1'];
            $tanggal2 = $_GET['tanggal2'];
            $label = 'Data Tanggal '.date('d-m-Y', strtotime($tanggal1)).' Sampai ' .date('d-m-Y', strtotime($tanggal2));
            $url_export = 'report/exportantrol?filter=1&tanggal1='.$tanggal1.'&tanggal2='.$tanggal2;
            $Antrol = $this->Antrol_model->view_by_date($tanggal1, $tanggal2); 
        } else if($filter == '2'){ 
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
            $label = 'Data Bulan '.$nama_bulan[$bulan].' '.$tahun;
            $url_export = 'report/exportantrol?filter=2&bulan='.$bulan.'&tahun='.$tahun;
            $Antrol = $this->Antrol_model->view_by_month($bulan, $tahun); 
        } else if($filter == '3'){ 
            $tahun = $_GET['tahun'];
            $label = 'Data Tahun '.$tahun;
            $url_export = 'report/exportantrol?filter=3&tahun='.$tahun;
            $Antrol = $this->Antrol_model->view_by_year($tahun);
        } 
    } else { 
        $label = 'Data Bulan '.date('F Y');
        $url_export = 'report/exportantrol';
        $Antrol = $this->Antrol_model->view_all();
    }

    $data['label'] = $label;
    $data['url_export'] = base_url($url_export);
    $data['Antrol'] = $Antrol;
    $data['option_tahun'] = $this->Antrol_model->option_tahun();

    $this->load->view('templates/header');  
    $this->load->view('templates/topbar');  
    $this->load->view('report/cetakantrol', $data);
    $this->load->view('templates/footer');  
}


public function exportantrol(){
include APPPATH.'third_party/PHPExcel/PHPExcel.php';
$excel = new PHPExcel();
    $excel->getProperties()->setCreator('IT RSHAA')
                 ->setLastModifiedBy('IT RSHAA')
                 ->setTitle("Data Antrol")
                 ->setSubject("Data Antrol")
                 ->setDescription("Laporan Data Antrol")
                 ->setKeywords("Data Antrol");
    $style_col = array(
      'font' => array('bold' => true), 
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER  
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),   
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN)  
      )
    );
    $style_row = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER  
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),   
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN)  
      )
    );
    
    $search = $this->input->get('search');
    if(isset($_GET['filter']) && ! empty($_GET['filter'])){ 
        $filter = $_GET['filter']; 
        if(isset($search) && !empty($search)) {
            $this->db->like('status_mutasi', $search);
        } else if($filter == '1'){ 
            $tanggal1 = $_GET['tanggal1'];
            $tanggal2 = $_GET['tanggal2'];
            $label = 'Data Antrol Tanggal '.date($tanggal1) .date($tanggal2);
            $Antrol = $this->Antrol_model->view_by_date($tanggal1, $tanggal2); 
        }else if($filter == '2'){ 
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
            $label = 'Data Antrol Bulan '.$nama_bulan[$bulan].' '.$tahun;
            $Antrol = $this->Antrol_model->view_by_month($bulan, $tahun); 
        }else if($filter == '3'){ 
            $tahun = $_GET['tahun'];
            $label = 'Data Tahun '.$tahun;
            $Antrol = $this->Antrol_model->view_by_year($tahun);
        } 
    } else { 
        $label = 'Semua Data Antrol RSUD H. Abdul Aziz Marabahan';
        $Antrol = $this->Antrol_model->view_all();
    }
    
    $excel->setActiveSheetIndex(0);
    $excel->getActiveSheet()->setCellValue('A1', $label); 
    $excel->getActiveSheet()->mergeCells('A1:I1');
    $excel->getActiveSheet()->setCellValue('A4', "No");
    $excel->getActiveSheet()->setCellValue('B4', "Tanggal Periksa");
    $excel->getActiveSheet()->setCellValue('C4', "No. RM"); 
    $excel->getActiveSheet()->setCellValue('D4', "No. Kartu");
    $excel->getActiveSheet()->setCellValue('E4', "No. Referensi");
    $excel->getActiveSheet()->setCellValue('F4', "Jenis Kunjungan");
    $excel->getActiveSheet()->setCellValue('G4', "Status Kirim");
    $excel->getActiveSheet()->setCellValue('H4', "Keterangan");
    $excel->getActiveSheet()->setCellValue('I4', "Kode Booking");
    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('E4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('F4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('G4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('H4')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('I4')->applyFromArray($style_col);

    $excel->getActiveSheet()->getRowDimension('1')->setRowHeight(100);
    $excel->getActiveSheet()->getRowDimension('2')->setRowHeight(20);
    $excel->getActiveSheet()->getRowDimension('3')->setRowHeight(20);
    $excel->getActiveSheet()->getRowDimension('4')->setRowHeight(20);
    $excel->getActiveSheet()->getRowDimension('5')->setRowHeight(20);
    $excel->getActiveSheet()->getRowDimension('6')->setRowHeight(40);
    $excel->getActiveSheet()->getRowDimension('7')->setRowHeight(20);
    $excel->getActiveSheet()->getRowDimension('8')->setRowHeight(50);
    $excel->getActiveSheet()->getRowDimension('9')->setRowHeight(50);
    $no = 1; 
    $numrow = 5; 
    foreach($Antrol as $data){ 
        
        $data_array = json_decode(json_encode($data), true);
        $excel->getActiveSheet()->setCellValue('A'.$numrow, $no);
        $excel->getActiveSheet()->setCellValue('B'.$numrow, $data_array['tanggal_periksa']);
        $excel->getActiveSheet()->setCellValue('C'.$numrow, $data_array['no_rkm_medis']);
        $excel->getActiveSheet()->setCellValue('D'.$numrow, $data_array['nomor_kartu']);
        $excel->getActiveSheet()->setCellValue('E'.$numrow, $data_array['nomor_referensi']);
        $excel->getActiveSheet()->setCellValue('F'.$numrow, $data_array['jenis_kunjungan']);
        $excel->getActiveSheet()->setCellValue('G'.$numrow, $data_array['status_kirim']);
        $excel->getActiveSheet()->setCellValue('H'.$numrow, $data_array['keterangan']);
        $excel->getActiveSheet()->setCellValue('I'.$numrow, $data_array['kodebooking']);
        $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getRowDimension($numrow)->setRowHeight(20);
        $no++; 
        $numrow++; 
        }

        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5); 
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); 
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(10); 
        $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
        $excel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
        $excel->getActiveSheet()->getColumnDimension('H')->setWidth(50);
        $excel->getActiveSheet()->getColumnDimension('I')->setWidth(40);

        $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

        $excel->getActiveSheet()->setTitle("Data Antrol ");
        $excel->getActiveSheet();
        //ob_end_clean();

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Data Antrol.xlsx"'); 
        header('Cache-Control: max-age=0');
        $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $write->save('php://output');
    }
    
}
