<?php defined('BASEPATH') or exit('No direct script access allowed');

class Data_model extends CI_Model
{
    private $_table = "reg_periksa";

    public $tanggal_periksa;    
    public $no_rkm_medis;    
    public $nomor_kartu;    
    public $nomor_referensi;    
    public $jenis_kunjungan;    
    public $status_kirim;    
    public $keterangan;    

    public function rules()
    {
        
        
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }

    public function getById($id_inventaris)
    {
        return $this->db->get_where($this->_table, ["id_inventaris" => $id_inventaris])->row();
    }

    public function getRajal()
{
    $query = "SELECT
                r.no_rkm_medis AS NRM,
                r.stts_daftar AS Pengunjung,
                rm.perujuk AS cara_masuk,
                r.tgl_registrasi AS Tanggal_Pendaftaran,
                px.nm_pasien AS nama,
                px.jk AS jenis_kelamin,
                DATEDIFF(CURDATE(), px.tgl_lahir) AS umur_hari,
                px.alamat AS Alamat,
                px.kecamatanpj AS kecamatan,
                px.kabupatenpj AS kabupaten,
                px.propinsipj AS provinsi,
                GROUP_CONCAT(dpx.kd_penyakit SEPARATOR ';') AS diagnosa,
                GROUP_CONCAT(ppx.kode SEPARATOR ';') AS tindakan,
                rj.rujuk_ke AS cara_keluar,
                d.nm_dokter AS DPJP,
                pj.png_jawab AS Pembayaran,
                p.nm_poli AS Poli,
                r.status_poli AS Kunjungan
            FROM reg_periksa r
            LEFT JOIN dokter d ON r.kd_dokter = d.kd_dokter
            LEFT JOIN poliklinik p ON r.kd_poli = p.kd_poli
            LEFT JOIN pasien px ON r.no_rkm_medis = px.no_rkm_medis
            LEFT JOIN penjab pj ON r.kd_pj = pj.kd_pj
            LEFT JOIN diagnosa_pasien dpx ON r.no_rawat = dpx.no_rawat
            LEFT JOIN prosedur_pasien ppx ON r.no_rawat = ppx.no_rawat
            LEFT JOIN rujuk_masuk rm ON r.no_rawat = rm.no_rawat
            LEFT JOIN rujuk rj ON r.no_rawat = rj.no_rawat
            WHERE MONTH(r.tgl_registrasi) = MONTH(CURDATE())
              AND YEAR(r.tgl_registrasi) = YEAR(CURDATE())
              AND r.status_lanjut = 'ralan'
            GROUP BY r.no_rawat";

    return $this->db->query($query)->result_array();
}

public function getRanap()
{
    $query = "SELECT
    r.no_rkm_medis AS NRM,
                r.stts_daftar AS Pengunjung,
                rm.perujuk AS cara_masuk,
                r.tgl_registrasi AS Tanggal_Pendaftaran,
                px.nm_pasien AS nama,
                px.jk AS jenis_kelamin,
                ki.stts_pulang AS stts_pulang,  
                r.tgl_registrasi AS Tanggal_masuk,
                r.tgl_registrasi AS Tanggal_keluar,
                DATEDIFF(CURDATE(), px.tgl_lahir) AS umur_hari,
                px.alamat AS Alamat,
                px.kecamatanpj AS kecamatan,
                px.kabupatenpj AS kabupaten,
                px.propinsipj AS provinsi,
                GROUP_CONCAT(dpx.kd_penyakit SEPARATOR ';') AS diagnosa,
                GROUP_CONCAT(ppx.kode SEPARATOR ';') AS tindakan,
                rj.rujuk_ke AS cara_keluar,
                d.nm_dokter AS DPJP,
                pj.png_jawab AS Pembayaran,
                p.nm_poli AS Poli,
                r.status_poli AS Kunjungan,
                b.nm_bangsal as ruang,
		        k.kelas as kelas
            FROM reg_periksa r
            LEFT JOIN dokter d ON r.kd_dokter = d.kd_dokter
            LEFT JOIN poliklinik p ON r.kd_poli = p.kd_poli
            LEFT JOIN pasien px ON r.no_rkm_medis = px.no_rkm_medis
            LEFT JOIN penjab pj ON r.kd_pj = pj.kd_pj
            LEFT JOIN diagnosa_pasien dpx ON r.no_rawat = dpx.no_rawat
            LEFT JOIN prosedur_pasien ppx ON r.no_rawat = ppx.no_rawat
            LEFT JOIN rujuk_masuk rm ON r.no_rawat = rm.no_rawat
            LEFT JOIN rujuk rj ON r.no_rawat = rj.no_rawat
            LEFT JOIN kamar_inap ki ON r.no_rawat = ki.no_rawat
            LEFT JOIN kamar k ON ki.kd_kamar = k.kd_kamar
            LEFT JOIN bangsal b ON k.kd_bangsal = b.kd_bangsal
            WHERE MONTH(r.tgl_registrasi) = MONTH(CURDATE())
              AND YEAR(r.tgl_registrasi) = YEAR(CURDATE())
              AND r.status_lanjut = 'ranap'
            GROUP BY r.no_rawat";

    return $this->db->query($query)->result_array();
}



    public function getAntrolByDateRange($start_date, $end_date)
        {
            $query = "SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '$start_date'
                AND `tanggal_periksa` <= '$end_date'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            ";
            return $this->db->query($query)->result_array();
        }

    public function getTotalKirim($status)
    {
        $query = $this->db->query("
            SELECT COUNT(*) as total_kirim 
            FROM mlite_antrian_referensi 
            WHERE MONTH(tanggal_periksa) = MONTH(CURDATE()) 
            AND YEAR(tanggal_periksa) = YEAR(CURDATE()) 
            AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking', 'null : null') 
            AND status_kirim = '$status'
            ");
        return $query->row()->total_kirim;
    }

    public function getTotalSEP()
    {
        $query = $this->db->query("
            SELECT COUNT(*) as total_sep 
            FROM bridging_sep 
            WHERE MONTH(tglsep) = MONTH(CURDATE()) 
            AND YEAR(tglsep) = YEAR(CURDATE()) 
            ");
        return $query->row()->total_sep;
    }

        public function view_by_date($date1, $date2)
        {
            $this->db->select('mlite_antrian_referensi.*');
            $this->db->from('mlite_antrian_referensi');
            $this->db->where('tanggal_periksa >=', $date1);
            $this->db->where('tanggal_periksa <=', $date2);
            $this->db->where_not_in('keterangan', ['Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking']);

            return $this->db->get()->result();

        }
        
        public function view_by_month($month, $year)
        {
            $this->db->select('mlite_antrian_referensi.*');
            $this->db->from('mlite_antrian_referensi');
            $this->db->where('MONTH(mlite_antrian_referensi.tanggal_periksa)', $month); 
            $this->db->where('YEAR(mlite_antrian_referensi.tanggal_periksa)', $year); 
            $this->db->where_not_in('keterangan', ['Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking']);
 
            return $this->db->get()->result();
        }
    
        public function view_by_year($year)
        {
            $this->db->select('mlite_antrian_referensi.*');
            $this->db->from('mlite_antrian_referensi');
            $this->db->where('YEAR(tanggal_periksa)', $year);  
            $this->db->where_not_in('keterangan', ['Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking']);

            return $this->db->get()->result();
        }
       
        public function view_all(){
            $this->db->select('mlite_antrian_referensi.*');
            $this->db->from('mlite_antrian_referensi');
            $this->db->where('MONTH(tanggal_periksa) = MONTH(CURDATE())');
            $this->db->where('YEAR(tanggal_periksa) = YEAR(CURDATE())');
            $this->db->where_not_in('keterangan', ['Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking']);
            
            return $this->db->get()->result();
        }
    
        public function option_tahun(){
            $this->db->select('YEAR(tanggal_periksa) AS tahun'); 
            $this->db->from('mlite_antrian_referensi'); 
            $this->db->order_by('YEAR(tanggal_periksa)'); 
            $this->db->group_by('YEAR(tanggal_periksa)');
            return $this->db->get()->result(); 
        }
}
