<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-25 08:43:39 --> Config Class Initialized
INFO - 2024-10-25 08:43:39 --> Hooks Class Initialized
DEBUG - 2024-10-25 08:43:39 --> UTF-8 Support Enabled
INFO - 2024-10-25 08:43:39 --> Utf8 Class Initialized
INFO - 2024-10-25 08:43:39 --> URI Class Initialized
DEBUG - 2024-10-25 08:43:39 --> No URI present. Default controller set.
INFO - 2024-10-25 08:43:39 --> Router Class Initialized
INFO - 2024-10-25 08:43:39 --> Output Class Initialized
INFO - 2024-10-25 08:43:39 --> Security Class Initialized
DEBUG - 2024-10-25 08:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 08:43:39 --> Input Class Initialized
INFO - 2024-10-25 08:43:39 --> Language Class Initialized
INFO - 2024-10-25 08:43:39 --> Loader Class Initialized
INFO - 2024-10-25 08:43:39 --> Helper loaded: url_helper
INFO - 2024-10-25 08:43:39 --> Helper loaded: file_helper
INFO - 2024-10-25 08:43:39 --> Helper loaded: security_helper
INFO - 2024-10-25 08:43:39 --> Helper loaded: wpu_helper
INFO - 2024-10-25 08:43:39 --> Database Driver Class Initialized
ERROR - 2024-10-25 08:43:41 --> Unable to connect to the database
INFO - 2024-10-25 08:43:41 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-25 14:13:41 --> Config Class Initialized
INFO - 2024-10-25 14:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:13:41 --> Utf8 Class Initialized
INFO - 2024-10-25 14:13:41 --> URI Class Initialized
DEBUG - 2024-10-25 14:13:41 --> No URI present. Default controller set.
INFO - 2024-10-25 14:13:41 --> Router Class Initialized
INFO - 2024-10-25 14:13:41 --> Output Class Initialized
INFO - 2024-10-25 14:13:41 --> Security Class Initialized
DEBUG - 2024-10-25 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:13:41 --> Input Class Initialized
INFO - 2024-10-25 14:13:41 --> Language Class Initialized
INFO - 2024-10-25 14:13:41 --> Loader Class Initialized
INFO - 2024-10-25 14:13:41 --> Helper loaded: url_helper
INFO - 2024-10-25 14:13:41 --> Helper loaded: file_helper
INFO - 2024-10-25 14:13:41 --> Helper loaded: security_helper
INFO - 2024-10-25 14:13:41 --> Helper loaded: wpu_helper
INFO - 2024-10-25 14:13:41 --> Database Driver Class Initialized
ERROR - 2024-10-25 14:13:44 --> Unable to connect to the database
INFO - 2024-10-25 14:13:44 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-25 14:13:45 --> Config Class Initialized
INFO - 2024-10-25 14:13:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:13:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:13:45 --> Utf8 Class Initialized
INFO - 2024-10-25 14:13:45 --> URI Class Initialized
DEBUG - 2024-10-25 14:13:45 --> No URI present. Default controller set.
INFO - 2024-10-25 14:13:45 --> Router Class Initialized
INFO - 2024-10-25 14:13:45 --> Output Class Initialized
INFO - 2024-10-25 14:13:45 --> Security Class Initialized
DEBUG - 2024-10-25 14:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:13:45 --> Input Class Initialized
INFO - 2024-10-25 14:13:45 --> Language Class Initialized
INFO - 2024-10-25 14:13:45 --> Loader Class Initialized
INFO - 2024-10-25 14:13:45 --> Helper loaded: url_helper
INFO - 2024-10-25 14:13:45 --> Helper loaded: file_helper
INFO - 2024-10-25 14:13:45 --> Helper loaded: security_helper
INFO - 2024-10-25 14:13:45 --> Helper loaded: wpu_helper
INFO - 2024-10-25 14:13:45 --> Database Driver Class Initialized
ERROR - 2024-10-25 14:13:47 --> Unable to connect to the database
INFO - 2024-10-25 14:13:47 --> Language file loaded: language/english/db_lang.php
