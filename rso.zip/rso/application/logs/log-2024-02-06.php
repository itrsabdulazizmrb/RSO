<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-06 00:53:13 --> Config Class Initialized
INFO - 2024-02-06 00:53:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:13 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:13 --> URI Class Initialized
DEBUG - 2024-02-06 00:53:13 --> No URI present. Default controller set.
INFO - 2024-02-06 00:53:13 --> Router Class Initialized
INFO - 2024-02-06 00:53:13 --> Output Class Initialized
INFO - 2024-02-06 00:53:13 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:13 --> Input Class Initialized
INFO - 2024-02-06 00:53:13 --> Language Class Initialized
INFO - 2024-02-06 00:53:13 --> Loader Class Initialized
INFO - 2024-02-06 00:53:13 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:13 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:13 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:13 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:14 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:14 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:14 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:14 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:14 --> Controller Class Initialized
DEBUG - 2024-02-06 00:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-06 00:53:14 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-06 00:53:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-06 00:53:14 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:14 --> Total execution time: 0.5754
INFO - 2024-02-06 00:53:18 --> Config Class Initialized
INFO - 2024-02-06 00:53:18 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:18 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:18 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:18 --> URI Class Initialized
INFO - 2024-02-06 00:53:18 --> Router Class Initialized
INFO - 2024-02-06 00:53:18 --> Output Class Initialized
INFO - 2024-02-06 00:53:18 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:18 --> Input Class Initialized
INFO - 2024-02-06 00:53:18 --> Language Class Initialized
INFO - 2024-02-06 00:53:19 --> Loader Class Initialized
INFO - 2024-02-06 00:53:19 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:19 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:19 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:19 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:19 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:19 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:19 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:19 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:19 --> Controller Class Initialized
DEBUG - 2024-02-06 00:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-06 00:53:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-06 00:53:19 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-06 00:53:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-06 00:53:19 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:19 --> Total execution time: 0.0511
INFO - 2024-02-06 00:53:21 --> Config Class Initialized
INFO - 2024-02-06 00:53:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:21 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:21 --> URI Class Initialized
INFO - 2024-02-06 00:53:21 --> Router Class Initialized
INFO - 2024-02-06 00:53:21 --> Output Class Initialized
INFO - 2024-02-06 00:53:21 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:21 --> Input Class Initialized
INFO - 2024-02-06 00:53:21 --> Language Class Initialized
INFO - 2024-02-06 00:53:21 --> Loader Class Initialized
INFO - 2024-02-06 00:53:21 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:21 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:21 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:21 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:21 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:21 --> Controller Class Initialized
DEBUG - 2024-02-06 00:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-06 00:53:21 --> Config Class Initialized
INFO - 2024-02-06 00:53:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:21 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:21 --> URI Class Initialized
INFO - 2024-02-06 00:53:21 --> Router Class Initialized
INFO - 2024-02-06 00:53:21 --> Output Class Initialized
INFO - 2024-02-06 00:53:21 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:21 --> Input Class Initialized
INFO - 2024-02-06 00:53:21 --> Language Class Initialized
INFO - 2024-02-06 00:53:21 --> Loader Class Initialized
INFO - 2024-02-06 00:53:21 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:21 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:21 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:21 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:21 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:21 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:21 --> Controller Class Initialized
INFO - 2024-02-06 00:53:21 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:21 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-06 00:53:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:21 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:21 --> Total execution time: 0.2734
INFO - 2024-02-06 00:53:23 --> Config Class Initialized
INFO - 2024-02-06 00:53:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:23 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:23 --> URI Class Initialized
INFO - 2024-02-06 00:53:23 --> Router Class Initialized
INFO - 2024-02-06 00:53:23 --> Output Class Initialized
INFO - 2024-02-06 00:53:23 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:23 --> Input Class Initialized
INFO - 2024-02-06 00:53:23 --> Language Class Initialized
INFO - 2024-02-06 00:53:23 --> Loader Class Initialized
INFO - 2024-02-06 00:53:23 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:23 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:23 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:23 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:23 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:23 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:23 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:23 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:23 --> Controller Class Initialized
INFO - 2024-02-06 00:53:23 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:23 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-06 00:53:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:23 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:23 --> Total execution time: 0.0519
INFO - 2024-02-06 00:53:24 --> Config Class Initialized
INFO - 2024-02-06 00:53:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:24 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:24 --> URI Class Initialized
INFO - 2024-02-06 00:53:24 --> Router Class Initialized
INFO - 2024-02-06 00:53:24 --> Output Class Initialized
INFO - 2024-02-06 00:53:24 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:24 --> Input Class Initialized
INFO - 2024-02-06 00:53:24 --> Language Class Initialized
INFO - 2024-02-06 00:53:24 --> Loader Class Initialized
INFO - 2024-02-06 00:53:24 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:24 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:24 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:24 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:24 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:24 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:24 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:24 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:24 --> Controller Class Initialized
INFO - 2024-02-06 00:53:24 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-02-06 00:53:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:24 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:24 --> Total execution time: 0.0897
INFO - 2024-02-06 00:53:27 --> Config Class Initialized
INFO - 2024-02-06 00:53:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:27 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:27 --> URI Class Initialized
INFO - 2024-02-06 00:53:27 --> Router Class Initialized
INFO - 2024-02-06 00:53:27 --> Output Class Initialized
INFO - 2024-02-06 00:53:27 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:27 --> Input Class Initialized
INFO - 2024-02-06 00:53:27 --> Language Class Initialized
INFO - 2024-02-06 00:53:27 --> Loader Class Initialized
INFO - 2024-02-06 00:53:27 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:27 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:27 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:27 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:27 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:27 --> Controller Class Initialized
INFO - 2024-02-06 00:53:27 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:27 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:27 --> Total execution time: 0.0665
INFO - 2024-02-06 00:53:27 --> Config Class Initialized
INFO - 2024-02-06 00:53:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:27 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:27 --> URI Class Initialized
INFO - 2024-02-06 00:53:27 --> Router Class Initialized
INFO - 2024-02-06 00:53:27 --> Output Class Initialized
INFO - 2024-02-06 00:53:27 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:27 --> Input Class Initialized
INFO - 2024-02-06 00:53:27 --> Language Class Initialized
INFO - 2024-02-06 00:53:27 --> Loader Class Initialized
INFO - 2024-02-06 00:53:27 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:27 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:27 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:27 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:27 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:27 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:27 --> Controller Class Initialized
INFO - 2024-02-06 00:53:27 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-06 00:53:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:27 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:27 --> Total execution time: 0.0556
INFO - 2024-02-06 00:53:29 --> Config Class Initialized
INFO - 2024-02-06 00:53:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:29 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:29 --> URI Class Initialized
INFO - 2024-02-06 00:53:29 --> Router Class Initialized
INFO - 2024-02-06 00:53:29 --> Output Class Initialized
INFO - 2024-02-06 00:53:29 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:29 --> Input Class Initialized
INFO - 2024-02-06 00:53:29 --> Language Class Initialized
INFO - 2024-02-06 00:53:29 --> Loader Class Initialized
INFO - 2024-02-06 00:53:29 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:29 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:29 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:29 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:29 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:29 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:29 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:29 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:29 --> Controller Class Initialized
INFO - 2024-02-06 00:53:29 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:29 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 00:53:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 00:53:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 00:53:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 00:53:29 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 00:53:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 00:53:29 --> Final output sent to browser
DEBUG - 2024-02-06 00:53:29 --> Total execution time: 0.0975
INFO - 2024-02-06 00:53:30 --> Config Class Initialized
INFO - 2024-02-06 00:53:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:53:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:53:30 --> Utf8 Class Initialized
INFO - 2024-02-06 00:53:30 --> URI Class Initialized
INFO - 2024-02-06 00:53:30 --> Router Class Initialized
INFO - 2024-02-06 00:53:30 --> Output Class Initialized
INFO - 2024-02-06 00:53:30 --> Security Class Initialized
DEBUG - 2024-02-06 00:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:53:30 --> Input Class Initialized
INFO - 2024-02-06 00:53:30 --> Language Class Initialized
INFO - 2024-02-06 00:53:30 --> Loader Class Initialized
INFO - 2024-02-06 00:53:30 --> Helper loaded: url_helper
INFO - 2024-02-06 00:53:30 --> Helper loaded: file_helper
INFO - 2024-02-06 00:53:30 --> Helper loaded: security_helper
INFO - 2024-02-06 00:53:30 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:53:30 --> Database Driver Class Initialized
INFO - 2024-02-06 00:53:30 --> Email Class Initialized
DEBUG - 2024-02-06 00:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:53:30 --> Helper loaded: form_helper
INFO - 2024-02-06 00:53:30 --> Form Validation Class Initialized
INFO - 2024-02-06 00:53:30 --> Controller Class Initialized
INFO - 2024-02-06 00:53:30 --> Model "User_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:53:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:53:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:53:32 --> Severity: error --> Exception: File https://example.com/path/to/your/photo.jpg not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:54:00 --> Config Class Initialized
INFO - 2024-02-06 00:54:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:54:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:54:00 --> Utf8 Class Initialized
INFO - 2024-02-06 00:54:00 --> URI Class Initialized
INFO - 2024-02-06 00:54:00 --> Router Class Initialized
INFO - 2024-02-06 00:54:00 --> Output Class Initialized
INFO - 2024-02-06 00:54:00 --> Security Class Initialized
DEBUG - 2024-02-06 00:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:54:00 --> Input Class Initialized
INFO - 2024-02-06 00:54:00 --> Language Class Initialized
INFO - 2024-02-06 00:54:00 --> Loader Class Initialized
INFO - 2024-02-06 00:54:00 --> Helper loaded: url_helper
INFO - 2024-02-06 00:54:00 --> Helper loaded: file_helper
INFO - 2024-02-06 00:54:00 --> Helper loaded: security_helper
INFO - 2024-02-06 00:54:00 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:54:00 --> Database Driver Class Initialized
INFO - 2024-02-06 00:54:00 --> Email Class Initialized
DEBUG - 2024-02-06 00:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:54:00 --> Helper loaded: form_helper
INFO - 2024-02-06 00:54:00 --> Form Validation Class Initialized
INFO - 2024-02-06 00:54:00 --> Controller Class Initialized
INFO - 2024-02-06 00:54:00 --> Model "User_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:54:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:54:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:54:00 --> Severity: error --> Exception: File https://rsudabdulaziz.online/uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:54:01 --> Config Class Initialized
INFO - 2024-02-06 00:54:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:54:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:54:01 --> Utf8 Class Initialized
INFO - 2024-02-06 00:54:01 --> URI Class Initialized
INFO - 2024-02-06 00:54:01 --> Router Class Initialized
INFO - 2024-02-06 00:54:01 --> Output Class Initialized
INFO - 2024-02-06 00:54:01 --> Security Class Initialized
DEBUG - 2024-02-06 00:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:54:01 --> Input Class Initialized
INFO - 2024-02-06 00:54:01 --> Language Class Initialized
INFO - 2024-02-06 00:54:01 --> Loader Class Initialized
INFO - 2024-02-06 00:54:01 --> Helper loaded: url_helper
INFO - 2024-02-06 00:54:01 --> Helper loaded: file_helper
INFO - 2024-02-06 00:54:01 --> Helper loaded: security_helper
INFO - 2024-02-06 00:54:01 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:54:01 --> Database Driver Class Initialized
INFO - 2024-02-06 00:54:01 --> Email Class Initialized
DEBUG - 2024-02-06 00:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:54:01 --> Helper loaded: form_helper
INFO - 2024-02-06 00:54:01 --> Form Validation Class Initialized
INFO - 2024-02-06 00:54:01 --> Controller Class Initialized
INFO - 2024-02-06 00:54:01 --> Model "User_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:54:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:54:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:54:01 --> Severity: error --> Exception: File https://rsudabdulaziz.online/uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:55:50 --> Config Class Initialized
INFO - 2024-02-06 00:55:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:55:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:55:50 --> Utf8 Class Initialized
INFO - 2024-02-06 00:55:50 --> URI Class Initialized
INFO - 2024-02-06 00:55:50 --> Router Class Initialized
INFO - 2024-02-06 00:55:50 --> Output Class Initialized
INFO - 2024-02-06 00:55:50 --> Security Class Initialized
DEBUG - 2024-02-06 00:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:55:50 --> Input Class Initialized
INFO - 2024-02-06 00:55:50 --> Language Class Initialized
INFO - 2024-02-06 00:55:50 --> Loader Class Initialized
INFO - 2024-02-06 00:55:50 --> Helper loaded: url_helper
INFO - 2024-02-06 00:55:50 --> Helper loaded: file_helper
INFO - 2024-02-06 00:55:50 --> Helper loaded: security_helper
INFO - 2024-02-06 00:55:50 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:55:50 --> Database Driver Class Initialized
INFO - 2024-02-06 00:55:50 --> Email Class Initialized
DEBUG - 2024-02-06 00:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:55:50 --> Helper loaded: form_helper
INFO - 2024-02-06 00:55:50 --> Form Validation Class Initialized
INFO - 2024-02-06 00:55:50 --> Controller Class Initialized
INFO - 2024-02-06 00:55:50 --> Model "User_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:55:50 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:55:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:55:50 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:55:51 --> Config Class Initialized
INFO - 2024-02-06 00:55:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:55:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:55:51 --> Utf8 Class Initialized
INFO - 2024-02-06 00:55:51 --> URI Class Initialized
INFO - 2024-02-06 00:55:51 --> Router Class Initialized
INFO - 2024-02-06 00:55:51 --> Output Class Initialized
INFO - 2024-02-06 00:55:51 --> Security Class Initialized
DEBUG - 2024-02-06 00:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:55:51 --> Input Class Initialized
INFO - 2024-02-06 00:55:51 --> Language Class Initialized
INFO - 2024-02-06 00:55:51 --> Loader Class Initialized
INFO - 2024-02-06 00:55:51 --> Helper loaded: url_helper
INFO - 2024-02-06 00:55:51 --> Helper loaded: file_helper
INFO - 2024-02-06 00:55:51 --> Helper loaded: security_helper
INFO - 2024-02-06 00:55:51 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:55:51 --> Database Driver Class Initialized
INFO - 2024-02-06 00:55:51 --> Email Class Initialized
DEBUG - 2024-02-06 00:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:55:51 --> Helper loaded: form_helper
INFO - 2024-02-06 00:55:51 --> Form Validation Class Initialized
INFO - 2024-02-06 00:55:51 --> Controller Class Initialized
INFO - 2024-02-06 00:55:51 --> Model "User_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:55:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:55:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:55:51 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:02 --> Config Class Initialized
INFO - 2024-02-06 00:56:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:02 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:02 --> URI Class Initialized
INFO - 2024-02-06 00:56:02 --> Router Class Initialized
INFO - 2024-02-06 00:56:02 --> Output Class Initialized
INFO - 2024-02-06 00:56:02 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:02 --> Input Class Initialized
INFO - 2024-02-06 00:56:02 --> Language Class Initialized
INFO - 2024-02-06 00:56:02 --> Loader Class Initialized
INFO - 2024-02-06 00:56:02 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:02 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:02 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:02 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:02 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:02 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:02 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:02 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:02 --> Controller Class Initialized
INFO - 2024-02-06 00:56:02 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:03 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:03 --> Config Class Initialized
INFO - 2024-02-06 00:56:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:03 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:03 --> URI Class Initialized
INFO - 2024-02-06 00:56:03 --> Router Class Initialized
INFO - 2024-02-06 00:56:03 --> Output Class Initialized
INFO - 2024-02-06 00:56:03 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:03 --> Input Class Initialized
INFO - 2024-02-06 00:56:03 --> Language Class Initialized
INFO - 2024-02-06 00:56:03 --> Loader Class Initialized
INFO - 2024-02-06 00:56:03 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:03 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:03 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:03 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:03 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:03 --> Controller Class Initialized
INFO - 2024-02-06 00:56:03 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:03 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:03 --> Config Class Initialized
INFO - 2024-02-06 00:56:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:03 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:03 --> URI Class Initialized
INFO - 2024-02-06 00:56:03 --> Router Class Initialized
INFO - 2024-02-06 00:56:03 --> Output Class Initialized
INFO - 2024-02-06 00:56:03 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:03 --> Input Class Initialized
INFO - 2024-02-06 00:56:03 --> Language Class Initialized
INFO - 2024-02-06 00:56:03 --> Loader Class Initialized
INFO - 2024-02-06 00:56:03 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:03 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:03 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:03 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:03 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:03 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:03 --> Controller Class Initialized
INFO - 2024-02-06 00:56:03 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:03 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:04 --> Config Class Initialized
INFO - 2024-02-06 00:56:04 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:04 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:04 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:04 --> URI Class Initialized
INFO - 2024-02-06 00:56:04 --> Router Class Initialized
INFO - 2024-02-06 00:56:04 --> Output Class Initialized
INFO - 2024-02-06 00:56:04 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:04 --> Input Class Initialized
INFO - 2024-02-06 00:56:04 --> Language Class Initialized
INFO - 2024-02-06 00:56:04 --> Loader Class Initialized
INFO - 2024-02-06 00:56:04 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:04 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:04 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:04 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:04 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:04 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:04 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:04 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:04 --> Controller Class Initialized
INFO - 2024-02-06 00:56:04 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:04 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:27 --> Config Class Initialized
INFO - 2024-02-06 00:56:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:27 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:27 --> URI Class Initialized
INFO - 2024-02-06 00:56:27 --> Router Class Initialized
INFO - 2024-02-06 00:56:27 --> Output Class Initialized
INFO - 2024-02-06 00:56:27 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:27 --> Input Class Initialized
INFO - 2024-02-06 00:56:27 --> Language Class Initialized
INFO - 2024-02-06 00:56:27 --> Loader Class Initialized
INFO - 2024-02-06 00:56:27 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:27 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:27 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:27 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:27 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:28 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:28 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:28 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:28 --> Controller Class Initialized
INFO - 2024-02-06 00:56:28 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:28 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets/img/dinas/16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:41 --> Config Class Initialized
INFO - 2024-02-06 00:56:41 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:41 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:41 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:41 --> URI Class Initialized
INFO - 2024-02-06 00:56:41 --> Router Class Initialized
INFO - 2024-02-06 00:56:41 --> Output Class Initialized
INFO - 2024-02-06 00:56:41 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:41 --> Input Class Initialized
INFO - 2024-02-06 00:56:41 --> Language Class Initialized
INFO - 2024-02-06 00:56:41 --> Loader Class Initialized
INFO - 2024-02-06 00:56:41 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:41 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:41 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:41 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:41 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:41 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:41 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:41 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:41 --> Controller Class Initialized
INFO - 2024-02-06 00:56:41 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:42 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets\img\dinas\16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:42 --> Config Class Initialized
INFO - 2024-02-06 00:56:42 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:42 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:42 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:42 --> URI Class Initialized
INFO - 2024-02-06 00:56:42 --> Router Class Initialized
INFO - 2024-02-06 00:56:42 --> Output Class Initialized
INFO - 2024-02-06 00:56:42 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:42 --> Input Class Initialized
INFO - 2024-02-06 00:56:42 --> Language Class Initialized
INFO - 2024-02-06 00:56:42 --> Loader Class Initialized
INFO - 2024-02-06 00:56:42 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:42 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:42 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:42 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:42 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:42 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:42 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:42 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:42 --> Controller Class Initialized
INFO - 2024-02-06 00:56:42 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:42 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets\img\dinas\16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:43 --> Config Class Initialized
INFO - 2024-02-06 00:56:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:43 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:43 --> URI Class Initialized
INFO - 2024-02-06 00:56:43 --> Router Class Initialized
INFO - 2024-02-06 00:56:43 --> Output Class Initialized
INFO - 2024-02-06 00:56:43 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:43 --> Input Class Initialized
INFO - 2024-02-06 00:56:43 --> Language Class Initialized
INFO - 2024-02-06 00:56:43 --> Loader Class Initialized
INFO - 2024-02-06 00:56:43 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:43 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:43 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:43 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:43 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:43 --> Controller Class Initialized
INFO - 2024-02-06 00:56:43 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:43 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets\img\dinas\16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:43 --> Config Class Initialized
INFO - 2024-02-06 00:56:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:43 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:43 --> URI Class Initialized
INFO - 2024-02-06 00:56:43 --> Router Class Initialized
INFO - 2024-02-06 00:56:43 --> Output Class Initialized
INFO - 2024-02-06 00:56:43 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:43 --> Input Class Initialized
INFO - 2024-02-06 00:56:43 --> Language Class Initialized
INFO - 2024-02-06 00:56:43 --> Loader Class Initialized
INFO - 2024-02-06 00:56:43 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:43 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:43 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:43 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:43 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:43 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:43 --> Controller Class Initialized
INFO - 2024-02-06 00:56:43 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:44 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets\img\dinas\16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:56:44 --> Config Class Initialized
INFO - 2024-02-06 00:56:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:56:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:56:44 --> Utf8 Class Initialized
INFO - 2024-02-06 00:56:44 --> URI Class Initialized
INFO - 2024-02-06 00:56:44 --> Router Class Initialized
INFO - 2024-02-06 00:56:44 --> Output Class Initialized
INFO - 2024-02-06 00:56:44 --> Security Class Initialized
DEBUG - 2024-02-06 00:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:56:44 --> Input Class Initialized
INFO - 2024-02-06 00:56:44 --> Language Class Initialized
INFO - 2024-02-06 00:56:44 --> Loader Class Initialized
INFO - 2024-02-06 00:56:44 --> Helper loaded: url_helper
INFO - 2024-02-06 00:56:44 --> Helper loaded: file_helper
INFO - 2024-02-06 00:56:44 --> Helper loaded: security_helper
INFO - 2024-02-06 00:56:44 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:56:44 --> Database Driver Class Initialized
INFO - 2024-02-06 00:56:44 --> Email Class Initialized
DEBUG - 2024-02-06 00:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:56:44 --> Helper loaded: form_helper
INFO - 2024-02-06 00:56:44 --> Form Validation Class Initialized
INFO - 2024-02-06 00:56:44 --> Controller Class Initialized
INFO - 2024-02-06 00:56:44 --> Model "User_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:56:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:56:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:56:44 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\assets\img\dinas\16.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:57:52 --> Config Class Initialized
INFO - 2024-02-06 00:57:52 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:57:52 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:57:52 --> Utf8 Class Initialized
INFO - 2024-02-06 00:57:52 --> URI Class Initialized
INFO - 2024-02-06 00:57:52 --> Router Class Initialized
INFO - 2024-02-06 00:57:52 --> Output Class Initialized
INFO - 2024-02-06 00:57:52 --> Security Class Initialized
DEBUG - 2024-02-06 00:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:57:52 --> Input Class Initialized
INFO - 2024-02-06 00:57:52 --> Language Class Initialized
INFO - 2024-02-06 00:57:52 --> Loader Class Initialized
INFO - 2024-02-06 00:57:52 --> Helper loaded: url_helper
INFO - 2024-02-06 00:57:52 --> Helper loaded: file_helper
INFO - 2024-02-06 00:57:52 --> Helper loaded: security_helper
INFO - 2024-02-06 00:57:52 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:57:52 --> Database Driver Class Initialized
INFO - 2024-02-06 00:57:52 --> Email Class Initialized
DEBUG - 2024-02-06 00:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:57:52 --> Helper loaded: form_helper
INFO - 2024-02-06 00:57:52 --> Form Validation Class Initialized
INFO - 2024-02-06 00:57:52 --> Controller Class Initialized
INFO - 2024-02-06 00:57:52 --> Model "User_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:57:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:57:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:57:52 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:57:53 --> Config Class Initialized
INFO - 2024-02-06 00:57:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:57:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:57:53 --> Utf8 Class Initialized
INFO - 2024-02-06 00:57:53 --> URI Class Initialized
INFO - 2024-02-06 00:57:53 --> Router Class Initialized
INFO - 2024-02-06 00:57:53 --> Output Class Initialized
INFO - 2024-02-06 00:57:53 --> Security Class Initialized
DEBUG - 2024-02-06 00:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:57:53 --> Input Class Initialized
INFO - 2024-02-06 00:57:53 --> Language Class Initialized
INFO - 2024-02-06 00:57:53 --> Loader Class Initialized
INFO - 2024-02-06 00:57:53 --> Helper loaded: url_helper
INFO - 2024-02-06 00:57:53 --> Helper loaded: file_helper
INFO - 2024-02-06 00:57:53 --> Helper loaded: security_helper
INFO - 2024-02-06 00:57:53 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:57:53 --> Database Driver Class Initialized
INFO - 2024-02-06 00:57:53 --> Email Class Initialized
DEBUG - 2024-02-06 00:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:57:53 --> Helper loaded: form_helper
INFO - 2024-02-06 00:57:53 --> Form Validation Class Initialized
INFO - 2024-02-06 00:57:53 --> Controller Class Initialized
INFO - 2024-02-06 00:57:53 --> Model "User_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:57:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:57:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:57:53 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:57:54 --> Config Class Initialized
INFO - 2024-02-06 00:57:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:57:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:57:54 --> Utf8 Class Initialized
INFO - 2024-02-06 00:57:54 --> URI Class Initialized
INFO - 2024-02-06 00:57:54 --> Router Class Initialized
INFO - 2024-02-06 00:57:54 --> Output Class Initialized
INFO - 2024-02-06 00:57:54 --> Security Class Initialized
DEBUG - 2024-02-06 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:57:54 --> Input Class Initialized
INFO - 2024-02-06 00:57:54 --> Language Class Initialized
INFO - 2024-02-06 00:57:54 --> Loader Class Initialized
INFO - 2024-02-06 00:57:54 --> Helper loaded: url_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: file_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: security_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:57:54 --> Database Driver Class Initialized
INFO - 2024-02-06 00:57:54 --> Email Class Initialized
DEBUG - 2024-02-06 00:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:57:54 --> Helper loaded: form_helper
INFO - 2024-02-06 00:57:54 --> Form Validation Class Initialized
INFO - 2024-02-06 00:57:54 --> Controller Class Initialized
INFO - 2024-02-06 00:57:54 --> Model "User_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:57:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:57:54 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:57:54 --> Config Class Initialized
INFO - 2024-02-06 00:57:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:57:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:57:54 --> Utf8 Class Initialized
INFO - 2024-02-06 00:57:54 --> URI Class Initialized
INFO - 2024-02-06 00:57:54 --> Router Class Initialized
INFO - 2024-02-06 00:57:54 --> Output Class Initialized
INFO - 2024-02-06 00:57:54 --> Security Class Initialized
DEBUG - 2024-02-06 00:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:57:54 --> Input Class Initialized
INFO - 2024-02-06 00:57:54 --> Language Class Initialized
INFO - 2024-02-06 00:57:54 --> Loader Class Initialized
INFO - 2024-02-06 00:57:54 --> Helper loaded: url_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: file_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: security_helper
INFO - 2024-02-06 00:57:54 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:57:54 --> Database Driver Class Initialized
INFO - 2024-02-06 00:57:54 --> Email Class Initialized
DEBUG - 2024-02-06 00:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:57:54 --> Helper loaded: form_helper
INFO - 2024-02-06 00:57:54 --> Form Validation Class Initialized
INFO - 2024-02-06 00:57:54 --> Controller Class Initialized
INFO - 2024-02-06 00:57:54 --> Model "User_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:57:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:57:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:57:54 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 00:57:55 --> Config Class Initialized
INFO - 2024-02-06 00:57:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 00:57:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 00:57:55 --> Utf8 Class Initialized
INFO - 2024-02-06 00:57:55 --> URI Class Initialized
INFO - 2024-02-06 00:57:55 --> Router Class Initialized
INFO - 2024-02-06 00:57:55 --> Output Class Initialized
INFO - 2024-02-06 00:57:55 --> Security Class Initialized
DEBUG - 2024-02-06 00:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 00:57:55 --> Input Class Initialized
INFO - 2024-02-06 00:57:55 --> Language Class Initialized
INFO - 2024-02-06 00:57:55 --> Loader Class Initialized
INFO - 2024-02-06 00:57:55 --> Helper loaded: url_helper
INFO - 2024-02-06 00:57:55 --> Helper loaded: file_helper
INFO - 2024-02-06 00:57:55 --> Helper loaded: security_helper
INFO - 2024-02-06 00:57:55 --> Helper loaded: wpu_helper
INFO - 2024-02-06 00:57:55 --> Database Driver Class Initialized
INFO - 2024-02-06 00:57:55 --> Email Class Initialized
DEBUG - 2024-02-06 00:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 00:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 00:57:55 --> Helper loaded: form_helper
INFO - 2024-02-06 00:57:55 --> Form Validation Class Initialized
INFO - 2024-02-06 00:57:55 --> Controller Class Initialized
INFO - 2024-02-06 00:57:55 --> Model "User_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Faktur_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Supplier_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 00:57:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 00:57:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 00:57:55 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\uploads/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:00:22 --> Config Class Initialized
INFO - 2024-02-06 01:00:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:00:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:00:22 --> Utf8 Class Initialized
INFO - 2024-02-06 01:00:22 --> URI Class Initialized
INFO - 2024-02-06 01:00:22 --> Router Class Initialized
INFO - 2024-02-06 01:00:22 --> Output Class Initialized
INFO - 2024-02-06 01:00:22 --> Security Class Initialized
DEBUG - 2024-02-06 01:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:00:22 --> Input Class Initialized
INFO - 2024-02-06 01:00:22 --> Language Class Initialized
INFO - 2024-02-06 01:00:22 --> Loader Class Initialized
INFO - 2024-02-06 01:00:22 --> Helper loaded: url_helper
INFO - 2024-02-06 01:00:22 --> Helper loaded: file_helper
INFO - 2024-02-06 01:00:22 --> Helper loaded: security_helper
INFO - 2024-02-06 01:00:22 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:00:22 --> Database Driver Class Initialized
INFO - 2024-02-06 01:00:22 --> Email Class Initialized
DEBUG - 2024-02-06 01:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:00:22 --> Helper loaded: form_helper
INFO - 2024-02-06 01:00:22 --> Form Validation Class Initialized
INFO - 2024-02-06 01:00:22 --> Controller Class Initialized
INFO - 2024-02-06 01:00:22 --> Model "User_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:00:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:00:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:00:23 --> Final output sent to browser
DEBUG - 2024-02-06 01:00:23 --> Total execution time: 0.5254
INFO - 2024-02-06 01:00:23 --> Config Class Initialized
INFO - 2024-02-06 01:00:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:00:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:00:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:00:23 --> URI Class Initialized
INFO - 2024-02-06 01:00:23 --> Router Class Initialized
INFO - 2024-02-06 01:00:23 --> Output Class Initialized
INFO - 2024-02-06 01:00:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:00:23 --> Input Class Initialized
INFO - 2024-02-06 01:00:23 --> Language Class Initialized
INFO - 2024-02-06 01:00:23 --> Loader Class Initialized
INFO - 2024-02-06 01:00:23 --> Helper loaded: url_helper
INFO - 2024-02-06 01:00:23 --> Helper loaded: file_helper
INFO - 2024-02-06 01:00:23 --> Helper loaded: security_helper
INFO - 2024-02-06 01:00:23 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:00:23 --> Database Driver Class Initialized
INFO - 2024-02-06 01:00:23 --> Email Class Initialized
DEBUG - 2024-02-06 01:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:00:23 --> Helper loaded: form_helper
INFO - 2024-02-06 01:00:23 --> Form Validation Class Initialized
INFO - 2024-02-06 01:00:23 --> Controller Class Initialized
INFO - 2024-02-06 01:00:23 --> Model "User_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:00:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:00:23 --> Final output sent to browser
DEBUG - 2024-02-06 01:00:23 --> Total execution time: 0.1464
INFO - 2024-02-06 01:02:09 --> Config Class Initialized
INFO - 2024-02-06 01:02:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:02:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:02:09 --> Utf8 Class Initialized
INFO - 2024-02-06 01:02:09 --> URI Class Initialized
INFO - 2024-02-06 01:02:09 --> Router Class Initialized
INFO - 2024-02-06 01:02:09 --> Output Class Initialized
INFO - 2024-02-06 01:02:09 --> Security Class Initialized
DEBUG - 2024-02-06 01:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:02:09 --> Input Class Initialized
INFO - 2024-02-06 01:02:09 --> Language Class Initialized
INFO - 2024-02-06 01:02:09 --> Loader Class Initialized
INFO - 2024-02-06 01:02:09 --> Helper loaded: url_helper
INFO - 2024-02-06 01:02:09 --> Helper loaded: file_helper
INFO - 2024-02-06 01:02:09 --> Helper loaded: security_helper
INFO - 2024-02-06 01:02:09 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:02:09 --> Database Driver Class Initialized
INFO - 2024-02-06 01:02:09 --> Email Class Initialized
DEBUG - 2024-02-06 01:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:02:09 --> Helper loaded: form_helper
INFO - 2024-02-06 01:02:09 --> Form Validation Class Initialized
INFO - 2024-02-06 01:02:09 --> Controller Class Initialized
INFO - 2024-02-06 01:02:09 --> Model "User_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:02:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:02:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:02:09 --> Final output sent to browser
DEBUG - 2024-02-06 01:02:09 --> Total execution time: 0.1195
INFO - 2024-02-06 01:03:08 --> Config Class Initialized
INFO - 2024-02-06 01:03:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:03:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:03:08 --> Utf8 Class Initialized
INFO - 2024-02-06 01:03:08 --> URI Class Initialized
INFO - 2024-02-06 01:03:08 --> Router Class Initialized
INFO - 2024-02-06 01:03:08 --> Output Class Initialized
INFO - 2024-02-06 01:03:08 --> Security Class Initialized
DEBUG - 2024-02-06 01:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:03:08 --> Input Class Initialized
INFO - 2024-02-06 01:03:08 --> Language Class Initialized
INFO - 2024-02-06 01:03:08 --> Loader Class Initialized
INFO - 2024-02-06 01:03:08 --> Helper loaded: url_helper
INFO - 2024-02-06 01:03:08 --> Helper loaded: file_helper
INFO - 2024-02-06 01:03:08 --> Helper loaded: security_helper
INFO - 2024-02-06 01:03:08 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:03:08 --> Database Driver Class Initialized
INFO - 2024-02-06 01:03:08 --> Email Class Initialized
DEBUG - 2024-02-06 01:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:03:08 --> Helper loaded: form_helper
INFO - 2024-02-06 01:03:08 --> Form Validation Class Initialized
INFO - 2024-02-06 01:03:08 --> Controller Class Initialized
INFO - 2024-02-06 01:03:08 --> Model "User_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:03:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:03:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:03:08 --> Final output sent to browser
DEBUG - 2024-02-06 01:03:08 --> Total execution time: 0.1395
INFO - 2024-02-06 01:03:22 --> Config Class Initialized
INFO - 2024-02-06 01:03:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:03:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:03:22 --> Utf8 Class Initialized
INFO - 2024-02-06 01:03:22 --> URI Class Initialized
INFO - 2024-02-06 01:03:22 --> Router Class Initialized
INFO - 2024-02-06 01:03:22 --> Output Class Initialized
INFO - 2024-02-06 01:03:22 --> Security Class Initialized
DEBUG - 2024-02-06 01:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:03:22 --> Input Class Initialized
INFO - 2024-02-06 01:03:22 --> Language Class Initialized
INFO - 2024-02-06 01:03:22 --> Loader Class Initialized
INFO - 2024-02-06 01:03:22 --> Helper loaded: url_helper
INFO - 2024-02-06 01:03:22 --> Helper loaded: file_helper
INFO - 2024-02-06 01:03:22 --> Helper loaded: security_helper
INFO - 2024-02-06 01:03:22 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:03:22 --> Database Driver Class Initialized
INFO - 2024-02-06 01:03:22 --> Email Class Initialized
DEBUG - 2024-02-06 01:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:03:22 --> Helper loaded: form_helper
INFO - 2024-02-06 01:03:22 --> Form Validation Class Initialized
INFO - 2024-02-06 01:03:22 --> Controller Class Initialized
INFO - 2024-02-06 01:03:22 --> Model "User_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:03:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:03:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:03:22 --> Final output sent to browser
DEBUG - 2024-02-06 01:03:22 --> Total execution time: 0.1228
INFO - 2024-02-06 01:04:08 --> Config Class Initialized
INFO - 2024-02-06 01:04:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:08 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:08 --> URI Class Initialized
INFO - 2024-02-06 01:04:08 --> Router Class Initialized
INFO - 2024-02-06 01:04:08 --> Output Class Initialized
INFO - 2024-02-06 01:04:08 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:08 --> Input Class Initialized
INFO - 2024-02-06 01:04:08 --> Language Class Initialized
INFO - 2024-02-06 01:04:08 --> Loader Class Initialized
INFO - 2024-02-06 01:04:08 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:08 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:08 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:08 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:08 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:08 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:08 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:08 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:08 --> Controller Class Initialized
INFO - 2024-02-06 01:04:08 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:08 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:08 --> Total execution time: 0.1194
INFO - 2024-02-06 01:04:23 --> Config Class Initialized
INFO - 2024-02-06 01:04:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:23 --> URI Class Initialized
INFO - 2024-02-06 01:04:23 --> Router Class Initialized
INFO - 2024-02-06 01:04:23 --> Output Class Initialized
INFO - 2024-02-06 01:04:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:23 --> Input Class Initialized
INFO - 2024-02-06 01:04:23 --> Language Class Initialized
INFO - 2024-02-06 01:04:23 --> Loader Class Initialized
INFO - 2024-02-06 01:04:23 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:23 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:23 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:23 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:23 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:23 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:23 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:23 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:23 --> Controller Class Initialized
INFO - 2024-02-06 01:04:23 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:23 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:04:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:23 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:23 --> Total execution time: 0.0507
INFO - 2024-02-06 01:04:24 --> Config Class Initialized
INFO - 2024-02-06 01:04:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:24 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:24 --> URI Class Initialized
INFO - 2024-02-06 01:04:24 --> Router Class Initialized
INFO - 2024-02-06 01:04:24 --> Output Class Initialized
INFO - 2024-02-06 01:04:24 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:24 --> Input Class Initialized
INFO - 2024-02-06 01:04:24 --> Language Class Initialized
INFO - 2024-02-06 01:04:24 --> Loader Class Initialized
INFO - 2024-02-06 01:04:24 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:24 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:24 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:24 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:24 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:24 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:24 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:24 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:24 --> Controller Class Initialized
INFO - 2024-02-06 01:04:24 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:24 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:24 --> Total execution time: 0.0758
INFO - 2024-02-06 01:04:32 --> Config Class Initialized
INFO - 2024-02-06 01:04:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:32 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:32 --> URI Class Initialized
INFO - 2024-02-06 01:04:32 --> Router Class Initialized
INFO - 2024-02-06 01:04:32 --> Output Class Initialized
INFO - 2024-02-06 01:04:32 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:32 --> Input Class Initialized
INFO - 2024-02-06 01:04:32 --> Language Class Initialized
INFO - 2024-02-06 01:04:32 --> Loader Class Initialized
INFO - 2024-02-06 01:04:32 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:32 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:32 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:32 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:32 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:32 --> Controller Class Initialized
INFO - 2024-02-06 01:04:32 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:32 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:32 --> Total execution time: 0.0854
INFO - 2024-02-06 01:04:32 --> Config Class Initialized
INFO - 2024-02-06 01:04:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:32 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:32 --> URI Class Initialized
INFO - 2024-02-06 01:04:32 --> Router Class Initialized
INFO - 2024-02-06 01:04:32 --> Output Class Initialized
INFO - 2024-02-06 01:04:32 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:32 --> Input Class Initialized
INFO - 2024-02-06 01:04:32 --> Language Class Initialized
INFO - 2024-02-06 01:04:32 --> Loader Class Initialized
INFO - 2024-02-06 01:04:32 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:32 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:32 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:32 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:32 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:32 --> Controller Class Initialized
INFO - 2024-02-06 01:04:32 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-06 01:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:32 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:32 --> Total execution time: 0.1059
INFO - 2024-02-06 01:04:33 --> Config Class Initialized
INFO - 2024-02-06 01:04:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:33 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:33 --> URI Class Initialized
INFO - 2024-02-06 01:04:33 --> Router Class Initialized
INFO - 2024-02-06 01:04:33 --> Output Class Initialized
INFO - 2024-02-06 01:04:33 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:33 --> Input Class Initialized
INFO - 2024-02-06 01:04:33 --> Language Class Initialized
INFO - 2024-02-06 01:04:33 --> Loader Class Initialized
INFO - 2024-02-06 01:04:33 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:33 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:33 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:33 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:33 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:33 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:33 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:33 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:33 --> Controller Class Initialized
INFO - 2024-02-06 01:04:33 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:33 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_faktur.php
INFO - 2024-02-06 01:04:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:33 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:33 --> Total execution time: 0.0975
INFO - 2024-02-06 01:04:34 --> Config Class Initialized
INFO - 2024-02-06 01:04:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:34 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:34 --> URI Class Initialized
INFO - 2024-02-06 01:04:34 --> Router Class Initialized
INFO - 2024-02-06 01:04:34 --> Output Class Initialized
INFO - 2024-02-06 01:04:34 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:34 --> Input Class Initialized
INFO - 2024-02-06 01:04:34 --> Language Class Initialized
INFO - 2024-02-06 01:04:34 --> Loader Class Initialized
INFO - 2024-02-06 01:04:34 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:34 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:34 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:34 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:34 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:34 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:34 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:34 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:34 --> Controller Class Initialized
INFO - 2024-02-06 01:04:34 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-06 01:04:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:34 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:34 --> Total execution time: 0.0820
INFO - 2024-02-06 01:04:35 --> Config Class Initialized
INFO - 2024-02-06 01:04:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:35 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:35 --> URI Class Initialized
INFO - 2024-02-06 01:04:35 --> Router Class Initialized
INFO - 2024-02-06 01:04:35 --> Output Class Initialized
INFO - 2024-02-06 01:04:35 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:35 --> Input Class Initialized
INFO - 2024-02-06 01:04:35 --> Language Class Initialized
INFO - 2024-02-06 01:04:35 --> Loader Class Initialized
INFO - 2024-02-06 01:04:35 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:35 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:35 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:35 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:35 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:35 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:35 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:35 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:35 --> Controller Class Initialized
INFO - 2024-02-06 01:04:35 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-02-06 01:04:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:35 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:35 --> Total execution time: 0.0577
INFO - 2024-02-06 01:04:36 --> Config Class Initialized
INFO - 2024-02-06 01:04:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:36 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:36 --> URI Class Initialized
INFO - 2024-02-06 01:04:36 --> Router Class Initialized
INFO - 2024-02-06 01:04:36 --> Output Class Initialized
INFO - 2024-02-06 01:04:36 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:36 --> Input Class Initialized
INFO - 2024-02-06 01:04:36 --> Language Class Initialized
INFO - 2024-02-06 01:04:36 --> Loader Class Initialized
INFO - 2024-02-06 01:04:36 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:36 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:36 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:36 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:36 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:36 --> Controller Class Initialized
INFO - 2024-02-06 01:04:36 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:36 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:36 --> Total execution time: 0.0501
INFO - 2024-02-06 01:04:36 --> Config Class Initialized
INFO - 2024-02-06 01:04:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:36 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:36 --> URI Class Initialized
INFO - 2024-02-06 01:04:36 --> Router Class Initialized
INFO - 2024-02-06 01:04:36 --> Output Class Initialized
INFO - 2024-02-06 01:04:36 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:36 --> Input Class Initialized
INFO - 2024-02-06 01:04:36 --> Language Class Initialized
INFO - 2024-02-06 01:04:36 --> Loader Class Initialized
INFO - 2024-02-06 01:04:36 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:36 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:36 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:36 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:36 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:36 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:36 --> Controller Class Initialized
INFO - 2024-02-06 01:04:36 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_faktur.php
INFO - 2024-02-06 01:04:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:36 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:36 --> Total execution time: 0.0794
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
INFO - 2024-02-06 01:04:40 --> Config Class Initialized
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> Hooks Class Initialized
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
DEBUG - 2024-02-06 01:04:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
INFO - 2024-02-06 01:04:40 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
INFO - 2024-02-06 01:04:40 --> URI Class Initialized
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Router Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Output Class Initialized
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Security Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
DEBUG - 2024-02-06 01:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:40 --> Input Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Language Class Initialized
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Loader Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:40 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:40 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:40 --> Database Driver Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:40 --> Email Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.0599
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.0702
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.0808
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.0907
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.1058
INFO - 2024-02-06 01:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:40 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:40 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:40 --> Controller Class Initialized
INFO - 2024-02-06 01:04:40 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:40 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:40 --> Total execution time: 0.1173
INFO - 2024-02-06 01:04:50 --> Config Class Initialized
INFO - 2024-02-06 01:04:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:50 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:50 --> URI Class Initialized
INFO - 2024-02-06 01:04:50 --> Router Class Initialized
INFO - 2024-02-06 01:04:50 --> Output Class Initialized
INFO - 2024-02-06 01:04:50 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:50 --> Input Class Initialized
INFO - 2024-02-06 01:04:50 --> Language Class Initialized
INFO - 2024-02-06 01:04:50 --> Loader Class Initialized
INFO - 2024-02-06 01:04:50 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:50 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:50 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:50 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:50 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:50 --> Controller Class Initialized
INFO - 2024-02-06 01:04:50 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-06 01:04:50 --> Helper loaded: inflector_helper
INFO - 2024-02-06 01:04:50 --> Upload Class Initialized
INFO - 2024-02-06 01:04:50 --> Config Class Initialized
INFO - 2024-02-06 01:04:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:50 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:50 --> URI Class Initialized
INFO - 2024-02-06 01:04:50 --> Router Class Initialized
INFO - 2024-02-06 01:04:50 --> Output Class Initialized
INFO - 2024-02-06 01:04:50 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:50 --> Input Class Initialized
INFO - 2024-02-06 01:04:50 --> Language Class Initialized
INFO - 2024-02-06 01:04:50 --> Loader Class Initialized
INFO - 2024-02-06 01:04:50 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:50 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:50 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:50 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:50 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:50 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:50 --> Controller Class Initialized
INFO - 2024-02-06 01:04:50 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:50 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:50 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-06 01:04:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:50 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:50 --> Total execution time: 0.0670
INFO - 2024-02-06 01:04:53 --> Config Class Initialized
INFO - 2024-02-06 01:04:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:53 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:53 --> URI Class Initialized
INFO - 2024-02-06 01:04:53 --> Router Class Initialized
INFO - 2024-02-06 01:04:53 --> Output Class Initialized
INFO - 2024-02-06 01:04:53 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:53 --> Input Class Initialized
INFO - 2024-02-06 01:04:53 --> Language Class Initialized
INFO - 2024-02-06 01:04:53 --> Loader Class Initialized
INFO - 2024-02-06 01:04:53 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:53 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:53 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:53 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:53 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:53 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:53 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:53 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:53 --> Controller Class Initialized
INFO - 2024-02-06 01:04:53 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-06 01:04:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:53 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:53 --> Total execution time: 0.0748
INFO - 2024-02-06 01:04:57 --> Config Class Initialized
INFO - 2024-02-06 01:04:57 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:57 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:57 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:57 --> URI Class Initialized
INFO - 2024-02-06 01:04:57 --> Router Class Initialized
INFO - 2024-02-06 01:04:57 --> Output Class Initialized
INFO - 2024-02-06 01:04:57 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:57 --> Input Class Initialized
INFO - 2024-02-06 01:04:57 --> Language Class Initialized
INFO - 2024-02-06 01:04:57 --> Loader Class Initialized
INFO - 2024-02-06 01:04:57 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:57 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:57 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:57 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:57 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:57 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:57 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:57 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:57 --> Controller Class Initialized
INFO - 2024-02-06 01:04:57 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:57 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-06 01:04:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:57 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:57 --> Total execution time: 0.0537
INFO - 2024-02-06 01:04:58 --> Config Class Initialized
INFO - 2024-02-06 01:04:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:04:58 --> Utf8 Class Initialized
INFO - 2024-02-06 01:04:58 --> URI Class Initialized
INFO - 2024-02-06 01:04:58 --> Router Class Initialized
INFO - 2024-02-06 01:04:58 --> Output Class Initialized
INFO - 2024-02-06 01:04:58 --> Security Class Initialized
DEBUG - 2024-02-06 01:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:04:58 --> Input Class Initialized
INFO - 2024-02-06 01:04:58 --> Language Class Initialized
INFO - 2024-02-06 01:04:58 --> Loader Class Initialized
INFO - 2024-02-06 01:04:58 --> Helper loaded: url_helper
INFO - 2024-02-06 01:04:58 --> Helper loaded: file_helper
INFO - 2024-02-06 01:04:58 --> Helper loaded: security_helper
INFO - 2024-02-06 01:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:04:58 --> Database Driver Class Initialized
INFO - 2024-02-06 01:04:58 --> Email Class Initialized
DEBUG - 2024-02-06 01:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:04:58 --> Helper loaded: form_helper
INFO - 2024-02-06 01:04:58 --> Form Validation Class Initialized
INFO - 2024-02-06 01:04:58 --> Controller Class Initialized
INFO - 2024-02-06 01:04:58 --> Model "User_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:04:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:04:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:04:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:04:58 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:04:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:04:58 --> Final output sent to browser
DEBUG - 2024-02-06 01:04:58 --> Total execution time: 0.0795
INFO - 2024-02-06 01:05:00 --> Config Class Initialized
INFO - 2024-02-06 01:05:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:05:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:05:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:05:00 --> URI Class Initialized
INFO - 2024-02-06 01:05:00 --> Router Class Initialized
INFO - 2024-02-06 01:05:00 --> Output Class Initialized
INFO - 2024-02-06 01:05:00 --> Security Class Initialized
DEBUG - 2024-02-06 01:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:05:00 --> Input Class Initialized
INFO - 2024-02-06 01:05:00 --> Language Class Initialized
INFO - 2024-02-06 01:05:00 --> Loader Class Initialized
INFO - 2024-02-06 01:05:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:05:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:05:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:05:00 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:05:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:05:00 --> Email Class Initialized
DEBUG - 2024-02-06 01:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:05:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:05:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:05:00 --> Controller Class Initialized
INFO - 2024-02-06 01:05:00 --> Model "User_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:05:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:05:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:05:00 --> Final output sent to browser
DEBUG - 2024-02-06 01:05:00 --> Total execution time: 0.1285
INFO - 2024-02-06 01:06:02 --> Config Class Initialized
INFO - 2024-02-06 01:06:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:06:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:06:02 --> Utf8 Class Initialized
INFO - 2024-02-06 01:06:02 --> URI Class Initialized
INFO - 2024-02-06 01:06:02 --> Router Class Initialized
INFO - 2024-02-06 01:06:02 --> Output Class Initialized
INFO - 2024-02-06 01:06:02 --> Security Class Initialized
DEBUG - 2024-02-06 01:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:06:02 --> Input Class Initialized
INFO - 2024-02-06 01:06:02 --> Language Class Initialized
INFO - 2024-02-06 01:06:02 --> Loader Class Initialized
INFO - 2024-02-06 01:06:02 --> Helper loaded: url_helper
INFO - 2024-02-06 01:06:02 --> Helper loaded: file_helper
INFO - 2024-02-06 01:06:02 --> Helper loaded: security_helper
INFO - 2024-02-06 01:06:02 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:06:02 --> Database Driver Class Initialized
INFO - 2024-02-06 01:06:02 --> Email Class Initialized
DEBUG - 2024-02-06 01:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:06:02 --> Helper loaded: form_helper
INFO - 2024-02-06 01:06:02 --> Form Validation Class Initialized
INFO - 2024-02-06 01:06:02 --> Controller Class Initialized
INFO - 2024-02-06 01:06:02 --> Model "User_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:06:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:06:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:06:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:06:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:06:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:06:02 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:06:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:06:02 --> Final output sent to browser
DEBUG - 2024-02-06 01:06:02 --> Total execution time: 0.0659
INFO - 2024-02-06 01:06:03 --> Config Class Initialized
INFO - 2024-02-06 01:06:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:06:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:06:03 --> Utf8 Class Initialized
INFO - 2024-02-06 01:06:03 --> URI Class Initialized
INFO - 2024-02-06 01:06:03 --> Router Class Initialized
INFO - 2024-02-06 01:06:03 --> Output Class Initialized
INFO - 2024-02-06 01:06:03 --> Security Class Initialized
DEBUG - 2024-02-06 01:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:06:03 --> Input Class Initialized
INFO - 2024-02-06 01:06:03 --> Language Class Initialized
INFO - 2024-02-06 01:06:03 --> Loader Class Initialized
INFO - 2024-02-06 01:06:03 --> Helper loaded: url_helper
INFO - 2024-02-06 01:06:03 --> Helper loaded: file_helper
INFO - 2024-02-06 01:06:03 --> Helper loaded: security_helper
INFO - 2024-02-06 01:06:03 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:06:03 --> Database Driver Class Initialized
INFO - 2024-02-06 01:06:03 --> Email Class Initialized
DEBUG - 2024-02-06 01:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:06:03 --> Helper loaded: form_helper
INFO - 2024-02-06 01:06:03 --> Form Validation Class Initialized
INFO - 2024-02-06 01:06:03 --> Controller Class Initialized
INFO - 2024-02-06 01:06:03 --> Model "User_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:06:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:06:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:06:03 --> Final output sent to browser
DEBUG - 2024-02-06 01:06:03 --> Total execution time: 0.1410
INFO - 2024-02-06 01:06:24 --> Config Class Initialized
INFO - 2024-02-06 01:06:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:06:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:06:24 --> Utf8 Class Initialized
INFO - 2024-02-06 01:06:24 --> URI Class Initialized
INFO - 2024-02-06 01:06:24 --> Router Class Initialized
INFO - 2024-02-06 01:06:24 --> Output Class Initialized
INFO - 2024-02-06 01:06:24 --> Security Class Initialized
DEBUG - 2024-02-06 01:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:06:24 --> Input Class Initialized
INFO - 2024-02-06 01:06:24 --> Language Class Initialized
INFO - 2024-02-06 01:06:24 --> Loader Class Initialized
INFO - 2024-02-06 01:06:24 --> Helper loaded: url_helper
INFO - 2024-02-06 01:06:24 --> Helper loaded: file_helper
INFO - 2024-02-06 01:06:24 --> Helper loaded: security_helper
INFO - 2024-02-06 01:06:24 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:06:24 --> Database Driver Class Initialized
INFO - 2024-02-06 01:06:24 --> Email Class Initialized
DEBUG - 2024-02-06 01:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:06:24 --> Helper loaded: form_helper
INFO - 2024-02-06 01:06:24 --> Form Validation Class Initialized
INFO - 2024-02-06 01:06:24 --> Controller Class Initialized
INFO - 2024-02-06 01:06:24 --> Model "User_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:06:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:06:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:06:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:06:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:06:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:06:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:06:24 --> Final output sent to browser
DEBUG - 2024-02-06 01:06:24 --> Total execution time: 0.0805
INFO - 2024-02-06 01:06:25 --> Config Class Initialized
INFO - 2024-02-06 01:06:25 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:06:25 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:06:25 --> Utf8 Class Initialized
INFO - 2024-02-06 01:06:25 --> URI Class Initialized
INFO - 2024-02-06 01:06:25 --> Router Class Initialized
INFO - 2024-02-06 01:06:25 --> Output Class Initialized
INFO - 2024-02-06 01:06:25 --> Security Class Initialized
DEBUG - 2024-02-06 01:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:06:25 --> Input Class Initialized
INFO - 2024-02-06 01:06:25 --> Language Class Initialized
INFO - 2024-02-06 01:06:25 --> Loader Class Initialized
INFO - 2024-02-06 01:06:25 --> Helper loaded: url_helper
INFO - 2024-02-06 01:06:25 --> Helper loaded: file_helper
INFO - 2024-02-06 01:06:25 --> Helper loaded: security_helper
INFO - 2024-02-06 01:06:25 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:06:25 --> Database Driver Class Initialized
INFO - 2024-02-06 01:06:25 --> Email Class Initialized
DEBUG - 2024-02-06 01:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:06:25 --> Helper loaded: form_helper
INFO - 2024-02-06 01:06:25 --> Form Validation Class Initialized
INFO - 2024-02-06 01:06:25 --> Controller Class Initialized
INFO - 2024-02-06 01:06:25 --> Model "User_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:06:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:06:25 --> Final output sent to browser
DEBUG - 2024-02-06 01:06:25 --> Total execution time: 0.1298
INFO - 2024-02-06 01:07:55 --> Config Class Initialized
INFO - 2024-02-06 01:07:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:07:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:07:55 --> Utf8 Class Initialized
INFO - 2024-02-06 01:07:55 --> URI Class Initialized
INFO - 2024-02-06 01:07:55 --> Router Class Initialized
INFO - 2024-02-06 01:07:55 --> Output Class Initialized
INFO - 2024-02-06 01:07:55 --> Security Class Initialized
DEBUG - 2024-02-06 01:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:07:55 --> Input Class Initialized
INFO - 2024-02-06 01:07:55 --> Language Class Initialized
INFO - 2024-02-06 01:07:55 --> Loader Class Initialized
INFO - 2024-02-06 01:07:55 --> Helper loaded: url_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: file_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: security_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:07:55 --> Database Driver Class Initialized
INFO - 2024-02-06 01:07:55 --> Email Class Initialized
DEBUG - 2024-02-06 01:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:07:55 --> Helper loaded: form_helper
INFO - 2024-02-06 01:07:55 --> Form Validation Class Initialized
INFO - 2024-02-06 01:07:55 --> Controller Class Initialized
INFO - 2024-02-06 01:07:55 --> Model "User_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:07:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:07:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:07:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:07:55 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:07:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:07:55 --> Final output sent to browser
DEBUG - 2024-02-06 01:07:55 --> Total execution time: 0.0622
INFO - 2024-02-06 01:07:55 --> Config Class Initialized
INFO - 2024-02-06 01:07:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:07:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:07:55 --> Utf8 Class Initialized
INFO - 2024-02-06 01:07:55 --> URI Class Initialized
INFO - 2024-02-06 01:07:55 --> Router Class Initialized
INFO - 2024-02-06 01:07:55 --> Output Class Initialized
INFO - 2024-02-06 01:07:55 --> Security Class Initialized
DEBUG - 2024-02-06 01:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:07:55 --> Input Class Initialized
INFO - 2024-02-06 01:07:55 --> Language Class Initialized
INFO - 2024-02-06 01:07:55 --> Loader Class Initialized
INFO - 2024-02-06 01:07:55 --> Helper loaded: url_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: file_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: security_helper
INFO - 2024-02-06 01:07:55 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:07:55 --> Database Driver Class Initialized
INFO - 2024-02-06 01:07:55 --> Email Class Initialized
DEBUG - 2024-02-06 01:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:07:55 --> Helper loaded: form_helper
INFO - 2024-02-06 01:07:55 --> Form Validation Class Initialized
INFO - 2024-02-06 01:07:55 --> Controller Class Initialized
INFO - 2024-02-06 01:07:55 --> Model "User_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:07:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:07:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:07:56 --> Final output sent to browser
DEBUG - 2024-02-06 01:07:56 --> Total execution time: 0.1162
INFO - 2024-02-06 01:18:23 --> Config Class Initialized
INFO - 2024-02-06 01:18:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:18:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:18:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:18:23 --> URI Class Initialized
INFO - 2024-02-06 01:18:23 --> Router Class Initialized
INFO - 2024-02-06 01:18:23 --> Output Class Initialized
INFO - 2024-02-06 01:18:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:18:23 --> Input Class Initialized
INFO - 2024-02-06 01:18:23 --> Language Class Initialized
ERROR - 2024-02-06 01:18:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\controllers\Report.php 259
INFO - 2024-02-06 01:18:34 --> Config Class Initialized
INFO - 2024-02-06 01:18:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:18:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:18:34 --> Utf8 Class Initialized
INFO - 2024-02-06 01:18:34 --> URI Class Initialized
INFO - 2024-02-06 01:18:34 --> Router Class Initialized
INFO - 2024-02-06 01:18:34 --> Output Class Initialized
INFO - 2024-02-06 01:18:34 --> Security Class Initialized
DEBUG - 2024-02-06 01:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:18:34 --> Input Class Initialized
INFO - 2024-02-06 01:18:34 --> Language Class Initialized
INFO - 2024-02-06 01:18:34 --> Loader Class Initialized
INFO - 2024-02-06 01:18:34 --> Helper loaded: url_helper
INFO - 2024-02-06 01:18:34 --> Helper loaded: file_helper
INFO - 2024-02-06 01:18:34 --> Helper loaded: security_helper
INFO - 2024-02-06 01:18:34 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:18:34 --> Database Driver Class Initialized
INFO - 2024-02-06 01:18:34 --> Email Class Initialized
DEBUG - 2024-02-06 01:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:18:34 --> Helper loaded: form_helper
INFO - 2024-02-06 01:18:34 --> Form Validation Class Initialized
INFO - 2024-02-06 01:18:34 --> Controller Class Initialized
INFO - 2024-02-06 01:18:34 --> Model "User_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:18:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:18:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:18:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:18:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:18:34 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:18:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:18:34 --> Final output sent to browser
DEBUG - 2024-02-06 01:18:34 --> Total execution time: 0.0780
INFO - 2024-02-06 01:18:35 --> Config Class Initialized
INFO - 2024-02-06 01:18:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:18:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:18:35 --> Utf8 Class Initialized
INFO - 2024-02-06 01:18:35 --> URI Class Initialized
INFO - 2024-02-06 01:18:35 --> Router Class Initialized
INFO - 2024-02-06 01:18:35 --> Output Class Initialized
INFO - 2024-02-06 01:18:35 --> Security Class Initialized
DEBUG - 2024-02-06 01:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:18:35 --> Input Class Initialized
INFO - 2024-02-06 01:18:35 --> Language Class Initialized
INFO - 2024-02-06 01:18:35 --> Loader Class Initialized
INFO - 2024-02-06 01:18:35 --> Helper loaded: url_helper
INFO - 2024-02-06 01:18:35 --> Helper loaded: file_helper
INFO - 2024-02-06 01:18:35 --> Helper loaded: security_helper
INFO - 2024-02-06 01:18:35 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:18:35 --> Database Driver Class Initialized
INFO - 2024-02-06 01:18:35 --> Email Class Initialized
DEBUG - 2024-02-06 01:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:18:35 --> Helper loaded: form_helper
INFO - 2024-02-06 01:18:35 --> Form Validation Class Initialized
INFO - 2024-02-06 01:18:35 --> Controller Class Initialized
INFO - 2024-02-06 01:18:35 --> Model "User_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:18:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:18:35 --> Final output sent to browser
DEBUG - 2024-02-06 01:18:35 --> Total execution time: 0.1093
INFO - 2024-02-06 01:19:24 --> Config Class Initialized
INFO - 2024-02-06 01:19:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:19:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:19:24 --> Utf8 Class Initialized
INFO - 2024-02-06 01:19:24 --> URI Class Initialized
INFO - 2024-02-06 01:19:24 --> Router Class Initialized
INFO - 2024-02-06 01:19:24 --> Output Class Initialized
INFO - 2024-02-06 01:19:24 --> Security Class Initialized
DEBUG - 2024-02-06 01:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:19:24 --> Input Class Initialized
INFO - 2024-02-06 01:19:24 --> Language Class Initialized
INFO - 2024-02-06 01:19:24 --> Loader Class Initialized
INFO - 2024-02-06 01:19:24 --> Helper loaded: url_helper
INFO - 2024-02-06 01:19:24 --> Helper loaded: file_helper
INFO - 2024-02-06 01:19:24 --> Helper loaded: security_helper
INFO - 2024-02-06 01:19:24 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:19:24 --> Database Driver Class Initialized
INFO - 2024-02-06 01:19:24 --> Email Class Initialized
DEBUG - 2024-02-06 01:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:19:24 --> Helper loaded: form_helper
INFO - 2024-02-06 01:19:24 --> Form Validation Class Initialized
INFO - 2024-02-06 01:19:24 --> Controller Class Initialized
INFO - 2024-02-06 01:19:24 --> Model "User_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:19:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:19:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:19:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:19:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:19:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:19:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:19:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:19:24 --> Final output sent to browser
DEBUG - 2024-02-06 01:19:24 --> Total execution time: 0.0604
INFO - 2024-02-06 01:28:56 --> Config Class Initialized
INFO - 2024-02-06 01:28:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:28:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:28:56 --> Utf8 Class Initialized
INFO - 2024-02-06 01:28:56 --> URI Class Initialized
INFO - 2024-02-06 01:28:56 --> Router Class Initialized
INFO - 2024-02-06 01:28:56 --> Output Class Initialized
INFO - 2024-02-06 01:28:56 --> Security Class Initialized
DEBUG - 2024-02-06 01:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:28:56 --> Input Class Initialized
INFO - 2024-02-06 01:28:56 --> Language Class Initialized
INFO - 2024-02-06 01:28:56 --> Loader Class Initialized
INFO - 2024-02-06 01:28:56 --> Helper loaded: url_helper
INFO - 2024-02-06 01:28:56 --> Helper loaded: file_helper
INFO - 2024-02-06 01:28:56 --> Helper loaded: security_helper
INFO - 2024-02-06 01:28:56 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:28:56 --> Database Driver Class Initialized
INFO - 2024-02-06 01:28:56 --> Email Class Initialized
DEBUG - 2024-02-06 01:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:28:56 --> Helper loaded: form_helper
INFO - 2024-02-06 01:28:56 --> Form Validation Class Initialized
INFO - 2024-02-06 01:28:56 --> Controller Class Initialized
INFO - 2024-02-06 01:28:56 --> Model "User_model" initialized
INFO - 2024-02-06 01:28:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:28:56 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:28:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:28:57 --> Final output sent to browser
DEBUG - 2024-02-06 01:28:57 --> Total execution time: 0.9224
INFO - 2024-02-06 01:28:57 --> Config Class Initialized
INFO - 2024-02-06 01:28:57 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:28:57 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:28:57 --> Utf8 Class Initialized
INFO - 2024-02-06 01:28:57 --> URI Class Initialized
INFO - 2024-02-06 01:28:57 --> Router Class Initialized
INFO - 2024-02-06 01:28:57 --> Output Class Initialized
INFO - 2024-02-06 01:28:57 --> Security Class Initialized
DEBUG - 2024-02-06 01:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:28:57 --> Input Class Initialized
INFO - 2024-02-06 01:28:57 --> Language Class Initialized
INFO - 2024-02-06 01:28:57 --> Loader Class Initialized
INFO - 2024-02-06 01:28:57 --> Helper loaded: url_helper
INFO - 2024-02-06 01:28:57 --> Helper loaded: file_helper
INFO - 2024-02-06 01:28:57 --> Helper loaded: security_helper
INFO - 2024-02-06 01:28:57 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:28:57 --> Database Driver Class Initialized
INFO - 2024-02-06 01:28:57 --> Email Class Initialized
DEBUG - 2024-02-06 01:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:28:57 --> Helper loaded: form_helper
INFO - 2024-02-06 01:28:57 --> Form Validation Class Initialized
INFO - 2024-02-06 01:28:57 --> Controller Class Initialized
INFO - 2024-02-06 01:28:57 --> Model "User_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:28:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:28:59 --> Final output sent to browser
DEBUG - 2024-02-06 01:28:59 --> Total execution time: 1.3048
INFO - 2024-02-06 01:29:37 --> Config Class Initialized
INFO - 2024-02-06 01:29:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:29:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:29:37 --> Utf8 Class Initialized
INFO - 2024-02-06 01:29:37 --> URI Class Initialized
INFO - 2024-02-06 01:29:37 --> Router Class Initialized
INFO - 2024-02-06 01:29:37 --> Output Class Initialized
INFO - 2024-02-06 01:29:37 --> Security Class Initialized
DEBUG - 2024-02-06 01:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:29:37 --> Input Class Initialized
INFO - 2024-02-06 01:29:37 --> Language Class Initialized
INFO - 2024-02-06 01:29:37 --> Loader Class Initialized
INFO - 2024-02-06 01:29:37 --> Helper loaded: url_helper
INFO - 2024-02-06 01:29:37 --> Helper loaded: file_helper
INFO - 2024-02-06 01:29:37 --> Helper loaded: security_helper
INFO - 2024-02-06 01:29:37 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:29:37 --> Database Driver Class Initialized
INFO - 2024-02-06 01:29:37 --> Email Class Initialized
DEBUG - 2024-02-06 01:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:29:37 --> Helper loaded: form_helper
INFO - 2024-02-06 01:29:37 --> Form Validation Class Initialized
INFO - 2024-02-06 01:29:37 --> Controller Class Initialized
INFO - 2024-02-06 01:29:37 --> Model "User_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:29:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:29:37 --> Final output sent to browser
DEBUG - 2024-02-06 01:29:37 --> Total execution time: 0.1382
INFO - 2024-02-06 01:29:57 --> Config Class Initialized
INFO - 2024-02-06 01:29:57 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:29:57 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:29:57 --> Utf8 Class Initialized
INFO - 2024-02-06 01:29:57 --> URI Class Initialized
INFO - 2024-02-06 01:29:57 --> Router Class Initialized
INFO - 2024-02-06 01:29:57 --> Output Class Initialized
INFO - 2024-02-06 01:29:57 --> Security Class Initialized
DEBUG - 2024-02-06 01:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:29:57 --> Input Class Initialized
INFO - 2024-02-06 01:29:57 --> Language Class Initialized
INFO - 2024-02-06 01:29:57 --> Loader Class Initialized
INFO - 2024-02-06 01:29:57 --> Helper loaded: url_helper
INFO - 2024-02-06 01:29:57 --> Helper loaded: file_helper
INFO - 2024-02-06 01:29:57 --> Helper loaded: security_helper
INFO - 2024-02-06 01:29:57 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:29:57 --> Database Driver Class Initialized
INFO - 2024-02-06 01:29:57 --> Email Class Initialized
DEBUG - 2024-02-06 01:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:29:57 --> Helper loaded: form_helper
INFO - 2024-02-06 01:29:57 --> Form Validation Class Initialized
INFO - 2024-02-06 01:29:57 --> Controller Class Initialized
INFO - 2024-02-06 01:29:57 --> Model "User_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:29:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:29:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:29:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-06 01:29:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-06 01:29:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-06 01:29:57 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-06 01:29:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-06 01:29:57 --> Final output sent to browser
DEBUG - 2024-02-06 01:29:57 --> Total execution time: 0.0639
INFO - 2024-02-06 01:29:58 --> Config Class Initialized
INFO - 2024-02-06 01:29:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:29:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:29:58 --> Utf8 Class Initialized
INFO - 2024-02-06 01:29:58 --> URI Class Initialized
INFO - 2024-02-06 01:29:58 --> Router Class Initialized
INFO - 2024-02-06 01:29:58 --> Output Class Initialized
INFO - 2024-02-06 01:29:58 --> Security Class Initialized
DEBUG - 2024-02-06 01:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:29:58 --> Input Class Initialized
INFO - 2024-02-06 01:29:58 --> Language Class Initialized
INFO - 2024-02-06 01:29:58 --> Loader Class Initialized
INFO - 2024-02-06 01:29:58 --> Helper loaded: url_helper
INFO - 2024-02-06 01:29:58 --> Helper loaded: file_helper
INFO - 2024-02-06 01:29:58 --> Helper loaded: security_helper
INFO - 2024-02-06 01:29:58 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:29:58 --> Database Driver Class Initialized
INFO - 2024-02-06 01:29:58 --> Email Class Initialized
DEBUG - 2024-02-06 01:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:29:58 --> Helper loaded: form_helper
INFO - 2024-02-06 01:29:58 --> Form Validation Class Initialized
INFO - 2024-02-06 01:29:58 --> Controller Class Initialized
INFO - 2024-02-06 01:29:58 --> Model "User_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:29:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:29:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:29:58 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\upload/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:30:23 --> Config Class Initialized
INFO - 2024-02-06 01:30:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:30:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:30:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:30:23 --> URI Class Initialized
INFO - 2024-02-06 01:30:23 --> Router Class Initialized
INFO - 2024-02-06 01:30:23 --> Output Class Initialized
INFO - 2024-02-06 01:30:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:30:23 --> Input Class Initialized
INFO - 2024-02-06 01:30:23 --> Language Class Initialized
INFO - 2024-02-06 01:30:23 --> Loader Class Initialized
INFO - 2024-02-06 01:30:23 --> Helper loaded: url_helper
INFO - 2024-02-06 01:30:23 --> Helper loaded: file_helper
INFO - 2024-02-06 01:30:23 --> Helper loaded: security_helper
INFO - 2024-02-06 01:30:23 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:30:23 --> Database Driver Class Initialized
INFO - 2024-02-06 01:30:23 --> Email Class Initialized
DEBUG - 2024-02-06 01:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:30:23 --> Helper loaded: form_helper
INFO - 2024-02-06 01:30:23 --> Form Validation Class Initialized
INFO - 2024-02-06 01:30:23 --> Controller Class Initialized
INFO - 2024-02-06 01:30:23 --> Model "User_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:30:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:30:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:30:23 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\application\upload\settings\logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:31:46 --> Config Class Initialized
INFO - 2024-02-06 01:31:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:31:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:31:46 --> Utf8 Class Initialized
INFO - 2024-02-06 01:31:46 --> URI Class Initialized
INFO - 2024-02-06 01:31:46 --> Router Class Initialized
INFO - 2024-02-06 01:31:46 --> Output Class Initialized
INFO - 2024-02-06 01:31:46 --> Security Class Initialized
DEBUG - 2024-02-06 01:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:31:46 --> Input Class Initialized
INFO - 2024-02-06 01:31:46 --> Language Class Initialized
INFO - 2024-02-06 01:31:46 --> Loader Class Initialized
INFO - 2024-02-06 01:31:46 --> Helper loaded: url_helper
INFO - 2024-02-06 01:31:46 --> Helper loaded: file_helper
INFO - 2024-02-06 01:31:46 --> Helper loaded: security_helper
INFO - 2024-02-06 01:31:46 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:31:46 --> Database Driver Class Initialized
INFO - 2024-02-06 01:31:46 --> Email Class Initialized
DEBUG - 2024-02-06 01:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:31:46 --> Helper loaded: form_helper
INFO - 2024-02-06 01:31:46 --> Form Validation Class Initialized
INFO - 2024-02-06 01:31:46 --> Controller Class Initialized
INFO - 2024-02-06 01:31:46 --> Model "User_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:31:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:31:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:31:46 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\upload\settings\logo_64fa06f9bbd91 not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:31:47 --> Config Class Initialized
INFO - 2024-02-06 01:31:47 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:31:47 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:31:47 --> Utf8 Class Initialized
INFO - 2024-02-06 01:31:47 --> URI Class Initialized
INFO - 2024-02-06 01:31:47 --> Router Class Initialized
INFO - 2024-02-06 01:31:47 --> Output Class Initialized
INFO - 2024-02-06 01:31:47 --> Security Class Initialized
DEBUG - 2024-02-06 01:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:31:47 --> Input Class Initialized
INFO - 2024-02-06 01:31:47 --> Language Class Initialized
INFO - 2024-02-06 01:31:47 --> Loader Class Initialized
INFO - 2024-02-06 01:31:47 --> Helper loaded: url_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: file_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: security_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:31:47 --> Database Driver Class Initialized
INFO - 2024-02-06 01:31:47 --> Email Class Initialized
DEBUG - 2024-02-06 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:31:47 --> Helper loaded: form_helper
INFO - 2024-02-06 01:31:47 --> Form Validation Class Initialized
INFO - 2024-02-06 01:31:47 --> Controller Class Initialized
INFO - 2024-02-06 01:31:47 --> Model "User_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:31:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:31:47 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\upload\settings\logo_64fa06f9bbd91 not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:31:47 --> Config Class Initialized
INFO - 2024-02-06 01:31:47 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:31:47 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:31:47 --> Utf8 Class Initialized
INFO - 2024-02-06 01:31:47 --> URI Class Initialized
INFO - 2024-02-06 01:31:47 --> Router Class Initialized
INFO - 2024-02-06 01:31:47 --> Output Class Initialized
INFO - 2024-02-06 01:31:47 --> Security Class Initialized
DEBUG - 2024-02-06 01:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:31:47 --> Input Class Initialized
INFO - 2024-02-06 01:31:47 --> Language Class Initialized
INFO - 2024-02-06 01:31:47 --> Loader Class Initialized
INFO - 2024-02-06 01:31:47 --> Helper loaded: url_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: file_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: security_helper
INFO - 2024-02-06 01:31:47 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:31:47 --> Database Driver Class Initialized
INFO - 2024-02-06 01:31:47 --> Email Class Initialized
DEBUG - 2024-02-06 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:31:47 --> Helper loaded: form_helper
INFO - 2024-02-06 01:31:47 --> Form Validation Class Initialized
INFO - 2024-02-06 01:31:47 --> Controller Class Initialized
INFO - 2024-02-06 01:31:47 --> Model "User_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:31:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:31:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:31:48 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\upload\settings\logo_64fa06f9bbd91 not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:31:48 --> Config Class Initialized
INFO - 2024-02-06 01:31:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:31:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:31:48 --> Utf8 Class Initialized
INFO - 2024-02-06 01:31:48 --> URI Class Initialized
INFO - 2024-02-06 01:31:48 --> Router Class Initialized
INFO - 2024-02-06 01:31:48 --> Output Class Initialized
INFO - 2024-02-06 01:31:48 --> Security Class Initialized
DEBUG - 2024-02-06 01:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:31:48 --> Input Class Initialized
INFO - 2024-02-06 01:31:48 --> Language Class Initialized
INFO - 2024-02-06 01:31:48 --> Loader Class Initialized
INFO - 2024-02-06 01:31:48 --> Helper loaded: url_helper
INFO - 2024-02-06 01:31:48 --> Helper loaded: file_helper
INFO - 2024-02-06 01:31:48 --> Helper loaded: security_helper
INFO - 2024-02-06 01:31:48 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:31:48 --> Database Driver Class Initialized
INFO - 2024-02-06 01:31:48 --> Email Class Initialized
DEBUG - 2024-02-06 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:31:48 --> Helper loaded: form_helper
INFO - 2024-02-06 01:31:48 --> Form Validation Class Initialized
INFO - 2024-02-06 01:31:48 --> Controller Class Initialized
INFO - 2024-02-06 01:31:48 --> Model "User_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:31:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:31:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:31:48 --> Severity: error --> Exception: File C:\xampp\htdocs\simba\upload\settings\logo_64fa06f9bbd91 not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:32:25 --> Config Class Initialized
INFO - 2024-02-06 01:32:25 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:32:25 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:32:25 --> Utf8 Class Initialized
INFO - 2024-02-06 01:32:25 --> URI Class Initialized
INFO - 2024-02-06 01:32:25 --> Router Class Initialized
INFO - 2024-02-06 01:32:25 --> Output Class Initialized
INFO - 2024-02-06 01:32:25 --> Security Class Initialized
DEBUG - 2024-02-06 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:32:25 --> Input Class Initialized
INFO - 2024-02-06 01:32:25 --> Language Class Initialized
INFO - 2024-02-06 01:32:25 --> Loader Class Initialized
INFO - 2024-02-06 01:32:25 --> Helper loaded: url_helper
INFO - 2024-02-06 01:32:25 --> Helper loaded: file_helper
INFO - 2024-02-06 01:32:25 --> Helper loaded: security_helper
INFO - 2024-02-06 01:32:25 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:32:25 --> Database Driver Class Initialized
INFO - 2024-02-06 01:32:25 --> Email Class Initialized
DEBUG - 2024-02-06 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:32:25 --> Helper loaded: form_helper
INFO - 2024-02-06 01:32:25 --> Form Validation Class Initialized
INFO - 2024-02-06 01:32:25 --> Controller Class Initialized
INFO - 2024-02-06 01:32:25 --> Model "User_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:32:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:32:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:32:25 --> Severity: error --> Exception: File http://localhost/simba/upload/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:32:26 --> Config Class Initialized
INFO - 2024-02-06 01:32:26 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:32:26 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:32:26 --> Utf8 Class Initialized
INFO - 2024-02-06 01:32:26 --> URI Class Initialized
INFO - 2024-02-06 01:32:26 --> Router Class Initialized
INFO - 2024-02-06 01:32:26 --> Output Class Initialized
INFO - 2024-02-06 01:32:26 --> Security Class Initialized
DEBUG - 2024-02-06 01:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:32:26 --> Input Class Initialized
INFO - 2024-02-06 01:32:26 --> Language Class Initialized
INFO - 2024-02-06 01:32:26 --> Loader Class Initialized
INFO - 2024-02-06 01:32:26 --> Helper loaded: url_helper
INFO - 2024-02-06 01:32:26 --> Helper loaded: file_helper
INFO - 2024-02-06 01:32:26 --> Helper loaded: security_helper
INFO - 2024-02-06 01:32:26 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:32:26 --> Database Driver Class Initialized
INFO - 2024-02-06 01:32:26 --> Email Class Initialized
DEBUG - 2024-02-06 01:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:32:26 --> Helper loaded: form_helper
INFO - 2024-02-06 01:32:26 --> Form Validation Class Initialized
INFO - 2024-02-06 01:32:26 --> Controller Class Initialized
INFO - 2024-02-06 01:32:26 --> Model "User_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:32:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:32:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:32:26 --> Severity: error --> Exception: File http://localhost/simba/upload/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:32:33 --> Config Class Initialized
INFO - 2024-02-06 01:32:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:32:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:32:33 --> Utf8 Class Initialized
INFO - 2024-02-06 01:32:33 --> URI Class Initialized
INFO - 2024-02-06 01:32:33 --> Router Class Initialized
INFO - 2024-02-06 01:32:33 --> Output Class Initialized
INFO - 2024-02-06 01:32:33 --> Security Class Initialized
DEBUG - 2024-02-06 01:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:32:33 --> Input Class Initialized
INFO - 2024-02-06 01:32:33 --> Language Class Initialized
INFO - 2024-02-06 01:32:33 --> Loader Class Initialized
INFO - 2024-02-06 01:32:33 --> Helper loaded: url_helper
INFO - 2024-02-06 01:32:33 --> Helper loaded: file_helper
INFO - 2024-02-06 01:32:33 --> Helper loaded: security_helper
INFO - 2024-02-06 01:32:33 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:32:33 --> Database Driver Class Initialized
INFO - 2024-02-06 01:32:33 --> Email Class Initialized
DEBUG - 2024-02-06 01:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:32:33 --> Helper loaded: form_helper
INFO - 2024-02-06 01:32:33 --> Form Validation Class Initialized
INFO - 2024-02-06 01:32:33 --> Controller Class Initialized
INFO - 2024-02-06 01:32:33 --> Model "User_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:32:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:32:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:32:33 --> Severity: error --> Exception: File http://localhost/simba/upload/settings/logo_64fa06f9bbd91.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-06 01:33:00 --> Config Class Initialized
INFO - 2024-02-06 01:33:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:33:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:33:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:33:00 --> URI Class Initialized
INFO - 2024-02-06 01:33:00 --> Router Class Initialized
INFO - 2024-02-06 01:33:00 --> Output Class Initialized
INFO - 2024-02-06 01:33:00 --> Security Class Initialized
DEBUG - 2024-02-06 01:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:33:00 --> Input Class Initialized
INFO - 2024-02-06 01:33:00 --> Language Class Initialized
INFO - 2024-02-06 01:33:00 --> Loader Class Initialized
INFO - 2024-02-06 01:33:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:33:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:33:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:33:00 --> Helper loaded: wpu_helper
INFO - 2024-02-06 01:33:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:33:00 --> Email Class Initialized
DEBUG - 2024-02-06 01:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-06 01:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:33:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:33:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:33:00 --> Controller Class Initialized
INFO - 2024-02-06 01:33:00 --> Model "User_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Faktur_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Supplier_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-06 01:33:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-06 01:33:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:33:00 --> Final output sent to browser
DEBUG - 2024-02-06 01:33:00 --> Total execution time: 0.1609
