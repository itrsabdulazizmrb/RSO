<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-08 00:12:46 --> Config Class Initialized
INFO - 2024-09-08 00:12:46 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:12:46 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:12:46 --> Utf8 Class Initialized
INFO - 2024-09-08 00:12:46 --> URI Class Initialized
DEBUG - 2024-09-08 00:12:46 --> No URI present. Default controller set.
INFO - 2024-09-08 00:12:46 --> Router Class Initialized
INFO - 2024-09-08 00:12:46 --> Output Class Initialized
INFO - 2024-09-08 00:12:46 --> Security Class Initialized
DEBUG - 2024-09-08 00:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:12:46 --> Input Class Initialized
INFO - 2024-09-08 00:12:46 --> Language Class Initialized
INFO - 2024-09-08 00:12:46 --> Loader Class Initialized
INFO - 2024-09-08 00:12:46 --> Helper loaded: url_helper
INFO - 2024-09-08 00:12:46 --> Helper loaded: file_helper
INFO - 2024-09-08 00:12:46 --> Helper loaded: security_helper
INFO - 2024-09-08 00:12:46 --> Helper loaded: wpu_helper
INFO - 2024-09-08 00:12:46 --> Database Driver Class Initialized
INFO - 2024-09-08 00:12:46 --> Email Class Initialized
DEBUG - 2024-09-08 00:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 00:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:12:46 --> Helper loaded: form_helper
INFO - 2024-09-08 00:12:46 --> Form Validation Class Initialized
INFO - 2024-09-08 00:12:46 --> Controller Class Initialized
DEBUG - 2024-09-08 00:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 00:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 00:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 00:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 00:12:46 --> Final output sent to browser
DEBUG - 2024-09-08 00:12:46 --> Total execution time: 0.2151
INFO - 2024-09-08 00:23:42 --> Config Class Initialized
INFO - 2024-09-08 00:23:42 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:23:42 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:23:42 --> Utf8 Class Initialized
INFO - 2024-09-08 00:23:42 --> URI Class Initialized
INFO - 2024-09-08 00:23:42 --> Router Class Initialized
INFO - 2024-09-08 00:23:42 --> Output Class Initialized
INFO - 2024-09-08 00:23:42 --> Security Class Initialized
DEBUG - 2024-09-08 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:23:42 --> Input Class Initialized
INFO - 2024-09-08 00:23:42 --> Language Class Initialized
INFO - 2024-09-08 00:23:42 --> Loader Class Initialized
INFO - 2024-09-08 00:23:42 --> Helper loaded: url_helper
INFO - 2024-09-08 00:23:42 --> Helper loaded: file_helper
INFO - 2024-09-08 00:23:42 --> Helper loaded: security_helper
INFO - 2024-09-08 00:23:42 --> Helper loaded: wpu_helper
INFO - 2024-09-08 00:23:42 --> Database Driver Class Initialized
INFO - 2024-09-08 00:23:43 --> Email Class Initialized
DEBUG - 2024-09-08 00:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 00:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:23:43 --> Helper loaded: form_helper
INFO - 2024-09-08 00:23:43 --> Form Validation Class Initialized
INFO - 2024-09-08 00:23:43 --> Controller Class Initialized
INFO - 2024-09-08 00:23:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 00:23:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 00:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-08 00:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-08 00:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-08 00:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-08 00:23:43 --> Final output sent to browser
DEBUG - 2024-09-08 00:23:43 --> Total execution time: 0.6368
INFO - 2024-09-08 00:42:29 --> Config Class Initialized
INFO - 2024-09-08 00:42:29 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:42:29 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:42:29 --> Utf8 Class Initialized
INFO - 2024-09-08 00:42:29 --> URI Class Initialized
DEBUG - 2024-09-08 00:42:29 --> No URI present. Default controller set.
INFO - 2024-09-08 00:42:29 --> Router Class Initialized
INFO - 2024-09-08 00:42:29 --> Output Class Initialized
INFO - 2024-09-08 00:42:29 --> Security Class Initialized
DEBUG - 2024-09-08 00:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:42:29 --> Input Class Initialized
INFO - 2024-09-08 00:42:29 --> Language Class Initialized
INFO - 2024-09-08 00:42:29 --> Loader Class Initialized
INFO - 2024-09-08 00:42:29 --> Helper loaded: url_helper
INFO - 2024-09-08 00:42:29 --> Helper loaded: file_helper
INFO - 2024-09-08 00:42:29 --> Helper loaded: security_helper
INFO - 2024-09-08 00:42:29 --> Helper loaded: wpu_helper
INFO - 2024-09-08 00:42:29 --> Database Driver Class Initialized
INFO - 2024-09-08 00:42:29 --> Email Class Initialized
DEBUG - 2024-09-08 00:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 00:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:42:29 --> Helper loaded: form_helper
INFO - 2024-09-08 00:42:29 --> Form Validation Class Initialized
INFO - 2024-09-08 00:42:29 --> Controller Class Initialized
DEBUG - 2024-09-08 00:42:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 00:42:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 00:42:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 00:42:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 00:42:29 --> Final output sent to browser
DEBUG - 2024-09-08 00:42:29 --> Total execution time: 0.2187
INFO - 2024-09-08 01:10:08 --> Config Class Initialized
INFO - 2024-09-08 01:10:08 --> Hooks Class Initialized
DEBUG - 2024-09-08 01:10:08 --> UTF-8 Support Enabled
INFO - 2024-09-08 01:10:08 --> Utf8 Class Initialized
INFO - 2024-09-08 01:10:08 --> URI Class Initialized
DEBUG - 2024-09-08 01:10:08 --> No URI present. Default controller set.
INFO - 2024-09-08 01:10:08 --> Router Class Initialized
INFO - 2024-09-08 01:10:08 --> Output Class Initialized
INFO - 2024-09-08 01:10:08 --> Security Class Initialized
DEBUG - 2024-09-08 01:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 01:10:08 --> Input Class Initialized
INFO - 2024-09-08 01:10:08 --> Language Class Initialized
INFO - 2024-09-08 01:10:08 --> Loader Class Initialized
INFO - 2024-09-08 01:10:08 --> Helper loaded: url_helper
INFO - 2024-09-08 01:10:08 --> Helper loaded: file_helper
INFO - 2024-09-08 01:10:08 --> Helper loaded: security_helper
INFO - 2024-09-08 01:10:08 --> Helper loaded: wpu_helper
INFO - 2024-09-08 01:10:08 --> Database Driver Class Initialized
INFO - 2024-09-08 01:10:08 --> Email Class Initialized
DEBUG - 2024-09-08 01:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 01:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 01:10:08 --> Helper loaded: form_helper
INFO - 2024-09-08 01:10:08 --> Form Validation Class Initialized
INFO - 2024-09-08 01:10:08 --> Controller Class Initialized
DEBUG - 2024-09-08 01:10:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 01:10:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 01:10:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 01:10:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 01:10:08 --> Final output sent to browser
DEBUG - 2024-09-08 01:10:08 --> Total execution time: 0.2226
INFO - 2024-09-08 01:12:45 --> Config Class Initialized
INFO - 2024-09-08 01:12:45 --> Hooks Class Initialized
DEBUG - 2024-09-08 01:12:45 --> UTF-8 Support Enabled
INFO - 2024-09-08 01:12:45 --> Utf8 Class Initialized
INFO - 2024-09-08 01:12:45 --> URI Class Initialized
DEBUG - 2024-09-08 01:12:45 --> No URI present. Default controller set.
INFO - 2024-09-08 01:12:45 --> Router Class Initialized
INFO - 2024-09-08 01:12:45 --> Output Class Initialized
INFO - 2024-09-08 01:12:45 --> Security Class Initialized
DEBUG - 2024-09-08 01:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 01:12:45 --> Input Class Initialized
INFO - 2024-09-08 01:12:45 --> Language Class Initialized
INFO - 2024-09-08 01:12:45 --> Loader Class Initialized
INFO - 2024-09-08 01:12:45 --> Helper loaded: url_helper
INFO - 2024-09-08 01:12:45 --> Helper loaded: file_helper
INFO - 2024-09-08 01:12:45 --> Helper loaded: security_helper
INFO - 2024-09-08 01:12:45 --> Helper loaded: wpu_helper
INFO - 2024-09-08 01:12:45 --> Database Driver Class Initialized
INFO - 2024-09-08 01:12:45 --> Email Class Initialized
DEBUG - 2024-09-08 01:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 01:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 01:12:45 --> Helper loaded: form_helper
INFO - 2024-09-08 01:12:45 --> Form Validation Class Initialized
INFO - 2024-09-08 01:12:45 --> Controller Class Initialized
DEBUG - 2024-09-08 01:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 01:12:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 01:12:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 01:12:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 01:12:45 --> Final output sent to browser
DEBUG - 2024-09-08 01:12:45 --> Total execution time: 0.2268
INFO - 2024-09-08 01:46:03 --> Config Class Initialized
INFO - 2024-09-08 01:46:03 --> Hooks Class Initialized
DEBUG - 2024-09-08 01:46:03 --> UTF-8 Support Enabled
INFO - 2024-09-08 01:46:03 --> Utf8 Class Initialized
INFO - 2024-09-08 01:46:03 --> URI Class Initialized
DEBUG - 2024-09-08 01:46:03 --> No URI present. Default controller set.
INFO - 2024-09-08 01:46:03 --> Router Class Initialized
INFO - 2024-09-08 01:46:03 --> Output Class Initialized
INFO - 2024-09-08 01:46:03 --> Security Class Initialized
DEBUG - 2024-09-08 01:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 01:46:03 --> Input Class Initialized
INFO - 2024-09-08 01:46:03 --> Language Class Initialized
INFO - 2024-09-08 01:46:03 --> Loader Class Initialized
INFO - 2024-09-08 01:46:03 --> Helper loaded: url_helper
INFO - 2024-09-08 01:46:03 --> Helper loaded: file_helper
INFO - 2024-09-08 01:46:03 --> Helper loaded: security_helper
INFO - 2024-09-08 01:46:03 --> Helper loaded: wpu_helper
INFO - 2024-09-08 01:46:03 --> Database Driver Class Initialized
INFO - 2024-09-08 01:46:03 --> Email Class Initialized
DEBUG - 2024-09-08 01:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 01:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 01:46:03 --> Helper loaded: form_helper
INFO - 2024-09-08 01:46:03 --> Form Validation Class Initialized
INFO - 2024-09-08 01:46:03 --> Controller Class Initialized
DEBUG - 2024-09-08 01:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 01:46:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 01:46:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 01:46:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 01:46:03 --> Final output sent to browser
DEBUG - 2024-09-08 01:46:03 --> Total execution time: 0.2461
INFO - 2024-09-08 02:13:21 --> Config Class Initialized
INFO - 2024-09-08 02:13:21 --> Hooks Class Initialized
DEBUG - 2024-09-08 02:13:21 --> UTF-8 Support Enabled
INFO - 2024-09-08 02:13:21 --> Utf8 Class Initialized
INFO - 2024-09-08 02:13:21 --> URI Class Initialized
DEBUG - 2024-09-08 02:13:21 --> No URI present. Default controller set.
INFO - 2024-09-08 02:13:21 --> Router Class Initialized
INFO - 2024-09-08 02:13:21 --> Output Class Initialized
INFO - 2024-09-08 02:13:21 --> Security Class Initialized
DEBUG - 2024-09-08 02:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 02:13:21 --> Input Class Initialized
INFO - 2024-09-08 02:13:21 --> Language Class Initialized
INFO - 2024-09-08 02:13:21 --> Loader Class Initialized
INFO - 2024-09-08 02:13:21 --> Helper loaded: url_helper
INFO - 2024-09-08 02:13:21 --> Helper loaded: file_helper
INFO - 2024-09-08 02:13:21 --> Helper loaded: security_helper
INFO - 2024-09-08 02:13:21 --> Helper loaded: wpu_helper
INFO - 2024-09-08 02:13:21 --> Database Driver Class Initialized
INFO - 2024-09-08 02:13:22 --> Email Class Initialized
DEBUG - 2024-09-08 02:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 02:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 02:13:22 --> Helper loaded: form_helper
INFO - 2024-09-08 02:13:22 --> Form Validation Class Initialized
INFO - 2024-09-08 02:13:22 --> Controller Class Initialized
DEBUG - 2024-09-08 02:13:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 02:13:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 02:13:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 02:13:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 02:13:22 --> Final output sent to browser
DEBUG - 2024-09-08 02:13:22 --> Total execution time: 0.2221
INFO - 2024-09-08 02:20:55 --> Config Class Initialized
INFO - 2024-09-08 02:20:55 --> Hooks Class Initialized
DEBUG - 2024-09-08 02:20:55 --> UTF-8 Support Enabled
INFO - 2024-09-08 02:20:55 --> Utf8 Class Initialized
INFO - 2024-09-08 02:20:55 --> URI Class Initialized
DEBUG - 2024-09-08 02:20:55 --> No URI present. Default controller set.
INFO - 2024-09-08 02:20:55 --> Router Class Initialized
INFO - 2024-09-08 02:20:55 --> Output Class Initialized
INFO - 2024-09-08 02:20:55 --> Security Class Initialized
DEBUG - 2024-09-08 02:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 02:20:55 --> Input Class Initialized
INFO - 2024-09-08 02:20:55 --> Language Class Initialized
INFO - 2024-09-08 02:20:55 --> Loader Class Initialized
INFO - 2024-09-08 02:20:55 --> Helper loaded: url_helper
INFO - 2024-09-08 02:20:55 --> Helper loaded: file_helper
INFO - 2024-09-08 02:20:55 --> Helper loaded: security_helper
INFO - 2024-09-08 02:20:55 --> Helper loaded: wpu_helper
INFO - 2024-09-08 02:20:55 --> Database Driver Class Initialized
INFO - 2024-09-08 02:20:56 --> Email Class Initialized
DEBUG - 2024-09-08 02:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 02:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 02:20:56 --> Helper loaded: form_helper
INFO - 2024-09-08 02:20:56 --> Form Validation Class Initialized
INFO - 2024-09-08 02:20:56 --> Controller Class Initialized
DEBUG - 2024-09-08 02:20:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 02:20:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 02:20:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 02:20:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 02:20:56 --> Final output sent to browser
DEBUG - 2024-09-08 02:20:56 --> Total execution time: 0.2158
INFO - 2024-09-08 02:43:55 --> Config Class Initialized
INFO - 2024-09-08 02:43:55 --> Hooks Class Initialized
DEBUG - 2024-09-08 02:43:55 --> UTF-8 Support Enabled
INFO - 2024-09-08 02:43:55 --> Utf8 Class Initialized
INFO - 2024-09-08 02:43:55 --> URI Class Initialized
DEBUG - 2024-09-08 02:43:55 --> No URI present. Default controller set.
INFO - 2024-09-08 02:43:55 --> Router Class Initialized
INFO - 2024-09-08 02:43:55 --> Output Class Initialized
INFO - 2024-09-08 02:43:55 --> Security Class Initialized
DEBUG - 2024-09-08 02:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 02:43:55 --> Input Class Initialized
INFO - 2024-09-08 02:43:55 --> Language Class Initialized
INFO - 2024-09-08 02:43:55 --> Loader Class Initialized
INFO - 2024-09-08 02:43:55 --> Helper loaded: url_helper
INFO - 2024-09-08 02:43:55 --> Helper loaded: file_helper
INFO - 2024-09-08 02:43:55 --> Helper loaded: security_helper
INFO - 2024-09-08 02:43:55 --> Helper loaded: wpu_helper
INFO - 2024-09-08 02:43:55 --> Database Driver Class Initialized
INFO - 2024-09-08 02:43:55 --> Email Class Initialized
DEBUG - 2024-09-08 02:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 02:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 02:43:55 --> Helper loaded: form_helper
INFO - 2024-09-08 02:43:55 --> Form Validation Class Initialized
INFO - 2024-09-08 02:43:55 --> Controller Class Initialized
DEBUG - 2024-09-08 02:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 02:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 02:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 02:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 02:43:55 --> Final output sent to browser
DEBUG - 2024-09-08 02:43:55 --> Total execution time: 0.2422
INFO - 2024-09-08 02:59:15 --> Config Class Initialized
INFO - 2024-09-08 02:59:15 --> Hooks Class Initialized
DEBUG - 2024-09-08 02:59:15 --> UTF-8 Support Enabled
INFO - 2024-09-08 02:59:15 --> Utf8 Class Initialized
INFO - 2024-09-08 02:59:15 --> URI Class Initialized
DEBUG - 2024-09-08 02:59:15 --> No URI present. Default controller set.
INFO - 2024-09-08 02:59:15 --> Router Class Initialized
INFO - 2024-09-08 02:59:15 --> Output Class Initialized
INFO - 2024-09-08 02:59:15 --> Security Class Initialized
DEBUG - 2024-09-08 02:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 02:59:15 --> Input Class Initialized
INFO - 2024-09-08 02:59:15 --> Language Class Initialized
INFO - 2024-09-08 02:59:15 --> Loader Class Initialized
INFO - 2024-09-08 02:59:15 --> Helper loaded: url_helper
INFO - 2024-09-08 02:59:15 --> Helper loaded: file_helper
INFO - 2024-09-08 02:59:15 --> Helper loaded: security_helper
INFO - 2024-09-08 02:59:15 --> Helper loaded: wpu_helper
INFO - 2024-09-08 02:59:15 --> Database Driver Class Initialized
INFO - 2024-09-08 02:59:15 --> Email Class Initialized
DEBUG - 2024-09-08 02:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 02:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 02:59:15 --> Helper loaded: form_helper
INFO - 2024-09-08 02:59:15 --> Form Validation Class Initialized
INFO - 2024-09-08 02:59:15 --> Controller Class Initialized
DEBUG - 2024-09-08 02:59:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 02:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 02:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 02:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 02:59:15 --> Final output sent to browser
DEBUG - 2024-09-08 02:59:15 --> Total execution time: 0.2143
INFO - 2024-09-08 03:14:30 --> Config Class Initialized
INFO - 2024-09-08 03:14:30 --> Hooks Class Initialized
DEBUG - 2024-09-08 03:14:30 --> UTF-8 Support Enabled
INFO - 2024-09-08 03:14:30 --> Utf8 Class Initialized
INFO - 2024-09-08 03:14:30 --> URI Class Initialized
DEBUG - 2024-09-08 03:14:30 --> No URI present. Default controller set.
INFO - 2024-09-08 03:14:30 --> Router Class Initialized
INFO - 2024-09-08 03:14:30 --> Output Class Initialized
INFO - 2024-09-08 03:14:30 --> Security Class Initialized
DEBUG - 2024-09-08 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 03:14:30 --> Input Class Initialized
INFO - 2024-09-08 03:14:30 --> Language Class Initialized
INFO - 2024-09-08 03:14:30 --> Loader Class Initialized
INFO - 2024-09-08 03:14:30 --> Helper loaded: url_helper
INFO - 2024-09-08 03:14:30 --> Helper loaded: file_helper
INFO - 2024-09-08 03:14:30 --> Helper loaded: security_helper
INFO - 2024-09-08 03:14:30 --> Helper loaded: wpu_helper
INFO - 2024-09-08 03:14:30 --> Database Driver Class Initialized
INFO - 2024-09-08 03:14:30 --> Email Class Initialized
DEBUG - 2024-09-08 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 03:14:30 --> Helper loaded: form_helper
INFO - 2024-09-08 03:14:30 --> Form Validation Class Initialized
INFO - 2024-09-08 03:14:30 --> Controller Class Initialized
DEBUG - 2024-09-08 03:14:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 03:14:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 03:14:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 03:14:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 03:14:30 --> Final output sent to browser
DEBUG - 2024-09-08 03:14:30 --> Total execution time: 0.2369
INFO - 2024-09-08 03:42:27 --> Config Class Initialized
INFO - 2024-09-08 03:42:27 --> Hooks Class Initialized
DEBUG - 2024-09-08 03:42:27 --> UTF-8 Support Enabled
INFO - 2024-09-08 03:42:27 --> Utf8 Class Initialized
INFO - 2024-09-08 03:42:27 --> URI Class Initialized
DEBUG - 2024-09-08 03:42:27 --> No URI present. Default controller set.
INFO - 2024-09-08 03:42:27 --> Router Class Initialized
INFO - 2024-09-08 03:42:27 --> Output Class Initialized
INFO - 2024-09-08 03:42:27 --> Security Class Initialized
DEBUG - 2024-09-08 03:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 03:42:27 --> Input Class Initialized
INFO - 2024-09-08 03:42:27 --> Language Class Initialized
INFO - 2024-09-08 03:42:27 --> Loader Class Initialized
INFO - 2024-09-08 03:42:27 --> Helper loaded: url_helper
INFO - 2024-09-08 03:42:27 --> Helper loaded: file_helper
INFO - 2024-09-08 03:42:27 --> Helper loaded: security_helper
INFO - 2024-09-08 03:42:27 --> Helper loaded: wpu_helper
INFO - 2024-09-08 03:42:27 --> Database Driver Class Initialized
INFO - 2024-09-08 03:42:27 --> Email Class Initialized
DEBUG - 2024-09-08 03:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 03:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 03:42:27 --> Helper loaded: form_helper
INFO - 2024-09-08 03:42:27 --> Form Validation Class Initialized
INFO - 2024-09-08 03:42:27 --> Controller Class Initialized
DEBUG - 2024-09-08 03:42:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 03:42:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 03:42:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 03:42:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 03:42:27 --> Final output sent to browser
DEBUG - 2024-09-08 03:42:27 --> Total execution time: 0.2148
INFO - 2024-09-08 04:12:54 --> Config Class Initialized
INFO - 2024-09-08 04:12:54 --> Hooks Class Initialized
DEBUG - 2024-09-08 04:12:54 --> UTF-8 Support Enabled
INFO - 2024-09-08 04:12:54 --> Utf8 Class Initialized
INFO - 2024-09-08 04:12:54 --> URI Class Initialized
DEBUG - 2024-09-08 04:12:54 --> No URI present. Default controller set.
INFO - 2024-09-08 04:12:54 --> Router Class Initialized
INFO - 2024-09-08 04:12:54 --> Output Class Initialized
INFO - 2024-09-08 04:12:54 --> Security Class Initialized
DEBUG - 2024-09-08 04:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 04:12:54 --> Input Class Initialized
INFO - 2024-09-08 04:12:54 --> Language Class Initialized
INFO - 2024-09-08 04:12:54 --> Loader Class Initialized
INFO - 2024-09-08 04:12:54 --> Helper loaded: url_helper
INFO - 2024-09-08 04:12:54 --> Helper loaded: file_helper
INFO - 2024-09-08 04:12:54 --> Helper loaded: security_helper
INFO - 2024-09-08 04:12:54 --> Helper loaded: wpu_helper
INFO - 2024-09-08 04:12:54 --> Database Driver Class Initialized
INFO - 2024-09-08 04:12:54 --> Email Class Initialized
DEBUG - 2024-09-08 04:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 04:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 04:12:54 --> Helper loaded: form_helper
INFO - 2024-09-08 04:12:54 --> Form Validation Class Initialized
INFO - 2024-09-08 04:12:54 --> Controller Class Initialized
DEBUG - 2024-09-08 04:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 04:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 04:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 04:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 04:12:54 --> Final output sent to browser
DEBUG - 2024-09-08 04:12:54 --> Total execution time: 0.4662
INFO - 2024-09-08 04:42:49 --> Config Class Initialized
INFO - 2024-09-08 04:42:49 --> Hooks Class Initialized
DEBUG - 2024-09-08 04:42:49 --> UTF-8 Support Enabled
INFO - 2024-09-08 04:42:49 --> Utf8 Class Initialized
INFO - 2024-09-08 04:42:49 --> URI Class Initialized
DEBUG - 2024-09-08 04:42:49 --> No URI present. Default controller set.
INFO - 2024-09-08 04:42:49 --> Router Class Initialized
INFO - 2024-09-08 04:42:49 --> Output Class Initialized
INFO - 2024-09-08 04:42:49 --> Security Class Initialized
DEBUG - 2024-09-08 04:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 04:42:49 --> Input Class Initialized
INFO - 2024-09-08 04:42:49 --> Language Class Initialized
INFO - 2024-09-08 04:42:49 --> Loader Class Initialized
INFO - 2024-09-08 04:42:49 --> Helper loaded: url_helper
INFO - 2024-09-08 04:42:49 --> Helper loaded: file_helper
INFO - 2024-09-08 04:42:49 --> Helper loaded: security_helper
INFO - 2024-09-08 04:42:49 --> Helper loaded: wpu_helper
INFO - 2024-09-08 04:42:49 --> Database Driver Class Initialized
INFO - 2024-09-08 04:42:49 --> Email Class Initialized
DEBUG - 2024-09-08 04:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 04:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 04:42:49 --> Helper loaded: form_helper
INFO - 2024-09-08 04:42:49 --> Form Validation Class Initialized
INFO - 2024-09-08 04:42:49 --> Controller Class Initialized
DEBUG - 2024-09-08 04:42:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 04:42:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 04:42:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 04:42:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 04:42:49 --> Final output sent to browser
DEBUG - 2024-09-08 04:42:49 --> Total execution time: 0.2215
INFO - 2024-09-08 05:10:24 --> Config Class Initialized
INFO - 2024-09-08 05:10:24 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:10:24 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:10:24 --> Utf8 Class Initialized
INFO - 2024-09-08 05:10:24 --> URI Class Initialized
INFO - 2024-09-08 05:10:24 --> Router Class Initialized
INFO - 2024-09-08 05:10:24 --> Output Class Initialized
INFO - 2024-09-08 05:10:24 --> Security Class Initialized
DEBUG - 2024-09-08 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:10:24 --> Input Class Initialized
INFO - 2024-09-08 05:10:24 --> Language Class Initialized
INFO - 2024-09-08 05:10:24 --> Loader Class Initialized
INFO - 2024-09-08 05:10:24 --> Helper loaded: url_helper
INFO - 2024-09-08 05:10:24 --> Helper loaded: file_helper
INFO - 2024-09-08 05:10:24 --> Helper loaded: security_helper
INFO - 2024-09-08 05:10:24 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:10:24 --> Database Driver Class Initialized
INFO - 2024-09-08 05:10:24 --> Email Class Initialized
DEBUG - 2024-09-08 05:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:10:24 --> Helper loaded: form_helper
INFO - 2024-09-08 05:10:24 --> Form Validation Class Initialized
INFO - 2024-09-08 05:10:24 --> Controller Class Initialized
DEBUG - 2024-09-08 05:10:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:10:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-08 05:10:25 --> Config Class Initialized
INFO - 2024-09-08 05:10:25 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:10:25 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:10:25 --> Utf8 Class Initialized
INFO - 2024-09-08 05:10:25 --> URI Class Initialized
INFO - 2024-09-08 05:10:25 --> Router Class Initialized
INFO - 2024-09-08 05:10:25 --> Output Class Initialized
INFO - 2024-09-08 05:10:25 --> Security Class Initialized
DEBUG - 2024-09-08 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:10:25 --> Input Class Initialized
INFO - 2024-09-08 05:10:25 --> Language Class Initialized
INFO - 2024-09-08 05:10:25 --> Loader Class Initialized
INFO - 2024-09-08 05:10:25 --> Helper loaded: url_helper
INFO - 2024-09-08 05:10:25 --> Helper loaded: file_helper
INFO - 2024-09-08 05:10:25 --> Helper loaded: security_helper
INFO - 2024-09-08 05:10:25 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:10:25 --> Database Driver Class Initialized
INFO - 2024-09-08 05:10:25 --> Email Class Initialized
DEBUG - 2024-09-08 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:10:25 --> Helper loaded: form_helper
INFO - 2024-09-08 05:10:25 --> Form Validation Class Initialized
INFO - 2024-09-08 05:10:25 --> Controller Class Initialized
INFO - 2024-09-08 05:10:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:10:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:10:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-08 05:10:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-08 05:10:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-08 05:10:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-08 05:10:25 --> Final output sent to browser
DEBUG - 2024-09-08 05:10:25 --> Total execution time: 0.5727
INFO - 2024-09-08 05:10:51 --> Config Class Initialized
INFO - 2024-09-08 05:10:51 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:10:51 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:10:51 --> Utf8 Class Initialized
INFO - 2024-09-08 05:10:51 --> URI Class Initialized
INFO - 2024-09-08 05:10:51 --> Router Class Initialized
INFO - 2024-09-08 05:10:51 --> Output Class Initialized
INFO - 2024-09-08 05:10:51 --> Security Class Initialized
DEBUG - 2024-09-08 05:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:10:51 --> Input Class Initialized
INFO - 2024-09-08 05:10:51 --> Language Class Initialized
INFO - 2024-09-08 05:10:51 --> Loader Class Initialized
INFO - 2024-09-08 05:10:51 --> Helper loaded: url_helper
INFO - 2024-09-08 05:10:51 --> Helper loaded: file_helper
INFO - 2024-09-08 05:10:51 --> Helper loaded: security_helper
INFO - 2024-09-08 05:10:51 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:10:51 --> Database Driver Class Initialized
INFO - 2024-09-08 05:10:51 --> Email Class Initialized
DEBUG - 2024-09-08 05:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:10:51 --> Helper loaded: form_helper
INFO - 2024-09-08 05:10:51 --> Form Validation Class Initialized
INFO - 2024-09-08 05:10:51 --> Controller Class Initialized
INFO - 2024-09-08 05:10:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:10:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-08 05:10:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-08 05:10:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-08 05:10:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-08 05:10:51 --> Final output sent to browser
DEBUG - 2024-09-08 05:10:51 --> Total execution time: 0.7062
INFO - 2024-09-08 05:11:27 --> Config Class Initialized
INFO - 2024-09-08 05:11:27 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:27 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:27 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:27 --> URI Class Initialized
INFO - 2024-09-08 05:11:27 --> Router Class Initialized
INFO - 2024-09-08 05:11:27 --> Output Class Initialized
INFO - 2024-09-08 05:11:27 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:27 --> Input Class Initialized
INFO - 2024-09-08 05:11:27 --> Language Class Initialized
INFO - 2024-09-08 05:11:27 --> Loader Class Initialized
INFO - 2024-09-08 05:11:27 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:27 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:27 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:27 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:27 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:27 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:27 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:27 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:27 --> Controller Class Initialized
INFO - 2024-09-08 05:11:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:11:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:11:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-08 05:11:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-08 05:11:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-08 05:11:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-08 05:11:27 --> Final output sent to browser
DEBUG - 2024-09-08 05:11:27 --> Total execution time: 0.6611
INFO - 2024-09-08 05:11:29 --> Config Class Initialized
INFO - 2024-09-08 05:11:29 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:29 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:29 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:29 --> URI Class Initialized
INFO - 2024-09-08 05:11:29 --> Router Class Initialized
INFO - 2024-09-08 05:11:29 --> Output Class Initialized
INFO - 2024-09-08 05:11:29 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:29 --> Input Class Initialized
INFO - 2024-09-08 05:11:29 --> Language Class Initialized
INFO - 2024-09-08 05:11:29 --> Loader Class Initialized
INFO - 2024-09-08 05:11:29 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:29 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:29 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:29 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:29 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:30 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:30 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:30 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:30 --> Controller Class Initialized
INFO - 2024-09-08 05:11:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:11:31 --> Final output sent to browser
DEBUG - 2024-09-08 05:11:31 --> Total execution time: 1.0618
INFO - 2024-09-08 05:11:33 --> Config Class Initialized
INFO - 2024-09-08 05:11:33 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:33 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:33 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:33 --> URI Class Initialized
INFO - 2024-09-08 05:11:33 --> Router Class Initialized
INFO - 2024-09-08 05:11:33 --> Output Class Initialized
INFO - 2024-09-08 05:11:33 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:33 --> Input Class Initialized
INFO - 2024-09-08 05:11:33 --> Language Class Initialized
INFO - 2024-09-08 05:11:33 --> Loader Class Initialized
INFO - 2024-09-08 05:11:33 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:33 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:33 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:33 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:33 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:33 --> Controller Class Initialized
INFO - 2024-09-08 05:11:33 --> Config Class Initialized
INFO - 2024-09-08 05:11:33 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:33 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:33 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:33 --> URI Class Initialized
INFO - 2024-09-08 05:11:33 --> Router Class Initialized
INFO - 2024-09-08 05:11:33 --> Output Class Initialized
INFO - 2024-09-08 05:11:33 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:33 --> Input Class Initialized
INFO - 2024-09-08 05:11:33 --> Language Class Initialized
INFO - 2024-09-08 05:11:33 --> Loader Class Initialized
INFO - 2024-09-08 05:11:33 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:33 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:33 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:33 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:33 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:33 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:33 --> Controller Class Initialized
DEBUG - 2024-09-08 05:11:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:11:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 05:11:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 05:11:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 05:11:33 --> Final output sent to browser
DEBUG - 2024-09-08 05:11:33 --> Total execution time: 0.2206
INFO - 2024-09-08 05:11:52 --> Config Class Initialized
INFO - 2024-09-08 05:11:52 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:52 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:52 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:52 --> URI Class Initialized
INFO - 2024-09-08 05:11:52 --> Router Class Initialized
INFO - 2024-09-08 05:11:52 --> Output Class Initialized
INFO - 2024-09-08 05:11:52 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:52 --> Input Class Initialized
INFO - 2024-09-08 05:11:52 --> Language Class Initialized
INFO - 2024-09-08 05:11:52 --> Loader Class Initialized
INFO - 2024-09-08 05:11:52 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:52 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:52 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:52 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:52 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:52 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:52 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:52 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:52 --> Controller Class Initialized
INFO - 2024-09-08 05:11:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:11:53 --> Final output sent to browser
DEBUG - 2024-09-08 05:11:53 --> Total execution time: 1.1918
INFO - 2024-09-08 05:11:54 --> Config Class Initialized
INFO - 2024-09-08 05:11:54 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:54 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:54 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:54 --> URI Class Initialized
INFO - 2024-09-08 05:11:54 --> Router Class Initialized
INFO - 2024-09-08 05:11:54 --> Output Class Initialized
INFO - 2024-09-08 05:11:54 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:54 --> Input Class Initialized
INFO - 2024-09-08 05:11:54 --> Language Class Initialized
INFO - 2024-09-08 05:11:54 --> Loader Class Initialized
INFO - 2024-09-08 05:11:54 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:54 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:54 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:54 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:54 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:54 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:54 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:54 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:54 --> Controller Class Initialized
INFO - 2024-09-08 05:11:55 --> Config Class Initialized
INFO - 2024-09-08 05:11:55 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:11:55 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:11:55 --> Utf8 Class Initialized
INFO - 2024-09-08 05:11:55 --> URI Class Initialized
INFO - 2024-09-08 05:11:55 --> Router Class Initialized
INFO - 2024-09-08 05:11:55 --> Output Class Initialized
INFO - 2024-09-08 05:11:55 --> Security Class Initialized
DEBUG - 2024-09-08 05:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:11:55 --> Input Class Initialized
INFO - 2024-09-08 05:11:55 --> Language Class Initialized
INFO - 2024-09-08 05:11:55 --> Loader Class Initialized
INFO - 2024-09-08 05:11:55 --> Helper loaded: url_helper
INFO - 2024-09-08 05:11:55 --> Helper loaded: file_helper
INFO - 2024-09-08 05:11:55 --> Helper loaded: security_helper
INFO - 2024-09-08 05:11:55 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:11:55 --> Database Driver Class Initialized
INFO - 2024-09-08 05:11:55 --> Email Class Initialized
DEBUG - 2024-09-08 05:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:11:55 --> Helper loaded: form_helper
INFO - 2024-09-08 05:11:55 --> Form Validation Class Initialized
INFO - 2024-09-08 05:11:55 --> Controller Class Initialized
DEBUG - 2024-09-08 05:11:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:11:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 05:11:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 05:11:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 05:11:55 --> Final output sent to browser
DEBUG - 2024-09-08 05:11:55 --> Total execution time: 0.2166
INFO - 2024-09-08 05:12:13 --> Config Class Initialized
INFO - 2024-09-08 05:12:13 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:12:13 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:12:13 --> Utf8 Class Initialized
INFO - 2024-09-08 05:12:13 --> URI Class Initialized
INFO - 2024-09-08 05:12:13 --> Router Class Initialized
INFO - 2024-09-08 05:12:13 --> Output Class Initialized
INFO - 2024-09-08 05:12:13 --> Security Class Initialized
DEBUG - 2024-09-08 05:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:12:13 --> Input Class Initialized
INFO - 2024-09-08 05:12:13 --> Language Class Initialized
INFO - 2024-09-08 05:12:13 --> Loader Class Initialized
INFO - 2024-09-08 05:12:13 --> Helper loaded: url_helper
INFO - 2024-09-08 05:12:13 --> Helper loaded: file_helper
INFO - 2024-09-08 05:12:13 --> Helper loaded: security_helper
INFO - 2024-09-08 05:12:13 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:12:13 --> Database Driver Class Initialized
INFO - 2024-09-08 05:12:13 --> Email Class Initialized
DEBUG - 2024-09-08 05:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:12:13 --> Helper loaded: form_helper
INFO - 2024-09-08 05:12:13 --> Form Validation Class Initialized
INFO - 2024-09-08 05:12:13 --> Controller Class Initialized
INFO - 2024-09-08 05:12:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-08 05:12:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-08 05:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-08 05:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-08 05:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-08 05:12:14 --> Final output sent to browser
DEBUG - 2024-09-08 05:12:14 --> Total execution time: 1.0486
INFO - 2024-09-08 05:12:17 --> Config Class Initialized
INFO - 2024-09-08 05:12:17 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:12:17 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:12:17 --> Utf8 Class Initialized
INFO - 2024-09-08 05:12:17 --> URI Class Initialized
DEBUG - 2024-09-08 05:12:17 --> No URI present. Default controller set.
INFO - 2024-09-08 05:12:17 --> Router Class Initialized
INFO - 2024-09-08 05:12:17 --> Output Class Initialized
INFO - 2024-09-08 05:12:17 --> Security Class Initialized
DEBUG - 2024-09-08 05:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:12:17 --> Input Class Initialized
INFO - 2024-09-08 05:12:17 --> Language Class Initialized
INFO - 2024-09-08 05:12:17 --> Loader Class Initialized
INFO - 2024-09-08 05:12:17 --> Helper loaded: url_helper
INFO - 2024-09-08 05:12:17 --> Helper loaded: file_helper
INFO - 2024-09-08 05:12:17 --> Helper loaded: security_helper
INFO - 2024-09-08 05:12:17 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:12:17 --> Database Driver Class Initialized
INFO - 2024-09-08 05:12:17 --> Email Class Initialized
DEBUG - 2024-09-08 05:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:12:17 --> Helper loaded: form_helper
INFO - 2024-09-08 05:12:17 --> Form Validation Class Initialized
INFO - 2024-09-08 05:12:17 --> Controller Class Initialized
DEBUG - 2024-09-08 05:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 05:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 05:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 05:12:17 --> Final output sent to browser
DEBUG - 2024-09-08 05:12:17 --> Total execution time: 0.2193
INFO - 2024-09-08 05:19:36 --> Config Class Initialized
INFO - 2024-09-08 05:19:36 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:19:36 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:19:36 --> Utf8 Class Initialized
INFO - 2024-09-08 05:19:36 --> URI Class Initialized
DEBUG - 2024-09-08 05:19:36 --> No URI present. Default controller set.
INFO - 2024-09-08 05:19:36 --> Router Class Initialized
INFO - 2024-09-08 05:19:36 --> Output Class Initialized
INFO - 2024-09-08 05:19:36 --> Security Class Initialized
DEBUG - 2024-09-08 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:19:36 --> Input Class Initialized
INFO - 2024-09-08 05:19:36 --> Language Class Initialized
INFO - 2024-09-08 05:19:36 --> Loader Class Initialized
INFO - 2024-09-08 05:19:36 --> Helper loaded: url_helper
INFO - 2024-09-08 05:19:36 --> Helper loaded: file_helper
INFO - 2024-09-08 05:19:36 --> Helper loaded: security_helper
INFO - 2024-09-08 05:19:36 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:19:36 --> Database Driver Class Initialized
INFO - 2024-09-08 05:19:36 --> Email Class Initialized
DEBUG - 2024-09-08 05:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:19:36 --> Helper loaded: form_helper
INFO - 2024-09-08 05:19:36 --> Form Validation Class Initialized
INFO - 2024-09-08 05:19:36 --> Controller Class Initialized
DEBUG - 2024-09-08 05:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:19:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 05:19:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 05:19:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 05:19:36 --> Final output sent to browser
DEBUG - 2024-09-08 05:19:36 --> Total execution time: 0.2290
INFO - 2024-09-08 05:43:30 --> Config Class Initialized
INFO - 2024-09-08 05:43:30 --> Hooks Class Initialized
DEBUG - 2024-09-08 05:43:30 --> UTF-8 Support Enabled
INFO - 2024-09-08 05:43:30 --> Utf8 Class Initialized
INFO - 2024-09-08 05:43:30 --> URI Class Initialized
DEBUG - 2024-09-08 05:43:30 --> No URI present. Default controller set.
INFO - 2024-09-08 05:43:30 --> Router Class Initialized
INFO - 2024-09-08 05:43:30 --> Output Class Initialized
INFO - 2024-09-08 05:43:30 --> Security Class Initialized
DEBUG - 2024-09-08 05:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 05:43:30 --> Input Class Initialized
INFO - 2024-09-08 05:43:30 --> Language Class Initialized
INFO - 2024-09-08 05:43:30 --> Loader Class Initialized
INFO - 2024-09-08 05:43:30 --> Helper loaded: url_helper
INFO - 2024-09-08 05:43:30 --> Helper loaded: file_helper
INFO - 2024-09-08 05:43:30 --> Helper loaded: security_helper
INFO - 2024-09-08 05:43:30 --> Helper loaded: wpu_helper
INFO - 2024-09-08 05:43:30 --> Database Driver Class Initialized
INFO - 2024-09-08 05:43:31 --> Email Class Initialized
DEBUG - 2024-09-08 05:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 05:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 05:43:31 --> Helper loaded: form_helper
INFO - 2024-09-08 05:43:31 --> Form Validation Class Initialized
INFO - 2024-09-08 05:43:31 --> Controller Class Initialized
DEBUG - 2024-09-08 05:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 05:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 05:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 05:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 05:43:31 --> Final output sent to browser
DEBUG - 2024-09-08 05:43:31 --> Total execution time: 0.2148
INFO - 2024-09-08 06:12:41 --> Config Class Initialized
INFO - 2024-09-08 06:12:41 --> Hooks Class Initialized
DEBUG - 2024-09-08 06:12:41 --> UTF-8 Support Enabled
INFO - 2024-09-08 06:12:41 --> Utf8 Class Initialized
INFO - 2024-09-08 06:12:41 --> URI Class Initialized
DEBUG - 2024-09-08 06:12:41 --> No URI present. Default controller set.
INFO - 2024-09-08 06:12:41 --> Router Class Initialized
INFO - 2024-09-08 06:12:41 --> Output Class Initialized
INFO - 2024-09-08 06:12:41 --> Security Class Initialized
DEBUG - 2024-09-08 06:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 06:12:41 --> Input Class Initialized
INFO - 2024-09-08 06:12:41 --> Language Class Initialized
INFO - 2024-09-08 06:12:41 --> Loader Class Initialized
INFO - 2024-09-08 06:12:41 --> Helper loaded: url_helper
INFO - 2024-09-08 06:12:41 --> Helper loaded: file_helper
INFO - 2024-09-08 06:12:41 --> Helper loaded: security_helper
INFO - 2024-09-08 06:12:41 --> Helper loaded: wpu_helper
INFO - 2024-09-08 06:12:41 --> Database Driver Class Initialized
INFO - 2024-09-08 06:12:41 --> Email Class Initialized
DEBUG - 2024-09-08 06:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 06:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 06:12:41 --> Helper loaded: form_helper
INFO - 2024-09-08 06:12:41 --> Form Validation Class Initialized
INFO - 2024-09-08 06:12:41 --> Controller Class Initialized
DEBUG - 2024-09-08 06:12:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 06:12:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 06:12:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 06:12:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 06:12:41 --> Final output sent to browser
DEBUG - 2024-09-08 06:12:41 --> Total execution time: 0.2099
INFO - 2024-09-08 06:16:46 --> Config Class Initialized
INFO - 2024-09-08 06:16:46 --> Hooks Class Initialized
DEBUG - 2024-09-08 06:16:46 --> UTF-8 Support Enabled
INFO - 2024-09-08 06:16:46 --> Utf8 Class Initialized
INFO - 2024-09-08 06:16:46 --> URI Class Initialized
DEBUG - 2024-09-08 06:16:46 --> No URI present. Default controller set.
INFO - 2024-09-08 06:16:46 --> Router Class Initialized
INFO - 2024-09-08 06:16:46 --> Output Class Initialized
INFO - 2024-09-08 06:16:46 --> Security Class Initialized
DEBUG - 2024-09-08 06:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 06:16:46 --> Input Class Initialized
INFO - 2024-09-08 06:16:46 --> Language Class Initialized
INFO - 2024-09-08 06:16:46 --> Loader Class Initialized
INFO - 2024-09-08 06:16:46 --> Helper loaded: url_helper
INFO - 2024-09-08 06:16:46 --> Helper loaded: file_helper
INFO - 2024-09-08 06:16:46 --> Helper loaded: security_helper
INFO - 2024-09-08 06:16:46 --> Helper loaded: wpu_helper
INFO - 2024-09-08 06:16:46 --> Database Driver Class Initialized
INFO - 2024-09-08 06:16:46 --> Email Class Initialized
DEBUG - 2024-09-08 06:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 06:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 06:16:46 --> Helper loaded: form_helper
INFO - 2024-09-08 06:16:46 --> Form Validation Class Initialized
INFO - 2024-09-08 06:16:46 --> Controller Class Initialized
DEBUG - 2024-09-08 06:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 06:16:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 06:16:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 06:16:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 06:16:46 --> Final output sent to browser
DEBUG - 2024-09-08 06:16:46 --> Total execution time: 0.2225
INFO - 2024-09-08 06:16:47 --> Config Class Initialized
INFO - 2024-09-08 06:16:47 --> Hooks Class Initialized
DEBUG - 2024-09-08 06:16:47 --> UTF-8 Support Enabled
INFO - 2024-09-08 06:16:47 --> Utf8 Class Initialized
INFO - 2024-09-08 06:16:47 --> URI Class Initialized
DEBUG - 2024-09-08 06:16:47 --> No URI present. Default controller set.
INFO - 2024-09-08 06:16:47 --> Router Class Initialized
INFO - 2024-09-08 06:16:47 --> Output Class Initialized
INFO - 2024-09-08 06:16:47 --> Security Class Initialized
DEBUG - 2024-09-08 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 06:16:47 --> Input Class Initialized
INFO - 2024-09-08 06:16:47 --> Language Class Initialized
INFO - 2024-09-08 06:16:47 --> Loader Class Initialized
INFO - 2024-09-08 06:16:47 --> Helper loaded: url_helper
INFO - 2024-09-08 06:16:47 --> Helper loaded: file_helper
INFO - 2024-09-08 06:16:47 --> Helper loaded: security_helper
INFO - 2024-09-08 06:16:47 --> Helper loaded: wpu_helper
INFO - 2024-09-08 06:16:47 --> Database Driver Class Initialized
INFO - 2024-09-08 06:16:47 --> Email Class Initialized
DEBUG - 2024-09-08 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 06:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 06:16:47 --> Helper loaded: form_helper
INFO - 2024-09-08 06:16:47 --> Form Validation Class Initialized
INFO - 2024-09-08 06:16:47 --> Controller Class Initialized
DEBUG - 2024-09-08 06:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 06:16:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 06:16:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 06:16:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 06:16:47 --> Final output sent to browser
DEBUG - 2024-09-08 06:16:47 --> Total execution time: 0.2218
INFO - 2024-09-08 06:44:00 --> Config Class Initialized
INFO - 2024-09-08 06:44:00 --> Hooks Class Initialized
DEBUG - 2024-09-08 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-09-08 06:44:00 --> Utf8 Class Initialized
INFO - 2024-09-08 06:44:00 --> URI Class Initialized
DEBUG - 2024-09-08 06:44:00 --> No URI present. Default controller set.
INFO - 2024-09-08 06:44:00 --> Router Class Initialized
INFO - 2024-09-08 06:44:00 --> Output Class Initialized
INFO - 2024-09-08 06:44:00 --> Security Class Initialized
DEBUG - 2024-09-08 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 06:44:00 --> Input Class Initialized
INFO - 2024-09-08 06:44:00 --> Language Class Initialized
INFO - 2024-09-08 06:44:00 --> Loader Class Initialized
INFO - 2024-09-08 06:44:00 --> Helper loaded: url_helper
INFO - 2024-09-08 06:44:00 --> Helper loaded: file_helper
INFO - 2024-09-08 06:44:00 --> Helper loaded: security_helper
INFO - 2024-09-08 06:44:00 --> Helper loaded: wpu_helper
INFO - 2024-09-08 06:44:00 --> Database Driver Class Initialized
INFO - 2024-09-08 06:44:00 --> Email Class Initialized
DEBUG - 2024-09-08 06:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 06:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 06:44:00 --> Helper loaded: form_helper
INFO - 2024-09-08 06:44:00 --> Form Validation Class Initialized
INFO - 2024-09-08 06:44:00 --> Controller Class Initialized
DEBUG - 2024-09-08 06:44:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 06:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 06:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 06:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 06:44:00 --> Final output sent to browser
DEBUG - 2024-09-08 06:44:00 --> Total execution time: 0.2159
INFO - 2024-09-08 07:14:07 --> Config Class Initialized
INFO - 2024-09-08 07:14:07 --> Hooks Class Initialized
DEBUG - 2024-09-08 07:14:07 --> UTF-8 Support Enabled
INFO - 2024-09-08 07:14:07 --> Utf8 Class Initialized
INFO - 2024-09-08 07:14:07 --> URI Class Initialized
DEBUG - 2024-09-08 07:14:07 --> No URI present. Default controller set.
INFO - 2024-09-08 07:14:07 --> Router Class Initialized
INFO - 2024-09-08 07:14:07 --> Output Class Initialized
INFO - 2024-09-08 07:14:07 --> Security Class Initialized
DEBUG - 2024-09-08 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 07:14:07 --> Input Class Initialized
INFO - 2024-09-08 07:14:07 --> Language Class Initialized
INFO - 2024-09-08 07:14:07 --> Loader Class Initialized
INFO - 2024-09-08 07:14:07 --> Helper loaded: url_helper
INFO - 2024-09-08 07:14:07 --> Helper loaded: file_helper
INFO - 2024-09-08 07:14:07 --> Helper loaded: security_helper
INFO - 2024-09-08 07:14:07 --> Helper loaded: wpu_helper
INFO - 2024-09-08 07:14:07 --> Database Driver Class Initialized
INFO - 2024-09-08 07:14:07 --> Email Class Initialized
DEBUG - 2024-09-08 07:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 07:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 07:14:07 --> Helper loaded: form_helper
INFO - 2024-09-08 07:14:07 --> Form Validation Class Initialized
INFO - 2024-09-08 07:14:07 --> Controller Class Initialized
DEBUG - 2024-09-08 07:14:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 07:14:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 07:14:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 07:14:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 07:14:07 --> Final output sent to browser
DEBUG - 2024-09-08 07:14:07 --> Total execution time: 0.2318
INFO - 2024-09-08 07:43:41 --> Config Class Initialized
INFO - 2024-09-08 07:43:41 --> Hooks Class Initialized
DEBUG - 2024-09-08 07:43:41 --> UTF-8 Support Enabled
INFO - 2024-09-08 07:43:41 --> Utf8 Class Initialized
INFO - 2024-09-08 07:43:41 --> URI Class Initialized
DEBUG - 2024-09-08 07:43:41 --> No URI present. Default controller set.
INFO - 2024-09-08 07:43:41 --> Router Class Initialized
INFO - 2024-09-08 07:43:41 --> Output Class Initialized
INFO - 2024-09-08 07:43:41 --> Security Class Initialized
DEBUG - 2024-09-08 07:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 07:43:41 --> Input Class Initialized
INFO - 2024-09-08 07:43:41 --> Language Class Initialized
INFO - 2024-09-08 07:43:41 --> Loader Class Initialized
INFO - 2024-09-08 07:43:41 --> Helper loaded: url_helper
INFO - 2024-09-08 07:43:41 --> Helper loaded: file_helper
INFO - 2024-09-08 07:43:41 --> Helper loaded: security_helper
INFO - 2024-09-08 07:43:41 --> Helper loaded: wpu_helper
INFO - 2024-09-08 07:43:41 --> Database Driver Class Initialized
INFO - 2024-09-08 07:43:42 --> Email Class Initialized
DEBUG - 2024-09-08 07:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 07:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 07:43:42 --> Helper loaded: form_helper
INFO - 2024-09-08 07:43:42 --> Form Validation Class Initialized
INFO - 2024-09-08 07:43:42 --> Controller Class Initialized
DEBUG - 2024-09-08 07:43:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 07:43:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 07:43:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 07:43:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 07:43:42 --> Final output sent to browser
DEBUG - 2024-09-08 07:43:42 --> Total execution time: 0.2231
INFO - 2024-09-08 08:13:04 --> Config Class Initialized
INFO - 2024-09-08 08:13:04 --> Hooks Class Initialized
DEBUG - 2024-09-08 08:13:04 --> UTF-8 Support Enabled
INFO - 2024-09-08 08:13:04 --> Utf8 Class Initialized
INFO - 2024-09-08 08:13:04 --> URI Class Initialized
DEBUG - 2024-09-08 08:13:04 --> No URI present. Default controller set.
INFO - 2024-09-08 08:13:04 --> Router Class Initialized
INFO - 2024-09-08 08:13:04 --> Output Class Initialized
INFO - 2024-09-08 08:13:04 --> Security Class Initialized
DEBUG - 2024-09-08 08:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 08:13:04 --> Input Class Initialized
INFO - 2024-09-08 08:13:04 --> Language Class Initialized
INFO - 2024-09-08 08:13:04 --> Loader Class Initialized
INFO - 2024-09-08 08:13:04 --> Helper loaded: url_helper
INFO - 2024-09-08 08:13:04 --> Helper loaded: file_helper
INFO - 2024-09-08 08:13:04 --> Helper loaded: security_helper
INFO - 2024-09-08 08:13:04 --> Helper loaded: wpu_helper
INFO - 2024-09-08 08:13:04 --> Database Driver Class Initialized
INFO - 2024-09-08 08:13:04 --> Email Class Initialized
DEBUG - 2024-09-08 08:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 08:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 08:13:04 --> Helper loaded: form_helper
INFO - 2024-09-08 08:13:04 --> Form Validation Class Initialized
INFO - 2024-09-08 08:13:04 --> Controller Class Initialized
DEBUG - 2024-09-08 08:13:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 08:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 08:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 08:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 08:13:04 --> Final output sent to browser
DEBUG - 2024-09-08 08:13:04 --> Total execution time: 0.2195
INFO - 2024-09-08 08:42:37 --> Config Class Initialized
INFO - 2024-09-08 08:42:37 --> Hooks Class Initialized
DEBUG - 2024-09-08 08:42:37 --> UTF-8 Support Enabled
INFO - 2024-09-08 08:42:37 --> Utf8 Class Initialized
INFO - 2024-09-08 08:42:37 --> URI Class Initialized
DEBUG - 2024-09-08 08:42:37 --> No URI present. Default controller set.
INFO - 2024-09-08 08:42:37 --> Router Class Initialized
INFO - 2024-09-08 08:42:37 --> Output Class Initialized
INFO - 2024-09-08 08:42:37 --> Security Class Initialized
DEBUG - 2024-09-08 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 08:42:37 --> Input Class Initialized
INFO - 2024-09-08 08:42:37 --> Language Class Initialized
INFO - 2024-09-08 08:42:37 --> Loader Class Initialized
INFO - 2024-09-08 08:42:37 --> Helper loaded: url_helper
INFO - 2024-09-08 08:42:37 --> Helper loaded: file_helper
INFO - 2024-09-08 08:42:37 --> Helper loaded: security_helper
INFO - 2024-09-08 08:42:37 --> Helper loaded: wpu_helper
INFO - 2024-09-08 08:42:37 --> Database Driver Class Initialized
INFO - 2024-09-08 08:42:38 --> Email Class Initialized
DEBUG - 2024-09-08 08:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 08:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 08:42:38 --> Helper loaded: form_helper
INFO - 2024-09-08 08:42:38 --> Form Validation Class Initialized
INFO - 2024-09-08 08:42:38 --> Controller Class Initialized
DEBUG - 2024-09-08 08:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 08:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 08:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 08:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 08:42:38 --> Final output sent to browser
DEBUG - 2024-09-08 08:42:38 --> Total execution time: 0.2117
INFO - 2024-09-08 08:48:06 --> Config Class Initialized
INFO - 2024-09-08 08:48:06 --> Hooks Class Initialized
DEBUG - 2024-09-08 08:48:06 --> UTF-8 Support Enabled
INFO - 2024-09-08 08:48:06 --> Utf8 Class Initialized
INFO - 2024-09-08 08:48:06 --> URI Class Initialized
DEBUG - 2024-09-08 08:48:06 --> No URI present. Default controller set.
INFO - 2024-09-08 08:48:06 --> Router Class Initialized
INFO - 2024-09-08 08:48:06 --> Output Class Initialized
INFO - 2024-09-08 08:48:06 --> Security Class Initialized
DEBUG - 2024-09-08 08:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 08:48:06 --> Input Class Initialized
INFO - 2024-09-08 08:48:06 --> Language Class Initialized
INFO - 2024-09-08 08:48:06 --> Loader Class Initialized
INFO - 2024-09-08 08:48:06 --> Helper loaded: url_helper
INFO - 2024-09-08 08:48:06 --> Helper loaded: file_helper
INFO - 2024-09-08 08:48:06 --> Helper loaded: security_helper
INFO - 2024-09-08 08:48:06 --> Helper loaded: wpu_helper
INFO - 2024-09-08 08:48:06 --> Database Driver Class Initialized
INFO - 2024-09-08 08:48:07 --> Email Class Initialized
DEBUG - 2024-09-08 08:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 08:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 08:48:07 --> Helper loaded: form_helper
INFO - 2024-09-08 08:48:07 --> Form Validation Class Initialized
INFO - 2024-09-08 08:48:07 --> Controller Class Initialized
DEBUG - 2024-09-08 08:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 08:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 08:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 08:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 08:48:07 --> Final output sent to browser
DEBUG - 2024-09-08 08:48:07 --> Total execution time: 0.2357
INFO - 2024-09-08 09:12:43 --> Config Class Initialized
INFO - 2024-09-08 09:12:43 --> Hooks Class Initialized
DEBUG - 2024-09-08 09:12:43 --> UTF-8 Support Enabled
INFO - 2024-09-08 09:12:43 --> Utf8 Class Initialized
INFO - 2024-09-08 09:12:43 --> URI Class Initialized
DEBUG - 2024-09-08 09:12:43 --> No URI present. Default controller set.
INFO - 2024-09-08 09:12:43 --> Router Class Initialized
INFO - 2024-09-08 09:12:43 --> Output Class Initialized
INFO - 2024-09-08 09:12:43 --> Security Class Initialized
DEBUG - 2024-09-08 09:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 09:12:43 --> Input Class Initialized
INFO - 2024-09-08 09:12:43 --> Language Class Initialized
INFO - 2024-09-08 09:12:43 --> Loader Class Initialized
INFO - 2024-09-08 09:12:43 --> Helper loaded: url_helper
INFO - 2024-09-08 09:12:43 --> Helper loaded: file_helper
INFO - 2024-09-08 09:12:43 --> Helper loaded: security_helper
INFO - 2024-09-08 09:12:43 --> Helper loaded: wpu_helper
INFO - 2024-09-08 09:12:43 --> Database Driver Class Initialized
INFO - 2024-09-08 09:12:43 --> Email Class Initialized
DEBUG - 2024-09-08 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 09:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 09:12:43 --> Helper loaded: form_helper
INFO - 2024-09-08 09:12:43 --> Form Validation Class Initialized
INFO - 2024-09-08 09:12:43 --> Controller Class Initialized
DEBUG - 2024-09-08 09:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 09:12:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 09:12:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 09:12:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 09:12:43 --> Final output sent to browser
DEBUG - 2024-09-08 09:12:43 --> Total execution time: 0.2201
INFO - 2024-09-08 09:42:19 --> Config Class Initialized
INFO - 2024-09-08 09:42:19 --> Hooks Class Initialized
DEBUG - 2024-09-08 09:42:19 --> UTF-8 Support Enabled
INFO - 2024-09-08 09:42:19 --> Utf8 Class Initialized
INFO - 2024-09-08 09:42:19 --> URI Class Initialized
DEBUG - 2024-09-08 09:42:19 --> No URI present. Default controller set.
INFO - 2024-09-08 09:42:19 --> Router Class Initialized
INFO - 2024-09-08 09:42:19 --> Output Class Initialized
INFO - 2024-09-08 09:42:19 --> Security Class Initialized
DEBUG - 2024-09-08 09:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 09:42:19 --> Input Class Initialized
INFO - 2024-09-08 09:42:19 --> Language Class Initialized
INFO - 2024-09-08 09:42:19 --> Loader Class Initialized
INFO - 2024-09-08 09:42:19 --> Helper loaded: url_helper
INFO - 2024-09-08 09:42:19 --> Helper loaded: file_helper
INFO - 2024-09-08 09:42:19 --> Helper loaded: security_helper
INFO - 2024-09-08 09:42:19 --> Helper loaded: wpu_helper
INFO - 2024-09-08 09:42:19 --> Database Driver Class Initialized
INFO - 2024-09-08 09:42:19 --> Email Class Initialized
DEBUG - 2024-09-08 09:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 09:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 09:42:19 --> Helper loaded: form_helper
INFO - 2024-09-08 09:42:19 --> Form Validation Class Initialized
INFO - 2024-09-08 09:42:19 --> Controller Class Initialized
DEBUG - 2024-09-08 09:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 09:42:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 09:42:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 09:42:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 09:42:19 --> Final output sent to browser
DEBUG - 2024-09-08 09:42:19 --> Total execution time: 0.2276
INFO - 2024-09-08 10:13:01 --> Config Class Initialized
INFO - 2024-09-08 10:13:01 --> Hooks Class Initialized
DEBUG - 2024-09-08 10:13:01 --> UTF-8 Support Enabled
INFO - 2024-09-08 10:13:01 --> Utf8 Class Initialized
INFO - 2024-09-08 10:13:01 --> URI Class Initialized
DEBUG - 2024-09-08 10:13:01 --> No URI present. Default controller set.
INFO - 2024-09-08 10:13:01 --> Router Class Initialized
INFO - 2024-09-08 10:13:01 --> Output Class Initialized
INFO - 2024-09-08 10:13:01 --> Security Class Initialized
DEBUG - 2024-09-08 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 10:13:01 --> Input Class Initialized
INFO - 2024-09-08 10:13:01 --> Language Class Initialized
INFO - 2024-09-08 10:13:01 --> Loader Class Initialized
INFO - 2024-09-08 10:13:01 --> Helper loaded: url_helper
INFO - 2024-09-08 10:13:01 --> Helper loaded: file_helper
INFO - 2024-09-08 10:13:01 --> Helper loaded: security_helper
INFO - 2024-09-08 10:13:01 --> Helper loaded: wpu_helper
INFO - 2024-09-08 10:13:01 --> Database Driver Class Initialized
INFO - 2024-09-08 10:13:02 --> Email Class Initialized
DEBUG - 2024-09-08 10:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 10:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 10:13:02 --> Helper loaded: form_helper
INFO - 2024-09-08 10:13:02 --> Form Validation Class Initialized
INFO - 2024-09-08 10:13:02 --> Controller Class Initialized
DEBUG - 2024-09-08 10:13:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 10:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 10:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 10:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 10:13:02 --> Final output sent to browser
DEBUG - 2024-09-08 10:13:02 --> Total execution time: 0.2421
INFO - 2024-09-08 10:43:52 --> Config Class Initialized
INFO - 2024-09-08 10:43:52 --> Hooks Class Initialized
DEBUG - 2024-09-08 10:43:52 --> UTF-8 Support Enabled
INFO - 2024-09-08 10:43:52 --> Utf8 Class Initialized
INFO - 2024-09-08 10:43:52 --> URI Class Initialized
DEBUG - 2024-09-08 10:43:52 --> No URI present. Default controller set.
INFO - 2024-09-08 10:43:52 --> Router Class Initialized
INFO - 2024-09-08 10:43:52 --> Output Class Initialized
INFO - 2024-09-08 10:43:52 --> Security Class Initialized
DEBUG - 2024-09-08 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 10:43:52 --> Input Class Initialized
INFO - 2024-09-08 10:43:52 --> Language Class Initialized
INFO - 2024-09-08 10:43:52 --> Loader Class Initialized
INFO - 2024-09-08 10:43:52 --> Helper loaded: url_helper
INFO - 2024-09-08 10:43:52 --> Helper loaded: file_helper
INFO - 2024-09-08 10:43:52 --> Helper loaded: security_helper
INFO - 2024-09-08 10:43:52 --> Helper loaded: wpu_helper
INFO - 2024-09-08 10:43:52 --> Database Driver Class Initialized
INFO - 2024-09-08 10:43:52 --> Email Class Initialized
DEBUG - 2024-09-08 10:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 10:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 10:43:52 --> Helper loaded: form_helper
INFO - 2024-09-08 10:43:52 --> Form Validation Class Initialized
INFO - 2024-09-08 10:43:52 --> Controller Class Initialized
DEBUG - 2024-09-08 10:43:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 10:43:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 10:43:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 10:43:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 10:43:52 --> Final output sent to browser
DEBUG - 2024-09-08 10:43:52 --> Total execution time: 0.2252
INFO - 2024-09-08 11:13:16 --> Config Class Initialized
INFO - 2024-09-08 11:13:16 --> Hooks Class Initialized
DEBUG - 2024-09-08 11:13:16 --> UTF-8 Support Enabled
INFO - 2024-09-08 11:13:16 --> Utf8 Class Initialized
INFO - 2024-09-08 11:13:16 --> URI Class Initialized
DEBUG - 2024-09-08 11:13:16 --> No URI present. Default controller set.
INFO - 2024-09-08 11:13:16 --> Router Class Initialized
INFO - 2024-09-08 11:13:16 --> Output Class Initialized
INFO - 2024-09-08 11:13:16 --> Security Class Initialized
DEBUG - 2024-09-08 11:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 11:13:16 --> Input Class Initialized
INFO - 2024-09-08 11:13:16 --> Language Class Initialized
INFO - 2024-09-08 11:13:16 --> Loader Class Initialized
INFO - 2024-09-08 11:13:16 --> Helper loaded: url_helper
INFO - 2024-09-08 11:13:16 --> Helper loaded: file_helper
INFO - 2024-09-08 11:13:16 --> Helper loaded: security_helper
INFO - 2024-09-08 11:13:16 --> Helper loaded: wpu_helper
INFO - 2024-09-08 11:13:16 --> Database Driver Class Initialized
INFO - 2024-09-08 11:13:16 --> Email Class Initialized
DEBUG - 2024-09-08 11:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 11:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 11:13:16 --> Helper loaded: form_helper
INFO - 2024-09-08 11:13:16 --> Form Validation Class Initialized
INFO - 2024-09-08 11:13:16 --> Controller Class Initialized
DEBUG - 2024-09-08 11:13:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 11:13:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 11:13:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 11:13:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 11:13:16 --> Final output sent to browser
DEBUG - 2024-09-08 11:13:16 --> Total execution time: 0.2190
INFO - 2024-09-08 11:43:33 --> Config Class Initialized
INFO - 2024-09-08 11:43:33 --> Hooks Class Initialized
DEBUG - 2024-09-08 11:43:33 --> UTF-8 Support Enabled
INFO - 2024-09-08 11:43:33 --> Utf8 Class Initialized
INFO - 2024-09-08 11:43:33 --> URI Class Initialized
DEBUG - 2024-09-08 11:43:33 --> No URI present. Default controller set.
INFO - 2024-09-08 11:43:33 --> Router Class Initialized
INFO - 2024-09-08 11:43:33 --> Output Class Initialized
INFO - 2024-09-08 11:43:33 --> Security Class Initialized
DEBUG - 2024-09-08 11:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 11:43:33 --> Input Class Initialized
INFO - 2024-09-08 11:43:33 --> Language Class Initialized
INFO - 2024-09-08 11:43:33 --> Loader Class Initialized
INFO - 2024-09-08 11:43:33 --> Helper loaded: url_helper
INFO - 2024-09-08 11:43:33 --> Helper loaded: file_helper
INFO - 2024-09-08 11:43:33 --> Helper loaded: security_helper
INFO - 2024-09-08 11:43:33 --> Helper loaded: wpu_helper
INFO - 2024-09-08 11:43:33 --> Database Driver Class Initialized
INFO - 2024-09-08 11:43:33 --> Email Class Initialized
DEBUG - 2024-09-08 11:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 11:43:33 --> Helper loaded: form_helper
INFO - 2024-09-08 11:43:33 --> Form Validation Class Initialized
INFO - 2024-09-08 11:43:33 --> Controller Class Initialized
DEBUG - 2024-09-08 11:43:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 11:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 11:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 11:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 11:43:33 --> Final output sent to browser
DEBUG - 2024-09-08 11:43:33 --> Total execution time: 0.2193
INFO - 2024-09-08 12:04:44 --> Config Class Initialized
INFO - 2024-09-08 12:04:44 --> Hooks Class Initialized
DEBUG - 2024-09-08 12:04:44 --> UTF-8 Support Enabled
INFO - 2024-09-08 12:04:44 --> Utf8 Class Initialized
INFO - 2024-09-08 12:04:44 --> URI Class Initialized
DEBUG - 2024-09-08 12:04:44 --> No URI present. Default controller set.
INFO - 2024-09-08 12:04:44 --> Router Class Initialized
INFO - 2024-09-08 12:04:44 --> Output Class Initialized
INFO - 2024-09-08 12:04:44 --> Security Class Initialized
DEBUG - 2024-09-08 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 12:04:44 --> Input Class Initialized
INFO - 2024-09-08 12:04:44 --> Language Class Initialized
INFO - 2024-09-08 12:04:44 --> Loader Class Initialized
INFO - 2024-09-08 12:04:44 --> Helper loaded: url_helper
INFO - 2024-09-08 12:04:44 --> Helper loaded: file_helper
INFO - 2024-09-08 12:04:44 --> Helper loaded: security_helper
INFO - 2024-09-08 12:04:44 --> Helper loaded: wpu_helper
INFO - 2024-09-08 12:04:44 --> Database Driver Class Initialized
INFO - 2024-09-08 12:04:44 --> Email Class Initialized
DEBUG - 2024-09-08 12:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 12:04:44 --> Helper loaded: form_helper
INFO - 2024-09-08 12:04:44 --> Form Validation Class Initialized
INFO - 2024-09-08 12:04:44 --> Controller Class Initialized
DEBUG - 2024-09-08 12:04:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 12:04:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 12:04:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 12:04:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 12:04:44 --> Final output sent to browser
DEBUG - 2024-09-08 12:04:44 --> Total execution time: 0.2190
INFO - 2024-09-08 12:12:14 --> Config Class Initialized
INFO - 2024-09-08 12:12:14 --> Hooks Class Initialized
DEBUG - 2024-09-08 12:12:14 --> UTF-8 Support Enabled
INFO - 2024-09-08 12:12:14 --> Utf8 Class Initialized
INFO - 2024-09-08 12:12:14 --> URI Class Initialized
DEBUG - 2024-09-08 12:12:14 --> No URI present. Default controller set.
INFO - 2024-09-08 12:12:14 --> Router Class Initialized
INFO - 2024-09-08 12:12:14 --> Output Class Initialized
INFO - 2024-09-08 12:12:14 --> Security Class Initialized
DEBUG - 2024-09-08 12:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 12:12:14 --> Input Class Initialized
INFO - 2024-09-08 12:12:14 --> Language Class Initialized
INFO - 2024-09-08 12:12:14 --> Loader Class Initialized
INFO - 2024-09-08 12:12:14 --> Helper loaded: url_helper
INFO - 2024-09-08 12:12:14 --> Helper loaded: file_helper
INFO - 2024-09-08 12:12:14 --> Helper loaded: security_helper
INFO - 2024-09-08 12:12:14 --> Helper loaded: wpu_helper
INFO - 2024-09-08 12:12:14 --> Database Driver Class Initialized
INFO - 2024-09-08 12:12:14 --> Email Class Initialized
DEBUG - 2024-09-08 12:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 12:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 12:12:14 --> Helper loaded: form_helper
INFO - 2024-09-08 12:12:14 --> Form Validation Class Initialized
INFO - 2024-09-08 12:12:14 --> Controller Class Initialized
DEBUG - 2024-09-08 12:12:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 12:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 12:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 12:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 12:12:14 --> Final output sent to browser
DEBUG - 2024-09-08 12:12:14 --> Total execution time: 0.2397
INFO - 2024-09-08 12:43:24 --> Config Class Initialized
INFO - 2024-09-08 12:43:24 --> Hooks Class Initialized
DEBUG - 2024-09-08 12:43:24 --> UTF-8 Support Enabled
INFO - 2024-09-08 12:43:24 --> Utf8 Class Initialized
INFO - 2024-09-08 12:43:24 --> URI Class Initialized
DEBUG - 2024-09-08 12:43:24 --> No URI present. Default controller set.
INFO - 2024-09-08 12:43:24 --> Router Class Initialized
INFO - 2024-09-08 12:43:24 --> Output Class Initialized
INFO - 2024-09-08 12:43:24 --> Security Class Initialized
DEBUG - 2024-09-08 12:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 12:43:24 --> Input Class Initialized
INFO - 2024-09-08 12:43:24 --> Language Class Initialized
INFO - 2024-09-08 12:43:24 --> Loader Class Initialized
INFO - 2024-09-08 12:43:24 --> Helper loaded: url_helper
INFO - 2024-09-08 12:43:24 --> Helper loaded: file_helper
INFO - 2024-09-08 12:43:24 --> Helper loaded: security_helper
INFO - 2024-09-08 12:43:24 --> Helper loaded: wpu_helper
INFO - 2024-09-08 12:43:24 --> Database Driver Class Initialized
INFO - 2024-09-08 12:43:24 --> Email Class Initialized
DEBUG - 2024-09-08 12:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 12:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 12:43:24 --> Helper loaded: form_helper
INFO - 2024-09-08 12:43:24 --> Form Validation Class Initialized
INFO - 2024-09-08 12:43:24 --> Controller Class Initialized
DEBUG - 2024-09-08 12:43:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 12:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 12:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 12:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 12:43:24 --> Final output sent to browser
DEBUG - 2024-09-08 12:43:24 --> Total execution time: 0.2232
INFO - 2024-09-08 13:13:04 --> Config Class Initialized
INFO - 2024-09-08 13:13:04 --> Hooks Class Initialized
DEBUG - 2024-09-08 13:13:04 --> UTF-8 Support Enabled
INFO - 2024-09-08 13:13:04 --> Utf8 Class Initialized
INFO - 2024-09-08 13:13:04 --> URI Class Initialized
DEBUG - 2024-09-08 13:13:04 --> No URI present. Default controller set.
INFO - 2024-09-08 13:13:04 --> Router Class Initialized
INFO - 2024-09-08 13:13:04 --> Output Class Initialized
INFO - 2024-09-08 13:13:04 --> Security Class Initialized
DEBUG - 2024-09-08 13:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 13:13:04 --> Input Class Initialized
INFO - 2024-09-08 13:13:04 --> Language Class Initialized
INFO - 2024-09-08 13:13:04 --> Loader Class Initialized
INFO - 2024-09-08 13:13:04 --> Helper loaded: url_helper
INFO - 2024-09-08 13:13:04 --> Helper loaded: file_helper
INFO - 2024-09-08 13:13:04 --> Helper loaded: security_helper
INFO - 2024-09-08 13:13:04 --> Helper loaded: wpu_helper
INFO - 2024-09-08 13:13:04 --> Database Driver Class Initialized
INFO - 2024-09-08 13:13:04 --> Email Class Initialized
DEBUG - 2024-09-08 13:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 13:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 13:13:04 --> Helper loaded: form_helper
INFO - 2024-09-08 13:13:04 --> Form Validation Class Initialized
INFO - 2024-09-08 13:13:04 --> Controller Class Initialized
DEBUG - 2024-09-08 13:13:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 13:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 13:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 13:13:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 13:13:04 --> Final output sent to browser
DEBUG - 2024-09-08 13:13:04 --> Total execution time: 0.2313
INFO - 2024-09-08 13:43:53 --> Config Class Initialized
INFO - 2024-09-08 13:43:53 --> Hooks Class Initialized
DEBUG - 2024-09-08 13:43:53 --> UTF-8 Support Enabled
INFO - 2024-09-08 13:43:53 --> Utf8 Class Initialized
INFO - 2024-09-08 13:43:53 --> URI Class Initialized
DEBUG - 2024-09-08 13:43:53 --> No URI present. Default controller set.
INFO - 2024-09-08 13:43:53 --> Router Class Initialized
INFO - 2024-09-08 13:43:53 --> Output Class Initialized
INFO - 2024-09-08 13:43:53 --> Security Class Initialized
DEBUG - 2024-09-08 13:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 13:43:53 --> Input Class Initialized
INFO - 2024-09-08 13:43:53 --> Language Class Initialized
INFO - 2024-09-08 13:43:53 --> Loader Class Initialized
INFO - 2024-09-08 13:43:53 --> Helper loaded: url_helper
INFO - 2024-09-08 13:43:53 --> Helper loaded: file_helper
INFO - 2024-09-08 13:43:53 --> Helper loaded: security_helper
INFO - 2024-09-08 13:43:53 --> Helper loaded: wpu_helper
INFO - 2024-09-08 13:43:53 --> Database Driver Class Initialized
INFO - 2024-09-08 13:43:53 --> Email Class Initialized
DEBUG - 2024-09-08 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 13:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 13:43:53 --> Helper loaded: form_helper
INFO - 2024-09-08 13:43:53 --> Form Validation Class Initialized
INFO - 2024-09-08 13:43:53 --> Controller Class Initialized
DEBUG - 2024-09-08 13:43:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 13:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 13:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 13:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 13:43:53 --> Final output sent to browser
DEBUG - 2024-09-08 13:43:53 --> Total execution time: 0.2281
INFO - 2024-09-08 14:13:13 --> Config Class Initialized
INFO - 2024-09-08 14:13:13 --> Hooks Class Initialized
DEBUG - 2024-09-08 14:13:13 --> UTF-8 Support Enabled
INFO - 2024-09-08 14:13:13 --> Utf8 Class Initialized
INFO - 2024-09-08 14:13:13 --> URI Class Initialized
DEBUG - 2024-09-08 14:13:13 --> No URI present. Default controller set.
INFO - 2024-09-08 14:13:13 --> Router Class Initialized
INFO - 2024-09-08 14:13:13 --> Output Class Initialized
INFO - 2024-09-08 14:13:13 --> Security Class Initialized
DEBUG - 2024-09-08 14:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 14:13:13 --> Input Class Initialized
INFO - 2024-09-08 14:13:13 --> Language Class Initialized
INFO - 2024-09-08 14:13:13 --> Loader Class Initialized
INFO - 2024-09-08 14:13:13 --> Helper loaded: url_helper
INFO - 2024-09-08 14:13:13 --> Helper loaded: file_helper
INFO - 2024-09-08 14:13:13 --> Helper loaded: security_helper
INFO - 2024-09-08 14:13:13 --> Helper loaded: wpu_helper
INFO - 2024-09-08 14:13:13 --> Database Driver Class Initialized
INFO - 2024-09-08 14:13:14 --> Email Class Initialized
DEBUG - 2024-09-08 14:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 14:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 14:13:14 --> Helper loaded: form_helper
INFO - 2024-09-08 14:13:14 --> Form Validation Class Initialized
INFO - 2024-09-08 14:13:14 --> Controller Class Initialized
DEBUG - 2024-09-08 14:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 14:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 14:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 14:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 14:13:14 --> Final output sent to browser
DEBUG - 2024-09-08 14:13:14 --> Total execution time: 0.2247
INFO - 2024-09-08 14:44:07 --> Config Class Initialized
INFO - 2024-09-08 14:44:07 --> Hooks Class Initialized
DEBUG - 2024-09-08 14:44:07 --> UTF-8 Support Enabled
INFO - 2024-09-08 14:44:07 --> Utf8 Class Initialized
INFO - 2024-09-08 14:44:07 --> URI Class Initialized
DEBUG - 2024-09-08 14:44:07 --> No URI present. Default controller set.
INFO - 2024-09-08 14:44:07 --> Router Class Initialized
INFO - 2024-09-08 14:44:07 --> Output Class Initialized
INFO - 2024-09-08 14:44:07 --> Security Class Initialized
DEBUG - 2024-09-08 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 14:44:07 --> Input Class Initialized
INFO - 2024-09-08 14:44:07 --> Language Class Initialized
INFO - 2024-09-08 14:44:07 --> Loader Class Initialized
INFO - 2024-09-08 14:44:07 --> Helper loaded: url_helper
INFO - 2024-09-08 14:44:07 --> Helper loaded: file_helper
INFO - 2024-09-08 14:44:07 --> Helper loaded: security_helper
INFO - 2024-09-08 14:44:07 --> Helper loaded: wpu_helper
INFO - 2024-09-08 14:44:07 --> Database Driver Class Initialized
INFO - 2024-09-08 14:44:07 --> Email Class Initialized
DEBUG - 2024-09-08 14:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 14:44:07 --> Helper loaded: form_helper
INFO - 2024-09-08 14:44:07 --> Form Validation Class Initialized
INFO - 2024-09-08 14:44:07 --> Controller Class Initialized
DEBUG - 2024-09-08 14:44:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 14:44:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 14:44:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 14:44:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 14:44:07 --> Final output sent to browser
DEBUG - 2024-09-08 14:44:07 --> Total execution time: 0.2327
INFO - 2024-09-08 14:57:32 --> Config Class Initialized
INFO - 2024-09-08 14:57:32 --> Hooks Class Initialized
DEBUG - 2024-09-08 14:57:32 --> UTF-8 Support Enabled
INFO - 2024-09-08 14:57:32 --> Utf8 Class Initialized
INFO - 2024-09-08 14:57:32 --> URI Class Initialized
DEBUG - 2024-09-08 14:57:32 --> No URI present. Default controller set.
INFO - 2024-09-08 14:57:32 --> Router Class Initialized
INFO - 2024-09-08 14:57:32 --> Output Class Initialized
INFO - 2024-09-08 14:57:32 --> Security Class Initialized
DEBUG - 2024-09-08 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 14:57:32 --> Input Class Initialized
INFO - 2024-09-08 14:57:32 --> Language Class Initialized
INFO - 2024-09-08 14:57:32 --> Loader Class Initialized
INFO - 2024-09-08 14:57:32 --> Helper loaded: url_helper
INFO - 2024-09-08 14:57:32 --> Helper loaded: file_helper
INFO - 2024-09-08 14:57:32 --> Helper loaded: security_helper
INFO - 2024-09-08 14:57:32 --> Helper loaded: wpu_helper
INFO - 2024-09-08 14:57:32 --> Database Driver Class Initialized
INFO - 2024-09-08 14:57:32 --> Email Class Initialized
DEBUG - 2024-09-08 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 14:57:32 --> Helper loaded: form_helper
INFO - 2024-09-08 14:57:32 --> Form Validation Class Initialized
INFO - 2024-09-08 14:57:32 --> Controller Class Initialized
DEBUG - 2024-09-08 14:57:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 14:57:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 14:57:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 14:57:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 14:57:32 --> Final output sent to browser
DEBUG - 2024-09-08 14:57:32 --> Total execution time: 0.2219
INFO - 2024-09-08 15:15:40 --> Config Class Initialized
INFO - 2024-09-08 15:15:40 --> Hooks Class Initialized
DEBUG - 2024-09-08 15:15:40 --> UTF-8 Support Enabled
INFO - 2024-09-08 15:15:40 --> Utf8 Class Initialized
INFO - 2024-09-08 15:15:40 --> URI Class Initialized
DEBUG - 2024-09-08 15:15:40 --> No URI present. Default controller set.
INFO - 2024-09-08 15:15:40 --> Router Class Initialized
INFO - 2024-09-08 15:15:40 --> Output Class Initialized
INFO - 2024-09-08 15:15:40 --> Security Class Initialized
DEBUG - 2024-09-08 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 15:15:40 --> Input Class Initialized
INFO - 2024-09-08 15:15:40 --> Language Class Initialized
INFO - 2024-09-08 15:15:40 --> Loader Class Initialized
INFO - 2024-09-08 15:15:40 --> Helper loaded: url_helper
INFO - 2024-09-08 15:15:40 --> Helper loaded: file_helper
INFO - 2024-09-08 15:15:40 --> Helper loaded: security_helper
INFO - 2024-09-08 15:15:40 --> Helper loaded: wpu_helper
INFO - 2024-09-08 15:15:40 --> Database Driver Class Initialized
INFO - 2024-09-08 15:15:40 --> Email Class Initialized
DEBUG - 2024-09-08 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 15:15:40 --> Helper loaded: form_helper
INFO - 2024-09-08 15:15:40 --> Form Validation Class Initialized
INFO - 2024-09-08 15:15:40 --> Controller Class Initialized
DEBUG - 2024-09-08 15:15:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 15:15:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 15:15:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 15:15:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 15:15:40 --> Final output sent to browser
DEBUG - 2024-09-08 15:15:40 --> Total execution time: 0.2173
INFO - 2024-09-08 15:44:57 --> Config Class Initialized
INFO - 2024-09-08 15:44:57 --> Hooks Class Initialized
DEBUG - 2024-09-08 15:44:57 --> UTF-8 Support Enabled
INFO - 2024-09-08 15:44:57 --> Utf8 Class Initialized
INFO - 2024-09-08 15:44:57 --> URI Class Initialized
DEBUG - 2024-09-08 15:44:57 --> No URI present. Default controller set.
INFO - 2024-09-08 15:44:57 --> Router Class Initialized
INFO - 2024-09-08 15:44:57 --> Output Class Initialized
INFO - 2024-09-08 15:44:57 --> Security Class Initialized
DEBUG - 2024-09-08 15:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 15:44:57 --> Input Class Initialized
INFO - 2024-09-08 15:44:57 --> Language Class Initialized
INFO - 2024-09-08 15:44:57 --> Loader Class Initialized
INFO - 2024-09-08 15:44:57 --> Helper loaded: url_helper
INFO - 2024-09-08 15:44:57 --> Helper loaded: file_helper
INFO - 2024-09-08 15:44:57 --> Helper loaded: security_helper
INFO - 2024-09-08 15:44:57 --> Helper loaded: wpu_helper
INFO - 2024-09-08 15:44:57 --> Database Driver Class Initialized
INFO - 2024-09-08 15:44:57 --> Email Class Initialized
DEBUG - 2024-09-08 15:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 15:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 15:44:57 --> Helper loaded: form_helper
INFO - 2024-09-08 15:44:57 --> Form Validation Class Initialized
INFO - 2024-09-08 15:44:57 --> Controller Class Initialized
DEBUG - 2024-09-08 15:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 15:44:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 15:44:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 15:44:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 15:44:57 --> Final output sent to browser
DEBUG - 2024-09-08 15:44:57 --> Total execution time: 0.2294
INFO - 2024-09-08 16:12:56 --> Config Class Initialized
INFO - 2024-09-08 16:12:56 --> Hooks Class Initialized
DEBUG - 2024-09-08 16:12:56 --> UTF-8 Support Enabled
INFO - 2024-09-08 16:12:56 --> Utf8 Class Initialized
INFO - 2024-09-08 16:12:56 --> URI Class Initialized
DEBUG - 2024-09-08 16:12:56 --> No URI present. Default controller set.
INFO - 2024-09-08 16:12:56 --> Router Class Initialized
INFO - 2024-09-08 16:12:56 --> Output Class Initialized
INFO - 2024-09-08 16:12:56 --> Security Class Initialized
DEBUG - 2024-09-08 16:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 16:12:56 --> Input Class Initialized
INFO - 2024-09-08 16:12:56 --> Language Class Initialized
INFO - 2024-09-08 16:12:56 --> Loader Class Initialized
INFO - 2024-09-08 16:12:56 --> Helper loaded: url_helper
INFO - 2024-09-08 16:12:56 --> Helper loaded: file_helper
INFO - 2024-09-08 16:12:56 --> Helper loaded: security_helper
INFO - 2024-09-08 16:12:56 --> Helper loaded: wpu_helper
INFO - 2024-09-08 16:12:56 --> Database Driver Class Initialized
INFO - 2024-09-08 16:12:56 --> Email Class Initialized
DEBUG - 2024-09-08 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 16:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 16:12:56 --> Helper loaded: form_helper
INFO - 2024-09-08 16:12:56 --> Form Validation Class Initialized
INFO - 2024-09-08 16:12:56 --> Controller Class Initialized
DEBUG - 2024-09-08 16:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 16:12:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 16:12:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 16:12:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 16:12:56 --> Final output sent to browser
DEBUG - 2024-09-08 16:12:56 --> Total execution time: 0.2292
INFO - 2024-09-08 16:12:57 --> Config Class Initialized
INFO - 2024-09-08 16:12:57 --> Hooks Class Initialized
DEBUG - 2024-09-08 16:12:57 --> UTF-8 Support Enabled
INFO - 2024-09-08 16:12:57 --> Utf8 Class Initialized
INFO - 2024-09-08 16:12:57 --> URI Class Initialized
DEBUG - 2024-09-08 16:12:57 --> No URI present. Default controller set.
INFO - 2024-09-08 16:12:57 --> Router Class Initialized
INFO - 2024-09-08 16:12:57 --> Output Class Initialized
INFO - 2024-09-08 16:12:57 --> Security Class Initialized
DEBUG - 2024-09-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 16:12:57 --> Input Class Initialized
INFO - 2024-09-08 16:12:57 --> Language Class Initialized
INFO - 2024-09-08 16:12:57 --> Loader Class Initialized
INFO - 2024-09-08 16:12:57 --> Helper loaded: url_helper
INFO - 2024-09-08 16:12:57 --> Helper loaded: file_helper
INFO - 2024-09-08 16:12:57 --> Helper loaded: security_helper
INFO - 2024-09-08 16:12:57 --> Helper loaded: wpu_helper
INFO - 2024-09-08 16:12:57 --> Database Driver Class Initialized
INFO - 2024-09-08 16:12:57 --> Email Class Initialized
DEBUG - 2024-09-08 16:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 16:12:57 --> Helper loaded: form_helper
INFO - 2024-09-08 16:12:57 --> Form Validation Class Initialized
INFO - 2024-09-08 16:12:57 --> Controller Class Initialized
DEBUG - 2024-09-08 16:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 16:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 16:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 16:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 16:12:57 --> Final output sent to browser
DEBUG - 2024-09-08 16:12:57 --> Total execution time: 0.2288
INFO - 2024-09-08 16:13:46 --> Config Class Initialized
INFO - 2024-09-08 16:13:46 --> Hooks Class Initialized
DEBUG - 2024-09-08 16:13:46 --> UTF-8 Support Enabled
INFO - 2024-09-08 16:13:46 --> Utf8 Class Initialized
INFO - 2024-09-08 16:13:46 --> URI Class Initialized
DEBUG - 2024-09-08 16:13:46 --> No URI present. Default controller set.
INFO - 2024-09-08 16:13:46 --> Router Class Initialized
INFO - 2024-09-08 16:13:46 --> Output Class Initialized
INFO - 2024-09-08 16:13:46 --> Security Class Initialized
DEBUG - 2024-09-08 16:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 16:13:46 --> Input Class Initialized
INFO - 2024-09-08 16:13:46 --> Language Class Initialized
INFO - 2024-09-08 16:13:46 --> Loader Class Initialized
INFO - 2024-09-08 16:13:46 --> Helper loaded: url_helper
INFO - 2024-09-08 16:13:46 --> Helper loaded: file_helper
INFO - 2024-09-08 16:13:46 --> Helper loaded: security_helper
INFO - 2024-09-08 16:13:46 --> Helper loaded: wpu_helper
INFO - 2024-09-08 16:13:46 --> Database Driver Class Initialized
INFO - 2024-09-08 16:13:46 --> Email Class Initialized
DEBUG - 2024-09-08 16:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 16:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 16:13:46 --> Helper loaded: form_helper
INFO - 2024-09-08 16:13:46 --> Form Validation Class Initialized
INFO - 2024-09-08 16:13:46 --> Controller Class Initialized
DEBUG - 2024-09-08 16:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 16:13:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 16:13:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 16:13:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 16:13:46 --> Final output sent to browser
DEBUG - 2024-09-08 16:13:46 --> Total execution time: 0.2337
INFO - 2024-09-08 16:43:33 --> Config Class Initialized
INFO - 2024-09-08 16:43:33 --> Hooks Class Initialized
DEBUG - 2024-09-08 16:43:33 --> UTF-8 Support Enabled
INFO - 2024-09-08 16:43:33 --> Utf8 Class Initialized
INFO - 2024-09-08 16:43:33 --> URI Class Initialized
DEBUG - 2024-09-08 16:43:33 --> No URI present. Default controller set.
INFO - 2024-09-08 16:43:33 --> Router Class Initialized
INFO - 2024-09-08 16:43:33 --> Output Class Initialized
INFO - 2024-09-08 16:43:33 --> Security Class Initialized
DEBUG - 2024-09-08 16:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 16:43:33 --> Input Class Initialized
INFO - 2024-09-08 16:43:33 --> Language Class Initialized
INFO - 2024-09-08 16:43:33 --> Loader Class Initialized
INFO - 2024-09-08 16:43:33 --> Helper loaded: url_helper
INFO - 2024-09-08 16:43:33 --> Helper loaded: file_helper
INFO - 2024-09-08 16:43:33 --> Helper loaded: security_helper
INFO - 2024-09-08 16:43:33 --> Helper loaded: wpu_helper
INFO - 2024-09-08 16:43:33 --> Database Driver Class Initialized
INFO - 2024-09-08 16:43:34 --> Email Class Initialized
DEBUG - 2024-09-08 16:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 16:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 16:43:34 --> Helper loaded: form_helper
INFO - 2024-09-08 16:43:34 --> Form Validation Class Initialized
INFO - 2024-09-08 16:43:34 --> Controller Class Initialized
DEBUG - 2024-09-08 16:43:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 16:43:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 16:43:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 16:43:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 16:43:34 --> Final output sent to browser
DEBUG - 2024-09-08 16:43:34 --> Total execution time: 0.2410
INFO - 2024-09-08 17:16:57 --> Config Class Initialized
INFO - 2024-09-08 17:16:57 --> Hooks Class Initialized
DEBUG - 2024-09-08 17:16:57 --> UTF-8 Support Enabled
INFO - 2024-09-08 17:16:57 --> Utf8 Class Initialized
INFO - 2024-09-08 17:16:57 --> URI Class Initialized
DEBUG - 2024-09-08 17:16:57 --> No URI present. Default controller set.
INFO - 2024-09-08 17:16:57 --> Router Class Initialized
INFO - 2024-09-08 17:16:57 --> Output Class Initialized
INFO - 2024-09-08 17:16:57 --> Security Class Initialized
DEBUG - 2024-09-08 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 17:16:57 --> Input Class Initialized
INFO - 2024-09-08 17:16:57 --> Language Class Initialized
INFO - 2024-09-08 17:16:57 --> Loader Class Initialized
INFO - 2024-09-08 17:16:57 --> Helper loaded: url_helper
INFO - 2024-09-08 17:16:57 --> Helper loaded: file_helper
INFO - 2024-09-08 17:16:57 --> Helper loaded: security_helper
INFO - 2024-09-08 17:16:57 --> Helper loaded: wpu_helper
INFO - 2024-09-08 17:16:57 --> Database Driver Class Initialized
INFO - 2024-09-08 17:16:57 --> Email Class Initialized
DEBUG - 2024-09-08 17:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 17:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 17:16:57 --> Helper loaded: form_helper
INFO - 2024-09-08 17:16:57 --> Form Validation Class Initialized
INFO - 2024-09-08 17:16:57 --> Controller Class Initialized
DEBUG - 2024-09-08 17:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 17:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 17:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 17:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 17:16:57 --> Final output sent to browser
DEBUG - 2024-09-08 17:16:57 --> Total execution time: 0.2345
INFO - 2024-09-08 17:44:50 --> Config Class Initialized
INFO - 2024-09-08 17:44:50 --> Hooks Class Initialized
DEBUG - 2024-09-08 17:44:50 --> UTF-8 Support Enabled
INFO - 2024-09-08 17:44:50 --> Utf8 Class Initialized
INFO - 2024-09-08 17:44:50 --> URI Class Initialized
DEBUG - 2024-09-08 17:44:50 --> No URI present. Default controller set.
INFO - 2024-09-08 17:44:50 --> Router Class Initialized
INFO - 2024-09-08 17:44:50 --> Output Class Initialized
INFO - 2024-09-08 17:44:50 --> Security Class Initialized
DEBUG - 2024-09-08 17:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 17:44:50 --> Input Class Initialized
INFO - 2024-09-08 17:44:50 --> Language Class Initialized
INFO - 2024-09-08 17:44:50 --> Loader Class Initialized
INFO - 2024-09-08 17:44:50 --> Helper loaded: url_helper
INFO - 2024-09-08 17:44:50 --> Helper loaded: file_helper
INFO - 2024-09-08 17:44:50 --> Helper loaded: security_helper
INFO - 2024-09-08 17:44:50 --> Helper loaded: wpu_helper
INFO - 2024-09-08 17:44:50 --> Database Driver Class Initialized
INFO - 2024-09-08 17:44:50 --> Email Class Initialized
DEBUG - 2024-09-08 17:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 17:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 17:44:50 --> Helper loaded: form_helper
INFO - 2024-09-08 17:44:50 --> Form Validation Class Initialized
INFO - 2024-09-08 17:44:50 --> Controller Class Initialized
DEBUG - 2024-09-08 17:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 17:44:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 17:44:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 17:44:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 17:44:50 --> Final output sent to browser
DEBUG - 2024-09-08 17:44:50 --> Total execution time: 0.2171
INFO - 2024-09-08 17:51:41 --> Config Class Initialized
INFO - 2024-09-08 17:51:41 --> Hooks Class Initialized
DEBUG - 2024-09-08 17:51:41 --> UTF-8 Support Enabled
INFO - 2024-09-08 17:51:41 --> Utf8 Class Initialized
INFO - 2024-09-08 17:51:41 --> URI Class Initialized
DEBUG - 2024-09-08 17:51:41 --> No URI present. Default controller set.
INFO - 2024-09-08 17:51:41 --> Router Class Initialized
INFO - 2024-09-08 17:51:41 --> Output Class Initialized
INFO - 2024-09-08 17:51:41 --> Security Class Initialized
DEBUG - 2024-09-08 17:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 17:51:41 --> Input Class Initialized
INFO - 2024-09-08 17:51:41 --> Language Class Initialized
INFO - 2024-09-08 17:51:41 --> Loader Class Initialized
INFO - 2024-09-08 17:51:41 --> Helper loaded: url_helper
INFO - 2024-09-08 17:51:41 --> Helper loaded: file_helper
INFO - 2024-09-08 17:51:41 --> Helper loaded: security_helper
INFO - 2024-09-08 17:51:41 --> Helper loaded: wpu_helper
INFO - 2024-09-08 17:51:41 --> Database Driver Class Initialized
INFO - 2024-09-08 17:51:41 --> Email Class Initialized
DEBUG - 2024-09-08 17:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 17:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 17:51:41 --> Helper loaded: form_helper
INFO - 2024-09-08 17:51:41 --> Form Validation Class Initialized
INFO - 2024-09-08 17:51:41 --> Controller Class Initialized
DEBUG - 2024-09-08 17:51:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 17:51:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 17:51:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 17:51:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 17:51:41 --> Final output sent to browser
DEBUG - 2024-09-08 17:51:41 --> Total execution time: 0.2209
INFO - 2024-09-08 18:14:07 --> Config Class Initialized
INFO - 2024-09-08 18:14:07 --> Hooks Class Initialized
DEBUG - 2024-09-08 18:14:07 --> UTF-8 Support Enabled
INFO - 2024-09-08 18:14:07 --> Utf8 Class Initialized
INFO - 2024-09-08 18:14:07 --> URI Class Initialized
DEBUG - 2024-09-08 18:14:07 --> No URI present. Default controller set.
INFO - 2024-09-08 18:14:07 --> Router Class Initialized
INFO - 2024-09-08 18:14:07 --> Output Class Initialized
INFO - 2024-09-08 18:14:07 --> Security Class Initialized
DEBUG - 2024-09-08 18:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 18:14:07 --> Input Class Initialized
INFO - 2024-09-08 18:14:07 --> Language Class Initialized
INFO - 2024-09-08 18:14:07 --> Loader Class Initialized
INFO - 2024-09-08 18:14:07 --> Helper loaded: url_helper
INFO - 2024-09-08 18:14:07 --> Helper loaded: file_helper
INFO - 2024-09-08 18:14:07 --> Helper loaded: security_helper
INFO - 2024-09-08 18:14:07 --> Helper loaded: wpu_helper
INFO - 2024-09-08 18:14:07 --> Database Driver Class Initialized
INFO - 2024-09-08 18:14:08 --> Email Class Initialized
DEBUG - 2024-09-08 18:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 18:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 18:14:08 --> Helper loaded: form_helper
INFO - 2024-09-08 18:14:08 --> Form Validation Class Initialized
INFO - 2024-09-08 18:14:08 --> Controller Class Initialized
DEBUG - 2024-09-08 18:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 18:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 18:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 18:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 18:14:08 --> Final output sent to browser
DEBUG - 2024-09-08 18:14:08 --> Total execution time: 0.2319
INFO - 2024-09-08 18:29:07 --> Config Class Initialized
INFO - 2024-09-08 18:29:07 --> Hooks Class Initialized
DEBUG - 2024-09-08 18:29:07 --> UTF-8 Support Enabled
INFO - 2024-09-08 18:29:07 --> Utf8 Class Initialized
INFO - 2024-09-08 18:29:07 --> URI Class Initialized
DEBUG - 2024-09-08 18:29:07 --> No URI present. Default controller set.
INFO - 2024-09-08 18:29:07 --> Router Class Initialized
INFO - 2024-09-08 18:29:07 --> Output Class Initialized
INFO - 2024-09-08 18:29:07 --> Security Class Initialized
DEBUG - 2024-09-08 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 18:29:07 --> Input Class Initialized
INFO - 2024-09-08 18:29:07 --> Language Class Initialized
INFO - 2024-09-08 18:29:07 --> Loader Class Initialized
INFO - 2024-09-08 18:29:07 --> Helper loaded: url_helper
INFO - 2024-09-08 18:29:07 --> Helper loaded: file_helper
INFO - 2024-09-08 18:29:07 --> Helper loaded: security_helper
INFO - 2024-09-08 18:29:07 --> Helper loaded: wpu_helper
INFO - 2024-09-08 18:29:07 --> Database Driver Class Initialized
INFO - 2024-09-08 18:29:07 --> Email Class Initialized
DEBUG - 2024-09-08 18:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 18:29:07 --> Helper loaded: form_helper
INFO - 2024-09-08 18:29:07 --> Form Validation Class Initialized
INFO - 2024-09-08 18:29:07 --> Controller Class Initialized
DEBUG - 2024-09-08 18:29:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 18:29:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 18:29:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 18:29:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 18:29:07 --> Final output sent to browser
DEBUG - 2024-09-08 18:29:07 --> Total execution time: 0.2391
INFO - 2024-09-08 18:43:46 --> Config Class Initialized
INFO - 2024-09-08 18:43:46 --> Hooks Class Initialized
DEBUG - 2024-09-08 18:43:46 --> UTF-8 Support Enabled
INFO - 2024-09-08 18:43:46 --> Utf8 Class Initialized
INFO - 2024-09-08 18:43:46 --> URI Class Initialized
DEBUG - 2024-09-08 18:43:46 --> No URI present. Default controller set.
INFO - 2024-09-08 18:43:46 --> Router Class Initialized
INFO - 2024-09-08 18:43:46 --> Output Class Initialized
INFO - 2024-09-08 18:43:46 --> Security Class Initialized
DEBUG - 2024-09-08 18:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 18:43:46 --> Input Class Initialized
INFO - 2024-09-08 18:43:46 --> Language Class Initialized
INFO - 2024-09-08 18:43:46 --> Loader Class Initialized
INFO - 2024-09-08 18:43:46 --> Helper loaded: url_helper
INFO - 2024-09-08 18:43:46 --> Helper loaded: file_helper
INFO - 2024-09-08 18:43:46 --> Helper loaded: security_helper
INFO - 2024-09-08 18:43:46 --> Helper loaded: wpu_helper
INFO - 2024-09-08 18:43:46 --> Database Driver Class Initialized
INFO - 2024-09-08 18:43:46 --> Email Class Initialized
DEBUG - 2024-09-08 18:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 18:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 18:43:46 --> Helper loaded: form_helper
INFO - 2024-09-08 18:43:46 --> Form Validation Class Initialized
INFO - 2024-09-08 18:43:46 --> Controller Class Initialized
DEBUG - 2024-09-08 18:43:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 18:43:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 18:43:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 18:43:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 18:43:46 --> Final output sent to browser
DEBUG - 2024-09-08 18:43:46 --> Total execution time: 0.2238
INFO - 2024-09-08 19:14:13 --> Config Class Initialized
INFO - 2024-09-08 19:14:13 --> Hooks Class Initialized
DEBUG - 2024-09-08 19:14:13 --> UTF-8 Support Enabled
INFO - 2024-09-08 19:14:13 --> Utf8 Class Initialized
INFO - 2024-09-08 19:14:13 --> URI Class Initialized
DEBUG - 2024-09-08 19:14:13 --> No URI present. Default controller set.
INFO - 2024-09-08 19:14:13 --> Router Class Initialized
INFO - 2024-09-08 19:14:13 --> Output Class Initialized
INFO - 2024-09-08 19:14:13 --> Security Class Initialized
DEBUG - 2024-09-08 19:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 19:14:13 --> Input Class Initialized
INFO - 2024-09-08 19:14:13 --> Language Class Initialized
INFO - 2024-09-08 19:14:13 --> Loader Class Initialized
INFO - 2024-09-08 19:14:13 --> Helper loaded: url_helper
INFO - 2024-09-08 19:14:13 --> Helper loaded: file_helper
INFO - 2024-09-08 19:14:13 --> Helper loaded: security_helper
INFO - 2024-09-08 19:14:13 --> Helper loaded: wpu_helper
INFO - 2024-09-08 19:14:13 --> Database Driver Class Initialized
INFO - 2024-09-08 19:14:13 --> Email Class Initialized
DEBUG - 2024-09-08 19:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 19:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 19:14:13 --> Helper loaded: form_helper
INFO - 2024-09-08 19:14:13 --> Form Validation Class Initialized
INFO - 2024-09-08 19:14:13 --> Controller Class Initialized
DEBUG - 2024-09-08 19:14:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 19:14:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 19:14:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 19:14:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 19:14:13 --> Final output sent to browser
DEBUG - 2024-09-08 19:14:13 --> Total execution time: 0.2238
INFO - 2024-09-08 19:30:41 --> Config Class Initialized
INFO - 2024-09-08 19:30:41 --> Hooks Class Initialized
DEBUG - 2024-09-08 19:30:41 --> UTF-8 Support Enabled
INFO - 2024-09-08 19:30:41 --> Utf8 Class Initialized
INFO - 2024-09-08 19:30:41 --> URI Class Initialized
DEBUG - 2024-09-08 19:30:41 --> No URI present. Default controller set.
INFO - 2024-09-08 19:30:41 --> Router Class Initialized
INFO - 2024-09-08 19:30:41 --> Output Class Initialized
INFO - 2024-09-08 19:30:41 --> Security Class Initialized
DEBUG - 2024-09-08 19:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 19:30:41 --> Input Class Initialized
INFO - 2024-09-08 19:30:41 --> Language Class Initialized
INFO - 2024-09-08 19:30:41 --> Loader Class Initialized
INFO - 2024-09-08 19:30:41 --> Helper loaded: url_helper
INFO - 2024-09-08 19:30:41 --> Helper loaded: file_helper
INFO - 2024-09-08 19:30:41 --> Helper loaded: security_helper
INFO - 2024-09-08 19:30:41 --> Helper loaded: wpu_helper
INFO - 2024-09-08 19:30:41 --> Database Driver Class Initialized
INFO - 2024-09-08 19:30:41 --> Email Class Initialized
DEBUG - 2024-09-08 19:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 19:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 19:30:41 --> Helper loaded: form_helper
INFO - 2024-09-08 19:30:41 --> Form Validation Class Initialized
INFO - 2024-09-08 19:30:41 --> Controller Class Initialized
DEBUG - 2024-09-08 19:30:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 19:30:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 19:30:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 19:30:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 19:30:41 --> Final output sent to browser
DEBUG - 2024-09-08 19:30:41 --> Total execution time: 0.2158
INFO - 2024-09-08 19:43:39 --> Config Class Initialized
INFO - 2024-09-08 19:43:39 --> Hooks Class Initialized
DEBUG - 2024-09-08 19:43:39 --> UTF-8 Support Enabled
INFO - 2024-09-08 19:43:39 --> Utf8 Class Initialized
INFO - 2024-09-08 19:43:39 --> URI Class Initialized
DEBUG - 2024-09-08 19:43:39 --> No URI present. Default controller set.
INFO - 2024-09-08 19:43:39 --> Router Class Initialized
INFO - 2024-09-08 19:43:39 --> Output Class Initialized
INFO - 2024-09-08 19:43:39 --> Security Class Initialized
DEBUG - 2024-09-08 19:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 19:43:39 --> Input Class Initialized
INFO - 2024-09-08 19:43:39 --> Language Class Initialized
INFO - 2024-09-08 19:43:39 --> Loader Class Initialized
INFO - 2024-09-08 19:43:39 --> Helper loaded: url_helper
INFO - 2024-09-08 19:43:39 --> Helper loaded: file_helper
INFO - 2024-09-08 19:43:39 --> Helper loaded: security_helper
INFO - 2024-09-08 19:43:39 --> Helper loaded: wpu_helper
INFO - 2024-09-08 19:43:39 --> Database Driver Class Initialized
INFO - 2024-09-08 19:43:39 --> Email Class Initialized
DEBUG - 2024-09-08 19:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 19:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 19:43:39 --> Helper loaded: form_helper
INFO - 2024-09-08 19:43:39 --> Form Validation Class Initialized
INFO - 2024-09-08 19:43:39 --> Controller Class Initialized
DEBUG - 2024-09-08 19:43:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 19:43:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 19:43:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 19:43:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 19:43:39 --> Final output sent to browser
DEBUG - 2024-09-08 19:43:39 --> Total execution time: 0.2210
INFO - 2024-09-08 20:13:48 --> Config Class Initialized
INFO - 2024-09-08 20:13:48 --> Hooks Class Initialized
DEBUG - 2024-09-08 20:13:48 --> UTF-8 Support Enabled
INFO - 2024-09-08 20:13:48 --> Utf8 Class Initialized
INFO - 2024-09-08 20:13:48 --> URI Class Initialized
DEBUG - 2024-09-08 20:13:48 --> No URI present. Default controller set.
INFO - 2024-09-08 20:13:48 --> Router Class Initialized
INFO - 2024-09-08 20:13:48 --> Output Class Initialized
INFO - 2024-09-08 20:13:48 --> Security Class Initialized
DEBUG - 2024-09-08 20:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:13:48 --> Input Class Initialized
INFO - 2024-09-08 20:13:48 --> Language Class Initialized
INFO - 2024-09-08 20:13:48 --> Loader Class Initialized
INFO - 2024-09-08 20:13:48 --> Helper loaded: url_helper
INFO - 2024-09-08 20:13:48 --> Helper loaded: file_helper
INFO - 2024-09-08 20:13:48 --> Helper loaded: security_helper
INFO - 2024-09-08 20:13:48 --> Helper loaded: wpu_helper
INFO - 2024-09-08 20:13:48 --> Database Driver Class Initialized
INFO - 2024-09-08 20:13:48 --> Email Class Initialized
DEBUG - 2024-09-08 20:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 20:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 20:13:48 --> Helper loaded: form_helper
INFO - 2024-09-08 20:13:48 --> Form Validation Class Initialized
INFO - 2024-09-08 20:13:48 --> Controller Class Initialized
DEBUG - 2024-09-08 20:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 20:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 20:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 20:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 20:13:48 --> Final output sent to browser
DEBUG - 2024-09-08 20:13:48 --> Total execution time: 0.2214
INFO - 2024-09-08 20:43:03 --> Config Class Initialized
INFO - 2024-09-08 20:43:03 --> Config Class Initialized
INFO - 2024-09-08 20:43:03 --> Hooks Class Initialized
INFO - 2024-09-08 20:43:03 --> Hooks Class Initialized
DEBUG - 2024-09-08 20:43:03 --> UTF-8 Support Enabled
DEBUG - 2024-09-08 20:43:03 --> UTF-8 Support Enabled
INFO - 2024-09-08 20:43:03 --> Utf8 Class Initialized
INFO - 2024-09-08 20:43:03 --> Utf8 Class Initialized
INFO - 2024-09-08 20:43:03 --> URI Class Initialized
INFO - 2024-09-08 20:43:03 --> URI Class Initialized
DEBUG - 2024-09-08 20:43:03 --> No URI present. Default controller set.
INFO - 2024-09-08 20:43:03 --> Router Class Initialized
DEBUG - 2024-09-08 20:43:03 --> No URI present. Default controller set.
INFO - 2024-09-08 20:43:03 --> Router Class Initialized
INFO - 2024-09-08 20:43:03 --> Output Class Initialized
INFO - 2024-09-08 20:43:03 --> Output Class Initialized
INFO - 2024-09-08 20:43:03 --> Security Class Initialized
INFO - 2024-09-08 20:43:03 --> Security Class Initialized
DEBUG - 2024-09-08 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:43:03 --> Input Class Initialized
DEBUG - 2024-09-08 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:43:03 --> Input Class Initialized
INFO - 2024-09-08 20:43:03 --> Language Class Initialized
INFO - 2024-09-08 20:43:03 --> Language Class Initialized
INFO - 2024-09-08 20:43:03 --> Loader Class Initialized
INFO - 2024-09-08 20:43:03 --> Loader Class Initialized
INFO - 2024-09-08 20:43:03 --> Helper loaded: url_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: url_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: file_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: file_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: security_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: security_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: wpu_helper
INFO - 2024-09-08 20:43:03 --> Helper loaded: wpu_helper
INFO - 2024-09-08 20:43:03 --> Database Driver Class Initialized
INFO - 2024-09-08 20:43:03 --> Database Driver Class Initialized
INFO - 2024-09-08 20:43:04 --> Email Class Initialized
DEBUG - 2024-09-08 20:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 20:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 20:43:04 --> Helper loaded: form_helper
INFO - 2024-09-08 20:43:04 --> Form Validation Class Initialized
INFO - 2024-09-08 20:43:04 --> Controller Class Initialized
DEBUG - 2024-09-08 20:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 20:43:04 --> Final output sent to browser
DEBUG - 2024-09-08 20:43:04 --> Total execution time: 0.2483
INFO - 2024-09-08 20:43:04 --> Email Class Initialized
DEBUG - 2024-09-08 20:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 20:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 20:43:04 --> Helper loaded: form_helper
INFO - 2024-09-08 20:43:04 --> Form Validation Class Initialized
INFO - 2024-09-08 20:43:04 --> Controller Class Initialized
DEBUG - 2024-09-08 20:43:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 20:43:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 20:43:04 --> Final output sent to browser
DEBUG - 2024-09-08 20:43:04 --> Total execution time: 0.2633
INFO - 2024-09-08 20:43:16 --> Config Class Initialized
INFO - 2024-09-08 20:43:16 --> Hooks Class Initialized
DEBUG - 2024-09-08 20:43:16 --> UTF-8 Support Enabled
INFO - 2024-09-08 20:43:16 --> Utf8 Class Initialized
INFO - 2024-09-08 20:43:16 --> URI Class Initialized
INFO - 2024-09-08 20:43:16 --> Router Class Initialized
INFO - 2024-09-08 20:43:16 --> Output Class Initialized
INFO - 2024-09-08 20:43:16 --> Security Class Initialized
DEBUG - 2024-09-08 20:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:43:16 --> Input Class Initialized
INFO - 2024-09-08 20:43:16 --> Language Class Initialized
ERROR - 2024-09-08 20:43:16 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-09-08 20:43:54 --> Config Class Initialized
INFO - 2024-09-08 20:43:54 --> Hooks Class Initialized
DEBUG - 2024-09-08 20:43:54 --> UTF-8 Support Enabled
INFO - 2024-09-08 20:43:54 --> Utf8 Class Initialized
INFO - 2024-09-08 20:43:54 --> URI Class Initialized
DEBUG - 2024-09-08 20:43:54 --> No URI present. Default controller set.
INFO - 2024-09-08 20:43:54 --> Router Class Initialized
INFO - 2024-09-08 20:43:54 --> Output Class Initialized
INFO - 2024-09-08 20:43:54 --> Security Class Initialized
DEBUG - 2024-09-08 20:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:43:54 --> Input Class Initialized
INFO - 2024-09-08 20:43:54 --> Language Class Initialized
INFO - 2024-09-08 20:43:54 --> Loader Class Initialized
INFO - 2024-09-08 20:43:54 --> Helper loaded: url_helper
INFO - 2024-09-08 20:43:54 --> Helper loaded: file_helper
INFO - 2024-09-08 20:43:54 --> Helper loaded: security_helper
INFO - 2024-09-08 20:43:54 --> Helper loaded: wpu_helper
INFO - 2024-09-08 20:43:54 --> Database Driver Class Initialized
INFO - 2024-09-08 20:43:55 --> Email Class Initialized
DEBUG - 2024-09-08 20:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 20:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 20:43:55 --> Helper loaded: form_helper
INFO - 2024-09-08 20:43:55 --> Form Validation Class Initialized
INFO - 2024-09-08 20:43:55 --> Controller Class Initialized
DEBUG - 2024-09-08 20:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 20:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 20:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 20:43:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 20:43:55 --> Final output sent to browser
DEBUG - 2024-09-08 20:43:55 --> Total execution time: 0.2199
INFO - 2024-09-08 20:48:11 --> Config Class Initialized
INFO - 2024-09-08 20:48:11 --> Hooks Class Initialized
DEBUG - 2024-09-08 20:48:11 --> UTF-8 Support Enabled
INFO - 2024-09-08 20:48:11 --> Utf8 Class Initialized
INFO - 2024-09-08 20:48:11 --> URI Class Initialized
DEBUG - 2024-09-08 20:48:11 --> No URI present. Default controller set.
INFO - 2024-09-08 20:48:11 --> Router Class Initialized
INFO - 2024-09-08 20:48:11 --> Output Class Initialized
INFO - 2024-09-08 20:48:11 --> Security Class Initialized
DEBUG - 2024-09-08 20:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 20:48:11 --> Input Class Initialized
INFO - 2024-09-08 20:48:11 --> Language Class Initialized
INFO - 2024-09-08 20:48:11 --> Loader Class Initialized
INFO - 2024-09-08 20:48:11 --> Helper loaded: url_helper
INFO - 2024-09-08 20:48:11 --> Helper loaded: file_helper
INFO - 2024-09-08 20:48:11 --> Helper loaded: security_helper
INFO - 2024-09-08 20:48:11 --> Helper loaded: wpu_helper
INFO - 2024-09-08 20:48:11 --> Database Driver Class Initialized
INFO - 2024-09-08 20:48:11 --> Email Class Initialized
DEBUG - 2024-09-08 20:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 20:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 20:48:11 --> Helper loaded: form_helper
INFO - 2024-09-08 20:48:11 --> Form Validation Class Initialized
INFO - 2024-09-08 20:48:11 --> Controller Class Initialized
DEBUG - 2024-09-08 20:48:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 20:48:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 20:48:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 20:48:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 20:48:11 --> Final output sent to browser
DEBUG - 2024-09-08 20:48:11 --> Total execution time: 0.2478
INFO - 2024-09-08 21:15:14 --> Config Class Initialized
INFO - 2024-09-08 21:15:14 --> Hooks Class Initialized
DEBUG - 2024-09-08 21:15:14 --> UTF-8 Support Enabled
INFO - 2024-09-08 21:15:14 --> Utf8 Class Initialized
INFO - 2024-09-08 21:15:14 --> URI Class Initialized
DEBUG - 2024-09-08 21:15:14 --> No URI present. Default controller set.
INFO - 2024-09-08 21:15:14 --> Router Class Initialized
INFO - 2024-09-08 21:15:14 --> Output Class Initialized
INFO - 2024-09-08 21:15:14 --> Security Class Initialized
DEBUG - 2024-09-08 21:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 21:15:14 --> Input Class Initialized
INFO - 2024-09-08 21:15:14 --> Language Class Initialized
INFO - 2024-09-08 21:15:14 --> Loader Class Initialized
INFO - 2024-09-08 21:15:14 --> Helper loaded: url_helper
INFO - 2024-09-08 21:15:14 --> Helper loaded: file_helper
INFO - 2024-09-08 21:15:14 --> Helper loaded: security_helper
INFO - 2024-09-08 21:15:14 --> Helper loaded: wpu_helper
INFO - 2024-09-08 21:15:14 --> Database Driver Class Initialized
INFO - 2024-09-08 21:15:15 --> Email Class Initialized
DEBUG - 2024-09-08 21:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 21:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 21:15:15 --> Helper loaded: form_helper
INFO - 2024-09-08 21:15:15 --> Form Validation Class Initialized
INFO - 2024-09-08 21:15:15 --> Controller Class Initialized
DEBUG - 2024-09-08 21:15:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 21:15:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 21:15:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 21:15:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 21:15:15 --> Final output sent to browser
DEBUG - 2024-09-08 21:15:15 --> Total execution time: 0.5812
INFO - 2024-09-08 21:43:05 --> Config Class Initialized
INFO - 2024-09-08 21:43:05 --> Hooks Class Initialized
DEBUG - 2024-09-08 21:43:05 --> UTF-8 Support Enabled
INFO - 2024-09-08 21:43:05 --> Utf8 Class Initialized
INFO - 2024-09-08 21:43:05 --> URI Class Initialized
DEBUG - 2024-09-08 21:43:05 --> No URI present. Default controller set.
INFO - 2024-09-08 21:43:05 --> Router Class Initialized
INFO - 2024-09-08 21:43:05 --> Output Class Initialized
INFO - 2024-09-08 21:43:05 --> Security Class Initialized
DEBUG - 2024-09-08 21:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 21:43:05 --> Input Class Initialized
INFO - 2024-09-08 21:43:05 --> Language Class Initialized
INFO - 2024-09-08 21:43:05 --> Loader Class Initialized
INFO - 2024-09-08 21:43:05 --> Helper loaded: url_helper
INFO - 2024-09-08 21:43:05 --> Helper loaded: file_helper
INFO - 2024-09-08 21:43:05 --> Helper loaded: security_helper
INFO - 2024-09-08 21:43:05 --> Helper loaded: wpu_helper
INFO - 2024-09-08 21:43:05 --> Database Driver Class Initialized
INFO - 2024-09-08 21:43:05 --> Email Class Initialized
DEBUG - 2024-09-08 21:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 21:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 21:43:05 --> Helper loaded: form_helper
INFO - 2024-09-08 21:43:05 --> Form Validation Class Initialized
INFO - 2024-09-08 21:43:05 --> Controller Class Initialized
DEBUG - 2024-09-08 21:43:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 21:43:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 21:43:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 21:43:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 21:43:05 --> Final output sent to browser
DEBUG - 2024-09-08 21:43:05 --> Total execution time: 0.2322
INFO - 2024-09-08 22:13:45 --> Config Class Initialized
INFO - 2024-09-08 22:13:45 --> Hooks Class Initialized
DEBUG - 2024-09-08 22:13:45 --> UTF-8 Support Enabled
INFO - 2024-09-08 22:13:45 --> Utf8 Class Initialized
INFO - 2024-09-08 22:13:45 --> URI Class Initialized
DEBUG - 2024-09-08 22:13:45 --> No URI present. Default controller set.
INFO - 2024-09-08 22:13:45 --> Router Class Initialized
INFO - 2024-09-08 22:13:45 --> Output Class Initialized
INFO - 2024-09-08 22:13:45 --> Security Class Initialized
DEBUG - 2024-09-08 22:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 22:13:45 --> Input Class Initialized
INFO - 2024-09-08 22:13:45 --> Language Class Initialized
INFO - 2024-09-08 22:13:45 --> Loader Class Initialized
INFO - 2024-09-08 22:13:45 --> Helper loaded: url_helper
INFO - 2024-09-08 22:13:45 --> Helper loaded: file_helper
INFO - 2024-09-08 22:13:45 --> Helper loaded: security_helper
INFO - 2024-09-08 22:13:45 --> Helper loaded: wpu_helper
INFO - 2024-09-08 22:13:45 --> Database Driver Class Initialized
INFO - 2024-09-08 22:13:45 --> Email Class Initialized
DEBUG - 2024-09-08 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 22:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 22:13:45 --> Helper loaded: form_helper
INFO - 2024-09-08 22:13:45 --> Form Validation Class Initialized
INFO - 2024-09-08 22:13:45 --> Controller Class Initialized
DEBUG - 2024-09-08 22:13:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 22:13:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 22:13:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 22:13:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 22:13:45 --> Final output sent to browser
DEBUG - 2024-09-08 22:13:45 --> Total execution time: 0.2124
INFO - 2024-09-08 22:43:50 --> Config Class Initialized
INFO - 2024-09-08 22:43:50 --> Hooks Class Initialized
DEBUG - 2024-09-08 22:43:50 --> UTF-8 Support Enabled
INFO - 2024-09-08 22:43:50 --> Utf8 Class Initialized
INFO - 2024-09-08 22:43:50 --> URI Class Initialized
DEBUG - 2024-09-08 22:43:50 --> No URI present. Default controller set.
INFO - 2024-09-08 22:43:50 --> Router Class Initialized
INFO - 2024-09-08 22:43:50 --> Output Class Initialized
INFO - 2024-09-08 22:43:50 --> Security Class Initialized
DEBUG - 2024-09-08 22:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 22:43:50 --> Input Class Initialized
INFO - 2024-09-08 22:43:50 --> Language Class Initialized
INFO - 2024-09-08 22:43:50 --> Loader Class Initialized
INFO - 2024-09-08 22:43:50 --> Helper loaded: url_helper
INFO - 2024-09-08 22:43:50 --> Helper loaded: file_helper
INFO - 2024-09-08 22:43:50 --> Helper loaded: security_helper
INFO - 2024-09-08 22:43:50 --> Helper loaded: wpu_helper
INFO - 2024-09-08 22:43:50 --> Database Driver Class Initialized
INFO - 2024-09-08 22:43:51 --> Email Class Initialized
DEBUG - 2024-09-08 22:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 22:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 22:43:51 --> Helper loaded: form_helper
INFO - 2024-09-08 22:43:51 --> Form Validation Class Initialized
INFO - 2024-09-08 22:43:51 --> Controller Class Initialized
DEBUG - 2024-09-08 22:43:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 22:43:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 22:43:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 22:43:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 22:43:51 --> Final output sent to browser
DEBUG - 2024-09-08 22:43:51 --> Total execution time: 0.2240
INFO - 2024-09-08 23:15:12 --> Config Class Initialized
INFO - 2024-09-08 23:15:12 --> Hooks Class Initialized
DEBUG - 2024-09-08 23:15:12 --> UTF-8 Support Enabled
INFO - 2024-09-08 23:15:12 --> Utf8 Class Initialized
INFO - 2024-09-08 23:15:12 --> URI Class Initialized
DEBUG - 2024-09-08 23:15:12 --> No URI present. Default controller set.
INFO - 2024-09-08 23:15:12 --> Router Class Initialized
INFO - 2024-09-08 23:15:12 --> Output Class Initialized
INFO - 2024-09-08 23:15:12 --> Security Class Initialized
DEBUG - 2024-09-08 23:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 23:15:12 --> Input Class Initialized
INFO - 2024-09-08 23:15:12 --> Language Class Initialized
INFO - 2024-09-08 23:15:12 --> Loader Class Initialized
INFO - 2024-09-08 23:15:12 --> Helper loaded: url_helper
INFO - 2024-09-08 23:15:12 --> Helper loaded: file_helper
INFO - 2024-09-08 23:15:12 --> Helper loaded: security_helper
INFO - 2024-09-08 23:15:12 --> Helper loaded: wpu_helper
INFO - 2024-09-08 23:15:12 --> Database Driver Class Initialized
INFO - 2024-09-08 23:15:12 --> Email Class Initialized
DEBUG - 2024-09-08 23:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 23:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 23:15:12 --> Helper loaded: form_helper
INFO - 2024-09-08 23:15:12 --> Form Validation Class Initialized
INFO - 2024-09-08 23:15:12 --> Controller Class Initialized
DEBUG - 2024-09-08 23:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 23:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 23:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 23:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 23:15:12 --> Final output sent to browser
DEBUG - 2024-09-08 23:15:12 --> Total execution time: 0.2153
INFO - 2024-09-08 23:41:04 --> Config Class Initialized
INFO - 2024-09-08 23:41:04 --> Hooks Class Initialized
DEBUG - 2024-09-08 23:41:04 --> UTF-8 Support Enabled
INFO - 2024-09-08 23:41:04 --> Utf8 Class Initialized
INFO - 2024-09-08 23:41:04 --> URI Class Initialized
DEBUG - 2024-09-08 23:41:04 --> No URI present. Default controller set.
INFO - 2024-09-08 23:41:04 --> Router Class Initialized
INFO - 2024-09-08 23:41:04 --> Output Class Initialized
INFO - 2024-09-08 23:41:04 --> Security Class Initialized
DEBUG - 2024-09-08 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 23:41:04 --> Input Class Initialized
INFO - 2024-09-08 23:41:04 --> Language Class Initialized
INFO - 2024-09-08 23:41:04 --> Loader Class Initialized
INFO - 2024-09-08 23:41:04 --> Helper loaded: url_helper
INFO - 2024-09-08 23:41:04 --> Helper loaded: file_helper
INFO - 2024-09-08 23:41:04 --> Helper loaded: security_helper
INFO - 2024-09-08 23:41:04 --> Helper loaded: wpu_helper
INFO - 2024-09-08 23:41:04 --> Database Driver Class Initialized
INFO - 2024-09-08 23:41:04 --> Email Class Initialized
DEBUG - 2024-09-08 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 23:41:04 --> Helper loaded: form_helper
INFO - 2024-09-08 23:41:04 --> Form Validation Class Initialized
INFO - 2024-09-08 23:41:04 --> Controller Class Initialized
DEBUG - 2024-09-08 23:41:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 23:41:04 --> Final output sent to browser
DEBUG - 2024-09-08 23:41:04 --> Total execution time: 0.2303
INFO - 2024-09-08 23:44:08 --> Config Class Initialized
INFO - 2024-09-08 23:44:08 --> Hooks Class Initialized
DEBUG - 2024-09-08 23:44:08 --> UTF-8 Support Enabled
INFO - 2024-09-08 23:44:08 --> Utf8 Class Initialized
INFO - 2024-09-08 23:44:08 --> URI Class Initialized
DEBUG - 2024-09-08 23:44:08 --> No URI present. Default controller set.
INFO - 2024-09-08 23:44:08 --> Router Class Initialized
INFO - 2024-09-08 23:44:08 --> Output Class Initialized
INFO - 2024-09-08 23:44:08 --> Security Class Initialized
DEBUG - 2024-09-08 23:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 23:44:08 --> Input Class Initialized
INFO - 2024-09-08 23:44:08 --> Language Class Initialized
INFO - 2024-09-08 23:44:08 --> Loader Class Initialized
INFO - 2024-09-08 23:44:08 --> Helper loaded: url_helper
INFO - 2024-09-08 23:44:08 --> Helper loaded: file_helper
INFO - 2024-09-08 23:44:08 --> Helper loaded: security_helper
INFO - 2024-09-08 23:44:08 --> Helper loaded: wpu_helper
INFO - 2024-09-08 23:44:08 --> Database Driver Class Initialized
INFO - 2024-09-08 23:44:08 --> Email Class Initialized
DEBUG - 2024-09-08 23:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-08 23:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 23:44:08 --> Helper loaded: form_helper
INFO - 2024-09-08 23:44:08 --> Form Validation Class Initialized
INFO - 2024-09-08 23:44:08 --> Controller Class Initialized
DEBUG - 2024-09-08 23:44:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-08 23:44:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-08 23:44:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-08 23:44:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-08 23:44:08 --> Final output sent to browser
DEBUG - 2024-09-08 23:44:08 --> Total execution time: 0.2354
