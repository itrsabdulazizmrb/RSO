<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-04 01:35:13 --> Config Class Initialized
INFO - 2024-10-04 01:35:13 --> Hooks Class Initialized
DEBUG - 2024-10-04 01:35:13 --> UTF-8 Support Enabled
INFO - 2024-10-04 01:35:13 --> Utf8 Class Initialized
INFO - 2024-10-04 01:35:13 --> URI Class Initialized
DEBUG - 2024-10-04 01:35:13 --> No URI present. Default controller set.
INFO - 2024-10-04 01:35:13 --> Router Class Initialized
INFO - 2024-10-04 01:35:13 --> Output Class Initialized
INFO - 2024-10-04 01:35:13 --> Security Class Initialized
DEBUG - 2024-10-04 01:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 01:35:13 --> Input Class Initialized
INFO - 2024-10-04 01:35:13 --> Language Class Initialized
INFO - 2024-10-04 01:35:13 --> Loader Class Initialized
INFO - 2024-10-04 01:35:13 --> Helper loaded: url_helper
INFO - 2024-10-04 01:35:13 --> Helper loaded: file_helper
INFO - 2024-10-04 01:35:13 --> Helper loaded: security_helper
INFO - 2024-10-04 01:35:13 --> Helper loaded: wpu_helper
INFO - 2024-10-04 01:35:13 --> Database Driver Class Initialized
INFO - 2024-10-04 01:35:13 --> Email Class Initialized
DEBUG - 2024-10-04 01:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 01:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 01:35:13 --> Helper loaded: form_helper
INFO - 2024-10-04 01:35:13 --> Form Validation Class Initialized
INFO - 2024-10-04 01:35:13 --> Controller Class Initialized
DEBUG - 2024-10-04 01:35:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 01:35:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 01:35:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 01:35:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 01:35:13 --> Final output sent to browser
DEBUG - 2024-10-04 01:35:13 --> Total execution time: 0.2393
INFO - 2024-10-04 05:57:14 --> Config Class Initialized
INFO - 2024-10-04 05:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:57:14 --> Utf8 Class Initialized
INFO - 2024-10-04 05:57:14 --> URI Class Initialized
DEBUG - 2024-10-04 05:57:14 --> No URI present. Default controller set.
INFO - 2024-10-04 05:57:14 --> Router Class Initialized
INFO - 2024-10-04 05:57:14 --> Output Class Initialized
INFO - 2024-10-04 05:57:14 --> Security Class Initialized
DEBUG - 2024-10-04 05:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:57:14 --> Input Class Initialized
INFO - 2024-10-04 05:57:14 --> Language Class Initialized
INFO - 2024-10-04 05:57:14 --> Loader Class Initialized
INFO - 2024-10-04 05:57:14 --> Helper loaded: url_helper
INFO - 2024-10-04 05:57:14 --> Helper loaded: file_helper
INFO - 2024-10-04 05:57:14 --> Helper loaded: security_helper
INFO - 2024-10-04 05:57:14 --> Helper loaded: wpu_helper
INFO - 2024-10-04 05:57:14 --> Database Driver Class Initialized
INFO - 2024-10-04 05:57:15 --> Email Class Initialized
DEBUG - 2024-10-04 05:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 05:57:15 --> Helper loaded: form_helper
INFO - 2024-10-04 05:57:15 --> Form Validation Class Initialized
INFO - 2024-10-04 05:57:15 --> Controller Class Initialized
DEBUG - 2024-10-04 05:57:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 05:57:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 05:57:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 05:57:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 05:57:15 --> Final output sent to browser
DEBUG - 2024-10-04 05:57:15 --> Total execution time: 0.2484
INFO - 2024-10-04 05:57:39 --> Config Class Initialized
INFO - 2024-10-04 05:57:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:57:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:57:39 --> Utf8 Class Initialized
INFO - 2024-10-04 05:57:39 --> URI Class Initialized
INFO - 2024-10-04 05:57:39 --> Router Class Initialized
INFO - 2024-10-04 05:57:39 --> Output Class Initialized
INFO - 2024-10-04 05:57:39 --> Security Class Initialized
DEBUG - 2024-10-04 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:57:39 --> Input Class Initialized
INFO - 2024-10-04 05:57:39 --> Language Class Initialized
ERROR - 2024-10-04 05:57:39 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:57:40 --> Config Class Initialized
INFO - 2024-10-04 05:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:57:40 --> Utf8 Class Initialized
INFO - 2024-10-04 05:57:40 --> URI Class Initialized
INFO - 2024-10-04 05:57:40 --> Router Class Initialized
INFO - 2024-10-04 05:57:40 --> Output Class Initialized
INFO - 2024-10-04 05:57:40 --> Security Class Initialized
DEBUG - 2024-10-04 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:57:40 --> Input Class Initialized
INFO - 2024-10-04 05:57:40 --> Language Class Initialized
ERROR - 2024-10-04 05:57:40 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:57:47 --> Config Class Initialized
INFO - 2024-10-04 05:57:47 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:57:47 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:57:47 --> Utf8 Class Initialized
INFO - 2024-10-04 05:57:47 --> URI Class Initialized
INFO - 2024-10-04 05:57:47 --> Router Class Initialized
INFO - 2024-10-04 05:57:47 --> Output Class Initialized
INFO - 2024-10-04 05:57:47 --> Security Class Initialized
DEBUG - 2024-10-04 05:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:57:47 --> Input Class Initialized
INFO - 2024-10-04 05:57:47 --> Language Class Initialized
ERROR - 2024-10-04 05:57:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:58:30 --> Config Class Initialized
INFO - 2024-10-04 05:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:58:30 --> Utf8 Class Initialized
INFO - 2024-10-04 05:58:30 --> URI Class Initialized
INFO - 2024-10-04 05:58:30 --> Router Class Initialized
INFO - 2024-10-04 05:58:30 --> Output Class Initialized
INFO - 2024-10-04 05:58:30 --> Security Class Initialized
DEBUG - 2024-10-04 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:58:30 --> Input Class Initialized
INFO - 2024-10-04 05:58:30 --> Language Class Initialized
ERROR - 2024-10-04 05:58:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:58:30 --> Config Class Initialized
INFO - 2024-10-04 05:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:58:30 --> Utf8 Class Initialized
INFO - 2024-10-04 05:58:30 --> URI Class Initialized
INFO - 2024-10-04 05:58:30 --> Router Class Initialized
INFO - 2024-10-04 05:58:30 --> Output Class Initialized
INFO - 2024-10-04 05:58:30 --> Security Class Initialized
DEBUG - 2024-10-04 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:58:30 --> Input Class Initialized
INFO - 2024-10-04 05:58:30 --> Language Class Initialized
ERROR - 2024-10-04 05:58:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:58:30 --> Config Class Initialized
INFO - 2024-10-04 05:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:58:30 --> Utf8 Class Initialized
INFO - 2024-10-04 05:58:30 --> URI Class Initialized
INFO - 2024-10-04 05:58:30 --> Router Class Initialized
INFO - 2024-10-04 05:58:30 --> Output Class Initialized
INFO - 2024-10-04 05:58:30 --> Security Class Initialized
DEBUG - 2024-10-04 05:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:58:30 --> Input Class Initialized
INFO - 2024-10-04 05:58:30 --> Language Class Initialized
ERROR - 2024-10-04 05:58:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 05:58:32 --> Config Class Initialized
INFO - 2024-10-04 05:58:32 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:58:32 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:58:32 --> Utf8 Class Initialized
INFO - 2024-10-04 05:58:32 --> URI Class Initialized
INFO - 2024-10-04 05:58:32 --> Router Class Initialized
INFO - 2024-10-04 05:58:32 --> Output Class Initialized
INFO - 2024-10-04 05:58:32 --> Security Class Initialized
DEBUG - 2024-10-04 05:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:58:32 --> Input Class Initialized
INFO - 2024-10-04 05:58:32 --> Language Class Initialized
ERROR - 2024-10-04 05:58:32 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-04 05:58:33 --> Config Class Initialized
INFO - 2024-10-04 05:58:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 05:58:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 05:58:33 --> Utf8 Class Initialized
INFO - 2024-10-04 05:58:33 --> URI Class Initialized
INFO - 2024-10-04 05:58:33 --> Router Class Initialized
INFO - 2024-10-04 05:58:33 --> Output Class Initialized
INFO - 2024-10-04 05:58:33 --> Security Class Initialized
DEBUG - 2024-10-04 05:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 05:58:33 --> Input Class Initialized
INFO - 2024-10-04 05:58:33 --> Language Class Initialized
ERROR - 2024-10-04 05:58:33 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-04 07:55:58 --> Config Class Initialized
INFO - 2024-10-04 07:55:58 --> Hooks Class Initialized
DEBUG - 2024-10-04 07:55:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 07:55:58 --> Utf8 Class Initialized
INFO - 2024-10-04 07:55:58 --> URI Class Initialized
DEBUG - 2024-10-04 07:55:58 --> No URI present. Default controller set.
INFO - 2024-10-04 07:55:58 --> Router Class Initialized
INFO - 2024-10-04 07:55:58 --> Output Class Initialized
INFO - 2024-10-04 07:55:58 --> Security Class Initialized
DEBUG - 2024-10-04 07:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 07:55:58 --> Input Class Initialized
INFO - 2024-10-04 07:55:58 --> Language Class Initialized
INFO - 2024-10-04 07:55:58 --> Loader Class Initialized
INFO - 2024-10-04 07:55:58 --> Helper loaded: url_helper
INFO - 2024-10-04 07:55:58 --> Helper loaded: file_helper
INFO - 2024-10-04 07:55:58 --> Helper loaded: security_helper
INFO - 2024-10-04 07:55:58 --> Helper loaded: wpu_helper
INFO - 2024-10-04 07:55:58 --> Database Driver Class Initialized
INFO - 2024-10-04 07:55:58 --> Email Class Initialized
DEBUG - 2024-10-04 07:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 07:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 07:55:58 --> Helper loaded: form_helper
INFO - 2024-10-04 07:55:58 --> Form Validation Class Initialized
INFO - 2024-10-04 07:55:58 --> Controller Class Initialized
DEBUG - 2024-10-04 07:55:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 07:55:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 07:55:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 07:55:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 07:55:58 --> Final output sent to browser
DEBUG - 2024-10-04 07:55:58 --> Total execution time: 0.2227
INFO - 2024-10-04 07:55:59 --> Config Class Initialized
INFO - 2024-10-04 07:55:59 --> Hooks Class Initialized
DEBUG - 2024-10-04 07:55:59 --> UTF-8 Support Enabled
INFO - 2024-10-04 07:55:59 --> Utf8 Class Initialized
INFO - 2024-10-04 07:55:59 --> URI Class Initialized
DEBUG - 2024-10-04 07:55:59 --> No URI present. Default controller set.
INFO - 2024-10-04 07:55:59 --> Router Class Initialized
INFO - 2024-10-04 07:55:59 --> Output Class Initialized
INFO - 2024-10-04 07:55:59 --> Security Class Initialized
DEBUG - 2024-10-04 07:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 07:55:59 --> Input Class Initialized
INFO - 2024-10-04 07:55:59 --> Language Class Initialized
INFO - 2024-10-04 07:55:59 --> Loader Class Initialized
INFO - 2024-10-04 07:55:59 --> Helper loaded: url_helper
INFO - 2024-10-04 07:55:59 --> Helper loaded: file_helper
INFO - 2024-10-04 07:55:59 --> Helper loaded: security_helper
INFO - 2024-10-04 07:55:59 --> Helper loaded: wpu_helper
INFO - 2024-10-04 07:55:59 --> Database Driver Class Initialized
INFO - 2024-10-04 07:56:00 --> Email Class Initialized
DEBUG - 2024-10-04 07:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 07:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 07:56:00 --> Helper loaded: form_helper
INFO - 2024-10-04 07:56:00 --> Form Validation Class Initialized
INFO - 2024-10-04 07:56:00 --> Controller Class Initialized
DEBUG - 2024-10-04 07:56:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 07:56:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 07:56:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 07:56:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 07:56:00 --> Final output sent to browser
DEBUG - 2024-10-04 07:56:00 --> Total execution time: 0.2220
INFO - 2024-10-04 09:06:47 --> Config Class Initialized
INFO - 2024-10-04 09:06:47 --> Hooks Class Initialized
DEBUG - 2024-10-04 09:06:47 --> UTF-8 Support Enabled
INFO - 2024-10-04 09:06:47 --> Utf8 Class Initialized
INFO - 2024-10-04 09:06:47 --> URI Class Initialized
DEBUG - 2024-10-04 09:06:47 --> No URI present. Default controller set.
INFO - 2024-10-04 09:06:47 --> Router Class Initialized
INFO - 2024-10-04 09:06:47 --> Output Class Initialized
INFO - 2024-10-04 09:06:47 --> Security Class Initialized
DEBUG - 2024-10-04 09:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 09:06:47 --> Input Class Initialized
INFO - 2024-10-04 09:06:47 --> Language Class Initialized
INFO - 2024-10-04 09:06:47 --> Loader Class Initialized
INFO - 2024-10-04 09:06:47 --> Helper loaded: url_helper
INFO - 2024-10-04 09:06:47 --> Helper loaded: file_helper
INFO - 2024-10-04 09:06:47 --> Helper loaded: security_helper
INFO - 2024-10-04 09:06:47 --> Helper loaded: wpu_helper
INFO - 2024-10-04 09:06:47 --> Database Driver Class Initialized
INFO - 2024-10-04 09:06:47 --> Email Class Initialized
DEBUG - 2024-10-04 09:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 09:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 09:06:47 --> Helper loaded: form_helper
INFO - 2024-10-04 09:06:47 --> Form Validation Class Initialized
INFO - 2024-10-04 09:06:47 --> Controller Class Initialized
DEBUG - 2024-10-04 09:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 09:06:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 09:06:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 09:06:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 09:06:47 --> Final output sent to browser
DEBUG - 2024-10-04 09:06:47 --> Total execution time: 0.2428
INFO - 2024-10-04 12:35:46 --> Config Class Initialized
INFO - 2024-10-04 12:35:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 12:35:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 12:35:46 --> Utf8 Class Initialized
INFO - 2024-10-04 12:35:46 --> URI Class Initialized
DEBUG - 2024-10-04 12:35:46 --> No URI present. Default controller set.
INFO - 2024-10-04 12:35:46 --> Router Class Initialized
INFO - 2024-10-04 12:35:46 --> Output Class Initialized
INFO - 2024-10-04 12:35:46 --> Security Class Initialized
DEBUG - 2024-10-04 12:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 12:35:46 --> Input Class Initialized
INFO - 2024-10-04 12:35:46 --> Language Class Initialized
INFO - 2024-10-04 12:35:46 --> Loader Class Initialized
INFO - 2024-10-04 12:35:46 --> Helper loaded: url_helper
INFO - 2024-10-04 12:35:46 --> Helper loaded: file_helper
INFO - 2024-10-04 12:35:46 --> Helper loaded: security_helper
INFO - 2024-10-04 12:35:46 --> Helper loaded: wpu_helper
INFO - 2024-10-04 12:35:46 --> Database Driver Class Initialized
INFO - 2024-10-04 12:35:47 --> Email Class Initialized
DEBUG - 2024-10-04 12:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 12:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 12:35:47 --> Helper loaded: form_helper
INFO - 2024-10-04 12:35:47 --> Form Validation Class Initialized
INFO - 2024-10-04 12:35:47 --> Controller Class Initialized
DEBUG - 2024-10-04 12:35:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 12:35:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 12:35:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 12:35:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 12:35:47 --> Final output sent to browser
DEBUG - 2024-10-04 12:35:47 --> Total execution time: 0.2312
INFO - 2024-10-04 19:23:52 --> Config Class Initialized
INFO - 2024-10-04 19:23:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 19:23:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 19:23:52 --> Utf8 Class Initialized
INFO - 2024-10-04 19:23:52 --> URI Class Initialized
DEBUG - 2024-10-04 19:23:52 --> No URI present. Default controller set.
INFO - 2024-10-04 19:23:52 --> Router Class Initialized
INFO - 2024-10-04 19:23:52 --> Output Class Initialized
INFO - 2024-10-04 19:23:52 --> Security Class Initialized
DEBUG - 2024-10-04 19:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 19:23:52 --> Input Class Initialized
INFO - 2024-10-04 19:23:52 --> Language Class Initialized
INFO - 2024-10-04 19:23:52 --> Loader Class Initialized
INFO - 2024-10-04 19:23:52 --> Helper loaded: url_helper
INFO - 2024-10-04 19:23:52 --> Helper loaded: file_helper
INFO - 2024-10-04 19:23:52 --> Helper loaded: security_helper
INFO - 2024-10-04 19:23:52 --> Helper loaded: wpu_helper
INFO - 2024-10-04 19:23:52 --> Database Driver Class Initialized
INFO - 2024-10-04 19:23:52 --> Email Class Initialized
DEBUG - 2024-10-04 19:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 19:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 19:23:52 --> Helper loaded: form_helper
INFO - 2024-10-04 19:23:52 --> Form Validation Class Initialized
INFO - 2024-10-04 19:23:52 --> Controller Class Initialized
DEBUG - 2024-10-04 19:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 19:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-04 19:23:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 19:23:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 19:23:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 19:23:52 --> Final output sent to browser
DEBUG - 2024-10-04 19:23:52 --> Total execution time: 0.2183
INFO - 2024-10-04 19:24:04 --> Config Class Initialized
INFO - 2024-10-04 19:24:04 --> Hooks Class Initialized
DEBUG - 2024-10-04 19:24:04 --> UTF-8 Support Enabled
INFO - 2024-10-04 19:24:04 --> Utf8 Class Initialized
INFO - 2024-10-04 19:24:04 --> URI Class Initialized
DEBUG - 2024-10-04 19:24:04 --> No URI present. Default controller set.
INFO - 2024-10-04 19:24:04 --> Router Class Initialized
INFO - 2024-10-04 19:24:04 --> Output Class Initialized
INFO - 2024-10-04 19:24:04 --> Security Class Initialized
DEBUG - 2024-10-04 19:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 19:24:04 --> Input Class Initialized
INFO - 2024-10-04 19:24:04 --> Language Class Initialized
INFO - 2024-10-04 19:24:04 --> Loader Class Initialized
INFO - 2024-10-04 19:24:04 --> Helper loaded: url_helper
INFO - 2024-10-04 19:24:04 --> Helper loaded: file_helper
INFO - 2024-10-04 19:24:04 --> Helper loaded: security_helper
INFO - 2024-10-04 19:24:04 --> Helper loaded: wpu_helper
INFO - 2024-10-04 19:24:04 --> Database Driver Class Initialized
INFO - 2024-10-04 19:24:04 --> Email Class Initialized
DEBUG - 2024-10-04 19:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 19:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 19:24:04 --> Helper loaded: form_helper
INFO - 2024-10-04 19:24:04 --> Form Validation Class Initialized
INFO - 2024-10-04 19:24:04 --> Controller Class Initialized
DEBUG - 2024-10-04 19:24:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 19:24:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 19:24:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 19:24:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 19:24:04 --> Final output sent to browser
DEBUG - 2024-10-04 19:24:04 --> Total execution time: 0.2225
INFO - 2024-10-04 19:24:24 --> Config Class Initialized
INFO - 2024-10-04 19:24:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 19:24:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 19:24:24 --> Utf8 Class Initialized
INFO - 2024-10-04 19:24:24 --> URI Class Initialized
DEBUG - 2024-10-04 19:24:24 --> No URI present. Default controller set.
INFO - 2024-10-04 19:24:24 --> Router Class Initialized
INFO - 2024-10-04 19:24:24 --> Output Class Initialized
INFO - 2024-10-04 19:24:24 --> Security Class Initialized
DEBUG - 2024-10-04 19:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 19:24:24 --> Input Class Initialized
INFO - 2024-10-04 19:24:24 --> Language Class Initialized
INFO - 2024-10-04 19:24:24 --> Loader Class Initialized
INFO - 2024-10-04 19:24:24 --> Helper loaded: url_helper
INFO - 2024-10-04 19:24:24 --> Helper loaded: file_helper
INFO - 2024-10-04 19:24:24 --> Helper loaded: security_helper
INFO - 2024-10-04 19:24:24 --> Helper loaded: wpu_helper
INFO - 2024-10-04 19:24:24 --> Database Driver Class Initialized
INFO - 2024-10-04 19:24:24 --> Email Class Initialized
DEBUG - 2024-10-04 19:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 19:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 19:24:24 --> Helper loaded: form_helper
INFO - 2024-10-04 19:24:24 --> Form Validation Class Initialized
INFO - 2024-10-04 19:24:24 --> Controller Class Initialized
DEBUG - 2024-10-04 19:24:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 19:24:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 19:24:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 19:24:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 19:24:24 --> Final output sent to browser
DEBUG - 2024-10-04 19:24:24 --> Total execution time: 0.2222
INFO - 2024-10-04 23:22:12 --> Config Class Initialized
INFO - 2024-10-04 23:22:12 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:12 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:12 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:12 --> URI Class Initialized
DEBUG - 2024-10-04 23:22:12 --> No URI present. Default controller set.
INFO - 2024-10-04 23:22:12 --> Router Class Initialized
INFO - 2024-10-04 23:22:12 --> Output Class Initialized
INFO - 2024-10-04 23:22:12 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:12 --> Input Class Initialized
INFO - 2024-10-04 23:22:12 --> Language Class Initialized
INFO - 2024-10-04 23:22:12 --> Loader Class Initialized
INFO - 2024-10-04 23:22:12 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:12 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:12 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:12 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:12 --> Database Driver Class Initialized
INFO - 2024-10-04 23:22:12 --> Email Class Initialized
DEBUG - 2024-10-04 23:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 23:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 23:22:12 --> Helper loaded: form_helper
INFO - 2024-10-04 23:22:12 --> Form Validation Class Initialized
INFO - 2024-10-04 23:22:12 --> Controller Class Initialized
DEBUG - 2024-10-04 23:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 23:22:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-04 23:22:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-04 23:22:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-04 23:22:12 --> Final output sent to browser
DEBUG - 2024-10-04 23:22:12 --> Total execution time: 0.2441
INFO - 2024-10-04 23:22:14 --> Config Class Initialized
INFO - 2024-10-04 23:22:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:14 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:14 --> URI Class Initialized
INFO - 2024-10-04 23:22:14 --> Router Class Initialized
INFO - 2024-10-04 23:22:14 --> Output Class Initialized
INFO - 2024-10-04 23:22:14 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:14 --> Input Class Initialized
INFO - 2024-10-04 23:22:14 --> Language Class Initialized
INFO - 2024-10-04 23:22:14 --> Loader Class Initialized
INFO - 2024-10-04 23:22:14 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:14 --> Database Driver Class Initialized
INFO - 2024-10-04 23:22:14 --> Email Class Initialized
DEBUG - 2024-10-04 23:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 23:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 23:22:14 --> Helper loaded: form_helper
INFO - 2024-10-04 23:22:14 --> Form Validation Class Initialized
INFO - 2024-10-04 23:22:14 --> Controller Class Initialized
DEBUG - 2024-10-04 23:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 23:22:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-04 23:22:14 --> Config Class Initialized
INFO - 2024-10-04 23:22:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:14 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:14 --> URI Class Initialized
INFO - 2024-10-04 23:22:14 --> Router Class Initialized
INFO - 2024-10-04 23:22:14 --> Output Class Initialized
INFO - 2024-10-04 23:22:14 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:14 --> Input Class Initialized
INFO - 2024-10-04 23:22:14 --> Language Class Initialized
INFO - 2024-10-04 23:22:14 --> Loader Class Initialized
INFO - 2024-10-04 23:22:14 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:14 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:14 --> Database Driver Class Initialized
INFO - 2024-10-04 23:22:15 --> Email Class Initialized
DEBUG - 2024-10-04 23:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 23:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 23:22:15 --> Helper loaded: form_helper
INFO - 2024-10-04 23:22:15 --> Form Validation Class Initialized
INFO - 2024-10-04 23:22:15 --> Controller Class Initialized
INFO - 2024-10-04 23:22:15 --> Model "Antrol_model" initialized
DEBUG - 2024-10-04 23:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 23:22:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-04 23:22:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-04 23:22:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-04 23:22:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-04 23:22:15 --> Final output sent to browser
DEBUG - 2024-10-04 23:22:15 --> Total execution time: 0.5402
INFO - 2024-10-04 23:22:29 --> Config Class Initialized
INFO - 2024-10-04 23:22:29 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:29 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:29 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:29 --> URI Class Initialized
INFO - 2024-10-04 23:22:29 --> Router Class Initialized
INFO - 2024-10-04 23:22:29 --> Output Class Initialized
INFO - 2024-10-04 23:22:29 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:29 --> Input Class Initialized
INFO - 2024-10-04 23:22:29 --> Language Class Initialized
INFO - 2024-10-04 23:22:29 --> Loader Class Initialized
INFO - 2024-10-04 23:22:29 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:29 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:29 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:29 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:29 --> Database Driver Class Initialized
ERROR - 2024-10-04 23:22:29 --> Unable to connect to the database
INFO - 2024-10-04 23:22:29 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-04 23:22:32 --> Config Class Initialized
INFO - 2024-10-04 23:22:32 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:32 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:32 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:32 --> URI Class Initialized
INFO - 2024-10-04 23:22:32 --> Router Class Initialized
INFO - 2024-10-04 23:22:32 --> Output Class Initialized
INFO - 2024-10-04 23:22:32 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:32 --> Input Class Initialized
INFO - 2024-10-04 23:22:32 --> Language Class Initialized
INFO - 2024-10-04 23:22:32 --> Loader Class Initialized
INFO - 2024-10-04 23:22:32 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:32 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:32 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:32 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:32 --> Database Driver Class Initialized
INFO - 2024-10-04 23:22:32 --> Email Class Initialized
DEBUG - 2024-10-04 23:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 23:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 23:22:32 --> Helper loaded: form_helper
INFO - 2024-10-04 23:22:32 --> Form Validation Class Initialized
INFO - 2024-10-04 23:22:32 --> Controller Class Initialized
INFO - 2024-10-04 23:22:32 --> Model "Antrol_model" initialized
DEBUG - 2024-10-04 23:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 23:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-04 23:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-04 23:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-04 23:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-04 23:22:32 --> Final output sent to browser
DEBUG - 2024-10-04 23:22:32 --> Total execution time: 0.5129
INFO - 2024-10-04 23:22:54 --> Config Class Initialized
INFO - 2024-10-04 23:22:54 --> Hooks Class Initialized
DEBUG - 2024-10-04 23:22:54 --> UTF-8 Support Enabled
INFO - 2024-10-04 23:22:54 --> Utf8 Class Initialized
INFO - 2024-10-04 23:22:54 --> URI Class Initialized
INFO - 2024-10-04 23:22:54 --> Router Class Initialized
INFO - 2024-10-04 23:22:54 --> Output Class Initialized
INFO - 2024-10-04 23:22:54 --> Security Class Initialized
DEBUG - 2024-10-04 23:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 23:22:54 --> Input Class Initialized
INFO - 2024-10-04 23:22:54 --> Language Class Initialized
INFO - 2024-10-04 23:22:54 --> Loader Class Initialized
INFO - 2024-10-04 23:22:54 --> Helper loaded: url_helper
INFO - 2024-10-04 23:22:54 --> Helper loaded: file_helper
INFO - 2024-10-04 23:22:54 --> Helper loaded: security_helper
INFO - 2024-10-04 23:22:54 --> Helper loaded: wpu_helper
INFO - 2024-10-04 23:22:54 --> Database Driver Class Initialized
INFO - 2024-10-04 23:22:54 --> Email Class Initialized
DEBUG - 2024-10-04 23:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-04 23:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 23:22:54 --> Helper loaded: form_helper
INFO - 2024-10-04 23:22:54 --> Form Validation Class Initialized
INFO - 2024-10-04 23:22:54 --> Controller Class Initialized
INFO - 2024-10-04 23:22:54 --> Model "Antrol_model" initialized
DEBUG - 2024-10-04 23:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-04 23:22:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-04 23:22:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-04 23:22:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-04 23:22:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-04 23:22:55 --> Final output sent to browser
DEBUG - 2024-10-04 23:22:55 --> Total execution time: 0.6001
