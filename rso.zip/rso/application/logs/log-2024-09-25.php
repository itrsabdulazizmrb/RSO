<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-25 00:55:13 --> Config Class Initialized
INFO - 2024-09-25 00:55:13 --> Hooks Class Initialized
DEBUG - 2024-09-25 00:55:13 --> UTF-8 Support Enabled
INFO - 2024-09-25 00:55:13 --> Utf8 Class Initialized
INFO - 2024-09-25 00:55:13 --> URI Class Initialized
DEBUG - 2024-09-25 00:55:13 --> No URI present. Default controller set.
INFO - 2024-09-25 00:55:13 --> Router Class Initialized
INFO - 2024-09-25 00:55:13 --> Output Class Initialized
INFO - 2024-09-25 00:55:13 --> Security Class Initialized
DEBUG - 2024-09-25 00:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 00:55:13 --> Input Class Initialized
INFO - 2024-09-25 00:55:13 --> Language Class Initialized
INFO - 2024-09-25 00:55:13 --> Loader Class Initialized
INFO - 2024-09-25 00:55:13 --> Helper loaded: url_helper
INFO - 2024-09-25 00:55:13 --> Helper loaded: file_helper
INFO - 2024-09-25 00:55:13 --> Helper loaded: security_helper
INFO - 2024-09-25 00:55:13 --> Helper loaded: wpu_helper
INFO - 2024-09-25 00:55:13 --> Database Driver Class Initialized
INFO - 2024-09-25 00:56:23 --> Config Class Initialized
INFO - 2024-09-25 00:56:23 --> Hooks Class Initialized
DEBUG - 2024-09-25 00:56:23 --> UTF-8 Support Enabled
INFO - 2024-09-25 00:56:23 --> Utf8 Class Initialized
INFO - 2024-09-25 00:56:23 --> URI Class Initialized
DEBUG - 2024-09-25 00:56:23 --> No URI present. Default controller set.
INFO - 2024-09-25 00:56:23 --> Router Class Initialized
INFO - 2024-09-25 00:56:23 --> Output Class Initialized
INFO - 2024-09-25 00:56:23 --> Security Class Initialized
DEBUG - 2024-09-25 00:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 00:56:23 --> Input Class Initialized
INFO - 2024-09-25 00:56:23 --> Language Class Initialized
INFO - 2024-09-25 00:56:23 --> Loader Class Initialized
INFO - 2024-09-25 00:56:23 --> Helper loaded: url_helper
INFO - 2024-09-25 00:56:23 --> Helper loaded: file_helper
INFO - 2024-09-25 00:56:23 --> Helper loaded: security_helper
INFO - 2024-09-25 00:56:23 --> Helper loaded: wpu_helper
INFO - 2024-09-25 00:56:23 --> Database Driver Class Initialized
INFO - 2024-09-25 04:21:13 --> Config Class Initialized
INFO - 2024-09-25 04:21:13 --> Hooks Class Initialized
DEBUG - 2024-09-25 04:21:13 --> UTF-8 Support Enabled
INFO - 2024-09-25 04:21:13 --> Utf8 Class Initialized
INFO - 2024-09-25 04:21:13 --> URI Class Initialized
DEBUG - 2024-09-25 04:21:13 --> No URI present. Default controller set.
INFO - 2024-09-25 04:21:13 --> Router Class Initialized
INFO - 2024-09-25 04:21:13 --> Output Class Initialized
INFO - 2024-09-25 04:21:13 --> Security Class Initialized
DEBUG - 2024-09-25 04:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 04:21:13 --> Input Class Initialized
INFO - 2024-09-25 04:21:13 --> Language Class Initialized
INFO - 2024-09-25 04:21:13 --> Loader Class Initialized
INFO - 2024-09-25 04:21:13 --> Helper loaded: url_helper
INFO - 2024-09-25 04:21:13 --> Helper loaded: file_helper
INFO - 2024-09-25 04:21:13 --> Helper loaded: security_helper
INFO - 2024-09-25 04:21:13 --> Helper loaded: wpu_helper
INFO - 2024-09-25 04:21:13 --> Database Driver Class Initialized
INFO - 2024-09-25 06:46:32 --> Config Class Initialized
INFO - 2024-09-25 06:46:32 --> Hooks Class Initialized
DEBUG - 2024-09-25 06:46:32 --> UTF-8 Support Enabled
INFO - 2024-09-25 06:46:32 --> Utf8 Class Initialized
INFO - 2024-09-25 06:46:32 --> URI Class Initialized
DEBUG - 2024-09-25 06:46:32 --> No URI present. Default controller set.
INFO - 2024-09-25 06:46:32 --> Router Class Initialized
INFO - 2024-09-25 06:46:32 --> Output Class Initialized
INFO - 2024-09-25 06:46:32 --> Security Class Initialized
DEBUG - 2024-09-25 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 06:46:32 --> Input Class Initialized
INFO - 2024-09-25 06:46:32 --> Language Class Initialized
INFO - 2024-09-25 06:46:32 --> Loader Class Initialized
INFO - 2024-09-25 06:46:32 --> Helper loaded: url_helper
INFO - 2024-09-25 06:46:32 --> Helper loaded: file_helper
INFO - 2024-09-25 06:46:32 --> Helper loaded: security_helper
INFO - 2024-09-25 06:46:32 --> Helper loaded: wpu_helper
INFO - 2024-09-25 06:46:32 --> Database Driver Class Initialized
INFO - 2024-09-25 10:27:10 --> Config Class Initialized
INFO - 2024-09-25 10:27:10 --> Hooks Class Initialized
DEBUG - 2024-09-25 10:27:10 --> UTF-8 Support Enabled
INFO - 2024-09-25 10:27:10 --> Utf8 Class Initialized
INFO - 2024-09-25 10:27:10 --> URI Class Initialized
DEBUG - 2024-09-25 10:27:10 --> No URI present. Default controller set.
INFO - 2024-09-25 10:27:10 --> Router Class Initialized
INFO - 2024-09-25 10:27:10 --> Output Class Initialized
INFO - 2024-09-25 10:27:10 --> Security Class Initialized
DEBUG - 2024-09-25 10:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 10:27:10 --> Input Class Initialized
INFO - 2024-09-25 10:27:10 --> Language Class Initialized
INFO - 2024-09-25 10:27:10 --> Loader Class Initialized
INFO - 2024-09-25 10:27:10 --> Helper loaded: url_helper
INFO - 2024-09-25 10:27:10 --> Helper loaded: file_helper
INFO - 2024-09-25 10:27:10 --> Helper loaded: security_helper
INFO - 2024-09-25 10:27:10 --> Helper loaded: wpu_helper
INFO - 2024-09-25 10:27:10 --> Database Driver Class Initialized
INFO - 2024-09-25 11:35:34 --> Config Class Initialized
INFO - 2024-09-25 11:35:34 --> Hooks Class Initialized
DEBUG - 2024-09-25 11:35:34 --> UTF-8 Support Enabled
INFO - 2024-09-25 11:35:34 --> Utf8 Class Initialized
INFO - 2024-09-25 11:35:34 --> URI Class Initialized
DEBUG - 2024-09-25 11:35:34 --> No URI present. Default controller set.
INFO - 2024-09-25 11:35:34 --> Router Class Initialized
INFO - 2024-09-25 11:35:34 --> Output Class Initialized
INFO - 2024-09-25 11:35:34 --> Security Class Initialized
DEBUG - 2024-09-25 11:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 11:35:34 --> Input Class Initialized
INFO - 2024-09-25 11:35:34 --> Language Class Initialized
INFO - 2024-09-25 11:35:34 --> Loader Class Initialized
INFO - 2024-09-25 11:35:34 --> Helper loaded: url_helper
INFO - 2024-09-25 11:35:34 --> Helper loaded: file_helper
INFO - 2024-09-25 11:35:34 --> Helper loaded: security_helper
INFO - 2024-09-25 11:35:34 --> Helper loaded: wpu_helper
INFO - 2024-09-25 11:35:34 --> Database Driver Class Initialized
INFO - 2024-09-25 11:35:38 --> Config Class Initialized
INFO - 2024-09-25 11:35:38 --> Hooks Class Initialized
DEBUG - 2024-09-25 11:35:38 --> UTF-8 Support Enabled
INFO - 2024-09-25 11:35:38 --> Utf8 Class Initialized
INFO - 2024-09-25 11:35:38 --> URI Class Initialized
DEBUG - 2024-09-25 11:35:38 --> No URI present. Default controller set.
INFO - 2024-09-25 11:35:38 --> Router Class Initialized
INFO - 2024-09-25 11:35:38 --> Output Class Initialized
INFO - 2024-09-25 11:35:38 --> Security Class Initialized
DEBUG - 2024-09-25 11:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 11:35:38 --> Input Class Initialized
INFO - 2024-09-25 11:35:38 --> Language Class Initialized
INFO - 2024-09-25 11:35:38 --> Loader Class Initialized
INFO - 2024-09-25 11:35:38 --> Helper loaded: url_helper
INFO - 2024-09-25 11:35:38 --> Helper loaded: file_helper
INFO - 2024-09-25 11:35:38 --> Helper loaded: security_helper
INFO - 2024-09-25 11:35:38 --> Helper loaded: wpu_helper
INFO - 2024-09-25 11:35:38 --> Database Driver Class Initialized
