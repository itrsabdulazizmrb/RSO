<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-04 15:04:37 --> Config Class Initialized
INFO - 2024-09-04 15:04:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:04:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:04:37 --> Utf8 Class Initialized
INFO - 2024-09-04 15:04:37 --> URI Class Initialized
INFO - 2024-09-04 15:04:37 --> Router Class Initialized
INFO - 2024-09-04 15:04:37 --> Output Class Initialized
INFO - 2024-09-04 15:04:37 --> Security Class Initialized
DEBUG - 2024-09-04 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:04:37 --> Input Class Initialized
INFO - 2024-09-04 15:04:37 --> Language Class Initialized
INFO - 2024-09-04 15:04:37 --> Loader Class Initialized
INFO - 2024-09-04 15:04:37 --> Helper loaded: url_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: file_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: security_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:04:37 --> Database Driver Class Initialized
INFO - 2024-09-04 15:04:37 --> Email Class Initialized
DEBUG - 2024-09-04 15:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:04:37 --> Helper loaded: form_helper
INFO - 2024-09-04 15:04:37 --> Form Validation Class Initialized
INFO - 2024-09-04 15:04:37 --> Controller Class Initialized
INFO - 2024-09-04 15:04:37 --> Config Class Initialized
INFO - 2024-09-04 15:04:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:04:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:04:37 --> Utf8 Class Initialized
INFO - 2024-09-04 15:04:37 --> URI Class Initialized
INFO - 2024-09-04 15:04:37 --> Router Class Initialized
INFO - 2024-09-04 15:04:37 --> Output Class Initialized
INFO - 2024-09-04 15:04:37 --> Security Class Initialized
DEBUG - 2024-09-04 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:04:37 --> Input Class Initialized
INFO - 2024-09-04 15:04:37 --> Language Class Initialized
INFO - 2024-09-04 15:04:37 --> Loader Class Initialized
INFO - 2024-09-04 15:04:37 --> Helper loaded: url_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: file_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: security_helper
INFO - 2024-09-04 15:04:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:04:37 --> Database Driver Class Initialized
INFO - 2024-09-04 15:04:38 --> Email Class Initialized
DEBUG - 2024-09-04 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:04:38 --> Helper loaded: form_helper
INFO - 2024-09-04 15:04:38 --> Form Validation Class Initialized
INFO - 2024-09-04 15:04:38 --> Controller Class Initialized
DEBUG - 2024-09-04 15:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:04:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 15:04:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 15:04:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 15:04:38 --> Final output sent to browser
DEBUG - 2024-09-04 15:04:38 --> Total execution time: 0.0929
INFO - 2024-09-04 15:04:41 --> Config Class Initialized
INFO - 2024-09-04 15:04:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:04:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:04:41 --> Utf8 Class Initialized
INFO - 2024-09-04 15:04:41 --> URI Class Initialized
INFO - 2024-09-04 15:04:41 --> Router Class Initialized
INFO - 2024-09-04 15:04:41 --> Output Class Initialized
INFO - 2024-09-04 15:04:41 --> Security Class Initialized
DEBUG - 2024-09-04 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:04:41 --> Input Class Initialized
INFO - 2024-09-04 15:04:41 --> Language Class Initialized
INFO - 2024-09-04 15:04:41 --> Loader Class Initialized
INFO - 2024-09-04 15:04:41 --> Helper loaded: url_helper
INFO - 2024-09-04 15:04:41 --> Helper loaded: file_helper
INFO - 2024-09-04 15:04:41 --> Helper loaded: security_helper
INFO - 2024-09-04 15:04:41 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:04:41 --> Database Driver Class Initialized
INFO - 2024-09-04 15:04:41 --> Email Class Initialized
DEBUG - 2024-09-04 15:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:04:41 --> Helper loaded: form_helper
INFO - 2024-09-04 15:04:41 --> Form Validation Class Initialized
INFO - 2024-09-04 15:04:41 --> Controller Class Initialized
DEBUG - 2024-09-04 15:04:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:04:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-09-04 15:04:41 --> Query error: Table 'sik.tbl_user' doesn't exist - Invalid query: SELECT *
FROM `tbl_user`
WHERE `username` = 'admin'
INFO - 2024-09-04 15:04:41 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 15:05:05 --> Config Class Initialized
INFO - 2024-09-04 15:05:05 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:05:05 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:05:05 --> Utf8 Class Initialized
INFO - 2024-09-04 15:05:05 --> URI Class Initialized
INFO - 2024-09-04 15:05:05 --> Router Class Initialized
INFO - 2024-09-04 15:05:05 --> Output Class Initialized
INFO - 2024-09-04 15:05:05 --> Security Class Initialized
DEBUG - 2024-09-04 15:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:05:05 --> Input Class Initialized
INFO - 2024-09-04 15:05:05 --> Language Class Initialized
INFO - 2024-09-04 15:05:05 --> Loader Class Initialized
INFO - 2024-09-04 15:05:05 --> Helper loaded: url_helper
INFO - 2024-09-04 15:05:05 --> Helper loaded: file_helper
INFO - 2024-09-04 15:05:05 --> Helper loaded: security_helper
INFO - 2024-09-04 15:05:05 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:05:05 --> Database Driver Class Initialized
INFO - 2024-09-04 15:05:05 --> Email Class Initialized
DEBUG - 2024-09-04 15:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:05:05 --> Helper loaded: form_helper
INFO - 2024-09-04 15:05:05 --> Form Validation Class Initialized
INFO - 2024-09-04 15:05:05 --> Controller Class Initialized
INFO - 2024-09-04 15:05:05 --> Model "User_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:05:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:05:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:05:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 15:05:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`, `menu`
                            FROM `user_menu` JOIN `user_access_menu`
                              ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                           WHERE `user_access_menu`.`id_role` = 
                        ORDER BY `user_access_menu`.`menu_id` ASC
                        
INFO - 2024-09-04 15:05:06 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 15:05:19 --> Config Class Initialized
INFO - 2024-09-04 15:05:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:05:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:05:19 --> Utf8 Class Initialized
INFO - 2024-09-04 15:05:19 --> URI Class Initialized
INFO - 2024-09-04 15:05:19 --> Router Class Initialized
INFO - 2024-09-04 15:05:19 --> Output Class Initialized
INFO - 2024-09-04 15:05:19 --> Security Class Initialized
DEBUG - 2024-09-04 15:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:05:19 --> Input Class Initialized
INFO - 2024-09-04 15:05:19 --> Language Class Initialized
INFO - 2024-09-04 15:05:19 --> Loader Class Initialized
INFO - 2024-09-04 15:05:19 --> Helper loaded: url_helper
INFO - 2024-09-04 15:05:19 --> Helper loaded: file_helper
INFO - 2024-09-04 15:05:19 --> Helper loaded: security_helper
INFO - 2024-09-04 15:05:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:05:19 --> Database Driver Class Initialized
INFO - 2024-09-04 15:05:19 --> Email Class Initialized
DEBUG - 2024-09-04 15:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:05:19 --> Helper loaded: form_helper
INFO - 2024-09-04 15:05:19 --> Form Validation Class Initialized
INFO - 2024-09-04 15:05:19 --> Controller Class Initialized
INFO - 2024-09-04 15:05:19 --> Model "User_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:05:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:05:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:05:24 --> Config Class Initialized
INFO - 2024-09-04 15:05:24 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:05:24 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:05:24 --> Utf8 Class Initialized
INFO - 2024-09-04 15:05:24 --> URI Class Initialized
INFO - 2024-09-04 15:05:24 --> Router Class Initialized
INFO - 2024-09-04 15:05:24 --> Output Class Initialized
INFO - 2024-09-04 15:05:24 --> Security Class Initialized
DEBUG - 2024-09-04 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:05:24 --> Input Class Initialized
INFO - 2024-09-04 15:05:24 --> Language Class Initialized
INFO - 2024-09-04 15:05:24 --> Loader Class Initialized
INFO - 2024-09-04 15:05:24 --> Helper loaded: url_helper
INFO - 2024-09-04 15:05:24 --> Helper loaded: file_helper
INFO - 2024-09-04 15:05:24 --> Helper loaded: security_helper
INFO - 2024-09-04 15:05:24 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:05:24 --> Database Driver Class Initialized
INFO - 2024-09-04 15:05:24 --> Email Class Initialized
DEBUG - 2024-09-04 15:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:05:24 --> Helper loaded: form_helper
INFO - 2024-09-04 15:05:24 --> Form Validation Class Initialized
INFO - 2024-09-04 15:05:24 --> Controller Class Initialized
INFO - 2024-09-04 15:05:24 --> Model "User_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:05:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:05:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:05:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 15:05:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`, `menu`
                            FROM `user_menu` JOIN `user_access_menu`
                              ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                           WHERE `user_access_menu`.`id_role` = 
                        ORDER BY `user_access_menu`.`menu_id` ASC
                        
INFO - 2024-09-04 15:05:24 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 15:05:29 --> Config Class Initialized
INFO - 2024-09-04 15:05:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:05:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:05:29 --> Utf8 Class Initialized
INFO - 2024-09-04 15:05:29 --> URI Class Initialized
INFO - 2024-09-04 15:05:29 --> Router Class Initialized
INFO - 2024-09-04 15:05:29 --> Output Class Initialized
INFO - 2024-09-04 15:05:29 --> Security Class Initialized
DEBUG - 2024-09-04 15:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:05:29 --> Input Class Initialized
INFO - 2024-09-04 15:05:29 --> Language Class Initialized
INFO - 2024-09-04 15:05:29 --> Loader Class Initialized
INFO - 2024-09-04 15:05:29 --> Helper loaded: url_helper
INFO - 2024-09-04 15:05:29 --> Helper loaded: file_helper
INFO - 2024-09-04 15:05:29 --> Helper loaded: security_helper
INFO - 2024-09-04 15:05:29 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:05:29 --> Database Driver Class Initialized
INFO - 2024-09-04 15:05:29 --> Email Class Initialized
DEBUG - 2024-09-04 15:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:05:29 --> Helper loaded: form_helper
INFO - 2024-09-04 15:05:29 --> Form Validation Class Initialized
INFO - 2024-09-04 15:05:29 --> Controller Class Initialized
INFO - 2024-09-04 15:05:29 --> Model "User_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:05:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:05:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:05:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:05:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:05:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:05:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:05:29 --> Final output sent to browser
DEBUG - 2024-09-04 15:05:29 --> Total execution time: 0.5067
INFO - 2024-09-04 15:39:38 --> Config Class Initialized
INFO - 2024-09-04 15:39:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:39:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:39:38 --> Utf8 Class Initialized
INFO - 2024-09-04 15:39:38 --> URI Class Initialized
INFO - 2024-09-04 15:39:38 --> Router Class Initialized
INFO - 2024-09-04 15:39:38 --> Output Class Initialized
INFO - 2024-09-04 15:39:38 --> Security Class Initialized
DEBUG - 2024-09-04 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:39:38 --> Input Class Initialized
INFO - 2024-09-04 15:39:38 --> Language Class Initialized
INFO - 2024-09-04 15:39:38 --> Loader Class Initialized
INFO - 2024-09-04 15:39:38 --> Helper loaded: url_helper
INFO - 2024-09-04 15:39:38 --> Helper loaded: file_helper
INFO - 2024-09-04 15:39:38 --> Helper loaded: security_helper
INFO - 2024-09-04 15:39:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:39:38 --> Database Driver Class Initialized
INFO - 2024-09-04 15:39:38 --> Email Class Initialized
DEBUG - 2024-09-04 15:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:39:38 --> Helper loaded: form_helper
INFO - 2024-09-04 15:39:38 --> Form Validation Class Initialized
INFO - 2024-09-04 15:39:38 --> Controller Class Initialized
INFO - 2024-09-04 15:39:38 --> Model "User_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:39:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:39:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:39:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:39:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:39:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:39:50 --> Config Class Initialized
INFO - 2024-09-04 15:39:50 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:39:50 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:39:50 --> Utf8 Class Initialized
INFO - 2024-09-04 15:39:50 --> URI Class Initialized
INFO - 2024-09-04 15:39:50 --> Router Class Initialized
INFO - 2024-09-04 15:39:50 --> Output Class Initialized
INFO - 2024-09-04 15:39:50 --> Security Class Initialized
DEBUG - 2024-09-04 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:39:50 --> Input Class Initialized
INFO - 2024-09-04 15:39:50 --> Language Class Initialized
INFO - 2024-09-04 15:39:50 --> Loader Class Initialized
INFO - 2024-09-04 15:39:50 --> Helper loaded: url_helper
INFO - 2024-09-04 15:39:50 --> Helper loaded: file_helper
INFO - 2024-09-04 15:39:50 --> Helper loaded: security_helper
INFO - 2024-09-04 15:39:50 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:39:50 --> Database Driver Class Initialized
INFO - 2024-09-04 15:39:50 --> Email Class Initialized
DEBUG - 2024-09-04 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:39:50 --> Helper loaded: form_helper
INFO - 2024-09-04 15:39:50 --> Form Validation Class Initialized
INFO - 2024-09-04 15:39:50 --> Controller Class Initialized
INFO - 2024-09-04 15:39:50 --> Model "User_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:39:50 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:39:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 15:39:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`, `menu`
                            FROM `user_menu` JOIN `user_access_menu`
                              ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                           WHERE `user_access_menu`.`id_role` = 
                        ORDER BY `user_access_menu`.`menu_id` ASC
                        
INFO - 2024-09-04 15:39:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 15:39:53 --> Config Class Initialized
INFO - 2024-09-04 15:39:53 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:39:53 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:39:53 --> Utf8 Class Initialized
INFO - 2024-09-04 15:39:53 --> URI Class Initialized
INFO - 2024-09-04 15:39:53 --> Router Class Initialized
INFO - 2024-09-04 15:39:53 --> Output Class Initialized
INFO - 2024-09-04 15:39:53 --> Security Class Initialized
DEBUG - 2024-09-04 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:39:53 --> Input Class Initialized
INFO - 2024-09-04 15:39:53 --> Language Class Initialized
INFO - 2024-09-04 15:39:53 --> Loader Class Initialized
INFO - 2024-09-04 15:39:53 --> Helper loaded: url_helper
INFO - 2024-09-04 15:39:53 --> Helper loaded: file_helper
INFO - 2024-09-04 15:39:53 --> Helper loaded: security_helper
INFO - 2024-09-04 15:39:53 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:39:53 --> Database Driver Class Initialized
INFO - 2024-09-04 15:39:53 --> Email Class Initialized
DEBUG - 2024-09-04 15:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:39:53 --> Helper loaded: form_helper
INFO - 2024-09-04 15:39:53 --> Form Validation Class Initialized
INFO - 2024-09-04 15:39:53 --> Controller Class Initialized
INFO - 2024-09-04 15:39:53 --> Model "User_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:39:53 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:39:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:39:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:39:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:39:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:39:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:39:54 --> Final output sent to browser
DEBUG - 2024-09-04 15:39:54 --> Total execution time: 0.5683
INFO - 2024-09-04 15:39:59 --> Config Class Initialized
INFO - 2024-09-04 15:39:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:39:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:39:59 --> Utf8 Class Initialized
INFO - 2024-09-04 15:39:59 --> URI Class Initialized
INFO - 2024-09-04 15:39:59 --> Router Class Initialized
INFO - 2024-09-04 15:39:59 --> Output Class Initialized
INFO - 2024-09-04 15:39:59 --> Security Class Initialized
DEBUG - 2024-09-04 15:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:39:59 --> Input Class Initialized
INFO - 2024-09-04 15:39:59 --> Language Class Initialized
INFO - 2024-09-04 15:39:59 --> Loader Class Initialized
INFO - 2024-09-04 15:39:59 --> Helper loaded: url_helper
INFO - 2024-09-04 15:39:59 --> Helper loaded: file_helper
INFO - 2024-09-04 15:39:59 --> Helper loaded: security_helper
INFO - 2024-09-04 15:39:59 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:39:59 --> Database Driver Class Initialized
INFO - 2024-09-04 15:39:59 --> Email Class Initialized
DEBUG - 2024-09-04 15:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:39:59 --> Helper loaded: form_helper
INFO - 2024-09-04 15:39:59 --> Form Validation Class Initialized
INFO - 2024-09-04 15:39:59 --> Controller Class Initialized
INFO - 2024-09-04 15:39:59 --> Model "User_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:39:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:39:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:39:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:39:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:39:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:39:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:39:59 --> Final output sent to browser
DEBUG - 2024-09-04 15:39:59 --> Total execution time: 0.6405
INFO - 2024-09-04 15:40:00 --> Config Class Initialized
INFO - 2024-09-04 15:40:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:40:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:40:00 --> Utf8 Class Initialized
INFO - 2024-09-04 15:40:00 --> URI Class Initialized
INFO - 2024-09-04 15:40:00 --> Router Class Initialized
INFO - 2024-09-04 15:40:00 --> Output Class Initialized
INFO - 2024-09-04 15:40:00 --> Security Class Initialized
DEBUG - 2024-09-04 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:40:00 --> Input Class Initialized
INFO - 2024-09-04 15:40:00 --> Language Class Initialized
INFO - 2024-09-04 15:40:00 --> Loader Class Initialized
INFO - 2024-09-04 15:40:00 --> Helper loaded: url_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: file_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: security_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:40:00 --> Database Driver Class Initialized
INFO - 2024-09-04 15:40:00 --> Email Class Initialized
DEBUG - 2024-09-04 15:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:40:00 --> Helper loaded: form_helper
INFO - 2024-09-04 15:40:00 --> Form Validation Class Initialized
INFO - 2024-09-04 15:40:00 --> Controller Class Initialized
INFO - 2024-09-04 15:40:00 --> Model "User_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:40:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:40:00 --> Config Class Initialized
INFO - 2024-09-04 15:40:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:40:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:40:00 --> Utf8 Class Initialized
INFO - 2024-09-04 15:40:00 --> URI Class Initialized
INFO - 2024-09-04 15:40:00 --> Router Class Initialized
INFO - 2024-09-04 15:40:00 --> Output Class Initialized
INFO - 2024-09-04 15:40:00 --> Security Class Initialized
DEBUG - 2024-09-04 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:40:00 --> Input Class Initialized
INFO - 2024-09-04 15:40:00 --> Language Class Initialized
INFO - 2024-09-04 15:40:00 --> Loader Class Initialized
INFO - 2024-09-04 15:40:00 --> Helper loaded: url_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: file_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: security_helper
INFO - 2024-09-04 15:40:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:40:00 --> Database Driver Class Initialized
INFO - 2024-09-04 15:40:00 --> Email Class Initialized
DEBUG - 2024-09-04 15:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:40:00 --> Final output sent to browser
DEBUG - 2024-09-04 15:40:00 --> Total execution time: 0.5458
INFO - 2024-09-04 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:40:00 --> Helper loaded: form_helper
INFO - 2024-09-04 15:40:00 --> Form Validation Class Initialized
INFO - 2024-09-04 15:40:00 --> Controller Class Initialized
INFO - 2024-09-04 15:40:00 --> Model "User_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:40:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:40:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:40:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:40:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:40:01 --> Config Class Initialized
INFO - 2024-09-04 15:40:01 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:40:01 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:40:01 --> Utf8 Class Initialized
INFO - 2024-09-04 15:40:01 --> URI Class Initialized
INFO - 2024-09-04 15:40:01 --> Router Class Initialized
INFO - 2024-09-04 15:40:01 --> Output Class Initialized
INFO - 2024-09-04 15:40:01 --> Security Class Initialized
DEBUG - 2024-09-04 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:40:01 --> Input Class Initialized
INFO - 2024-09-04 15:40:01 --> Language Class Initialized
INFO - 2024-09-04 15:40:01 --> Loader Class Initialized
INFO - 2024-09-04 15:40:01 --> Helper loaded: url_helper
INFO - 2024-09-04 15:40:01 --> Helper loaded: file_helper
INFO - 2024-09-04 15:40:01 --> Helper loaded: security_helper
INFO - 2024-09-04 15:40:01 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:40:01 --> Database Driver Class Initialized
INFO - 2024-09-04 15:40:01 --> Email Class Initialized
DEBUG - 2024-09-04 15:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:40:01 --> Helper loaded: form_helper
INFO - 2024-09-04 15:40:01 --> Form Validation Class Initialized
INFO - 2024-09-04 15:40:01 --> Controller Class Initialized
INFO - 2024-09-04 15:40:01 --> Model "User_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:40:01 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:40:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:40:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:40:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:40:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:40:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:40:02 --> Final output sent to browser
DEBUG - 2024-09-04 15:40:02 --> Total execution time: 0.4528
INFO - 2024-09-04 15:40:05 --> Config Class Initialized
INFO - 2024-09-04 15:40:05 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:40:05 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:40:05 --> Utf8 Class Initialized
INFO - 2024-09-04 15:40:05 --> URI Class Initialized
INFO - 2024-09-04 15:40:05 --> Router Class Initialized
INFO - 2024-09-04 15:40:05 --> Output Class Initialized
INFO - 2024-09-04 15:40:05 --> Security Class Initialized
DEBUG - 2024-09-04 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:40:05 --> Input Class Initialized
INFO - 2024-09-04 15:40:05 --> Language Class Initialized
INFO - 2024-09-04 15:40:05 --> Loader Class Initialized
INFO - 2024-09-04 15:40:05 --> Helper loaded: url_helper
INFO - 2024-09-04 15:40:05 --> Helper loaded: file_helper
INFO - 2024-09-04 15:40:05 --> Helper loaded: security_helper
INFO - 2024-09-04 15:40:05 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:40:05 --> Database Driver Class Initialized
INFO - 2024-09-04 15:40:05 --> Email Class Initialized
DEBUG - 2024-09-04 15:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:40:05 --> Helper loaded: form_helper
INFO - 2024-09-04 15:40:05 --> Form Validation Class Initialized
INFO - 2024-09-04 15:40:05 --> Controller Class Initialized
INFO - 2024-09-04 15:40:05 --> Model "User_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:40:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:40:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:40:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:40:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:40:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:40:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:40:05 --> Final output sent to browser
DEBUG - 2024-09-04 15:40:05 --> Total execution time: 0.4401
INFO - 2024-09-04 15:40:29 --> Config Class Initialized
INFO - 2024-09-04 15:40:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:40:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:40:29 --> Utf8 Class Initialized
INFO - 2024-09-04 15:40:29 --> URI Class Initialized
INFO - 2024-09-04 15:40:29 --> Router Class Initialized
INFO - 2024-09-04 15:40:29 --> Output Class Initialized
INFO - 2024-09-04 15:40:29 --> Security Class Initialized
DEBUG - 2024-09-04 15:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:40:29 --> Input Class Initialized
INFO - 2024-09-04 15:40:29 --> Language Class Initialized
INFO - 2024-09-04 15:40:29 --> Loader Class Initialized
INFO - 2024-09-04 15:40:29 --> Helper loaded: url_helper
INFO - 2024-09-04 15:40:29 --> Helper loaded: file_helper
INFO - 2024-09-04 15:40:29 --> Helper loaded: security_helper
INFO - 2024-09-04 15:40:29 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:40:29 --> Database Driver Class Initialized
INFO - 2024-09-04 15:40:29 --> Email Class Initialized
DEBUG - 2024-09-04 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:40:29 --> Helper loaded: form_helper
INFO - 2024-09-04 15:40:29 --> Form Validation Class Initialized
INFO - 2024-09-04 15:40:29 --> Controller Class Initialized
INFO - 2024-09-04 15:40:29 --> Model "User_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:40:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:40:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:40:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:40:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:40:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:40:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:40:30 --> Final output sent to browser
DEBUG - 2024-09-04 15:40:30 --> Total execution time: 0.5380
INFO - 2024-09-04 15:42:38 --> Config Class Initialized
INFO - 2024-09-04 15:42:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:42:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:42:38 --> Utf8 Class Initialized
INFO - 2024-09-04 15:42:38 --> URI Class Initialized
INFO - 2024-09-04 15:42:38 --> Router Class Initialized
INFO - 2024-09-04 15:42:38 --> Output Class Initialized
INFO - 2024-09-04 15:42:38 --> Security Class Initialized
DEBUG - 2024-09-04 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:42:38 --> Input Class Initialized
INFO - 2024-09-04 15:42:38 --> Language Class Initialized
INFO - 2024-09-04 15:42:38 --> Loader Class Initialized
INFO - 2024-09-04 15:42:38 --> Helper loaded: url_helper
INFO - 2024-09-04 15:42:38 --> Helper loaded: file_helper
INFO - 2024-09-04 15:42:38 --> Helper loaded: security_helper
INFO - 2024-09-04 15:42:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:42:38 --> Database Driver Class Initialized
INFO - 2024-09-04 15:42:38 --> Email Class Initialized
DEBUG - 2024-09-04 15:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:42:38 --> Helper loaded: form_helper
INFO - 2024-09-04 15:42:38 --> Form Validation Class Initialized
INFO - 2024-09-04 15:42:38 --> Controller Class Initialized
INFO - 2024-09-04 15:42:38 --> Model "User_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:42:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:42:38 --> Final output sent to browser
DEBUG - 2024-09-04 15:42:38 --> Total execution time: 0.0794
INFO - 2024-09-04 15:42:39 --> Config Class Initialized
INFO - 2024-09-04 15:42:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:42:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:42:39 --> Utf8 Class Initialized
INFO - 2024-09-04 15:42:39 --> URI Class Initialized
INFO - 2024-09-04 15:42:39 --> Router Class Initialized
INFO - 2024-09-04 15:42:39 --> Output Class Initialized
INFO - 2024-09-04 15:42:39 --> Security Class Initialized
DEBUG - 2024-09-04 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:42:39 --> Input Class Initialized
INFO - 2024-09-04 15:42:39 --> Language Class Initialized
INFO - 2024-09-04 15:42:39 --> Loader Class Initialized
INFO - 2024-09-04 15:42:39 --> Helper loaded: url_helper
INFO - 2024-09-04 15:42:39 --> Helper loaded: file_helper
INFO - 2024-09-04 15:42:39 --> Helper loaded: security_helper
INFO - 2024-09-04 15:42:39 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:42:39 --> Database Driver Class Initialized
INFO - 2024-09-04 15:42:39 --> Email Class Initialized
DEBUG - 2024-09-04 15:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:42:39 --> Helper loaded: form_helper
INFO - 2024-09-04 15:42:39 --> Form Validation Class Initialized
INFO - 2024-09-04 15:42:39 --> Controller Class Initialized
INFO - 2024-09-04 15:42:39 --> Model "User_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:42:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:42:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:42:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:42:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:42:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:42:39 --> Final output sent to browser
DEBUG - 2024-09-04 15:42:39 --> Total execution time: 0.0626
INFO - 2024-09-04 15:42:39 --> Config Class Initialized
INFO - 2024-09-04 15:42:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:42:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:42:39 --> Utf8 Class Initialized
INFO - 2024-09-04 15:42:39 --> URI Class Initialized
INFO - 2024-09-04 15:42:39 --> Router Class Initialized
INFO - 2024-09-04 15:42:39 --> Output Class Initialized
INFO - 2024-09-04 15:42:39 --> Security Class Initialized
DEBUG - 2024-09-04 15:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:42:39 --> Input Class Initialized
INFO - 2024-09-04 15:42:39 --> Language Class Initialized
INFO - 2024-09-04 15:42:40 --> Loader Class Initialized
INFO - 2024-09-04 15:42:40 --> Helper loaded: url_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: file_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: security_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:42:40 --> Database Driver Class Initialized
INFO - 2024-09-04 15:42:40 --> Email Class Initialized
DEBUG - 2024-09-04 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:42:40 --> Helper loaded: form_helper
INFO - 2024-09-04 15:42:40 --> Form Validation Class Initialized
INFO - 2024-09-04 15:42:40 --> Controller Class Initialized
INFO - 2024-09-04 15:42:40 --> Model "User_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:42:40 --> Final output sent to browser
DEBUG - 2024-09-04 15:42:40 --> Total execution time: 0.0883
INFO - 2024-09-04 15:42:40 --> Config Class Initialized
INFO - 2024-09-04 15:42:40 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:42:40 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:42:40 --> Utf8 Class Initialized
INFO - 2024-09-04 15:42:40 --> URI Class Initialized
INFO - 2024-09-04 15:42:40 --> Router Class Initialized
INFO - 2024-09-04 15:42:40 --> Output Class Initialized
INFO - 2024-09-04 15:42:40 --> Security Class Initialized
DEBUG - 2024-09-04 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:42:40 --> Input Class Initialized
INFO - 2024-09-04 15:42:40 --> Language Class Initialized
INFO - 2024-09-04 15:42:40 --> Loader Class Initialized
INFO - 2024-09-04 15:42:40 --> Helper loaded: url_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: file_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: security_helper
INFO - 2024-09-04 15:42:40 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:42:40 --> Database Driver Class Initialized
INFO - 2024-09-04 15:42:40 --> Email Class Initialized
DEBUG - 2024-09-04 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:42:40 --> Helper loaded: form_helper
INFO - 2024-09-04 15:42:40 --> Form Validation Class Initialized
INFO - 2024-09-04 15:42:40 --> Controller Class Initialized
INFO - 2024-09-04 15:42:40 --> Model "User_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:42:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:42:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:42:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:42:40 --> Final output sent to browser
DEBUG - 2024-09-04 15:42:40 --> Total execution time: 0.0816
INFO - 2024-09-04 15:43:06 --> Config Class Initialized
INFO - 2024-09-04 15:43:06 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:43:06 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:43:06 --> Utf8 Class Initialized
INFO - 2024-09-04 15:43:06 --> URI Class Initialized
INFO - 2024-09-04 15:43:06 --> Router Class Initialized
INFO - 2024-09-04 15:43:06 --> Output Class Initialized
INFO - 2024-09-04 15:43:06 --> Security Class Initialized
DEBUG - 2024-09-04 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:43:06 --> Input Class Initialized
INFO - 2024-09-04 15:43:06 --> Language Class Initialized
INFO - 2024-09-04 15:43:06 --> Loader Class Initialized
INFO - 2024-09-04 15:43:06 --> Helper loaded: url_helper
INFO - 2024-09-04 15:43:06 --> Helper loaded: file_helper
INFO - 2024-09-04 15:43:06 --> Helper loaded: security_helper
INFO - 2024-09-04 15:43:06 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:43:06 --> Database Driver Class Initialized
INFO - 2024-09-04 15:43:06 --> Email Class Initialized
DEBUG - 2024-09-04 15:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:43:06 --> Helper loaded: form_helper
INFO - 2024-09-04 15:43:06 --> Form Validation Class Initialized
INFO - 2024-09-04 15:43:06 --> Controller Class Initialized
INFO - 2024-09-04 15:43:06 --> Model "User_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:43:06 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:43:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:43:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:43:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:43:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:43:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:43:06 --> Final output sent to browser
DEBUG - 2024-09-04 15:43:06 --> Total execution time: 0.1138
INFO - 2024-09-04 15:43:07 --> Config Class Initialized
INFO - 2024-09-04 15:43:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:43:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:43:07 --> Utf8 Class Initialized
INFO - 2024-09-04 15:43:07 --> URI Class Initialized
INFO - 2024-09-04 15:43:07 --> Router Class Initialized
INFO - 2024-09-04 15:43:07 --> Output Class Initialized
INFO - 2024-09-04 15:43:07 --> Security Class Initialized
DEBUG - 2024-09-04 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:43:07 --> Input Class Initialized
INFO - 2024-09-04 15:43:07 --> Language Class Initialized
INFO - 2024-09-04 15:43:07 --> Loader Class Initialized
INFO - 2024-09-04 15:43:07 --> Helper loaded: url_helper
INFO - 2024-09-04 15:43:07 --> Helper loaded: file_helper
INFO - 2024-09-04 15:43:07 --> Helper loaded: security_helper
INFO - 2024-09-04 15:43:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:43:07 --> Database Driver Class Initialized
INFO - 2024-09-04 15:43:07 --> Email Class Initialized
DEBUG - 2024-09-04 15:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:43:07 --> Helper loaded: form_helper
INFO - 2024-09-04 15:43:07 --> Form Validation Class Initialized
INFO - 2024-09-04 15:43:07 --> Controller Class Initialized
INFO - 2024-09-04 15:43:07 --> Model "User_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:43:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:43:07 --> Final output sent to browser
DEBUG - 2024-09-04 15:43:07 --> Total execution time: 0.0800
INFO - 2024-09-04 15:43:21 --> Config Class Initialized
INFO - 2024-09-04 15:43:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:43:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:43:21 --> Utf8 Class Initialized
INFO - 2024-09-04 15:43:21 --> URI Class Initialized
INFO - 2024-09-04 15:43:21 --> Router Class Initialized
INFO - 2024-09-04 15:43:21 --> Output Class Initialized
INFO - 2024-09-04 15:43:21 --> Security Class Initialized
DEBUG - 2024-09-04 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:43:21 --> Input Class Initialized
INFO - 2024-09-04 15:43:21 --> Language Class Initialized
INFO - 2024-09-04 15:43:21 --> Loader Class Initialized
INFO - 2024-09-04 15:43:21 --> Helper loaded: url_helper
INFO - 2024-09-04 15:43:21 --> Helper loaded: file_helper
INFO - 2024-09-04 15:43:21 --> Helper loaded: security_helper
INFO - 2024-09-04 15:43:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:43:21 --> Database Driver Class Initialized
INFO - 2024-09-04 15:43:21 --> Email Class Initialized
DEBUG - 2024-09-04 15:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:43:21 --> Helper loaded: form_helper
INFO - 2024-09-04 15:43:21 --> Form Validation Class Initialized
INFO - 2024-09-04 15:43:21 --> Controller Class Initialized
INFO - 2024-09-04 15:43:21 --> Model "User_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:43:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:43:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:43:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:43:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:43:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:43:21 --> Final output sent to browser
DEBUG - 2024-09-04 15:43:21 --> Total execution time: 0.1496
INFO - 2024-09-04 15:43:55 --> Config Class Initialized
INFO - 2024-09-04 15:43:55 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:43:55 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:43:55 --> Utf8 Class Initialized
INFO - 2024-09-04 15:43:55 --> URI Class Initialized
INFO - 2024-09-04 15:43:55 --> Router Class Initialized
INFO - 2024-09-04 15:43:55 --> Output Class Initialized
INFO - 2024-09-04 15:43:55 --> Security Class Initialized
DEBUG - 2024-09-04 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:43:55 --> Input Class Initialized
INFO - 2024-09-04 15:43:55 --> Language Class Initialized
INFO - 2024-09-04 15:43:55 --> Loader Class Initialized
INFO - 2024-09-04 15:43:55 --> Helper loaded: url_helper
INFO - 2024-09-04 15:43:55 --> Helper loaded: file_helper
INFO - 2024-09-04 15:43:55 --> Helper loaded: security_helper
INFO - 2024-09-04 15:43:55 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:43:55 --> Database Driver Class Initialized
INFO - 2024-09-04 15:43:55 --> Email Class Initialized
DEBUG - 2024-09-04 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:43:55 --> Helper loaded: form_helper
INFO - 2024-09-04 15:43:55 --> Form Validation Class Initialized
INFO - 2024-09-04 15:43:55 --> Controller Class Initialized
INFO - 2024-09-04 15:43:55 --> Model "User_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:43:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:43:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:43:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:43:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:43:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:43:55 --> Final output sent to browser
DEBUG - 2024-09-04 15:43:55 --> Total execution time: 0.1450
INFO - 2024-09-04 15:44:06 --> Config Class Initialized
INFO - 2024-09-04 15:44:06 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:44:06 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:44:06 --> Utf8 Class Initialized
INFO - 2024-09-04 15:44:06 --> URI Class Initialized
INFO - 2024-09-04 15:44:06 --> Router Class Initialized
INFO - 2024-09-04 15:44:06 --> Output Class Initialized
INFO - 2024-09-04 15:44:06 --> Security Class Initialized
DEBUG - 2024-09-04 15:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:44:06 --> Input Class Initialized
INFO - 2024-09-04 15:44:06 --> Language Class Initialized
INFO - 2024-09-04 15:44:06 --> Loader Class Initialized
INFO - 2024-09-04 15:44:06 --> Helper loaded: url_helper
INFO - 2024-09-04 15:44:06 --> Helper loaded: file_helper
INFO - 2024-09-04 15:44:06 --> Helper loaded: security_helper
INFO - 2024-09-04 15:44:06 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:44:06 --> Database Driver Class Initialized
INFO - 2024-09-04 15:44:06 --> Email Class Initialized
DEBUG - 2024-09-04 15:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:44:06 --> Helper loaded: form_helper
INFO - 2024-09-04 15:44:06 --> Form Validation Class Initialized
INFO - 2024-09-04 15:44:06 --> Controller Class Initialized
INFO - 2024-09-04 15:44:06 --> Model "User_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:44:06 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:44:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:44:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:44:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:44:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:44:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:44:06 --> Final output sent to browser
DEBUG - 2024-09-04 15:44:06 --> Total execution time: 0.1194
INFO - 2024-09-04 15:44:13 --> Config Class Initialized
INFO - 2024-09-04 15:44:13 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:44:13 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:44:13 --> Utf8 Class Initialized
INFO - 2024-09-04 15:44:13 --> URI Class Initialized
INFO - 2024-09-04 15:44:13 --> Router Class Initialized
INFO - 2024-09-04 15:44:13 --> Output Class Initialized
INFO - 2024-09-04 15:44:13 --> Security Class Initialized
DEBUG - 2024-09-04 15:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:44:13 --> Input Class Initialized
INFO - 2024-09-04 15:44:13 --> Language Class Initialized
INFO - 2024-09-04 15:44:13 --> Loader Class Initialized
INFO - 2024-09-04 15:44:13 --> Helper loaded: url_helper
INFO - 2024-09-04 15:44:13 --> Helper loaded: file_helper
INFO - 2024-09-04 15:44:13 --> Helper loaded: security_helper
INFO - 2024-09-04 15:44:13 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:44:13 --> Database Driver Class Initialized
INFO - 2024-09-04 15:44:13 --> Email Class Initialized
DEBUG - 2024-09-04 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:44:13 --> Helper loaded: form_helper
INFO - 2024-09-04 15:44:13 --> Form Validation Class Initialized
INFO - 2024-09-04 15:44:13 --> Controller Class Initialized
INFO - 2024-09-04 15:44:13 --> Model "User_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:44:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:44:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:44:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:44:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:44:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:44:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:44:14 --> Final output sent to browser
DEBUG - 2024-09-04 15:44:14 --> Total execution time: 0.1516
INFO - 2024-09-04 15:47:17 --> Config Class Initialized
INFO - 2024-09-04 15:47:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:47:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:47:17 --> Utf8 Class Initialized
INFO - 2024-09-04 15:47:17 --> URI Class Initialized
INFO - 2024-09-04 15:47:17 --> Router Class Initialized
INFO - 2024-09-04 15:47:17 --> Output Class Initialized
INFO - 2024-09-04 15:47:17 --> Security Class Initialized
DEBUG - 2024-09-04 15:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:47:17 --> Input Class Initialized
INFO - 2024-09-04 15:47:17 --> Language Class Initialized
INFO - 2024-09-04 15:47:17 --> Loader Class Initialized
INFO - 2024-09-04 15:47:17 --> Helper loaded: url_helper
INFO - 2024-09-04 15:47:17 --> Helper loaded: file_helper
INFO - 2024-09-04 15:47:17 --> Helper loaded: security_helper
INFO - 2024-09-04 15:47:17 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:47:17 --> Database Driver Class Initialized
INFO - 2024-09-04 15:47:17 --> Email Class Initialized
DEBUG - 2024-09-04 15:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:47:17 --> Helper loaded: form_helper
INFO - 2024-09-04 15:47:17 --> Form Validation Class Initialized
INFO - 2024-09-04 15:47:17 --> Controller Class Initialized
INFO - 2024-09-04 15:47:17 --> Model "User_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:47:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:47:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:47:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:47:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:47:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:47:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:47:17 --> Final output sent to browser
DEBUG - 2024-09-04 15:47:17 --> Total execution time: 0.1461
INFO - 2024-09-04 15:49:11 --> Config Class Initialized
INFO - 2024-09-04 15:49:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:49:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:49:11 --> Utf8 Class Initialized
INFO - 2024-09-04 15:49:11 --> URI Class Initialized
INFO - 2024-09-04 15:49:11 --> Router Class Initialized
INFO - 2024-09-04 15:49:11 --> Output Class Initialized
INFO - 2024-09-04 15:49:11 --> Security Class Initialized
DEBUG - 2024-09-04 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:49:11 --> Input Class Initialized
INFO - 2024-09-04 15:49:11 --> Language Class Initialized
INFO - 2024-09-04 15:49:11 --> Loader Class Initialized
INFO - 2024-09-04 15:49:11 --> Helper loaded: url_helper
INFO - 2024-09-04 15:49:11 --> Helper loaded: file_helper
INFO - 2024-09-04 15:49:11 --> Helper loaded: security_helper
INFO - 2024-09-04 15:49:11 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:49:11 --> Database Driver Class Initialized
INFO - 2024-09-04 15:49:11 --> Email Class Initialized
DEBUG - 2024-09-04 15:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:49:11 --> Helper loaded: form_helper
INFO - 2024-09-04 15:49:11 --> Form Validation Class Initialized
INFO - 2024-09-04 15:49:11 --> Controller Class Initialized
INFO - 2024-09-04 15:49:11 --> Model "User_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:49:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:49:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 15:49:11 --> Severity: error --> Exception: Call to undefined method Antrol_model::getAntrolByCurrentMonth() C:\xampp\htdocs\antrol\application\controllers\Data.php 78
INFO - 2024-09-04 15:49:37 --> Config Class Initialized
INFO - 2024-09-04 15:49:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:49:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:49:37 --> Utf8 Class Initialized
INFO - 2024-09-04 15:49:37 --> URI Class Initialized
INFO - 2024-09-04 15:49:37 --> Router Class Initialized
INFO - 2024-09-04 15:49:37 --> Output Class Initialized
INFO - 2024-09-04 15:49:37 --> Security Class Initialized
DEBUG - 2024-09-04 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:49:37 --> Input Class Initialized
INFO - 2024-09-04 15:49:37 --> Language Class Initialized
INFO - 2024-09-04 15:49:37 --> Loader Class Initialized
INFO - 2024-09-04 15:49:37 --> Helper loaded: url_helper
INFO - 2024-09-04 15:49:37 --> Helper loaded: file_helper
INFO - 2024-09-04 15:49:37 --> Helper loaded: security_helper
INFO - 2024-09-04 15:49:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:49:37 --> Database Driver Class Initialized
INFO - 2024-09-04 15:49:37 --> Email Class Initialized
DEBUG - 2024-09-04 15:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:49:37 --> Helper loaded: form_helper
INFO - 2024-09-04 15:49:37 --> Form Validation Class Initialized
INFO - 2024-09-04 15:49:37 --> Controller Class Initialized
INFO - 2024-09-04 15:49:37 --> Model "User_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:49:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:49:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:49:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:49:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:49:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:49:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:49:37 --> Final output sent to browser
DEBUG - 2024-09-04 15:49:37 --> Total execution time: 0.1399
INFO - 2024-09-04 15:49:44 --> Config Class Initialized
INFO - 2024-09-04 15:49:44 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:49:44 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:49:44 --> Utf8 Class Initialized
INFO - 2024-09-04 15:49:44 --> URI Class Initialized
INFO - 2024-09-04 15:49:44 --> Router Class Initialized
INFO - 2024-09-04 15:49:44 --> Output Class Initialized
INFO - 2024-09-04 15:49:44 --> Security Class Initialized
DEBUG - 2024-09-04 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:49:44 --> Input Class Initialized
INFO - 2024-09-04 15:49:44 --> Language Class Initialized
ERROR - 2024-09-04 15:49:44 --> 404 Page Not Found: Admin/antrol
INFO - 2024-09-04 15:50:13 --> Config Class Initialized
INFO - 2024-09-04 15:50:13 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:50:13 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:50:13 --> Utf8 Class Initialized
INFO - 2024-09-04 15:50:13 --> URI Class Initialized
INFO - 2024-09-04 15:50:13 --> Router Class Initialized
INFO - 2024-09-04 15:50:13 --> Output Class Initialized
INFO - 2024-09-04 15:50:13 --> Security Class Initialized
DEBUG - 2024-09-04 15:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:50:13 --> Input Class Initialized
INFO - 2024-09-04 15:50:13 --> Language Class Initialized
INFO - 2024-09-04 15:50:13 --> Loader Class Initialized
INFO - 2024-09-04 15:50:13 --> Helper loaded: url_helper
INFO - 2024-09-04 15:50:13 --> Helper loaded: file_helper
INFO - 2024-09-04 15:50:13 --> Helper loaded: security_helper
INFO - 2024-09-04 15:50:13 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:50:13 --> Database Driver Class Initialized
INFO - 2024-09-04 15:50:13 --> Email Class Initialized
DEBUG - 2024-09-04 15:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:50:13 --> Helper loaded: form_helper
INFO - 2024-09-04 15:50:13 --> Form Validation Class Initialized
INFO - 2024-09-04 15:50:13 --> Controller Class Initialized
INFO - 2024-09-04 15:50:13 --> Model "User_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:50:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:50:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:50:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:50:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:50:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:50:14 --> Final output sent to browser
DEBUG - 2024-09-04 15:50:14 --> Total execution time: 0.1408
INFO - 2024-09-04 15:50:15 --> Config Class Initialized
INFO - 2024-09-04 15:50:15 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:50:15 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:50:15 --> Utf8 Class Initialized
INFO - 2024-09-04 15:50:15 --> URI Class Initialized
INFO - 2024-09-04 15:50:15 --> Router Class Initialized
INFO - 2024-09-04 15:50:15 --> Output Class Initialized
INFO - 2024-09-04 15:50:15 --> Security Class Initialized
DEBUG - 2024-09-04 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:50:15 --> Input Class Initialized
INFO - 2024-09-04 15:50:15 --> Language Class Initialized
INFO - 2024-09-04 15:50:15 --> Loader Class Initialized
INFO - 2024-09-04 15:50:15 --> Helper loaded: url_helper
INFO - 2024-09-04 15:50:15 --> Helper loaded: file_helper
INFO - 2024-09-04 15:50:15 --> Helper loaded: security_helper
INFO - 2024-09-04 15:50:15 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:50:15 --> Database Driver Class Initialized
INFO - 2024-09-04 15:50:15 --> Email Class Initialized
DEBUG - 2024-09-04 15:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:50:15 --> Helper loaded: form_helper
INFO - 2024-09-04 15:50:15 --> Form Validation Class Initialized
INFO - 2024-09-04 15:50:15 --> Controller Class Initialized
INFO - 2024-09-04 15:50:15 --> Model "User_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:50:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:50:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:50:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:50:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:50:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:50:15 --> Final output sent to browser
DEBUG - 2024-09-04 15:50:15 --> Total execution time: 0.1108
INFO - 2024-09-04 15:50:20 --> Config Class Initialized
INFO - 2024-09-04 15:50:20 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:50:20 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:50:20 --> Utf8 Class Initialized
INFO - 2024-09-04 15:50:20 --> URI Class Initialized
INFO - 2024-09-04 15:50:20 --> Router Class Initialized
INFO - 2024-09-04 15:50:20 --> Output Class Initialized
INFO - 2024-09-04 15:50:20 --> Security Class Initialized
DEBUG - 2024-09-04 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:50:20 --> Input Class Initialized
INFO - 2024-09-04 15:50:20 --> Language Class Initialized
INFO - 2024-09-04 15:50:20 --> Loader Class Initialized
INFO - 2024-09-04 15:50:20 --> Helper loaded: url_helper
INFO - 2024-09-04 15:50:20 --> Helper loaded: file_helper
INFO - 2024-09-04 15:50:20 --> Helper loaded: security_helper
INFO - 2024-09-04 15:50:20 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:50:20 --> Database Driver Class Initialized
INFO - 2024-09-04 15:50:20 --> Email Class Initialized
DEBUG - 2024-09-04 15:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:50:21 --> Helper loaded: form_helper
INFO - 2024-09-04 15:50:21 --> Form Validation Class Initialized
INFO - 2024-09-04 15:50:21 --> Controller Class Initialized
INFO - 2024-09-04 15:50:21 --> Model "User_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:50:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:50:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:50:21 --> Final output sent to browser
DEBUG - 2024-09-04 15:50:21 --> Total execution time: 0.0859
INFO - 2024-09-04 15:50:37 --> Config Class Initialized
INFO - 2024-09-04 15:50:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:50:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:50:37 --> Utf8 Class Initialized
INFO - 2024-09-04 15:50:37 --> URI Class Initialized
INFO - 2024-09-04 15:50:37 --> Router Class Initialized
INFO - 2024-09-04 15:50:37 --> Output Class Initialized
INFO - 2024-09-04 15:50:37 --> Security Class Initialized
DEBUG - 2024-09-04 15:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:50:37 --> Input Class Initialized
INFO - 2024-09-04 15:50:37 --> Language Class Initialized
INFO - 2024-09-04 15:50:37 --> Loader Class Initialized
INFO - 2024-09-04 15:50:37 --> Helper loaded: url_helper
INFO - 2024-09-04 15:50:37 --> Helper loaded: file_helper
INFO - 2024-09-04 15:50:37 --> Helper loaded: security_helper
INFO - 2024-09-04 15:50:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:50:37 --> Database Driver Class Initialized
INFO - 2024-09-04 15:50:37 --> Email Class Initialized
DEBUG - 2024-09-04 15:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:50:37 --> Helper loaded: form_helper
INFO - 2024-09-04 15:50:37 --> Form Validation Class Initialized
INFO - 2024-09-04 15:50:37 --> Controller Class Initialized
INFO - 2024-09-04 15:50:37 --> Model "User_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:50:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:50:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:50:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:50:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 15:50:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:50:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:50:37 --> Final output sent to browser
DEBUG - 2024-09-04 15:50:37 --> Total execution time: 0.1281
INFO - 2024-09-04 15:50:57 --> Config Class Initialized
INFO - 2024-09-04 15:50:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:50:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:50:57 --> Utf8 Class Initialized
INFO - 2024-09-04 15:50:57 --> URI Class Initialized
INFO - 2024-09-04 15:50:57 --> Router Class Initialized
INFO - 2024-09-04 15:50:57 --> Output Class Initialized
INFO - 2024-09-04 15:50:57 --> Security Class Initialized
DEBUG - 2024-09-04 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:50:57 --> Input Class Initialized
INFO - 2024-09-04 15:50:57 --> Language Class Initialized
INFO - 2024-09-04 15:50:57 --> Loader Class Initialized
INFO - 2024-09-04 15:50:57 --> Helper loaded: url_helper
INFO - 2024-09-04 15:50:57 --> Helper loaded: file_helper
INFO - 2024-09-04 15:50:57 --> Helper loaded: security_helper
INFO - 2024-09-04 15:50:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:50:57 --> Database Driver Class Initialized
INFO - 2024-09-04 15:50:57 --> Email Class Initialized
DEBUG - 2024-09-04 15:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:50:57 --> Helper loaded: form_helper
INFO - 2024-09-04 15:50:57 --> Form Validation Class Initialized
INFO - 2024-09-04 15:50:57 --> Controller Class Initialized
INFO - 2024-09-04 15:50:57 --> Model "User_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:50:57 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:50:58 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:50:58 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:50:58 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:50:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:50:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:50:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:50:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:50:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:50:58 --> Final output sent to browser
DEBUG - 2024-09-04 15:50:58 --> Total execution time: 0.1539
INFO - 2024-09-04 15:51:12 --> Config Class Initialized
INFO - 2024-09-04 15:51:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:51:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:51:12 --> Utf8 Class Initialized
INFO - 2024-09-04 15:51:12 --> URI Class Initialized
INFO - 2024-09-04 15:51:12 --> Router Class Initialized
INFO - 2024-09-04 15:51:12 --> Output Class Initialized
INFO - 2024-09-04 15:51:12 --> Security Class Initialized
DEBUG - 2024-09-04 15:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:51:12 --> Input Class Initialized
INFO - 2024-09-04 15:51:12 --> Language Class Initialized
INFO - 2024-09-04 15:51:12 --> Loader Class Initialized
INFO - 2024-09-04 15:51:12 --> Helper loaded: url_helper
INFO - 2024-09-04 15:51:12 --> Helper loaded: file_helper
INFO - 2024-09-04 15:51:12 --> Helper loaded: security_helper
INFO - 2024-09-04 15:51:12 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:51:12 --> Database Driver Class Initialized
INFO - 2024-09-04 15:51:12 --> Email Class Initialized
DEBUG - 2024-09-04 15:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:51:12 --> Helper loaded: form_helper
INFO - 2024-09-04 15:51:12 --> Form Validation Class Initialized
INFO - 2024-09-04 15:51:12 --> Controller Class Initialized
INFO - 2024-09-04 15:51:12 --> Model "User_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:51:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:51:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:51:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:51:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:51:12 --> Final output sent to browser
DEBUG - 2024-09-04 15:51:12 --> Total execution time: 0.2128
INFO - 2024-09-04 15:53:19 --> Config Class Initialized
INFO - 2024-09-04 15:53:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:53:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:53:19 --> Utf8 Class Initialized
INFO - 2024-09-04 15:53:19 --> URI Class Initialized
INFO - 2024-09-04 15:53:19 --> Router Class Initialized
INFO - 2024-09-04 15:53:19 --> Output Class Initialized
INFO - 2024-09-04 15:53:19 --> Security Class Initialized
DEBUG - 2024-09-04 15:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:53:19 --> Input Class Initialized
INFO - 2024-09-04 15:53:19 --> Language Class Initialized
INFO - 2024-09-04 15:53:19 --> Loader Class Initialized
INFO - 2024-09-04 15:53:19 --> Helper loaded: url_helper
INFO - 2024-09-04 15:53:19 --> Helper loaded: file_helper
INFO - 2024-09-04 15:53:19 --> Helper loaded: security_helper
INFO - 2024-09-04 15:53:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:53:19 --> Database Driver Class Initialized
INFO - 2024-09-04 15:53:19 --> Email Class Initialized
DEBUG - 2024-09-04 15:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:53:19 --> Helper loaded: form_helper
INFO - 2024-09-04 15:53:19 --> Form Validation Class Initialized
INFO - 2024-09-04 15:53:19 --> Controller Class Initialized
INFO - 2024-09-04 15:53:19 --> Model "User_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:53:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:53:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:53:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:53:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:53:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:53:20 --> Final output sent to browser
DEBUG - 2024-09-04 15:53:20 --> Total execution time: 0.1756
INFO - 2024-09-04 15:53:29 --> Config Class Initialized
INFO - 2024-09-04 15:53:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 15:53:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 15:53:29 --> Utf8 Class Initialized
INFO - 2024-09-04 15:53:29 --> URI Class Initialized
INFO - 2024-09-04 15:53:29 --> Router Class Initialized
INFO - 2024-09-04 15:53:29 --> Output Class Initialized
INFO - 2024-09-04 15:53:29 --> Security Class Initialized
DEBUG - 2024-09-04 15:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 15:53:29 --> Input Class Initialized
INFO - 2024-09-04 15:53:29 --> Language Class Initialized
INFO - 2024-09-04 15:53:29 --> Loader Class Initialized
INFO - 2024-09-04 15:53:29 --> Helper loaded: url_helper
INFO - 2024-09-04 15:53:29 --> Helper loaded: file_helper
INFO - 2024-09-04 15:53:29 --> Helper loaded: security_helper
INFO - 2024-09-04 15:53:29 --> Helper loaded: wpu_helper
INFO - 2024-09-04 15:53:29 --> Database Driver Class Initialized
INFO - 2024-09-04 15:53:29 --> Email Class Initialized
DEBUG - 2024-09-04 15:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 15:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 15:53:29 --> Helper loaded: form_helper
INFO - 2024-09-04 15:53:29 --> Form Validation Class Initialized
INFO - 2024-09-04 15:53:29 --> Controller Class Initialized
INFO - 2024-09-04 15:53:29 --> Model "User_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Faktur_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Supplier_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Jenis_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Barang_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 15:53:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 15:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 15:53:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 15:53:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 15:53:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 15:53:30 --> Final output sent to browser
DEBUG - 2024-09-04 15:53:30 --> Total execution time: 0.1732
INFO - 2024-09-04 16:01:04 --> Config Class Initialized
INFO - 2024-09-04 16:01:04 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:01:04 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:01:04 --> Utf8 Class Initialized
INFO - 2024-09-04 16:01:04 --> URI Class Initialized
INFO - 2024-09-04 16:01:04 --> Router Class Initialized
INFO - 2024-09-04 16:01:04 --> Output Class Initialized
INFO - 2024-09-04 16:01:04 --> Security Class Initialized
DEBUG - 2024-09-04 16:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:01:04 --> Input Class Initialized
INFO - 2024-09-04 16:01:04 --> Language Class Initialized
INFO - 2024-09-04 16:01:04 --> Loader Class Initialized
INFO - 2024-09-04 16:01:04 --> Helper loaded: url_helper
INFO - 2024-09-04 16:01:04 --> Helper loaded: file_helper
INFO - 2024-09-04 16:01:04 --> Helper loaded: security_helper
INFO - 2024-09-04 16:01:04 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:01:04 --> Database Driver Class Initialized
INFO - 2024-09-04 16:01:04 --> Email Class Initialized
DEBUG - 2024-09-04 16:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:01:04 --> Helper loaded: form_helper
INFO - 2024-09-04 16:01:04 --> Form Validation Class Initialized
INFO - 2024-09-04 16:01:04 --> Controller Class Initialized
INFO - 2024-09-04 16:01:04 --> Model "User_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:01:04 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:01:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:01:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:01:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:01:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:01:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:01:05 --> Final output sent to browser
DEBUG - 2024-09-04 16:01:05 --> Total execution time: 0.1475
INFO - 2024-09-04 16:01:10 --> Config Class Initialized
INFO - 2024-09-04 16:01:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:01:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:01:10 --> Utf8 Class Initialized
INFO - 2024-09-04 16:01:10 --> URI Class Initialized
INFO - 2024-09-04 16:01:10 --> Router Class Initialized
INFO - 2024-09-04 16:01:10 --> Output Class Initialized
INFO - 2024-09-04 16:01:10 --> Security Class Initialized
DEBUG - 2024-09-04 16:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:01:10 --> Input Class Initialized
INFO - 2024-09-04 16:01:10 --> Language Class Initialized
INFO - 2024-09-04 16:01:10 --> Loader Class Initialized
INFO - 2024-09-04 16:01:10 --> Helper loaded: url_helper
INFO - 2024-09-04 16:01:10 --> Helper loaded: file_helper
INFO - 2024-09-04 16:01:10 --> Helper loaded: security_helper
INFO - 2024-09-04 16:01:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:01:10 --> Database Driver Class Initialized
INFO - 2024-09-04 16:01:10 --> Email Class Initialized
DEBUG - 2024-09-04 16:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:01:10 --> Helper loaded: form_helper
INFO - 2024-09-04 16:01:10 --> Form Validation Class Initialized
INFO - 2024-09-04 16:01:10 --> Controller Class Initialized
INFO - 2024-09-04 16:01:10 --> Model "User_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:01:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:01:10 --> Final output sent to browser
DEBUG - 2024-09-04 16:01:10 --> Total execution time: 0.1449
INFO - 2024-09-04 16:01:13 --> Config Class Initialized
INFO - 2024-09-04 16:01:13 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:01:13 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:01:13 --> Utf8 Class Initialized
INFO - 2024-09-04 16:01:13 --> URI Class Initialized
INFO - 2024-09-04 16:01:13 --> Router Class Initialized
INFO - 2024-09-04 16:01:13 --> Output Class Initialized
INFO - 2024-09-04 16:01:13 --> Security Class Initialized
DEBUG - 2024-09-04 16:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:01:13 --> Input Class Initialized
INFO - 2024-09-04 16:01:13 --> Language Class Initialized
INFO - 2024-09-04 16:01:13 --> Loader Class Initialized
INFO - 2024-09-04 16:01:13 --> Helper loaded: url_helper
INFO - 2024-09-04 16:01:13 --> Helper loaded: file_helper
INFO - 2024-09-04 16:01:13 --> Helper loaded: security_helper
INFO - 2024-09-04 16:01:13 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:01:13 --> Database Driver Class Initialized
INFO - 2024-09-04 16:01:13 --> Email Class Initialized
DEBUG - 2024-09-04 16:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:01:13 --> Helper loaded: form_helper
INFO - 2024-09-04 16:01:13 --> Form Validation Class Initialized
INFO - 2024-09-04 16:01:13 --> Controller Class Initialized
INFO - 2024-09-04 16:01:13 --> Model "User_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:01:13 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:01:14 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:01:14 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:01:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:01:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:01:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:01:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:01:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:01:14 --> Final output sent to browser
DEBUG - 2024-09-04 16:01:14 --> Total execution time: 0.1477
INFO - 2024-09-04 16:02:16 --> Config Class Initialized
INFO - 2024-09-04 16:02:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:02:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:02:16 --> Utf8 Class Initialized
INFO - 2024-09-04 16:02:16 --> URI Class Initialized
INFO - 2024-09-04 16:02:16 --> Router Class Initialized
INFO - 2024-09-04 16:02:16 --> Output Class Initialized
INFO - 2024-09-04 16:02:16 --> Security Class Initialized
DEBUG - 2024-09-04 16:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:02:16 --> Input Class Initialized
INFO - 2024-09-04 16:02:16 --> Language Class Initialized
INFO - 2024-09-04 16:02:16 --> Loader Class Initialized
INFO - 2024-09-04 16:02:16 --> Helper loaded: url_helper
INFO - 2024-09-04 16:02:16 --> Helper loaded: file_helper
INFO - 2024-09-04 16:02:16 --> Helper loaded: security_helper
INFO - 2024-09-04 16:02:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:02:16 --> Database Driver Class Initialized
INFO - 2024-09-04 16:02:16 --> Email Class Initialized
DEBUG - 2024-09-04 16:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:02:16 --> Helper loaded: form_helper
INFO - 2024-09-04 16:02:16 --> Form Validation Class Initialized
INFO - 2024-09-04 16:02:16 --> Controller Class Initialized
INFO - 2024-09-04 16:02:16 --> Model "User_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:02:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:02:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:02:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:02:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:02:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:02:16 --> Final output sent to browser
DEBUG - 2024-09-04 16:02:16 --> Total execution time: 0.1605
INFO - 2024-09-04 16:02:34 --> Config Class Initialized
INFO - 2024-09-04 16:02:34 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:02:34 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:02:34 --> Utf8 Class Initialized
INFO - 2024-09-04 16:02:34 --> URI Class Initialized
INFO - 2024-09-04 16:02:34 --> Router Class Initialized
INFO - 2024-09-04 16:02:34 --> Output Class Initialized
INFO - 2024-09-04 16:02:34 --> Security Class Initialized
DEBUG - 2024-09-04 16:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:02:34 --> Input Class Initialized
INFO - 2024-09-04 16:02:34 --> Language Class Initialized
INFO - 2024-09-04 16:02:34 --> Loader Class Initialized
INFO - 2024-09-04 16:02:34 --> Helper loaded: url_helper
INFO - 2024-09-04 16:02:34 --> Helper loaded: file_helper
INFO - 2024-09-04 16:02:34 --> Helper loaded: security_helper
INFO - 2024-09-04 16:02:34 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:02:34 --> Database Driver Class Initialized
INFO - 2024-09-04 16:02:34 --> Email Class Initialized
DEBUG - 2024-09-04 16:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:02:34 --> Helper loaded: form_helper
INFO - 2024-09-04 16:02:34 --> Form Validation Class Initialized
INFO - 2024-09-04 16:02:34 --> Controller Class Initialized
INFO - 2024-09-04 16:02:34 --> Model "User_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:02:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:02:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:02:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:02:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:02:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:02:34 --> Final output sent to browser
DEBUG - 2024-09-04 16:02:34 --> Total execution time: 0.1255
INFO - 2024-09-04 16:02:42 --> Config Class Initialized
INFO - 2024-09-04 16:02:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:02:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:02:42 --> Utf8 Class Initialized
INFO - 2024-09-04 16:02:42 --> URI Class Initialized
INFO - 2024-09-04 16:02:42 --> Router Class Initialized
INFO - 2024-09-04 16:02:42 --> Output Class Initialized
INFO - 2024-09-04 16:02:42 --> Security Class Initialized
DEBUG - 2024-09-04 16:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:02:42 --> Input Class Initialized
INFO - 2024-09-04 16:02:42 --> Language Class Initialized
INFO - 2024-09-04 16:02:42 --> Loader Class Initialized
INFO - 2024-09-04 16:02:42 --> Helper loaded: url_helper
INFO - 2024-09-04 16:02:42 --> Helper loaded: file_helper
INFO - 2024-09-04 16:02:42 --> Helper loaded: security_helper
INFO - 2024-09-04 16:02:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:02:42 --> Database Driver Class Initialized
INFO - 2024-09-04 16:02:42 --> Email Class Initialized
DEBUG - 2024-09-04 16:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:02:42 --> Helper loaded: form_helper
INFO - 2024-09-04 16:02:42 --> Form Validation Class Initialized
INFO - 2024-09-04 16:02:42 --> Controller Class Initialized
INFO - 2024-09-04 16:02:42 --> Model "User_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:02:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:02:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:02:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:02:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:02:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:02:42 --> Final output sent to browser
DEBUG - 2024-09-04 16:02:42 --> Total execution time: 0.1763
INFO - 2024-09-04 16:03:00 --> Config Class Initialized
INFO - 2024-09-04 16:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:03:00 --> Utf8 Class Initialized
INFO - 2024-09-04 16:03:00 --> URI Class Initialized
INFO - 2024-09-04 16:03:00 --> Router Class Initialized
INFO - 2024-09-04 16:03:00 --> Output Class Initialized
INFO - 2024-09-04 16:03:00 --> Security Class Initialized
DEBUG - 2024-09-04 16:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:03:00 --> Input Class Initialized
INFO - 2024-09-04 16:03:00 --> Language Class Initialized
INFO - 2024-09-04 16:03:00 --> Loader Class Initialized
INFO - 2024-09-04 16:03:00 --> Helper loaded: url_helper
INFO - 2024-09-04 16:03:00 --> Helper loaded: file_helper
INFO - 2024-09-04 16:03:00 --> Helper loaded: security_helper
INFO - 2024-09-04 16:03:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:03:00 --> Database Driver Class Initialized
INFO - 2024-09-04 16:03:00 --> Email Class Initialized
DEBUG - 2024-09-04 16:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:03:00 --> Helper loaded: form_helper
INFO - 2024-09-04 16:03:00 --> Form Validation Class Initialized
INFO - 2024-09-04 16:03:00 --> Controller Class Initialized
INFO - 2024-09-04 16:03:00 --> Model "User_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:03:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:03:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:03:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:03:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:03:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:03:00 --> Final output sent to browser
DEBUG - 2024-09-04 16:03:00 --> Total execution time: 0.1484
INFO - 2024-09-04 16:03:08 --> Config Class Initialized
INFO - 2024-09-04 16:03:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:03:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:03:08 --> Utf8 Class Initialized
INFO - 2024-09-04 16:03:08 --> URI Class Initialized
INFO - 2024-09-04 16:03:08 --> Router Class Initialized
INFO - 2024-09-04 16:03:08 --> Output Class Initialized
INFO - 2024-09-04 16:03:08 --> Security Class Initialized
DEBUG - 2024-09-04 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:03:08 --> Input Class Initialized
INFO - 2024-09-04 16:03:08 --> Language Class Initialized
INFO - 2024-09-04 16:03:08 --> Loader Class Initialized
INFO - 2024-09-04 16:03:08 --> Helper loaded: url_helper
INFO - 2024-09-04 16:03:08 --> Helper loaded: file_helper
INFO - 2024-09-04 16:03:08 --> Helper loaded: security_helper
INFO - 2024-09-04 16:03:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:03:08 --> Database Driver Class Initialized
INFO - 2024-09-04 16:03:08 --> Email Class Initialized
DEBUG - 2024-09-04 16:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:03:08 --> Helper loaded: form_helper
INFO - 2024-09-04 16:03:08 --> Form Validation Class Initialized
INFO - 2024-09-04 16:03:08 --> Controller Class Initialized
INFO - 2024-09-04 16:03:08 --> Model "User_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:03:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:03:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:03:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:03:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:03:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:03:08 --> Final output sent to browser
DEBUG - 2024-09-04 16:03:08 --> Total execution time: 0.1415
INFO - 2024-09-04 16:05:41 --> Config Class Initialized
INFO - 2024-09-04 16:05:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:05:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:05:41 --> Utf8 Class Initialized
INFO - 2024-09-04 16:05:41 --> URI Class Initialized
INFO - 2024-09-04 16:05:41 --> Router Class Initialized
INFO - 2024-09-04 16:05:41 --> Output Class Initialized
INFO - 2024-09-04 16:05:41 --> Security Class Initialized
DEBUG - 2024-09-04 16:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:05:41 --> Input Class Initialized
INFO - 2024-09-04 16:05:41 --> Language Class Initialized
INFO - 2024-09-04 16:05:41 --> Loader Class Initialized
INFO - 2024-09-04 16:05:41 --> Helper loaded: url_helper
INFO - 2024-09-04 16:05:41 --> Helper loaded: file_helper
INFO - 2024-09-04 16:05:41 --> Helper loaded: security_helper
INFO - 2024-09-04 16:05:41 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:05:41 --> Database Driver Class Initialized
INFO - 2024-09-04 16:05:41 --> Email Class Initialized
DEBUG - 2024-09-04 16:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:05:41 --> Helper loaded: form_helper
INFO - 2024-09-04 16:05:41 --> Form Validation Class Initialized
INFO - 2024-09-04 16:05:41 --> Controller Class Initialized
INFO - 2024-09-04 16:05:41 --> Model "User_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:05:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:05:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:05:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:05:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:05:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:05:41 --> Final output sent to browser
DEBUG - 2024-09-04 16:05:41 --> Total execution time: 0.1344
INFO - 2024-09-04 16:06:16 --> Config Class Initialized
INFO - 2024-09-04 16:06:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:06:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:06:16 --> Utf8 Class Initialized
INFO - 2024-09-04 16:06:16 --> URI Class Initialized
INFO - 2024-09-04 16:06:16 --> Router Class Initialized
INFO - 2024-09-04 16:06:16 --> Output Class Initialized
INFO - 2024-09-04 16:06:16 --> Security Class Initialized
DEBUG - 2024-09-04 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:06:16 --> Input Class Initialized
INFO - 2024-09-04 16:06:16 --> Language Class Initialized
INFO - 2024-09-04 16:06:16 --> Loader Class Initialized
INFO - 2024-09-04 16:06:16 --> Helper loaded: url_helper
INFO - 2024-09-04 16:06:16 --> Helper loaded: file_helper
INFO - 2024-09-04 16:06:16 --> Helper loaded: security_helper
INFO - 2024-09-04 16:06:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:06:16 --> Database Driver Class Initialized
INFO - 2024-09-04 16:06:16 --> Email Class Initialized
DEBUG - 2024-09-04 16:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:06:16 --> Helper loaded: form_helper
INFO - 2024-09-04 16:06:16 --> Form Validation Class Initialized
INFO - 2024-09-04 16:06:16 --> Controller Class Initialized
INFO - 2024-09-04 16:06:16 --> Model "User_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:06:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:06:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:06:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:06:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:06:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:06:16 --> Final output sent to browser
DEBUG - 2024-09-04 16:06:16 --> Total execution time: 0.1486
INFO - 2024-09-04 16:06:38 --> Config Class Initialized
INFO - 2024-09-04 16:06:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:06:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:06:38 --> Utf8 Class Initialized
INFO - 2024-09-04 16:06:38 --> URI Class Initialized
INFO - 2024-09-04 16:06:38 --> Router Class Initialized
INFO - 2024-09-04 16:06:38 --> Output Class Initialized
INFO - 2024-09-04 16:06:38 --> Security Class Initialized
DEBUG - 2024-09-04 16:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:06:38 --> Input Class Initialized
INFO - 2024-09-04 16:06:38 --> Language Class Initialized
INFO - 2024-09-04 16:06:38 --> Loader Class Initialized
INFO - 2024-09-04 16:06:38 --> Helper loaded: url_helper
INFO - 2024-09-04 16:06:38 --> Helper loaded: file_helper
INFO - 2024-09-04 16:06:38 --> Helper loaded: security_helper
INFO - 2024-09-04 16:06:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:06:38 --> Database Driver Class Initialized
INFO - 2024-09-04 16:06:38 --> Email Class Initialized
DEBUG - 2024-09-04 16:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:06:38 --> Helper loaded: form_helper
INFO - 2024-09-04 16:06:38 --> Form Validation Class Initialized
INFO - 2024-09-04 16:06:38 --> Controller Class Initialized
INFO - 2024-09-04 16:06:38 --> Model "User_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:06:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:06:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:06:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:06:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:06:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:06:38 --> Final output sent to browser
DEBUG - 2024-09-04 16:06:38 --> Total execution time: 0.1504
INFO - 2024-09-04 16:07:21 --> Config Class Initialized
INFO - 2024-09-04 16:07:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:07:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:07:21 --> Utf8 Class Initialized
INFO - 2024-09-04 16:07:21 --> URI Class Initialized
INFO - 2024-09-04 16:07:21 --> Router Class Initialized
INFO - 2024-09-04 16:07:21 --> Output Class Initialized
INFO - 2024-09-04 16:07:21 --> Security Class Initialized
DEBUG - 2024-09-04 16:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:07:21 --> Input Class Initialized
INFO - 2024-09-04 16:07:21 --> Language Class Initialized
INFO - 2024-09-04 16:07:21 --> Loader Class Initialized
INFO - 2024-09-04 16:07:21 --> Helper loaded: url_helper
INFO - 2024-09-04 16:07:21 --> Helper loaded: file_helper
INFO - 2024-09-04 16:07:21 --> Helper loaded: security_helper
INFO - 2024-09-04 16:07:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:07:21 --> Database Driver Class Initialized
INFO - 2024-09-04 16:07:21 --> Email Class Initialized
DEBUG - 2024-09-04 16:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:07:21 --> Helper loaded: form_helper
INFO - 2024-09-04 16:07:21 --> Form Validation Class Initialized
INFO - 2024-09-04 16:07:21 --> Controller Class Initialized
INFO - 2024-09-04 16:07:21 --> Model "User_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:07:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:07:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:07:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:07:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:07:21 --> Final output sent to browser
DEBUG - 2024-09-04 16:07:21 --> Total execution time: 0.1531
INFO - 2024-09-04 16:09:43 --> Config Class Initialized
INFO - 2024-09-04 16:09:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:09:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:09:43 --> Utf8 Class Initialized
INFO - 2024-09-04 16:09:43 --> URI Class Initialized
INFO - 2024-09-04 16:09:43 --> Router Class Initialized
INFO - 2024-09-04 16:09:43 --> Output Class Initialized
INFO - 2024-09-04 16:09:43 --> Security Class Initialized
DEBUG - 2024-09-04 16:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:09:43 --> Input Class Initialized
INFO - 2024-09-04 16:09:43 --> Language Class Initialized
INFO - 2024-09-04 16:09:43 --> Loader Class Initialized
INFO - 2024-09-04 16:09:43 --> Helper loaded: url_helper
INFO - 2024-09-04 16:09:43 --> Helper loaded: file_helper
INFO - 2024-09-04 16:09:43 --> Helper loaded: security_helper
INFO - 2024-09-04 16:09:43 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:09:43 --> Database Driver Class Initialized
INFO - 2024-09-04 16:09:43 --> Email Class Initialized
DEBUG - 2024-09-04 16:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:09:43 --> Helper loaded: form_helper
INFO - 2024-09-04 16:09:43 --> Form Validation Class Initialized
INFO - 2024-09-04 16:09:43 --> Controller Class Initialized
INFO - 2024-09-04 16:09:43 --> Model "User_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:09:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:09:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:09:43 --> Final output sent to browser
DEBUG - 2024-09-04 16:09:43 --> Total execution time: 0.1675
INFO - 2024-09-04 16:09:52 --> Config Class Initialized
INFO - 2024-09-04 16:09:52 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:09:52 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:09:52 --> Utf8 Class Initialized
INFO - 2024-09-04 16:09:52 --> URI Class Initialized
INFO - 2024-09-04 16:09:52 --> Router Class Initialized
INFO - 2024-09-04 16:09:52 --> Output Class Initialized
INFO - 2024-09-04 16:09:52 --> Security Class Initialized
DEBUG - 2024-09-04 16:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:09:52 --> Input Class Initialized
INFO - 2024-09-04 16:09:52 --> Language Class Initialized
INFO - 2024-09-04 16:09:52 --> Loader Class Initialized
INFO - 2024-09-04 16:09:52 --> Helper loaded: url_helper
INFO - 2024-09-04 16:09:52 --> Helper loaded: file_helper
INFO - 2024-09-04 16:09:52 --> Helper loaded: security_helper
INFO - 2024-09-04 16:09:52 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:09:52 --> Database Driver Class Initialized
INFO - 2024-09-04 16:09:52 --> Email Class Initialized
DEBUG - 2024-09-04 16:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:09:52 --> Helper loaded: form_helper
INFO - 2024-09-04 16:09:52 --> Form Validation Class Initialized
INFO - 2024-09-04 16:09:52 --> Controller Class Initialized
INFO - 2024-09-04 16:09:52 --> Model "User_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:09:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:09:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:09:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:09:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:09:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:09:52 --> Final output sent to browser
DEBUG - 2024-09-04 16:09:52 --> Total execution time: 0.1048
INFO - 2024-09-04 16:10:12 --> Config Class Initialized
INFO - 2024-09-04 16:10:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:10:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:10:12 --> Utf8 Class Initialized
INFO - 2024-09-04 16:10:12 --> URI Class Initialized
INFO - 2024-09-04 16:10:12 --> Router Class Initialized
INFO - 2024-09-04 16:10:12 --> Output Class Initialized
INFO - 2024-09-04 16:10:12 --> Security Class Initialized
DEBUG - 2024-09-04 16:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:10:12 --> Input Class Initialized
INFO - 2024-09-04 16:10:12 --> Language Class Initialized
INFO - 2024-09-04 16:10:12 --> Loader Class Initialized
INFO - 2024-09-04 16:10:12 --> Helper loaded: url_helper
INFO - 2024-09-04 16:10:12 --> Helper loaded: file_helper
INFO - 2024-09-04 16:10:12 --> Helper loaded: security_helper
INFO - 2024-09-04 16:10:12 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:10:12 --> Database Driver Class Initialized
INFO - 2024-09-04 16:10:12 --> Email Class Initialized
DEBUG - 2024-09-04 16:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:10:12 --> Helper loaded: form_helper
INFO - 2024-09-04 16:10:12 --> Form Validation Class Initialized
INFO - 2024-09-04 16:10:12 --> Controller Class Initialized
INFO - 2024-09-04 16:10:12 --> Model "User_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:10:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:10:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:10:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:10:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:10:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:10:12 --> Final output sent to browser
DEBUG - 2024-09-04 16:10:12 --> Total execution time: 0.1311
INFO - 2024-09-04 16:14:33 --> Config Class Initialized
INFO - 2024-09-04 16:14:33 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:14:33 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:14:33 --> Utf8 Class Initialized
INFO - 2024-09-04 16:14:33 --> URI Class Initialized
INFO - 2024-09-04 16:14:33 --> Router Class Initialized
INFO - 2024-09-04 16:14:33 --> Output Class Initialized
INFO - 2024-09-04 16:14:33 --> Security Class Initialized
DEBUG - 2024-09-04 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:14:33 --> Input Class Initialized
INFO - 2024-09-04 16:14:33 --> Language Class Initialized
INFO - 2024-09-04 16:14:33 --> Loader Class Initialized
INFO - 2024-09-04 16:14:33 --> Helper loaded: url_helper
INFO - 2024-09-04 16:14:33 --> Helper loaded: file_helper
INFO - 2024-09-04 16:14:33 --> Helper loaded: security_helper
INFO - 2024-09-04 16:14:33 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:14:33 --> Database Driver Class Initialized
INFO - 2024-09-04 16:14:33 --> Email Class Initialized
DEBUG - 2024-09-04 16:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:14:34 --> Helper loaded: form_helper
INFO - 2024-09-04 16:14:34 --> Form Validation Class Initialized
INFO - 2024-09-04 16:14:34 --> Controller Class Initialized
INFO - 2024-09-04 16:14:34 --> Model "User_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:14:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:14:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:14:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:14:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:14:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:14:34 --> Final output sent to browser
DEBUG - 2024-09-04 16:14:34 --> Total execution time: 0.1553
INFO - 2024-09-04 16:16:11 --> Config Class Initialized
INFO - 2024-09-04 16:16:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:16:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:16:11 --> Utf8 Class Initialized
INFO - 2024-09-04 16:16:11 --> URI Class Initialized
INFO - 2024-09-04 16:16:11 --> Router Class Initialized
INFO - 2024-09-04 16:16:11 --> Output Class Initialized
INFO - 2024-09-04 16:16:11 --> Security Class Initialized
DEBUG - 2024-09-04 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:16:11 --> Input Class Initialized
INFO - 2024-09-04 16:16:11 --> Language Class Initialized
INFO - 2024-09-04 16:16:11 --> Loader Class Initialized
INFO - 2024-09-04 16:16:11 --> Helper loaded: url_helper
INFO - 2024-09-04 16:16:11 --> Helper loaded: file_helper
INFO - 2024-09-04 16:16:11 --> Helper loaded: security_helper
INFO - 2024-09-04 16:16:11 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:16:11 --> Database Driver Class Initialized
INFO - 2024-09-04 16:16:11 --> Email Class Initialized
DEBUG - 2024-09-04 16:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:16:11 --> Helper loaded: form_helper
INFO - 2024-09-04 16:16:11 --> Form Validation Class Initialized
INFO - 2024-09-04 16:16:11 --> Controller Class Initialized
INFO - 2024-09-04 16:16:11 --> Model "User_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:16:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:16:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:16:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:16:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:16:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:16:11 --> Final output sent to browser
DEBUG - 2024-09-04 16:16:11 --> Total execution time: 0.1348
INFO - 2024-09-04 16:16:34 --> Config Class Initialized
INFO - 2024-09-04 16:16:34 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:16:34 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:16:34 --> Utf8 Class Initialized
INFO - 2024-09-04 16:16:34 --> URI Class Initialized
INFO - 2024-09-04 16:16:34 --> Router Class Initialized
INFO - 2024-09-04 16:16:34 --> Output Class Initialized
INFO - 2024-09-04 16:16:34 --> Security Class Initialized
DEBUG - 2024-09-04 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:16:34 --> Input Class Initialized
INFO - 2024-09-04 16:16:34 --> Language Class Initialized
INFO - 2024-09-04 16:16:34 --> Loader Class Initialized
INFO - 2024-09-04 16:16:34 --> Helper loaded: url_helper
INFO - 2024-09-04 16:16:34 --> Helper loaded: file_helper
INFO - 2024-09-04 16:16:34 --> Helper loaded: security_helper
INFO - 2024-09-04 16:16:34 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:16:34 --> Database Driver Class Initialized
INFO - 2024-09-04 16:16:34 --> Email Class Initialized
DEBUG - 2024-09-04 16:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:16:34 --> Helper loaded: form_helper
INFO - 2024-09-04 16:16:34 --> Form Validation Class Initialized
INFO - 2024-09-04 16:16:34 --> Controller Class Initialized
INFO - 2024-09-04 16:16:34 --> Model "User_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:16:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:16:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:16:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:16:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:16:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:16:34 --> Final output sent to browser
DEBUG - 2024-09-04 16:16:34 --> Total execution time: 0.1828
INFO - 2024-09-04 16:18:21 --> Config Class Initialized
INFO - 2024-09-04 16:18:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:18:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:18:21 --> Utf8 Class Initialized
INFO - 2024-09-04 16:18:21 --> URI Class Initialized
INFO - 2024-09-04 16:18:21 --> Router Class Initialized
INFO - 2024-09-04 16:18:21 --> Output Class Initialized
INFO - 2024-09-04 16:18:21 --> Security Class Initialized
DEBUG - 2024-09-04 16:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:18:21 --> Input Class Initialized
INFO - 2024-09-04 16:18:21 --> Language Class Initialized
INFO - 2024-09-04 16:18:21 --> Loader Class Initialized
INFO - 2024-09-04 16:18:21 --> Helper loaded: url_helper
INFO - 2024-09-04 16:18:21 --> Helper loaded: file_helper
INFO - 2024-09-04 16:18:21 --> Helper loaded: security_helper
INFO - 2024-09-04 16:18:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:18:21 --> Database Driver Class Initialized
INFO - 2024-09-04 16:18:21 --> Email Class Initialized
DEBUG - 2024-09-04 16:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:18:21 --> Helper loaded: form_helper
INFO - 2024-09-04 16:18:21 --> Form Validation Class Initialized
INFO - 2024-09-04 16:18:21 --> Controller Class Initialized
INFO - 2024-09-04 16:18:21 --> Model "User_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:18:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:18:22 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:18:22 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:18:22 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:18:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:18:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:18:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:18:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:18:22 --> Final output sent to browser
DEBUG - 2024-09-04 16:18:22 --> Total execution time: 0.1639
INFO - 2024-09-04 16:18:23 --> Config Class Initialized
INFO - 2024-09-04 16:18:23 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:18:23 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:18:23 --> Utf8 Class Initialized
INFO - 2024-09-04 16:18:23 --> URI Class Initialized
INFO - 2024-09-04 16:18:23 --> Router Class Initialized
INFO - 2024-09-04 16:18:23 --> Output Class Initialized
INFO - 2024-09-04 16:18:23 --> Security Class Initialized
DEBUG - 2024-09-04 16:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:18:23 --> Input Class Initialized
INFO - 2024-09-04 16:18:23 --> Language Class Initialized
ERROR - 2024-09-04 16:18:23 --> 404 Page Not Found: Data/path
INFO - 2024-09-04 16:22:09 --> Config Class Initialized
INFO - 2024-09-04 16:22:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:22:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:22:09 --> Utf8 Class Initialized
INFO - 2024-09-04 16:22:09 --> URI Class Initialized
INFO - 2024-09-04 16:22:09 --> Router Class Initialized
INFO - 2024-09-04 16:22:09 --> Output Class Initialized
INFO - 2024-09-04 16:22:09 --> Security Class Initialized
DEBUG - 2024-09-04 16:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:22:09 --> Input Class Initialized
INFO - 2024-09-04 16:22:09 --> Language Class Initialized
INFO - 2024-09-04 16:22:09 --> Loader Class Initialized
INFO - 2024-09-04 16:22:09 --> Helper loaded: url_helper
INFO - 2024-09-04 16:22:09 --> Helper loaded: file_helper
INFO - 2024-09-04 16:22:09 --> Helper loaded: security_helper
INFO - 2024-09-04 16:22:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:22:09 --> Database Driver Class Initialized
INFO - 2024-09-04 16:22:09 --> Email Class Initialized
DEBUG - 2024-09-04 16:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:22:09 --> Helper loaded: form_helper
INFO - 2024-09-04 16:22:09 --> Form Validation Class Initialized
INFO - 2024-09-04 16:22:09 --> Controller Class Initialized
INFO - 2024-09-04 16:22:09 --> Model "User_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:22:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:22:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:22:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:22:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:22:09 --> Final output sent to browser
DEBUG - 2024-09-04 16:22:09 --> Total execution time: 0.1821
INFO - 2024-09-04 16:22:27 --> Config Class Initialized
INFO - 2024-09-04 16:22:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:22:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:22:27 --> Utf8 Class Initialized
INFO - 2024-09-04 16:22:27 --> URI Class Initialized
INFO - 2024-09-04 16:22:27 --> Router Class Initialized
INFO - 2024-09-04 16:22:27 --> Output Class Initialized
INFO - 2024-09-04 16:22:27 --> Security Class Initialized
DEBUG - 2024-09-04 16:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:22:27 --> Input Class Initialized
INFO - 2024-09-04 16:22:27 --> Language Class Initialized
INFO - 2024-09-04 16:22:27 --> Loader Class Initialized
INFO - 2024-09-04 16:22:27 --> Helper loaded: url_helper
INFO - 2024-09-04 16:22:27 --> Helper loaded: file_helper
INFO - 2024-09-04 16:22:27 --> Helper loaded: security_helper
INFO - 2024-09-04 16:22:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:22:27 --> Database Driver Class Initialized
INFO - 2024-09-04 16:22:27 --> Email Class Initialized
DEBUG - 2024-09-04 16:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:22:27 --> Helper loaded: form_helper
INFO - 2024-09-04 16:22:27 --> Form Validation Class Initialized
INFO - 2024-09-04 16:22:27 --> Controller Class Initialized
INFO - 2024-09-04 16:22:27 --> Model "User_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:22:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:22:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:22:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:22:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:22:27 --> Final output sent to browser
DEBUG - 2024-09-04 16:22:27 --> Total execution time: 0.1561
INFO - 2024-09-04 16:22:32 --> Config Class Initialized
INFO - 2024-09-04 16:22:32 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:22:32 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:22:32 --> Utf8 Class Initialized
INFO - 2024-09-04 16:22:32 --> URI Class Initialized
INFO - 2024-09-04 16:22:32 --> Router Class Initialized
INFO - 2024-09-04 16:22:32 --> Output Class Initialized
INFO - 2024-09-04 16:22:32 --> Security Class Initialized
DEBUG - 2024-09-04 16:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:22:32 --> Input Class Initialized
INFO - 2024-09-04 16:22:32 --> Language Class Initialized
INFO - 2024-09-04 16:22:32 --> Loader Class Initialized
INFO - 2024-09-04 16:22:32 --> Helper loaded: url_helper
INFO - 2024-09-04 16:22:32 --> Helper loaded: file_helper
INFO - 2024-09-04 16:22:32 --> Helper loaded: security_helper
INFO - 2024-09-04 16:22:32 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:22:32 --> Database Driver Class Initialized
INFO - 2024-09-04 16:22:32 --> Email Class Initialized
DEBUG - 2024-09-04 16:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:22:32 --> Helper loaded: form_helper
INFO - 2024-09-04 16:22:32 --> Form Validation Class Initialized
INFO - 2024-09-04 16:22:32 --> Controller Class Initialized
INFO - 2024-09-04 16:22:32 --> Model "User_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:22:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:22:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:22:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:22:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:22:32 --> Final output sent to browser
DEBUG - 2024-09-04 16:22:32 --> Total execution time: 0.1461
INFO - 2024-09-04 16:23:30 --> Config Class Initialized
INFO - 2024-09-04 16:23:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:23:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:23:30 --> Utf8 Class Initialized
INFO - 2024-09-04 16:23:30 --> URI Class Initialized
INFO - 2024-09-04 16:23:30 --> Router Class Initialized
INFO - 2024-09-04 16:23:30 --> Output Class Initialized
INFO - 2024-09-04 16:23:30 --> Security Class Initialized
DEBUG - 2024-09-04 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:23:30 --> Input Class Initialized
INFO - 2024-09-04 16:23:30 --> Language Class Initialized
INFO - 2024-09-04 16:23:30 --> Loader Class Initialized
INFO - 2024-09-04 16:23:30 --> Helper loaded: url_helper
INFO - 2024-09-04 16:23:30 --> Helper loaded: file_helper
INFO - 2024-09-04 16:23:30 --> Helper loaded: security_helper
INFO - 2024-09-04 16:23:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:23:30 --> Database Driver Class Initialized
INFO - 2024-09-04 16:23:30 --> Email Class Initialized
DEBUG - 2024-09-04 16:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:23:30 --> Helper loaded: form_helper
INFO - 2024-09-04 16:23:30 --> Form Validation Class Initialized
INFO - 2024-09-04 16:23:30 --> Controller Class Initialized
INFO - 2024-09-04 16:23:30 --> Model "User_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:23:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:23:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:23:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:23:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:23:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:23:30 --> Final output sent to browser
DEBUG - 2024-09-04 16:23:30 --> Total execution time: 0.1649
INFO - 2024-09-04 16:23:57 --> Config Class Initialized
INFO - 2024-09-04 16:23:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:23:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:23:57 --> Utf8 Class Initialized
INFO - 2024-09-04 16:23:57 --> URI Class Initialized
INFO - 2024-09-04 16:23:57 --> Router Class Initialized
INFO - 2024-09-04 16:23:57 --> Output Class Initialized
INFO - 2024-09-04 16:23:57 --> Security Class Initialized
DEBUG - 2024-09-04 16:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:23:57 --> Input Class Initialized
INFO - 2024-09-04 16:23:57 --> Language Class Initialized
INFO - 2024-09-04 16:23:57 --> Loader Class Initialized
INFO - 2024-09-04 16:23:57 --> Helper loaded: url_helper
INFO - 2024-09-04 16:23:57 --> Helper loaded: file_helper
INFO - 2024-09-04 16:23:57 --> Helper loaded: security_helper
INFO - 2024-09-04 16:23:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:23:57 --> Database Driver Class Initialized
INFO - 2024-09-04 16:23:57 --> Email Class Initialized
DEBUG - 2024-09-04 16:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:23:57 --> Helper loaded: form_helper
INFO - 2024-09-04 16:23:57 --> Form Validation Class Initialized
INFO - 2024-09-04 16:23:57 --> Controller Class Initialized
INFO - 2024-09-04 16:23:57 --> Model "User_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:23:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:23:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:23:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:23:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:23:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:23:58 --> Final output sent to browser
DEBUG - 2024-09-04 16:23:58 --> Total execution time: 0.1318
INFO - 2024-09-04 16:26:18 --> Config Class Initialized
INFO - 2024-09-04 16:26:18 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:26:18 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:26:18 --> Utf8 Class Initialized
INFO - 2024-09-04 16:26:18 --> URI Class Initialized
INFO - 2024-09-04 16:26:18 --> Router Class Initialized
INFO - 2024-09-04 16:26:18 --> Output Class Initialized
INFO - 2024-09-04 16:26:18 --> Security Class Initialized
DEBUG - 2024-09-04 16:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:26:18 --> Input Class Initialized
INFO - 2024-09-04 16:26:18 --> Language Class Initialized
INFO - 2024-09-04 16:26:18 --> Loader Class Initialized
INFO - 2024-09-04 16:26:18 --> Helper loaded: url_helper
INFO - 2024-09-04 16:26:18 --> Helper loaded: file_helper
INFO - 2024-09-04 16:26:18 --> Helper loaded: security_helper
INFO - 2024-09-04 16:26:18 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:26:18 --> Database Driver Class Initialized
INFO - 2024-09-04 16:26:18 --> Email Class Initialized
DEBUG - 2024-09-04 16:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:26:18 --> Helper loaded: form_helper
INFO - 2024-09-04 16:26:18 --> Form Validation Class Initialized
INFO - 2024-09-04 16:26:18 --> Controller Class Initialized
INFO - 2024-09-04 16:26:18 --> Model "User_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:26:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:26:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:26:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:26:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:26:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:26:18 --> Final output sent to browser
DEBUG - 2024-09-04 16:26:18 --> Total execution time: 0.1084
INFO - 2024-09-04 16:26:51 --> Config Class Initialized
INFO - 2024-09-04 16:26:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:26:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:26:51 --> Utf8 Class Initialized
INFO - 2024-09-04 16:26:51 --> URI Class Initialized
INFO - 2024-09-04 16:26:51 --> Router Class Initialized
INFO - 2024-09-04 16:26:51 --> Output Class Initialized
INFO - 2024-09-04 16:26:51 --> Security Class Initialized
DEBUG - 2024-09-04 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:26:51 --> Input Class Initialized
INFO - 2024-09-04 16:26:51 --> Language Class Initialized
INFO - 2024-09-04 16:26:51 --> Loader Class Initialized
INFO - 2024-09-04 16:26:51 --> Helper loaded: url_helper
INFO - 2024-09-04 16:26:51 --> Helper loaded: file_helper
INFO - 2024-09-04 16:26:51 --> Helper loaded: security_helper
INFO - 2024-09-04 16:26:51 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:26:51 --> Database Driver Class Initialized
INFO - 2024-09-04 16:26:51 --> Email Class Initialized
DEBUG - 2024-09-04 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:26:51 --> Helper loaded: form_helper
INFO - 2024-09-04 16:26:51 --> Form Validation Class Initialized
INFO - 2024-09-04 16:26:51 --> Controller Class Initialized
INFO - 2024-09-04 16:26:51 --> Model "User_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:26:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:26:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:26:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:26:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:26:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:26:51 --> Final output sent to browser
DEBUG - 2024-09-04 16:26:51 --> Total execution time: 0.2221
INFO - 2024-09-04 16:26:51 --> Config Class Initialized
INFO - 2024-09-04 16:26:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:26:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:26:51 --> Utf8 Class Initialized
INFO - 2024-09-04 16:26:51 --> URI Class Initialized
INFO - 2024-09-04 16:26:51 --> Router Class Initialized
INFO - 2024-09-04 16:26:51 --> Output Class Initialized
INFO - 2024-09-04 16:26:51 --> Security Class Initialized
DEBUG - 2024-09-04 16:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:26:51 --> Input Class Initialized
INFO - 2024-09-04 16:26:51 --> Language Class Initialized
ERROR - 2024-09-04 16:26:51 --> 404 Page Not Found: Data/path
INFO - 2024-09-04 16:26:56 --> Config Class Initialized
INFO - 2024-09-04 16:26:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:26:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:26:56 --> Utf8 Class Initialized
INFO - 2024-09-04 16:26:56 --> URI Class Initialized
INFO - 2024-09-04 16:26:56 --> Router Class Initialized
INFO - 2024-09-04 16:26:56 --> Output Class Initialized
INFO - 2024-09-04 16:26:56 --> Security Class Initialized
DEBUG - 2024-09-04 16:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:26:56 --> Input Class Initialized
INFO - 2024-09-04 16:26:56 --> Language Class Initialized
INFO - 2024-09-04 16:26:56 --> Loader Class Initialized
INFO - 2024-09-04 16:26:56 --> Helper loaded: url_helper
INFO - 2024-09-04 16:26:56 --> Helper loaded: file_helper
INFO - 2024-09-04 16:26:56 --> Helper loaded: security_helper
INFO - 2024-09-04 16:26:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:26:56 --> Database Driver Class Initialized
INFO - 2024-09-04 16:26:56 --> Email Class Initialized
DEBUG - 2024-09-04 16:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:26:56 --> Helper loaded: form_helper
INFO - 2024-09-04 16:26:56 --> Form Validation Class Initialized
INFO - 2024-09-04 16:26:56 --> Controller Class Initialized
INFO - 2024-09-04 16:26:56 --> Model "User_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:26:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:26:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:26:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:26:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:26:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:26:57 --> Final output sent to browser
DEBUG - 2024-09-04 16:26:57 --> Total execution time: 0.0994
INFO - 2024-09-04 16:27:35 --> Config Class Initialized
INFO - 2024-09-04 16:27:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:27:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:27:35 --> Utf8 Class Initialized
INFO - 2024-09-04 16:27:35 --> URI Class Initialized
INFO - 2024-09-04 16:27:35 --> Router Class Initialized
INFO - 2024-09-04 16:27:35 --> Output Class Initialized
INFO - 2024-09-04 16:27:35 --> Security Class Initialized
DEBUG - 2024-09-04 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:27:35 --> Input Class Initialized
INFO - 2024-09-04 16:27:35 --> Language Class Initialized
INFO - 2024-09-04 16:27:35 --> Loader Class Initialized
INFO - 2024-09-04 16:27:35 --> Helper loaded: url_helper
INFO - 2024-09-04 16:27:35 --> Helper loaded: file_helper
INFO - 2024-09-04 16:27:35 --> Helper loaded: security_helper
INFO - 2024-09-04 16:27:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:27:35 --> Database Driver Class Initialized
INFO - 2024-09-04 16:27:35 --> Email Class Initialized
DEBUG - 2024-09-04 16:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:27:35 --> Helper loaded: form_helper
INFO - 2024-09-04 16:27:35 --> Form Validation Class Initialized
INFO - 2024-09-04 16:27:35 --> Controller Class Initialized
INFO - 2024-09-04 16:27:35 --> Model "User_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:27:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:27:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:27:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:27:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:27:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:27:35 --> Final output sent to browser
DEBUG - 2024-09-04 16:27:35 --> Total execution time: 0.1153
INFO - 2024-09-04 16:27:45 --> Config Class Initialized
INFO - 2024-09-04 16:27:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:27:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:27:45 --> Utf8 Class Initialized
INFO - 2024-09-04 16:27:45 --> URI Class Initialized
INFO - 2024-09-04 16:27:45 --> Router Class Initialized
INFO - 2024-09-04 16:27:45 --> Output Class Initialized
INFO - 2024-09-04 16:27:45 --> Security Class Initialized
DEBUG - 2024-09-04 16:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:27:45 --> Input Class Initialized
INFO - 2024-09-04 16:27:45 --> Language Class Initialized
INFO - 2024-09-04 16:27:45 --> Loader Class Initialized
INFO - 2024-09-04 16:27:45 --> Helper loaded: url_helper
INFO - 2024-09-04 16:27:45 --> Helper loaded: file_helper
INFO - 2024-09-04 16:27:45 --> Helper loaded: security_helper
INFO - 2024-09-04 16:27:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:27:45 --> Database Driver Class Initialized
INFO - 2024-09-04 16:27:45 --> Email Class Initialized
DEBUG - 2024-09-04 16:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:27:45 --> Helper loaded: form_helper
INFO - 2024-09-04 16:27:45 --> Form Validation Class Initialized
INFO - 2024-09-04 16:27:45 --> Controller Class Initialized
INFO - 2024-09-04 16:27:45 --> Model "User_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:27:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:27:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:27:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:27:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:27:45 --> Final output sent to browser
DEBUG - 2024-09-04 16:27:45 --> Total execution time: 0.1519
INFO - 2024-09-04 16:28:26 --> Config Class Initialized
INFO - 2024-09-04 16:28:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:28:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:28:26 --> Utf8 Class Initialized
INFO - 2024-09-04 16:28:26 --> URI Class Initialized
INFO - 2024-09-04 16:28:26 --> Router Class Initialized
INFO - 2024-09-04 16:28:26 --> Output Class Initialized
INFO - 2024-09-04 16:28:26 --> Security Class Initialized
DEBUG - 2024-09-04 16:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:28:26 --> Input Class Initialized
INFO - 2024-09-04 16:28:26 --> Language Class Initialized
INFO - 2024-09-04 16:28:26 --> Loader Class Initialized
INFO - 2024-09-04 16:28:26 --> Helper loaded: url_helper
INFO - 2024-09-04 16:28:26 --> Helper loaded: file_helper
INFO - 2024-09-04 16:28:26 --> Helper loaded: security_helper
INFO - 2024-09-04 16:28:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:28:26 --> Database Driver Class Initialized
INFO - 2024-09-04 16:28:26 --> Email Class Initialized
DEBUG - 2024-09-04 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:28:26 --> Helper loaded: form_helper
INFO - 2024-09-04 16:28:26 --> Form Validation Class Initialized
INFO - 2024-09-04 16:28:26 --> Controller Class Initialized
INFO - 2024-09-04 16:28:26 --> Model "User_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:28:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:28:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:28:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:28:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:28:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:28:26 --> Final output sent to browser
DEBUG - 2024-09-04 16:28:26 --> Total execution time: 0.1561
INFO - 2024-09-04 16:29:20 --> Config Class Initialized
INFO - 2024-09-04 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:29:20 --> Utf8 Class Initialized
INFO - 2024-09-04 16:29:20 --> URI Class Initialized
INFO - 2024-09-04 16:29:20 --> Router Class Initialized
INFO - 2024-09-04 16:29:20 --> Output Class Initialized
INFO - 2024-09-04 16:29:20 --> Security Class Initialized
DEBUG - 2024-09-04 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:29:20 --> Input Class Initialized
INFO - 2024-09-04 16:29:20 --> Language Class Initialized
INFO - 2024-09-04 16:29:20 --> Loader Class Initialized
INFO - 2024-09-04 16:29:20 --> Helper loaded: url_helper
INFO - 2024-09-04 16:29:20 --> Helper loaded: file_helper
INFO - 2024-09-04 16:29:20 --> Helper loaded: security_helper
INFO - 2024-09-04 16:29:20 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:29:20 --> Database Driver Class Initialized
INFO - 2024-09-04 16:29:20 --> Email Class Initialized
DEBUG - 2024-09-04 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:29:20 --> Helper loaded: form_helper
INFO - 2024-09-04 16:29:20 --> Form Validation Class Initialized
INFO - 2024-09-04 16:29:20 --> Controller Class Initialized
INFO - 2024-09-04 16:29:20 --> Model "User_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:29:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:29:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:29:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:29:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:29:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:29:20 --> Final output sent to browser
DEBUG - 2024-09-04 16:29:20 --> Total execution time: 0.1442
INFO - 2024-09-04 16:29:56 --> Config Class Initialized
INFO - 2024-09-04 16:29:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:29:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:29:56 --> Utf8 Class Initialized
INFO - 2024-09-04 16:29:56 --> URI Class Initialized
INFO - 2024-09-04 16:29:56 --> Router Class Initialized
INFO - 2024-09-04 16:29:56 --> Output Class Initialized
INFO - 2024-09-04 16:29:56 --> Security Class Initialized
DEBUG - 2024-09-04 16:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:29:56 --> Input Class Initialized
INFO - 2024-09-04 16:29:56 --> Language Class Initialized
INFO - 2024-09-04 16:29:56 --> Loader Class Initialized
INFO - 2024-09-04 16:29:56 --> Helper loaded: url_helper
INFO - 2024-09-04 16:29:56 --> Helper loaded: file_helper
INFO - 2024-09-04 16:29:56 --> Helper loaded: security_helper
INFO - 2024-09-04 16:29:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:29:56 --> Database Driver Class Initialized
INFO - 2024-09-04 16:29:56 --> Email Class Initialized
DEBUG - 2024-09-04 16:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:29:56 --> Helper loaded: form_helper
INFO - 2024-09-04 16:29:56 --> Form Validation Class Initialized
INFO - 2024-09-04 16:29:56 --> Controller Class Initialized
INFO - 2024-09-04 16:29:56 --> Model "User_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:29:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:29:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:29:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:29:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:29:56 --> Final output sent to browser
DEBUG - 2024-09-04 16:29:56 --> Total execution time: 0.1402
INFO - 2024-09-04 16:30:36 --> Config Class Initialized
INFO - 2024-09-04 16:30:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:30:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:30:36 --> Utf8 Class Initialized
INFO - 2024-09-04 16:30:36 --> URI Class Initialized
INFO - 2024-09-04 16:30:36 --> Router Class Initialized
INFO - 2024-09-04 16:30:36 --> Output Class Initialized
INFO - 2024-09-04 16:30:36 --> Security Class Initialized
DEBUG - 2024-09-04 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:30:36 --> Input Class Initialized
INFO - 2024-09-04 16:30:36 --> Language Class Initialized
INFO - 2024-09-04 16:30:36 --> Loader Class Initialized
INFO - 2024-09-04 16:30:36 --> Helper loaded: url_helper
INFO - 2024-09-04 16:30:36 --> Helper loaded: file_helper
INFO - 2024-09-04 16:30:36 --> Helper loaded: security_helper
INFO - 2024-09-04 16:30:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:30:36 --> Database Driver Class Initialized
INFO - 2024-09-04 16:30:36 --> Email Class Initialized
DEBUG - 2024-09-04 16:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:30:36 --> Helper loaded: form_helper
INFO - 2024-09-04 16:30:36 --> Form Validation Class Initialized
INFO - 2024-09-04 16:30:36 --> Controller Class Initialized
INFO - 2024-09-04 16:30:36 --> Model "User_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:30:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:30:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:30:36 --> Final output sent to browser
DEBUG - 2024-09-04 16:30:36 --> Total execution time: 0.1213
INFO - 2024-09-04 16:31:20 --> Config Class Initialized
INFO - 2024-09-04 16:31:20 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:31:20 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:31:20 --> Utf8 Class Initialized
INFO - 2024-09-04 16:31:20 --> URI Class Initialized
INFO - 2024-09-04 16:31:20 --> Router Class Initialized
INFO - 2024-09-04 16:31:20 --> Output Class Initialized
INFO - 2024-09-04 16:31:20 --> Security Class Initialized
DEBUG - 2024-09-04 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:31:20 --> Input Class Initialized
INFO - 2024-09-04 16:31:20 --> Language Class Initialized
INFO - 2024-09-04 16:31:20 --> Loader Class Initialized
INFO - 2024-09-04 16:31:20 --> Helper loaded: url_helper
INFO - 2024-09-04 16:31:20 --> Helper loaded: file_helper
INFO - 2024-09-04 16:31:20 --> Helper loaded: security_helper
INFO - 2024-09-04 16:31:20 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:31:20 --> Database Driver Class Initialized
INFO - 2024-09-04 16:31:20 --> Email Class Initialized
DEBUG - 2024-09-04 16:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:31:20 --> Helper loaded: form_helper
INFO - 2024-09-04 16:31:20 --> Form Validation Class Initialized
INFO - 2024-09-04 16:31:20 --> Controller Class Initialized
INFO - 2024-09-04 16:31:20 --> Model "User_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:31:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:31:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:31:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:31:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:31:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:31:20 --> Final output sent to browser
DEBUG - 2024-09-04 16:31:20 --> Total execution time: 0.1194
INFO - 2024-09-04 16:31:20 --> Config Class Initialized
INFO - 2024-09-04 16:31:20 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:31:20 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:31:20 --> Utf8 Class Initialized
INFO - 2024-09-04 16:31:20 --> URI Class Initialized
INFO - 2024-09-04 16:31:20 --> Router Class Initialized
INFO - 2024-09-04 16:31:20 --> Output Class Initialized
INFO - 2024-09-04 16:31:20 --> Security Class Initialized
DEBUG - 2024-09-04 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:31:20 --> Input Class Initialized
INFO - 2024-09-04 16:31:20 --> Language Class Initialized
ERROR - 2024-09-04 16:31:20 --> 404 Page Not Found: Data/path
INFO - 2024-09-04 16:31:30 --> Config Class Initialized
INFO - 2024-09-04 16:31:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:31:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:31:30 --> Utf8 Class Initialized
INFO - 2024-09-04 16:31:30 --> URI Class Initialized
INFO - 2024-09-04 16:31:30 --> Router Class Initialized
INFO - 2024-09-04 16:31:30 --> Output Class Initialized
INFO - 2024-09-04 16:31:30 --> Security Class Initialized
DEBUG - 2024-09-04 16:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:31:30 --> Input Class Initialized
INFO - 2024-09-04 16:31:30 --> Language Class Initialized
INFO - 2024-09-04 16:31:30 --> Loader Class Initialized
INFO - 2024-09-04 16:31:30 --> Helper loaded: url_helper
INFO - 2024-09-04 16:31:30 --> Helper loaded: file_helper
INFO - 2024-09-04 16:31:30 --> Helper loaded: security_helper
INFO - 2024-09-04 16:31:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:31:30 --> Database Driver Class Initialized
INFO - 2024-09-04 16:31:30 --> Email Class Initialized
DEBUG - 2024-09-04 16:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:31:30 --> Helper loaded: form_helper
INFO - 2024-09-04 16:31:30 --> Form Validation Class Initialized
INFO - 2024-09-04 16:31:30 --> Controller Class Initialized
INFO - 2024-09-04 16:31:30 --> Model "User_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:31:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:31:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:31:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:31:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:31:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:31:30 --> Final output sent to browser
DEBUG - 2024-09-04 16:31:30 --> Total execution time: 0.1286
INFO - 2024-09-04 16:33:14 --> Config Class Initialized
INFO - 2024-09-04 16:33:14 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:33:14 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:33:14 --> Utf8 Class Initialized
INFO - 2024-09-04 16:33:14 --> URI Class Initialized
INFO - 2024-09-04 16:33:14 --> Router Class Initialized
INFO - 2024-09-04 16:33:14 --> Output Class Initialized
INFO - 2024-09-04 16:33:14 --> Security Class Initialized
DEBUG - 2024-09-04 16:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:33:14 --> Input Class Initialized
INFO - 2024-09-04 16:33:14 --> Language Class Initialized
INFO - 2024-09-04 16:33:14 --> Loader Class Initialized
INFO - 2024-09-04 16:33:14 --> Helper loaded: url_helper
INFO - 2024-09-04 16:33:14 --> Helper loaded: file_helper
INFO - 2024-09-04 16:33:14 --> Helper loaded: security_helper
INFO - 2024-09-04 16:33:14 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:33:14 --> Database Driver Class Initialized
INFO - 2024-09-04 16:33:14 --> Email Class Initialized
DEBUG - 2024-09-04 16:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:33:14 --> Helper loaded: form_helper
INFO - 2024-09-04 16:33:14 --> Form Validation Class Initialized
INFO - 2024-09-04 16:33:14 --> Controller Class Initialized
INFO - 2024-09-04 16:33:14 --> Model "User_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:33:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:33:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:33:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:33:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:33:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:33:14 --> Final output sent to browser
DEBUG - 2024-09-04 16:33:14 --> Total execution time: 0.1374
INFO - 2024-09-04 16:33:25 --> Config Class Initialized
INFO - 2024-09-04 16:33:25 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:33:25 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:33:25 --> Utf8 Class Initialized
INFO - 2024-09-04 16:33:25 --> URI Class Initialized
INFO - 2024-09-04 16:33:25 --> Router Class Initialized
INFO - 2024-09-04 16:33:25 --> Output Class Initialized
INFO - 2024-09-04 16:33:25 --> Security Class Initialized
DEBUG - 2024-09-04 16:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:33:25 --> Input Class Initialized
INFO - 2024-09-04 16:33:25 --> Language Class Initialized
INFO - 2024-09-04 16:33:25 --> Loader Class Initialized
INFO - 2024-09-04 16:33:25 --> Helper loaded: url_helper
INFO - 2024-09-04 16:33:25 --> Helper loaded: file_helper
INFO - 2024-09-04 16:33:25 --> Helper loaded: security_helper
INFO - 2024-09-04 16:33:25 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:33:25 --> Database Driver Class Initialized
INFO - 2024-09-04 16:33:25 --> Email Class Initialized
DEBUG - 2024-09-04 16:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:33:25 --> Helper loaded: form_helper
INFO - 2024-09-04 16:33:25 --> Form Validation Class Initialized
INFO - 2024-09-04 16:33:25 --> Controller Class Initialized
INFO - 2024-09-04 16:33:25 --> Model "User_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:33:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:33:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:33:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:33:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:33:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:33:26 --> Final output sent to browser
DEBUG - 2024-09-04 16:33:26 --> Total execution time: 0.1260
INFO - 2024-09-04 16:33:37 --> Config Class Initialized
INFO - 2024-09-04 16:33:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:33:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:33:37 --> Utf8 Class Initialized
INFO - 2024-09-04 16:33:37 --> URI Class Initialized
INFO - 2024-09-04 16:33:37 --> Router Class Initialized
INFO - 2024-09-04 16:33:37 --> Output Class Initialized
INFO - 2024-09-04 16:33:37 --> Security Class Initialized
DEBUG - 2024-09-04 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:33:37 --> Input Class Initialized
INFO - 2024-09-04 16:33:37 --> Language Class Initialized
INFO - 2024-09-04 16:33:37 --> Loader Class Initialized
INFO - 2024-09-04 16:33:37 --> Helper loaded: url_helper
INFO - 2024-09-04 16:33:37 --> Helper loaded: file_helper
INFO - 2024-09-04 16:33:37 --> Helper loaded: security_helper
INFO - 2024-09-04 16:33:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:33:37 --> Database Driver Class Initialized
INFO - 2024-09-04 16:33:37 --> Email Class Initialized
DEBUG - 2024-09-04 16:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:33:37 --> Helper loaded: form_helper
INFO - 2024-09-04 16:33:37 --> Form Validation Class Initialized
INFO - 2024-09-04 16:33:37 --> Controller Class Initialized
INFO - 2024-09-04 16:33:37 --> Model "User_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:33:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:33:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:33:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:33:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:33:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:33:37 --> Final output sent to browser
DEBUG - 2024-09-04 16:33:37 --> Total execution time: 0.1085
INFO - 2024-09-04 16:34:09 --> Config Class Initialized
INFO - 2024-09-04 16:34:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:34:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:34:09 --> Utf8 Class Initialized
INFO - 2024-09-04 16:34:09 --> URI Class Initialized
INFO - 2024-09-04 16:34:09 --> Router Class Initialized
INFO - 2024-09-04 16:34:09 --> Output Class Initialized
INFO - 2024-09-04 16:34:09 --> Security Class Initialized
DEBUG - 2024-09-04 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:34:09 --> Input Class Initialized
INFO - 2024-09-04 16:34:09 --> Language Class Initialized
INFO - 2024-09-04 16:34:09 --> Loader Class Initialized
INFO - 2024-09-04 16:34:09 --> Helper loaded: url_helper
INFO - 2024-09-04 16:34:09 --> Helper loaded: file_helper
INFO - 2024-09-04 16:34:09 --> Helper loaded: security_helper
INFO - 2024-09-04 16:34:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:34:09 --> Database Driver Class Initialized
INFO - 2024-09-04 16:34:09 --> Email Class Initialized
DEBUG - 2024-09-04 16:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:34:09 --> Helper loaded: form_helper
INFO - 2024-09-04 16:34:09 --> Form Validation Class Initialized
INFO - 2024-09-04 16:34:09 --> Controller Class Initialized
INFO - 2024-09-04 16:34:09 --> Model "User_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:34:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:34:09 --> Final output sent to browser
DEBUG - 2024-09-04 16:34:09 --> Total execution time: 0.0905
INFO - 2024-09-04 16:35:15 --> Config Class Initialized
INFO - 2024-09-04 16:35:15 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:15 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:15 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:15 --> URI Class Initialized
INFO - 2024-09-04 16:35:15 --> Router Class Initialized
INFO - 2024-09-04 16:35:15 --> Output Class Initialized
INFO - 2024-09-04 16:35:15 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:15 --> Input Class Initialized
INFO - 2024-09-04 16:35:15 --> Language Class Initialized
INFO - 2024-09-04 16:35:15 --> Loader Class Initialized
INFO - 2024-09-04 16:35:15 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:15 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:15 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:15 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:15 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:15 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:15 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:15 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:15 --> Controller Class Initialized
INFO - 2024-09-04 16:35:15 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:15 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:15 --> Total execution time: 0.1768
INFO - 2024-09-04 16:35:19 --> Config Class Initialized
INFO - 2024-09-04 16:35:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:19 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:19 --> URI Class Initialized
INFO - 2024-09-04 16:35:19 --> Router Class Initialized
INFO - 2024-09-04 16:35:19 --> Output Class Initialized
INFO - 2024-09-04 16:35:19 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:19 --> Input Class Initialized
INFO - 2024-09-04 16:35:19 --> Language Class Initialized
INFO - 2024-09-04 16:35:19 --> Loader Class Initialized
INFO - 2024-09-04 16:35:19 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:19 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:19 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:19 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:19 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:20 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:20 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:20 --> Controller Class Initialized
INFO - 2024-09-04 16:35:20 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:20 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:20 --> Total execution time: 0.1219
INFO - 2024-09-04 16:35:30 --> Config Class Initialized
INFO - 2024-09-04 16:35:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:30 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:30 --> URI Class Initialized
INFO - 2024-09-04 16:35:30 --> Router Class Initialized
INFO - 2024-09-04 16:35:30 --> Output Class Initialized
INFO - 2024-09-04 16:35:30 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:30 --> Input Class Initialized
INFO - 2024-09-04 16:35:30 --> Language Class Initialized
INFO - 2024-09-04 16:35:30 --> Loader Class Initialized
INFO - 2024-09-04 16:35:30 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:30 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:30 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:30 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:30 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:30 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:30 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:30 --> Controller Class Initialized
INFO - 2024-09-04 16:35:30 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:30 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:30 --> Total execution time: 0.1147
INFO - 2024-09-04 16:35:35 --> Config Class Initialized
INFO - 2024-09-04 16:35:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:35 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:35 --> URI Class Initialized
INFO - 2024-09-04 16:35:35 --> Router Class Initialized
INFO - 2024-09-04 16:35:35 --> Output Class Initialized
INFO - 2024-09-04 16:35:35 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:35 --> Input Class Initialized
INFO - 2024-09-04 16:35:35 --> Language Class Initialized
INFO - 2024-09-04 16:35:35 --> Loader Class Initialized
INFO - 2024-09-04 16:35:35 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:35 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:35 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:35 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:35 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:35 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:35 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:35 --> Controller Class Initialized
INFO - 2024-09-04 16:35:35 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:35 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:35 --> Total execution time: 0.1111
INFO - 2024-09-04 16:35:45 --> Config Class Initialized
INFO - 2024-09-04 16:35:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:45 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:45 --> URI Class Initialized
INFO - 2024-09-04 16:35:45 --> Router Class Initialized
INFO - 2024-09-04 16:35:45 --> Output Class Initialized
INFO - 2024-09-04 16:35:45 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:45 --> Input Class Initialized
INFO - 2024-09-04 16:35:45 --> Language Class Initialized
INFO - 2024-09-04 16:35:45 --> Loader Class Initialized
INFO - 2024-09-04 16:35:45 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:45 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:45 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:45 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:45 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:45 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:45 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:45 --> Controller Class Initialized
INFO - 2024-09-04 16:35:45 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:45 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:45 --> Total execution time: 0.1046
INFO - 2024-09-04 16:35:47 --> Config Class Initialized
INFO - 2024-09-04 16:35:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:47 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:47 --> URI Class Initialized
INFO - 2024-09-04 16:35:47 --> Router Class Initialized
INFO - 2024-09-04 16:35:47 --> Output Class Initialized
INFO - 2024-09-04 16:35:47 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:47 --> Input Class Initialized
INFO - 2024-09-04 16:35:47 --> Language Class Initialized
INFO - 2024-09-04 16:35:47 --> Loader Class Initialized
INFO - 2024-09-04 16:35:47 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:47 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:47 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:47 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:47 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:47 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:47 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:47 --> Controller Class Initialized
INFO - 2024-09-04 16:35:47 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:47 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:47 --> Total execution time: 0.1000
INFO - 2024-09-04 16:35:51 --> Config Class Initialized
INFO - 2024-09-04 16:35:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:51 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:51 --> URI Class Initialized
INFO - 2024-09-04 16:35:51 --> Router Class Initialized
INFO - 2024-09-04 16:35:51 --> Output Class Initialized
INFO - 2024-09-04 16:35:51 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:51 --> Input Class Initialized
INFO - 2024-09-04 16:35:51 --> Language Class Initialized
INFO - 2024-09-04 16:35:51 --> Loader Class Initialized
INFO - 2024-09-04 16:35:51 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:51 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:51 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:51 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:51 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:51 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:51 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:51 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:51 --> Controller Class Initialized
INFO - 2024-09-04 16:35:51 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:51 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:51 --> Total execution time: 0.1297
INFO - 2024-09-04 16:35:55 --> Config Class Initialized
INFO - 2024-09-04 16:35:55 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:55 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:55 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:55 --> URI Class Initialized
INFO - 2024-09-04 16:35:55 --> Router Class Initialized
INFO - 2024-09-04 16:35:55 --> Output Class Initialized
INFO - 2024-09-04 16:35:55 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:55 --> Input Class Initialized
INFO - 2024-09-04 16:35:55 --> Language Class Initialized
INFO - 2024-09-04 16:35:55 --> Loader Class Initialized
INFO - 2024-09-04 16:35:55 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:55 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:55 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:55 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:55 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:55 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:55 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:55 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:55 --> Controller Class Initialized
INFO - 2024-09-04 16:35:55 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:55 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:55 --> Total execution time: 0.1081
INFO - 2024-09-04 16:35:59 --> Config Class Initialized
INFO - 2024-09-04 16:35:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:35:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:35:59 --> Utf8 Class Initialized
INFO - 2024-09-04 16:35:59 --> URI Class Initialized
INFO - 2024-09-04 16:35:59 --> Router Class Initialized
INFO - 2024-09-04 16:35:59 --> Output Class Initialized
INFO - 2024-09-04 16:35:59 --> Security Class Initialized
DEBUG - 2024-09-04 16:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:35:59 --> Input Class Initialized
INFO - 2024-09-04 16:35:59 --> Language Class Initialized
INFO - 2024-09-04 16:35:59 --> Loader Class Initialized
INFO - 2024-09-04 16:35:59 --> Helper loaded: url_helper
INFO - 2024-09-04 16:35:59 --> Helper loaded: file_helper
INFO - 2024-09-04 16:35:59 --> Helper loaded: security_helper
INFO - 2024-09-04 16:35:59 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:35:59 --> Database Driver Class Initialized
INFO - 2024-09-04 16:35:59 --> Email Class Initialized
DEBUG - 2024-09-04 16:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:35:59 --> Helper loaded: form_helper
INFO - 2024-09-04 16:35:59 --> Form Validation Class Initialized
INFO - 2024-09-04 16:35:59 --> Controller Class Initialized
INFO - 2024-09-04 16:35:59 --> Model "User_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:35:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:35:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:35:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:35:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:35:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:35:59 --> Final output sent to browser
DEBUG - 2024-09-04 16:35:59 --> Total execution time: 0.1188
INFO - 2024-09-04 16:36:05 --> Config Class Initialized
INFO - 2024-09-04 16:36:05 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:05 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:05 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:05 --> URI Class Initialized
INFO - 2024-09-04 16:36:05 --> Router Class Initialized
INFO - 2024-09-04 16:36:05 --> Output Class Initialized
INFO - 2024-09-04 16:36:05 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:05 --> Input Class Initialized
INFO - 2024-09-04 16:36:05 --> Language Class Initialized
INFO - 2024-09-04 16:36:05 --> Loader Class Initialized
INFO - 2024-09-04 16:36:05 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:05 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:05 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:05 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:05 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:05 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:05 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:05 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:05 --> Controller Class Initialized
INFO - 2024-09-04 16:36:05 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:05 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:05 --> Total execution time: 0.1371
INFO - 2024-09-04 16:36:14 --> Config Class Initialized
INFO - 2024-09-04 16:36:14 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:14 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:14 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:14 --> URI Class Initialized
INFO - 2024-09-04 16:36:14 --> Router Class Initialized
INFO - 2024-09-04 16:36:14 --> Output Class Initialized
INFO - 2024-09-04 16:36:14 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:14 --> Input Class Initialized
INFO - 2024-09-04 16:36:14 --> Language Class Initialized
INFO - 2024-09-04 16:36:14 --> Loader Class Initialized
INFO - 2024-09-04 16:36:14 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:14 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:14 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:14 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:14 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:14 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:14 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:14 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:14 --> Controller Class Initialized
INFO - 2024-09-04 16:36:14 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:14 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:14 --> Total execution time: 0.1194
INFO - 2024-09-04 16:36:22 --> Config Class Initialized
INFO - 2024-09-04 16:36:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:22 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:22 --> URI Class Initialized
INFO - 2024-09-04 16:36:22 --> Router Class Initialized
INFO - 2024-09-04 16:36:22 --> Output Class Initialized
INFO - 2024-09-04 16:36:22 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:22 --> Input Class Initialized
INFO - 2024-09-04 16:36:22 --> Language Class Initialized
INFO - 2024-09-04 16:36:22 --> Loader Class Initialized
INFO - 2024-09-04 16:36:22 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:22 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:22 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:22 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:22 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:22 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:22 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:22 --> Controller Class Initialized
INFO - 2024-09-04 16:36:22 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:22 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:22 --> Total execution time: 0.1095
INFO - 2024-09-04 16:36:27 --> Config Class Initialized
INFO - 2024-09-04 16:36:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:27 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:27 --> URI Class Initialized
INFO - 2024-09-04 16:36:27 --> Router Class Initialized
INFO - 2024-09-04 16:36:27 --> Output Class Initialized
INFO - 2024-09-04 16:36:27 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:27 --> Input Class Initialized
INFO - 2024-09-04 16:36:27 --> Language Class Initialized
INFO - 2024-09-04 16:36:27 --> Loader Class Initialized
INFO - 2024-09-04 16:36:27 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:27 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:27 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:27 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:27 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:27 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:27 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:27 --> Controller Class Initialized
INFO - 2024-09-04 16:36:27 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:28 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:28 --> Total execution time: 0.0976
INFO - 2024-09-04 16:36:32 --> Config Class Initialized
INFO - 2024-09-04 16:36:32 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:32 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:32 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:32 --> URI Class Initialized
INFO - 2024-09-04 16:36:32 --> Router Class Initialized
INFO - 2024-09-04 16:36:32 --> Output Class Initialized
INFO - 2024-09-04 16:36:32 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:32 --> Input Class Initialized
INFO - 2024-09-04 16:36:32 --> Language Class Initialized
INFO - 2024-09-04 16:36:32 --> Loader Class Initialized
INFO - 2024-09-04 16:36:32 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:32 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:32 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:32 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:32 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:32 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:32 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:32 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:32 --> Controller Class Initialized
INFO - 2024-09-04 16:36:32 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:32 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:32 --> Total execution time: 0.1246
INFO - 2024-09-04 16:36:36 --> Config Class Initialized
INFO - 2024-09-04 16:36:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:36 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:36 --> URI Class Initialized
INFO - 2024-09-04 16:36:36 --> Router Class Initialized
INFO - 2024-09-04 16:36:36 --> Output Class Initialized
INFO - 2024-09-04 16:36:36 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:36 --> Input Class Initialized
INFO - 2024-09-04 16:36:36 --> Language Class Initialized
INFO - 2024-09-04 16:36:36 --> Loader Class Initialized
INFO - 2024-09-04 16:36:36 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:36 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:37 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:37 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:37 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:37 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:37 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:37 --> Controller Class Initialized
INFO - 2024-09-04 16:36:37 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:37 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:37 --> Total execution time: 0.1190
INFO - 2024-09-04 16:36:42 --> Config Class Initialized
INFO - 2024-09-04 16:36:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:36:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:36:42 --> Utf8 Class Initialized
INFO - 2024-09-04 16:36:42 --> URI Class Initialized
INFO - 2024-09-04 16:36:42 --> Router Class Initialized
INFO - 2024-09-04 16:36:42 --> Output Class Initialized
INFO - 2024-09-04 16:36:42 --> Security Class Initialized
DEBUG - 2024-09-04 16:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:36:42 --> Input Class Initialized
INFO - 2024-09-04 16:36:42 --> Language Class Initialized
INFO - 2024-09-04 16:36:42 --> Loader Class Initialized
INFO - 2024-09-04 16:36:42 --> Helper loaded: url_helper
INFO - 2024-09-04 16:36:42 --> Helper loaded: file_helper
INFO - 2024-09-04 16:36:42 --> Helper loaded: security_helper
INFO - 2024-09-04 16:36:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:36:42 --> Database Driver Class Initialized
INFO - 2024-09-04 16:36:42 --> Email Class Initialized
DEBUG - 2024-09-04 16:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:36:42 --> Helper loaded: form_helper
INFO - 2024-09-04 16:36:42 --> Form Validation Class Initialized
INFO - 2024-09-04 16:36:42 --> Controller Class Initialized
INFO - 2024-09-04 16:36:42 --> Model "User_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:36:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:36:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:36:42 --> Final output sent to browser
DEBUG - 2024-09-04 16:36:42 --> Total execution time: 0.1234
INFO - 2024-09-04 16:37:16 --> Config Class Initialized
INFO - 2024-09-04 16:37:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:37:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:37:16 --> Utf8 Class Initialized
INFO - 2024-09-04 16:37:16 --> URI Class Initialized
INFO - 2024-09-04 16:37:16 --> Router Class Initialized
INFO - 2024-09-04 16:37:16 --> Output Class Initialized
INFO - 2024-09-04 16:37:16 --> Security Class Initialized
DEBUG - 2024-09-04 16:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:37:16 --> Input Class Initialized
INFO - 2024-09-04 16:37:16 --> Language Class Initialized
INFO - 2024-09-04 16:37:16 --> Loader Class Initialized
INFO - 2024-09-04 16:37:16 --> Helper loaded: url_helper
INFO - 2024-09-04 16:37:16 --> Helper loaded: file_helper
INFO - 2024-09-04 16:37:16 --> Helper loaded: security_helper
INFO - 2024-09-04 16:37:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:37:16 --> Database Driver Class Initialized
INFO - 2024-09-04 16:37:16 --> Email Class Initialized
DEBUG - 2024-09-04 16:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:37:16 --> Helper loaded: form_helper
INFO - 2024-09-04 16:37:16 --> Form Validation Class Initialized
INFO - 2024-09-04 16:37:16 --> Controller Class Initialized
INFO - 2024-09-04 16:37:16 --> Model "User_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:37:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:37:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:37:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:37:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:37:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:37:16 --> Final output sent to browser
DEBUG - 2024-09-04 16:37:16 --> Total execution time: 0.1133
INFO - 2024-09-04 16:37:34 --> Config Class Initialized
INFO - 2024-09-04 16:37:34 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:37:34 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:37:34 --> Utf8 Class Initialized
INFO - 2024-09-04 16:37:34 --> URI Class Initialized
INFO - 2024-09-04 16:37:34 --> Router Class Initialized
INFO - 2024-09-04 16:37:34 --> Output Class Initialized
INFO - 2024-09-04 16:37:34 --> Security Class Initialized
DEBUG - 2024-09-04 16:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:37:34 --> Input Class Initialized
INFO - 2024-09-04 16:37:34 --> Language Class Initialized
INFO - 2024-09-04 16:37:34 --> Loader Class Initialized
INFO - 2024-09-04 16:37:34 --> Helper loaded: url_helper
INFO - 2024-09-04 16:37:34 --> Helper loaded: file_helper
INFO - 2024-09-04 16:37:34 --> Helper loaded: security_helper
INFO - 2024-09-04 16:37:34 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:37:34 --> Database Driver Class Initialized
INFO - 2024-09-04 16:37:34 --> Email Class Initialized
DEBUG - 2024-09-04 16:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:37:34 --> Helper loaded: form_helper
INFO - 2024-09-04 16:37:34 --> Form Validation Class Initialized
INFO - 2024-09-04 16:37:34 --> Controller Class Initialized
INFO - 2024-09-04 16:37:34 --> Model "User_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:37:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:37:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:37:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:37:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:37:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:37:34 --> Final output sent to browser
DEBUG - 2024-09-04 16:37:35 --> Total execution time: 0.1263
INFO - 2024-09-04 16:37:42 --> Config Class Initialized
INFO - 2024-09-04 16:37:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:37:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:37:42 --> Utf8 Class Initialized
INFO - 2024-09-04 16:37:42 --> URI Class Initialized
INFO - 2024-09-04 16:37:42 --> Router Class Initialized
INFO - 2024-09-04 16:37:42 --> Output Class Initialized
INFO - 2024-09-04 16:37:42 --> Security Class Initialized
DEBUG - 2024-09-04 16:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:37:42 --> Input Class Initialized
INFO - 2024-09-04 16:37:42 --> Language Class Initialized
INFO - 2024-09-04 16:37:42 --> Loader Class Initialized
INFO - 2024-09-04 16:37:42 --> Helper loaded: url_helper
INFO - 2024-09-04 16:37:42 --> Helper loaded: file_helper
INFO - 2024-09-04 16:37:42 --> Helper loaded: security_helper
INFO - 2024-09-04 16:37:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:37:42 --> Database Driver Class Initialized
INFO - 2024-09-04 16:37:42 --> Email Class Initialized
DEBUG - 2024-09-04 16:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:37:42 --> Helper loaded: form_helper
INFO - 2024-09-04 16:37:42 --> Form Validation Class Initialized
INFO - 2024-09-04 16:37:42 --> Controller Class Initialized
INFO - 2024-09-04 16:37:42 --> Model "User_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:37:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:37:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:37:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:37:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:37:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:37:42 --> Final output sent to browser
DEBUG - 2024-09-04 16:37:42 --> Total execution time: 0.1089
INFO - 2024-09-04 16:37:45 --> Config Class Initialized
INFO - 2024-09-04 16:37:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:37:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:37:45 --> Utf8 Class Initialized
INFO - 2024-09-04 16:37:45 --> URI Class Initialized
INFO - 2024-09-04 16:37:45 --> Router Class Initialized
INFO - 2024-09-04 16:37:45 --> Output Class Initialized
INFO - 2024-09-04 16:37:45 --> Security Class Initialized
DEBUG - 2024-09-04 16:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:37:45 --> Input Class Initialized
INFO - 2024-09-04 16:37:45 --> Language Class Initialized
INFO - 2024-09-04 16:37:45 --> Loader Class Initialized
INFO - 2024-09-04 16:37:45 --> Helper loaded: url_helper
INFO - 2024-09-04 16:37:45 --> Helper loaded: file_helper
INFO - 2024-09-04 16:37:45 --> Helper loaded: security_helper
INFO - 2024-09-04 16:37:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:37:45 --> Database Driver Class Initialized
INFO - 2024-09-04 16:37:45 --> Email Class Initialized
DEBUG - 2024-09-04 16:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:37:45 --> Helper loaded: form_helper
INFO - 2024-09-04 16:37:45 --> Form Validation Class Initialized
INFO - 2024-09-04 16:37:45 --> Controller Class Initialized
INFO - 2024-09-04 16:37:45 --> Model "User_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:37:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:37:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:37:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:37:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:37:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:37:45 --> Final output sent to browser
DEBUG - 2024-09-04 16:37:45 --> Total execution time: 0.1098
INFO - 2024-09-04 16:37:59 --> Config Class Initialized
INFO - 2024-09-04 16:37:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:37:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:37:59 --> Utf8 Class Initialized
INFO - 2024-09-04 16:37:59 --> URI Class Initialized
INFO - 2024-09-04 16:37:59 --> Router Class Initialized
INFO - 2024-09-04 16:37:59 --> Output Class Initialized
INFO - 2024-09-04 16:37:59 --> Security Class Initialized
DEBUG - 2024-09-04 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:37:59 --> Input Class Initialized
INFO - 2024-09-04 16:37:59 --> Language Class Initialized
INFO - 2024-09-04 16:37:59 --> Loader Class Initialized
INFO - 2024-09-04 16:37:59 --> Helper loaded: url_helper
INFO - 2024-09-04 16:37:59 --> Helper loaded: file_helper
INFO - 2024-09-04 16:37:59 --> Helper loaded: security_helper
INFO - 2024-09-04 16:37:59 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:37:59 --> Database Driver Class Initialized
INFO - 2024-09-04 16:37:59 --> Email Class Initialized
DEBUG - 2024-09-04 16:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:37:59 --> Helper loaded: form_helper
INFO - 2024-09-04 16:37:59 --> Form Validation Class Initialized
INFO - 2024-09-04 16:37:59 --> Controller Class Initialized
INFO - 2024-09-04 16:37:59 --> Model "User_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:37:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:37:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:37:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:37:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:37:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:37:59 --> Final output sent to browser
DEBUG - 2024-09-04 16:37:59 --> Total execution time: 0.1110
INFO - 2024-09-04 16:38:02 --> Config Class Initialized
INFO - 2024-09-04 16:38:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:38:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:38:02 --> Utf8 Class Initialized
INFO - 2024-09-04 16:38:02 --> URI Class Initialized
INFO - 2024-09-04 16:38:02 --> Router Class Initialized
INFO - 2024-09-04 16:38:02 --> Output Class Initialized
INFO - 2024-09-04 16:38:02 --> Security Class Initialized
DEBUG - 2024-09-04 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:38:02 --> Input Class Initialized
INFO - 2024-09-04 16:38:02 --> Language Class Initialized
INFO - 2024-09-04 16:38:02 --> Loader Class Initialized
INFO - 2024-09-04 16:38:02 --> Helper loaded: url_helper
INFO - 2024-09-04 16:38:02 --> Helper loaded: file_helper
INFO - 2024-09-04 16:38:02 --> Helper loaded: security_helper
INFO - 2024-09-04 16:38:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:38:02 --> Database Driver Class Initialized
INFO - 2024-09-04 16:38:02 --> Email Class Initialized
DEBUG - 2024-09-04 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:38:02 --> Helper loaded: form_helper
INFO - 2024-09-04 16:38:02 --> Form Validation Class Initialized
INFO - 2024-09-04 16:38:02 --> Controller Class Initialized
INFO - 2024-09-04 16:38:02 --> Model "User_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:38:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:38:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:38:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:38:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:38:02 --> Final output sent to browser
DEBUG - 2024-09-04 16:38:02 --> Total execution time: 0.1361
INFO - 2024-09-04 16:38:21 --> Config Class Initialized
INFO - 2024-09-04 16:38:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:38:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:38:21 --> Utf8 Class Initialized
INFO - 2024-09-04 16:38:21 --> URI Class Initialized
INFO - 2024-09-04 16:38:21 --> Router Class Initialized
INFO - 2024-09-04 16:38:21 --> Output Class Initialized
INFO - 2024-09-04 16:38:21 --> Security Class Initialized
DEBUG - 2024-09-04 16:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:38:21 --> Input Class Initialized
INFO - 2024-09-04 16:38:21 --> Language Class Initialized
INFO - 2024-09-04 16:38:21 --> Loader Class Initialized
INFO - 2024-09-04 16:38:21 --> Helper loaded: url_helper
INFO - 2024-09-04 16:38:21 --> Helper loaded: file_helper
INFO - 2024-09-04 16:38:21 --> Helper loaded: security_helper
INFO - 2024-09-04 16:38:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:38:21 --> Database Driver Class Initialized
INFO - 2024-09-04 16:38:21 --> Email Class Initialized
DEBUG - 2024-09-04 16:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:38:21 --> Helper loaded: form_helper
INFO - 2024-09-04 16:38:21 --> Form Validation Class Initialized
INFO - 2024-09-04 16:38:21 --> Controller Class Initialized
INFO - 2024-09-04 16:38:21 --> Model "User_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:38:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:38:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:38:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:38:21 --> Final output sent to browser
DEBUG - 2024-09-04 16:38:21 --> Total execution time: 0.1522
INFO - 2024-09-04 16:38:28 --> Config Class Initialized
INFO - 2024-09-04 16:38:28 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:38:28 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:38:28 --> Utf8 Class Initialized
INFO - 2024-09-04 16:38:28 --> URI Class Initialized
INFO - 2024-09-04 16:38:28 --> Router Class Initialized
INFO - 2024-09-04 16:38:28 --> Output Class Initialized
INFO - 2024-09-04 16:38:28 --> Security Class Initialized
DEBUG - 2024-09-04 16:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:38:28 --> Input Class Initialized
INFO - 2024-09-04 16:38:28 --> Language Class Initialized
INFO - 2024-09-04 16:38:28 --> Loader Class Initialized
INFO - 2024-09-04 16:38:28 --> Helper loaded: url_helper
INFO - 2024-09-04 16:38:28 --> Helper loaded: file_helper
INFO - 2024-09-04 16:38:28 --> Helper loaded: security_helper
INFO - 2024-09-04 16:38:28 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:38:28 --> Database Driver Class Initialized
INFO - 2024-09-04 16:38:28 --> Email Class Initialized
DEBUG - 2024-09-04 16:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:38:28 --> Helper loaded: form_helper
INFO - 2024-09-04 16:38:28 --> Form Validation Class Initialized
INFO - 2024-09-04 16:38:28 --> Controller Class Initialized
INFO - 2024-09-04 16:38:28 --> Model "User_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:38:28 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:38:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:38:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:38:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:38:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:38:28 --> Final output sent to browser
DEBUG - 2024-09-04 16:38:28 --> Total execution time: 0.1380
INFO - 2024-09-04 16:43:08 --> Config Class Initialized
INFO - 2024-09-04 16:43:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:43:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:43:08 --> Utf8 Class Initialized
INFO - 2024-09-04 16:43:08 --> URI Class Initialized
INFO - 2024-09-04 16:43:08 --> Router Class Initialized
INFO - 2024-09-04 16:43:08 --> Output Class Initialized
INFO - 2024-09-04 16:43:08 --> Security Class Initialized
DEBUG - 2024-09-04 16:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:43:08 --> Input Class Initialized
INFO - 2024-09-04 16:43:08 --> Language Class Initialized
INFO - 2024-09-04 16:43:08 --> Loader Class Initialized
INFO - 2024-09-04 16:43:08 --> Helper loaded: url_helper
INFO - 2024-09-04 16:43:08 --> Helper loaded: file_helper
INFO - 2024-09-04 16:43:08 --> Helper loaded: security_helper
INFO - 2024-09-04 16:43:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:43:08 --> Database Driver Class Initialized
INFO - 2024-09-04 16:43:08 --> Email Class Initialized
DEBUG - 2024-09-04 16:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:43:08 --> Helper loaded: form_helper
INFO - 2024-09-04 16:43:08 --> Form Validation Class Initialized
INFO - 2024-09-04 16:43:08 --> Controller Class Initialized
INFO - 2024-09-04 16:43:08 --> Model "User_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:43:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:43:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:43:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:43:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:43:08 --> Final output sent to browser
DEBUG - 2024-09-04 16:43:08 --> Total execution time: 0.1286
INFO - 2024-09-04 16:43:38 --> Config Class Initialized
INFO - 2024-09-04 16:43:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:43:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:43:38 --> Utf8 Class Initialized
INFO - 2024-09-04 16:43:38 --> URI Class Initialized
INFO - 2024-09-04 16:43:38 --> Router Class Initialized
INFO - 2024-09-04 16:43:38 --> Output Class Initialized
INFO - 2024-09-04 16:43:38 --> Security Class Initialized
DEBUG - 2024-09-04 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:43:38 --> Input Class Initialized
INFO - 2024-09-04 16:43:38 --> Language Class Initialized
INFO - 2024-09-04 16:43:38 --> Loader Class Initialized
INFO - 2024-09-04 16:43:38 --> Helper loaded: url_helper
INFO - 2024-09-04 16:43:38 --> Helper loaded: file_helper
INFO - 2024-09-04 16:43:38 --> Helper loaded: security_helper
INFO - 2024-09-04 16:43:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:43:38 --> Database Driver Class Initialized
INFO - 2024-09-04 16:43:38 --> Email Class Initialized
DEBUG - 2024-09-04 16:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:43:38 --> Helper loaded: form_helper
INFO - 2024-09-04 16:43:38 --> Form Validation Class Initialized
INFO - 2024-09-04 16:43:38 --> Controller Class Initialized
INFO - 2024-09-04 16:43:38 --> Model "User_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:43:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:43:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:43:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:43:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:43:38 --> Final output sent to browser
DEBUG - 2024-09-04 16:43:38 --> Total execution time: 0.1395
INFO - 2024-09-04 16:44:02 --> Config Class Initialized
INFO - 2024-09-04 16:44:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:02 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:02 --> URI Class Initialized
INFO - 2024-09-04 16:44:02 --> Router Class Initialized
INFO - 2024-09-04 16:44:02 --> Output Class Initialized
INFO - 2024-09-04 16:44:02 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:02 --> Input Class Initialized
INFO - 2024-09-04 16:44:02 --> Language Class Initialized
INFO - 2024-09-04 16:44:02 --> Loader Class Initialized
INFO - 2024-09-04 16:44:02 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:02 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:02 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:02 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:02 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:02 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:02 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:02 --> Controller Class Initialized
INFO - 2024-09-04 16:44:02 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:02 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:02 --> Total execution time: 0.1596
INFO - 2024-09-04 16:44:07 --> Config Class Initialized
INFO - 2024-09-04 16:44:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:07 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:07 --> URI Class Initialized
INFO - 2024-09-04 16:44:07 --> Router Class Initialized
INFO - 2024-09-04 16:44:07 --> Output Class Initialized
INFO - 2024-09-04 16:44:07 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:07 --> Input Class Initialized
INFO - 2024-09-04 16:44:07 --> Language Class Initialized
INFO - 2024-09-04 16:44:07 --> Loader Class Initialized
INFO - 2024-09-04 16:44:07 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:07 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:07 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:07 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:07 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:07 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:07 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:07 --> Controller Class Initialized
INFO - 2024-09-04 16:44:07 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:07 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:07 --> Total execution time: 0.1463
INFO - 2024-09-04 16:44:15 --> Config Class Initialized
INFO - 2024-09-04 16:44:15 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:15 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:15 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:15 --> URI Class Initialized
INFO - 2024-09-04 16:44:15 --> Router Class Initialized
INFO - 2024-09-04 16:44:15 --> Output Class Initialized
INFO - 2024-09-04 16:44:15 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:15 --> Input Class Initialized
INFO - 2024-09-04 16:44:15 --> Language Class Initialized
INFO - 2024-09-04 16:44:15 --> Loader Class Initialized
INFO - 2024-09-04 16:44:15 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:15 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:15 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:15 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:15 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:15 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:15 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:15 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:15 --> Controller Class Initialized
INFO - 2024-09-04 16:44:15 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:15 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:15 --> Total execution time: 0.1036
INFO - 2024-09-04 16:44:28 --> Config Class Initialized
INFO - 2024-09-04 16:44:28 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:28 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:28 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:28 --> URI Class Initialized
INFO - 2024-09-04 16:44:28 --> Router Class Initialized
INFO - 2024-09-04 16:44:28 --> Output Class Initialized
INFO - 2024-09-04 16:44:28 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:28 --> Input Class Initialized
INFO - 2024-09-04 16:44:28 --> Language Class Initialized
INFO - 2024-09-04 16:44:28 --> Loader Class Initialized
INFO - 2024-09-04 16:44:28 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:28 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:28 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:28 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:28 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:28 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:28 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:28 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:28 --> Controller Class Initialized
INFO - 2024-09-04 16:44:28 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:28 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:28 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:28 --> Total execution time: 0.1316
INFO - 2024-09-04 16:44:49 --> Config Class Initialized
INFO - 2024-09-04 16:44:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:49 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:49 --> URI Class Initialized
INFO - 2024-09-04 16:44:49 --> Router Class Initialized
INFO - 2024-09-04 16:44:49 --> Output Class Initialized
INFO - 2024-09-04 16:44:49 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:49 --> Input Class Initialized
INFO - 2024-09-04 16:44:49 --> Language Class Initialized
INFO - 2024-09-04 16:44:49 --> Loader Class Initialized
INFO - 2024-09-04 16:44:49 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:49 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:49 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:49 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:49 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:49 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:49 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:49 --> Controller Class Initialized
INFO - 2024-09-04 16:44:49 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:49 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:49 --> Total execution time: 0.1336
INFO - 2024-09-04 16:44:57 --> Config Class Initialized
INFO - 2024-09-04 16:44:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:57 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:57 --> URI Class Initialized
INFO - 2024-09-04 16:44:57 --> Router Class Initialized
INFO - 2024-09-04 16:44:57 --> Output Class Initialized
INFO - 2024-09-04 16:44:57 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:57 --> Input Class Initialized
INFO - 2024-09-04 16:44:57 --> Language Class Initialized
INFO - 2024-09-04 16:44:57 --> Loader Class Initialized
INFO - 2024-09-04 16:44:57 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:57 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:57 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:57 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:57 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:57 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:57 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:57 --> Controller Class Initialized
INFO - 2024-09-04 16:44:57 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:57 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:57 --> Total execution time: 0.1320
INFO - 2024-09-04 16:44:58 --> Config Class Initialized
INFO - 2024-09-04 16:44:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:44:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:44:58 --> Utf8 Class Initialized
INFO - 2024-09-04 16:44:58 --> URI Class Initialized
INFO - 2024-09-04 16:44:58 --> Router Class Initialized
INFO - 2024-09-04 16:44:58 --> Output Class Initialized
INFO - 2024-09-04 16:44:58 --> Security Class Initialized
DEBUG - 2024-09-04 16:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:44:58 --> Input Class Initialized
INFO - 2024-09-04 16:44:58 --> Language Class Initialized
INFO - 2024-09-04 16:44:58 --> Loader Class Initialized
INFO - 2024-09-04 16:44:58 --> Helper loaded: url_helper
INFO - 2024-09-04 16:44:58 --> Helper loaded: file_helper
INFO - 2024-09-04 16:44:58 --> Helper loaded: security_helper
INFO - 2024-09-04 16:44:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:44:58 --> Database Driver Class Initialized
INFO - 2024-09-04 16:44:58 --> Email Class Initialized
DEBUG - 2024-09-04 16:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:44:58 --> Helper loaded: form_helper
INFO - 2024-09-04 16:44:58 --> Form Validation Class Initialized
INFO - 2024-09-04 16:44:58 --> Controller Class Initialized
INFO - 2024-09-04 16:44:58 --> Model "User_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:44:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:44:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:44:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:44:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:44:59 --> Final output sent to browser
DEBUG - 2024-09-04 16:44:59 --> Total execution time: 0.1011
INFO - 2024-09-04 16:45:00 --> Config Class Initialized
INFO - 2024-09-04 16:45:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:45:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:45:00 --> Utf8 Class Initialized
INFO - 2024-09-04 16:45:00 --> URI Class Initialized
INFO - 2024-09-04 16:45:00 --> Router Class Initialized
INFO - 2024-09-04 16:45:00 --> Output Class Initialized
INFO - 2024-09-04 16:45:00 --> Security Class Initialized
DEBUG - 2024-09-04 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:45:00 --> Input Class Initialized
INFO - 2024-09-04 16:45:00 --> Language Class Initialized
INFO - 2024-09-04 16:45:00 --> Loader Class Initialized
INFO - 2024-09-04 16:45:00 --> Helper loaded: url_helper
INFO - 2024-09-04 16:45:00 --> Helper loaded: file_helper
INFO - 2024-09-04 16:45:00 --> Helper loaded: security_helper
INFO - 2024-09-04 16:45:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:45:00 --> Database Driver Class Initialized
INFO - 2024-09-04 16:45:00 --> Email Class Initialized
DEBUG - 2024-09-04 16:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:45:00 --> Helper loaded: form_helper
INFO - 2024-09-04 16:45:00 --> Form Validation Class Initialized
INFO - 2024-09-04 16:45:00 --> Controller Class Initialized
INFO - 2024-09-04 16:45:00 --> Model "User_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Permintaan_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Faktur_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Pesanan_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Supplier_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Jenis_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Inventaris_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Barang_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Pemeliharaan_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Perbaikan_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Penghapusan_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Mutasi_model" initialized
INFO - 2024-09-04 16:45:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:45:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:45:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:45:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:45:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:45:00 --> Final output sent to browser
DEBUG - 2024-09-04 16:45:00 --> Total execution time: 0.1044
INFO - 2024-09-04 16:58:01 --> Config Class Initialized
INFO - 2024-09-04 16:58:01 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:58:01 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:58:01 --> Utf8 Class Initialized
INFO - 2024-09-04 16:58:01 --> URI Class Initialized
INFO - 2024-09-04 16:58:01 --> Router Class Initialized
INFO - 2024-09-04 16:58:01 --> Output Class Initialized
INFO - 2024-09-04 16:58:01 --> Security Class Initialized
DEBUG - 2024-09-04 16:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:58:01 --> Input Class Initialized
INFO - 2024-09-04 16:58:01 --> Language Class Initialized
INFO - 2024-09-04 16:58:01 --> Loader Class Initialized
INFO - 2024-09-04 16:58:01 --> Helper loaded: url_helper
INFO - 2024-09-04 16:58:01 --> Helper loaded: file_helper
INFO - 2024-09-04 16:58:01 --> Helper loaded: security_helper
INFO - 2024-09-04 16:58:01 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:58:01 --> Database Driver Class Initialized
INFO - 2024-09-04 16:58:01 --> Email Class Initialized
DEBUG - 2024-09-04 16:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:58:01 --> Helper loaded: form_helper
INFO - 2024-09-04 16:58:01 --> Form Validation Class Initialized
INFO - 2024-09-04 16:58:01 --> Controller Class Initialized
INFO - 2024-09-04 16:58:01 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:58:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 16:58:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 16:58:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 16:58:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 16:58:01 --> Final output sent to browser
DEBUG - 2024-09-04 16:58:01 --> Total execution time: 0.0986
INFO - 2024-09-04 16:59:12 --> Config Class Initialized
INFO - 2024-09-04 16:59:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:59:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:59:12 --> Utf8 Class Initialized
INFO - 2024-09-04 16:59:12 --> URI Class Initialized
INFO - 2024-09-04 16:59:12 --> Router Class Initialized
INFO - 2024-09-04 16:59:12 --> Output Class Initialized
INFO - 2024-09-04 16:59:12 --> Security Class Initialized
DEBUG - 2024-09-04 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:59:12 --> Input Class Initialized
INFO - 2024-09-04 16:59:12 --> Language Class Initialized
ERROR - 2024-09-04 16:59:12 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\antrol\application\controllers\Report.php 13
INFO - 2024-09-04 16:59:16 --> Config Class Initialized
INFO - 2024-09-04 16:59:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:59:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:59:16 --> Utf8 Class Initialized
INFO - 2024-09-04 16:59:16 --> URI Class Initialized
INFO - 2024-09-04 16:59:16 --> Router Class Initialized
INFO - 2024-09-04 16:59:16 --> Output Class Initialized
INFO - 2024-09-04 16:59:16 --> Security Class Initialized
DEBUG - 2024-09-04 16:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:59:16 --> Input Class Initialized
INFO - 2024-09-04 16:59:16 --> Language Class Initialized
INFO - 2024-09-04 16:59:16 --> Loader Class Initialized
INFO - 2024-09-04 16:59:16 --> Helper loaded: url_helper
INFO - 2024-09-04 16:59:16 --> Helper loaded: file_helper
INFO - 2024-09-04 16:59:16 --> Helper loaded: security_helper
INFO - 2024-09-04 16:59:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 16:59:16 --> Database Driver Class Initialized
INFO - 2024-09-04 16:59:16 --> Email Class Initialized
DEBUG - 2024-09-04 16:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 16:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 16:59:16 --> Helper loaded: form_helper
INFO - 2024-09-04 16:59:16 --> Form Validation Class Initialized
INFO - 2024-09-04 16:59:16 --> Controller Class Initialized
INFO - 2024-09-04 16:59:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 16:59:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 16:59:16 --> Query error: Unknown column 'inventaris.id_barang' in 'on clause' - Invalid query: SELECT `inventaris`.*, `inventaris_barang`.*, `inventaris_ruang`.*
FROM `inventaris`
JOIN `inventaris_barang` ON `inventaris`.`id_barang` = `inventaris_barang`.`id_barang`
JOIN `inventaris_ruang` ON `inventaris`.`id_ruang` = `inventaris_ruang`.`id_ruang`
INFO - 2024-09-04 16:59:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 16:59:45 --> Config Class Initialized
INFO - 2024-09-04 16:59:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 16:59:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 16:59:45 --> Utf8 Class Initialized
INFO - 2024-09-04 16:59:45 --> URI Class Initialized
INFO - 2024-09-04 16:59:45 --> Router Class Initialized
INFO - 2024-09-04 16:59:45 --> Output Class Initialized
INFO - 2024-09-04 16:59:45 --> Security Class Initialized
DEBUG - 2024-09-04 16:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 16:59:45 --> Input Class Initialized
INFO - 2024-09-04 16:59:45 --> Language Class Initialized
ERROR - 2024-09-04 16:59:45 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\antrol\application\controllers\Report.php 17
INFO - 2024-09-04 17:00:16 --> Config Class Initialized
INFO - 2024-09-04 17:00:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:00:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:00:16 --> Utf8 Class Initialized
INFO - 2024-09-04 17:00:16 --> URI Class Initialized
INFO - 2024-09-04 17:00:16 --> Router Class Initialized
INFO - 2024-09-04 17:00:16 --> Output Class Initialized
INFO - 2024-09-04 17:00:16 --> Security Class Initialized
DEBUG - 2024-09-04 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:00:16 --> Input Class Initialized
INFO - 2024-09-04 17:00:16 --> Language Class Initialized
ERROR - 2024-09-04 17:00:16 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\antrol\application\controllers\Report.php 16
INFO - 2024-09-04 17:00:17 --> Config Class Initialized
INFO - 2024-09-04 17:00:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:00:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:00:17 --> Utf8 Class Initialized
INFO - 2024-09-04 17:00:17 --> URI Class Initialized
INFO - 2024-09-04 17:00:17 --> Router Class Initialized
INFO - 2024-09-04 17:00:17 --> Output Class Initialized
INFO - 2024-09-04 17:00:17 --> Security Class Initialized
DEBUG - 2024-09-04 17:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:00:17 --> Input Class Initialized
INFO - 2024-09-04 17:00:17 --> Language Class Initialized
ERROR - 2024-09-04 17:00:17 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\antrol\application\controllers\Report.php 16
INFO - 2024-09-04 17:00:18 --> Config Class Initialized
INFO - 2024-09-04 17:00:18 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:00:18 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:00:18 --> Utf8 Class Initialized
INFO - 2024-09-04 17:00:18 --> URI Class Initialized
INFO - 2024-09-04 17:00:18 --> Router Class Initialized
INFO - 2024-09-04 17:00:18 --> Output Class Initialized
INFO - 2024-09-04 17:00:18 --> Security Class Initialized
DEBUG - 2024-09-04 17:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:00:18 --> Input Class Initialized
INFO - 2024-09-04 17:00:18 --> Language Class Initialized
ERROR - 2024-09-04 17:00:18 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\antrol\application\controllers\Report.php 16
INFO - 2024-09-04 17:01:19 --> Config Class Initialized
INFO - 2024-09-04 17:01:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:01:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:01:19 --> Utf8 Class Initialized
INFO - 2024-09-04 17:01:19 --> URI Class Initialized
INFO - 2024-09-04 17:01:19 --> Router Class Initialized
INFO - 2024-09-04 17:01:19 --> Output Class Initialized
INFO - 2024-09-04 17:01:19 --> Security Class Initialized
DEBUG - 2024-09-04 17:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:01:19 --> Input Class Initialized
INFO - 2024-09-04 17:01:19 --> Language Class Initialized
INFO - 2024-09-04 17:01:19 --> Loader Class Initialized
INFO - 2024-09-04 17:01:19 --> Helper loaded: url_helper
INFO - 2024-09-04 17:01:19 --> Helper loaded: file_helper
INFO - 2024-09-04 17:01:19 --> Helper loaded: security_helper
INFO - 2024-09-04 17:01:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:01:19 --> Database Driver Class Initialized
INFO - 2024-09-04 17:01:19 --> Email Class Initialized
DEBUG - 2024-09-04 17:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:01:19 --> Helper loaded: form_helper
INFO - 2024-09-04 17:01:19 --> Form Validation Class Initialized
INFO - 2024-09-04 17:01:19 --> Controller Class Initialized
INFO - 2024-09-04 17:01:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:01:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:01:19 --> Query error: Unknown column 'inventaris.id_barang' in 'on clause' - Invalid query: SELECT `inventaris`.*, `inventaris_barang`.*, `inventaris_ruang`.*
FROM `inventaris`
JOIN `inventaris_barang` ON `inventaris`.`id_barang` = `inventaris_barang`.`id_barang`
JOIN `inventaris_ruang` ON `inventaris`.`id_ruang` = `inventaris_ruang`.`id_ruang`
INFO - 2024-09-04 17:01:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 17:04:11 --> Config Class Initialized
INFO - 2024-09-04 17:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:04:11 --> Utf8 Class Initialized
INFO - 2024-09-04 17:04:11 --> URI Class Initialized
INFO - 2024-09-04 17:04:11 --> Router Class Initialized
INFO - 2024-09-04 17:04:11 --> Output Class Initialized
INFO - 2024-09-04 17:04:11 --> Security Class Initialized
DEBUG - 2024-09-04 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:04:11 --> Input Class Initialized
INFO - 2024-09-04 17:04:11 --> Language Class Initialized
INFO - 2024-09-04 17:04:11 --> Loader Class Initialized
INFO - 2024-09-04 17:04:11 --> Helper loaded: url_helper
INFO - 2024-09-04 17:04:11 --> Helper loaded: file_helper
INFO - 2024-09-04 17:04:11 --> Helper loaded: security_helper
INFO - 2024-09-04 17:04:11 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:04:11 --> Database Driver Class Initialized
INFO - 2024-09-04 17:04:11 --> Email Class Initialized
DEBUG - 2024-09-04 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:04:11 --> Helper loaded: form_helper
INFO - 2024-09-04 17:04:11 --> Form Validation Class Initialized
INFO - 2024-09-04 17:04:11 --> Controller Class Initialized
INFO - 2024-09-04 17:04:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:04:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:04:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`, `menu`
                            FROM `user_menu` JOIN `user_access_menu`
                              ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                           WHERE `user_access_menu`.`id_role` = 
                        ORDER BY `user_access_menu`.`menu_id` ASC
                        
INFO - 2024-09-04 17:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 17:04:21 --> Config Class Initialized
INFO - 2024-09-04 17:04:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:04:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:04:21 --> Utf8 Class Initialized
INFO - 2024-09-04 17:04:21 --> URI Class Initialized
INFO - 2024-09-04 17:04:21 --> Router Class Initialized
INFO - 2024-09-04 17:04:21 --> Output Class Initialized
INFO - 2024-09-04 17:04:21 --> Security Class Initialized
DEBUG - 2024-09-04 17:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:04:21 --> Input Class Initialized
INFO - 2024-09-04 17:04:21 --> Language Class Initialized
INFO - 2024-09-04 17:04:21 --> Loader Class Initialized
INFO - 2024-09-04 17:04:21 --> Helper loaded: url_helper
INFO - 2024-09-04 17:04:21 --> Helper loaded: file_helper
INFO - 2024-09-04 17:04:21 --> Helper loaded: security_helper
INFO - 2024-09-04 17:04:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:04:21 --> Database Driver Class Initialized
INFO - 2024-09-04 17:04:21 --> Email Class Initialized
DEBUG - 2024-09-04 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:04:21 --> Helper loaded: form_helper
INFO - 2024-09-04 17:04:21 --> Form Validation Class Initialized
INFO - 2024-09-04 17:04:21 --> Controller Class Initialized
INFO - 2024-09-04 17:04:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:04:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:04:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:05:48 --> Config Class Initialized
INFO - 2024-09-04 17:05:48 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:05:48 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:05:48 --> Utf8 Class Initialized
INFO - 2024-09-04 17:05:48 --> URI Class Initialized
DEBUG - 2024-09-04 17:05:48 --> No URI present. Default controller set.
INFO - 2024-09-04 17:05:48 --> Router Class Initialized
INFO - 2024-09-04 17:05:48 --> Output Class Initialized
INFO - 2024-09-04 17:05:48 --> Security Class Initialized
DEBUG - 2024-09-04 17:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:05:48 --> Input Class Initialized
INFO - 2024-09-04 17:05:48 --> Language Class Initialized
INFO - 2024-09-04 17:05:48 --> Loader Class Initialized
INFO - 2024-09-04 17:05:48 --> Helper loaded: url_helper
INFO - 2024-09-04 17:05:48 --> Helper loaded: file_helper
INFO - 2024-09-04 17:05:48 --> Helper loaded: security_helper
INFO - 2024-09-04 17:05:48 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:05:48 --> Database Driver Class Initialized
INFO - 2024-09-04 17:05:48 --> Email Class Initialized
DEBUG - 2024-09-04 17:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:05:48 --> Helper loaded: form_helper
INFO - 2024-09-04 17:05:48 --> Form Validation Class Initialized
INFO - 2024-09-04 17:05:48 --> Controller Class Initialized
DEBUG - 2024-09-04 17:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:05:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:05:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:05:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:05:48 --> Final output sent to browser
DEBUG - 2024-09-04 17:05:48 --> Total execution time: 0.0407
INFO - 2024-09-04 17:05:55 --> Config Class Initialized
INFO - 2024-09-04 17:05:55 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:05:55 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:05:55 --> Utf8 Class Initialized
INFO - 2024-09-04 17:05:55 --> URI Class Initialized
DEBUG - 2024-09-04 17:05:55 --> No URI present. Default controller set.
INFO - 2024-09-04 17:05:55 --> Router Class Initialized
INFO - 2024-09-04 17:05:55 --> Output Class Initialized
INFO - 2024-09-04 17:05:55 --> Security Class Initialized
DEBUG - 2024-09-04 17:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:05:55 --> Input Class Initialized
INFO - 2024-09-04 17:05:55 --> Language Class Initialized
INFO - 2024-09-04 17:05:55 --> Loader Class Initialized
INFO - 2024-09-04 17:05:55 --> Helper loaded: url_helper
INFO - 2024-09-04 17:05:55 --> Helper loaded: file_helper
INFO - 2024-09-04 17:05:55 --> Helper loaded: security_helper
INFO - 2024-09-04 17:05:55 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:05:55 --> Database Driver Class Initialized
INFO - 2024-09-04 17:05:55 --> Email Class Initialized
DEBUG - 2024-09-04 17:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:05:55 --> Helper loaded: form_helper
INFO - 2024-09-04 17:05:55 --> Form Validation Class Initialized
INFO - 2024-09-04 17:05:55 --> Controller Class Initialized
DEBUG - 2024-09-04 17:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:05:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:05:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:05:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:05:55 --> Final output sent to browser
DEBUG - 2024-09-04 17:05:55 --> Total execution time: 0.0660
INFO - 2024-09-04 17:05:56 --> Config Class Initialized
INFO - 2024-09-04 17:05:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:05:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:05:56 --> Utf8 Class Initialized
INFO - 2024-09-04 17:05:56 --> URI Class Initialized
DEBUG - 2024-09-04 17:05:56 --> No URI present. Default controller set.
INFO - 2024-09-04 17:05:56 --> Router Class Initialized
INFO - 2024-09-04 17:05:56 --> Output Class Initialized
INFO - 2024-09-04 17:05:56 --> Security Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:05:56 --> Input Class Initialized
INFO - 2024-09-04 17:05:56 --> Language Class Initialized
INFO - 2024-09-04 17:05:56 --> Loader Class Initialized
INFO - 2024-09-04 17:05:56 --> Helper loaded: url_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: file_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: security_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:05:56 --> Database Driver Class Initialized
INFO - 2024-09-04 17:05:56 --> Email Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:05:56 --> Helper loaded: form_helper
INFO - 2024-09-04 17:05:56 --> Form Validation Class Initialized
INFO - 2024-09-04 17:05:56 --> Controller Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:05:56 --> Final output sent to browser
DEBUG - 2024-09-04 17:05:56 --> Total execution time: 0.0481
INFO - 2024-09-04 17:05:56 --> Config Class Initialized
INFO - 2024-09-04 17:05:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:05:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:05:56 --> Utf8 Class Initialized
INFO - 2024-09-04 17:05:56 --> URI Class Initialized
DEBUG - 2024-09-04 17:05:56 --> No URI present. Default controller set.
INFO - 2024-09-04 17:05:56 --> Router Class Initialized
INFO - 2024-09-04 17:05:56 --> Output Class Initialized
INFO - 2024-09-04 17:05:56 --> Security Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:05:56 --> Input Class Initialized
INFO - 2024-09-04 17:05:56 --> Language Class Initialized
INFO - 2024-09-04 17:05:56 --> Loader Class Initialized
INFO - 2024-09-04 17:05:56 --> Helper loaded: url_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: file_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: security_helper
INFO - 2024-09-04 17:05:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:05:56 --> Database Driver Class Initialized
INFO - 2024-09-04 17:05:56 --> Email Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:05:56 --> Helper loaded: form_helper
INFO - 2024-09-04 17:05:56 --> Form Validation Class Initialized
INFO - 2024-09-04 17:05:56 --> Controller Class Initialized
DEBUG - 2024-09-04 17:05:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:05:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:05:56 --> Final output sent to browser
DEBUG - 2024-09-04 17:05:56 --> Total execution time: 0.0655
INFO - 2024-09-04 17:06:00 --> Config Class Initialized
INFO - 2024-09-04 17:06:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:06:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:06:00 --> Utf8 Class Initialized
INFO - 2024-09-04 17:06:00 --> URI Class Initialized
DEBUG - 2024-09-04 17:06:00 --> No URI present. Default controller set.
INFO - 2024-09-04 17:06:00 --> Router Class Initialized
INFO - 2024-09-04 17:06:00 --> Output Class Initialized
INFO - 2024-09-04 17:06:00 --> Security Class Initialized
DEBUG - 2024-09-04 17:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:06:00 --> Input Class Initialized
INFO - 2024-09-04 17:06:00 --> Language Class Initialized
INFO - 2024-09-04 17:06:00 --> Loader Class Initialized
INFO - 2024-09-04 17:06:00 --> Helper loaded: url_helper
INFO - 2024-09-04 17:06:00 --> Helper loaded: file_helper
INFO - 2024-09-04 17:06:00 --> Helper loaded: security_helper
INFO - 2024-09-04 17:06:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:06:00 --> Database Driver Class Initialized
INFO - 2024-09-04 17:06:00 --> Email Class Initialized
DEBUG - 2024-09-04 17:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:06:00 --> Helper loaded: form_helper
INFO - 2024-09-04 17:06:00 --> Form Validation Class Initialized
INFO - 2024-09-04 17:06:00 --> Controller Class Initialized
DEBUG - 2024-09-04 17:06:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:06:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:06:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:06:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:06:00 --> Final output sent to browser
DEBUG - 2024-09-04 17:06:00 --> Total execution time: 0.0640
INFO - 2024-09-04 17:06:12 --> Config Class Initialized
INFO - 2024-09-04 17:06:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:06:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:06:12 --> Utf8 Class Initialized
INFO - 2024-09-04 17:06:12 --> URI Class Initialized
INFO - 2024-09-04 17:06:12 --> Router Class Initialized
INFO - 2024-09-04 17:06:12 --> Output Class Initialized
INFO - 2024-09-04 17:06:12 --> Security Class Initialized
DEBUG - 2024-09-04 17:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:06:12 --> Input Class Initialized
INFO - 2024-09-04 17:06:12 --> Language Class Initialized
ERROR - 2024-09-04 17:06:12 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-04 17:06:30 --> Config Class Initialized
INFO - 2024-09-04 17:06:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:06:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:06:30 --> Utf8 Class Initialized
INFO - 2024-09-04 17:06:30 --> URI Class Initialized
INFO - 2024-09-04 17:06:30 --> Router Class Initialized
INFO - 2024-09-04 17:06:30 --> Output Class Initialized
INFO - 2024-09-04 17:06:30 --> Security Class Initialized
DEBUG - 2024-09-04 17:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:06:30 --> Input Class Initialized
INFO - 2024-09-04 17:06:30 --> Language Class Initialized
INFO - 2024-09-04 17:06:30 --> Loader Class Initialized
INFO - 2024-09-04 17:06:30 --> Helper loaded: url_helper
INFO - 2024-09-04 17:06:30 --> Helper loaded: file_helper
INFO - 2024-09-04 17:06:30 --> Helper loaded: security_helper
INFO - 2024-09-04 17:06:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:06:30 --> Database Driver Class Initialized
INFO - 2024-09-04 17:06:30 --> Email Class Initialized
DEBUG - 2024-09-04 17:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:06:30 --> Helper loaded: form_helper
INFO - 2024-09-04 17:06:30 --> Form Validation Class Initialized
INFO - 2024-09-04 17:06:30 --> Controller Class Initialized
INFO - 2024-09-04 17:06:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:06:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:06:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:06:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:06:30 --> Final output sent to browser
DEBUG - 2024-09-04 17:06:30 --> Total execution time: 0.0712
INFO - 2024-09-04 17:07:00 --> Config Class Initialized
INFO - 2024-09-04 17:07:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:07:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:07:00 --> Utf8 Class Initialized
INFO - 2024-09-04 17:07:00 --> URI Class Initialized
INFO - 2024-09-04 17:07:00 --> Router Class Initialized
INFO - 2024-09-04 17:07:00 --> Output Class Initialized
INFO - 2024-09-04 17:07:00 --> Security Class Initialized
DEBUG - 2024-09-04 17:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:07:00 --> Input Class Initialized
INFO - 2024-09-04 17:07:00 --> Language Class Initialized
ERROR - 2024-09-04 17:07:00 --> 404 Page Not Found: Data/index
INFO - 2024-09-04 17:07:02 --> Config Class Initialized
INFO - 2024-09-04 17:07:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:07:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:07:02 --> Utf8 Class Initialized
INFO - 2024-09-04 17:07:02 --> URI Class Initialized
INFO - 2024-09-04 17:07:02 --> Router Class Initialized
INFO - 2024-09-04 17:07:02 --> Output Class Initialized
INFO - 2024-09-04 17:07:02 --> Security Class Initialized
DEBUG - 2024-09-04 17:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:07:02 --> Input Class Initialized
INFO - 2024-09-04 17:07:02 --> Language Class Initialized
INFO - 2024-09-04 17:07:02 --> Loader Class Initialized
INFO - 2024-09-04 17:07:02 --> Helper loaded: url_helper
INFO - 2024-09-04 17:07:02 --> Helper loaded: file_helper
INFO - 2024-09-04 17:07:02 --> Helper loaded: security_helper
INFO - 2024-09-04 17:07:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:07:02 --> Database Driver Class Initialized
INFO - 2024-09-04 17:07:02 --> Email Class Initialized
DEBUG - 2024-09-04 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:07:02 --> Helper loaded: form_helper
INFO - 2024-09-04 17:07:02 --> Form Validation Class Initialized
INFO - 2024-09-04 17:07:02 --> Controller Class Initialized
INFO - 2024-09-04 17:07:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:07:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:07:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:07:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:07:02 --> Final output sent to browser
DEBUG - 2024-09-04 17:07:02 --> Total execution time: 0.0923
INFO - 2024-09-04 17:07:42 --> Config Class Initialized
INFO - 2024-09-04 17:07:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:07:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:07:42 --> Utf8 Class Initialized
INFO - 2024-09-04 17:07:42 --> URI Class Initialized
INFO - 2024-09-04 17:07:42 --> Router Class Initialized
INFO - 2024-09-04 17:07:42 --> Output Class Initialized
INFO - 2024-09-04 17:07:42 --> Security Class Initialized
DEBUG - 2024-09-04 17:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:07:42 --> Input Class Initialized
INFO - 2024-09-04 17:07:42 --> Language Class Initialized
INFO - 2024-09-04 17:07:42 --> Loader Class Initialized
INFO - 2024-09-04 17:07:42 --> Helper loaded: url_helper
INFO - 2024-09-04 17:07:42 --> Helper loaded: file_helper
INFO - 2024-09-04 17:07:42 --> Helper loaded: security_helper
INFO - 2024-09-04 17:07:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:07:42 --> Database Driver Class Initialized
INFO - 2024-09-04 17:07:42 --> Email Class Initialized
DEBUG - 2024-09-04 17:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:07:42 --> Helper loaded: form_helper
INFO - 2024-09-04 17:07:42 --> Form Validation Class Initialized
INFO - 2024-09-04 17:07:42 --> Controller Class Initialized
INFO - 2024-09-04 17:07:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:07:42 --> Final output sent to browser
DEBUG - 2024-09-04 17:07:42 --> Total execution time: 0.0779
INFO - 2024-09-04 17:07:46 --> Config Class Initialized
INFO - 2024-09-04 17:07:46 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:07:46 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:07:46 --> Utf8 Class Initialized
INFO - 2024-09-04 17:07:46 --> URI Class Initialized
INFO - 2024-09-04 17:07:46 --> Router Class Initialized
INFO - 2024-09-04 17:07:46 --> Output Class Initialized
INFO - 2024-09-04 17:07:46 --> Security Class Initialized
DEBUG - 2024-09-04 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:07:46 --> Input Class Initialized
INFO - 2024-09-04 17:07:46 --> Language Class Initialized
INFO - 2024-09-04 17:07:46 --> Loader Class Initialized
INFO - 2024-09-04 17:07:46 --> Helper loaded: url_helper
INFO - 2024-09-04 17:07:46 --> Helper loaded: file_helper
INFO - 2024-09-04 17:07:46 --> Helper loaded: security_helper
INFO - 2024-09-04 17:07:46 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:07:46 --> Database Driver Class Initialized
INFO - 2024-09-04 17:07:46 --> Email Class Initialized
DEBUG - 2024-09-04 17:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:07:46 --> Helper loaded: form_helper
INFO - 2024-09-04 17:07:46 --> Form Validation Class Initialized
INFO - 2024-09-04 17:07:46 --> Controller Class Initialized
INFO - 2024-09-04 17:07:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:07:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:07:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:07:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:07:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:07:46 --> Final output sent to browser
DEBUG - 2024-09-04 17:07:46 --> Total execution time: 0.2557
INFO - 2024-09-04 17:08:41 --> Config Class Initialized
INFO - 2024-09-04 17:08:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:08:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:08:41 --> Utf8 Class Initialized
INFO - 2024-09-04 17:08:41 --> URI Class Initialized
INFO - 2024-09-04 17:08:41 --> Router Class Initialized
INFO - 2024-09-04 17:08:41 --> Output Class Initialized
INFO - 2024-09-04 17:08:41 --> Security Class Initialized
DEBUG - 2024-09-04 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:08:41 --> Input Class Initialized
INFO - 2024-09-04 17:08:41 --> Language Class Initialized
INFO - 2024-09-04 17:08:41 --> Loader Class Initialized
INFO - 2024-09-04 17:08:41 --> Helper loaded: url_helper
INFO - 2024-09-04 17:08:41 --> Helper loaded: file_helper
INFO - 2024-09-04 17:08:42 --> Helper loaded: security_helper
INFO - 2024-09-04 17:08:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:08:42 --> Database Driver Class Initialized
INFO - 2024-09-04 17:08:42 --> Email Class Initialized
DEBUG - 2024-09-04 17:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:08:42 --> Helper loaded: form_helper
INFO - 2024-09-04 17:08:42 --> Form Validation Class Initialized
INFO - 2024-09-04 17:08:42 --> Controller Class Initialized
INFO - 2024-09-04 17:08:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:08:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:08:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:08:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:08:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:08:42 --> Final output sent to browser
DEBUG - 2024-09-04 17:08:42 --> Total execution time: 0.2399
INFO - 2024-09-04 17:08:43 --> Config Class Initialized
INFO - 2024-09-04 17:08:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:08:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:08:43 --> Utf8 Class Initialized
INFO - 2024-09-04 17:08:43 --> URI Class Initialized
INFO - 2024-09-04 17:08:43 --> Router Class Initialized
INFO - 2024-09-04 17:08:43 --> Output Class Initialized
INFO - 2024-09-04 17:08:43 --> Security Class Initialized
DEBUG - 2024-09-04 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:08:43 --> Input Class Initialized
INFO - 2024-09-04 17:08:43 --> Language Class Initialized
INFO - 2024-09-04 17:08:43 --> Loader Class Initialized
INFO - 2024-09-04 17:08:43 --> Helper loaded: url_helper
INFO - 2024-09-04 17:08:43 --> Helper loaded: file_helper
INFO - 2024-09-04 17:08:43 --> Helper loaded: security_helper
INFO - 2024-09-04 17:08:43 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:08:43 --> Database Driver Class Initialized
INFO - 2024-09-04 17:08:43 --> Email Class Initialized
DEBUG - 2024-09-04 17:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:08:43 --> Helper loaded: form_helper
INFO - 2024-09-04 17:08:43 --> Form Validation Class Initialized
INFO - 2024-09-04 17:08:43 --> Controller Class Initialized
INFO - 2024-09-04 17:08:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:08:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:08:49 --> Config Class Initialized
INFO - 2024-09-04 17:08:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:08:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:08:49 --> Utf8 Class Initialized
INFO - 2024-09-04 17:08:49 --> URI Class Initialized
INFO - 2024-09-04 17:08:49 --> Router Class Initialized
INFO - 2024-09-04 17:08:49 --> Output Class Initialized
INFO - 2024-09-04 17:08:49 --> Security Class Initialized
DEBUG - 2024-09-04 17:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:08:49 --> Input Class Initialized
INFO - 2024-09-04 17:08:49 --> Language Class Initialized
INFO - 2024-09-04 17:08:49 --> Loader Class Initialized
INFO - 2024-09-04 17:08:49 --> Helper loaded: url_helper
INFO - 2024-09-04 17:08:49 --> Helper loaded: file_helper
INFO - 2024-09-04 17:08:49 --> Helper loaded: security_helper
INFO - 2024-09-04 17:08:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:08:49 --> Database Driver Class Initialized
INFO - 2024-09-04 17:08:49 --> Email Class Initialized
DEBUG - 2024-09-04 17:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:08:50 --> Config Class Initialized
INFO - 2024-09-04 17:08:50 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:08:50 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:08:50 --> Utf8 Class Initialized
INFO - 2024-09-04 17:08:50 --> URI Class Initialized
INFO - 2024-09-04 17:08:50 --> Router Class Initialized
INFO - 2024-09-04 17:08:50 --> Output Class Initialized
INFO - 2024-09-04 17:08:50 --> Security Class Initialized
DEBUG - 2024-09-04 17:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:08:50 --> Input Class Initialized
INFO - 2024-09-04 17:08:50 --> Language Class Initialized
INFO - 2024-09-04 17:08:50 --> Loader Class Initialized
INFO - 2024-09-04 17:08:50 --> Helper loaded: url_helper
INFO - 2024-09-04 17:08:50 --> Helper loaded: file_helper
INFO - 2024-09-04 17:08:50 --> Helper loaded: security_helper
INFO - 2024-09-04 17:08:50 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:08:50 --> Database Driver Class Initialized
INFO - 2024-09-04 17:08:50 --> Email Class Initialized
DEBUG - 2024-09-04 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:08:51 --> Config Class Initialized
INFO - 2024-09-04 17:08:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:08:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:08:51 --> Utf8 Class Initialized
INFO - 2024-09-04 17:08:51 --> URI Class Initialized
INFO - 2024-09-04 17:08:51 --> Router Class Initialized
INFO - 2024-09-04 17:08:51 --> Output Class Initialized
INFO - 2024-09-04 17:08:51 --> Security Class Initialized
DEBUG - 2024-09-04 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:08:51 --> Input Class Initialized
INFO - 2024-09-04 17:08:51 --> Language Class Initialized
INFO - 2024-09-04 17:08:51 --> Loader Class Initialized
INFO - 2024-09-04 17:08:51 --> Helper loaded: url_helper
INFO - 2024-09-04 17:08:51 --> Helper loaded: file_helper
INFO - 2024-09-04 17:08:51 --> Helper loaded: security_helper
INFO - 2024-09-04 17:08:51 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:08:51 --> Database Driver Class Initialized
INFO - 2024-09-04 17:08:51 --> Email Class Initialized
DEBUG - 2024-09-04 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:09:13 --> Helper loaded: form_helper
INFO - 2024-09-04 17:09:13 --> Helper loaded: form_helper
INFO - 2024-09-04 17:09:13 --> Form Validation Class Initialized
INFO - 2024-09-04 17:09:13 --> Form Validation Class Initialized
INFO - 2024-09-04 17:09:13 --> Controller Class Initialized
INFO - 2024-09-04 17:09:13 --> Controller Class Initialized
INFO - 2024-09-04 17:09:13 --> Model "Antrol_model" initialized
INFO - 2024-09-04 17:09:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-09-04 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:09:13 --> Final output sent to browser
DEBUG - 2024-09-04 17:09:13 --> Total execution time: 24.4290
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:09:13 --> Final output sent to browser
DEBUG - 2024-09-04 17:09:13 --> Total execution time: 23.3341
INFO - 2024-09-04 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:09:13 --> Helper loaded: form_helper
INFO - 2024-09-04 17:09:13 --> Form Validation Class Initialized
INFO - 2024-09-04 17:09:13 --> Controller Class Initialized
INFO - 2024-09-04 17:09:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:09:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:09:13 --> Final output sent to browser
DEBUG - 2024-09-04 17:09:13 --> Total execution time: 22.0976
INFO - 2024-09-04 17:09:18 --> Config Class Initialized
INFO - 2024-09-04 17:09:18 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:09:18 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:09:18 --> Utf8 Class Initialized
INFO - 2024-09-04 17:09:18 --> URI Class Initialized
INFO - 2024-09-04 17:09:18 --> Router Class Initialized
INFO - 2024-09-04 17:09:18 --> Output Class Initialized
INFO - 2024-09-04 17:09:18 --> Security Class Initialized
DEBUG - 2024-09-04 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:09:18 --> Input Class Initialized
INFO - 2024-09-04 17:09:18 --> Language Class Initialized
INFO - 2024-09-04 17:09:18 --> Loader Class Initialized
INFO - 2024-09-04 17:09:18 --> Helper loaded: url_helper
INFO - 2024-09-04 17:09:18 --> Helper loaded: file_helper
INFO - 2024-09-04 17:09:18 --> Helper loaded: security_helper
INFO - 2024-09-04 17:09:18 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:09:18 --> Database Driver Class Initialized
INFO - 2024-09-04 17:09:18 --> Email Class Initialized
DEBUG - 2024-09-04 17:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:09:18 --> Helper loaded: form_helper
INFO - 2024-09-04 17:09:18 --> Form Validation Class Initialized
INFO - 2024-09-04 17:09:18 --> Controller Class Initialized
INFO - 2024-09-04 17:09:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:09:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:09:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:09:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\antrol\application\views\report\cetakantrol.php 107
INFO - 2024-09-04 17:10:27 --> Config Class Initialized
INFO - 2024-09-04 17:10:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:10:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:10:27 --> Utf8 Class Initialized
INFO - 2024-09-04 17:10:27 --> URI Class Initialized
INFO - 2024-09-04 17:10:27 --> Router Class Initialized
INFO - 2024-09-04 17:10:27 --> Output Class Initialized
INFO - 2024-09-04 17:10:27 --> Security Class Initialized
DEBUG - 2024-09-04 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:10:27 --> Input Class Initialized
INFO - 2024-09-04 17:10:27 --> Language Class Initialized
INFO - 2024-09-04 17:10:27 --> Loader Class Initialized
INFO - 2024-09-04 17:10:27 --> Helper loaded: url_helper
INFO - 2024-09-04 17:10:27 --> Helper loaded: file_helper
INFO - 2024-09-04 17:10:27 --> Helper loaded: security_helper
INFO - 2024-09-04 17:10:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:10:27 --> Database Driver Class Initialized
INFO - 2024-09-04 17:10:27 --> Email Class Initialized
DEBUG - 2024-09-04 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:10:27 --> Helper loaded: form_helper
INFO - 2024-09-04 17:10:27 --> Form Validation Class Initialized
INFO - 2024-09-04 17:10:27 --> Controller Class Initialized
INFO - 2024-09-04 17:10:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:10:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:10:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:10:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:10:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:10:28 --> Final output sent to browser
DEBUG - 2024-09-04 17:10:28 --> Total execution time: 0.4066
INFO - 2024-09-04 17:12:08 --> Config Class Initialized
INFO - 2024-09-04 17:12:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:12:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:12:08 --> Utf8 Class Initialized
INFO - 2024-09-04 17:12:08 --> URI Class Initialized
INFO - 2024-09-04 17:12:08 --> Router Class Initialized
INFO - 2024-09-04 17:12:08 --> Output Class Initialized
INFO - 2024-09-04 17:12:08 --> Security Class Initialized
DEBUG - 2024-09-04 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:12:08 --> Input Class Initialized
INFO - 2024-09-04 17:12:08 --> Language Class Initialized
INFO - 2024-09-04 17:12:08 --> Loader Class Initialized
INFO - 2024-09-04 17:12:08 --> Helper loaded: url_helper
INFO - 2024-09-04 17:12:08 --> Helper loaded: file_helper
INFO - 2024-09-04 17:12:08 --> Helper loaded: security_helper
INFO - 2024-09-04 17:12:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:12:08 --> Database Driver Class Initialized
INFO - 2024-09-04 17:12:08 --> Email Class Initialized
DEBUG - 2024-09-04 17:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:12:08 --> Helper loaded: form_helper
INFO - 2024-09-04 17:12:08 --> Form Validation Class Initialized
INFO - 2024-09-04 17:12:08 --> Controller Class Initialized
INFO - 2024-09-04 17:12:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:12:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:12:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:12:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:12:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:12:09 --> Final output sent to browser
DEBUG - 2024-09-04 17:12:09 --> Total execution time: 0.4799
INFO - 2024-09-04 17:12:12 --> Config Class Initialized
INFO - 2024-09-04 17:12:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:12:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:12:12 --> Utf8 Class Initialized
INFO - 2024-09-04 17:12:12 --> URI Class Initialized
DEBUG - 2024-09-04 17:12:12 --> No URI present. Default controller set.
INFO - 2024-09-04 17:12:12 --> Router Class Initialized
INFO - 2024-09-04 17:12:12 --> Output Class Initialized
INFO - 2024-09-04 17:12:12 --> Security Class Initialized
DEBUG - 2024-09-04 17:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:12:12 --> Input Class Initialized
INFO - 2024-09-04 17:12:12 --> Language Class Initialized
INFO - 2024-09-04 17:12:12 --> Loader Class Initialized
INFO - 2024-09-04 17:12:12 --> Helper loaded: url_helper
INFO - 2024-09-04 17:12:12 --> Helper loaded: file_helper
INFO - 2024-09-04 17:12:12 --> Helper loaded: security_helper
INFO - 2024-09-04 17:12:12 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:12:12 --> Database Driver Class Initialized
INFO - 2024-09-04 17:12:12 --> Email Class Initialized
DEBUG - 2024-09-04 17:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:12:12 --> Helper loaded: form_helper
INFO - 2024-09-04 17:12:12 --> Form Validation Class Initialized
INFO - 2024-09-04 17:12:12 --> Controller Class Initialized
DEBUG - 2024-09-04 17:12:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:12:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:12:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:12:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:12:12 --> Final output sent to browser
DEBUG - 2024-09-04 17:12:12 --> Total execution time: 0.0562
INFO - 2024-09-04 17:12:22 --> Config Class Initialized
INFO - 2024-09-04 17:12:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:12:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:12:22 --> Utf8 Class Initialized
INFO - 2024-09-04 17:12:22 --> URI Class Initialized
INFO - 2024-09-04 17:12:22 --> Router Class Initialized
INFO - 2024-09-04 17:12:22 --> Output Class Initialized
INFO - 2024-09-04 17:12:22 --> Security Class Initialized
DEBUG - 2024-09-04 17:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:12:22 --> Input Class Initialized
INFO - 2024-09-04 17:12:22 --> Language Class Initialized
INFO - 2024-09-04 17:12:22 --> Loader Class Initialized
INFO - 2024-09-04 17:12:22 --> Helper loaded: url_helper
INFO - 2024-09-04 17:12:22 --> Helper loaded: file_helper
INFO - 2024-09-04 17:12:22 --> Helper loaded: security_helper
INFO - 2024-09-04 17:12:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:12:22 --> Database Driver Class Initialized
INFO - 2024-09-04 17:12:22 --> Email Class Initialized
DEBUG - 2024-09-04 17:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:12:22 --> Helper loaded: form_helper
INFO - 2024-09-04 17:12:22 --> Form Validation Class Initialized
INFO - 2024-09-04 17:12:22 --> Controller Class Initialized
INFO - 2024-09-04 17:12:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:12:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:12:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:12:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:12:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:12:22 --> Final output sent to browser
DEBUG - 2024-09-04 17:12:22 --> Total execution time: 0.3692
INFO - 2024-09-04 17:13:22 --> Config Class Initialized
INFO - 2024-09-04 17:13:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:13:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:13:22 --> Utf8 Class Initialized
INFO - 2024-09-04 17:13:22 --> URI Class Initialized
INFO - 2024-09-04 17:13:22 --> Router Class Initialized
INFO - 2024-09-04 17:13:22 --> Output Class Initialized
INFO - 2024-09-04 17:13:22 --> Security Class Initialized
DEBUG - 2024-09-04 17:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:13:22 --> Input Class Initialized
INFO - 2024-09-04 17:13:22 --> Language Class Initialized
INFO - 2024-09-04 17:13:22 --> Loader Class Initialized
INFO - 2024-09-04 17:13:22 --> Helper loaded: url_helper
INFO - 2024-09-04 17:13:22 --> Helper loaded: file_helper
INFO - 2024-09-04 17:13:22 --> Helper loaded: security_helper
INFO - 2024-09-04 17:13:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:13:22 --> Database Driver Class Initialized
ERROR - 2024-09-04 17:13:26 --> Unable to connect to the database
INFO - 2024-09-04 17:13:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 17:13:29 --> Config Class Initialized
INFO - 2024-09-04 17:13:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:13:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:13:29 --> Utf8 Class Initialized
INFO - 2024-09-04 17:13:29 --> URI Class Initialized
INFO - 2024-09-04 17:13:29 --> Router Class Initialized
INFO - 2024-09-04 17:13:29 --> Output Class Initialized
INFO - 2024-09-04 17:13:29 --> Security Class Initialized
DEBUG - 2024-09-04 17:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:13:29 --> Input Class Initialized
INFO - 2024-09-04 17:13:29 --> Language Class Initialized
INFO - 2024-09-04 17:13:29 --> Loader Class Initialized
INFO - 2024-09-04 17:13:29 --> Helper loaded: url_helper
INFO - 2024-09-04 17:13:29 --> Helper loaded: file_helper
INFO - 2024-09-04 17:13:29 --> Helper loaded: security_helper
INFO - 2024-09-04 17:13:29 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:13:29 --> Database Driver Class Initialized
INFO - 2024-09-04 17:13:32 --> Email Class Initialized
DEBUG - 2024-09-04 17:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:13:32 --> Helper loaded: form_helper
INFO - 2024-09-04 17:13:32 --> Form Validation Class Initialized
INFO - 2024-09-04 17:13:32 --> Controller Class Initialized
INFO - 2024-09-04 17:13:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:13:32 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:13:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:13:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:13:33 --> Final output sent to browser
DEBUG - 2024-09-04 17:13:33 --> Total execution time: 3.4630
INFO - 2024-09-04 17:14:32 --> Config Class Initialized
INFO - 2024-09-04 17:14:32 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:14:32 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:14:32 --> Utf8 Class Initialized
INFO - 2024-09-04 17:14:32 --> URI Class Initialized
INFO - 2024-09-04 17:14:32 --> Router Class Initialized
INFO - 2024-09-04 17:14:32 --> Output Class Initialized
INFO - 2024-09-04 17:14:32 --> Security Class Initialized
DEBUG - 2024-09-04 17:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:14:32 --> Input Class Initialized
INFO - 2024-09-04 17:14:32 --> Language Class Initialized
INFO - 2024-09-04 17:14:32 --> Loader Class Initialized
INFO - 2024-09-04 17:14:32 --> Helper loaded: url_helper
INFO - 2024-09-04 17:14:32 --> Helper loaded: file_helper
INFO - 2024-09-04 17:14:32 --> Helper loaded: security_helper
INFO - 2024-09-04 17:14:32 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:14:32 --> Database Driver Class Initialized
INFO - 2024-09-04 17:14:32 --> Email Class Initialized
DEBUG - 2024-09-04 17:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:14:32 --> Helper loaded: form_helper
INFO - 2024-09-04 17:14:32 --> Form Validation Class Initialized
INFO - 2024-09-04 17:14:32 --> Controller Class Initialized
INFO - 2024-09-04 17:14:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:14:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:14:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:14:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:14:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:14:33 --> Final output sent to browser
DEBUG - 2024-09-04 17:14:33 --> Total execution time: 0.4564
INFO - 2024-09-04 17:14:36 --> Config Class Initialized
INFO - 2024-09-04 17:14:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:14:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:14:36 --> Utf8 Class Initialized
INFO - 2024-09-04 17:14:36 --> URI Class Initialized
INFO - 2024-09-04 17:14:36 --> Router Class Initialized
INFO - 2024-09-04 17:14:36 --> Output Class Initialized
INFO - 2024-09-04 17:14:36 --> Security Class Initialized
DEBUG - 2024-09-04 17:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:14:36 --> Input Class Initialized
INFO - 2024-09-04 17:14:36 --> Language Class Initialized
INFO - 2024-09-04 17:14:36 --> Loader Class Initialized
INFO - 2024-09-04 17:14:36 --> Helper loaded: url_helper
INFO - 2024-09-04 17:14:36 --> Helper loaded: file_helper
INFO - 2024-09-04 17:14:36 --> Helper loaded: security_helper
INFO - 2024-09-04 17:14:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:14:36 --> Database Driver Class Initialized
INFO - 2024-09-04 17:14:36 --> Email Class Initialized
DEBUG - 2024-09-04 17:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:14:36 --> Helper loaded: form_helper
INFO - 2024-09-04 17:14:36 --> Form Validation Class Initialized
INFO - 2024-09-04 17:14:36 --> Controller Class Initialized
INFO - 2024-09-04 17:14:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:14:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:14:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:14:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:14:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:14:37 --> Final output sent to browser
DEBUG - 2024-09-04 17:14:37 --> Total execution time: 0.4871
INFO - 2024-09-04 17:18:09 --> Config Class Initialized
INFO - 2024-09-04 17:18:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:18:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:18:09 --> Utf8 Class Initialized
INFO - 2024-09-04 17:18:09 --> URI Class Initialized
INFO - 2024-09-04 17:18:09 --> Router Class Initialized
INFO - 2024-09-04 17:18:09 --> Output Class Initialized
INFO - 2024-09-04 17:18:09 --> Security Class Initialized
DEBUG - 2024-09-04 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:18:09 --> Input Class Initialized
INFO - 2024-09-04 17:18:09 --> Language Class Initialized
INFO - 2024-09-04 17:18:09 --> Loader Class Initialized
INFO - 2024-09-04 17:18:09 --> Helper loaded: url_helper
INFO - 2024-09-04 17:18:09 --> Helper loaded: file_helper
INFO - 2024-09-04 17:18:09 --> Helper loaded: security_helper
INFO - 2024-09-04 17:18:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:18:09 --> Database Driver Class Initialized
INFO - 2024-09-04 17:18:09 --> Email Class Initialized
DEBUG - 2024-09-04 17:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:18:09 --> Helper loaded: form_helper
INFO - 2024-09-04 17:18:09 --> Form Validation Class Initialized
INFO - 2024-09-04 17:18:09 --> Controller Class Initialized
INFO - 2024-09-04 17:18:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:18:09 --> Final output sent to browser
DEBUG - 2024-09-04 17:18:09 --> Total execution time: 0.2805
INFO - 2024-09-04 17:19:47 --> Config Class Initialized
INFO - 2024-09-04 17:19:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:19:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:19:47 --> Utf8 Class Initialized
INFO - 2024-09-04 17:19:47 --> URI Class Initialized
INFO - 2024-09-04 17:19:47 --> Router Class Initialized
INFO - 2024-09-04 17:19:47 --> Output Class Initialized
INFO - 2024-09-04 17:19:47 --> Security Class Initialized
DEBUG - 2024-09-04 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:19:47 --> Input Class Initialized
INFO - 2024-09-04 17:19:47 --> Language Class Initialized
INFO - 2024-09-04 17:19:47 --> Loader Class Initialized
INFO - 2024-09-04 17:19:47 --> Helper loaded: url_helper
INFO - 2024-09-04 17:19:47 --> Helper loaded: file_helper
INFO - 2024-09-04 17:19:47 --> Helper loaded: security_helper
INFO - 2024-09-04 17:19:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:19:47 --> Database Driver Class Initialized
INFO - 2024-09-04 17:19:47 --> Email Class Initialized
DEBUG - 2024-09-04 17:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:19:47 --> Helper loaded: form_helper
INFO - 2024-09-04 17:19:47 --> Form Validation Class Initialized
INFO - 2024-09-04 17:19:47 --> Controller Class Initialized
INFO - 2024-09-04 17:19:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:19:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:19:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:19:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:19:47 --> Final output sent to browser
DEBUG - 2024-09-04 17:19:47 --> Total execution time: 0.4100
INFO - 2024-09-04 17:20:30 --> Config Class Initialized
INFO - 2024-09-04 17:20:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:20:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:20:30 --> Utf8 Class Initialized
INFO - 2024-09-04 17:20:30 --> URI Class Initialized
DEBUG - 2024-09-04 17:20:30 --> No URI present. Default controller set.
INFO - 2024-09-04 17:20:30 --> Router Class Initialized
INFO - 2024-09-04 17:20:30 --> Output Class Initialized
INFO - 2024-09-04 17:20:30 --> Security Class Initialized
DEBUG - 2024-09-04 17:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:20:30 --> Input Class Initialized
INFO - 2024-09-04 17:20:30 --> Language Class Initialized
INFO - 2024-09-04 17:20:30 --> Loader Class Initialized
INFO - 2024-09-04 17:20:30 --> Helper loaded: url_helper
INFO - 2024-09-04 17:20:30 --> Helper loaded: file_helper
INFO - 2024-09-04 17:20:30 --> Helper loaded: security_helper
INFO - 2024-09-04 17:20:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:20:30 --> Database Driver Class Initialized
INFO - 2024-09-04 17:20:30 --> Email Class Initialized
DEBUG - 2024-09-04 17:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:20:30 --> Helper loaded: form_helper
INFO - 2024-09-04 17:20:30 --> Form Validation Class Initialized
INFO - 2024-09-04 17:20:30 --> Controller Class Initialized
DEBUG - 2024-09-04 17:20:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:20:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:20:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:20:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:20:30 --> Final output sent to browser
DEBUG - 2024-09-04 17:20:30 --> Total execution time: 0.0484
INFO - 2024-09-04 17:20:33 --> Config Class Initialized
INFO - 2024-09-04 17:20:33 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:20:33 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:20:33 --> Utf8 Class Initialized
INFO - 2024-09-04 17:20:33 --> URI Class Initialized
INFO - 2024-09-04 17:20:33 --> Router Class Initialized
INFO - 2024-09-04 17:20:33 --> Output Class Initialized
INFO - 2024-09-04 17:20:33 --> Security Class Initialized
DEBUG - 2024-09-04 17:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:20:33 --> Input Class Initialized
INFO - 2024-09-04 17:20:33 --> Language Class Initialized
INFO - 2024-09-04 17:20:33 --> Loader Class Initialized
INFO - 2024-09-04 17:20:33 --> Helper loaded: url_helper
INFO - 2024-09-04 17:20:33 --> Helper loaded: file_helper
INFO - 2024-09-04 17:20:33 --> Helper loaded: security_helper
INFO - 2024-09-04 17:20:33 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:20:33 --> Database Driver Class Initialized
INFO - 2024-09-04 17:20:33 --> Email Class Initialized
DEBUG - 2024-09-04 17:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:20:33 --> Helper loaded: form_helper
INFO - 2024-09-04 17:20:33 --> Form Validation Class Initialized
INFO - 2024-09-04 17:20:33 --> Controller Class Initialized
INFO - 2024-09-04 17:20:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:20:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:20:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:20:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:20:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:20:33 --> Final output sent to browser
DEBUG - 2024-09-04 17:20:33 --> Total execution time: 0.0845
INFO - 2024-09-04 17:20:40 --> Config Class Initialized
INFO - 2024-09-04 17:20:40 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:20:40 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:20:40 --> Utf8 Class Initialized
INFO - 2024-09-04 17:20:40 --> URI Class Initialized
INFO - 2024-09-04 17:20:40 --> Router Class Initialized
INFO - 2024-09-04 17:20:40 --> Output Class Initialized
INFO - 2024-09-04 17:20:40 --> Security Class Initialized
DEBUG - 2024-09-04 17:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:20:40 --> Input Class Initialized
INFO - 2024-09-04 17:20:40 --> Language Class Initialized
INFO - 2024-09-04 17:20:40 --> Loader Class Initialized
INFO - 2024-09-04 17:20:40 --> Helper loaded: url_helper
INFO - 2024-09-04 17:20:40 --> Helper loaded: file_helper
INFO - 2024-09-04 17:20:40 --> Helper loaded: security_helper
INFO - 2024-09-04 17:20:40 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:20:40 --> Database Driver Class Initialized
INFO - 2024-09-04 17:20:40 --> Email Class Initialized
DEBUG - 2024-09-04 17:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:20:40 --> Helper loaded: form_helper
INFO - 2024-09-04 17:20:40 --> Form Validation Class Initialized
INFO - 2024-09-04 17:20:40 --> Controller Class Initialized
INFO - 2024-09-04 17:20:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:20:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:20:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:20:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:20:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:20:40 --> Final output sent to browser
DEBUG - 2024-09-04 17:20:40 --> Total execution time: 0.2728
INFO - 2024-09-04 17:20:48 --> Config Class Initialized
INFO - 2024-09-04 17:20:48 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:20:48 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:20:48 --> Utf8 Class Initialized
INFO - 2024-09-04 17:20:48 --> URI Class Initialized
INFO - 2024-09-04 17:20:48 --> Router Class Initialized
INFO - 2024-09-04 17:20:48 --> Output Class Initialized
INFO - 2024-09-04 17:20:48 --> Security Class Initialized
DEBUG - 2024-09-04 17:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:20:48 --> Input Class Initialized
INFO - 2024-09-04 17:20:48 --> Language Class Initialized
ERROR - 2024-09-04 17:20:48 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:22:04 --> Config Class Initialized
INFO - 2024-09-04 17:22:04 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:22:04 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:22:04 --> Utf8 Class Initialized
INFO - 2024-09-04 17:22:04 --> URI Class Initialized
INFO - 2024-09-04 17:22:04 --> Router Class Initialized
INFO - 2024-09-04 17:22:04 --> Output Class Initialized
INFO - 2024-09-04 17:22:04 --> Security Class Initialized
DEBUG - 2024-09-04 17:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:22:04 --> Input Class Initialized
INFO - 2024-09-04 17:22:04 --> Language Class Initialized
INFO - 2024-09-04 17:22:04 --> Loader Class Initialized
INFO - 2024-09-04 17:22:04 --> Helper loaded: url_helper
INFO - 2024-09-04 17:22:04 --> Helper loaded: file_helper
INFO - 2024-09-04 17:22:04 --> Helper loaded: security_helper
INFO - 2024-09-04 17:22:04 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:22:04 --> Database Driver Class Initialized
INFO - 2024-09-04 17:22:04 --> Email Class Initialized
DEBUG - 2024-09-04 17:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:22:04 --> Helper loaded: form_helper
INFO - 2024-09-04 17:22:04 --> Form Validation Class Initialized
INFO - 2024-09-04 17:22:04 --> Controller Class Initialized
INFO - 2024-09-04 17:22:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:22:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:22:04 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:22:04 --> Final output sent to browser
DEBUG - 2024-09-04 17:22:04 --> Total execution time: 0.3142
INFO - 2024-09-04 17:22:11 --> Config Class Initialized
INFO - 2024-09-04 17:22:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:22:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:22:11 --> Utf8 Class Initialized
INFO - 2024-09-04 17:22:11 --> URI Class Initialized
INFO - 2024-09-04 17:22:11 --> Router Class Initialized
INFO - 2024-09-04 17:22:11 --> Output Class Initialized
INFO - 2024-09-04 17:22:11 --> Security Class Initialized
DEBUG - 2024-09-04 17:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:22:11 --> Input Class Initialized
INFO - 2024-09-04 17:22:11 --> Language Class Initialized
ERROR - 2024-09-04 17:22:11 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:29:35 --> Config Class Initialized
INFO - 2024-09-04 17:29:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:29:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:29:35 --> Utf8 Class Initialized
INFO - 2024-09-04 17:29:35 --> URI Class Initialized
INFO - 2024-09-04 17:29:35 --> Router Class Initialized
INFO - 2024-09-04 17:29:35 --> Output Class Initialized
INFO - 2024-09-04 17:29:35 --> Security Class Initialized
DEBUG - 2024-09-04 17:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:29:35 --> Input Class Initialized
INFO - 2024-09-04 17:29:35 --> Language Class Initialized
INFO - 2024-09-04 17:29:35 --> Loader Class Initialized
INFO - 2024-09-04 17:29:35 --> Helper loaded: url_helper
INFO - 2024-09-04 17:29:35 --> Helper loaded: file_helper
INFO - 2024-09-04 17:29:35 --> Helper loaded: security_helper
INFO - 2024-09-04 17:29:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:29:35 --> Database Driver Class Initialized
INFO - 2024-09-04 17:29:35 --> Email Class Initialized
DEBUG - 2024-09-04 17:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:29:35 --> Helper loaded: form_helper
INFO - 2024-09-04 17:29:35 --> Form Validation Class Initialized
INFO - 2024-09-04 17:29:35 --> Controller Class Initialized
INFO - 2024-09-04 17:29:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:29:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:29:35 --> Severity: Notice --> Undefined variable: label C:\xampp\htdocs\antrol\application\controllers\Report.php 61
ERROR - 2024-09-04 17:29:35 --> Severity: Notice --> Undefined variable: url_export C:\xampp\htdocs\antrol\application\controllers\Report.php 62
INFO - 2024-09-04 17:29:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:29:35 --> Final output sent to browser
DEBUG - 2024-09-04 17:29:35 --> Total execution time: 0.3869
INFO - 2024-09-04 17:29:45 --> Config Class Initialized
INFO - 2024-09-04 17:29:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:29:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:29:45 --> Utf8 Class Initialized
INFO - 2024-09-04 17:29:45 --> URI Class Initialized
INFO - 2024-09-04 17:29:45 --> Router Class Initialized
INFO - 2024-09-04 17:29:45 --> Output Class Initialized
INFO - 2024-09-04 17:29:45 --> Security Class Initialized
DEBUG - 2024-09-04 17:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:29:45 --> Input Class Initialized
INFO - 2024-09-04 17:29:45 --> Language Class Initialized
ERROR - 2024-09-04 17:29:45 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:30:27 --> Config Class Initialized
INFO - 2024-09-04 17:30:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:30:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:30:27 --> Utf8 Class Initialized
INFO - 2024-09-04 17:30:27 --> URI Class Initialized
INFO - 2024-09-04 17:30:27 --> Router Class Initialized
INFO - 2024-09-04 17:30:27 --> Output Class Initialized
INFO - 2024-09-04 17:30:27 --> Security Class Initialized
DEBUG - 2024-09-04 17:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:30:27 --> Input Class Initialized
INFO - 2024-09-04 17:30:27 --> Language Class Initialized
ERROR - 2024-09-04 17:30:27 --> 404 Page Not Found: Report/index
INFO - 2024-09-04 17:30:29 --> Config Class Initialized
INFO - 2024-09-04 17:30:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:30:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:30:29 --> Utf8 Class Initialized
INFO - 2024-09-04 17:30:29 --> URI Class Initialized
INFO - 2024-09-04 17:30:29 --> Router Class Initialized
INFO - 2024-09-04 17:30:29 --> Output Class Initialized
INFO - 2024-09-04 17:30:29 --> Security Class Initialized
DEBUG - 2024-09-04 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:30:29 --> Input Class Initialized
INFO - 2024-09-04 17:30:29 --> Language Class Initialized
ERROR - 2024-09-04 17:30:29 --> 404 Page Not Found: Report/index
INFO - 2024-09-04 17:30:36 --> Config Class Initialized
INFO - 2024-09-04 17:30:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:30:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:30:36 --> Utf8 Class Initialized
INFO - 2024-09-04 17:30:36 --> URI Class Initialized
INFO - 2024-09-04 17:30:36 --> Router Class Initialized
INFO - 2024-09-04 17:30:36 --> Output Class Initialized
INFO - 2024-09-04 17:30:36 --> Security Class Initialized
DEBUG - 2024-09-04 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:30:36 --> Input Class Initialized
INFO - 2024-09-04 17:30:36 --> Language Class Initialized
INFO - 2024-09-04 17:30:36 --> Loader Class Initialized
INFO - 2024-09-04 17:30:36 --> Helper loaded: url_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: file_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: security_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:30:36 --> Database Driver Class Initialized
INFO - 2024-09-04 17:30:36 --> Email Class Initialized
DEBUG - 2024-09-04 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:30:36 --> Helper loaded: form_helper
INFO - 2024-09-04 17:30:36 --> Form Validation Class Initialized
INFO - 2024-09-04 17:30:36 --> Controller Class Initialized
INFO - 2024-09-04 17:30:36 --> Config Class Initialized
INFO - 2024-09-04 17:30:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:30:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:30:36 --> Utf8 Class Initialized
INFO - 2024-09-04 17:30:36 --> URI Class Initialized
INFO - 2024-09-04 17:30:36 --> Router Class Initialized
INFO - 2024-09-04 17:30:36 --> Output Class Initialized
INFO - 2024-09-04 17:30:36 --> Security Class Initialized
DEBUG - 2024-09-04 17:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:30:36 --> Input Class Initialized
INFO - 2024-09-04 17:30:36 --> Language Class Initialized
INFO - 2024-09-04 17:30:36 --> Loader Class Initialized
INFO - 2024-09-04 17:30:36 --> Helper loaded: url_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: file_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: security_helper
INFO - 2024-09-04 17:30:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:30:36 --> Database Driver Class Initialized
INFO - 2024-09-04 17:30:36 --> Email Class Initialized
DEBUG - 2024-09-04 17:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:30:36 --> Helper loaded: form_helper
INFO - 2024-09-04 17:30:36 --> Form Validation Class Initialized
INFO - 2024-09-04 17:30:36 --> Controller Class Initialized
DEBUG - 2024-09-04 17:30:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-04 17:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-04 17:30:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-04 17:30:36 --> Final output sent to browser
DEBUG - 2024-09-04 17:30:36 --> Total execution time: 0.0466
INFO - 2024-09-04 17:30:58 --> Config Class Initialized
INFO - 2024-09-04 17:30:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:30:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:30:58 --> Utf8 Class Initialized
INFO - 2024-09-04 17:30:58 --> URI Class Initialized
INFO - 2024-09-04 17:30:58 --> Router Class Initialized
INFO - 2024-09-04 17:30:58 --> Output Class Initialized
INFO - 2024-09-04 17:30:58 --> Security Class Initialized
DEBUG - 2024-09-04 17:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:30:58 --> Input Class Initialized
INFO - 2024-09-04 17:30:58 --> Language Class Initialized
INFO - 2024-09-04 17:30:58 --> Loader Class Initialized
INFO - 2024-09-04 17:30:58 --> Helper loaded: url_helper
INFO - 2024-09-04 17:30:58 --> Helper loaded: file_helper
INFO - 2024-09-04 17:30:58 --> Helper loaded: security_helper
INFO - 2024-09-04 17:30:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:30:58 --> Database Driver Class Initialized
INFO - 2024-09-04 17:30:58 --> Email Class Initialized
DEBUG - 2024-09-04 17:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:30:58 --> Helper loaded: form_helper
INFO - 2024-09-04 17:30:58 --> Form Validation Class Initialized
INFO - 2024-09-04 17:30:58 --> Controller Class Initialized
INFO - 2024-09-04 17:30:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:30:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:30:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:30:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:30:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:30:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:30:58 --> Final output sent to browser
DEBUG - 2024-09-04 17:30:58 --> Total execution time: 0.3086
INFO - 2024-09-04 17:31:02 --> Config Class Initialized
INFO - 2024-09-04 17:31:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:31:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:31:02 --> Utf8 Class Initialized
INFO - 2024-09-04 17:31:02 --> URI Class Initialized
INFO - 2024-09-04 17:31:02 --> Router Class Initialized
INFO - 2024-09-04 17:31:02 --> Output Class Initialized
INFO - 2024-09-04 17:31:02 --> Security Class Initialized
DEBUG - 2024-09-04 17:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:31:02 --> Input Class Initialized
INFO - 2024-09-04 17:31:02 --> Language Class Initialized
INFO - 2024-09-04 17:31:02 --> Loader Class Initialized
INFO - 2024-09-04 17:31:02 --> Helper loaded: url_helper
INFO - 2024-09-04 17:31:02 --> Helper loaded: file_helper
INFO - 2024-09-04 17:31:02 --> Helper loaded: security_helper
INFO - 2024-09-04 17:31:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:31:02 --> Database Driver Class Initialized
INFO - 2024-09-04 17:31:02 --> Email Class Initialized
DEBUG - 2024-09-04 17:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:31:02 --> Helper loaded: form_helper
INFO - 2024-09-04 17:31:02 --> Form Validation Class Initialized
INFO - 2024-09-04 17:31:02 --> Controller Class Initialized
INFO - 2024-09-04 17:31:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:31:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:31:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:31:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:31:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:31:02 --> Final output sent to browser
DEBUG - 2024-09-04 17:31:02 --> Total execution time: 0.3296
INFO - 2024-09-04 17:31:07 --> Config Class Initialized
INFO - 2024-09-04 17:31:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:31:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:31:07 --> Utf8 Class Initialized
INFO - 2024-09-04 17:31:07 --> URI Class Initialized
INFO - 2024-09-04 17:31:07 --> Router Class Initialized
INFO - 2024-09-04 17:31:07 --> Output Class Initialized
INFO - 2024-09-04 17:31:07 --> Security Class Initialized
DEBUG - 2024-09-04 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:31:07 --> Input Class Initialized
INFO - 2024-09-04 17:31:07 --> Language Class Initialized
ERROR - 2024-09-04 17:31:07 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:32:03 --> Config Class Initialized
INFO - 2024-09-04 17:32:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:32:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:32:03 --> Utf8 Class Initialized
INFO - 2024-09-04 17:32:03 --> URI Class Initialized
INFO - 2024-09-04 17:32:03 --> Router Class Initialized
INFO - 2024-09-04 17:32:03 --> Output Class Initialized
INFO - 2024-09-04 17:32:03 --> Security Class Initialized
DEBUG - 2024-09-04 17:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:32:03 --> Input Class Initialized
INFO - 2024-09-04 17:32:03 --> Language Class Initialized
ERROR - 2024-09-04 17:32:04 --> 404 Page Not Found: Report/cetakantrol
INFO - 2024-09-04 17:32:16 --> Config Class Initialized
INFO - 2024-09-04 17:32:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:32:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:32:16 --> Utf8 Class Initialized
INFO - 2024-09-04 17:32:16 --> URI Class Initialized
INFO - 2024-09-04 17:32:16 --> Router Class Initialized
INFO - 2024-09-04 17:32:16 --> Output Class Initialized
INFO - 2024-09-04 17:32:16 --> Security Class Initialized
DEBUG - 2024-09-04 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:32:16 --> Input Class Initialized
INFO - 2024-09-04 17:32:16 --> Language Class Initialized
INFO - 2024-09-04 17:32:16 --> Loader Class Initialized
INFO - 2024-09-04 17:32:16 --> Helper loaded: url_helper
INFO - 2024-09-04 17:32:16 --> Helper loaded: file_helper
INFO - 2024-09-04 17:32:16 --> Helper loaded: security_helper
INFO - 2024-09-04 17:32:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:32:16 --> Database Driver Class Initialized
INFO - 2024-09-04 17:32:16 --> Email Class Initialized
DEBUG - 2024-09-04 17:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:32:16 --> Helper loaded: form_helper
INFO - 2024-09-04 17:32:16 --> Form Validation Class Initialized
INFO - 2024-09-04 17:32:16 --> Controller Class Initialized
INFO - 2024-09-04 17:32:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:32:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:32:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:32:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:32:16 --> Final output sent to browser
DEBUG - 2024-09-04 17:32:16 --> Total execution time: 0.2883
INFO - 2024-09-04 17:35:24 --> Config Class Initialized
INFO - 2024-09-04 17:35:24 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:35:24 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:35:24 --> Utf8 Class Initialized
INFO - 2024-09-04 17:35:24 --> URI Class Initialized
INFO - 2024-09-04 17:35:24 --> Router Class Initialized
INFO - 2024-09-04 17:35:24 --> Output Class Initialized
INFO - 2024-09-04 17:35:24 --> Security Class Initialized
DEBUG - 2024-09-04 17:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:35:24 --> Input Class Initialized
INFO - 2024-09-04 17:35:24 --> Language Class Initialized
INFO - 2024-09-04 17:35:24 --> Loader Class Initialized
INFO - 2024-09-04 17:35:24 --> Helper loaded: url_helper
INFO - 2024-09-04 17:35:24 --> Helper loaded: file_helper
INFO - 2024-09-04 17:35:24 --> Helper loaded: security_helper
INFO - 2024-09-04 17:35:24 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:35:24 --> Database Driver Class Initialized
INFO - 2024-09-04 17:35:24 --> Email Class Initialized
DEBUG - 2024-09-04 17:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:35:24 --> Helper loaded: form_helper
INFO - 2024-09-04 17:35:24 --> Form Validation Class Initialized
INFO - 2024-09-04 17:35:24 --> Controller Class Initialized
INFO - 2024-09-04 17:35:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:35:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:35:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:35:24 --> Final output sent to browser
DEBUG - 2024-09-04 17:35:24 --> Total execution time: 0.0942
INFO - 2024-09-04 17:35:49 --> Config Class Initialized
INFO - 2024-09-04 17:35:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:35:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:35:49 --> Utf8 Class Initialized
INFO - 2024-09-04 17:35:49 --> URI Class Initialized
INFO - 2024-09-04 17:35:49 --> Router Class Initialized
INFO - 2024-09-04 17:35:49 --> Output Class Initialized
INFO - 2024-09-04 17:35:49 --> Security Class Initialized
DEBUG - 2024-09-04 17:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:35:49 --> Input Class Initialized
INFO - 2024-09-04 17:35:49 --> Language Class Initialized
INFO - 2024-09-04 17:35:49 --> Loader Class Initialized
INFO - 2024-09-04 17:35:49 --> Helper loaded: url_helper
INFO - 2024-09-04 17:35:49 --> Helper loaded: file_helper
INFO - 2024-09-04 17:35:49 --> Helper loaded: security_helper
INFO - 2024-09-04 17:35:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:35:49 --> Database Driver Class Initialized
INFO - 2024-09-04 17:35:49 --> Email Class Initialized
DEBUG - 2024-09-04 17:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:35:49 --> Helper loaded: form_helper
INFO - 2024-09-04 17:35:49 --> Form Validation Class Initialized
INFO - 2024-09-04 17:35:49 --> Controller Class Initialized
INFO - 2024-09-04 17:35:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:35:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:35:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:35:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:35:49 --> Final output sent to browser
DEBUG - 2024-09-04 17:35:49 --> Total execution time: 0.0927
INFO - 2024-09-04 17:36:42 --> Config Class Initialized
INFO - 2024-09-04 17:36:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:36:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:36:42 --> Utf8 Class Initialized
INFO - 2024-09-04 17:36:42 --> URI Class Initialized
INFO - 2024-09-04 17:36:42 --> Router Class Initialized
INFO - 2024-09-04 17:36:42 --> Output Class Initialized
INFO - 2024-09-04 17:36:42 --> Security Class Initialized
DEBUG - 2024-09-04 17:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:36:42 --> Input Class Initialized
INFO - 2024-09-04 17:36:42 --> Language Class Initialized
INFO - 2024-09-04 17:36:42 --> Loader Class Initialized
INFO - 2024-09-04 17:36:42 --> Helper loaded: url_helper
INFO - 2024-09-04 17:36:42 --> Helper loaded: file_helper
INFO - 2024-09-04 17:36:42 --> Helper loaded: security_helper
INFO - 2024-09-04 17:36:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:36:42 --> Database Driver Class Initialized
INFO - 2024-09-04 17:36:42 --> Email Class Initialized
DEBUG - 2024-09-04 17:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:36:42 --> Helper loaded: form_helper
INFO - 2024-09-04 17:36:42 --> Form Validation Class Initialized
INFO - 2024-09-04 17:36:42 --> Controller Class Initialized
INFO - 2024-09-04 17:36:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:36:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:36:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:36:42 --> Final output sent to browser
DEBUG - 2024-09-04 17:36:42 --> Total execution time: 0.0971
INFO - 2024-09-04 17:36:49 --> Config Class Initialized
INFO - 2024-09-04 17:36:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:36:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:36:49 --> Utf8 Class Initialized
INFO - 2024-09-04 17:36:49 --> URI Class Initialized
INFO - 2024-09-04 17:36:49 --> Router Class Initialized
INFO - 2024-09-04 17:36:49 --> Output Class Initialized
INFO - 2024-09-04 17:36:49 --> Security Class Initialized
DEBUG - 2024-09-04 17:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:36:49 --> Input Class Initialized
INFO - 2024-09-04 17:36:49 --> Language Class Initialized
INFO - 2024-09-04 17:36:49 --> Loader Class Initialized
INFO - 2024-09-04 17:36:49 --> Helper loaded: url_helper
INFO - 2024-09-04 17:36:49 --> Helper loaded: file_helper
INFO - 2024-09-04 17:36:49 --> Helper loaded: security_helper
INFO - 2024-09-04 17:36:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:36:49 --> Database Driver Class Initialized
INFO - 2024-09-04 17:36:49 --> Email Class Initialized
DEBUG - 2024-09-04 17:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:36:49 --> Helper loaded: form_helper
INFO - 2024-09-04 17:36:49 --> Form Validation Class Initialized
INFO - 2024-09-04 17:36:49 --> Controller Class Initialized
INFO - 2024-09-04 17:36:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:36:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:36:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:36:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:36:49 --> Final output sent to browser
DEBUG - 2024-09-04 17:36:49 --> Total execution time: 0.2699
INFO - 2024-09-04 17:38:02 --> Config Class Initialized
INFO - 2024-09-04 17:38:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:38:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:38:02 --> Utf8 Class Initialized
INFO - 2024-09-04 17:38:02 --> URI Class Initialized
INFO - 2024-09-04 17:38:02 --> Router Class Initialized
INFO - 2024-09-04 17:38:02 --> Output Class Initialized
INFO - 2024-09-04 17:38:02 --> Security Class Initialized
DEBUG - 2024-09-04 17:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:38:02 --> Input Class Initialized
INFO - 2024-09-04 17:38:02 --> Language Class Initialized
INFO - 2024-09-04 17:38:02 --> Loader Class Initialized
INFO - 2024-09-04 17:38:02 --> Helper loaded: url_helper
INFO - 2024-09-04 17:38:02 --> Helper loaded: file_helper
INFO - 2024-09-04 17:38:02 --> Helper loaded: security_helper
INFO - 2024-09-04 17:38:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:38:02 --> Database Driver Class Initialized
INFO - 2024-09-04 17:38:02 --> Email Class Initialized
DEBUG - 2024-09-04 17:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:38:02 --> Helper loaded: form_helper
INFO - 2024-09-04 17:38:02 --> Form Validation Class Initialized
INFO - 2024-09-04 17:38:02 --> Controller Class Initialized
INFO - 2024-09-04 17:38:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:38:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:38:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:38:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:38:03 --> Final output sent to browser
DEBUG - 2024-09-04 17:38:03 --> Total execution time: 0.2897
INFO - 2024-09-04 17:38:13 --> Config Class Initialized
INFO - 2024-09-04 17:38:13 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:38:13 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:38:13 --> Utf8 Class Initialized
INFO - 2024-09-04 17:38:13 --> URI Class Initialized
INFO - 2024-09-04 17:38:13 --> Router Class Initialized
INFO - 2024-09-04 17:38:13 --> Output Class Initialized
INFO - 2024-09-04 17:38:13 --> Security Class Initialized
DEBUG - 2024-09-04 17:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:38:13 --> Input Class Initialized
INFO - 2024-09-04 17:38:13 --> Language Class Initialized
INFO - 2024-09-04 17:38:13 --> Loader Class Initialized
INFO - 2024-09-04 17:38:13 --> Helper loaded: url_helper
INFO - 2024-09-04 17:38:13 --> Helper loaded: file_helper
INFO - 2024-09-04 17:38:13 --> Helper loaded: security_helper
INFO - 2024-09-04 17:38:13 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:38:13 --> Database Driver Class Initialized
INFO - 2024-09-04 17:38:13 --> Email Class Initialized
DEBUG - 2024-09-04 17:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:38:13 --> Helper loaded: form_helper
INFO - 2024-09-04 17:38:13 --> Form Validation Class Initialized
INFO - 2024-09-04 17:38:13 --> Controller Class Initialized
INFO - 2024-09-04 17:38:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:38:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:38:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:38:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:38:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:38:13 --> Final output sent to browser
DEBUG - 2024-09-04 17:38:13 --> Total execution time: 0.0743
INFO - 2024-09-04 17:38:19 --> Config Class Initialized
INFO - 2024-09-04 17:38:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:38:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:38:19 --> Utf8 Class Initialized
INFO - 2024-09-04 17:38:19 --> URI Class Initialized
INFO - 2024-09-04 17:38:19 --> Router Class Initialized
INFO - 2024-09-04 17:38:19 --> Output Class Initialized
INFO - 2024-09-04 17:38:19 --> Security Class Initialized
DEBUG - 2024-09-04 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:38:19 --> Input Class Initialized
INFO - 2024-09-04 17:38:19 --> Language Class Initialized
INFO - 2024-09-04 17:38:19 --> Loader Class Initialized
INFO - 2024-09-04 17:38:19 --> Helper loaded: url_helper
INFO - 2024-09-04 17:38:19 --> Helper loaded: file_helper
INFO - 2024-09-04 17:38:19 --> Helper loaded: security_helper
INFO - 2024-09-04 17:38:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:38:19 --> Database Driver Class Initialized
INFO - 2024-09-04 17:38:19 --> Email Class Initialized
DEBUG - 2024-09-04 17:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:38:19 --> Helper loaded: form_helper
INFO - 2024-09-04 17:38:19 --> Form Validation Class Initialized
INFO - 2024-09-04 17:38:19 --> Controller Class Initialized
INFO - 2024-09-04 17:38:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:38:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:38:19 --> Query error: Unknown column 'inventaris_mutasi.tanggal_periksa' in 'where clause' - Invalid query: SELECT `mlite_antrian_referensi`.*
FROM `mlite_antrian_referensi`
WHERE MONTH(inventaris_mutasi.tanggal_periksa) = '8'
AND YEAR(inventaris_mutasi.tanggal_periksa) = '2024'
INFO - 2024-09-04 17:38:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-04 17:38:46 --> Config Class Initialized
INFO - 2024-09-04 17:38:46 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:38:46 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:38:46 --> Utf8 Class Initialized
INFO - 2024-09-04 17:38:46 --> URI Class Initialized
INFO - 2024-09-04 17:38:46 --> Router Class Initialized
INFO - 2024-09-04 17:38:46 --> Output Class Initialized
INFO - 2024-09-04 17:38:46 --> Security Class Initialized
DEBUG - 2024-09-04 17:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:38:46 --> Input Class Initialized
INFO - 2024-09-04 17:38:46 --> Language Class Initialized
INFO - 2024-09-04 17:38:46 --> Loader Class Initialized
INFO - 2024-09-04 17:38:46 --> Helper loaded: url_helper
INFO - 2024-09-04 17:38:46 --> Helper loaded: file_helper
INFO - 2024-09-04 17:38:46 --> Helper loaded: security_helper
INFO - 2024-09-04 17:38:46 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:38:46 --> Database Driver Class Initialized
INFO - 2024-09-04 17:38:46 --> Email Class Initialized
DEBUG - 2024-09-04 17:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:38:46 --> Helper loaded: form_helper
INFO - 2024-09-04 17:38:46 --> Form Validation Class Initialized
INFO - 2024-09-04 17:38:46 --> Controller Class Initialized
INFO - 2024-09-04 17:38:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:38:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:38:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:38:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:38:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:38:46 --> Final output sent to browser
DEBUG - 2024-09-04 17:38:46 --> Total execution time: 0.1225
INFO - 2024-09-04 17:38:51 --> Config Class Initialized
INFO - 2024-09-04 17:38:51 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:38:51 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:38:51 --> Utf8 Class Initialized
INFO - 2024-09-04 17:38:51 --> URI Class Initialized
INFO - 2024-09-04 17:38:51 --> Router Class Initialized
INFO - 2024-09-04 17:38:51 --> Output Class Initialized
INFO - 2024-09-04 17:38:51 --> Security Class Initialized
DEBUG - 2024-09-04 17:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:38:51 --> Input Class Initialized
INFO - 2024-09-04 17:38:51 --> Language Class Initialized
INFO - 2024-09-04 17:38:51 --> Loader Class Initialized
INFO - 2024-09-04 17:38:51 --> Helper loaded: url_helper
INFO - 2024-09-04 17:38:51 --> Helper loaded: file_helper
INFO - 2024-09-04 17:38:51 --> Helper loaded: security_helper
INFO - 2024-09-04 17:38:51 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:38:51 --> Database Driver Class Initialized
INFO - 2024-09-04 17:38:51 --> Email Class Initialized
DEBUG - 2024-09-04 17:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:38:51 --> Helper loaded: form_helper
INFO - 2024-09-04 17:38:51 --> Form Validation Class Initialized
INFO - 2024-09-04 17:38:51 --> Controller Class Initialized
INFO - 2024-09-04 17:38:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:38:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:38:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:38:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:38:51 --> Final output sent to browser
DEBUG - 2024-09-04 17:38:51 --> Total execution time: 0.0994
INFO - 2024-09-04 17:39:21 --> Config Class Initialized
INFO - 2024-09-04 17:39:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:39:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:39:21 --> Utf8 Class Initialized
INFO - 2024-09-04 17:39:21 --> URI Class Initialized
INFO - 2024-09-04 17:39:21 --> Router Class Initialized
INFO - 2024-09-04 17:39:21 --> Output Class Initialized
INFO - 2024-09-04 17:39:21 --> Security Class Initialized
DEBUG - 2024-09-04 17:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:39:21 --> Input Class Initialized
INFO - 2024-09-04 17:39:21 --> Language Class Initialized
INFO - 2024-09-04 17:39:21 --> Loader Class Initialized
INFO - 2024-09-04 17:39:21 --> Helper loaded: url_helper
INFO - 2024-09-04 17:39:21 --> Helper loaded: file_helper
INFO - 2024-09-04 17:39:21 --> Helper loaded: security_helper
INFO - 2024-09-04 17:39:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:39:21 --> Database Driver Class Initialized
INFO - 2024-09-04 17:39:21 --> Email Class Initialized
DEBUG - 2024-09-04 17:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:39:21 --> Helper loaded: form_helper
INFO - 2024-09-04 17:39:21 --> Form Validation Class Initialized
INFO - 2024-09-04 17:39:21 --> Controller Class Initialized
INFO - 2024-09-04 17:39:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:39:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:39:21 --> Final output sent to browser
DEBUG - 2024-09-04 17:39:21 --> Total execution time: 0.0746
INFO - 2024-09-04 17:41:16 --> Config Class Initialized
INFO - 2024-09-04 17:41:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:16 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:16 --> URI Class Initialized
INFO - 2024-09-04 17:41:16 --> Router Class Initialized
INFO - 2024-09-04 17:41:16 --> Output Class Initialized
INFO - 2024-09-04 17:41:16 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:16 --> Input Class Initialized
INFO - 2024-09-04 17:41:16 --> Language Class Initialized
INFO - 2024-09-04 17:41:16 --> Loader Class Initialized
INFO - 2024-09-04 17:41:16 --> Helper loaded: url_helper
INFO - 2024-09-04 17:41:16 --> Helper loaded: file_helper
INFO - 2024-09-04 17:41:16 --> Helper loaded: security_helper
INFO - 2024-09-04 17:41:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:41:16 --> Database Driver Class Initialized
INFO - 2024-09-04 17:41:16 --> Email Class Initialized
DEBUG - 2024-09-04 17:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:41:16 --> Helper loaded: form_helper
INFO - 2024-09-04 17:41:16 --> Form Validation Class Initialized
INFO - 2024-09-04 17:41:16 --> Controller Class Initialized
INFO - 2024-09-04 17:41:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:41:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:41:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:41:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:41:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:41:16 --> Final output sent to browser
DEBUG - 2024-09-04 17:41:16 --> Total execution time: 0.1119
INFO - 2024-09-04 17:41:16 --> Config Class Initialized
INFO - 2024-09-04 17:41:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:16 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:16 --> URI Class Initialized
INFO - 2024-09-04 17:41:16 --> Router Class Initialized
INFO - 2024-09-04 17:41:16 --> Output Class Initialized
INFO - 2024-09-04 17:41:16 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:16 --> Input Class Initialized
INFO - 2024-09-04 17:41:16 --> Language Class Initialized
ERROR - 2024-09-04 17:41:16 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:41:27 --> Config Class Initialized
INFO - 2024-09-04 17:41:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:27 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:27 --> URI Class Initialized
INFO - 2024-09-04 17:41:27 --> Router Class Initialized
INFO - 2024-09-04 17:41:27 --> Output Class Initialized
INFO - 2024-09-04 17:41:27 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:27 --> Input Class Initialized
INFO - 2024-09-04 17:41:27 --> Language Class Initialized
INFO - 2024-09-04 17:41:27 --> Loader Class Initialized
INFO - 2024-09-04 17:41:27 --> Helper loaded: url_helper
INFO - 2024-09-04 17:41:27 --> Helper loaded: file_helper
INFO - 2024-09-04 17:41:27 --> Helper loaded: security_helper
INFO - 2024-09-04 17:41:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:41:27 --> Database Driver Class Initialized
INFO - 2024-09-04 17:41:27 --> Email Class Initialized
DEBUG - 2024-09-04 17:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:41:27 --> Helper loaded: form_helper
INFO - 2024-09-04 17:41:27 --> Form Validation Class Initialized
INFO - 2024-09-04 17:41:27 --> Controller Class Initialized
INFO - 2024-09-04 17:41:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:41:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:41:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\antrol\application\views\report\cetakantrol.php 111
INFO - 2024-09-04 17:41:47 --> Config Class Initialized
INFO - 2024-09-04 17:41:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:47 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:47 --> URI Class Initialized
INFO - 2024-09-04 17:41:47 --> Router Class Initialized
INFO - 2024-09-04 17:41:47 --> Output Class Initialized
INFO - 2024-09-04 17:41:47 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:47 --> Input Class Initialized
INFO - 2024-09-04 17:41:47 --> Language Class Initialized
INFO - 2024-09-04 17:41:47 --> Loader Class Initialized
INFO - 2024-09-04 17:41:47 --> Helper loaded: url_helper
INFO - 2024-09-04 17:41:47 --> Helper loaded: file_helper
INFO - 2024-09-04 17:41:47 --> Helper loaded: security_helper
INFO - 2024-09-04 17:41:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:41:47 --> Database Driver Class Initialized
INFO - 2024-09-04 17:41:47 --> Email Class Initialized
DEBUG - 2024-09-04 17:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:41:47 --> Helper loaded: form_helper
INFO - 2024-09-04 17:41:47 --> Form Validation Class Initialized
INFO - 2024-09-04 17:41:47 --> Controller Class Initialized
INFO - 2024-09-04 17:41:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:41:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:41:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:41:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:41:47 --> Final output sent to browser
DEBUG - 2024-09-04 17:41:47 --> Total execution time: 0.1284
INFO - 2024-09-04 17:41:47 --> Config Class Initialized
INFO - 2024-09-04 17:41:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:47 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:47 --> URI Class Initialized
INFO - 2024-09-04 17:41:47 --> Router Class Initialized
INFO - 2024-09-04 17:41:47 --> Output Class Initialized
INFO - 2024-09-04 17:41:47 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:47 --> Input Class Initialized
INFO - 2024-09-04 17:41:47 --> Language Class Initialized
ERROR - 2024-09-04 17:41:47 --> 404 Page Not Found: Assets/js
INFO - 2024-09-04 17:41:56 --> Config Class Initialized
INFO - 2024-09-04 17:41:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:41:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:41:56 --> Utf8 Class Initialized
INFO - 2024-09-04 17:41:56 --> URI Class Initialized
INFO - 2024-09-04 17:41:56 --> Router Class Initialized
INFO - 2024-09-04 17:41:56 --> Output Class Initialized
INFO - 2024-09-04 17:41:56 --> Security Class Initialized
DEBUG - 2024-09-04 17:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:41:56 --> Input Class Initialized
INFO - 2024-09-04 17:41:56 --> Language Class Initialized
INFO - 2024-09-04 17:41:56 --> Loader Class Initialized
INFO - 2024-09-04 17:41:56 --> Helper loaded: url_helper
INFO - 2024-09-04 17:41:56 --> Helper loaded: file_helper
INFO - 2024-09-04 17:41:56 --> Helper loaded: security_helper
INFO - 2024-09-04 17:41:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:41:56 --> Database Driver Class Initialized
INFO - 2024-09-04 17:41:56 --> Email Class Initialized
DEBUG - 2024-09-04 17:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:41:56 --> Helper loaded: form_helper
INFO - 2024-09-04 17:41:56 --> Form Validation Class Initialized
INFO - 2024-09-04 17:41:56 --> Controller Class Initialized
INFO - 2024-09-04 17:41:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:41:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:41:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:41:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:41:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:41:57 --> Final output sent to browser
DEBUG - 2024-09-04 17:41:57 --> Total execution time: 0.1534
INFO - 2024-09-04 17:42:17 --> Config Class Initialized
INFO - 2024-09-04 17:42:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:17 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:17 --> URI Class Initialized
INFO - 2024-09-04 17:42:17 --> Router Class Initialized
INFO - 2024-09-04 17:42:17 --> Output Class Initialized
INFO - 2024-09-04 17:42:17 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:17 --> Input Class Initialized
INFO - 2024-09-04 17:42:17 --> Language Class Initialized
INFO - 2024-09-04 17:42:17 --> Loader Class Initialized
INFO - 2024-09-04 17:42:17 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:17 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:17 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:17 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:17 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:17 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:17 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:17 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:17 --> Controller Class Initialized
INFO - 2024-09-04 17:42:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:42:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:42:17 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\antrol\application\views\templates\topbar.php 23
ERROR - 2024-09-04 17:42:17 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\antrol\application\views\templates\topbar.php 30
INFO - 2024-09-04 17:42:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:17 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:17 --> Total execution time: 0.1134
INFO - 2024-09-04 17:42:34 --> Config Class Initialized
INFO - 2024-09-04 17:42:34 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:34 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:34 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:34 --> URI Class Initialized
INFO - 2024-09-04 17:42:34 --> Router Class Initialized
INFO - 2024-09-04 17:42:34 --> Output Class Initialized
INFO - 2024-09-04 17:42:34 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:34 --> Input Class Initialized
INFO - 2024-09-04 17:42:34 --> Language Class Initialized
INFO - 2024-09-04 17:42:34 --> Loader Class Initialized
INFO - 2024-09-04 17:42:34 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:34 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:34 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:34 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:34 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:34 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:34 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:34 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:34 --> Controller Class Initialized
INFO - 2024-09-04 17:42:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:42:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:42:34 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\antrol\application\views\templates\topbar.php 23
INFO - 2024-09-04 17:42:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:34 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:34 --> Total execution time: 0.1300
INFO - 2024-09-04 17:42:35 --> Config Class Initialized
INFO - 2024-09-04 17:42:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:35 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:35 --> URI Class Initialized
INFO - 2024-09-04 17:42:35 --> Router Class Initialized
INFO - 2024-09-04 17:42:35 --> Output Class Initialized
INFO - 2024-09-04 17:42:35 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:35 --> Input Class Initialized
INFO - 2024-09-04 17:42:35 --> Language Class Initialized
INFO - 2024-09-04 17:42:35 --> Loader Class Initialized
INFO - 2024-09-04 17:42:35 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:35 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:35 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:35 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:35 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:35 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:35 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:35 --> Controller Class Initialized
INFO - 2024-09-04 17:42:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:42:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:42:35 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\antrol\application\views\templates\topbar.php 23
INFO - 2024-09-04 17:42:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:35 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:35 --> Total execution time: 0.1187
INFO - 2024-09-04 17:42:38 --> Config Class Initialized
INFO - 2024-09-04 17:42:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:38 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:38 --> URI Class Initialized
INFO - 2024-09-04 17:42:38 --> Router Class Initialized
INFO - 2024-09-04 17:42:38 --> Output Class Initialized
INFO - 2024-09-04 17:42:38 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:38 --> Input Class Initialized
INFO - 2024-09-04 17:42:38 --> Language Class Initialized
INFO - 2024-09-04 17:42:38 --> Loader Class Initialized
INFO - 2024-09-04 17:42:38 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:38 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:38 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:38 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:38 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:38 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:38 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:38 --> Controller Class Initialized
INFO - 2024-09-04 17:42:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
ERROR - 2024-09-04 17:42:38 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\antrol\application\views\templates\topbar.php 23
INFO - 2024-09-04 17:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:38 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:38 --> Total execution time: 0.1117
INFO - 2024-09-04 17:42:45 --> Config Class Initialized
INFO - 2024-09-04 17:42:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:45 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:45 --> URI Class Initialized
INFO - 2024-09-04 17:42:45 --> Router Class Initialized
INFO - 2024-09-04 17:42:45 --> Output Class Initialized
INFO - 2024-09-04 17:42:45 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:45 --> Input Class Initialized
INFO - 2024-09-04 17:42:45 --> Language Class Initialized
INFO - 2024-09-04 17:42:45 --> Loader Class Initialized
INFO - 2024-09-04 17:42:45 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:45 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:45 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:45 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:45 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:45 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:45 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:45 --> Controller Class Initialized
INFO - 2024-09-04 17:42:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:42:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:42:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:45 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:45 --> Total execution time: 0.1134
INFO - 2024-09-04 17:42:57 --> Config Class Initialized
INFO - 2024-09-04 17:42:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:42:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:42:58 --> Utf8 Class Initialized
INFO - 2024-09-04 17:42:58 --> URI Class Initialized
INFO - 2024-09-04 17:42:58 --> Router Class Initialized
INFO - 2024-09-04 17:42:58 --> Output Class Initialized
INFO - 2024-09-04 17:42:58 --> Security Class Initialized
DEBUG - 2024-09-04 17:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:42:58 --> Input Class Initialized
INFO - 2024-09-04 17:42:58 --> Language Class Initialized
INFO - 2024-09-04 17:42:58 --> Loader Class Initialized
INFO - 2024-09-04 17:42:58 --> Helper loaded: url_helper
INFO - 2024-09-04 17:42:58 --> Helper loaded: file_helper
INFO - 2024-09-04 17:42:58 --> Helper loaded: security_helper
INFO - 2024-09-04 17:42:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:42:58 --> Database Driver Class Initialized
INFO - 2024-09-04 17:42:58 --> Email Class Initialized
DEBUG - 2024-09-04 17:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:42:58 --> Helper loaded: form_helper
INFO - 2024-09-04 17:42:58 --> Form Validation Class Initialized
INFO - 2024-09-04 17:42:58 --> Controller Class Initialized
INFO - 2024-09-04 17:42:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:42:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:42:58 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\antrol\application\views\templates\header.php 13
INFO - 2024-09-04 17:42:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:42:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:42:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:42:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:42:58 --> Final output sent to browser
DEBUG - 2024-09-04 17:42:58 --> Total execution time: 0.1646
INFO - 2024-09-04 17:43:03 --> Config Class Initialized
INFO - 2024-09-04 17:43:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:43:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:43:03 --> Utf8 Class Initialized
INFO - 2024-09-04 17:43:03 --> URI Class Initialized
INFO - 2024-09-04 17:43:03 --> Router Class Initialized
INFO - 2024-09-04 17:43:03 --> Output Class Initialized
INFO - 2024-09-04 17:43:03 --> Security Class Initialized
DEBUG - 2024-09-04 17:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:43:03 --> Input Class Initialized
INFO - 2024-09-04 17:43:03 --> Language Class Initialized
INFO - 2024-09-04 17:43:03 --> Loader Class Initialized
INFO - 2024-09-04 17:43:03 --> Helper loaded: url_helper
INFO - 2024-09-04 17:43:03 --> Helper loaded: file_helper
INFO - 2024-09-04 17:43:03 --> Helper loaded: security_helper
INFO - 2024-09-04 17:43:03 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:43:03 --> Database Driver Class Initialized
INFO - 2024-09-04 17:43:03 --> Email Class Initialized
DEBUG - 2024-09-04 17:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:43:03 --> Helper loaded: form_helper
INFO - 2024-09-04 17:43:03 --> Form Validation Class Initialized
INFO - 2024-09-04 17:43:03 --> Controller Class Initialized
INFO - 2024-09-04 17:43:03 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:43:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:43:03 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\antrol\application\views\templates\header.php 13
INFO - 2024-09-04 17:43:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:43:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:43:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:43:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:43:03 --> Final output sent to browser
DEBUG - 2024-09-04 17:43:03 --> Total execution time: 0.1142
INFO - 2024-09-04 17:43:07 --> Config Class Initialized
INFO - 2024-09-04 17:43:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:43:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:43:07 --> Utf8 Class Initialized
INFO - 2024-09-04 17:43:07 --> URI Class Initialized
INFO - 2024-09-04 17:43:07 --> Router Class Initialized
INFO - 2024-09-04 17:43:07 --> Output Class Initialized
INFO - 2024-09-04 17:43:07 --> Security Class Initialized
DEBUG - 2024-09-04 17:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:43:07 --> Input Class Initialized
INFO - 2024-09-04 17:43:07 --> Language Class Initialized
INFO - 2024-09-04 17:43:07 --> Loader Class Initialized
INFO - 2024-09-04 17:43:07 --> Helper loaded: url_helper
INFO - 2024-09-04 17:43:07 --> Helper loaded: file_helper
INFO - 2024-09-04 17:43:07 --> Helper loaded: security_helper
INFO - 2024-09-04 17:43:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:43:07 --> Database Driver Class Initialized
INFO - 2024-09-04 17:43:07 --> Email Class Initialized
DEBUG - 2024-09-04 17:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:43:07 --> Helper loaded: form_helper
INFO - 2024-09-04 17:43:07 --> Form Validation Class Initialized
INFO - 2024-09-04 17:43:07 --> Controller Class Initialized
INFO - 2024-09-04 17:43:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:43:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 17:43:07 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\antrol\application\views\templates\header.php 13
INFO - 2024-09-04 17:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:43:07 --> Final output sent to browser
DEBUG - 2024-09-04 17:43:07 --> Total execution time: 0.1413
INFO - 2024-09-04 17:43:17 --> Config Class Initialized
INFO - 2024-09-04 17:43:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:43:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:43:17 --> Utf8 Class Initialized
INFO - 2024-09-04 17:43:17 --> URI Class Initialized
INFO - 2024-09-04 17:43:17 --> Router Class Initialized
INFO - 2024-09-04 17:43:17 --> Output Class Initialized
INFO - 2024-09-04 17:43:17 --> Security Class Initialized
DEBUG - 2024-09-04 17:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:43:17 --> Input Class Initialized
INFO - 2024-09-04 17:43:17 --> Language Class Initialized
INFO - 2024-09-04 17:43:17 --> Loader Class Initialized
INFO - 2024-09-04 17:43:17 --> Helper loaded: url_helper
INFO - 2024-09-04 17:43:17 --> Helper loaded: file_helper
INFO - 2024-09-04 17:43:17 --> Helper loaded: security_helper
INFO - 2024-09-04 17:43:17 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:43:17 --> Database Driver Class Initialized
INFO - 2024-09-04 17:43:17 --> Email Class Initialized
DEBUG - 2024-09-04 17:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:43:17 --> Helper loaded: form_helper
INFO - 2024-09-04 17:43:17 --> Form Validation Class Initialized
INFO - 2024-09-04 17:43:17 --> Controller Class Initialized
INFO - 2024-09-04 17:43:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:43:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:43:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:43:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:43:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:43:17 --> Final output sent to browser
DEBUG - 2024-09-04 17:43:17 --> Total execution time: 0.0962
INFO - 2024-09-04 17:43:37 --> Config Class Initialized
INFO - 2024-09-04 17:43:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:43:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:43:37 --> Utf8 Class Initialized
INFO - 2024-09-04 17:43:37 --> URI Class Initialized
INFO - 2024-09-04 17:43:37 --> Router Class Initialized
INFO - 2024-09-04 17:43:37 --> Output Class Initialized
INFO - 2024-09-04 17:43:37 --> Security Class Initialized
DEBUG - 2024-09-04 17:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:43:37 --> Input Class Initialized
INFO - 2024-09-04 17:43:37 --> Language Class Initialized
INFO - 2024-09-04 17:43:37 --> Loader Class Initialized
INFO - 2024-09-04 17:43:37 --> Helper loaded: url_helper
INFO - 2024-09-04 17:43:37 --> Helper loaded: file_helper
INFO - 2024-09-04 17:43:37 --> Helper loaded: security_helper
INFO - 2024-09-04 17:43:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:43:37 --> Database Driver Class Initialized
INFO - 2024-09-04 17:43:37 --> Email Class Initialized
DEBUG - 2024-09-04 17:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:43:37 --> Helper loaded: form_helper
INFO - 2024-09-04 17:43:37 --> Form Validation Class Initialized
INFO - 2024-09-04 17:43:37 --> Controller Class Initialized
INFO - 2024-09-04 17:43:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:43:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:43:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:43:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:43:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:43:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:43:37 --> Final output sent to browser
DEBUG - 2024-09-04 17:43:37 --> Total execution time: 0.1307
INFO - 2024-09-04 17:43:48 --> Config Class Initialized
INFO - 2024-09-04 17:43:48 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:43:48 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:43:48 --> Utf8 Class Initialized
INFO - 2024-09-04 17:43:48 --> URI Class Initialized
INFO - 2024-09-04 17:43:48 --> Router Class Initialized
INFO - 2024-09-04 17:43:48 --> Output Class Initialized
INFO - 2024-09-04 17:43:48 --> Security Class Initialized
DEBUG - 2024-09-04 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:43:48 --> Input Class Initialized
INFO - 2024-09-04 17:43:48 --> Language Class Initialized
INFO - 2024-09-04 17:43:48 --> Loader Class Initialized
INFO - 2024-09-04 17:43:48 --> Helper loaded: url_helper
INFO - 2024-09-04 17:43:48 --> Helper loaded: file_helper
INFO - 2024-09-04 17:43:48 --> Helper loaded: security_helper
INFO - 2024-09-04 17:43:48 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:43:48 --> Database Driver Class Initialized
INFO - 2024-09-04 17:43:48 --> Email Class Initialized
DEBUG - 2024-09-04 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:43:48 --> Helper loaded: form_helper
INFO - 2024-09-04 17:43:48 --> Form Validation Class Initialized
INFO - 2024-09-04 17:43:48 --> Controller Class Initialized
INFO - 2024-09-04 17:43:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:43:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:43:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:43:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:43:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:43:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:43:48 --> Final output sent to browser
DEBUG - 2024-09-04 17:43:48 --> Total execution time: 0.1150
INFO - 2024-09-04 17:44:21 --> Config Class Initialized
INFO - 2024-09-04 17:44:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:44:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:44:21 --> Utf8 Class Initialized
INFO - 2024-09-04 17:44:21 --> URI Class Initialized
INFO - 2024-09-04 17:44:21 --> Router Class Initialized
INFO - 2024-09-04 17:44:21 --> Output Class Initialized
INFO - 2024-09-04 17:44:21 --> Security Class Initialized
DEBUG - 2024-09-04 17:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:44:21 --> Input Class Initialized
INFO - 2024-09-04 17:44:21 --> Language Class Initialized
INFO - 2024-09-04 17:44:21 --> Loader Class Initialized
INFO - 2024-09-04 17:44:21 --> Helper loaded: url_helper
INFO - 2024-09-04 17:44:21 --> Helper loaded: file_helper
INFO - 2024-09-04 17:44:21 --> Helper loaded: security_helper
INFO - 2024-09-04 17:44:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:44:21 --> Database Driver Class Initialized
INFO - 2024-09-04 17:44:21 --> Email Class Initialized
DEBUG - 2024-09-04 17:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:44:21 --> Helper loaded: form_helper
INFO - 2024-09-04 17:44:21 --> Form Validation Class Initialized
INFO - 2024-09-04 17:44:21 --> Controller Class Initialized
INFO - 2024-09-04 17:44:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:44:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:44:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:44:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:44:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:44:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:44:22 --> Final output sent to browser
DEBUG - 2024-09-04 17:44:22 --> Total execution time: 0.1534
INFO - 2024-09-04 17:44:42 --> Config Class Initialized
INFO - 2024-09-04 17:44:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:44:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:44:42 --> Utf8 Class Initialized
INFO - 2024-09-04 17:44:42 --> URI Class Initialized
INFO - 2024-09-04 17:44:42 --> Router Class Initialized
INFO - 2024-09-04 17:44:42 --> Output Class Initialized
INFO - 2024-09-04 17:44:42 --> Security Class Initialized
DEBUG - 2024-09-04 17:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:44:42 --> Input Class Initialized
INFO - 2024-09-04 17:44:42 --> Language Class Initialized
INFO - 2024-09-04 17:44:42 --> Loader Class Initialized
INFO - 2024-09-04 17:44:42 --> Helper loaded: url_helper
INFO - 2024-09-04 17:44:42 --> Helper loaded: file_helper
INFO - 2024-09-04 17:44:42 --> Helper loaded: security_helper
INFO - 2024-09-04 17:44:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:44:42 --> Database Driver Class Initialized
INFO - 2024-09-04 17:44:42 --> Email Class Initialized
DEBUG - 2024-09-04 17:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:44:42 --> Helper loaded: form_helper
INFO - 2024-09-04 17:44:42 --> Form Validation Class Initialized
INFO - 2024-09-04 17:44:42 --> Controller Class Initialized
INFO - 2024-09-04 17:44:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:44:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:44:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:44:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:44:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:44:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:44:42 --> Final output sent to browser
DEBUG - 2024-09-04 17:44:42 --> Total execution time: 0.1249
INFO - 2024-09-04 17:45:25 --> Config Class Initialized
INFO - 2024-09-04 17:45:25 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:45:25 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:45:25 --> Utf8 Class Initialized
INFO - 2024-09-04 17:45:25 --> URI Class Initialized
INFO - 2024-09-04 17:45:25 --> Router Class Initialized
INFO - 2024-09-04 17:45:25 --> Output Class Initialized
INFO - 2024-09-04 17:45:25 --> Security Class Initialized
DEBUG - 2024-09-04 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:45:25 --> Input Class Initialized
INFO - 2024-09-04 17:45:25 --> Language Class Initialized
INFO - 2024-09-04 17:45:25 --> Loader Class Initialized
INFO - 2024-09-04 17:45:25 --> Helper loaded: url_helper
INFO - 2024-09-04 17:45:25 --> Helper loaded: file_helper
INFO - 2024-09-04 17:45:25 --> Helper loaded: security_helper
INFO - 2024-09-04 17:45:25 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:45:25 --> Database Driver Class Initialized
INFO - 2024-09-04 17:45:25 --> Email Class Initialized
DEBUG - 2024-09-04 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:45:25 --> Helper loaded: form_helper
INFO - 2024-09-04 17:45:25 --> Form Validation Class Initialized
INFO - 2024-09-04 17:45:25 --> Controller Class Initialized
INFO - 2024-09-04 17:45:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:45:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:45:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:45:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:45:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:45:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:45:25 --> Final output sent to browser
DEBUG - 2024-09-04 17:45:25 --> Total execution time: 0.1125
INFO - 2024-09-04 17:45:56 --> Config Class Initialized
INFO - 2024-09-04 17:45:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:45:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:45:56 --> Utf8 Class Initialized
INFO - 2024-09-04 17:45:56 --> URI Class Initialized
INFO - 2024-09-04 17:45:56 --> Router Class Initialized
INFO - 2024-09-04 17:45:56 --> Output Class Initialized
INFO - 2024-09-04 17:45:56 --> Security Class Initialized
DEBUG - 2024-09-04 17:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:45:56 --> Input Class Initialized
INFO - 2024-09-04 17:45:56 --> Language Class Initialized
INFO - 2024-09-04 17:45:56 --> Loader Class Initialized
INFO - 2024-09-04 17:45:56 --> Helper loaded: url_helper
INFO - 2024-09-04 17:45:56 --> Helper loaded: file_helper
INFO - 2024-09-04 17:45:56 --> Helper loaded: security_helper
INFO - 2024-09-04 17:45:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:45:56 --> Database Driver Class Initialized
INFO - 2024-09-04 17:45:56 --> Email Class Initialized
DEBUG - 2024-09-04 17:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:45:56 --> Helper loaded: form_helper
INFO - 2024-09-04 17:45:56 --> Form Validation Class Initialized
INFO - 2024-09-04 17:45:56 --> Controller Class Initialized
INFO - 2024-09-04 17:45:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:45:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:45:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:45:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:45:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:45:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:45:56 --> Final output sent to browser
DEBUG - 2024-09-04 17:45:56 --> Total execution time: 0.1105
INFO - 2024-09-04 17:46:10 --> Config Class Initialized
INFO - 2024-09-04 17:46:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:46:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:46:10 --> Utf8 Class Initialized
INFO - 2024-09-04 17:46:10 --> URI Class Initialized
INFO - 2024-09-04 17:46:10 --> Router Class Initialized
INFO - 2024-09-04 17:46:10 --> Output Class Initialized
INFO - 2024-09-04 17:46:10 --> Security Class Initialized
DEBUG - 2024-09-04 17:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:46:10 --> Input Class Initialized
INFO - 2024-09-04 17:46:10 --> Language Class Initialized
INFO - 2024-09-04 17:46:10 --> Loader Class Initialized
INFO - 2024-09-04 17:46:10 --> Helper loaded: url_helper
INFO - 2024-09-04 17:46:10 --> Helper loaded: file_helper
INFO - 2024-09-04 17:46:10 --> Helper loaded: security_helper
INFO - 2024-09-04 17:46:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:46:10 --> Database Driver Class Initialized
INFO - 2024-09-04 17:46:10 --> Email Class Initialized
DEBUG - 2024-09-04 17:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:46:10 --> Helper loaded: form_helper
INFO - 2024-09-04 17:46:10 --> Form Validation Class Initialized
INFO - 2024-09-04 17:46:10 --> Controller Class Initialized
INFO - 2024-09-04 17:46:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:46:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:46:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:46:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:46:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:46:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:46:10 --> Final output sent to browser
DEBUG - 2024-09-04 17:46:10 --> Total execution time: 0.1178
INFO - 2024-09-04 17:47:08 --> Config Class Initialized
INFO - 2024-09-04 17:47:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:47:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:47:08 --> Utf8 Class Initialized
INFO - 2024-09-04 17:47:08 --> URI Class Initialized
INFO - 2024-09-04 17:47:08 --> Router Class Initialized
INFO - 2024-09-04 17:47:08 --> Output Class Initialized
INFO - 2024-09-04 17:47:08 --> Security Class Initialized
DEBUG - 2024-09-04 17:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:47:08 --> Input Class Initialized
INFO - 2024-09-04 17:47:08 --> Language Class Initialized
INFO - 2024-09-04 17:47:08 --> Loader Class Initialized
INFO - 2024-09-04 17:47:08 --> Helper loaded: url_helper
INFO - 2024-09-04 17:47:08 --> Helper loaded: file_helper
INFO - 2024-09-04 17:47:08 --> Helper loaded: security_helper
INFO - 2024-09-04 17:47:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:47:08 --> Database Driver Class Initialized
INFO - 2024-09-04 17:47:08 --> Email Class Initialized
DEBUG - 2024-09-04 17:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:47:09 --> Helper loaded: form_helper
INFO - 2024-09-04 17:47:09 --> Form Validation Class Initialized
INFO - 2024-09-04 17:47:09 --> Controller Class Initialized
INFO - 2024-09-04 17:47:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:47:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:47:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:47:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:47:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:47:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:47:09 --> Final output sent to browser
DEBUG - 2024-09-04 17:47:09 --> Total execution time: 0.1073
INFO - 2024-09-04 17:47:49 --> Config Class Initialized
INFO - 2024-09-04 17:47:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:47:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:47:49 --> Utf8 Class Initialized
INFO - 2024-09-04 17:47:49 --> URI Class Initialized
INFO - 2024-09-04 17:47:49 --> Router Class Initialized
INFO - 2024-09-04 17:47:49 --> Output Class Initialized
INFO - 2024-09-04 17:47:49 --> Security Class Initialized
DEBUG - 2024-09-04 17:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:47:49 --> Input Class Initialized
INFO - 2024-09-04 17:47:49 --> Language Class Initialized
INFO - 2024-09-04 17:47:49 --> Loader Class Initialized
INFO - 2024-09-04 17:47:49 --> Helper loaded: url_helper
INFO - 2024-09-04 17:47:49 --> Helper loaded: file_helper
INFO - 2024-09-04 17:47:49 --> Helper loaded: security_helper
INFO - 2024-09-04 17:47:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:47:49 --> Database Driver Class Initialized
INFO - 2024-09-04 17:47:49 --> Email Class Initialized
DEBUG - 2024-09-04 17:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:47:49 --> Helper loaded: form_helper
INFO - 2024-09-04 17:47:49 --> Form Validation Class Initialized
INFO - 2024-09-04 17:47:49 --> Controller Class Initialized
INFO - 2024-09-04 17:47:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:47:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:47:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:47:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:47:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:47:49 --> Final output sent to browser
DEBUG - 2024-09-04 17:47:49 --> Total execution time: 0.1274
INFO - 2024-09-04 17:49:11 --> Config Class Initialized
INFO - 2024-09-04 17:49:11 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:49:11 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:49:11 --> Utf8 Class Initialized
INFO - 2024-09-04 17:49:11 --> URI Class Initialized
INFO - 2024-09-04 17:49:11 --> Router Class Initialized
INFO - 2024-09-04 17:49:11 --> Output Class Initialized
INFO - 2024-09-04 17:49:11 --> Security Class Initialized
DEBUG - 2024-09-04 17:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:49:11 --> Input Class Initialized
INFO - 2024-09-04 17:49:11 --> Language Class Initialized
INFO - 2024-09-04 17:49:11 --> Loader Class Initialized
INFO - 2024-09-04 17:49:11 --> Helper loaded: url_helper
INFO - 2024-09-04 17:49:11 --> Helper loaded: file_helper
INFO - 2024-09-04 17:49:11 --> Helper loaded: security_helper
INFO - 2024-09-04 17:49:11 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:49:11 --> Database Driver Class Initialized
INFO - 2024-09-04 17:49:11 --> Email Class Initialized
DEBUG - 2024-09-04 17:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:49:11 --> Helper loaded: form_helper
INFO - 2024-09-04 17:49:11 --> Form Validation Class Initialized
INFO - 2024-09-04 17:49:11 --> Controller Class Initialized
INFO - 2024-09-04 17:49:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:49:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:49:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:49:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:49:11 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:49:11 --> Final output sent to browser
DEBUG - 2024-09-04 17:49:11 --> Total execution time: 0.1410
INFO - 2024-09-04 17:49:26 --> Config Class Initialized
INFO - 2024-09-04 17:49:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:49:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:49:26 --> Utf8 Class Initialized
INFO - 2024-09-04 17:49:26 --> URI Class Initialized
INFO - 2024-09-04 17:49:26 --> Router Class Initialized
INFO - 2024-09-04 17:49:26 --> Output Class Initialized
INFO - 2024-09-04 17:49:26 --> Security Class Initialized
DEBUG - 2024-09-04 17:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:49:26 --> Input Class Initialized
INFO - 2024-09-04 17:49:26 --> Language Class Initialized
INFO - 2024-09-04 17:49:26 --> Loader Class Initialized
INFO - 2024-09-04 17:49:26 --> Helper loaded: url_helper
INFO - 2024-09-04 17:49:26 --> Helper loaded: file_helper
INFO - 2024-09-04 17:49:26 --> Helper loaded: security_helper
INFO - 2024-09-04 17:49:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:49:26 --> Database Driver Class Initialized
INFO - 2024-09-04 17:49:26 --> Email Class Initialized
DEBUG - 2024-09-04 17:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:49:26 --> Helper loaded: form_helper
INFO - 2024-09-04 17:49:26 --> Form Validation Class Initialized
INFO - 2024-09-04 17:49:26 --> Controller Class Initialized
INFO - 2024-09-04 17:49:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:49:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:49:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:49:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:49:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:49:26 --> Final output sent to browser
DEBUG - 2024-09-04 17:49:26 --> Total execution time: 0.1336
INFO - 2024-09-04 17:50:09 --> Config Class Initialized
INFO - 2024-09-04 17:50:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:50:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:50:09 --> Utf8 Class Initialized
INFO - 2024-09-04 17:50:09 --> URI Class Initialized
INFO - 2024-09-04 17:50:09 --> Router Class Initialized
INFO - 2024-09-04 17:50:09 --> Output Class Initialized
INFO - 2024-09-04 17:50:09 --> Security Class Initialized
DEBUG - 2024-09-04 17:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:50:09 --> Input Class Initialized
INFO - 2024-09-04 17:50:09 --> Language Class Initialized
INFO - 2024-09-04 17:50:09 --> Loader Class Initialized
INFO - 2024-09-04 17:50:09 --> Helper loaded: url_helper
INFO - 2024-09-04 17:50:09 --> Helper loaded: file_helper
INFO - 2024-09-04 17:50:09 --> Helper loaded: security_helper
INFO - 2024-09-04 17:50:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:50:09 --> Database Driver Class Initialized
INFO - 2024-09-04 17:50:09 --> Email Class Initialized
DEBUG - 2024-09-04 17:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:50:09 --> Helper loaded: form_helper
INFO - 2024-09-04 17:50:09 --> Form Validation Class Initialized
INFO - 2024-09-04 17:50:09 --> Controller Class Initialized
INFO - 2024-09-04 17:50:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:50:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:50:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:50:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:50:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:50:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:50:10 --> Final output sent to browser
DEBUG - 2024-09-04 17:50:10 --> Total execution time: 0.1062
INFO - 2024-09-04 17:50:10 --> Config Class Initialized
INFO - 2024-09-04 17:50:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:50:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:50:10 --> Utf8 Class Initialized
INFO - 2024-09-04 17:50:10 --> URI Class Initialized
INFO - 2024-09-04 17:50:10 --> Router Class Initialized
INFO - 2024-09-04 17:50:10 --> Output Class Initialized
INFO - 2024-09-04 17:50:10 --> Security Class Initialized
DEBUG - 2024-09-04 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:50:10 --> Input Class Initialized
INFO - 2024-09-04 17:50:10 --> Language Class Initialized
ERROR - 2024-09-04 17:50:10 --> 404 Page Not Found: Report/path
INFO - 2024-09-04 17:50:46 --> Config Class Initialized
INFO - 2024-09-04 17:50:46 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:50:46 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:50:46 --> Utf8 Class Initialized
INFO - 2024-09-04 17:50:46 --> URI Class Initialized
INFO - 2024-09-04 17:50:46 --> Router Class Initialized
INFO - 2024-09-04 17:50:46 --> Output Class Initialized
INFO - 2024-09-04 17:50:46 --> Security Class Initialized
DEBUG - 2024-09-04 17:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:50:46 --> Input Class Initialized
INFO - 2024-09-04 17:50:46 --> Language Class Initialized
INFO - 2024-09-04 17:50:46 --> Loader Class Initialized
INFO - 2024-09-04 17:50:46 --> Helper loaded: url_helper
INFO - 2024-09-04 17:50:46 --> Helper loaded: file_helper
INFO - 2024-09-04 17:50:46 --> Helper loaded: security_helper
INFO - 2024-09-04 17:50:46 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:50:46 --> Database Driver Class Initialized
INFO - 2024-09-04 17:50:46 --> Email Class Initialized
DEBUG - 2024-09-04 17:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:50:46 --> Helper loaded: form_helper
INFO - 2024-09-04 17:50:46 --> Form Validation Class Initialized
INFO - 2024-09-04 17:50:46 --> Controller Class Initialized
INFO - 2024-09-04 17:50:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:50:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:50:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:50:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:50:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:50:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:50:46 --> Final output sent to browser
DEBUG - 2024-09-04 17:50:46 --> Total execution time: 0.1344
INFO - 2024-09-04 17:51:01 --> Config Class Initialized
INFO - 2024-09-04 17:51:01 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:51:01 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:51:01 --> Utf8 Class Initialized
INFO - 2024-09-04 17:51:01 --> URI Class Initialized
INFO - 2024-09-04 17:51:01 --> Router Class Initialized
INFO - 2024-09-04 17:51:01 --> Output Class Initialized
INFO - 2024-09-04 17:51:01 --> Security Class Initialized
DEBUG - 2024-09-04 17:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:51:01 --> Input Class Initialized
INFO - 2024-09-04 17:51:01 --> Language Class Initialized
INFO - 2024-09-04 17:51:01 --> Loader Class Initialized
INFO - 2024-09-04 17:51:01 --> Helper loaded: url_helper
INFO - 2024-09-04 17:51:01 --> Helper loaded: file_helper
INFO - 2024-09-04 17:51:01 --> Helper loaded: security_helper
INFO - 2024-09-04 17:51:01 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:51:01 --> Database Driver Class Initialized
INFO - 2024-09-04 17:51:01 --> Email Class Initialized
DEBUG - 2024-09-04 17:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:51:01 --> Helper loaded: form_helper
INFO - 2024-09-04 17:51:01 --> Form Validation Class Initialized
INFO - 2024-09-04 17:51:01 --> Controller Class Initialized
INFO - 2024-09-04 17:51:01 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:51:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:51:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:51:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:51:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:51:01 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:51:01 --> Final output sent to browser
DEBUG - 2024-09-04 17:51:01 --> Total execution time: 0.1209
INFO - 2024-09-04 17:51:30 --> Config Class Initialized
INFO - 2024-09-04 17:51:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:51:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:51:30 --> Utf8 Class Initialized
INFO - 2024-09-04 17:51:30 --> URI Class Initialized
INFO - 2024-09-04 17:51:30 --> Router Class Initialized
INFO - 2024-09-04 17:51:30 --> Output Class Initialized
INFO - 2024-09-04 17:51:30 --> Security Class Initialized
DEBUG - 2024-09-04 17:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:51:30 --> Input Class Initialized
INFO - 2024-09-04 17:51:30 --> Language Class Initialized
INFO - 2024-09-04 17:51:30 --> Loader Class Initialized
INFO - 2024-09-04 17:51:30 --> Helper loaded: url_helper
INFO - 2024-09-04 17:51:30 --> Helper loaded: file_helper
INFO - 2024-09-04 17:51:30 --> Helper loaded: security_helper
INFO - 2024-09-04 17:51:30 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:51:30 --> Database Driver Class Initialized
INFO - 2024-09-04 17:51:30 --> Email Class Initialized
DEBUG - 2024-09-04 17:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:51:30 --> Helper loaded: form_helper
INFO - 2024-09-04 17:51:30 --> Form Validation Class Initialized
INFO - 2024-09-04 17:51:30 --> Controller Class Initialized
INFO - 2024-09-04 17:51:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:51:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:51:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:51:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:51:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:51:30 --> Final output sent to browser
DEBUG - 2024-09-04 17:51:30 --> Total execution time: 0.1194
INFO - 2024-09-04 17:51:58 --> Config Class Initialized
INFO - 2024-09-04 17:51:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:51:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:51:58 --> Utf8 Class Initialized
INFO - 2024-09-04 17:51:58 --> URI Class Initialized
INFO - 2024-09-04 17:51:58 --> Router Class Initialized
INFO - 2024-09-04 17:51:58 --> Output Class Initialized
INFO - 2024-09-04 17:51:58 --> Security Class Initialized
DEBUG - 2024-09-04 17:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:51:58 --> Input Class Initialized
INFO - 2024-09-04 17:51:58 --> Language Class Initialized
INFO - 2024-09-04 17:51:58 --> Loader Class Initialized
INFO - 2024-09-04 17:51:58 --> Helper loaded: url_helper
INFO - 2024-09-04 17:51:58 --> Helper loaded: file_helper
INFO - 2024-09-04 17:51:58 --> Helper loaded: security_helper
INFO - 2024-09-04 17:51:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:51:58 --> Database Driver Class Initialized
INFO - 2024-09-04 17:51:58 --> Email Class Initialized
DEBUG - 2024-09-04 17:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:51:58 --> Helper loaded: form_helper
INFO - 2024-09-04 17:51:58 --> Form Validation Class Initialized
INFO - 2024-09-04 17:51:58 --> Controller Class Initialized
INFO - 2024-09-04 17:51:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:51:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:51:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:51:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:51:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:51:58 --> Final output sent to browser
DEBUG - 2024-09-04 17:51:58 --> Total execution time: 0.1046
INFO - 2024-09-04 17:52:07 --> Config Class Initialized
INFO - 2024-09-04 17:52:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:52:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:52:07 --> Utf8 Class Initialized
INFO - 2024-09-04 17:52:07 --> URI Class Initialized
INFO - 2024-09-04 17:52:07 --> Router Class Initialized
INFO - 2024-09-04 17:52:07 --> Output Class Initialized
INFO - 2024-09-04 17:52:07 --> Security Class Initialized
DEBUG - 2024-09-04 17:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:52:07 --> Input Class Initialized
INFO - 2024-09-04 17:52:07 --> Language Class Initialized
INFO - 2024-09-04 17:52:07 --> Loader Class Initialized
INFO - 2024-09-04 17:52:07 --> Helper loaded: url_helper
INFO - 2024-09-04 17:52:07 --> Helper loaded: file_helper
INFO - 2024-09-04 17:52:07 --> Helper loaded: security_helper
INFO - 2024-09-04 17:52:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:52:07 --> Database Driver Class Initialized
INFO - 2024-09-04 17:52:07 --> Email Class Initialized
DEBUG - 2024-09-04 17:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:52:07 --> Helper loaded: form_helper
INFO - 2024-09-04 17:52:07 --> Form Validation Class Initialized
INFO - 2024-09-04 17:52:07 --> Controller Class Initialized
INFO - 2024-09-04 17:52:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:52:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:52:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:52:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:52:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:52:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:52:07 --> Final output sent to browser
DEBUG - 2024-09-04 17:52:07 --> Total execution time: 0.1354
INFO - 2024-09-04 17:52:08 --> Config Class Initialized
INFO - 2024-09-04 17:52:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:52:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:52:08 --> Utf8 Class Initialized
INFO - 2024-09-04 17:52:08 --> URI Class Initialized
INFO - 2024-09-04 17:52:08 --> Router Class Initialized
INFO - 2024-09-04 17:52:08 --> Output Class Initialized
INFO - 2024-09-04 17:52:08 --> Security Class Initialized
DEBUG - 2024-09-04 17:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:52:08 --> Input Class Initialized
INFO - 2024-09-04 17:52:08 --> Language Class Initialized
INFO - 2024-09-04 17:52:08 --> Loader Class Initialized
INFO - 2024-09-04 17:52:08 --> Helper loaded: url_helper
INFO - 2024-09-04 17:52:08 --> Helper loaded: file_helper
INFO - 2024-09-04 17:52:08 --> Helper loaded: security_helper
INFO - 2024-09-04 17:52:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:52:08 --> Database Driver Class Initialized
INFO - 2024-09-04 17:52:08 --> Email Class Initialized
DEBUG - 2024-09-04 17:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:52:08 --> Helper loaded: form_helper
INFO - 2024-09-04 17:52:08 --> Form Validation Class Initialized
INFO - 2024-09-04 17:52:08 --> Controller Class Initialized
INFO - 2024-09-04 17:52:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:52:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:52:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:52:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:52:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:52:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:52:08 --> Final output sent to browser
DEBUG - 2024-09-04 17:52:08 --> Total execution time: 0.1037
INFO - 2024-09-04 17:52:22 --> Config Class Initialized
INFO - 2024-09-04 17:52:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:52:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:52:22 --> Utf8 Class Initialized
INFO - 2024-09-04 17:52:22 --> URI Class Initialized
INFO - 2024-09-04 17:52:22 --> Router Class Initialized
INFO - 2024-09-04 17:52:22 --> Output Class Initialized
INFO - 2024-09-04 17:52:22 --> Security Class Initialized
DEBUG - 2024-09-04 17:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:52:22 --> Input Class Initialized
INFO - 2024-09-04 17:52:22 --> Language Class Initialized
INFO - 2024-09-04 17:52:22 --> Loader Class Initialized
INFO - 2024-09-04 17:52:22 --> Helper loaded: url_helper
INFO - 2024-09-04 17:52:22 --> Helper loaded: file_helper
INFO - 2024-09-04 17:52:22 --> Helper loaded: security_helper
INFO - 2024-09-04 17:52:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:52:22 --> Database Driver Class Initialized
INFO - 2024-09-04 17:52:22 --> Email Class Initialized
DEBUG - 2024-09-04 17:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:52:22 --> Helper loaded: form_helper
INFO - 2024-09-04 17:52:22 --> Form Validation Class Initialized
INFO - 2024-09-04 17:52:22 --> Controller Class Initialized
INFO - 2024-09-04 17:52:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:52:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:52:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:52:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:52:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:52:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:52:22 --> Final output sent to browser
DEBUG - 2024-09-04 17:52:22 --> Total execution time: 0.1120
INFO - 2024-09-04 17:52:26 --> Config Class Initialized
INFO - 2024-09-04 17:52:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:52:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:52:26 --> Utf8 Class Initialized
INFO - 2024-09-04 17:52:26 --> URI Class Initialized
INFO - 2024-09-04 17:52:26 --> Router Class Initialized
INFO - 2024-09-04 17:52:26 --> Output Class Initialized
INFO - 2024-09-04 17:52:26 --> Security Class Initialized
DEBUG - 2024-09-04 17:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:52:26 --> Input Class Initialized
INFO - 2024-09-04 17:52:26 --> Language Class Initialized
INFO - 2024-09-04 17:52:26 --> Loader Class Initialized
INFO - 2024-09-04 17:52:26 --> Helper loaded: url_helper
INFO - 2024-09-04 17:52:26 --> Helper loaded: file_helper
INFO - 2024-09-04 17:52:26 --> Helper loaded: security_helper
INFO - 2024-09-04 17:52:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:52:26 --> Database Driver Class Initialized
INFO - 2024-09-04 17:52:26 --> Email Class Initialized
DEBUG - 2024-09-04 17:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:52:26 --> Helper loaded: form_helper
INFO - 2024-09-04 17:52:26 --> Form Validation Class Initialized
INFO - 2024-09-04 17:52:26 --> Controller Class Initialized
INFO - 2024-09-04 17:52:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:52:26 --> Final output sent to browser
DEBUG - 2024-09-04 17:52:26 --> Total execution time: 0.1379
INFO - 2024-09-04 17:52:45 --> Config Class Initialized
INFO - 2024-09-04 17:52:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:52:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:52:45 --> Utf8 Class Initialized
INFO - 2024-09-04 17:52:45 --> URI Class Initialized
INFO - 2024-09-04 17:52:45 --> Router Class Initialized
INFO - 2024-09-04 17:52:45 --> Output Class Initialized
INFO - 2024-09-04 17:52:45 --> Security Class Initialized
DEBUG - 2024-09-04 17:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:52:45 --> Input Class Initialized
INFO - 2024-09-04 17:52:45 --> Language Class Initialized
INFO - 2024-09-04 17:52:45 --> Loader Class Initialized
INFO - 2024-09-04 17:52:45 --> Helper loaded: url_helper
INFO - 2024-09-04 17:52:45 --> Helper loaded: file_helper
INFO - 2024-09-04 17:52:45 --> Helper loaded: security_helper
INFO - 2024-09-04 17:52:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:52:45 --> Database Driver Class Initialized
INFO - 2024-09-04 17:52:45 --> Email Class Initialized
DEBUG - 2024-09-04 17:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:52:45 --> Helper loaded: form_helper
INFO - 2024-09-04 17:52:45 --> Form Validation Class Initialized
INFO - 2024-09-04 17:52:45 --> Controller Class Initialized
INFO - 2024-09-04 17:52:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:52:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:52:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:52:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:52:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:52:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:52:45 --> Final output sent to browser
DEBUG - 2024-09-04 17:52:45 --> Total execution time: 0.1405
INFO - 2024-09-04 17:54:58 --> Config Class Initialized
INFO - 2024-09-04 17:54:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:54:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:54:58 --> Utf8 Class Initialized
INFO - 2024-09-04 17:54:58 --> URI Class Initialized
INFO - 2024-09-04 17:54:58 --> Router Class Initialized
INFO - 2024-09-04 17:54:58 --> Output Class Initialized
INFO - 2024-09-04 17:54:58 --> Security Class Initialized
DEBUG - 2024-09-04 17:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:54:58 --> Input Class Initialized
INFO - 2024-09-04 17:54:59 --> Language Class Initialized
INFO - 2024-09-04 17:54:59 --> Loader Class Initialized
INFO - 2024-09-04 17:54:59 --> Helper loaded: url_helper
INFO - 2024-09-04 17:54:59 --> Helper loaded: file_helper
INFO - 2024-09-04 17:54:59 --> Helper loaded: security_helper
INFO - 2024-09-04 17:54:59 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:54:59 --> Database Driver Class Initialized
INFO - 2024-09-04 17:54:59 --> Email Class Initialized
DEBUG - 2024-09-04 17:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:54:59 --> Helper loaded: form_helper
INFO - 2024-09-04 17:54:59 --> Form Validation Class Initialized
INFO - 2024-09-04 17:54:59 --> Controller Class Initialized
INFO - 2024-09-04 17:54:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:54:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:54:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:54:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:54:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:54:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:54:59 --> Final output sent to browser
DEBUG - 2024-09-04 17:54:59 --> Total execution time: 0.1235
INFO - 2024-09-04 17:55:16 --> Config Class Initialized
INFO - 2024-09-04 17:55:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:55:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:55:16 --> Utf8 Class Initialized
INFO - 2024-09-04 17:55:16 --> URI Class Initialized
INFO - 2024-09-04 17:55:16 --> Router Class Initialized
INFO - 2024-09-04 17:55:16 --> Output Class Initialized
INFO - 2024-09-04 17:55:16 --> Security Class Initialized
DEBUG - 2024-09-04 17:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:55:16 --> Input Class Initialized
INFO - 2024-09-04 17:55:16 --> Language Class Initialized
INFO - 2024-09-04 17:55:16 --> Loader Class Initialized
INFO - 2024-09-04 17:55:16 --> Helper loaded: url_helper
INFO - 2024-09-04 17:55:16 --> Helper loaded: file_helper
INFO - 2024-09-04 17:55:16 --> Helper loaded: security_helper
INFO - 2024-09-04 17:55:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:55:16 --> Database Driver Class Initialized
INFO - 2024-09-04 17:55:16 --> Email Class Initialized
DEBUG - 2024-09-04 17:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:55:16 --> Helper loaded: form_helper
INFO - 2024-09-04 17:55:16 --> Form Validation Class Initialized
INFO - 2024-09-04 17:55:16 --> Controller Class Initialized
INFO - 2024-09-04 17:55:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:55:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:55:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:55:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:55:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:55:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:55:16 --> Final output sent to browser
DEBUG - 2024-09-04 17:55:16 --> Total execution time: 0.1292
INFO - 2024-09-04 17:56:38 --> Config Class Initialized
INFO - 2024-09-04 17:56:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:56:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:56:38 --> Utf8 Class Initialized
INFO - 2024-09-04 17:56:38 --> URI Class Initialized
INFO - 2024-09-04 17:56:38 --> Router Class Initialized
INFO - 2024-09-04 17:56:38 --> Output Class Initialized
INFO - 2024-09-04 17:56:38 --> Security Class Initialized
DEBUG - 2024-09-04 17:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:56:38 --> Input Class Initialized
INFO - 2024-09-04 17:56:38 --> Language Class Initialized
INFO - 2024-09-04 17:56:38 --> Loader Class Initialized
INFO - 2024-09-04 17:56:38 --> Helper loaded: url_helper
INFO - 2024-09-04 17:56:38 --> Helper loaded: file_helper
INFO - 2024-09-04 17:56:38 --> Helper loaded: security_helper
INFO - 2024-09-04 17:56:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:56:38 --> Database Driver Class Initialized
INFO - 2024-09-04 17:56:38 --> Email Class Initialized
DEBUG - 2024-09-04 17:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:56:38 --> Helper loaded: form_helper
INFO - 2024-09-04 17:56:38 --> Form Validation Class Initialized
INFO - 2024-09-04 17:56:38 --> Controller Class Initialized
INFO - 2024-09-04 17:56:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:56:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:56:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:56:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:56:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:56:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:56:38 --> Final output sent to browser
DEBUG - 2024-09-04 17:56:38 --> Total execution time: 0.1421
INFO - 2024-09-04 17:57:00 --> Config Class Initialized
INFO - 2024-09-04 17:57:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:57:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:57:00 --> Utf8 Class Initialized
INFO - 2024-09-04 17:57:00 --> URI Class Initialized
INFO - 2024-09-04 17:57:00 --> Router Class Initialized
INFO - 2024-09-04 17:57:00 --> Output Class Initialized
INFO - 2024-09-04 17:57:00 --> Security Class Initialized
DEBUG - 2024-09-04 17:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:57:00 --> Input Class Initialized
INFO - 2024-09-04 17:57:00 --> Language Class Initialized
INFO - 2024-09-04 17:57:00 --> Loader Class Initialized
INFO - 2024-09-04 17:57:00 --> Helper loaded: url_helper
INFO - 2024-09-04 17:57:00 --> Helper loaded: file_helper
INFO - 2024-09-04 17:57:00 --> Helper loaded: security_helper
INFO - 2024-09-04 17:57:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:57:00 --> Database Driver Class Initialized
INFO - 2024-09-04 17:57:00 --> Email Class Initialized
DEBUG - 2024-09-04 17:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:57:00 --> Helper loaded: form_helper
INFO - 2024-09-04 17:57:00 --> Form Validation Class Initialized
INFO - 2024-09-04 17:57:00 --> Controller Class Initialized
INFO - 2024-09-04 17:57:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:57:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:57:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:57:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:57:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:57:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:57:00 --> Final output sent to browser
DEBUG - 2024-09-04 17:57:00 --> Total execution time: 0.1151
INFO - 2024-09-04 17:57:14 --> Config Class Initialized
INFO - 2024-09-04 17:57:14 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:57:14 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:57:14 --> Utf8 Class Initialized
INFO - 2024-09-04 17:57:14 --> URI Class Initialized
INFO - 2024-09-04 17:57:14 --> Router Class Initialized
INFO - 2024-09-04 17:57:14 --> Output Class Initialized
INFO - 2024-09-04 17:57:14 --> Security Class Initialized
DEBUG - 2024-09-04 17:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:57:14 --> Input Class Initialized
INFO - 2024-09-04 17:57:14 --> Language Class Initialized
INFO - 2024-09-04 17:57:14 --> Loader Class Initialized
INFO - 2024-09-04 17:57:14 --> Helper loaded: url_helper
INFO - 2024-09-04 17:57:14 --> Helper loaded: file_helper
INFO - 2024-09-04 17:57:14 --> Helper loaded: security_helper
INFO - 2024-09-04 17:57:14 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:57:14 --> Database Driver Class Initialized
INFO - 2024-09-04 17:57:14 --> Email Class Initialized
DEBUG - 2024-09-04 17:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:57:14 --> Helper loaded: form_helper
INFO - 2024-09-04 17:57:14 --> Form Validation Class Initialized
INFO - 2024-09-04 17:57:14 --> Controller Class Initialized
INFO - 2024-09-04 17:57:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:57:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:57:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:57:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:57:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 17:57:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:57:15 --> Final output sent to browser
DEBUG - 2024-09-04 17:57:15 --> Total execution time: 0.1697
INFO - 2024-09-04 17:57:29 --> Config Class Initialized
INFO - 2024-09-04 17:57:29 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:57:29 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:57:29 --> Utf8 Class Initialized
INFO - 2024-09-04 17:57:29 --> URI Class Initialized
INFO - 2024-09-04 17:57:29 --> Router Class Initialized
INFO - 2024-09-04 17:57:29 --> Output Class Initialized
INFO - 2024-09-04 17:57:29 --> Security Class Initialized
DEBUG - 2024-09-04 17:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:57:29 --> Input Class Initialized
INFO - 2024-09-04 17:57:29 --> Language Class Initialized
INFO - 2024-09-04 17:57:29 --> Loader Class Initialized
INFO - 2024-09-04 17:57:29 --> Helper loaded: url_helper
INFO - 2024-09-04 17:57:29 --> Helper loaded: file_helper
INFO - 2024-09-04 17:57:29 --> Helper loaded: security_helper
INFO - 2024-09-04 17:57:29 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:57:29 --> Database Driver Class Initialized
INFO - 2024-09-04 17:57:29 --> Email Class Initialized
DEBUG - 2024-09-04 17:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:57:29 --> Helper loaded: form_helper
INFO - 2024-09-04 17:57:29 --> Form Validation Class Initialized
INFO - 2024-09-04 17:57:29 --> Controller Class Initialized
INFO - 2024-09-04 17:57:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:57:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:57:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:57:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:57:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:57:29 --> Final output sent to browser
DEBUG - 2024-09-04 17:57:29 --> Total execution time: 0.0649
INFO - 2024-09-04 17:57:40 --> Config Class Initialized
INFO - 2024-09-04 17:57:40 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:57:40 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:57:40 --> Utf8 Class Initialized
INFO - 2024-09-04 17:57:40 --> URI Class Initialized
INFO - 2024-09-04 17:57:40 --> Router Class Initialized
INFO - 2024-09-04 17:57:40 --> Output Class Initialized
INFO - 2024-09-04 17:57:40 --> Security Class Initialized
DEBUG - 2024-09-04 17:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:57:40 --> Input Class Initialized
INFO - 2024-09-04 17:57:40 --> Language Class Initialized
INFO - 2024-09-04 17:57:40 --> Loader Class Initialized
INFO - 2024-09-04 17:57:40 --> Helper loaded: url_helper
INFO - 2024-09-04 17:57:40 --> Helper loaded: file_helper
INFO - 2024-09-04 17:57:40 --> Helper loaded: security_helper
INFO - 2024-09-04 17:57:40 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:57:40 --> Database Driver Class Initialized
INFO - 2024-09-04 17:57:40 --> Email Class Initialized
DEBUG - 2024-09-04 17:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:57:40 --> Helper loaded: form_helper
INFO - 2024-09-04 17:57:40 --> Form Validation Class Initialized
INFO - 2024-09-04 17:57:40 --> Controller Class Initialized
INFO - 2024-09-04 17:57:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:57:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:57:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:57:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:57:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:57:40 --> Final output sent to browser
DEBUG - 2024-09-04 17:57:40 --> Total execution time: 0.1171
INFO - 2024-09-04 17:57:49 --> Config Class Initialized
INFO - 2024-09-04 17:57:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:57:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:57:49 --> Utf8 Class Initialized
INFO - 2024-09-04 17:57:49 --> URI Class Initialized
INFO - 2024-09-04 17:57:49 --> Router Class Initialized
INFO - 2024-09-04 17:57:49 --> Output Class Initialized
INFO - 2024-09-04 17:57:49 --> Security Class Initialized
DEBUG - 2024-09-04 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:57:49 --> Input Class Initialized
INFO - 2024-09-04 17:57:49 --> Language Class Initialized
INFO - 2024-09-04 17:57:49 --> Loader Class Initialized
INFO - 2024-09-04 17:57:49 --> Helper loaded: url_helper
INFO - 2024-09-04 17:57:49 --> Helper loaded: file_helper
INFO - 2024-09-04 17:57:49 --> Helper loaded: security_helper
INFO - 2024-09-04 17:57:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:57:49 --> Database Driver Class Initialized
INFO - 2024-09-04 17:57:49 --> Email Class Initialized
DEBUG - 2024-09-04 17:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:57:49 --> Helper loaded: form_helper
INFO - 2024-09-04 17:57:49 --> Form Validation Class Initialized
INFO - 2024-09-04 17:57:49 --> Controller Class Initialized
INFO - 2024-09-04 17:57:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:57:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:57:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:57:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:57:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:57:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:57:49 --> Final output sent to browser
DEBUG - 2024-09-04 17:57:49 --> Total execution time: 0.1150
INFO - 2024-09-04 17:59:33 --> Config Class Initialized
INFO - 2024-09-04 17:59:33 --> Hooks Class Initialized
DEBUG - 2024-09-04 17:59:33 --> UTF-8 Support Enabled
INFO - 2024-09-04 17:59:33 --> Utf8 Class Initialized
INFO - 2024-09-04 17:59:33 --> URI Class Initialized
INFO - 2024-09-04 17:59:33 --> Router Class Initialized
INFO - 2024-09-04 17:59:33 --> Output Class Initialized
INFO - 2024-09-04 17:59:33 --> Security Class Initialized
DEBUG - 2024-09-04 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 17:59:33 --> Input Class Initialized
INFO - 2024-09-04 17:59:33 --> Language Class Initialized
INFO - 2024-09-04 17:59:33 --> Loader Class Initialized
INFO - 2024-09-04 17:59:33 --> Helper loaded: url_helper
INFO - 2024-09-04 17:59:33 --> Helper loaded: file_helper
INFO - 2024-09-04 17:59:33 --> Helper loaded: security_helper
INFO - 2024-09-04 17:59:33 --> Helper loaded: wpu_helper
INFO - 2024-09-04 17:59:33 --> Database Driver Class Initialized
INFO - 2024-09-04 17:59:33 --> Email Class Initialized
DEBUG - 2024-09-04 17:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 17:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 17:59:33 --> Helper loaded: form_helper
INFO - 2024-09-04 17:59:33 --> Form Validation Class Initialized
INFO - 2024-09-04 17:59:33 --> Controller Class Initialized
INFO - 2024-09-04 17:59:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 17:59:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 17:59:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 17:59:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 17:59:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 17:59:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 17:59:34 --> Final output sent to browser
DEBUG - 2024-09-04 17:59:34 --> Total execution time: 0.1266
INFO - 2024-09-04 18:00:57 --> Config Class Initialized
INFO - 2024-09-04 18:00:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:00:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:00:57 --> Utf8 Class Initialized
INFO - 2024-09-04 18:00:57 --> URI Class Initialized
INFO - 2024-09-04 18:00:57 --> Router Class Initialized
INFO - 2024-09-04 18:00:57 --> Output Class Initialized
INFO - 2024-09-04 18:00:57 --> Security Class Initialized
DEBUG - 2024-09-04 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:00:57 --> Input Class Initialized
INFO - 2024-09-04 18:00:57 --> Language Class Initialized
INFO - 2024-09-04 18:00:57 --> Loader Class Initialized
INFO - 2024-09-04 18:00:57 --> Helper loaded: url_helper
INFO - 2024-09-04 18:00:57 --> Helper loaded: file_helper
INFO - 2024-09-04 18:00:57 --> Helper loaded: security_helper
INFO - 2024-09-04 18:00:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:00:57 --> Database Driver Class Initialized
INFO - 2024-09-04 18:00:57 --> Email Class Initialized
DEBUG - 2024-09-04 18:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:00:57 --> Helper loaded: form_helper
INFO - 2024-09-04 18:00:57 --> Form Validation Class Initialized
INFO - 2024-09-04 18:00:57 --> Controller Class Initialized
INFO - 2024-09-04 18:00:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:00:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:00:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:00:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:00:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:00:57 --> Final output sent to browser
DEBUG - 2024-09-04 18:00:57 --> Total execution time: 0.1023
INFO - 2024-09-04 18:01:10 --> Config Class Initialized
INFO - 2024-09-04 18:01:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:01:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:01:10 --> Utf8 Class Initialized
INFO - 2024-09-04 18:01:10 --> URI Class Initialized
INFO - 2024-09-04 18:01:10 --> Router Class Initialized
INFO - 2024-09-04 18:01:10 --> Output Class Initialized
INFO - 2024-09-04 18:01:10 --> Security Class Initialized
DEBUG - 2024-09-04 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:01:10 --> Input Class Initialized
INFO - 2024-09-04 18:01:10 --> Language Class Initialized
INFO - 2024-09-04 18:01:10 --> Loader Class Initialized
INFO - 2024-09-04 18:01:10 --> Helper loaded: url_helper
INFO - 2024-09-04 18:01:10 --> Helper loaded: file_helper
INFO - 2024-09-04 18:01:10 --> Helper loaded: security_helper
INFO - 2024-09-04 18:01:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:01:10 --> Database Driver Class Initialized
INFO - 2024-09-04 18:01:10 --> Email Class Initialized
DEBUG - 2024-09-04 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:01:10 --> Helper loaded: form_helper
INFO - 2024-09-04 18:01:10 --> Form Validation Class Initialized
INFO - 2024-09-04 18:01:10 --> Controller Class Initialized
INFO - 2024-09-04 18:01:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:01:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:01:10 --> Final output sent to browser
DEBUG - 2024-09-04 18:01:10 --> Total execution time: 0.1206
INFO - 2024-09-04 18:01:22 --> Config Class Initialized
INFO - 2024-09-04 18:01:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:01:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:01:22 --> Utf8 Class Initialized
INFO - 2024-09-04 18:01:22 --> URI Class Initialized
INFO - 2024-09-04 18:01:22 --> Router Class Initialized
INFO - 2024-09-04 18:01:22 --> Output Class Initialized
INFO - 2024-09-04 18:01:22 --> Security Class Initialized
DEBUG - 2024-09-04 18:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:01:22 --> Input Class Initialized
INFO - 2024-09-04 18:01:22 --> Language Class Initialized
INFO - 2024-09-04 18:01:22 --> Loader Class Initialized
INFO - 2024-09-04 18:01:22 --> Helper loaded: url_helper
INFO - 2024-09-04 18:01:22 --> Helper loaded: file_helper
INFO - 2024-09-04 18:01:22 --> Helper loaded: security_helper
INFO - 2024-09-04 18:01:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:01:22 --> Database Driver Class Initialized
INFO - 2024-09-04 18:01:22 --> Email Class Initialized
DEBUG - 2024-09-04 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:01:22 --> Helper loaded: form_helper
INFO - 2024-09-04 18:01:22 --> Form Validation Class Initialized
INFO - 2024-09-04 18:01:22 --> Controller Class Initialized
INFO - 2024-09-04 18:01:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:01:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:01:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:01:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:01:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:01:22 --> Final output sent to browser
DEBUG - 2024-09-04 18:01:22 --> Total execution time: 0.0833
INFO - 2024-09-04 18:01:26 --> Config Class Initialized
INFO - 2024-09-04 18:01:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:01:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:01:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:01:26 --> URI Class Initialized
INFO - 2024-09-04 18:01:26 --> Router Class Initialized
INFO - 2024-09-04 18:01:26 --> Output Class Initialized
INFO - 2024-09-04 18:01:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:01:26 --> Input Class Initialized
INFO - 2024-09-04 18:01:26 --> Language Class Initialized
INFO - 2024-09-04 18:01:26 --> Loader Class Initialized
INFO - 2024-09-04 18:01:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:01:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:01:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:01:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:01:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:01:27 --> Email Class Initialized
DEBUG - 2024-09-04 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:01:27 --> Helper loaded: form_helper
INFO - 2024-09-04 18:01:27 --> Form Validation Class Initialized
INFO - 2024-09-04 18:01:27 --> Controller Class Initialized
INFO - 2024-09-04 18:01:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:01:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:01:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:01:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:01:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:01:27 --> Final output sent to browser
DEBUG - 2024-09-04 18:01:27 --> Total execution time: 0.1607
INFO - 2024-09-04 18:01:44 --> Config Class Initialized
INFO - 2024-09-04 18:01:44 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:01:44 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:01:44 --> Utf8 Class Initialized
INFO - 2024-09-04 18:01:44 --> URI Class Initialized
INFO - 2024-09-04 18:01:44 --> Router Class Initialized
INFO - 2024-09-04 18:01:44 --> Output Class Initialized
INFO - 2024-09-04 18:01:44 --> Security Class Initialized
DEBUG - 2024-09-04 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:01:44 --> Input Class Initialized
INFO - 2024-09-04 18:01:44 --> Language Class Initialized
INFO - 2024-09-04 18:01:44 --> Loader Class Initialized
INFO - 2024-09-04 18:01:44 --> Helper loaded: url_helper
INFO - 2024-09-04 18:01:44 --> Helper loaded: file_helper
INFO - 2024-09-04 18:01:44 --> Helper loaded: security_helper
INFO - 2024-09-04 18:01:44 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:01:44 --> Database Driver Class Initialized
INFO - 2024-09-04 18:01:44 --> Email Class Initialized
DEBUG - 2024-09-04 18:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:01:44 --> Helper loaded: form_helper
INFO - 2024-09-04 18:01:44 --> Form Validation Class Initialized
INFO - 2024-09-04 18:01:44 --> Controller Class Initialized
INFO - 2024-09-04 18:01:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:01:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:01:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:01:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:01:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:01:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:01:44 --> Final output sent to browser
DEBUG - 2024-09-04 18:01:44 --> Total execution time: 0.1339
INFO - 2024-09-04 18:02:12 --> Config Class Initialized
INFO - 2024-09-04 18:02:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:02:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:02:12 --> Utf8 Class Initialized
INFO - 2024-09-04 18:02:12 --> URI Class Initialized
INFO - 2024-09-04 18:02:12 --> Router Class Initialized
INFO - 2024-09-04 18:02:12 --> Output Class Initialized
INFO - 2024-09-04 18:02:12 --> Security Class Initialized
DEBUG - 2024-09-04 18:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:02:12 --> Input Class Initialized
INFO - 2024-09-04 18:02:12 --> Language Class Initialized
INFO - 2024-09-04 18:02:12 --> Loader Class Initialized
INFO - 2024-09-04 18:02:12 --> Helper loaded: url_helper
INFO - 2024-09-04 18:02:12 --> Helper loaded: file_helper
INFO - 2024-09-04 18:02:12 --> Helper loaded: security_helper
INFO - 2024-09-04 18:02:12 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:02:12 --> Database Driver Class Initialized
INFO - 2024-09-04 18:02:12 --> Email Class Initialized
DEBUG - 2024-09-04 18:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:02:12 --> Helper loaded: form_helper
INFO - 2024-09-04 18:02:12 --> Form Validation Class Initialized
INFO - 2024-09-04 18:02:12 --> Controller Class Initialized
INFO - 2024-09-04 18:02:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:02:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:02:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:02:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:02:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:02:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:02:12 --> Final output sent to browser
DEBUG - 2024-09-04 18:02:12 --> Total execution time: 0.1189
INFO - 2024-09-04 18:02:26 --> Config Class Initialized
INFO - 2024-09-04 18:02:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:02:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:02:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:02:26 --> URI Class Initialized
INFO - 2024-09-04 18:02:26 --> Router Class Initialized
INFO - 2024-09-04 18:02:26 --> Output Class Initialized
INFO - 2024-09-04 18:02:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:02:26 --> Input Class Initialized
INFO - 2024-09-04 18:02:26 --> Language Class Initialized
INFO - 2024-09-04 18:02:26 --> Loader Class Initialized
INFO - 2024-09-04 18:02:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:02:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:02:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:02:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:02:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:02:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:02:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:02:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:02:26 --> Controller Class Initialized
INFO - 2024-09-04 18:02:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:02:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:02:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:02:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:02:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:02:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:02:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:02:26 --> Total execution time: 0.1056
INFO - 2024-09-04 18:02:48 --> Config Class Initialized
INFO - 2024-09-04 18:02:48 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:02:48 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:02:48 --> Utf8 Class Initialized
INFO - 2024-09-04 18:02:48 --> URI Class Initialized
INFO - 2024-09-04 18:02:48 --> Router Class Initialized
INFO - 2024-09-04 18:02:48 --> Output Class Initialized
INFO - 2024-09-04 18:02:48 --> Security Class Initialized
DEBUG - 2024-09-04 18:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:02:48 --> Input Class Initialized
INFO - 2024-09-04 18:02:48 --> Language Class Initialized
INFO - 2024-09-04 18:02:48 --> Loader Class Initialized
INFO - 2024-09-04 18:02:48 --> Helper loaded: url_helper
INFO - 2024-09-04 18:02:48 --> Helper loaded: file_helper
INFO - 2024-09-04 18:02:48 --> Helper loaded: security_helper
INFO - 2024-09-04 18:02:48 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:02:48 --> Database Driver Class Initialized
INFO - 2024-09-04 18:02:48 --> Email Class Initialized
DEBUG - 2024-09-04 18:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:02:48 --> Helper loaded: form_helper
INFO - 2024-09-04 18:02:48 --> Form Validation Class Initialized
INFO - 2024-09-04 18:02:48 --> Controller Class Initialized
INFO - 2024-09-04 18:02:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:02:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:02:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:02:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:02:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:02:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:02:48 --> Final output sent to browser
DEBUG - 2024-09-04 18:02:48 --> Total execution time: 0.1194
INFO - 2024-09-04 18:03:39 --> Config Class Initialized
INFO - 2024-09-04 18:03:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:03:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:03:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:03:39 --> URI Class Initialized
INFO - 2024-09-04 18:03:39 --> Router Class Initialized
INFO - 2024-09-04 18:03:39 --> Output Class Initialized
INFO - 2024-09-04 18:03:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:03:39 --> Input Class Initialized
INFO - 2024-09-04 18:03:39 --> Language Class Initialized
INFO - 2024-09-04 18:03:39 --> Loader Class Initialized
INFO - 2024-09-04 18:03:39 --> Helper loaded: url_helper
INFO - 2024-09-04 18:03:39 --> Helper loaded: file_helper
INFO - 2024-09-04 18:03:39 --> Helper loaded: security_helper
INFO - 2024-09-04 18:03:39 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:03:39 --> Database Driver Class Initialized
INFO - 2024-09-04 18:03:39 --> Email Class Initialized
DEBUG - 2024-09-04 18:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:03:39 --> Helper loaded: form_helper
INFO - 2024-09-04 18:03:39 --> Form Validation Class Initialized
INFO - 2024-09-04 18:03:39 --> Controller Class Initialized
INFO - 2024-09-04 18:03:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:03:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:03:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:03:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:03:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:03:39 --> Final output sent to browser
DEBUG - 2024-09-04 18:03:39 --> Total execution time: 0.1197
INFO - 2024-09-04 18:03:49 --> Config Class Initialized
INFO - 2024-09-04 18:03:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:03:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:03:49 --> Utf8 Class Initialized
INFO - 2024-09-04 18:03:49 --> URI Class Initialized
INFO - 2024-09-04 18:03:49 --> Router Class Initialized
INFO - 2024-09-04 18:03:49 --> Output Class Initialized
INFO - 2024-09-04 18:03:49 --> Security Class Initialized
DEBUG - 2024-09-04 18:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:03:49 --> Input Class Initialized
INFO - 2024-09-04 18:03:49 --> Language Class Initialized
INFO - 2024-09-04 18:03:49 --> Loader Class Initialized
INFO - 2024-09-04 18:03:49 --> Helper loaded: url_helper
INFO - 2024-09-04 18:03:49 --> Helper loaded: file_helper
INFO - 2024-09-04 18:03:49 --> Helper loaded: security_helper
INFO - 2024-09-04 18:03:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:03:49 --> Database Driver Class Initialized
INFO - 2024-09-04 18:03:49 --> Email Class Initialized
DEBUG - 2024-09-04 18:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:03:49 --> Helper loaded: form_helper
INFO - 2024-09-04 18:03:49 --> Form Validation Class Initialized
INFO - 2024-09-04 18:03:49 --> Controller Class Initialized
INFO - 2024-09-04 18:03:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:03:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:03:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:03:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:03:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:03:49 --> Final output sent to browser
DEBUG - 2024-09-04 18:03:49 --> Total execution time: 0.1046
INFO - 2024-09-04 18:03:56 --> Config Class Initialized
INFO - 2024-09-04 18:03:56 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:03:56 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:03:56 --> Utf8 Class Initialized
INFO - 2024-09-04 18:03:56 --> URI Class Initialized
INFO - 2024-09-04 18:03:56 --> Router Class Initialized
INFO - 2024-09-04 18:03:56 --> Output Class Initialized
INFO - 2024-09-04 18:03:56 --> Security Class Initialized
DEBUG - 2024-09-04 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:03:56 --> Input Class Initialized
INFO - 2024-09-04 18:03:56 --> Language Class Initialized
INFO - 2024-09-04 18:03:56 --> Loader Class Initialized
INFO - 2024-09-04 18:03:56 --> Helper loaded: url_helper
INFO - 2024-09-04 18:03:56 --> Helper loaded: file_helper
INFO - 2024-09-04 18:03:56 --> Helper loaded: security_helper
INFO - 2024-09-04 18:03:56 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:03:56 --> Database Driver Class Initialized
INFO - 2024-09-04 18:03:56 --> Email Class Initialized
DEBUG - 2024-09-04 18:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:03:56 --> Helper loaded: form_helper
INFO - 2024-09-04 18:03:56 --> Form Validation Class Initialized
INFO - 2024-09-04 18:03:56 --> Controller Class Initialized
INFO - 2024-09-04 18:03:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:03:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:03:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:03:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:03:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:03:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:03:56 --> Final output sent to browser
DEBUG - 2024-09-04 18:03:56 --> Total execution time: 0.1126
INFO - 2024-09-04 18:04:10 --> Config Class Initialized
INFO - 2024-09-04 18:04:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:04:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:04:10 --> Utf8 Class Initialized
INFO - 2024-09-04 18:04:10 --> URI Class Initialized
INFO - 2024-09-04 18:04:10 --> Router Class Initialized
INFO - 2024-09-04 18:04:10 --> Output Class Initialized
INFO - 2024-09-04 18:04:10 --> Security Class Initialized
DEBUG - 2024-09-04 18:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:04:10 --> Input Class Initialized
INFO - 2024-09-04 18:04:10 --> Language Class Initialized
INFO - 2024-09-04 18:04:10 --> Loader Class Initialized
INFO - 2024-09-04 18:04:10 --> Helper loaded: url_helper
INFO - 2024-09-04 18:04:10 --> Helper loaded: file_helper
INFO - 2024-09-04 18:04:10 --> Helper loaded: security_helper
INFO - 2024-09-04 18:04:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:04:10 --> Database Driver Class Initialized
INFO - 2024-09-04 18:04:10 --> Email Class Initialized
DEBUG - 2024-09-04 18:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:04:10 --> Helper loaded: form_helper
INFO - 2024-09-04 18:04:10 --> Form Validation Class Initialized
INFO - 2024-09-04 18:04:10 --> Controller Class Initialized
INFO - 2024-09-04 18:04:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:04:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:04:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:04:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:04:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:04:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:04:10 --> Final output sent to browser
DEBUG - 2024-09-04 18:04:10 --> Total execution time: 0.1612
INFO - 2024-09-04 18:05:50 --> Config Class Initialized
INFO - 2024-09-04 18:05:50 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:05:50 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:05:50 --> Utf8 Class Initialized
INFO - 2024-09-04 18:05:50 --> URI Class Initialized
INFO - 2024-09-04 18:05:50 --> Router Class Initialized
INFO - 2024-09-04 18:05:50 --> Output Class Initialized
INFO - 2024-09-04 18:05:50 --> Security Class Initialized
DEBUG - 2024-09-04 18:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:05:50 --> Input Class Initialized
INFO - 2024-09-04 18:05:50 --> Language Class Initialized
INFO - 2024-09-04 18:05:50 --> Loader Class Initialized
INFO - 2024-09-04 18:05:50 --> Helper loaded: url_helper
INFO - 2024-09-04 18:05:50 --> Helper loaded: file_helper
INFO - 2024-09-04 18:05:50 --> Helper loaded: security_helper
INFO - 2024-09-04 18:05:50 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:05:50 --> Database Driver Class Initialized
INFO - 2024-09-04 18:05:50 --> Email Class Initialized
DEBUG - 2024-09-04 18:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:05:50 --> Helper loaded: form_helper
INFO - 2024-09-04 18:05:50 --> Form Validation Class Initialized
INFO - 2024-09-04 18:05:50 --> Controller Class Initialized
INFO - 2024-09-04 18:05:50 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:05:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:05:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:05:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:05:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:05:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:05:50 --> Final output sent to browser
DEBUG - 2024-09-04 18:05:50 --> Total execution time: 0.1091
INFO - 2024-09-04 18:06:26 --> Config Class Initialized
INFO - 2024-09-04 18:06:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:06:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:06:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:06:26 --> URI Class Initialized
INFO - 2024-09-04 18:06:26 --> Router Class Initialized
INFO - 2024-09-04 18:06:26 --> Output Class Initialized
INFO - 2024-09-04 18:06:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:06:26 --> Input Class Initialized
INFO - 2024-09-04 18:06:26 --> Language Class Initialized
INFO - 2024-09-04 18:06:26 --> Loader Class Initialized
INFO - 2024-09-04 18:06:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:06:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:06:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:06:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:06:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:06:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:06:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:06:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:06:26 --> Controller Class Initialized
INFO - 2024-09-04 18:06:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:06:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:06:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:06:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:06:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:06:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:06:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:06:26 --> Total execution time: 0.1198
INFO - 2024-09-04 18:06:52 --> Config Class Initialized
INFO - 2024-09-04 18:06:52 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:06:52 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:06:52 --> Utf8 Class Initialized
INFO - 2024-09-04 18:06:52 --> URI Class Initialized
INFO - 2024-09-04 18:06:52 --> Router Class Initialized
INFO - 2024-09-04 18:06:52 --> Output Class Initialized
INFO - 2024-09-04 18:06:52 --> Security Class Initialized
DEBUG - 2024-09-04 18:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:06:52 --> Input Class Initialized
INFO - 2024-09-04 18:06:52 --> Language Class Initialized
INFO - 2024-09-04 18:06:52 --> Loader Class Initialized
INFO - 2024-09-04 18:06:52 --> Helper loaded: url_helper
INFO - 2024-09-04 18:06:52 --> Helper loaded: file_helper
INFO - 2024-09-04 18:06:52 --> Helper loaded: security_helper
INFO - 2024-09-04 18:06:52 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:06:52 --> Database Driver Class Initialized
INFO - 2024-09-04 18:06:52 --> Email Class Initialized
DEBUG - 2024-09-04 18:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:06:52 --> Helper loaded: form_helper
INFO - 2024-09-04 18:06:52 --> Form Validation Class Initialized
INFO - 2024-09-04 18:06:52 --> Controller Class Initialized
INFO - 2024-09-04 18:06:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:06:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:06:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:06:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:06:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:06:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:06:52 --> Final output sent to browser
DEBUG - 2024-09-04 18:06:52 --> Total execution time: 0.1075
INFO - 2024-09-04 18:06:59 --> Config Class Initialized
INFO - 2024-09-04 18:06:59 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:06:59 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:06:59 --> Utf8 Class Initialized
INFO - 2024-09-04 18:06:59 --> URI Class Initialized
INFO - 2024-09-04 18:06:59 --> Router Class Initialized
INFO - 2024-09-04 18:06:59 --> Output Class Initialized
INFO - 2024-09-04 18:06:59 --> Security Class Initialized
DEBUG - 2024-09-04 18:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:06:59 --> Input Class Initialized
INFO - 2024-09-04 18:06:59 --> Language Class Initialized
INFO - 2024-09-04 18:06:59 --> Loader Class Initialized
INFO - 2024-09-04 18:06:59 --> Helper loaded: url_helper
INFO - 2024-09-04 18:06:59 --> Helper loaded: file_helper
INFO - 2024-09-04 18:06:59 --> Helper loaded: security_helper
INFO - 2024-09-04 18:06:59 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:06:59 --> Database Driver Class Initialized
INFO - 2024-09-04 18:06:59 --> Email Class Initialized
DEBUG - 2024-09-04 18:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:06:59 --> Helper loaded: form_helper
INFO - 2024-09-04 18:06:59 --> Form Validation Class Initialized
INFO - 2024-09-04 18:06:59 --> Controller Class Initialized
INFO - 2024-09-04 18:06:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:06:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:06:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:06:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:06:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:06:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:06:59 --> Final output sent to browser
DEBUG - 2024-09-04 18:06:59 --> Total execution time: 0.0986
INFO - 2024-09-04 18:07:26 --> Config Class Initialized
INFO - 2024-09-04 18:07:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:07:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:07:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:07:26 --> URI Class Initialized
INFO - 2024-09-04 18:07:26 --> Router Class Initialized
INFO - 2024-09-04 18:07:26 --> Output Class Initialized
INFO - 2024-09-04 18:07:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:07:26 --> Input Class Initialized
INFO - 2024-09-04 18:07:26 --> Language Class Initialized
INFO - 2024-09-04 18:07:26 --> Loader Class Initialized
INFO - 2024-09-04 18:07:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:07:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:07:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:07:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:07:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:07:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:07:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:07:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:07:26 --> Controller Class Initialized
INFO - 2024-09-04 18:07:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:07:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:07:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:07:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:07:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:07:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:07:26 --> Total execution time: 0.1031
INFO - 2024-09-04 18:07:37 --> Config Class Initialized
INFO - 2024-09-04 18:07:37 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:07:37 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:07:37 --> Utf8 Class Initialized
INFO - 2024-09-04 18:07:37 --> URI Class Initialized
INFO - 2024-09-04 18:07:37 --> Router Class Initialized
INFO - 2024-09-04 18:07:37 --> Output Class Initialized
INFO - 2024-09-04 18:07:37 --> Security Class Initialized
DEBUG - 2024-09-04 18:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:07:37 --> Input Class Initialized
INFO - 2024-09-04 18:07:37 --> Language Class Initialized
INFO - 2024-09-04 18:07:37 --> Loader Class Initialized
INFO - 2024-09-04 18:07:37 --> Helper loaded: url_helper
INFO - 2024-09-04 18:07:37 --> Helper loaded: file_helper
INFO - 2024-09-04 18:07:37 --> Helper loaded: security_helper
INFO - 2024-09-04 18:07:37 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:07:37 --> Database Driver Class Initialized
INFO - 2024-09-04 18:07:37 --> Email Class Initialized
DEBUG - 2024-09-04 18:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:07:37 --> Helper loaded: form_helper
INFO - 2024-09-04 18:07:37 --> Form Validation Class Initialized
INFO - 2024-09-04 18:07:37 --> Controller Class Initialized
INFO - 2024-09-04 18:07:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:07:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:07:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:07:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:07:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:07:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:07:38 --> Final output sent to browser
DEBUG - 2024-09-04 18:07:38 --> Total execution time: 0.1061
INFO - 2024-09-04 18:07:42 --> Config Class Initialized
INFO - 2024-09-04 18:07:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:07:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:07:42 --> Utf8 Class Initialized
INFO - 2024-09-04 18:07:42 --> URI Class Initialized
INFO - 2024-09-04 18:07:42 --> Router Class Initialized
INFO - 2024-09-04 18:07:42 --> Output Class Initialized
INFO - 2024-09-04 18:07:42 --> Security Class Initialized
DEBUG - 2024-09-04 18:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:07:42 --> Input Class Initialized
INFO - 2024-09-04 18:07:42 --> Language Class Initialized
INFO - 2024-09-04 18:07:42 --> Loader Class Initialized
INFO - 2024-09-04 18:07:42 --> Helper loaded: url_helper
INFO - 2024-09-04 18:07:42 --> Helper loaded: file_helper
INFO - 2024-09-04 18:07:42 --> Helper loaded: security_helper
INFO - 2024-09-04 18:07:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:07:42 --> Database Driver Class Initialized
INFO - 2024-09-04 18:07:42 --> Email Class Initialized
DEBUG - 2024-09-04 18:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:07:42 --> Helper loaded: form_helper
INFO - 2024-09-04 18:07:42 --> Form Validation Class Initialized
INFO - 2024-09-04 18:07:42 --> Controller Class Initialized
INFO - 2024-09-04 18:07:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:07:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:07:42 --> Final output sent to browser
DEBUG - 2024-09-04 18:07:42 --> Total execution time: 0.1231
INFO - 2024-09-04 18:07:57 --> Config Class Initialized
INFO - 2024-09-04 18:07:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:07:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:07:57 --> Utf8 Class Initialized
INFO - 2024-09-04 18:07:57 --> URI Class Initialized
INFO - 2024-09-04 18:07:57 --> Router Class Initialized
INFO - 2024-09-04 18:07:57 --> Output Class Initialized
INFO - 2024-09-04 18:07:57 --> Security Class Initialized
DEBUG - 2024-09-04 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:07:57 --> Input Class Initialized
INFO - 2024-09-04 18:07:57 --> Language Class Initialized
INFO - 2024-09-04 18:07:57 --> Loader Class Initialized
INFO - 2024-09-04 18:07:57 --> Helper loaded: url_helper
INFO - 2024-09-04 18:07:57 --> Helper loaded: file_helper
INFO - 2024-09-04 18:07:57 --> Helper loaded: security_helper
INFO - 2024-09-04 18:07:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:07:57 --> Database Driver Class Initialized
INFO - 2024-09-04 18:07:57 --> Email Class Initialized
DEBUG - 2024-09-04 18:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:07:57 --> Helper loaded: form_helper
INFO - 2024-09-04 18:07:57 --> Form Validation Class Initialized
INFO - 2024-09-04 18:07:57 --> Controller Class Initialized
INFO - 2024-09-04 18:07:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:07:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:07:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:07:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:07:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:07:58 --> Final output sent to browser
DEBUG - 2024-09-04 18:07:58 --> Total execution time: 0.1219
INFO - 2024-09-04 18:08:09 --> Config Class Initialized
INFO - 2024-09-04 18:08:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:09 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:09 --> URI Class Initialized
INFO - 2024-09-04 18:08:09 --> Router Class Initialized
INFO - 2024-09-04 18:08:09 --> Output Class Initialized
INFO - 2024-09-04 18:08:09 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:09 --> Input Class Initialized
INFO - 2024-09-04 18:08:09 --> Language Class Initialized
INFO - 2024-09-04 18:08:09 --> Loader Class Initialized
INFO - 2024-09-04 18:08:09 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:09 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:09 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:09 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:09 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:09 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:09 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:09 --> Controller Class Initialized
INFO - 2024-09-04 18:08:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:09 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:09 --> Total execution time: 0.1245
INFO - 2024-09-04 18:08:15 --> Config Class Initialized
INFO - 2024-09-04 18:08:15 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:15 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:15 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:15 --> URI Class Initialized
INFO - 2024-09-04 18:08:15 --> Router Class Initialized
INFO - 2024-09-04 18:08:15 --> Output Class Initialized
INFO - 2024-09-04 18:08:15 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:15 --> Input Class Initialized
INFO - 2024-09-04 18:08:15 --> Language Class Initialized
INFO - 2024-09-04 18:08:15 --> Loader Class Initialized
INFO - 2024-09-04 18:08:15 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:15 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:15 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:15 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:15 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:15 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:15 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:15 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:15 --> Controller Class Initialized
INFO - 2024-09-04 18:08:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:16 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:16 --> Total execution time: 0.1507
INFO - 2024-09-04 18:08:24 --> Config Class Initialized
INFO - 2024-09-04 18:08:24 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:24 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:24 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:24 --> URI Class Initialized
INFO - 2024-09-04 18:08:24 --> Router Class Initialized
INFO - 2024-09-04 18:08:24 --> Output Class Initialized
INFO - 2024-09-04 18:08:24 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:24 --> Input Class Initialized
INFO - 2024-09-04 18:08:24 --> Language Class Initialized
INFO - 2024-09-04 18:08:24 --> Loader Class Initialized
INFO - 2024-09-04 18:08:24 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:24 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:24 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:24 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:24 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:24 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:24 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:24 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:24 --> Controller Class Initialized
INFO - 2024-09-04 18:08:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:24 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:24 --> Total execution time: 0.1143
INFO - 2024-09-04 18:08:31 --> Config Class Initialized
INFO - 2024-09-04 18:08:31 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:31 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:31 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:31 --> URI Class Initialized
INFO - 2024-09-04 18:08:31 --> Router Class Initialized
INFO - 2024-09-04 18:08:31 --> Output Class Initialized
INFO - 2024-09-04 18:08:31 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:31 --> Input Class Initialized
INFO - 2024-09-04 18:08:31 --> Language Class Initialized
INFO - 2024-09-04 18:08:31 --> Loader Class Initialized
INFO - 2024-09-04 18:08:31 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:31 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:31 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:31 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:31 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:31 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:31 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:31 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:31 --> Controller Class Initialized
INFO - 2024-09-04 18:08:31 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:31 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:31 --> Total execution time: 0.0925
INFO - 2024-09-04 18:08:38 --> Config Class Initialized
INFO - 2024-09-04 18:08:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:38 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:38 --> URI Class Initialized
INFO - 2024-09-04 18:08:38 --> Router Class Initialized
INFO - 2024-09-04 18:08:38 --> Output Class Initialized
INFO - 2024-09-04 18:08:38 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:38 --> Input Class Initialized
INFO - 2024-09-04 18:08:38 --> Language Class Initialized
INFO - 2024-09-04 18:08:38 --> Loader Class Initialized
INFO - 2024-09-04 18:08:38 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:38 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:38 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:38 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:38 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:38 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:38 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:38 --> Controller Class Initialized
INFO - 2024-09-04 18:08:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:38 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:38 --> Total execution time: 0.1089
INFO - 2024-09-04 18:08:45 --> Config Class Initialized
INFO - 2024-09-04 18:08:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:45 --> URI Class Initialized
INFO - 2024-09-04 18:08:45 --> Router Class Initialized
INFO - 2024-09-04 18:08:45 --> Output Class Initialized
INFO - 2024-09-04 18:08:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:45 --> Input Class Initialized
INFO - 2024-09-04 18:08:45 --> Language Class Initialized
INFO - 2024-09-04 18:08:45 --> Loader Class Initialized
INFO - 2024-09-04 18:08:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:45 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:45 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:45 --> Controller Class Initialized
INFO - 2024-09-04 18:08:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:45 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:45 --> Total execution time: 0.1247
INFO - 2024-09-04 18:08:50 --> Config Class Initialized
INFO - 2024-09-04 18:08:50 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:50 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:50 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:50 --> URI Class Initialized
INFO - 2024-09-04 18:08:50 --> Router Class Initialized
INFO - 2024-09-04 18:08:50 --> Output Class Initialized
INFO - 2024-09-04 18:08:50 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:50 --> Input Class Initialized
INFO - 2024-09-04 18:08:50 --> Language Class Initialized
INFO - 2024-09-04 18:08:50 --> Loader Class Initialized
INFO - 2024-09-04 18:08:50 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:50 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:50 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:50 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:50 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:50 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:50 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:50 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:50 --> Controller Class Initialized
INFO - 2024-09-04 18:08:50 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:50 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:50 --> Total execution time: 0.1074
INFO - 2024-09-04 18:08:54 --> Config Class Initialized
INFO - 2024-09-04 18:08:54 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:54 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:54 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:54 --> URI Class Initialized
INFO - 2024-09-04 18:08:54 --> Router Class Initialized
INFO - 2024-09-04 18:08:54 --> Output Class Initialized
INFO - 2024-09-04 18:08:54 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:54 --> Input Class Initialized
INFO - 2024-09-04 18:08:54 --> Language Class Initialized
INFO - 2024-09-04 18:08:54 --> Loader Class Initialized
INFO - 2024-09-04 18:08:54 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:54 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:54 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:54 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:54 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:54 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:54 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:54 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:54 --> Controller Class Initialized
INFO - 2024-09-04 18:08:54 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:54 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:54 --> Total execution time: 0.1071
INFO - 2024-09-04 18:08:58 --> Config Class Initialized
INFO - 2024-09-04 18:08:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:08:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:08:58 --> Utf8 Class Initialized
INFO - 2024-09-04 18:08:58 --> URI Class Initialized
INFO - 2024-09-04 18:08:58 --> Router Class Initialized
INFO - 2024-09-04 18:08:58 --> Output Class Initialized
INFO - 2024-09-04 18:08:58 --> Security Class Initialized
DEBUG - 2024-09-04 18:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:08:58 --> Input Class Initialized
INFO - 2024-09-04 18:08:58 --> Language Class Initialized
INFO - 2024-09-04 18:08:58 --> Loader Class Initialized
INFO - 2024-09-04 18:08:58 --> Helper loaded: url_helper
INFO - 2024-09-04 18:08:58 --> Helper loaded: file_helper
INFO - 2024-09-04 18:08:58 --> Helper loaded: security_helper
INFO - 2024-09-04 18:08:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:08:58 --> Database Driver Class Initialized
INFO - 2024-09-04 18:08:58 --> Email Class Initialized
DEBUG - 2024-09-04 18:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:08:58 --> Helper loaded: form_helper
INFO - 2024-09-04 18:08:58 --> Form Validation Class Initialized
INFO - 2024-09-04 18:08:58 --> Controller Class Initialized
INFO - 2024-09-04 18:08:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:08:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:08:58 --> Final output sent to browser
DEBUG - 2024-09-04 18:08:58 --> Total execution time: 0.1112
INFO - 2024-09-04 18:09:02 --> Config Class Initialized
INFO - 2024-09-04 18:09:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:09:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:09:02 --> Utf8 Class Initialized
INFO - 2024-09-04 18:09:02 --> URI Class Initialized
INFO - 2024-09-04 18:09:02 --> Router Class Initialized
INFO - 2024-09-04 18:09:02 --> Output Class Initialized
INFO - 2024-09-04 18:09:02 --> Security Class Initialized
DEBUG - 2024-09-04 18:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:09:02 --> Input Class Initialized
INFO - 2024-09-04 18:09:02 --> Language Class Initialized
INFO - 2024-09-04 18:09:02 --> Loader Class Initialized
INFO - 2024-09-04 18:09:02 --> Helper loaded: url_helper
INFO - 2024-09-04 18:09:02 --> Helper loaded: file_helper
INFO - 2024-09-04 18:09:02 --> Helper loaded: security_helper
INFO - 2024-09-04 18:09:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:09:02 --> Database Driver Class Initialized
INFO - 2024-09-04 18:09:02 --> Email Class Initialized
DEBUG - 2024-09-04 18:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:09:02 --> Helper loaded: form_helper
INFO - 2024-09-04 18:09:02 --> Form Validation Class Initialized
INFO - 2024-09-04 18:09:02 --> Controller Class Initialized
INFO - 2024-09-04 18:09:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:09:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:09:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:09:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:09:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:09:02 --> Final output sent to browser
DEBUG - 2024-09-04 18:09:02 --> Total execution time: 0.1116
INFO - 2024-09-04 18:10:17 --> Config Class Initialized
INFO - 2024-09-04 18:10:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:10:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:10:17 --> Utf8 Class Initialized
INFO - 2024-09-04 18:10:17 --> URI Class Initialized
INFO - 2024-09-04 18:10:17 --> Router Class Initialized
INFO - 2024-09-04 18:10:17 --> Output Class Initialized
INFO - 2024-09-04 18:10:17 --> Security Class Initialized
DEBUG - 2024-09-04 18:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:10:17 --> Input Class Initialized
INFO - 2024-09-04 18:10:17 --> Language Class Initialized
INFO - 2024-09-04 18:10:17 --> Loader Class Initialized
INFO - 2024-09-04 18:10:17 --> Helper loaded: url_helper
INFO - 2024-09-04 18:10:17 --> Helper loaded: file_helper
INFO - 2024-09-04 18:10:17 --> Helper loaded: security_helper
INFO - 2024-09-04 18:10:17 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:10:17 --> Database Driver Class Initialized
INFO - 2024-09-04 18:10:17 --> Email Class Initialized
DEBUG - 2024-09-04 18:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:10:17 --> Helper loaded: form_helper
INFO - 2024-09-04 18:10:17 --> Form Validation Class Initialized
INFO - 2024-09-04 18:10:17 --> Controller Class Initialized
INFO - 2024-09-04 18:10:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:10:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:10:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:10:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:10:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:10:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:10:17 --> Final output sent to browser
DEBUG - 2024-09-04 18:10:17 --> Total execution time: 0.1154
INFO - 2024-09-04 18:10:39 --> Config Class Initialized
INFO - 2024-09-04 18:10:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:10:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:10:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:10:39 --> URI Class Initialized
INFO - 2024-09-04 18:10:39 --> Router Class Initialized
INFO - 2024-09-04 18:10:39 --> Output Class Initialized
INFO - 2024-09-04 18:10:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:10:39 --> Input Class Initialized
INFO - 2024-09-04 18:10:39 --> Language Class Initialized
INFO - 2024-09-04 18:10:39 --> Loader Class Initialized
INFO - 2024-09-04 18:10:39 --> Helper loaded: url_helper
INFO - 2024-09-04 18:10:39 --> Helper loaded: file_helper
INFO - 2024-09-04 18:10:39 --> Helper loaded: security_helper
INFO - 2024-09-04 18:10:39 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:10:39 --> Database Driver Class Initialized
INFO - 2024-09-04 18:10:39 --> Email Class Initialized
DEBUG - 2024-09-04 18:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:10:39 --> Helper loaded: form_helper
INFO - 2024-09-04 18:10:39 --> Form Validation Class Initialized
INFO - 2024-09-04 18:10:39 --> Controller Class Initialized
INFO - 2024-09-04 18:10:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:10:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:10:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:10:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:10:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:10:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:10:39 --> Final output sent to browser
DEBUG - 2024-09-04 18:10:39 --> Total execution time: 0.1110
INFO - 2024-09-04 18:10:45 --> Config Class Initialized
INFO - 2024-09-04 18:10:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:10:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:10:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:10:45 --> URI Class Initialized
INFO - 2024-09-04 18:10:45 --> Router Class Initialized
INFO - 2024-09-04 18:10:45 --> Output Class Initialized
INFO - 2024-09-04 18:10:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:10:45 --> Input Class Initialized
INFO - 2024-09-04 18:10:45 --> Language Class Initialized
INFO - 2024-09-04 18:10:45 --> Loader Class Initialized
INFO - 2024-09-04 18:10:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:10:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:10:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:10:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:10:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:10:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:10:45 --> Helper loaded: form_helper
INFO - 2024-09-04 18:10:45 --> Form Validation Class Initialized
INFO - 2024-09-04 18:10:45 --> Controller Class Initialized
INFO - 2024-09-04 18:10:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:10:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:10:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:10:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:10:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:10:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:10:45 --> Final output sent to browser
DEBUG - 2024-09-04 18:10:45 --> Total execution time: 0.1130
INFO - 2024-09-04 18:11:05 --> Config Class Initialized
INFO - 2024-09-04 18:11:05 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:11:05 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:11:05 --> Utf8 Class Initialized
INFO - 2024-09-04 18:11:05 --> URI Class Initialized
INFO - 2024-09-04 18:11:05 --> Router Class Initialized
INFO - 2024-09-04 18:11:05 --> Output Class Initialized
INFO - 2024-09-04 18:11:05 --> Security Class Initialized
DEBUG - 2024-09-04 18:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:11:05 --> Input Class Initialized
INFO - 2024-09-04 18:11:05 --> Language Class Initialized
INFO - 2024-09-04 18:11:05 --> Loader Class Initialized
INFO - 2024-09-04 18:11:05 --> Helper loaded: url_helper
INFO - 2024-09-04 18:11:05 --> Helper loaded: file_helper
INFO - 2024-09-04 18:11:05 --> Helper loaded: security_helper
INFO - 2024-09-04 18:11:05 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:11:05 --> Database Driver Class Initialized
INFO - 2024-09-04 18:11:05 --> Email Class Initialized
DEBUG - 2024-09-04 18:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:11:05 --> Helper loaded: form_helper
INFO - 2024-09-04 18:11:05 --> Form Validation Class Initialized
INFO - 2024-09-04 18:11:05 --> Controller Class Initialized
INFO - 2024-09-04 18:11:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:11:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:11:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:11:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:11:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:11:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:11:05 --> Final output sent to browser
DEBUG - 2024-09-04 18:11:05 --> Total execution time: 0.1015
INFO - 2024-09-04 18:11:26 --> Config Class Initialized
INFO - 2024-09-04 18:11:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:11:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:11:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:11:26 --> URI Class Initialized
INFO - 2024-09-04 18:11:26 --> Router Class Initialized
INFO - 2024-09-04 18:11:26 --> Output Class Initialized
INFO - 2024-09-04 18:11:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:11:26 --> Input Class Initialized
INFO - 2024-09-04 18:11:26 --> Language Class Initialized
INFO - 2024-09-04 18:11:26 --> Loader Class Initialized
INFO - 2024-09-04 18:11:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:11:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:11:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:11:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:11:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:11:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:11:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:11:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:11:26 --> Controller Class Initialized
INFO - 2024-09-04 18:11:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:11:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:11:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:11:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:11:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:11:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:11:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:11:26 --> Total execution time: 0.1266
INFO - 2024-09-04 18:11:44 --> Config Class Initialized
INFO - 2024-09-04 18:11:44 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:11:44 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:11:44 --> Utf8 Class Initialized
INFO - 2024-09-04 18:11:44 --> URI Class Initialized
INFO - 2024-09-04 18:11:44 --> Router Class Initialized
INFO - 2024-09-04 18:11:44 --> Output Class Initialized
INFO - 2024-09-04 18:11:44 --> Security Class Initialized
DEBUG - 2024-09-04 18:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:11:44 --> Input Class Initialized
INFO - 2024-09-04 18:11:44 --> Language Class Initialized
INFO - 2024-09-04 18:11:44 --> Loader Class Initialized
INFO - 2024-09-04 18:11:44 --> Helper loaded: url_helper
INFO - 2024-09-04 18:11:44 --> Helper loaded: file_helper
INFO - 2024-09-04 18:11:44 --> Helper loaded: security_helper
INFO - 2024-09-04 18:11:44 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:11:44 --> Database Driver Class Initialized
INFO - 2024-09-04 18:11:44 --> Email Class Initialized
DEBUG - 2024-09-04 18:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:11:44 --> Helper loaded: form_helper
INFO - 2024-09-04 18:11:44 --> Form Validation Class Initialized
INFO - 2024-09-04 18:11:44 --> Controller Class Initialized
INFO - 2024-09-04 18:11:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:11:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:11:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:11:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:11:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:11:44 --> Final output sent to browser
DEBUG - 2024-09-04 18:11:44 --> Total execution time: 0.1342
INFO - 2024-09-04 18:12:10 --> Config Class Initialized
INFO - 2024-09-04 18:12:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:12:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:12:10 --> Utf8 Class Initialized
INFO - 2024-09-04 18:12:10 --> URI Class Initialized
INFO - 2024-09-04 18:12:10 --> Router Class Initialized
INFO - 2024-09-04 18:12:10 --> Output Class Initialized
INFO - 2024-09-04 18:12:10 --> Security Class Initialized
DEBUG - 2024-09-04 18:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:12:10 --> Input Class Initialized
INFO - 2024-09-04 18:12:10 --> Language Class Initialized
INFO - 2024-09-04 18:12:10 --> Loader Class Initialized
INFO - 2024-09-04 18:12:10 --> Helper loaded: url_helper
INFO - 2024-09-04 18:12:10 --> Helper loaded: file_helper
INFO - 2024-09-04 18:12:10 --> Helper loaded: security_helper
INFO - 2024-09-04 18:12:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:12:10 --> Database Driver Class Initialized
INFO - 2024-09-04 18:12:10 --> Email Class Initialized
DEBUG - 2024-09-04 18:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:12:10 --> Helper loaded: form_helper
INFO - 2024-09-04 18:12:10 --> Form Validation Class Initialized
INFO - 2024-09-04 18:12:10 --> Controller Class Initialized
INFO - 2024-09-04 18:12:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:12:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:12:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:12:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:12:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:12:10 --> Final output sent to browser
DEBUG - 2024-09-04 18:12:10 --> Total execution time: 0.1209
INFO - 2024-09-04 18:12:54 --> Config Class Initialized
INFO - 2024-09-04 18:12:54 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:12:54 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:12:54 --> Utf8 Class Initialized
INFO - 2024-09-04 18:12:54 --> URI Class Initialized
INFO - 2024-09-04 18:12:54 --> Router Class Initialized
INFO - 2024-09-04 18:12:54 --> Output Class Initialized
INFO - 2024-09-04 18:12:54 --> Security Class Initialized
DEBUG - 2024-09-04 18:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:12:54 --> Input Class Initialized
INFO - 2024-09-04 18:12:54 --> Language Class Initialized
INFO - 2024-09-04 18:12:54 --> Loader Class Initialized
INFO - 2024-09-04 18:12:54 --> Helper loaded: url_helper
INFO - 2024-09-04 18:12:54 --> Helper loaded: file_helper
INFO - 2024-09-04 18:12:54 --> Helper loaded: security_helper
INFO - 2024-09-04 18:12:54 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:12:54 --> Database Driver Class Initialized
INFO - 2024-09-04 18:12:54 --> Email Class Initialized
DEBUG - 2024-09-04 18:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:12:54 --> Helper loaded: form_helper
INFO - 2024-09-04 18:12:54 --> Form Validation Class Initialized
INFO - 2024-09-04 18:12:54 --> Controller Class Initialized
INFO - 2024-09-04 18:12:54 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:12:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:12:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:12:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:12:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:12:55 --> Final output sent to browser
DEBUG - 2024-09-04 18:12:55 --> Total execution time: 0.1246
INFO - 2024-09-04 18:12:58 --> Config Class Initialized
INFO - 2024-09-04 18:12:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:12:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:12:58 --> Utf8 Class Initialized
INFO - 2024-09-04 18:12:58 --> URI Class Initialized
INFO - 2024-09-04 18:12:58 --> Router Class Initialized
INFO - 2024-09-04 18:12:58 --> Output Class Initialized
INFO - 2024-09-04 18:12:58 --> Security Class Initialized
DEBUG - 2024-09-04 18:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:12:58 --> Input Class Initialized
INFO - 2024-09-04 18:12:58 --> Language Class Initialized
INFO - 2024-09-04 18:12:58 --> Loader Class Initialized
INFO - 2024-09-04 18:12:58 --> Helper loaded: url_helper
INFO - 2024-09-04 18:12:58 --> Helper loaded: file_helper
INFO - 2024-09-04 18:12:58 --> Helper loaded: security_helper
INFO - 2024-09-04 18:12:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:12:58 --> Database Driver Class Initialized
INFO - 2024-09-04 18:12:58 --> Email Class Initialized
DEBUG - 2024-09-04 18:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:12:58 --> Helper loaded: form_helper
INFO - 2024-09-04 18:12:58 --> Form Validation Class Initialized
INFO - 2024-09-04 18:12:58 --> Controller Class Initialized
INFO - 2024-09-04 18:12:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:12:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:12:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:12:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:12:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:12:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:12:58 --> Final output sent to browser
DEBUG - 2024-09-04 18:12:58 --> Total execution time: 0.1085
INFO - 2024-09-04 18:13:03 --> Config Class Initialized
INFO - 2024-09-04 18:13:03 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:03 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:03 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:03 --> URI Class Initialized
INFO - 2024-09-04 18:13:03 --> Router Class Initialized
INFO - 2024-09-04 18:13:03 --> Output Class Initialized
INFO - 2024-09-04 18:13:03 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:03 --> Input Class Initialized
INFO - 2024-09-04 18:13:03 --> Language Class Initialized
INFO - 2024-09-04 18:13:03 --> Loader Class Initialized
INFO - 2024-09-04 18:13:03 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:03 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:03 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:03 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:03 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:03 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:03 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:03 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:03 --> Controller Class Initialized
INFO - 2024-09-04 18:13:03 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:03 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:03 --> Total execution time: 0.1222
INFO - 2024-09-04 18:13:07 --> Config Class Initialized
INFO - 2024-09-04 18:13:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:07 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:07 --> URI Class Initialized
INFO - 2024-09-04 18:13:07 --> Router Class Initialized
INFO - 2024-09-04 18:13:07 --> Output Class Initialized
INFO - 2024-09-04 18:13:07 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:07 --> Input Class Initialized
INFO - 2024-09-04 18:13:07 --> Language Class Initialized
INFO - 2024-09-04 18:13:07 --> Loader Class Initialized
INFO - 2024-09-04 18:13:07 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:07 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:07 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:07 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:07 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:07 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:07 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:07 --> Controller Class Initialized
INFO - 2024-09-04 18:13:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:07 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:07 --> Total execution time: 0.1129
INFO - 2024-09-04 18:13:13 --> Config Class Initialized
INFO - 2024-09-04 18:13:13 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:13 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:13 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:13 --> URI Class Initialized
INFO - 2024-09-04 18:13:13 --> Router Class Initialized
INFO - 2024-09-04 18:13:13 --> Output Class Initialized
INFO - 2024-09-04 18:13:13 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:13 --> Input Class Initialized
INFO - 2024-09-04 18:13:13 --> Language Class Initialized
INFO - 2024-09-04 18:13:13 --> Loader Class Initialized
INFO - 2024-09-04 18:13:13 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:13 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:13 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:13 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:13 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:13 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:13 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:13 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:13 --> Controller Class Initialized
INFO - 2024-09-04 18:13:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:13 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:13 --> Total execution time: 0.1224
INFO - 2024-09-04 18:13:18 --> Config Class Initialized
INFO - 2024-09-04 18:13:18 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:18 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:18 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:18 --> URI Class Initialized
INFO - 2024-09-04 18:13:18 --> Router Class Initialized
INFO - 2024-09-04 18:13:18 --> Output Class Initialized
INFO - 2024-09-04 18:13:18 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:18 --> Input Class Initialized
INFO - 2024-09-04 18:13:18 --> Language Class Initialized
INFO - 2024-09-04 18:13:18 --> Loader Class Initialized
INFO - 2024-09-04 18:13:18 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:18 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:18 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:18 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:18 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:18 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:18 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:18 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:18 --> Controller Class Initialized
INFO - 2024-09-04 18:13:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:18 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:18 --> Total execution time: 0.2193
INFO - 2024-09-04 18:13:22 --> Config Class Initialized
INFO - 2024-09-04 18:13:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:22 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:22 --> URI Class Initialized
INFO - 2024-09-04 18:13:22 --> Router Class Initialized
INFO - 2024-09-04 18:13:22 --> Output Class Initialized
INFO - 2024-09-04 18:13:22 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:22 --> Input Class Initialized
INFO - 2024-09-04 18:13:22 --> Language Class Initialized
INFO - 2024-09-04 18:13:22 --> Loader Class Initialized
INFO - 2024-09-04 18:13:22 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:22 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:22 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:22 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:22 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:22 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:22 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:22 --> Controller Class Initialized
INFO - 2024-09-04 18:13:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:22 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:22 --> Total execution time: 0.1097
INFO - 2024-09-04 18:13:26 --> Config Class Initialized
INFO - 2024-09-04 18:13:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:26 --> URI Class Initialized
INFO - 2024-09-04 18:13:26 --> Router Class Initialized
INFO - 2024-09-04 18:13:26 --> Output Class Initialized
INFO - 2024-09-04 18:13:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:26 --> Input Class Initialized
INFO - 2024-09-04 18:13:26 --> Language Class Initialized
INFO - 2024-09-04 18:13:26 --> Loader Class Initialized
INFO - 2024-09-04 18:13:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:26 --> Controller Class Initialized
INFO - 2024-09-04 18:13:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:26 --> Total execution time: 0.1208
INFO - 2024-09-04 18:13:30 --> Config Class Initialized
INFO - 2024-09-04 18:13:30 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:30 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:30 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:30 --> URI Class Initialized
INFO - 2024-09-04 18:13:30 --> Router Class Initialized
INFO - 2024-09-04 18:13:31 --> Output Class Initialized
INFO - 2024-09-04 18:13:31 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:31 --> Input Class Initialized
INFO - 2024-09-04 18:13:31 --> Language Class Initialized
INFO - 2024-09-04 18:13:31 --> Loader Class Initialized
INFO - 2024-09-04 18:13:31 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:31 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:31 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:31 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:31 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:31 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:31 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:31 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:31 --> Controller Class Initialized
INFO - 2024-09-04 18:13:31 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:31 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:31 --> Total execution time: 0.1281
INFO - 2024-09-04 18:13:35 --> Config Class Initialized
INFO - 2024-09-04 18:13:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:35 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:35 --> URI Class Initialized
INFO - 2024-09-04 18:13:35 --> Router Class Initialized
INFO - 2024-09-04 18:13:35 --> Output Class Initialized
INFO - 2024-09-04 18:13:35 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:35 --> Input Class Initialized
INFO - 2024-09-04 18:13:35 --> Language Class Initialized
INFO - 2024-09-04 18:13:35 --> Loader Class Initialized
INFO - 2024-09-04 18:13:35 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:35 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:35 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:35 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:35 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:35 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:35 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:35 --> Controller Class Initialized
INFO - 2024-09-04 18:13:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:35 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:35 --> Total execution time: 0.1027
INFO - 2024-09-04 18:13:42 --> Config Class Initialized
INFO - 2024-09-04 18:13:42 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:42 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:42 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:42 --> URI Class Initialized
INFO - 2024-09-04 18:13:42 --> Router Class Initialized
INFO - 2024-09-04 18:13:42 --> Output Class Initialized
INFO - 2024-09-04 18:13:42 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:42 --> Input Class Initialized
INFO - 2024-09-04 18:13:42 --> Language Class Initialized
INFO - 2024-09-04 18:13:42 --> Loader Class Initialized
INFO - 2024-09-04 18:13:42 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:42 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:42 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:42 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:42 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:42 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:42 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:42 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:42 --> Controller Class Initialized
INFO - 2024-09-04 18:13:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:42 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:42 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:42 --> Total execution time: 0.1433
INFO - 2024-09-04 18:13:47 --> Config Class Initialized
INFO - 2024-09-04 18:13:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:13:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:13:47 --> Utf8 Class Initialized
INFO - 2024-09-04 18:13:47 --> URI Class Initialized
INFO - 2024-09-04 18:13:47 --> Router Class Initialized
INFO - 2024-09-04 18:13:47 --> Output Class Initialized
INFO - 2024-09-04 18:13:47 --> Security Class Initialized
DEBUG - 2024-09-04 18:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:13:47 --> Input Class Initialized
INFO - 2024-09-04 18:13:47 --> Language Class Initialized
INFO - 2024-09-04 18:13:47 --> Loader Class Initialized
INFO - 2024-09-04 18:13:47 --> Helper loaded: url_helper
INFO - 2024-09-04 18:13:47 --> Helper loaded: file_helper
INFO - 2024-09-04 18:13:47 --> Helper loaded: security_helper
INFO - 2024-09-04 18:13:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:13:47 --> Database Driver Class Initialized
INFO - 2024-09-04 18:13:47 --> Email Class Initialized
DEBUG - 2024-09-04 18:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:13:47 --> Helper loaded: form_helper
INFO - 2024-09-04 18:13:47 --> Form Validation Class Initialized
INFO - 2024-09-04 18:13:47 --> Controller Class Initialized
INFO - 2024-09-04 18:13:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:13:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:13:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:13:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:13:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:13:47 --> Final output sent to browser
DEBUG - 2024-09-04 18:13:47 --> Total execution time: 0.1384
INFO - 2024-09-04 18:14:02 --> Config Class Initialized
INFO - 2024-09-04 18:14:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:02 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:02 --> URI Class Initialized
INFO - 2024-09-04 18:14:02 --> Router Class Initialized
INFO - 2024-09-04 18:14:02 --> Output Class Initialized
INFO - 2024-09-04 18:14:02 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:02 --> Input Class Initialized
INFO - 2024-09-04 18:14:02 --> Language Class Initialized
INFO - 2024-09-04 18:14:02 --> Loader Class Initialized
INFO - 2024-09-04 18:14:02 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:02 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:02 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:02 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:02 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:02 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:02 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:02 --> Controller Class Initialized
INFO - 2024-09-04 18:14:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:02 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:02 --> Total execution time: 0.1352
INFO - 2024-09-04 18:14:06 --> Config Class Initialized
INFO - 2024-09-04 18:14:06 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:06 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:06 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:06 --> URI Class Initialized
INFO - 2024-09-04 18:14:06 --> Router Class Initialized
INFO - 2024-09-04 18:14:06 --> Output Class Initialized
INFO - 2024-09-04 18:14:06 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:06 --> Input Class Initialized
INFO - 2024-09-04 18:14:06 --> Language Class Initialized
INFO - 2024-09-04 18:14:06 --> Loader Class Initialized
INFO - 2024-09-04 18:14:06 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:06 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:06 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:06 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:06 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:06 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:06 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:06 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:06 --> Controller Class Initialized
INFO - 2024-09-04 18:14:06 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:06 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:06 --> Total execution time: 0.1163
INFO - 2024-09-04 18:14:10 --> Config Class Initialized
INFO - 2024-09-04 18:14:10 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:10 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:10 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:10 --> URI Class Initialized
INFO - 2024-09-04 18:14:10 --> Router Class Initialized
INFO - 2024-09-04 18:14:10 --> Output Class Initialized
INFO - 2024-09-04 18:14:10 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:10 --> Input Class Initialized
INFO - 2024-09-04 18:14:10 --> Language Class Initialized
INFO - 2024-09-04 18:14:10 --> Loader Class Initialized
INFO - 2024-09-04 18:14:10 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:10 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:10 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:10 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:10 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:10 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:10 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:10 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:10 --> Controller Class Initialized
INFO - 2024-09-04 18:14:10 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:10 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:10 --> Total execution time: 0.1100
INFO - 2024-09-04 18:14:39 --> Config Class Initialized
INFO - 2024-09-04 18:14:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:39 --> URI Class Initialized
INFO - 2024-09-04 18:14:39 --> Router Class Initialized
INFO - 2024-09-04 18:14:39 --> Output Class Initialized
INFO - 2024-09-04 18:14:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:39 --> Input Class Initialized
INFO - 2024-09-04 18:14:39 --> Language Class Initialized
ERROR - 2024-09-04 18:14:39 --> 404 Page Not Found: Data/antrol
INFO - 2024-09-04 18:14:39 --> Config Class Initialized
INFO - 2024-09-04 18:14:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:39 --> URI Class Initialized
INFO - 2024-09-04 18:14:39 --> Router Class Initialized
INFO - 2024-09-04 18:14:39 --> Output Class Initialized
INFO - 2024-09-04 18:14:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:39 --> Input Class Initialized
INFO - 2024-09-04 18:14:39 --> Language Class Initialized
ERROR - 2024-09-04 18:14:39 --> 404 Page Not Found: Data/antrol
INFO - 2024-09-04 18:14:41 --> Config Class Initialized
INFO - 2024-09-04 18:14:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:41 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:41 --> URI Class Initialized
INFO - 2024-09-04 18:14:41 --> Router Class Initialized
INFO - 2024-09-04 18:14:41 --> Output Class Initialized
INFO - 2024-09-04 18:14:41 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:41 --> Input Class Initialized
INFO - 2024-09-04 18:14:41 --> Language Class Initialized
INFO - 2024-09-04 18:14:41 --> Loader Class Initialized
INFO - 2024-09-04 18:14:41 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:41 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:41 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:41 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:41 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:41 --> Controller Class Initialized
INFO - 2024-09-04 18:14:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:41 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:41 --> Total execution time: 0.0983
INFO - 2024-09-04 18:14:41 --> Config Class Initialized
INFO - 2024-09-04 18:14:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:41 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:41 --> URI Class Initialized
INFO - 2024-09-04 18:14:41 --> Router Class Initialized
INFO - 2024-09-04 18:14:41 --> Output Class Initialized
INFO - 2024-09-04 18:14:41 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:41 --> Input Class Initialized
INFO - 2024-09-04 18:14:41 --> Language Class Initialized
INFO - 2024-09-04 18:14:41 --> Loader Class Initialized
INFO - 2024-09-04 18:14:41 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:41 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:41 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:41 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:41 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:41 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:41 --> Controller Class Initialized
INFO - 2024-09-04 18:14:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:41 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:41 --> Total execution time: 0.0718
INFO - 2024-09-04 18:14:43 --> Config Class Initialized
INFO - 2024-09-04 18:14:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:43 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:43 --> URI Class Initialized
INFO - 2024-09-04 18:14:43 --> Router Class Initialized
INFO - 2024-09-04 18:14:43 --> Output Class Initialized
INFO - 2024-09-04 18:14:43 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:43 --> Input Class Initialized
INFO - 2024-09-04 18:14:43 --> Language Class Initialized
ERROR - 2024-09-04 18:14:43 --> 404 Page Not Found: Data/antrol
INFO - 2024-09-04 18:14:45 --> Config Class Initialized
INFO - 2024-09-04 18:14:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:45 --> URI Class Initialized
INFO - 2024-09-04 18:14:45 --> Router Class Initialized
INFO - 2024-09-04 18:14:45 --> Output Class Initialized
INFO - 2024-09-04 18:14:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:45 --> Input Class Initialized
INFO - 2024-09-04 18:14:45 --> Language Class Initialized
INFO - 2024-09-04 18:14:45 --> Loader Class Initialized
INFO - 2024-09-04 18:14:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:45 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:45 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:45 --> Controller Class Initialized
INFO - 2024-09-04 18:14:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:45 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:45 --> Total execution time: 0.0712
INFO - 2024-09-04 18:14:54 --> Config Class Initialized
INFO - 2024-09-04 18:14:54 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:54 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:54 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:54 --> URI Class Initialized
INFO - 2024-09-04 18:14:54 --> Router Class Initialized
INFO - 2024-09-04 18:14:54 --> Output Class Initialized
INFO - 2024-09-04 18:14:54 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:54 --> Input Class Initialized
INFO - 2024-09-04 18:14:54 --> Language Class Initialized
INFO - 2024-09-04 18:14:54 --> Loader Class Initialized
INFO - 2024-09-04 18:14:54 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:54 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:54 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:54 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:54 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:54 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:54 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:54 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:54 --> Controller Class Initialized
INFO - 2024-09-04 18:14:54 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:54 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:54 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:54 --> Total execution time: 0.1472
INFO - 2024-09-04 18:14:55 --> Config Class Initialized
INFO - 2024-09-04 18:14:55 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:14:55 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:14:55 --> Utf8 Class Initialized
INFO - 2024-09-04 18:14:55 --> URI Class Initialized
INFO - 2024-09-04 18:14:55 --> Router Class Initialized
INFO - 2024-09-04 18:14:55 --> Output Class Initialized
INFO - 2024-09-04 18:14:55 --> Security Class Initialized
DEBUG - 2024-09-04 18:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:14:55 --> Input Class Initialized
INFO - 2024-09-04 18:14:55 --> Language Class Initialized
INFO - 2024-09-04 18:14:55 --> Loader Class Initialized
INFO - 2024-09-04 18:14:55 --> Helper loaded: url_helper
INFO - 2024-09-04 18:14:55 --> Helper loaded: file_helper
INFO - 2024-09-04 18:14:55 --> Helper loaded: security_helper
INFO - 2024-09-04 18:14:55 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:14:55 --> Database Driver Class Initialized
INFO - 2024-09-04 18:14:55 --> Email Class Initialized
DEBUG - 2024-09-04 18:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:14:55 --> Helper loaded: form_helper
INFO - 2024-09-04 18:14:55 --> Form Validation Class Initialized
INFO - 2024-09-04 18:14:55 --> Controller Class Initialized
INFO - 2024-09-04 18:14:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:14:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:14:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:14:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:14:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:14:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:14:55 --> Final output sent to browser
DEBUG - 2024-09-04 18:14:55 --> Total execution time: 0.0798
INFO - 2024-09-04 18:15:08 --> Config Class Initialized
INFO - 2024-09-04 18:15:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:08 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:08 --> URI Class Initialized
INFO - 2024-09-04 18:15:08 --> Router Class Initialized
INFO - 2024-09-04 18:15:08 --> Output Class Initialized
INFO - 2024-09-04 18:15:08 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:08 --> Input Class Initialized
INFO - 2024-09-04 18:15:08 --> Language Class Initialized
INFO - 2024-09-04 18:15:08 --> Loader Class Initialized
INFO - 2024-09-04 18:15:08 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:08 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:08 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:08 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:08 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:08 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:08 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:08 --> Controller Class Initialized
INFO - 2024-09-04 18:15:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:15:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:08 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:08 --> Total execution time: 0.1016
INFO - 2024-09-04 18:15:16 --> Config Class Initialized
INFO - 2024-09-04 18:15:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:16 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:16 --> URI Class Initialized
INFO - 2024-09-04 18:15:16 --> Router Class Initialized
INFO - 2024-09-04 18:15:16 --> Output Class Initialized
INFO - 2024-09-04 18:15:16 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:16 --> Input Class Initialized
INFO - 2024-09-04 18:15:16 --> Language Class Initialized
INFO - 2024-09-04 18:15:16 --> Loader Class Initialized
INFO - 2024-09-04 18:15:16 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:16 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:16 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:16 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:16 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:16 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:16 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:16 --> Controller Class Initialized
INFO - 2024-09-04 18:15:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:15:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:16 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:16 --> Total execution time: 0.1240
INFO - 2024-09-04 18:15:33 --> Config Class Initialized
INFO - 2024-09-04 18:15:33 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:33 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:33 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:33 --> URI Class Initialized
INFO - 2024-09-04 18:15:33 --> Router Class Initialized
INFO - 2024-09-04 18:15:33 --> Output Class Initialized
INFO - 2024-09-04 18:15:33 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:33 --> Input Class Initialized
INFO - 2024-09-04 18:15:33 --> Language Class Initialized
INFO - 2024-09-04 18:15:33 --> Loader Class Initialized
INFO - 2024-09-04 18:15:33 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:33 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:33 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:33 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:33 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:33 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:33 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:33 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:33 --> Controller Class Initialized
INFO - 2024-09-04 18:15:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:15:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:33 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:33 --> Total execution time: 0.0944
INFO - 2024-09-04 18:15:36 --> Config Class Initialized
INFO - 2024-09-04 18:15:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:36 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:36 --> URI Class Initialized
INFO - 2024-09-04 18:15:36 --> Router Class Initialized
INFO - 2024-09-04 18:15:36 --> Output Class Initialized
INFO - 2024-09-04 18:15:36 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:36 --> Input Class Initialized
INFO - 2024-09-04 18:15:36 --> Language Class Initialized
INFO - 2024-09-04 18:15:36 --> Loader Class Initialized
INFO - 2024-09-04 18:15:36 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:36 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:36 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:36 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:36 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:36 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:36 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:36 --> Controller Class Initialized
INFO - 2024-09-04 18:15:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:15:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:36 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:36 --> Total execution time: 0.0792
INFO - 2024-09-04 18:15:38 --> Config Class Initialized
INFO - 2024-09-04 18:15:38 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:38 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:38 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:38 --> URI Class Initialized
INFO - 2024-09-04 18:15:38 --> Router Class Initialized
INFO - 2024-09-04 18:15:38 --> Output Class Initialized
INFO - 2024-09-04 18:15:38 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:38 --> Input Class Initialized
INFO - 2024-09-04 18:15:38 --> Language Class Initialized
INFO - 2024-09-04 18:15:38 --> Loader Class Initialized
INFO - 2024-09-04 18:15:38 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:38 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:38 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:38 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:38 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:38 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:38 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:38 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:38 --> Controller Class Initialized
INFO - 2024-09-04 18:15:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:15:38 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:38 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:38 --> Total execution time: 0.0780
INFO - 2024-09-04 18:15:47 --> Config Class Initialized
INFO - 2024-09-04 18:15:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:15:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:15:47 --> Utf8 Class Initialized
INFO - 2024-09-04 18:15:47 --> URI Class Initialized
INFO - 2024-09-04 18:15:47 --> Router Class Initialized
INFO - 2024-09-04 18:15:47 --> Output Class Initialized
INFO - 2024-09-04 18:15:47 --> Security Class Initialized
DEBUG - 2024-09-04 18:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:15:47 --> Input Class Initialized
INFO - 2024-09-04 18:15:47 --> Language Class Initialized
INFO - 2024-09-04 18:15:47 --> Loader Class Initialized
INFO - 2024-09-04 18:15:47 --> Helper loaded: url_helper
INFO - 2024-09-04 18:15:47 --> Helper loaded: file_helper
INFO - 2024-09-04 18:15:47 --> Helper loaded: security_helper
INFO - 2024-09-04 18:15:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:15:47 --> Database Driver Class Initialized
INFO - 2024-09-04 18:15:47 --> Email Class Initialized
DEBUG - 2024-09-04 18:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:15:47 --> Helper loaded: form_helper
INFO - 2024-09-04 18:15:47 --> Form Validation Class Initialized
INFO - 2024-09-04 18:15:47 --> Controller Class Initialized
INFO - 2024-09-04 18:15:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:15:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:15:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:15:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:15:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:15:47 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:15:47 --> Final output sent to browser
DEBUG - 2024-09-04 18:15:47 --> Total execution time: 0.0660
INFO - 2024-09-04 18:16:44 --> Config Class Initialized
INFO - 2024-09-04 18:16:44 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:16:44 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:16:44 --> Utf8 Class Initialized
INFO - 2024-09-04 18:16:44 --> URI Class Initialized
INFO - 2024-09-04 18:16:44 --> Router Class Initialized
INFO - 2024-09-04 18:16:44 --> Output Class Initialized
INFO - 2024-09-04 18:16:44 --> Security Class Initialized
DEBUG - 2024-09-04 18:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:16:44 --> Input Class Initialized
INFO - 2024-09-04 18:16:44 --> Language Class Initialized
INFO - 2024-09-04 18:16:44 --> Loader Class Initialized
INFO - 2024-09-04 18:16:44 --> Helper loaded: url_helper
INFO - 2024-09-04 18:16:44 --> Helper loaded: file_helper
INFO - 2024-09-04 18:16:44 --> Helper loaded: security_helper
INFO - 2024-09-04 18:16:44 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:16:44 --> Database Driver Class Initialized
INFO - 2024-09-04 18:16:44 --> Email Class Initialized
DEBUG - 2024-09-04 18:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:16:44 --> Helper loaded: form_helper
INFO - 2024-09-04 18:16:44 --> Form Validation Class Initialized
INFO - 2024-09-04 18:16:44 --> Controller Class Initialized
INFO - 2024-09-04 18:16:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:16:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:16:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:16:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:16:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:16:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:16:44 --> Final output sent to browser
DEBUG - 2024-09-04 18:16:44 --> Total execution time: 0.1384
INFO - 2024-09-04 18:16:49 --> Config Class Initialized
INFO - 2024-09-04 18:16:49 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:16:49 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:16:49 --> Utf8 Class Initialized
INFO - 2024-09-04 18:16:49 --> URI Class Initialized
INFO - 2024-09-04 18:16:49 --> Router Class Initialized
INFO - 2024-09-04 18:16:49 --> Output Class Initialized
INFO - 2024-09-04 18:16:49 --> Security Class Initialized
DEBUG - 2024-09-04 18:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:16:49 --> Input Class Initialized
INFO - 2024-09-04 18:16:49 --> Language Class Initialized
INFO - 2024-09-04 18:16:49 --> Loader Class Initialized
INFO - 2024-09-04 18:16:49 --> Helper loaded: url_helper
INFO - 2024-09-04 18:16:49 --> Helper loaded: file_helper
INFO - 2024-09-04 18:16:49 --> Helper loaded: security_helper
INFO - 2024-09-04 18:16:49 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:16:49 --> Database Driver Class Initialized
INFO - 2024-09-04 18:16:49 --> Email Class Initialized
DEBUG - 2024-09-04 18:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:16:49 --> Helper loaded: form_helper
INFO - 2024-09-04 18:16:49 --> Form Validation Class Initialized
INFO - 2024-09-04 18:16:49 --> Controller Class Initialized
INFO - 2024-09-04 18:16:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:16:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:16:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:16:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:16:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:16:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:16:49 --> Final output sent to browser
DEBUG - 2024-09-04 18:16:49 --> Total execution time: 0.1281
INFO - 2024-09-04 18:17:16 --> Config Class Initialized
INFO - 2024-09-04 18:17:16 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:17:16 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:17:16 --> Utf8 Class Initialized
INFO - 2024-09-04 18:17:16 --> URI Class Initialized
INFO - 2024-09-04 18:17:16 --> Router Class Initialized
INFO - 2024-09-04 18:17:16 --> Output Class Initialized
INFO - 2024-09-04 18:17:16 --> Security Class Initialized
DEBUG - 2024-09-04 18:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:17:16 --> Input Class Initialized
INFO - 2024-09-04 18:17:16 --> Language Class Initialized
INFO - 2024-09-04 18:17:16 --> Loader Class Initialized
INFO - 2024-09-04 18:17:16 --> Helper loaded: url_helper
INFO - 2024-09-04 18:17:16 --> Helper loaded: file_helper
INFO - 2024-09-04 18:17:16 --> Helper loaded: security_helper
INFO - 2024-09-04 18:17:16 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:17:16 --> Database Driver Class Initialized
INFO - 2024-09-04 18:17:16 --> Email Class Initialized
DEBUG - 2024-09-04 18:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:17:16 --> Helper loaded: form_helper
INFO - 2024-09-04 18:17:16 --> Form Validation Class Initialized
INFO - 2024-09-04 18:17:16 --> Controller Class Initialized
INFO - 2024-09-04 18:17:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:17:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:17:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:17:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:17:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:17:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:17:16 --> Final output sent to browser
DEBUG - 2024-09-04 18:17:16 --> Total execution time: 0.1127
INFO - 2024-09-04 18:17:23 --> Config Class Initialized
INFO - 2024-09-04 18:17:23 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:17:23 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:17:23 --> Utf8 Class Initialized
INFO - 2024-09-04 18:17:23 --> URI Class Initialized
INFO - 2024-09-04 18:17:23 --> Router Class Initialized
INFO - 2024-09-04 18:17:23 --> Output Class Initialized
INFO - 2024-09-04 18:17:23 --> Security Class Initialized
DEBUG - 2024-09-04 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:17:23 --> Input Class Initialized
INFO - 2024-09-04 18:17:23 --> Language Class Initialized
INFO - 2024-09-04 18:17:23 --> Loader Class Initialized
INFO - 2024-09-04 18:17:23 --> Helper loaded: url_helper
INFO - 2024-09-04 18:17:23 --> Helper loaded: file_helper
INFO - 2024-09-04 18:17:23 --> Helper loaded: security_helper
INFO - 2024-09-04 18:17:23 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:17:23 --> Database Driver Class Initialized
INFO - 2024-09-04 18:17:23 --> Email Class Initialized
DEBUG - 2024-09-04 18:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:17:23 --> Helper loaded: form_helper
INFO - 2024-09-04 18:17:23 --> Form Validation Class Initialized
INFO - 2024-09-04 18:17:23 --> Controller Class Initialized
INFO - 2024-09-04 18:17:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:17:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:17:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:17:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:17:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:17:23 --> Final output sent to browser
DEBUG - 2024-09-04 18:17:23 --> Total execution time: 0.1182
INFO - 2024-09-04 18:17:27 --> Config Class Initialized
INFO - 2024-09-04 18:17:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:17:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:17:27 --> Utf8 Class Initialized
INFO - 2024-09-04 18:17:27 --> URI Class Initialized
INFO - 2024-09-04 18:17:27 --> Router Class Initialized
INFO - 2024-09-04 18:17:27 --> Output Class Initialized
INFO - 2024-09-04 18:17:27 --> Security Class Initialized
DEBUG - 2024-09-04 18:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:17:27 --> Input Class Initialized
INFO - 2024-09-04 18:17:27 --> Language Class Initialized
INFO - 2024-09-04 18:17:27 --> Loader Class Initialized
INFO - 2024-09-04 18:17:27 --> Helper loaded: url_helper
INFO - 2024-09-04 18:17:27 --> Helper loaded: file_helper
INFO - 2024-09-04 18:17:27 --> Helper loaded: security_helper
INFO - 2024-09-04 18:17:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:17:27 --> Database Driver Class Initialized
INFO - 2024-09-04 18:17:27 --> Email Class Initialized
DEBUG - 2024-09-04 18:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:17:27 --> Helper loaded: form_helper
INFO - 2024-09-04 18:17:27 --> Form Validation Class Initialized
INFO - 2024-09-04 18:17:27 --> Controller Class Initialized
INFO - 2024-09-04 18:17:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:17:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:17:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:17:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:17:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:17:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:17:27 --> Final output sent to browser
DEBUG - 2024-09-04 18:17:27 --> Total execution time: 0.1292
INFO - 2024-09-04 18:17:57 --> Config Class Initialized
INFO - 2024-09-04 18:17:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:17:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:17:57 --> Utf8 Class Initialized
INFO - 2024-09-04 18:17:57 --> URI Class Initialized
INFO - 2024-09-04 18:17:57 --> Router Class Initialized
INFO - 2024-09-04 18:17:57 --> Output Class Initialized
INFO - 2024-09-04 18:17:57 --> Security Class Initialized
DEBUG - 2024-09-04 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:17:57 --> Input Class Initialized
INFO - 2024-09-04 18:17:57 --> Language Class Initialized
INFO - 2024-09-04 18:17:57 --> Loader Class Initialized
INFO - 2024-09-04 18:17:57 --> Helper loaded: url_helper
INFO - 2024-09-04 18:17:57 --> Helper loaded: file_helper
INFO - 2024-09-04 18:17:57 --> Helper loaded: security_helper
INFO - 2024-09-04 18:17:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:17:57 --> Database Driver Class Initialized
INFO - 2024-09-04 18:17:57 --> Email Class Initialized
DEBUG - 2024-09-04 18:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:17:57 --> Helper loaded: form_helper
INFO - 2024-09-04 18:17:57 --> Form Validation Class Initialized
INFO - 2024-09-04 18:17:57 --> Controller Class Initialized
INFO - 2024-09-04 18:17:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:17:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:17:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:17:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:17:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:17:57 --> Final output sent to browser
DEBUG - 2024-09-04 18:17:57 --> Total execution time: 0.1181
INFO - 2024-09-04 18:18:05 --> Config Class Initialized
INFO - 2024-09-04 18:18:05 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:05 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:05 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:05 --> URI Class Initialized
INFO - 2024-09-04 18:18:05 --> Router Class Initialized
INFO - 2024-09-04 18:18:05 --> Output Class Initialized
INFO - 2024-09-04 18:18:05 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:05 --> Input Class Initialized
INFO - 2024-09-04 18:18:05 --> Language Class Initialized
INFO - 2024-09-04 18:18:05 --> Loader Class Initialized
INFO - 2024-09-04 18:18:05 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:05 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:05 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:05 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:05 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:05 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:05 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:05 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:05 --> Controller Class Initialized
INFO - 2024-09-04 18:18:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:05 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:05 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:05 --> Total execution time: 0.1519
INFO - 2024-09-04 18:18:09 --> Config Class Initialized
INFO - 2024-09-04 18:18:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:09 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:09 --> URI Class Initialized
INFO - 2024-09-04 18:18:09 --> Router Class Initialized
INFO - 2024-09-04 18:18:09 --> Output Class Initialized
INFO - 2024-09-04 18:18:09 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:09 --> Input Class Initialized
INFO - 2024-09-04 18:18:09 --> Language Class Initialized
INFO - 2024-09-04 18:18:09 --> Loader Class Initialized
INFO - 2024-09-04 18:18:09 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:09 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:09 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:09 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:09 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:09 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:09 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:09 --> Controller Class Initialized
INFO - 2024-09-04 18:18:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:09 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:09 --> Total execution time: 0.1018
INFO - 2024-09-04 18:18:18 --> Config Class Initialized
INFO - 2024-09-04 18:18:18 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:18 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:18 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:18 --> URI Class Initialized
INFO - 2024-09-04 18:18:18 --> Router Class Initialized
INFO - 2024-09-04 18:18:18 --> Output Class Initialized
INFO - 2024-09-04 18:18:18 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:18 --> Input Class Initialized
INFO - 2024-09-04 18:18:18 --> Language Class Initialized
INFO - 2024-09-04 18:18:18 --> Loader Class Initialized
INFO - 2024-09-04 18:18:18 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:18 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:18 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:18 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:18 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:18 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:18 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:18 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:18 --> Controller Class Initialized
INFO - 2024-09-04 18:18:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:18 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:18 --> Total execution time: 0.0965
INFO - 2024-09-04 18:18:23 --> Config Class Initialized
INFO - 2024-09-04 18:18:23 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:23 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:23 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:23 --> URI Class Initialized
INFO - 2024-09-04 18:18:23 --> Router Class Initialized
INFO - 2024-09-04 18:18:23 --> Output Class Initialized
INFO - 2024-09-04 18:18:23 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:23 --> Input Class Initialized
INFO - 2024-09-04 18:18:23 --> Language Class Initialized
INFO - 2024-09-04 18:18:23 --> Loader Class Initialized
INFO - 2024-09-04 18:18:23 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:23 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:23 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:23 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:23 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:23 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:23 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:23 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:23 --> Controller Class Initialized
INFO - 2024-09-04 18:18:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:23 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:23 --> Total execution time: 0.1274
INFO - 2024-09-04 18:18:45 --> Config Class Initialized
INFO - 2024-09-04 18:18:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:45 --> URI Class Initialized
INFO - 2024-09-04 18:18:45 --> Router Class Initialized
INFO - 2024-09-04 18:18:45 --> Output Class Initialized
INFO - 2024-09-04 18:18:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:45 --> Input Class Initialized
INFO - 2024-09-04 18:18:45 --> Language Class Initialized
INFO - 2024-09-04 18:18:45 --> Loader Class Initialized
INFO - 2024-09-04 18:18:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:45 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:45 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:45 --> Controller Class Initialized
INFO - 2024-09-04 18:18:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:46 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:46 --> Total execution time: 0.1348
INFO - 2024-09-04 18:18:50 --> Config Class Initialized
INFO - 2024-09-04 18:18:50 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:50 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:50 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:50 --> URI Class Initialized
INFO - 2024-09-04 18:18:50 --> Router Class Initialized
INFO - 2024-09-04 18:18:50 --> Output Class Initialized
INFO - 2024-09-04 18:18:50 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:50 --> Input Class Initialized
INFO - 2024-09-04 18:18:50 --> Language Class Initialized
INFO - 2024-09-04 18:18:50 --> Loader Class Initialized
INFO - 2024-09-04 18:18:50 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:51 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:51 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:51 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:51 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:51 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:51 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:51 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:51 --> Controller Class Initialized
INFO - 2024-09-04 18:18:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:51 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:51 --> Total execution time: 0.1470
INFO - 2024-09-04 18:18:57 --> Config Class Initialized
INFO - 2024-09-04 18:18:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:18:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:18:57 --> Utf8 Class Initialized
INFO - 2024-09-04 18:18:57 --> URI Class Initialized
INFO - 2024-09-04 18:18:57 --> Router Class Initialized
INFO - 2024-09-04 18:18:57 --> Output Class Initialized
INFO - 2024-09-04 18:18:57 --> Security Class Initialized
DEBUG - 2024-09-04 18:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:18:57 --> Input Class Initialized
INFO - 2024-09-04 18:18:57 --> Language Class Initialized
INFO - 2024-09-04 18:18:57 --> Loader Class Initialized
INFO - 2024-09-04 18:18:57 --> Helper loaded: url_helper
INFO - 2024-09-04 18:18:57 --> Helper loaded: file_helper
INFO - 2024-09-04 18:18:57 --> Helper loaded: security_helper
INFO - 2024-09-04 18:18:57 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:18:57 --> Database Driver Class Initialized
INFO - 2024-09-04 18:18:57 --> Email Class Initialized
DEBUG - 2024-09-04 18:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:18:57 --> Helper loaded: form_helper
INFO - 2024-09-04 18:18:57 --> Form Validation Class Initialized
INFO - 2024-09-04 18:18:57 --> Controller Class Initialized
INFO - 2024-09-04 18:18:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:18:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:18:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:18:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:18:57 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:18:57 --> Final output sent to browser
DEBUG - 2024-09-04 18:18:57 --> Total execution time: 0.1053
INFO - 2024-09-04 18:19:02 --> Config Class Initialized
INFO - 2024-09-04 18:19:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:19:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:19:02 --> Utf8 Class Initialized
INFO - 2024-09-04 18:19:02 --> URI Class Initialized
INFO - 2024-09-04 18:19:02 --> Router Class Initialized
INFO - 2024-09-04 18:19:02 --> Output Class Initialized
INFO - 2024-09-04 18:19:02 --> Security Class Initialized
DEBUG - 2024-09-04 18:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:19:02 --> Input Class Initialized
INFO - 2024-09-04 18:19:02 --> Language Class Initialized
INFO - 2024-09-04 18:19:02 --> Loader Class Initialized
INFO - 2024-09-04 18:19:02 --> Helper loaded: url_helper
INFO - 2024-09-04 18:19:02 --> Helper loaded: file_helper
INFO - 2024-09-04 18:19:02 --> Helper loaded: security_helper
INFO - 2024-09-04 18:19:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:19:02 --> Database Driver Class Initialized
INFO - 2024-09-04 18:19:02 --> Email Class Initialized
DEBUG - 2024-09-04 18:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:19:02 --> Helper loaded: form_helper
INFO - 2024-09-04 18:19:02 --> Form Validation Class Initialized
INFO - 2024-09-04 18:19:02 --> Controller Class Initialized
INFO - 2024-09-04 18:19:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:19:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:19:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:19:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:19:02 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:19:02 --> Final output sent to browser
DEBUG - 2024-09-04 18:19:02 --> Total execution time: 0.1037
INFO - 2024-09-04 18:19:06 --> Config Class Initialized
INFO - 2024-09-04 18:19:06 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:19:06 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:19:06 --> Utf8 Class Initialized
INFO - 2024-09-04 18:19:06 --> URI Class Initialized
INFO - 2024-09-04 18:19:06 --> Router Class Initialized
INFO - 2024-09-04 18:19:06 --> Output Class Initialized
INFO - 2024-09-04 18:19:06 --> Security Class Initialized
DEBUG - 2024-09-04 18:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:19:06 --> Input Class Initialized
INFO - 2024-09-04 18:19:06 --> Language Class Initialized
INFO - 2024-09-04 18:19:06 --> Loader Class Initialized
INFO - 2024-09-04 18:19:06 --> Helper loaded: url_helper
INFO - 2024-09-04 18:19:06 --> Helper loaded: file_helper
INFO - 2024-09-04 18:19:06 --> Helper loaded: security_helper
INFO - 2024-09-04 18:19:06 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:19:06 --> Database Driver Class Initialized
INFO - 2024-09-04 18:19:06 --> Email Class Initialized
DEBUG - 2024-09-04 18:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:19:06 --> Helper loaded: form_helper
INFO - 2024-09-04 18:19:06 --> Form Validation Class Initialized
INFO - 2024-09-04 18:19:06 --> Controller Class Initialized
INFO - 2024-09-04 18:19:06 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:19:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:19:06 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:19:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:19:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:19:07 --> Final output sent to browser
DEBUG - 2024-09-04 18:19:07 --> Total execution time: 0.1107
INFO - 2024-09-04 18:19:12 --> Config Class Initialized
INFO - 2024-09-04 18:19:12 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:19:12 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:19:12 --> Utf8 Class Initialized
INFO - 2024-09-04 18:19:12 --> URI Class Initialized
INFO - 2024-09-04 18:19:12 --> Router Class Initialized
INFO - 2024-09-04 18:19:12 --> Output Class Initialized
INFO - 2024-09-04 18:19:12 --> Security Class Initialized
DEBUG - 2024-09-04 18:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:19:12 --> Input Class Initialized
INFO - 2024-09-04 18:19:12 --> Language Class Initialized
INFO - 2024-09-04 18:19:12 --> Loader Class Initialized
INFO - 2024-09-04 18:19:12 --> Helper loaded: url_helper
INFO - 2024-09-04 18:19:12 --> Helper loaded: file_helper
INFO - 2024-09-04 18:19:12 --> Helper loaded: security_helper
INFO - 2024-09-04 18:19:12 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:19:12 --> Database Driver Class Initialized
INFO - 2024-09-04 18:19:12 --> Email Class Initialized
DEBUG - 2024-09-04 18:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:19:12 --> Helper loaded: form_helper
INFO - 2024-09-04 18:19:12 --> Form Validation Class Initialized
INFO - 2024-09-04 18:19:12 --> Controller Class Initialized
INFO - 2024-09-04 18:19:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:19:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:19:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:19:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:19:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:19:12 --> Final output sent to browser
DEBUG - 2024-09-04 18:19:12 --> Total execution time: 0.1127
INFO - 2024-09-04 18:19:21 --> Config Class Initialized
INFO - 2024-09-04 18:19:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:19:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:19:21 --> Utf8 Class Initialized
INFO - 2024-09-04 18:19:21 --> URI Class Initialized
INFO - 2024-09-04 18:19:21 --> Router Class Initialized
INFO - 2024-09-04 18:19:21 --> Output Class Initialized
INFO - 2024-09-04 18:19:21 --> Security Class Initialized
DEBUG - 2024-09-04 18:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:19:21 --> Input Class Initialized
INFO - 2024-09-04 18:19:21 --> Language Class Initialized
INFO - 2024-09-04 18:19:21 --> Loader Class Initialized
INFO - 2024-09-04 18:19:21 --> Helper loaded: url_helper
INFO - 2024-09-04 18:19:21 --> Helper loaded: file_helper
INFO - 2024-09-04 18:19:21 --> Helper loaded: security_helper
INFO - 2024-09-04 18:19:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:19:21 --> Database Driver Class Initialized
INFO - 2024-09-04 18:19:21 --> Email Class Initialized
DEBUG - 2024-09-04 18:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:19:21 --> Helper loaded: form_helper
INFO - 2024-09-04 18:19:21 --> Form Validation Class Initialized
INFO - 2024-09-04 18:19:21 --> Controller Class Initialized
INFO - 2024-09-04 18:19:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:19:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:19:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:19:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:19:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:19:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:19:21 --> Final output sent to browser
DEBUG - 2024-09-04 18:19:21 --> Total execution time: 0.0876
INFO - 2024-09-04 18:20:25 --> Config Class Initialized
INFO - 2024-09-04 18:20:25 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:20:25 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:20:25 --> Utf8 Class Initialized
INFO - 2024-09-04 18:20:25 --> URI Class Initialized
INFO - 2024-09-04 18:20:25 --> Router Class Initialized
INFO - 2024-09-04 18:20:25 --> Output Class Initialized
INFO - 2024-09-04 18:20:25 --> Security Class Initialized
DEBUG - 2024-09-04 18:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:20:25 --> Input Class Initialized
INFO - 2024-09-04 18:20:25 --> Language Class Initialized
INFO - 2024-09-04 18:20:25 --> Loader Class Initialized
INFO - 2024-09-04 18:20:25 --> Helper loaded: url_helper
INFO - 2024-09-04 18:20:25 --> Helper loaded: file_helper
INFO - 2024-09-04 18:20:25 --> Helper loaded: security_helper
INFO - 2024-09-04 18:20:25 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:20:25 --> Database Driver Class Initialized
INFO - 2024-09-04 18:20:25 --> Email Class Initialized
DEBUG - 2024-09-04 18:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:20:25 --> Helper loaded: form_helper
INFO - 2024-09-04 18:20:25 --> Form Validation Class Initialized
INFO - 2024-09-04 18:20:25 --> Controller Class Initialized
INFO - 2024-09-04 18:20:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:20:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:20:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:20:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:20:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:20:25 --> Final output sent to browser
DEBUG - 2024-09-04 18:20:25 --> Total execution time: 0.1664
INFO - 2024-09-04 18:20:43 --> Config Class Initialized
INFO - 2024-09-04 18:20:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:20:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:20:43 --> Utf8 Class Initialized
INFO - 2024-09-04 18:20:43 --> URI Class Initialized
INFO - 2024-09-04 18:20:43 --> Router Class Initialized
INFO - 2024-09-04 18:20:43 --> Output Class Initialized
INFO - 2024-09-04 18:20:43 --> Security Class Initialized
DEBUG - 2024-09-04 18:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:20:43 --> Input Class Initialized
INFO - 2024-09-04 18:20:43 --> Language Class Initialized
INFO - 2024-09-04 18:20:43 --> Loader Class Initialized
INFO - 2024-09-04 18:20:43 --> Helper loaded: url_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: file_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: security_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:20:43 --> Database Driver Class Initialized
INFO - 2024-09-04 18:20:43 --> Email Class Initialized
DEBUG - 2024-09-04 18:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:20:43 --> Helper loaded: form_helper
INFO - 2024-09-04 18:20:43 --> Form Validation Class Initialized
INFO - 2024-09-04 18:20:43 --> Controller Class Initialized
INFO - 2024-09-04 18:20:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:20:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:20:43 --> Config Class Initialized
INFO - 2024-09-04 18:20:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:20:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:20:43 --> Utf8 Class Initialized
INFO - 2024-09-04 18:20:43 --> URI Class Initialized
INFO - 2024-09-04 18:20:43 --> Router Class Initialized
INFO - 2024-09-04 18:20:43 --> Output Class Initialized
INFO - 2024-09-04 18:20:43 --> Security Class Initialized
DEBUG - 2024-09-04 18:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:20:43 --> Input Class Initialized
INFO - 2024-09-04 18:20:43 --> Language Class Initialized
INFO - 2024-09-04 18:20:43 --> Loader Class Initialized
INFO - 2024-09-04 18:20:43 --> Helper loaded: url_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: file_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: security_helper
INFO - 2024-09-04 18:20:43 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:20:43 --> Database Driver Class Initialized
INFO - 2024-09-04 18:20:43 --> Email Class Initialized
DEBUG - 2024-09-04 18:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:20:45 --> Config Class Initialized
INFO - 2024-09-04 18:20:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:20:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:20:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:20:45 --> URI Class Initialized
INFO - 2024-09-04 18:20:45 --> Router Class Initialized
INFO - 2024-09-04 18:20:45 --> Output Class Initialized
INFO - 2024-09-04 18:20:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:20:45 --> Input Class Initialized
INFO - 2024-09-04 18:20:45 --> Language Class Initialized
INFO - 2024-09-04 18:20:45 --> Loader Class Initialized
INFO - 2024-09-04 18:20:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:20:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:20:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:20:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:20:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:20:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-04 18:21:13 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\Style\Color.php 440
INFO - 2024-09-04 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:21:13 --> Helper loaded: form_helper
INFO - 2024-09-04 18:21:13 --> Form Validation Class Initialized
INFO - 2024-09-04 18:21:13 --> Controller Class Initialized
INFO - 2024-09-04 18:21:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
ERROR - 2024-09-04 18:21:13 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\antrol\application\views\report\cetakantrol.php 1
INFO - 2024-09-04 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:21:13 --> Helper loaded: form_helper
INFO - 2024-09-04 18:21:13 --> Form Validation Class Initialized
INFO - 2024-09-04 18:21:13 --> Controller Class Initialized
INFO - 2024-09-04 18:21:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:21:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:21:13 --> Final output sent to browser
DEBUG - 2024-09-04 18:21:13 --> Total execution time: 27.9228
INFO - 2024-09-04 18:21:45 --> Config Class Initialized
INFO - 2024-09-04 18:21:45 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:21:45 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:21:45 --> Utf8 Class Initialized
INFO - 2024-09-04 18:21:45 --> URI Class Initialized
INFO - 2024-09-04 18:21:45 --> Router Class Initialized
INFO - 2024-09-04 18:21:45 --> Output Class Initialized
INFO - 2024-09-04 18:21:45 --> Security Class Initialized
DEBUG - 2024-09-04 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:21:45 --> Input Class Initialized
INFO - 2024-09-04 18:21:45 --> Language Class Initialized
INFO - 2024-09-04 18:21:45 --> Loader Class Initialized
INFO - 2024-09-04 18:21:45 --> Helper loaded: url_helper
INFO - 2024-09-04 18:21:45 --> Helper loaded: file_helper
INFO - 2024-09-04 18:21:45 --> Helper loaded: security_helper
INFO - 2024-09-04 18:21:45 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:21:45 --> Database Driver Class Initialized
INFO - 2024-09-04 18:21:45 --> Email Class Initialized
DEBUG - 2024-09-04 18:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:21:45 --> Helper loaded: form_helper
INFO - 2024-09-04 18:21:45 --> Form Validation Class Initialized
INFO - 2024-09-04 18:21:45 --> Controller Class Initialized
INFO - 2024-09-04 18:21:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:21:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:21:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:21:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:21:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:21:45 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:21:45 --> Final output sent to browser
DEBUG - 2024-09-04 18:21:45 --> Total execution time: 0.1096
INFO - 2024-09-04 18:21:47 --> Config Class Initialized
INFO - 2024-09-04 18:21:47 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:21:47 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:21:47 --> Utf8 Class Initialized
INFO - 2024-09-04 18:21:47 --> URI Class Initialized
INFO - 2024-09-04 18:21:47 --> Router Class Initialized
INFO - 2024-09-04 18:21:47 --> Output Class Initialized
INFO - 2024-09-04 18:21:47 --> Security Class Initialized
DEBUG - 2024-09-04 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:21:47 --> Input Class Initialized
INFO - 2024-09-04 18:21:47 --> Language Class Initialized
INFO - 2024-09-04 18:21:47 --> Loader Class Initialized
INFO - 2024-09-04 18:21:47 --> Helper loaded: url_helper
INFO - 2024-09-04 18:21:47 --> Helper loaded: file_helper
INFO - 2024-09-04 18:21:47 --> Helper loaded: security_helper
INFO - 2024-09-04 18:21:47 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:21:47 --> Database Driver Class Initialized
INFO - 2024-09-04 18:21:47 --> Email Class Initialized
DEBUG - 2024-09-04 18:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:21:47 --> Helper loaded: form_helper
INFO - 2024-09-04 18:21:47 --> Form Validation Class Initialized
INFO - 2024-09-04 18:21:47 --> Controller Class Initialized
INFO - 2024-09-04 18:21:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:21:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 18:21:48 --> Severity: error --> Exception: Maximum 31 characters allowed in sheet title. C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\Worksheet.php 456
INFO - 2024-09-04 18:22:27 --> Config Class Initialized
INFO - 2024-09-04 18:22:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:22:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:22:27 --> Utf8 Class Initialized
INFO - 2024-09-04 18:22:27 --> URI Class Initialized
INFO - 2024-09-04 18:22:27 --> Router Class Initialized
INFO - 2024-09-04 18:22:27 --> Output Class Initialized
INFO - 2024-09-04 18:22:27 --> Security Class Initialized
DEBUG - 2024-09-04 18:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:22:27 --> Input Class Initialized
INFO - 2024-09-04 18:22:27 --> Language Class Initialized
INFO - 2024-09-04 18:22:27 --> Loader Class Initialized
INFO - 2024-09-04 18:22:27 --> Helper loaded: url_helper
INFO - 2024-09-04 18:22:27 --> Helper loaded: file_helper
INFO - 2024-09-04 18:22:27 --> Helper loaded: security_helper
INFO - 2024-09-04 18:22:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:22:27 --> Database Driver Class Initialized
INFO - 2024-09-04 18:22:27 --> Email Class Initialized
DEBUG - 2024-09-04 18:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:22:27 --> Helper loaded: form_helper
INFO - 2024-09-04 18:22:27 --> Form Validation Class Initialized
INFO - 2024-09-04 18:22:27 --> Controller Class Initialized
INFO - 2024-09-04 18:22:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:22:28 --> Final output sent to browser
DEBUG - 2024-09-04 18:22:28 --> Total execution time: 1.6843
INFO - 2024-09-04 18:27:36 --> Config Class Initialized
INFO - 2024-09-04 18:27:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:27:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:27:36 --> Utf8 Class Initialized
INFO - 2024-09-04 18:27:36 --> URI Class Initialized
INFO - 2024-09-04 18:27:36 --> Router Class Initialized
INFO - 2024-09-04 18:27:36 --> Output Class Initialized
INFO - 2024-09-04 18:27:36 --> Security Class Initialized
DEBUG - 2024-09-04 18:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:27:36 --> Input Class Initialized
INFO - 2024-09-04 18:27:36 --> Language Class Initialized
INFO - 2024-09-04 18:27:36 --> Loader Class Initialized
INFO - 2024-09-04 18:27:36 --> Helper loaded: url_helper
INFO - 2024-09-04 18:27:36 --> Helper loaded: file_helper
INFO - 2024-09-04 18:27:36 --> Helper loaded: security_helper
INFO - 2024-09-04 18:27:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:27:36 --> Database Driver Class Initialized
INFO - 2024-09-04 18:27:36 --> Email Class Initialized
DEBUG - 2024-09-04 18:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:27:36 --> Helper loaded: form_helper
INFO - 2024-09-04 18:27:36 --> Form Validation Class Initialized
INFO - 2024-09-04 18:27:36 --> Controller Class Initialized
INFO - 2024-09-04 18:27:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:27:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:27:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:27:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:27:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:27:36 --> Final output sent to browser
DEBUG - 2024-09-04 18:27:36 --> Total execution time: 0.0933
INFO - 2024-09-04 18:31:17 --> Config Class Initialized
INFO - 2024-09-04 18:31:17 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:31:17 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:31:17 --> Utf8 Class Initialized
INFO - 2024-09-04 18:31:17 --> URI Class Initialized
INFO - 2024-09-04 18:31:17 --> Router Class Initialized
INFO - 2024-09-04 18:31:17 --> Output Class Initialized
INFO - 2024-09-04 18:31:17 --> Security Class Initialized
DEBUG - 2024-09-04 18:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:31:17 --> Input Class Initialized
INFO - 2024-09-04 18:31:17 --> Language Class Initialized
INFO - 2024-09-04 18:31:17 --> Loader Class Initialized
INFO - 2024-09-04 18:31:17 --> Helper loaded: url_helper
INFO - 2024-09-04 18:31:17 --> Helper loaded: file_helper
INFO - 2024-09-04 18:31:17 --> Helper loaded: security_helper
INFO - 2024-09-04 18:31:17 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:31:17 --> Database Driver Class Initialized
INFO - 2024-09-04 18:31:17 --> Email Class Initialized
DEBUG - 2024-09-04 18:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:31:17 --> Helper loaded: form_helper
INFO - 2024-09-04 18:31:17 --> Form Validation Class Initialized
INFO - 2024-09-04 18:31:17 --> Controller Class Initialized
INFO - 2024-09-04 18:31:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:31:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:31:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:31:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:31:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:31:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:31:17 --> Final output sent to browser
DEBUG - 2024-09-04 18:31:17 --> Total execution time: 0.1028
INFO - 2024-09-04 18:31:19 --> Config Class Initialized
INFO - 2024-09-04 18:31:19 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:31:19 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:31:19 --> Utf8 Class Initialized
INFO - 2024-09-04 18:31:19 --> URI Class Initialized
INFO - 2024-09-04 18:31:19 --> Router Class Initialized
INFO - 2024-09-04 18:31:19 --> Output Class Initialized
INFO - 2024-09-04 18:31:19 --> Security Class Initialized
DEBUG - 2024-09-04 18:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:31:19 --> Input Class Initialized
INFO - 2024-09-04 18:31:19 --> Language Class Initialized
INFO - 2024-09-04 18:31:19 --> Loader Class Initialized
INFO - 2024-09-04 18:31:19 --> Helper loaded: url_helper
INFO - 2024-09-04 18:31:19 --> Helper loaded: file_helper
INFO - 2024-09-04 18:31:19 --> Helper loaded: security_helper
INFO - 2024-09-04 18:31:19 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:31:19 --> Database Driver Class Initialized
INFO - 2024-09-04 18:31:19 --> Email Class Initialized
DEBUG - 2024-09-04 18:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:31:19 --> Helper loaded: form_helper
INFO - 2024-09-04 18:31:19 --> Form Validation Class Initialized
INFO - 2024-09-04 18:31:19 --> Controller Class Initialized
INFO - 2024-09-04 18:31:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:31:20 --> Final output sent to browser
DEBUG - 2024-09-04 18:31:20 --> Total execution time: 0.6444
INFO - 2024-09-04 18:31:34 --> Config Class Initialized
INFO - 2024-09-04 18:31:34 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:31:34 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:31:34 --> Utf8 Class Initialized
INFO - 2024-09-04 18:31:34 --> URI Class Initialized
INFO - 2024-09-04 18:31:34 --> Router Class Initialized
INFO - 2024-09-04 18:31:34 --> Output Class Initialized
INFO - 2024-09-04 18:31:34 --> Security Class Initialized
DEBUG - 2024-09-04 18:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:31:34 --> Input Class Initialized
INFO - 2024-09-04 18:31:34 --> Language Class Initialized
INFO - 2024-09-04 18:31:34 --> Loader Class Initialized
INFO - 2024-09-04 18:31:34 --> Helper loaded: url_helper
INFO - 2024-09-04 18:31:34 --> Helper loaded: file_helper
INFO - 2024-09-04 18:31:34 --> Helper loaded: security_helper
INFO - 2024-09-04 18:31:34 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:31:34 --> Database Driver Class Initialized
INFO - 2024-09-04 18:31:34 --> Email Class Initialized
DEBUG - 2024-09-04 18:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:31:34 --> Helper loaded: form_helper
INFO - 2024-09-04 18:31:34 --> Form Validation Class Initialized
INFO - 2024-09-04 18:31:34 --> Controller Class Initialized
INFO - 2024-09-04 18:31:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:31:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:31:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:31:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:31:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:31:34 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:31:34 --> Final output sent to browser
DEBUG - 2024-09-04 18:31:34 --> Total execution time: 0.0843
INFO - 2024-09-04 18:32:36 --> Config Class Initialized
INFO - 2024-09-04 18:32:36 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:32:36 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:32:36 --> Utf8 Class Initialized
INFO - 2024-09-04 18:32:36 --> URI Class Initialized
INFO - 2024-09-04 18:32:36 --> Router Class Initialized
INFO - 2024-09-04 18:32:36 --> Output Class Initialized
INFO - 2024-09-04 18:32:36 --> Security Class Initialized
DEBUG - 2024-09-04 18:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:32:36 --> Input Class Initialized
INFO - 2024-09-04 18:32:36 --> Language Class Initialized
INFO - 2024-09-04 18:32:36 --> Loader Class Initialized
INFO - 2024-09-04 18:32:36 --> Helper loaded: url_helper
INFO - 2024-09-04 18:32:36 --> Helper loaded: file_helper
INFO - 2024-09-04 18:32:36 --> Helper loaded: security_helper
INFO - 2024-09-04 18:32:36 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:32:36 --> Database Driver Class Initialized
INFO - 2024-09-04 18:32:36 --> Email Class Initialized
DEBUG - 2024-09-04 18:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:32:36 --> Helper loaded: form_helper
INFO - 2024-09-04 18:32:36 --> Form Validation Class Initialized
INFO - 2024-09-04 18:32:36 --> Controller Class Initialized
INFO - 2024-09-04 18:32:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:32:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:32:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:32:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:32:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:32:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:32:36 --> Final output sent to browser
DEBUG - 2024-09-04 18:32:36 --> Total execution time: 0.1060
INFO - 2024-09-04 18:33:57 --> Config Class Initialized
INFO - 2024-09-04 18:33:57 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:33:57 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:33:57 --> Utf8 Class Initialized
INFO - 2024-09-04 18:33:57 --> URI Class Initialized
INFO - 2024-09-04 18:33:57 --> Router Class Initialized
INFO - 2024-09-04 18:33:58 --> Output Class Initialized
INFO - 2024-09-04 18:33:58 --> Security Class Initialized
DEBUG - 2024-09-04 18:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:33:58 --> Input Class Initialized
INFO - 2024-09-04 18:33:58 --> Language Class Initialized
INFO - 2024-09-04 18:33:58 --> Loader Class Initialized
INFO - 2024-09-04 18:33:58 --> Helper loaded: url_helper
INFO - 2024-09-04 18:33:58 --> Helper loaded: file_helper
INFO - 2024-09-04 18:33:58 --> Helper loaded: security_helper
INFO - 2024-09-04 18:33:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:33:58 --> Database Driver Class Initialized
INFO - 2024-09-04 18:33:58 --> Email Class Initialized
DEBUG - 2024-09-04 18:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:33:58 --> Helper loaded: form_helper
INFO - 2024-09-04 18:33:58 --> Form Validation Class Initialized
INFO - 2024-09-04 18:33:58 --> Controller Class Initialized
INFO - 2024-09-04 18:33:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:33:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:33:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:33:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:33:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:33:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:33:58 --> Final output sent to browser
DEBUG - 2024-09-04 18:33:58 --> Total execution time: 0.1114
INFO - 2024-09-04 18:34:09 --> Config Class Initialized
INFO - 2024-09-04 18:34:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:34:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:34:09 --> Utf8 Class Initialized
INFO - 2024-09-04 18:34:09 --> URI Class Initialized
INFO - 2024-09-04 18:34:09 --> Router Class Initialized
INFO - 2024-09-04 18:34:09 --> Output Class Initialized
INFO - 2024-09-04 18:34:09 --> Security Class Initialized
DEBUG - 2024-09-04 18:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:34:09 --> Input Class Initialized
INFO - 2024-09-04 18:34:09 --> Language Class Initialized
INFO - 2024-09-04 18:34:09 --> Loader Class Initialized
INFO - 2024-09-04 18:34:09 --> Helper loaded: url_helper
INFO - 2024-09-04 18:34:09 --> Helper loaded: file_helper
INFO - 2024-09-04 18:34:09 --> Helper loaded: security_helper
INFO - 2024-09-04 18:34:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:34:09 --> Database Driver Class Initialized
INFO - 2024-09-04 18:34:09 --> Email Class Initialized
DEBUG - 2024-09-04 18:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:34:09 --> Helper loaded: form_helper
INFO - 2024-09-04 18:34:09 --> Form Validation Class Initialized
INFO - 2024-09-04 18:34:09 --> Controller Class Initialized
INFO - 2024-09-04 18:34:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:34:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:34:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:34:09 --> Final output sent to browser
DEBUG - 2024-09-04 18:34:09 --> Total execution time: 0.2085
INFO - 2024-09-04 18:36:00 --> Config Class Initialized
INFO - 2024-09-04 18:36:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:36:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:36:00 --> Utf8 Class Initialized
INFO - 2024-09-04 18:36:00 --> URI Class Initialized
INFO - 2024-09-04 18:36:00 --> Router Class Initialized
INFO - 2024-09-04 18:36:00 --> Output Class Initialized
INFO - 2024-09-04 18:36:00 --> Security Class Initialized
DEBUG - 2024-09-04 18:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:36:00 --> Input Class Initialized
INFO - 2024-09-04 18:36:00 --> Language Class Initialized
INFO - 2024-09-04 18:36:00 --> Loader Class Initialized
INFO - 2024-09-04 18:36:00 --> Helper loaded: url_helper
INFO - 2024-09-04 18:36:00 --> Helper loaded: file_helper
INFO - 2024-09-04 18:36:00 --> Helper loaded: security_helper
INFO - 2024-09-04 18:36:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:36:00 --> Database Driver Class Initialized
INFO - 2024-09-04 18:36:00 --> Email Class Initialized
DEBUG - 2024-09-04 18:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:36:00 --> Helper loaded: form_helper
INFO - 2024-09-04 18:36:00 --> Form Validation Class Initialized
INFO - 2024-09-04 18:36:00 --> Controller Class Initialized
INFO - 2024-09-04 18:36:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:36:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:36:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:36:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:36:00 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:36:00 --> Final output sent to browser
DEBUG - 2024-09-04 18:36:00 --> Total execution time: 0.1328
INFO - 2024-09-04 18:36:26 --> Config Class Initialized
INFO - 2024-09-04 18:36:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:36:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:36:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:36:26 --> URI Class Initialized
INFO - 2024-09-04 18:36:26 --> Router Class Initialized
INFO - 2024-09-04 18:36:26 --> Output Class Initialized
INFO - 2024-09-04 18:36:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:36:26 --> Input Class Initialized
INFO - 2024-09-04 18:36:26 --> Language Class Initialized
INFO - 2024-09-04 18:36:26 --> Loader Class Initialized
INFO - 2024-09-04 18:36:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:36:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:36:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:36:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:36:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:36:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:36:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:36:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:36:26 --> Controller Class Initialized
INFO - 2024-09-04 18:36:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:36:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:36:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:36:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:36:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:36:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:36:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:36:26 --> Total execution time: 0.1445
INFO - 2024-09-04 18:37:41 --> Config Class Initialized
INFO - 2024-09-04 18:37:41 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:37:41 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:37:41 --> Utf8 Class Initialized
INFO - 2024-09-04 18:37:41 --> URI Class Initialized
INFO - 2024-09-04 18:37:41 --> Router Class Initialized
INFO - 2024-09-04 18:37:41 --> Output Class Initialized
INFO - 2024-09-04 18:37:41 --> Security Class Initialized
DEBUG - 2024-09-04 18:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:37:41 --> Input Class Initialized
INFO - 2024-09-04 18:37:41 --> Language Class Initialized
INFO - 2024-09-04 18:37:41 --> Loader Class Initialized
INFO - 2024-09-04 18:37:41 --> Helper loaded: url_helper
INFO - 2024-09-04 18:37:41 --> Helper loaded: file_helper
INFO - 2024-09-04 18:37:41 --> Helper loaded: security_helper
INFO - 2024-09-04 18:37:41 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:37:41 --> Database Driver Class Initialized
INFO - 2024-09-04 18:37:41 --> Email Class Initialized
DEBUG - 2024-09-04 18:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:37:41 --> Helper loaded: form_helper
INFO - 2024-09-04 18:37:41 --> Form Validation Class Initialized
INFO - 2024-09-04 18:37:41 --> Controller Class Initialized
INFO - 2024-09-04 18:37:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:37:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:37:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:37:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:37:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:37:41 --> Final output sent to browser
DEBUG - 2024-09-04 18:37:41 --> Total execution time: 0.1368
INFO - 2024-09-04 18:37:43 --> Config Class Initialized
INFO - 2024-09-04 18:37:43 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:37:43 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:37:43 --> Utf8 Class Initialized
INFO - 2024-09-04 18:37:43 --> URI Class Initialized
INFO - 2024-09-04 18:37:43 --> Router Class Initialized
INFO - 2024-09-04 18:37:43 --> Output Class Initialized
INFO - 2024-09-04 18:37:43 --> Security Class Initialized
DEBUG - 2024-09-04 18:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:37:43 --> Input Class Initialized
INFO - 2024-09-04 18:37:43 --> Language Class Initialized
INFO - 2024-09-04 18:37:43 --> Loader Class Initialized
INFO - 2024-09-04 18:37:43 --> Helper loaded: url_helper
INFO - 2024-09-04 18:37:43 --> Helper loaded: file_helper
INFO - 2024-09-04 18:37:43 --> Helper loaded: security_helper
INFO - 2024-09-04 18:37:43 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:37:43 --> Database Driver Class Initialized
INFO - 2024-09-04 18:37:43 --> Email Class Initialized
DEBUG - 2024-09-04 18:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:37:43 --> Helper loaded: form_helper
INFO - 2024-09-04 18:37:43 --> Form Validation Class Initialized
INFO - 2024-09-04 18:37:43 --> Controller Class Initialized
INFO - 2024-09-04 18:37:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:38:27 --> Config Class Initialized
INFO - 2024-09-04 18:38:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:38:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:38:27 --> Utf8 Class Initialized
INFO - 2024-09-04 18:38:27 --> URI Class Initialized
INFO - 2024-09-04 18:38:27 --> Router Class Initialized
INFO - 2024-09-04 18:38:27 --> Output Class Initialized
INFO - 2024-09-04 18:38:27 --> Security Class Initialized
DEBUG - 2024-09-04 18:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:38:27 --> Input Class Initialized
INFO - 2024-09-04 18:38:27 --> Language Class Initialized
INFO - 2024-09-04 18:38:27 --> Loader Class Initialized
INFO - 2024-09-04 18:38:27 --> Helper loaded: url_helper
INFO - 2024-09-04 18:38:27 --> Helper loaded: file_helper
INFO - 2024-09-04 18:38:27 --> Helper loaded: security_helper
INFO - 2024-09-04 18:38:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:38:27 --> Database Driver Class Initialized
INFO - 2024-09-04 18:38:27 --> Email Class Initialized
DEBUG - 2024-09-04 18:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:38:27 --> Helper loaded: form_helper
INFO - 2024-09-04 18:38:27 --> Form Validation Class Initialized
INFO - 2024-09-04 18:38:27 --> Controller Class Initialized
INFO - 2024-09-04 18:38:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:38:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:39:07 --> Config Class Initialized
INFO - 2024-09-04 18:39:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:39:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:39:07 --> Utf8 Class Initialized
INFO - 2024-09-04 18:39:07 --> URI Class Initialized
INFO - 2024-09-04 18:39:07 --> Router Class Initialized
INFO - 2024-09-04 18:39:07 --> Output Class Initialized
INFO - 2024-09-04 18:39:07 --> Security Class Initialized
DEBUG - 2024-09-04 18:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:39:07 --> Input Class Initialized
INFO - 2024-09-04 18:39:07 --> Language Class Initialized
INFO - 2024-09-04 18:39:07 --> Loader Class Initialized
INFO - 2024-09-04 18:39:07 --> Helper loaded: url_helper
INFO - 2024-09-04 18:39:07 --> Helper loaded: file_helper
INFO - 2024-09-04 18:39:07 --> Helper loaded: security_helper
INFO - 2024-09-04 18:39:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:39:07 --> Database Driver Class Initialized
INFO - 2024-09-04 18:39:07 --> Email Class Initialized
DEBUG - 2024-09-04 18:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:39:08 --> Helper loaded: form_helper
INFO - 2024-09-04 18:39:08 --> Form Validation Class Initialized
INFO - 2024-09-04 18:39:08 --> Controller Class Initialized
INFO - 2024-09-04 18:39:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:39:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:39:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:39:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:39:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:39:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:39:08 --> Final output sent to browser
DEBUG - 2024-09-04 18:39:08 --> Total execution time: 0.0983
INFO - 2024-09-04 18:39:09 --> Config Class Initialized
INFO - 2024-09-04 18:39:09 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:39:09 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:39:09 --> Utf8 Class Initialized
INFO - 2024-09-04 18:39:09 --> URI Class Initialized
INFO - 2024-09-04 18:39:09 --> Router Class Initialized
INFO - 2024-09-04 18:39:09 --> Output Class Initialized
INFO - 2024-09-04 18:39:09 --> Security Class Initialized
DEBUG - 2024-09-04 18:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:39:09 --> Input Class Initialized
INFO - 2024-09-04 18:39:09 --> Language Class Initialized
INFO - 2024-09-04 18:39:09 --> Loader Class Initialized
INFO - 2024-09-04 18:39:09 --> Helper loaded: url_helper
INFO - 2024-09-04 18:39:09 --> Helper loaded: file_helper
INFO - 2024-09-04 18:39:09 --> Helper loaded: security_helper
INFO - 2024-09-04 18:39:09 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:39:09 --> Database Driver Class Initialized
INFO - 2024-09-04 18:39:09 --> Email Class Initialized
DEBUG - 2024-09-04 18:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:39:09 --> Helper loaded: form_helper
INFO - 2024-09-04 18:39:09 --> Form Validation Class Initialized
INFO - 2024-09-04 18:39:09 --> Controller Class Initialized
INFO - 2024-09-04 18:39:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:39:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:39:09 --> Final output sent to browser
DEBUG - 2024-09-04 18:39:09 --> Total execution time: 0.5896
INFO - 2024-09-04 18:39:21 --> Config Class Initialized
INFO - 2024-09-04 18:39:21 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:39:21 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:39:21 --> Utf8 Class Initialized
INFO - 2024-09-04 18:39:21 --> URI Class Initialized
INFO - 2024-09-04 18:39:21 --> Router Class Initialized
INFO - 2024-09-04 18:39:21 --> Output Class Initialized
INFO - 2024-09-04 18:39:21 --> Security Class Initialized
DEBUG - 2024-09-04 18:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:39:21 --> Input Class Initialized
INFO - 2024-09-04 18:39:21 --> Language Class Initialized
INFO - 2024-09-04 18:39:21 --> Loader Class Initialized
INFO - 2024-09-04 18:39:21 --> Helper loaded: url_helper
INFO - 2024-09-04 18:39:21 --> Helper loaded: file_helper
INFO - 2024-09-04 18:39:21 --> Helper loaded: security_helper
INFO - 2024-09-04 18:39:21 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:39:21 --> Database Driver Class Initialized
INFO - 2024-09-04 18:39:21 --> Email Class Initialized
DEBUG - 2024-09-04 18:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:39:21 --> Helper loaded: form_helper
INFO - 2024-09-04 18:39:21 --> Form Validation Class Initialized
INFO - 2024-09-04 18:39:21 --> Controller Class Initialized
INFO - 2024-09-04 18:39:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:39:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:39:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:39:21 --> Final output sent to browser
DEBUG - 2024-09-04 18:39:21 --> Total execution time: 0.0916
INFO - 2024-09-04 18:39:39 --> Config Class Initialized
INFO - 2024-09-04 18:39:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:39:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:39:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:39:39 --> URI Class Initialized
INFO - 2024-09-04 18:39:39 --> Router Class Initialized
INFO - 2024-09-04 18:39:39 --> Output Class Initialized
INFO - 2024-09-04 18:39:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:39:39 --> Input Class Initialized
INFO - 2024-09-04 18:39:39 --> Language Class Initialized
INFO - 2024-09-04 18:39:39 --> Loader Class Initialized
INFO - 2024-09-04 18:39:39 --> Helper loaded: url_helper
INFO - 2024-09-04 18:39:39 --> Helper loaded: file_helper
INFO - 2024-09-04 18:39:39 --> Helper loaded: security_helper
INFO - 2024-09-04 18:39:39 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:39:39 --> Database Driver Class Initialized
INFO - 2024-09-04 18:39:39 --> Email Class Initialized
DEBUG - 2024-09-04 18:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:39:39 --> Helper loaded: form_helper
INFO - 2024-09-04 18:39:39 --> Form Validation Class Initialized
INFO - 2024-09-04 18:39:39 --> Controller Class Initialized
INFO - 2024-09-04 18:39:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:39:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-04 18:40:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\CachedObjectStorage\CacheBase.php:177) C:\xampp\htdocs\antrol\system\core\Common.php 570
ERROR - 2024-09-04 18:40:07 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 7340032 bytes) C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\CachedObjectStorage\CacheBase.php 177
INFO - 2024-09-04 18:40:20 --> Config Class Initialized
INFO - 2024-09-04 18:40:20 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:40:20 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:40:20 --> Utf8 Class Initialized
INFO - 2024-09-04 18:40:20 --> URI Class Initialized
INFO - 2024-09-04 18:40:20 --> Router Class Initialized
INFO - 2024-09-04 18:40:20 --> Output Class Initialized
INFO - 2024-09-04 18:40:20 --> Security Class Initialized
DEBUG - 2024-09-04 18:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:40:20 --> Input Class Initialized
INFO - 2024-09-04 18:40:20 --> Language Class Initialized
INFO - 2024-09-04 18:40:20 --> Loader Class Initialized
INFO - 2024-09-04 18:40:20 --> Helper loaded: url_helper
INFO - 2024-09-04 18:40:20 --> Helper loaded: file_helper
INFO - 2024-09-04 18:40:20 --> Helper loaded: security_helper
INFO - 2024-09-04 18:40:20 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:40:20 --> Database Driver Class Initialized
INFO - 2024-09-04 18:40:20 --> Email Class Initialized
DEBUG - 2024-09-04 18:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:40:20 --> Helper loaded: form_helper
INFO - 2024-09-04 18:40:20 --> Form Validation Class Initialized
INFO - 2024-09-04 18:40:20 --> Controller Class Initialized
INFO - 2024-09-04 18:40:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:40:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:40:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:40:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:40:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:40:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:40:20 --> Final output sent to browser
DEBUG - 2024-09-04 18:40:20 --> Total execution time: 0.2846
INFO - 2024-09-04 18:41:58 --> Config Class Initialized
INFO - 2024-09-04 18:41:58 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:41:58 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:41:58 --> Utf8 Class Initialized
INFO - 2024-09-04 18:41:58 --> URI Class Initialized
INFO - 2024-09-04 18:41:58 --> Router Class Initialized
INFO - 2024-09-04 18:41:58 --> Output Class Initialized
INFO - 2024-09-04 18:41:58 --> Security Class Initialized
DEBUG - 2024-09-04 18:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:41:58 --> Input Class Initialized
INFO - 2024-09-04 18:41:58 --> Language Class Initialized
INFO - 2024-09-04 18:41:58 --> Loader Class Initialized
INFO - 2024-09-04 18:41:58 --> Helper loaded: url_helper
INFO - 2024-09-04 18:41:58 --> Helper loaded: file_helper
INFO - 2024-09-04 18:41:58 --> Helper loaded: security_helper
INFO - 2024-09-04 18:41:58 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:41:58 --> Database Driver Class Initialized
INFO - 2024-09-04 18:41:59 --> Email Class Initialized
DEBUG - 2024-09-04 18:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:41:59 --> Helper loaded: form_helper
INFO - 2024-09-04 18:41:59 --> Form Validation Class Initialized
INFO - 2024-09-04 18:41:59 --> Controller Class Initialized
INFO - 2024-09-04 18:41:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:41:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:41:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:41:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:41:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:41:59 --> Final output sent to browser
DEBUG - 2024-09-04 18:41:59 --> Total execution time: 0.1339
INFO - 2024-09-04 18:42:00 --> Config Class Initialized
INFO - 2024-09-04 18:42:00 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:42:00 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:42:00 --> Utf8 Class Initialized
INFO - 2024-09-04 18:42:00 --> URI Class Initialized
INFO - 2024-09-04 18:42:00 --> Router Class Initialized
INFO - 2024-09-04 18:42:00 --> Output Class Initialized
INFO - 2024-09-04 18:42:00 --> Security Class Initialized
DEBUG - 2024-09-04 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:42:00 --> Input Class Initialized
INFO - 2024-09-04 18:42:00 --> Language Class Initialized
INFO - 2024-09-04 18:42:00 --> Loader Class Initialized
INFO - 2024-09-04 18:42:00 --> Helper loaded: url_helper
INFO - 2024-09-04 18:42:00 --> Helper loaded: file_helper
INFO - 2024-09-04 18:42:00 --> Helper loaded: security_helper
INFO - 2024-09-04 18:42:00 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:42:00 --> Database Driver Class Initialized
INFO - 2024-09-04 18:42:00 --> Email Class Initialized
DEBUG - 2024-09-04 18:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:42:00 --> Helper loaded: form_helper
INFO - 2024-09-04 18:42:00 --> Form Validation Class Initialized
INFO - 2024-09-04 18:42:00 --> Controller Class Initialized
INFO - 2024-09-04 18:42:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:42:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:42:01 --> Final output sent to browser
DEBUG - 2024-09-04 18:42:01 --> Total execution time: 0.6214
INFO - 2024-09-04 18:43:06 --> Config Class Initialized
INFO - 2024-09-04 18:43:06 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:43:06 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:43:06 --> Utf8 Class Initialized
INFO - 2024-09-04 18:43:06 --> URI Class Initialized
INFO - 2024-09-04 18:43:06 --> Router Class Initialized
INFO - 2024-09-04 18:43:06 --> Output Class Initialized
INFO - 2024-09-04 18:43:06 --> Security Class Initialized
DEBUG - 2024-09-04 18:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:43:07 --> Input Class Initialized
INFO - 2024-09-04 18:43:07 --> Language Class Initialized
INFO - 2024-09-04 18:43:07 --> Loader Class Initialized
INFO - 2024-09-04 18:43:07 --> Helper loaded: url_helper
INFO - 2024-09-04 18:43:07 --> Helper loaded: file_helper
INFO - 2024-09-04 18:43:07 --> Helper loaded: security_helper
INFO - 2024-09-04 18:43:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:43:07 --> Database Driver Class Initialized
INFO - 2024-09-04 18:43:07 --> Email Class Initialized
DEBUG - 2024-09-04 18:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:43:07 --> Helper loaded: form_helper
INFO - 2024-09-04 18:43:07 --> Form Validation Class Initialized
INFO - 2024-09-04 18:43:07 --> Controller Class Initialized
INFO - 2024-09-04 18:43:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:43:07 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:43:07 --> Final output sent to browser
DEBUG - 2024-09-04 18:43:07 --> Total execution time: 0.1131
INFO - 2024-09-04 18:43:08 --> Config Class Initialized
INFO - 2024-09-04 18:43:08 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:43:08 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:43:08 --> Utf8 Class Initialized
INFO - 2024-09-04 18:43:08 --> URI Class Initialized
INFO - 2024-09-04 18:43:08 --> Router Class Initialized
INFO - 2024-09-04 18:43:08 --> Output Class Initialized
INFO - 2024-09-04 18:43:08 --> Security Class Initialized
DEBUG - 2024-09-04 18:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:43:08 --> Input Class Initialized
INFO - 2024-09-04 18:43:08 --> Language Class Initialized
INFO - 2024-09-04 18:43:08 --> Loader Class Initialized
INFO - 2024-09-04 18:43:08 --> Helper loaded: url_helper
INFO - 2024-09-04 18:43:08 --> Helper loaded: file_helper
INFO - 2024-09-04 18:43:08 --> Helper loaded: security_helper
INFO - 2024-09-04 18:43:08 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:43:08 --> Database Driver Class Initialized
INFO - 2024-09-04 18:43:08 --> Email Class Initialized
DEBUG - 2024-09-04 18:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:43:08 --> Helper loaded: form_helper
INFO - 2024-09-04 18:43:08 --> Form Validation Class Initialized
INFO - 2024-09-04 18:43:08 --> Controller Class Initialized
INFO - 2024-09-04 18:43:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:43:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:43:08 --> Final output sent to browser
DEBUG - 2024-09-04 18:43:08 --> Total execution time: 0.5132
INFO - 2024-09-04 18:45:04 --> Config Class Initialized
INFO - 2024-09-04 18:45:04 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:45:04 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:45:04 --> Utf8 Class Initialized
INFO - 2024-09-04 18:45:04 --> URI Class Initialized
INFO - 2024-09-04 18:45:04 --> Router Class Initialized
INFO - 2024-09-04 18:45:04 --> Output Class Initialized
INFO - 2024-09-04 18:45:04 --> Security Class Initialized
DEBUG - 2024-09-04 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:45:04 --> Input Class Initialized
INFO - 2024-09-04 18:45:04 --> Language Class Initialized
INFO - 2024-09-04 18:45:04 --> Loader Class Initialized
INFO - 2024-09-04 18:45:04 --> Helper loaded: url_helper
INFO - 2024-09-04 18:45:04 --> Helper loaded: file_helper
INFO - 2024-09-04 18:45:04 --> Helper loaded: security_helper
INFO - 2024-09-04 18:45:04 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:45:04 --> Database Driver Class Initialized
INFO - 2024-09-04 18:45:04 --> Email Class Initialized
DEBUG - 2024-09-04 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:45:04 --> Helper loaded: form_helper
INFO - 2024-09-04 18:45:04 --> Form Validation Class Initialized
INFO - 2024-09-04 18:45:04 --> Controller Class Initialized
INFO - 2024-09-04 18:45:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:45:04 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:45:04 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:45:04 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:45:04 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:45:04 --> Final output sent to browser
DEBUG - 2024-09-04 18:45:04 --> Total execution time: 0.1253
INFO - 2024-09-04 18:45:07 --> Config Class Initialized
INFO - 2024-09-04 18:45:07 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:45:07 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:45:07 --> Utf8 Class Initialized
INFO - 2024-09-04 18:45:07 --> URI Class Initialized
INFO - 2024-09-04 18:45:07 --> Router Class Initialized
INFO - 2024-09-04 18:45:07 --> Output Class Initialized
INFO - 2024-09-04 18:45:07 --> Security Class Initialized
DEBUG - 2024-09-04 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:45:07 --> Input Class Initialized
INFO - 2024-09-04 18:45:07 --> Language Class Initialized
INFO - 2024-09-04 18:45:07 --> Loader Class Initialized
INFO - 2024-09-04 18:45:07 --> Helper loaded: url_helper
INFO - 2024-09-04 18:45:07 --> Helper loaded: file_helper
INFO - 2024-09-04 18:45:07 --> Helper loaded: security_helper
INFO - 2024-09-04 18:45:07 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:45:07 --> Database Driver Class Initialized
INFO - 2024-09-04 18:45:07 --> Email Class Initialized
DEBUG - 2024-09-04 18:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:45:07 --> Helper loaded: form_helper
INFO - 2024-09-04 18:45:07 --> Form Validation Class Initialized
INFO - 2024-09-04 18:45:07 --> Controller Class Initialized
INFO - 2024-09-04 18:45:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:45:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:45:09 --> Final output sent to browser
DEBUG - 2024-09-04 18:45:09 --> Total execution time: 2.4576
INFO - 2024-09-04 18:47:02 --> Config Class Initialized
INFO - 2024-09-04 18:47:02 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:47:02 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:47:02 --> Utf8 Class Initialized
INFO - 2024-09-04 18:47:02 --> URI Class Initialized
INFO - 2024-09-04 18:47:02 --> Router Class Initialized
INFO - 2024-09-04 18:47:02 --> Output Class Initialized
INFO - 2024-09-04 18:47:02 --> Security Class Initialized
DEBUG - 2024-09-04 18:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:47:02 --> Input Class Initialized
INFO - 2024-09-04 18:47:02 --> Language Class Initialized
INFO - 2024-09-04 18:47:02 --> Loader Class Initialized
INFO - 2024-09-04 18:47:02 --> Helper loaded: url_helper
INFO - 2024-09-04 18:47:02 --> Helper loaded: file_helper
INFO - 2024-09-04 18:47:02 --> Helper loaded: security_helper
INFO - 2024-09-04 18:47:02 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:47:02 --> Database Driver Class Initialized
INFO - 2024-09-04 18:47:02 --> Email Class Initialized
DEBUG - 2024-09-04 18:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:47:02 --> Helper loaded: form_helper
INFO - 2024-09-04 18:47:02 --> Form Validation Class Initialized
INFO - 2024-09-04 18:47:02 --> Controller Class Initialized
INFO - 2024-09-04 18:47:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:47:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:47:04 --> Final output sent to browser
DEBUG - 2024-09-04 18:47:04 --> Total execution time: 2.6713
INFO - 2024-09-04 18:47:14 --> Config Class Initialized
INFO - 2024-09-04 18:47:14 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:47:14 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:47:14 --> Utf8 Class Initialized
INFO - 2024-09-04 18:47:14 --> URI Class Initialized
INFO - 2024-09-04 18:47:14 --> Router Class Initialized
INFO - 2024-09-04 18:47:14 --> Output Class Initialized
INFO - 2024-09-04 18:47:14 --> Security Class Initialized
DEBUG - 2024-09-04 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:47:14 --> Input Class Initialized
INFO - 2024-09-04 18:47:14 --> Language Class Initialized
INFO - 2024-09-04 18:47:14 --> Loader Class Initialized
INFO - 2024-09-04 18:47:14 --> Helper loaded: url_helper
INFO - 2024-09-04 18:47:14 --> Helper loaded: file_helper
INFO - 2024-09-04 18:47:14 --> Helper loaded: security_helper
INFO - 2024-09-04 18:47:14 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:47:14 --> Database Driver Class Initialized
INFO - 2024-09-04 18:47:14 --> Email Class Initialized
DEBUG - 2024-09-04 18:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:47:14 --> Helper loaded: form_helper
INFO - 2024-09-04 18:47:14 --> Form Validation Class Initialized
INFO - 2024-09-04 18:47:14 --> Controller Class Initialized
INFO - 2024-09-04 18:47:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:47:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:47:17 --> Final output sent to browser
DEBUG - 2024-09-04 18:47:17 --> Total execution time: 2.6601
INFO - 2024-09-04 18:48:35 --> Config Class Initialized
INFO - 2024-09-04 18:48:35 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:48:35 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:48:35 --> Utf8 Class Initialized
INFO - 2024-09-04 18:48:35 --> URI Class Initialized
INFO - 2024-09-04 18:48:35 --> Router Class Initialized
INFO - 2024-09-04 18:48:35 --> Output Class Initialized
INFO - 2024-09-04 18:48:35 --> Security Class Initialized
DEBUG - 2024-09-04 18:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:48:35 --> Input Class Initialized
INFO - 2024-09-04 18:48:35 --> Language Class Initialized
INFO - 2024-09-04 18:48:35 --> Loader Class Initialized
INFO - 2024-09-04 18:48:35 --> Helper loaded: url_helper
INFO - 2024-09-04 18:48:35 --> Helper loaded: file_helper
INFO - 2024-09-04 18:48:35 --> Helper loaded: security_helper
INFO - 2024-09-04 18:48:35 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:48:35 --> Database Driver Class Initialized
INFO - 2024-09-04 18:48:35 --> Email Class Initialized
DEBUG - 2024-09-04 18:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:48:35 --> Helper loaded: form_helper
INFO - 2024-09-04 18:48:35 --> Form Validation Class Initialized
INFO - 2024-09-04 18:48:35 --> Controller Class Initialized
INFO - 2024-09-04 18:48:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:48:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:48:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:48:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:48:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-04 18:48:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:48:35 --> Final output sent to browser
DEBUG - 2024-09-04 18:48:35 --> Total execution time: 0.1154
INFO - 2024-09-04 18:48:39 --> Config Class Initialized
INFO - 2024-09-04 18:48:39 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:48:39 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:48:39 --> Utf8 Class Initialized
INFO - 2024-09-04 18:48:39 --> URI Class Initialized
INFO - 2024-09-04 18:48:39 --> Router Class Initialized
INFO - 2024-09-04 18:48:39 --> Output Class Initialized
INFO - 2024-09-04 18:48:39 --> Security Class Initialized
DEBUG - 2024-09-04 18:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:48:39 --> Input Class Initialized
INFO - 2024-09-04 18:48:39 --> Language Class Initialized
INFO - 2024-09-04 18:48:39 --> Loader Class Initialized
INFO - 2024-09-04 18:48:39 --> Helper loaded: url_helper
INFO - 2024-09-04 18:48:39 --> Helper loaded: file_helper
INFO - 2024-09-04 18:48:39 --> Helper loaded: security_helper
INFO - 2024-09-04 18:48:39 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:48:39 --> Database Driver Class Initialized
INFO - 2024-09-04 18:48:39 --> Email Class Initialized
DEBUG - 2024-09-04 18:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:48:39 --> Helper loaded: form_helper
INFO - 2024-09-04 18:48:39 --> Form Validation Class Initialized
INFO - 2024-09-04 18:48:39 --> Controller Class Initialized
INFO - 2024-09-04 18:48:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:48:41 --> Final output sent to browser
DEBUG - 2024-09-04 18:48:41 --> Total execution time: 2.3042
INFO - 2024-09-04 18:49:22 --> Config Class Initialized
INFO - 2024-09-04 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:49:22 --> Utf8 Class Initialized
INFO - 2024-09-04 18:49:22 --> URI Class Initialized
INFO - 2024-09-04 18:49:22 --> Router Class Initialized
INFO - 2024-09-04 18:49:22 --> Output Class Initialized
INFO - 2024-09-04 18:49:22 --> Security Class Initialized
DEBUG - 2024-09-04 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:49:22 --> Input Class Initialized
INFO - 2024-09-04 18:49:22 --> Language Class Initialized
INFO - 2024-09-04 18:49:22 --> Loader Class Initialized
INFO - 2024-09-04 18:49:22 --> Helper loaded: url_helper
INFO - 2024-09-04 18:49:22 --> Helper loaded: file_helper
INFO - 2024-09-04 18:49:22 --> Helper loaded: security_helper
INFO - 2024-09-04 18:49:22 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:49:22 --> Database Driver Class Initialized
INFO - 2024-09-04 18:49:22 --> Email Class Initialized
DEBUG - 2024-09-04 18:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:49:22 --> Helper loaded: form_helper
INFO - 2024-09-04 18:49:22 --> Form Validation Class Initialized
INFO - 2024-09-04 18:49:22 --> Controller Class Initialized
INFO - 2024-09-04 18:49:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:49:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:49:23 --> Final output sent to browser
DEBUG - 2024-09-04 18:49:23 --> Total execution time: 0.4859
INFO - 2024-09-04 18:49:24 --> Config Class Initialized
INFO - 2024-09-04 18:49:24 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:49:24 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:49:24 --> Utf8 Class Initialized
INFO - 2024-09-04 18:49:24 --> URI Class Initialized
INFO - 2024-09-04 18:49:24 --> Router Class Initialized
INFO - 2024-09-04 18:49:24 --> Output Class Initialized
INFO - 2024-09-04 18:49:24 --> Security Class Initialized
DEBUG - 2024-09-04 18:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:49:24 --> Input Class Initialized
INFO - 2024-09-04 18:49:24 --> Language Class Initialized
INFO - 2024-09-04 18:49:24 --> Loader Class Initialized
INFO - 2024-09-04 18:49:24 --> Helper loaded: url_helper
INFO - 2024-09-04 18:49:24 --> Helper loaded: file_helper
INFO - 2024-09-04 18:49:24 --> Helper loaded: security_helper
INFO - 2024-09-04 18:49:24 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:49:24 --> Database Driver Class Initialized
INFO - 2024-09-04 18:49:24 --> Email Class Initialized
DEBUG - 2024-09-04 18:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:49:24 --> Helper loaded: form_helper
INFO - 2024-09-04 18:49:24 --> Form Validation Class Initialized
INFO - 2024-09-04 18:49:24 --> Controller Class Initialized
INFO - 2024-09-04 18:49:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:49:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:49:25 --> Final output sent to browser
DEBUG - 2024-09-04 18:49:25 --> Total execution time: 0.7938
INFO - 2024-09-04 18:49:28 --> Config Class Initialized
INFO - 2024-09-04 18:49:28 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:49:28 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:49:28 --> Utf8 Class Initialized
INFO - 2024-09-04 18:49:28 --> URI Class Initialized
INFO - 2024-09-04 18:49:28 --> Router Class Initialized
INFO - 2024-09-04 18:49:28 --> Output Class Initialized
INFO - 2024-09-04 18:49:28 --> Security Class Initialized
DEBUG - 2024-09-04 18:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:49:28 --> Input Class Initialized
INFO - 2024-09-04 18:49:28 --> Language Class Initialized
ERROR - 2024-09-04 18:49:28 --> 404 Page Not Found: /index
INFO - 2024-09-04 18:49:31 --> Config Class Initialized
INFO - 2024-09-04 18:49:31 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:49:31 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:49:31 --> Utf8 Class Initialized
INFO - 2024-09-04 18:49:31 --> URI Class Initialized
INFO - 2024-09-04 18:49:31 --> Router Class Initialized
INFO - 2024-09-04 18:49:31 --> Output Class Initialized
INFO - 2024-09-04 18:49:31 --> Security Class Initialized
DEBUG - 2024-09-04 18:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:49:31 --> Input Class Initialized
INFO - 2024-09-04 18:49:31 --> Language Class Initialized
INFO - 2024-09-04 18:49:31 --> Loader Class Initialized
INFO - 2024-09-04 18:49:31 --> Helper loaded: url_helper
INFO - 2024-09-04 18:49:31 --> Helper loaded: file_helper
INFO - 2024-09-04 18:49:31 --> Helper loaded: security_helper
INFO - 2024-09-04 18:49:31 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:49:31 --> Database Driver Class Initialized
INFO - 2024-09-04 18:49:31 --> Email Class Initialized
DEBUG - 2024-09-04 18:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:49:31 --> Helper loaded: form_helper
INFO - 2024-09-04 18:49:31 --> Form Validation Class Initialized
INFO - 2024-09-04 18:49:31 --> Controller Class Initialized
INFO - 2024-09-04 18:49:31 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:49:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:49:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:49:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:49:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:49:31 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:49:31 --> Final output sent to browser
DEBUG - 2024-09-04 18:49:31 --> Total execution time: 0.0843
INFO - 2024-09-04 18:50:53 --> Config Class Initialized
INFO - 2024-09-04 18:50:53 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:50:53 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:50:53 --> Utf8 Class Initialized
INFO - 2024-09-04 18:50:53 --> URI Class Initialized
INFO - 2024-09-04 18:50:53 --> Router Class Initialized
INFO - 2024-09-04 18:50:53 --> Output Class Initialized
INFO - 2024-09-04 18:50:53 --> Security Class Initialized
DEBUG - 2024-09-04 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:50:53 --> Input Class Initialized
INFO - 2024-09-04 18:50:53 --> Language Class Initialized
INFO - 2024-09-04 18:50:53 --> Loader Class Initialized
INFO - 2024-09-04 18:50:53 --> Helper loaded: url_helper
INFO - 2024-09-04 18:50:53 --> Helper loaded: file_helper
INFO - 2024-09-04 18:50:53 --> Helper loaded: security_helper
INFO - 2024-09-04 18:50:53 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:50:53 --> Database Driver Class Initialized
INFO - 2024-09-04 18:50:53 --> Email Class Initialized
DEBUG - 2024-09-04 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:50:53 --> Helper loaded: form_helper
INFO - 2024-09-04 18:50:53 --> Form Validation Class Initialized
INFO - 2024-09-04 18:50:53 --> Controller Class Initialized
INFO - 2024-09-04 18:50:53 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:50:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:50:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:50:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:50:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:50:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:50:53 --> Final output sent to browser
DEBUG - 2024-09-04 18:50:53 --> Total execution time: 0.1280
INFO - 2024-09-04 18:51:27 --> Config Class Initialized
INFO - 2024-09-04 18:51:27 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:51:27 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:51:27 --> Utf8 Class Initialized
INFO - 2024-09-04 18:51:27 --> URI Class Initialized
INFO - 2024-09-04 18:51:27 --> Router Class Initialized
INFO - 2024-09-04 18:51:27 --> Output Class Initialized
INFO - 2024-09-04 18:51:27 --> Security Class Initialized
DEBUG - 2024-09-04 18:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:51:27 --> Input Class Initialized
INFO - 2024-09-04 18:51:27 --> Language Class Initialized
INFO - 2024-09-04 18:51:27 --> Loader Class Initialized
INFO - 2024-09-04 18:51:27 --> Helper loaded: url_helper
INFO - 2024-09-04 18:51:27 --> Helper loaded: file_helper
INFO - 2024-09-04 18:51:27 --> Helper loaded: security_helper
INFO - 2024-09-04 18:51:27 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:51:27 --> Database Driver Class Initialized
INFO - 2024-09-04 18:51:27 --> Email Class Initialized
DEBUG - 2024-09-04 18:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:51:27 --> Helper loaded: form_helper
INFO - 2024-09-04 18:51:27 --> Form Validation Class Initialized
INFO - 2024-09-04 18:51:27 --> Controller Class Initialized
INFO - 2024-09-04 18:51:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:51:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:51:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:51:27 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:51:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:51:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:51:28 --> Final output sent to browser
DEBUG - 2024-09-04 18:51:28 --> Total execution time: 0.1324
INFO - 2024-09-04 18:52:26 --> Config Class Initialized
INFO - 2024-09-04 18:52:26 --> Hooks Class Initialized
DEBUG - 2024-09-04 18:52:26 --> UTF-8 Support Enabled
INFO - 2024-09-04 18:52:26 --> Utf8 Class Initialized
INFO - 2024-09-04 18:52:26 --> URI Class Initialized
INFO - 2024-09-04 18:52:26 --> Router Class Initialized
INFO - 2024-09-04 18:52:26 --> Output Class Initialized
INFO - 2024-09-04 18:52:26 --> Security Class Initialized
DEBUG - 2024-09-04 18:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-04 18:52:26 --> Input Class Initialized
INFO - 2024-09-04 18:52:26 --> Language Class Initialized
INFO - 2024-09-04 18:52:26 --> Loader Class Initialized
INFO - 2024-09-04 18:52:26 --> Helper loaded: url_helper
INFO - 2024-09-04 18:52:26 --> Helper loaded: file_helper
INFO - 2024-09-04 18:52:26 --> Helper loaded: security_helper
INFO - 2024-09-04 18:52:26 --> Helper loaded: wpu_helper
INFO - 2024-09-04 18:52:26 --> Database Driver Class Initialized
INFO - 2024-09-04 18:52:26 --> Email Class Initialized
DEBUG - 2024-09-04 18:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-04 18:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-04 18:52:26 --> Helper loaded: form_helper
INFO - 2024-09-04 18:52:26 --> Form Validation Class Initialized
INFO - 2024-09-04 18:52:26 --> Controller Class Initialized
INFO - 2024-09-04 18:52:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-04 18:52:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-04 18:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-04 18:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-04 18:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-04 18:52:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-04 18:52:26 --> Final output sent to browser
DEBUG - 2024-09-04 18:52:26 --> Total execution time: 0.1010
