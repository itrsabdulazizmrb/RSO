<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-13 01:35:46 --> Config Class Initialized
INFO - 2024-11-13 01:35:46 --> Hooks Class Initialized
DEBUG - 2024-11-13 01:35:46 --> UTF-8 Support Enabled
INFO - 2024-11-13 01:35:46 --> Utf8 Class Initialized
INFO - 2024-11-13 01:35:46 --> URI Class Initialized
DEBUG - 2024-11-13 01:35:46 --> No URI present. Default controller set.
INFO - 2024-11-13 01:35:46 --> Router Class Initialized
INFO - 2024-11-13 01:35:46 --> Output Class Initialized
INFO - 2024-11-13 01:35:46 --> Security Class Initialized
DEBUG - 2024-11-13 01:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 01:35:46 --> Input Class Initialized
INFO - 2024-11-13 01:35:46 --> Language Class Initialized
INFO - 2024-11-13 01:35:46 --> Loader Class Initialized
INFO - 2024-11-13 01:35:46 --> Helper loaded: url_helper
INFO - 2024-11-13 01:35:46 --> Helper loaded: file_helper
INFO - 2024-11-13 01:35:46 --> Helper loaded: security_helper
INFO - 2024-11-13 01:35:46 --> Helper loaded: wpu_helper
INFO - 2024-11-13 01:35:46 --> Database Driver Class Initialized
INFO - 2024-11-13 01:35:46 --> Email Class Initialized
DEBUG - 2024-11-13 01:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 01:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 01:35:46 --> Helper loaded: form_helper
INFO - 2024-11-13 01:35:46 --> Form Validation Class Initialized
INFO - 2024-11-13 01:35:46 --> Controller Class Initialized
DEBUG - 2024-11-13 01:35:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 01:35:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 01:35:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 01:35:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 01:35:46 --> Final output sent to browser
DEBUG - 2024-11-13 01:35:46 --> Total execution time: 0.3104
INFO - 2024-11-13 01:35:49 --> Config Class Initialized
INFO - 2024-11-13 01:35:49 --> Hooks Class Initialized
DEBUG - 2024-11-13 01:35:49 --> UTF-8 Support Enabled
INFO - 2024-11-13 01:35:49 --> Utf8 Class Initialized
INFO - 2024-11-13 01:35:49 --> URI Class Initialized
INFO - 2024-11-13 01:35:49 --> Router Class Initialized
INFO - 2024-11-13 01:35:49 --> Output Class Initialized
INFO - 2024-11-13 01:35:49 --> Security Class Initialized
DEBUG - 2024-11-13 01:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 01:35:49 --> Input Class Initialized
INFO - 2024-11-13 01:35:49 --> Language Class Initialized
INFO - 2024-11-13 01:35:49 --> Loader Class Initialized
INFO - 2024-11-13 01:35:49 --> Helper loaded: url_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: file_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: security_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: wpu_helper
INFO - 2024-11-13 01:35:49 --> Database Driver Class Initialized
INFO - 2024-11-13 01:35:49 --> Email Class Initialized
DEBUG - 2024-11-13 01:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 01:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 01:35:49 --> Helper loaded: form_helper
INFO - 2024-11-13 01:35:49 --> Form Validation Class Initialized
INFO - 2024-11-13 01:35:49 --> Controller Class Initialized
DEBUG - 2024-11-13 01:35:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 01:35:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-13 01:35:49 --> Config Class Initialized
INFO - 2024-11-13 01:35:49 --> Hooks Class Initialized
DEBUG - 2024-11-13 01:35:49 --> UTF-8 Support Enabled
INFO - 2024-11-13 01:35:49 --> Utf8 Class Initialized
INFO - 2024-11-13 01:35:49 --> URI Class Initialized
INFO - 2024-11-13 01:35:49 --> Router Class Initialized
INFO - 2024-11-13 01:35:49 --> Output Class Initialized
INFO - 2024-11-13 01:35:49 --> Security Class Initialized
DEBUG - 2024-11-13 01:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 01:35:49 --> Input Class Initialized
INFO - 2024-11-13 01:35:49 --> Language Class Initialized
INFO - 2024-11-13 01:35:49 --> Loader Class Initialized
INFO - 2024-11-13 01:35:49 --> Helper loaded: url_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: file_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: security_helper
INFO - 2024-11-13 01:35:49 --> Helper loaded: wpu_helper
INFO - 2024-11-13 01:35:49 --> Database Driver Class Initialized
INFO - 2024-11-13 01:35:49 --> Email Class Initialized
DEBUG - 2024-11-13 01:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 01:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 01:35:49 --> Helper loaded: form_helper
INFO - 2024-11-13 01:35:49 --> Form Validation Class Initialized
INFO - 2024-11-13 01:35:49 --> Controller Class Initialized
INFO - 2024-11-13 01:35:49 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 01:35:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 01:35:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 01:35:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 01:35:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-13 01:35:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 01:35:50 --> Final output sent to browser
DEBUG - 2024-11-13 01:35:50 --> Total execution time: 0.7424
INFO - 2024-11-13 06:51:25 --> Config Class Initialized
INFO - 2024-11-13 06:51:25 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:51:25 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:51:25 --> Utf8 Class Initialized
INFO - 2024-11-13 06:51:25 --> URI Class Initialized
DEBUG - 2024-11-13 06:51:25 --> No URI present. Default controller set.
INFO - 2024-11-13 06:51:25 --> Router Class Initialized
INFO - 2024-11-13 06:51:25 --> Output Class Initialized
INFO - 2024-11-13 06:51:25 --> Security Class Initialized
DEBUG - 2024-11-13 06:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:51:25 --> Input Class Initialized
INFO - 2024-11-13 06:51:25 --> Language Class Initialized
INFO - 2024-11-13 06:51:25 --> Loader Class Initialized
INFO - 2024-11-13 06:51:25 --> Helper loaded: url_helper
INFO - 2024-11-13 06:51:25 --> Helper loaded: file_helper
INFO - 2024-11-13 06:51:25 --> Helper loaded: security_helper
INFO - 2024-11-13 06:51:25 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:51:25 --> Database Driver Class Initialized
INFO - 2024-11-13 06:51:26 --> Email Class Initialized
DEBUG - 2024-11-13 06:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:51:26 --> Helper loaded: form_helper
INFO - 2024-11-13 06:51:26 --> Form Validation Class Initialized
INFO - 2024-11-13 06:51:26 --> Controller Class Initialized
DEBUG - 2024-11-13 06:51:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:51:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 06:51:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 06:51:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 06:51:26 --> Final output sent to browser
DEBUG - 2024-11-13 06:51:26 --> Total execution time: 0.4248
INFO - 2024-11-13 06:51:29 --> Config Class Initialized
INFO - 2024-11-13 06:51:29 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:51:29 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:51:29 --> Utf8 Class Initialized
INFO - 2024-11-13 06:51:29 --> URI Class Initialized
INFO - 2024-11-13 06:51:29 --> Router Class Initialized
INFO - 2024-11-13 06:51:29 --> Output Class Initialized
INFO - 2024-11-13 06:51:29 --> Security Class Initialized
DEBUG - 2024-11-13 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:51:29 --> Input Class Initialized
INFO - 2024-11-13 06:51:29 --> Language Class Initialized
INFO - 2024-11-13 06:51:29 --> Loader Class Initialized
INFO - 2024-11-13 06:51:29 --> Helper loaded: url_helper
INFO - 2024-11-13 06:51:29 --> Helper loaded: file_helper
INFO - 2024-11-13 06:51:29 --> Helper loaded: security_helper
INFO - 2024-11-13 06:51:29 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:51:29 --> Database Driver Class Initialized
INFO - 2024-11-13 06:51:30 --> Email Class Initialized
DEBUG - 2024-11-13 06:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:51:30 --> Helper loaded: form_helper
INFO - 2024-11-13 06:51:30 --> Form Validation Class Initialized
INFO - 2024-11-13 06:51:30 --> Controller Class Initialized
DEBUG - 2024-11-13 06:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:51:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-13 06:51:30 --> Config Class Initialized
INFO - 2024-11-13 06:51:30 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:51:30 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:51:30 --> Utf8 Class Initialized
INFO - 2024-11-13 06:51:30 --> URI Class Initialized
INFO - 2024-11-13 06:51:30 --> Router Class Initialized
INFO - 2024-11-13 06:51:30 --> Output Class Initialized
INFO - 2024-11-13 06:51:30 --> Security Class Initialized
DEBUG - 2024-11-13 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:51:30 --> Input Class Initialized
INFO - 2024-11-13 06:51:30 --> Language Class Initialized
INFO - 2024-11-13 06:51:30 --> Loader Class Initialized
INFO - 2024-11-13 06:51:30 --> Helper loaded: url_helper
INFO - 2024-11-13 06:51:30 --> Helper loaded: file_helper
INFO - 2024-11-13 06:51:30 --> Helper loaded: security_helper
INFO - 2024-11-13 06:51:30 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:51:30 --> Database Driver Class Initialized
INFO - 2024-11-13 06:51:30 --> Email Class Initialized
DEBUG - 2024-11-13 06:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:51:30 --> Helper loaded: form_helper
INFO - 2024-11-13 06:51:30 --> Form Validation Class Initialized
INFO - 2024-11-13 06:51:30 --> Controller Class Initialized
INFO - 2024-11-13 06:51:30 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-13 06:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:51:31 --> Final output sent to browser
DEBUG - 2024-11-13 06:51:31 --> Total execution time: 1.0358
INFO - 2024-11-13 06:58:01 --> Config Class Initialized
INFO - 2024-11-13 06:58:01 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:01 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:01 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:01 --> URI Class Initialized
DEBUG - 2024-11-13 06:58:01 --> No URI present. Default controller set.
INFO - 2024-11-13 06:58:01 --> Router Class Initialized
INFO - 2024-11-13 06:58:01 --> Output Class Initialized
INFO - 2024-11-13 06:58:01 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:01 --> Input Class Initialized
INFO - 2024-11-13 06:58:01 --> Language Class Initialized
INFO - 2024-11-13 06:58:01 --> Loader Class Initialized
INFO - 2024-11-13 06:58:01 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:01 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:01 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:01 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:01 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:02 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:02 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:02 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:02 --> Controller Class Initialized
DEBUG - 2024-11-13 06:58:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 06:58:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 06:58:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 06:58:02 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:02 --> Total execution time: 0.4063
INFO - 2024-11-13 06:58:13 --> Config Class Initialized
INFO - 2024-11-13 06:58:13 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:13 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:13 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:13 --> URI Class Initialized
INFO - 2024-11-13 06:58:13 --> Router Class Initialized
INFO - 2024-11-13 06:58:13 --> Output Class Initialized
INFO - 2024-11-13 06:58:13 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:13 --> Input Class Initialized
INFO - 2024-11-13 06:58:13 --> Language Class Initialized
INFO - 2024-11-13 06:58:13 --> Loader Class Initialized
INFO - 2024-11-13 06:58:13 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:13 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:13 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:13 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:13 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:13 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:13 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:13 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:13 --> Controller Class Initialized
DEBUG - 2024-11-13 06:58:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-13 06:58:14 --> Config Class Initialized
INFO - 2024-11-13 06:58:14 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:14 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:14 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:14 --> URI Class Initialized
INFO - 2024-11-13 06:58:14 --> Router Class Initialized
INFO - 2024-11-13 06:58:14 --> Output Class Initialized
INFO - 2024-11-13 06:58:14 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:14 --> Input Class Initialized
INFO - 2024-11-13 06:58:14 --> Language Class Initialized
INFO - 2024-11-13 06:58:14 --> Loader Class Initialized
INFO - 2024-11-13 06:58:14 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:14 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:14 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:14 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:14 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:14 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:14 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:14 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:14 --> Controller Class Initialized
INFO - 2024-11-13 06:58:14 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:58:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:58:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:58:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-13 06:58:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:58:15 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:15 --> Total execution time: 1.0816
INFO - 2024-11-13 06:58:15 --> Config Class Initialized
INFO - 2024-11-13 06:58:15 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:15 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:15 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:15 --> URI Class Initialized
INFO - 2024-11-13 06:58:15 --> Router Class Initialized
INFO - 2024-11-13 06:58:15 --> Output Class Initialized
INFO - 2024-11-13 06:58:15 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:15 --> Input Class Initialized
INFO - 2024-11-13 06:58:15 --> Language Class Initialized
INFO - 2024-11-13 06:58:15 --> Loader Class Initialized
INFO - 2024-11-13 06:58:15 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:15 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:15 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:15 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:15 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:16 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:16 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:16 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:16 --> Controller Class Initialized
INFO - 2024-11-13 06:58:16 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:58:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:58:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:58:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:58:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:58:16 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:16 --> Total execution time: 0.9290
INFO - 2024-11-13 06:58:23 --> Config Class Initialized
INFO - 2024-11-13 06:58:23 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:23 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:23 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:23 --> URI Class Initialized
INFO - 2024-11-13 06:58:23 --> Router Class Initialized
INFO - 2024-11-13 06:58:23 --> Output Class Initialized
INFO - 2024-11-13 06:58:23 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:23 --> Input Class Initialized
INFO - 2024-11-13 06:58:23 --> Language Class Initialized
INFO - 2024-11-13 06:58:23 --> Loader Class Initialized
INFO - 2024-11-13 06:58:23 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:23 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:23 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:23 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:23 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:23 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:23 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:23 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:23 --> Controller Class Initialized
INFO - 2024-11-13 06:58:23 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:58:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:58:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:58:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:58:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:58:24 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:24 --> Total execution time: 1.0313
INFO - 2024-11-13 06:58:25 --> Config Class Initialized
INFO - 2024-11-13 06:58:25 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:25 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:25 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:25 --> URI Class Initialized
INFO - 2024-11-13 06:58:25 --> Router Class Initialized
INFO - 2024-11-13 06:58:25 --> Output Class Initialized
INFO - 2024-11-13 06:58:25 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:25 --> Input Class Initialized
INFO - 2024-11-13 06:58:25 --> Language Class Initialized
INFO - 2024-11-13 06:58:25 --> Loader Class Initialized
INFO - 2024-11-13 06:58:25 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:25 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:25 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:25 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:25 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:26 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:26 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:26 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:26 --> Controller Class Initialized
INFO - 2024-11-13 06:58:26 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:26 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:26 --> Total execution time: 0.6767
INFO - 2024-11-13 06:58:37 --> Config Class Initialized
INFO - 2024-11-13 06:58:37 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:58:37 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:58:37 --> Utf8 Class Initialized
INFO - 2024-11-13 06:58:37 --> URI Class Initialized
INFO - 2024-11-13 06:58:37 --> Router Class Initialized
INFO - 2024-11-13 06:58:37 --> Output Class Initialized
INFO - 2024-11-13 06:58:37 --> Security Class Initialized
DEBUG - 2024-11-13 06:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:58:37 --> Input Class Initialized
INFO - 2024-11-13 06:58:37 --> Language Class Initialized
INFO - 2024-11-13 06:58:37 --> Loader Class Initialized
INFO - 2024-11-13 06:58:37 --> Helper loaded: url_helper
INFO - 2024-11-13 06:58:37 --> Helper loaded: file_helper
INFO - 2024-11-13 06:58:37 --> Helper loaded: security_helper
INFO - 2024-11-13 06:58:37 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:58:37 --> Database Driver Class Initialized
INFO - 2024-11-13 06:58:37 --> Email Class Initialized
DEBUG - 2024-11-13 06:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:58:37 --> Helper loaded: form_helper
INFO - 2024-11-13 06:58:37 --> Form Validation Class Initialized
INFO - 2024-11-13 06:58:37 --> Controller Class Initialized
INFO - 2024-11-13 06:58:37 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:58:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:58:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:58:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:58:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:58:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:58:37 --> Final output sent to browser
DEBUG - 2024-11-13 06:58:37 --> Total execution time: 0.9163
INFO - 2024-11-13 06:59:01 --> Config Class Initialized
INFO - 2024-11-13 06:59:01 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:01 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:01 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:01 --> URI Class Initialized
INFO - 2024-11-13 06:59:01 --> Router Class Initialized
INFO - 2024-11-13 06:59:01 --> Output Class Initialized
INFO - 2024-11-13 06:59:01 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:01 --> Input Class Initialized
INFO - 2024-11-13 06:59:01 --> Language Class Initialized
INFO - 2024-11-13 06:59:01 --> Loader Class Initialized
INFO - 2024-11-13 06:59:01 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:01 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:01 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:01 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:01 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:02 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:02 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:02 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:02 --> Controller Class Initialized
INFO - 2024-11-13 06:59:02 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:59:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:59:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:59:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:59:02 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:02 --> Total execution time: 0.8834
INFO - 2024-11-13 06:59:12 --> Config Class Initialized
INFO - 2024-11-13 06:59:12 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:12 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:12 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:12 --> URI Class Initialized
INFO - 2024-11-13 06:59:12 --> Router Class Initialized
INFO - 2024-11-13 06:59:12 --> Output Class Initialized
INFO - 2024-11-13 06:59:12 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:12 --> Input Class Initialized
INFO - 2024-11-13 06:59:12 --> Language Class Initialized
INFO - 2024-11-13 06:59:12 --> Loader Class Initialized
INFO - 2024-11-13 06:59:12 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:12 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:12 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:12 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:12 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:12 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:12 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:12 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:12 --> Controller Class Initialized
INFO - 2024-11-13 06:59:12 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:14 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:14 --> Total execution time: 2.2482
INFO - 2024-11-13 06:59:15 --> Config Class Initialized
INFO - 2024-11-13 06:59:15 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:15 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:15 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:15 --> URI Class Initialized
INFO - 2024-11-13 06:59:15 --> Router Class Initialized
INFO - 2024-11-13 06:59:15 --> Output Class Initialized
INFO - 2024-11-13 06:59:15 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:15 --> Input Class Initialized
INFO - 2024-11-13 06:59:15 --> Language Class Initialized
INFO - 2024-11-13 06:59:15 --> Loader Class Initialized
INFO - 2024-11-13 06:59:15 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:15 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:15 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:15 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:15 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:15 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:15 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:15 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:15 --> Controller Class Initialized
INFO - 2024-11-13 06:59:15 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:59:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:59:15 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:15 --> Total execution time: 0.9101
INFO - 2024-11-13 06:59:16 --> Config Class Initialized
INFO - 2024-11-13 06:59:16 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:16 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:16 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:16 --> URI Class Initialized
INFO - 2024-11-13 06:59:16 --> Router Class Initialized
INFO - 2024-11-13 06:59:16 --> Output Class Initialized
INFO - 2024-11-13 06:59:16 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:16 --> Input Class Initialized
INFO - 2024-11-13 06:59:16 --> Language Class Initialized
INFO - 2024-11-13 06:59:16 --> Loader Class Initialized
INFO - 2024-11-13 06:59:16 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:16 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:16 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:16 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:16 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:17 --> Config Class Initialized
INFO - 2024-11-13 06:59:17 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:17 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:17 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:17 --> URI Class Initialized
INFO - 2024-11-13 06:59:17 --> Router Class Initialized
INFO - 2024-11-13 06:59:17 --> Output Class Initialized
INFO - 2024-11-13 06:59:17 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:17 --> Input Class Initialized
INFO - 2024-11-13 06:59:17 --> Language Class Initialized
INFO - 2024-11-13 06:59:17 --> Loader Class Initialized
INFO - 2024-11-13 06:59:17 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:17 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:17 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:17 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:17 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:17 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:17 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:17 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:17 --> Controller Class Initialized
INFO - 2024-11-13 06:59:17 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:17 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:17 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:17 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:17 --> Controller Class Initialized
INFO - 2024-11-13 06:59:17 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:59:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:59:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 06:59:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:59:17 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:17 --> Total execution time: 0.8728
INFO - 2024-11-13 06:59:17 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:17 --> Total execution time: 0.8999
INFO - 2024-11-13 06:59:20 --> Config Class Initialized
INFO - 2024-11-13 06:59:20 --> Hooks Class Initialized
DEBUG - 2024-11-13 06:59:20 --> UTF-8 Support Enabled
INFO - 2024-11-13 06:59:20 --> Utf8 Class Initialized
INFO - 2024-11-13 06:59:20 --> URI Class Initialized
INFO - 2024-11-13 06:59:20 --> Router Class Initialized
INFO - 2024-11-13 06:59:20 --> Output Class Initialized
INFO - 2024-11-13 06:59:20 --> Security Class Initialized
DEBUG - 2024-11-13 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 06:59:20 --> Input Class Initialized
INFO - 2024-11-13 06:59:20 --> Language Class Initialized
INFO - 2024-11-13 06:59:20 --> Loader Class Initialized
INFO - 2024-11-13 06:59:20 --> Helper loaded: url_helper
INFO - 2024-11-13 06:59:20 --> Helper loaded: file_helper
INFO - 2024-11-13 06:59:20 --> Helper loaded: security_helper
INFO - 2024-11-13 06:59:20 --> Helper loaded: wpu_helper
INFO - 2024-11-13 06:59:20 --> Database Driver Class Initialized
INFO - 2024-11-13 06:59:20 --> Email Class Initialized
DEBUG - 2024-11-13 06:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 06:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 06:59:20 --> Helper loaded: form_helper
INFO - 2024-11-13 06:59:20 --> Form Validation Class Initialized
INFO - 2024-11-13 06:59:20 --> Controller Class Initialized
INFO - 2024-11-13 06:59:20 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 06:59:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 06:59:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 06:59:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 06:59:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-13 06:59:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 06:59:21 --> Final output sent to browser
DEBUG - 2024-11-13 06:59:21 --> Total execution time: 1.1036
INFO - 2024-11-13 07:00:14 --> Config Class Initialized
INFO - 2024-11-13 07:00:14 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:00:14 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:00:14 --> Utf8 Class Initialized
INFO - 2024-11-13 07:00:14 --> URI Class Initialized
INFO - 2024-11-13 07:00:14 --> Router Class Initialized
INFO - 2024-11-13 07:00:14 --> Output Class Initialized
INFO - 2024-11-13 07:00:14 --> Security Class Initialized
DEBUG - 2024-11-13 07:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:00:14 --> Input Class Initialized
INFO - 2024-11-13 07:00:14 --> Language Class Initialized
INFO - 2024-11-13 07:00:14 --> Loader Class Initialized
INFO - 2024-11-13 07:00:14 --> Helper loaded: url_helper
INFO - 2024-11-13 07:00:14 --> Helper loaded: file_helper
INFO - 2024-11-13 07:00:14 --> Helper loaded: security_helper
INFO - 2024-11-13 07:00:14 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:00:14 --> Database Driver Class Initialized
INFO - 2024-11-13 07:00:15 --> Email Class Initialized
DEBUG - 2024-11-13 07:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:00:15 --> Helper loaded: form_helper
INFO - 2024-11-13 07:00:15 --> Form Validation Class Initialized
INFO - 2024-11-13 07:00:15 --> Controller Class Initialized
INFO - 2024-11-13 07:00:15 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 07:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:00:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 07:00:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 07:00:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 07:00:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 07:00:15 --> Final output sent to browser
DEBUG - 2024-11-13 07:00:15 --> Total execution time: 1.3992
INFO - 2024-11-13 07:00:17 --> Config Class Initialized
INFO - 2024-11-13 07:00:17 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:00:17 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:00:17 --> Utf8 Class Initialized
INFO - 2024-11-13 07:00:17 --> URI Class Initialized
INFO - 2024-11-13 07:00:17 --> Router Class Initialized
INFO - 2024-11-13 07:00:17 --> Output Class Initialized
INFO - 2024-11-13 07:00:17 --> Security Class Initialized
DEBUG - 2024-11-13 07:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:00:17 --> Input Class Initialized
INFO - 2024-11-13 07:00:17 --> Language Class Initialized
INFO - 2024-11-13 07:00:17 --> Loader Class Initialized
INFO - 2024-11-13 07:00:17 --> Helper loaded: url_helper
INFO - 2024-11-13 07:00:17 --> Helper loaded: file_helper
INFO - 2024-11-13 07:00:17 --> Helper loaded: security_helper
INFO - 2024-11-13 07:00:17 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:00:17 --> Database Driver Class Initialized
INFO - 2024-11-13 07:00:18 --> Email Class Initialized
DEBUG - 2024-11-13 07:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:00:18 --> Helper loaded: form_helper
INFO - 2024-11-13 07:00:18 --> Form Validation Class Initialized
INFO - 2024-11-13 07:00:18 --> Controller Class Initialized
INFO - 2024-11-13 07:00:18 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 07:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:00:19 --> Final output sent to browser
DEBUG - 2024-11-13 07:00:19 --> Total execution time: 2.1564
INFO - 2024-11-13 07:00:38 --> Config Class Initialized
INFO - 2024-11-13 07:00:38 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:00:38 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:00:38 --> Utf8 Class Initialized
INFO - 2024-11-13 07:00:38 --> URI Class Initialized
INFO - 2024-11-13 07:00:38 --> Router Class Initialized
INFO - 2024-11-13 07:00:38 --> Output Class Initialized
INFO - 2024-11-13 07:00:38 --> Security Class Initialized
DEBUG - 2024-11-13 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:00:38 --> Input Class Initialized
INFO - 2024-11-13 07:00:38 --> Language Class Initialized
INFO - 2024-11-13 07:00:38 --> Loader Class Initialized
INFO - 2024-11-13 07:00:38 --> Helper loaded: url_helper
INFO - 2024-11-13 07:00:38 --> Helper loaded: file_helper
INFO - 2024-11-13 07:00:38 --> Helper loaded: security_helper
INFO - 2024-11-13 07:00:38 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:00:38 --> Database Driver Class Initialized
INFO - 2024-11-13 07:00:38 --> Email Class Initialized
DEBUG - 2024-11-13 07:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:00:38 --> Helper loaded: form_helper
INFO - 2024-11-13 07:00:38 --> Form Validation Class Initialized
INFO - 2024-11-13 07:00:38 --> Controller Class Initialized
INFO - 2024-11-13 07:00:38 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 07:00:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:00:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 07:00:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 07:00:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 07:00:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 07:00:38 --> Final output sent to browser
DEBUG - 2024-11-13 07:00:38 --> Total execution time: 0.8836
INFO - 2024-11-13 07:04:06 --> Config Class Initialized
INFO - 2024-11-13 07:04:06 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:04:06 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:04:06 --> Utf8 Class Initialized
INFO - 2024-11-13 07:04:06 --> URI Class Initialized
INFO - 2024-11-13 07:04:06 --> Router Class Initialized
INFO - 2024-11-13 07:04:06 --> Output Class Initialized
INFO - 2024-11-13 07:04:06 --> Security Class Initialized
DEBUG - 2024-11-13 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:04:06 --> Input Class Initialized
INFO - 2024-11-13 07:04:06 --> Language Class Initialized
INFO - 2024-11-13 07:04:06 --> Loader Class Initialized
INFO - 2024-11-13 07:04:06 --> Helper loaded: url_helper
INFO - 2024-11-13 07:04:06 --> Helper loaded: file_helper
INFO - 2024-11-13 07:04:06 --> Helper loaded: security_helper
INFO - 2024-11-13 07:04:06 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:04:06 --> Database Driver Class Initialized
INFO - 2024-11-13 07:04:07 --> Email Class Initialized
DEBUG - 2024-11-13 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:04:07 --> Helper loaded: form_helper
INFO - 2024-11-13 07:04:07 --> Form Validation Class Initialized
INFO - 2024-11-13 07:04:07 --> Controller Class Initialized
INFO - 2024-11-13 07:04:07 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 07:04:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:04:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 07:04:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 07:04:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-13 07:04:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 07:04:07 --> Final output sent to browser
DEBUG - 2024-11-13 07:04:07 --> Total execution time: 1.0662
INFO - 2024-11-13 07:17:51 --> Config Class Initialized
INFO - 2024-11-13 07:17:51 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:17:51 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:17:51 --> Utf8 Class Initialized
INFO - 2024-11-13 07:17:51 --> URI Class Initialized
INFO - 2024-11-13 07:17:51 --> Router Class Initialized
INFO - 2024-11-13 07:17:51 --> Output Class Initialized
INFO - 2024-11-13 07:17:51 --> Security Class Initialized
DEBUG - 2024-11-13 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:17:51 --> Input Class Initialized
INFO - 2024-11-13 07:17:51 --> Language Class Initialized
INFO - 2024-11-13 07:17:51 --> Loader Class Initialized
INFO - 2024-11-13 07:17:51 --> Helper loaded: url_helper
INFO - 2024-11-13 07:17:51 --> Helper loaded: file_helper
INFO - 2024-11-13 07:17:51 --> Helper loaded: security_helper
INFO - 2024-11-13 07:17:51 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:17:51 --> Database Driver Class Initialized
INFO - 2024-11-13 07:17:52 --> Email Class Initialized
DEBUG - 2024-11-13 07:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:17:52 --> Helper loaded: form_helper
INFO - 2024-11-13 07:17:52 --> Form Validation Class Initialized
INFO - 2024-11-13 07:17:52 --> Controller Class Initialized
INFO - 2024-11-13 07:17:52 --> Model "Antrol_model" initialized
DEBUG - 2024-11-13 07:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-13 07:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-13 07:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-11-13 07:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-13 07:17:52 --> Final output sent to browser
DEBUG - 2024-11-13 07:17:52 --> Total execution time: 0.9110
INFO - 2024-11-13 07:18:54 --> Config Class Initialized
INFO - 2024-11-13 07:18:54 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:18:54 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:18:54 --> Utf8 Class Initialized
INFO - 2024-11-13 07:18:54 --> URI Class Initialized
INFO - 2024-11-13 07:18:54 --> Router Class Initialized
INFO - 2024-11-13 07:18:54 --> Output Class Initialized
INFO - 2024-11-13 07:18:54 --> Security Class Initialized
DEBUG - 2024-11-13 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:18:54 --> Input Class Initialized
INFO - 2024-11-13 07:18:54 --> Language Class Initialized
INFO - 2024-11-13 07:18:54 --> Loader Class Initialized
INFO - 2024-11-13 07:18:54 --> Helper loaded: url_helper
INFO - 2024-11-13 07:18:54 --> Helper loaded: file_helper
INFO - 2024-11-13 07:18:54 --> Helper loaded: security_helper
INFO - 2024-11-13 07:18:54 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:18:54 --> Database Driver Class Initialized
INFO - 2024-11-13 07:18:55 --> Email Class Initialized
DEBUG - 2024-11-13 07:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:18:55 --> Helper loaded: form_helper
INFO - 2024-11-13 07:18:55 --> Form Validation Class Initialized
INFO - 2024-11-13 07:18:55 --> Controller Class Initialized
DEBUG - 2024-11-13 07:18:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:18:55 --> Config Class Initialized
INFO - 2024-11-13 07:18:55 --> Hooks Class Initialized
DEBUG - 2024-11-13 07:18:55 --> UTF-8 Support Enabled
INFO - 2024-11-13 07:18:55 --> Utf8 Class Initialized
INFO - 2024-11-13 07:18:55 --> URI Class Initialized
INFO - 2024-11-13 07:18:55 --> Router Class Initialized
INFO - 2024-11-13 07:18:55 --> Output Class Initialized
INFO - 2024-11-13 07:18:55 --> Security Class Initialized
DEBUG - 2024-11-13 07:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 07:18:55 --> Input Class Initialized
INFO - 2024-11-13 07:18:55 --> Language Class Initialized
INFO - 2024-11-13 07:18:55 --> Loader Class Initialized
INFO - 2024-11-13 07:18:55 --> Helper loaded: url_helper
INFO - 2024-11-13 07:18:55 --> Helper loaded: file_helper
INFO - 2024-11-13 07:18:55 --> Helper loaded: security_helper
INFO - 2024-11-13 07:18:55 --> Helper loaded: wpu_helper
INFO - 2024-11-13 07:18:55 --> Database Driver Class Initialized
INFO - 2024-11-13 07:18:56 --> Email Class Initialized
DEBUG - 2024-11-13 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 07:18:56 --> Helper loaded: form_helper
INFO - 2024-11-13 07:18:56 --> Form Validation Class Initialized
INFO - 2024-11-13 07:18:56 --> Controller Class Initialized
DEBUG - 2024-11-13 07:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 07:18:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 07:18:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 07:18:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 07:18:56 --> Final output sent to browser
DEBUG - 2024-11-13 07:18:56 --> Total execution time: 0.4301
INFO - 2024-11-13 08:16:20 --> Config Class Initialized
INFO - 2024-11-13 08:16:20 --> Hooks Class Initialized
DEBUG - 2024-11-13 08:16:20 --> UTF-8 Support Enabled
INFO - 2024-11-13 08:16:20 --> Utf8 Class Initialized
INFO - 2024-11-13 08:16:20 --> URI Class Initialized
DEBUG - 2024-11-13 08:16:20 --> No URI present. Default controller set.
INFO - 2024-11-13 08:16:20 --> Router Class Initialized
INFO - 2024-11-13 08:16:20 --> Output Class Initialized
INFO - 2024-11-13 08:16:20 --> Security Class Initialized
DEBUG - 2024-11-13 08:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 08:16:20 --> Input Class Initialized
INFO - 2024-11-13 08:16:20 --> Language Class Initialized
INFO - 2024-11-13 08:16:20 --> Loader Class Initialized
INFO - 2024-11-13 08:16:20 --> Helper loaded: url_helper
INFO - 2024-11-13 08:16:20 --> Helper loaded: file_helper
INFO - 2024-11-13 08:16:20 --> Helper loaded: security_helper
INFO - 2024-11-13 08:16:20 --> Helper loaded: wpu_helper
INFO - 2024-11-13 08:16:20 --> Database Driver Class Initialized
INFO - 2024-11-13 08:16:20 --> Email Class Initialized
DEBUG - 2024-11-13 08:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 08:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 08:16:20 --> Helper loaded: form_helper
INFO - 2024-11-13 08:16:20 --> Form Validation Class Initialized
INFO - 2024-11-13 08:16:20 --> Controller Class Initialized
DEBUG - 2024-11-13 08:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 08:16:20 --> Final output sent to browser
DEBUG - 2024-11-13 08:16:20 --> Total execution time: 0.4239
INFO - 2024-11-13 09:34:50 --> Config Class Initialized
INFO - 2024-11-13 09:34:50 --> Hooks Class Initialized
DEBUG - 2024-11-13 09:34:50 --> UTF-8 Support Enabled
INFO - 2024-11-13 09:34:50 --> Utf8 Class Initialized
INFO - 2024-11-13 09:34:50 --> URI Class Initialized
DEBUG - 2024-11-13 09:34:50 --> No URI present. Default controller set.
INFO - 2024-11-13 09:34:50 --> Router Class Initialized
INFO - 2024-11-13 09:34:50 --> Output Class Initialized
INFO - 2024-11-13 09:34:50 --> Security Class Initialized
DEBUG - 2024-11-13 09:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 09:34:50 --> Input Class Initialized
INFO - 2024-11-13 09:34:50 --> Language Class Initialized
INFO - 2024-11-13 09:34:50 --> Loader Class Initialized
INFO - 2024-11-13 09:34:50 --> Helper loaded: url_helper
INFO - 2024-11-13 09:34:50 --> Helper loaded: file_helper
INFO - 2024-11-13 09:34:50 --> Helper loaded: security_helper
INFO - 2024-11-13 09:34:50 --> Helper loaded: wpu_helper
INFO - 2024-11-13 09:34:50 --> Database Driver Class Initialized
INFO - 2024-11-13 09:34:50 --> Email Class Initialized
DEBUG - 2024-11-13 09:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 09:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 09:34:50 --> Helper loaded: form_helper
INFO - 2024-11-13 09:34:50 --> Form Validation Class Initialized
INFO - 2024-11-13 09:34:50 --> Controller Class Initialized
DEBUG - 2024-11-13 09:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 09:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 09:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 09:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 09:34:50 --> Final output sent to browser
DEBUG - 2024-11-13 09:34:50 --> Total execution time: 0.4059
INFO - 2024-11-13 09:35:08 --> Config Class Initialized
INFO - 2024-11-13 09:35:08 --> Hooks Class Initialized
DEBUG - 2024-11-13 09:35:08 --> UTF-8 Support Enabled
INFO - 2024-11-13 09:35:08 --> Utf8 Class Initialized
INFO - 2024-11-13 09:35:08 --> URI Class Initialized
DEBUG - 2024-11-13 09:35:08 --> No URI present. Default controller set.
INFO - 2024-11-13 09:35:08 --> Router Class Initialized
INFO - 2024-11-13 09:35:08 --> Output Class Initialized
INFO - 2024-11-13 09:35:08 --> Security Class Initialized
DEBUG - 2024-11-13 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-13 09:35:08 --> Input Class Initialized
INFO - 2024-11-13 09:35:08 --> Language Class Initialized
INFO - 2024-11-13 09:35:08 --> Loader Class Initialized
INFO - 2024-11-13 09:35:08 --> Helper loaded: url_helper
INFO - 2024-11-13 09:35:08 --> Helper loaded: file_helper
INFO - 2024-11-13 09:35:08 --> Helper loaded: security_helper
INFO - 2024-11-13 09:35:08 --> Helper loaded: wpu_helper
INFO - 2024-11-13 09:35:08 --> Database Driver Class Initialized
INFO - 2024-11-13 09:35:08 --> Email Class Initialized
DEBUG - 2024-11-13 09:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-13 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-13 09:35:08 --> Helper loaded: form_helper
INFO - 2024-11-13 09:35:08 --> Form Validation Class Initialized
INFO - 2024-11-13 09:35:08 --> Controller Class Initialized
DEBUG - 2024-11-13 09:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-13 09:35:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-13 09:35:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-13 09:35:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-13 09:35:08 --> Final output sent to browser
DEBUG - 2024-11-13 09:35:08 --> Total execution time: 0.4363
