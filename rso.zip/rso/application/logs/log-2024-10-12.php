<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-12 08:55:41 --> Config Class Initialized
INFO - 2024-10-12 08:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-12 08:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-12 08:55:41 --> Utf8 Class Initialized
INFO - 2024-10-12 08:55:41 --> URI Class Initialized
DEBUG - 2024-10-12 08:55:41 --> No URI present. Default controller set.
INFO - 2024-10-12 08:55:41 --> Router Class Initialized
INFO - 2024-10-12 08:55:41 --> Output Class Initialized
INFO - 2024-10-12 08:55:41 --> Security Class Initialized
DEBUG - 2024-10-12 08:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 08:55:41 --> Input Class Initialized
INFO - 2024-10-12 08:55:41 --> Language Class Initialized
INFO - 2024-10-12 08:55:41 --> Loader Class Initialized
INFO - 2024-10-12 08:55:41 --> Helper loaded: url_helper
INFO - 2024-10-12 08:55:41 --> Helper loaded: file_helper
INFO - 2024-10-12 08:55:41 --> Helper loaded: security_helper
INFO - 2024-10-12 08:55:41 --> Helper loaded: wpu_helper
INFO - 2024-10-12 08:55:41 --> Database Driver Class Initialized
INFO - 2024-10-12 08:55:41 --> Email Class Initialized
DEBUG - 2024-10-12 08:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 08:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 08:55:41 --> Helper loaded: form_helper
INFO - 2024-10-12 08:55:41 --> Form Validation Class Initialized
INFO - 2024-10-12 08:55:41 --> Controller Class Initialized
DEBUG - 2024-10-12 08:55:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 08:55:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-12 08:55:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-12 08:55:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-12 08:55:41 --> Final output sent to browser
DEBUG - 2024-10-12 08:55:41 --> Total execution time: 0.2171
INFO - 2024-10-12 20:45:49 --> Config Class Initialized
INFO - 2024-10-12 20:45:49 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:45:49 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:45:49 --> Utf8 Class Initialized
INFO - 2024-10-12 20:45:49 --> URI Class Initialized
DEBUG - 2024-10-12 20:45:49 --> No URI present. Default controller set.
INFO - 2024-10-12 20:45:49 --> Router Class Initialized
INFO - 2024-10-12 20:45:49 --> Output Class Initialized
INFO - 2024-10-12 20:45:49 --> Security Class Initialized
DEBUG - 2024-10-12 20:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:45:49 --> Input Class Initialized
INFO - 2024-10-12 20:45:49 --> Language Class Initialized
INFO - 2024-10-12 20:45:49 --> Loader Class Initialized
INFO - 2024-10-12 20:45:49 --> Helper loaded: url_helper
INFO - 2024-10-12 20:45:49 --> Helper loaded: file_helper
INFO - 2024-10-12 20:45:49 --> Helper loaded: security_helper
INFO - 2024-10-12 20:45:49 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:45:49 --> Database Driver Class Initialized
INFO - 2024-10-12 20:45:49 --> Email Class Initialized
DEBUG - 2024-10-12 20:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:45:49 --> Helper loaded: form_helper
INFO - 2024-10-12 20:45:49 --> Form Validation Class Initialized
INFO - 2024-10-12 20:45:49 --> Controller Class Initialized
DEBUG - 2024-10-12 20:45:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-12 20:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-12 20:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-12 20:45:49 --> Final output sent to browser
DEBUG - 2024-10-12 20:45:49 --> Total execution time: 0.2199
INFO - 2024-10-12 20:45:52 --> Config Class Initialized
INFO - 2024-10-12 20:45:52 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:45:52 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:45:52 --> Utf8 Class Initialized
INFO - 2024-10-12 20:45:52 --> URI Class Initialized
INFO - 2024-10-12 20:45:52 --> Router Class Initialized
INFO - 2024-10-12 20:45:52 --> Output Class Initialized
INFO - 2024-10-12 20:45:52 --> Security Class Initialized
DEBUG - 2024-10-12 20:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:45:52 --> Input Class Initialized
INFO - 2024-10-12 20:45:52 --> Language Class Initialized
INFO - 2024-10-12 20:45:52 --> Loader Class Initialized
INFO - 2024-10-12 20:45:52 --> Helper loaded: url_helper
INFO - 2024-10-12 20:45:52 --> Helper loaded: file_helper
INFO - 2024-10-12 20:45:52 --> Helper loaded: security_helper
INFO - 2024-10-12 20:45:52 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:45:52 --> Database Driver Class Initialized
INFO - 2024-10-12 20:45:53 --> Email Class Initialized
DEBUG - 2024-10-12 20:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:45:53 --> Helper loaded: form_helper
INFO - 2024-10-12 20:45:53 --> Form Validation Class Initialized
INFO - 2024-10-12 20:45:53 --> Controller Class Initialized
DEBUG - 2024-10-12 20:45:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:45:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-12 20:45:53 --> Config Class Initialized
INFO - 2024-10-12 20:45:53 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:45:53 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:45:53 --> Utf8 Class Initialized
INFO - 2024-10-12 20:45:53 --> URI Class Initialized
INFO - 2024-10-12 20:45:53 --> Router Class Initialized
INFO - 2024-10-12 20:45:53 --> Output Class Initialized
INFO - 2024-10-12 20:45:53 --> Security Class Initialized
DEBUG - 2024-10-12 20:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:45:53 --> Input Class Initialized
INFO - 2024-10-12 20:45:53 --> Language Class Initialized
INFO - 2024-10-12 20:45:53 --> Loader Class Initialized
INFO - 2024-10-12 20:45:53 --> Helper loaded: url_helper
INFO - 2024-10-12 20:45:53 --> Helper loaded: file_helper
INFO - 2024-10-12 20:45:53 --> Helper loaded: security_helper
INFO - 2024-10-12 20:45:53 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:45:53 --> Database Driver Class Initialized
INFO - 2024-10-12 20:45:53 --> Email Class Initialized
DEBUG - 2024-10-12 20:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:45:53 --> Helper loaded: form_helper
INFO - 2024-10-12 20:45:53 --> Form Validation Class Initialized
INFO - 2024-10-12 20:45:53 --> Controller Class Initialized
INFO - 2024-10-12 20:45:53 --> Model "Antrol_model" initialized
DEBUG - 2024-10-12 20:45:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:45:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-12 20:45:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-12 20:45:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-12 20:45:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-12 20:45:53 --> Final output sent to browser
DEBUG - 2024-10-12 20:45:53 --> Total execution time: 0.6782
INFO - 2024-10-12 20:54:49 --> Config Class Initialized
INFO - 2024-10-12 20:54:49 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:54:49 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:54:49 --> Utf8 Class Initialized
INFO - 2024-10-12 20:54:49 --> URI Class Initialized
DEBUG - 2024-10-12 20:54:49 --> No URI present. Default controller set.
INFO - 2024-10-12 20:54:49 --> Router Class Initialized
INFO - 2024-10-12 20:54:49 --> Output Class Initialized
INFO - 2024-10-12 20:54:49 --> Security Class Initialized
DEBUG - 2024-10-12 20:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:54:49 --> Input Class Initialized
INFO - 2024-10-12 20:54:49 --> Language Class Initialized
INFO - 2024-10-12 20:54:49 --> Loader Class Initialized
INFO - 2024-10-12 20:54:49 --> Helper loaded: url_helper
INFO - 2024-10-12 20:54:49 --> Helper loaded: file_helper
INFO - 2024-10-12 20:54:49 --> Helper loaded: security_helper
INFO - 2024-10-12 20:54:49 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:54:49 --> Database Driver Class Initialized
INFO - 2024-10-12 20:54:50 --> Email Class Initialized
DEBUG - 2024-10-12 20:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:54:50 --> Helper loaded: form_helper
INFO - 2024-10-12 20:54:50 --> Form Validation Class Initialized
INFO - 2024-10-12 20:54:50 --> Controller Class Initialized
DEBUG - 2024-10-12 20:54:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:54:50 --> Config Class Initialized
INFO - 2024-10-12 20:54:50 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:54:50 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:54:50 --> Utf8 Class Initialized
INFO - 2024-10-12 20:54:50 --> URI Class Initialized
INFO - 2024-10-12 20:54:50 --> Router Class Initialized
INFO - 2024-10-12 20:54:50 --> Output Class Initialized
INFO - 2024-10-12 20:54:50 --> Security Class Initialized
DEBUG - 2024-10-12 20:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:54:50 --> Input Class Initialized
INFO - 2024-10-12 20:54:50 --> Language Class Initialized
ERROR - 2024-10-12 20:54:50 --> 404 Page Not Found: User/index
INFO - 2024-10-12 20:54:58 --> Config Class Initialized
INFO - 2024-10-12 20:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:54:58 --> Utf8 Class Initialized
INFO - 2024-10-12 20:54:58 --> URI Class Initialized
INFO - 2024-10-12 20:54:58 --> Router Class Initialized
INFO - 2024-10-12 20:54:58 --> Output Class Initialized
INFO - 2024-10-12 20:54:58 --> Security Class Initialized
DEBUG - 2024-10-12 20:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:54:58 --> Input Class Initialized
INFO - 2024-10-12 20:54:58 --> Language Class Initialized
ERROR - 2024-10-12 20:54:58 --> 404 Page Not Found: A/index
INFO - 2024-10-12 20:55:05 --> Config Class Initialized
INFO - 2024-10-12 20:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:05 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:05 --> URI Class Initialized
DEBUG - 2024-10-12 20:55:05 --> No URI present. Default controller set.
INFO - 2024-10-12 20:55:05 --> Router Class Initialized
INFO - 2024-10-12 20:55:05 --> Output Class Initialized
INFO - 2024-10-12 20:55:05 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:05 --> Input Class Initialized
INFO - 2024-10-12 20:55:05 --> Language Class Initialized
INFO - 2024-10-12 20:55:05 --> Loader Class Initialized
INFO - 2024-10-12 20:55:05 --> Helper loaded: url_helper
INFO - 2024-10-12 20:55:05 --> Helper loaded: file_helper
INFO - 2024-10-12 20:55:05 --> Helper loaded: security_helper
INFO - 2024-10-12 20:55:05 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:55:05 --> Database Driver Class Initialized
INFO - 2024-10-12 20:55:05 --> Email Class Initialized
DEBUG - 2024-10-12 20:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:55:05 --> Helper loaded: form_helper
INFO - 2024-10-12 20:55:05 --> Form Validation Class Initialized
INFO - 2024-10-12 20:55:05 --> Controller Class Initialized
DEBUG - 2024-10-12 20:55:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:55:05 --> Config Class Initialized
INFO - 2024-10-12 20:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:05 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:05 --> URI Class Initialized
INFO - 2024-10-12 20:55:05 --> Router Class Initialized
INFO - 2024-10-12 20:55:05 --> Output Class Initialized
INFO - 2024-10-12 20:55:05 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:05 --> Input Class Initialized
INFO - 2024-10-12 20:55:05 --> Language Class Initialized
ERROR - 2024-10-12 20:55:05 --> 404 Page Not Found: User/index
INFO - 2024-10-12 20:55:12 --> Config Class Initialized
INFO - 2024-10-12 20:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:12 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:12 --> URI Class Initialized
INFO - 2024-10-12 20:55:12 --> Router Class Initialized
INFO - 2024-10-12 20:55:12 --> Output Class Initialized
INFO - 2024-10-12 20:55:12 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:12 --> Input Class Initialized
INFO - 2024-10-12 20:55:12 --> Language Class Initialized
INFO - 2024-10-12 20:55:12 --> Loader Class Initialized
INFO - 2024-10-12 20:55:12 --> Helper loaded: url_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: file_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: security_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:55:12 --> Database Driver Class Initialized
INFO - 2024-10-12 20:55:12 --> Email Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:55:12 --> Helper loaded: form_helper
INFO - 2024-10-12 20:55:12 --> Form Validation Class Initialized
INFO - 2024-10-12 20:55:12 --> Controller Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:55:12 --> Config Class Initialized
INFO - 2024-10-12 20:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:12 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:12 --> URI Class Initialized
INFO - 2024-10-12 20:55:12 --> Router Class Initialized
INFO - 2024-10-12 20:55:12 --> Output Class Initialized
INFO - 2024-10-12 20:55:12 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:12 --> Input Class Initialized
INFO - 2024-10-12 20:55:12 --> Language Class Initialized
INFO - 2024-10-12 20:55:12 --> Loader Class Initialized
INFO - 2024-10-12 20:55:12 --> Helper loaded: url_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: file_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: security_helper
INFO - 2024-10-12 20:55:12 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:55:12 --> Database Driver Class Initialized
INFO - 2024-10-12 20:55:12 --> Email Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:55:12 --> Helper loaded: form_helper
INFO - 2024-10-12 20:55:12 --> Form Validation Class Initialized
INFO - 2024-10-12 20:55:12 --> Controller Class Initialized
DEBUG - 2024-10-12 20:55:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:55:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-12 20:55:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-12 20:55:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-12 20:55:12 --> Final output sent to browser
DEBUG - 2024-10-12 20:55:12 --> Total execution time: 0.2297
INFO - 2024-10-12 20:55:14 --> Config Class Initialized
INFO - 2024-10-12 20:55:14 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:14 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:14 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:14 --> URI Class Initialized
INFO - 2024-10-12 20:55:14 --> Router Class Initialized
INFO - 2024-10-12 20:55:14 --> Output Class Initialized
INFO - 2024-10-12 20:55:14 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:14 --> Input Class Initialized
INFO - 2024-10-12 20:55:14 --> Language Class Initialized
INFO - 2024-10-12 20:55:14 --> Loader Class Initialized
INFO - 2024-10-12 20:55:14 --> Helper loaded: url_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: file_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: security_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:55:14 --> Database Driver Class Initialized
INFO - 2024-10-12 20:55:14 --> Email Class Initialized
DEBUG - 2024-10-12 20:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:55:14 --> Helper loaded: form_helper
INFO - 2024-10-12 20:55:14 --> Form Validation Class Initialized
INFO - 2024-10-12 20:55:14 --> Controller Class Initialized
DEBUG - 2024-10-12 20:55:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:55:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-12 20:55:14 --> Config Class Initialized
INFO - 2024-10-12 20:55:14 --> Hooks Class Initialized
DEBUG - 2024-10-12 20:55:14 --> UTF-8 Support Enabled
INFO - 2024-10-12 20:55:14 --> Utf8 Class Initialized
INFO - 2024-10-12 20:55:14 --> URI Class Initialized
INFO - 2024-10-12 20:55:14 --> Router Class Initialized
INFO - 2024-10-12 20:55:14 --> Output Class Initialized
INFO - 2024-10-12 20:55:14 --> Security Class Initialized
DEBUG - 2024-10-12 20:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-12 20:55:14 --> Input Class Initialized
INFO - 2024-10-12 20:55:14 --> Language Class Initialized
INFO - 2024-10-12 20:55:14 --> Loader Class Initialized
INFO - 2024-10-12 20:55:14 --> Helper loaded: url_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: file_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: security_helper
INFO - 2024-10-12 20:55:14 --> Helper loaded: wpu_helper
INFO - 2024-10-12 20:55:14 --> Database Driver Class Initialized
INFO - 2024-10-12 20:55:14 --> Email Class Initialized
DEBUG - 2024-10-12 20:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-12 20:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-12 20:55:14 --> Helper loaded: form_helper
INFO - 2024-10-12 20:55:14 --> Form Validation Class Initialized
INFO - 2024-10-12 20:55:14 --> Controller Class Initialized
INFO - 2024-10-12 20:55:14 --> Model "Antrol_model" initialized
DEBUG - 2024-10-12 20:55:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-12 20:55:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-12 20:55:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-12 20:55:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-12 20:55:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-12 20:55:15 --> Final output sent to browser
DEBUG - 2024-10-12 20:55:15 --> Total execution time: 0.6139
