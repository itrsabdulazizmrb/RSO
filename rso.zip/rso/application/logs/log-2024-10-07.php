<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-07 03:01:22 --> Config Class Initialized
INFO - 2024-10-07 03:01:22 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:22 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:22 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:22 --> URI Class Initialized
INFO - 2024-10-07 03:01:22 --> Router Class Initialized
INFO - 2024-10-07 03:01:22 --> Output Class Initialized
INFO - 2024-10-07 03:01:22 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:22 --> Input Class Initialized
INFO - 2024-10-07 03:01:22 --> Language Class Initialized
INFO - 2024-10-07 03:01:22 --> Loader Class Initialized
INFO - 2024-10-07 03:01:22 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:22 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:22 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:22 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:22 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:22 --> Controller Class Initialized
INFO - 2024-10-07 03:01:22 --> Config Class Initialized
INFO - 2024-10-07 03:01:22 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:22 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:22 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:22 --> URI Class Initialized
INFO - 2024-10-07 03:01:22 --> Router Class Initialized
INFO - 2024-10-07 03:01:22 --> Output Class Initialized
INFO - 2024-10-07 03:01:22 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:22 --> Input Class Initialized
INFO - 2024-10-07 03:01:22 --> Language Class Initialized
INFO - 2024-10-07 03:01:22 --> Loader Class Initialized
INFO - 2024-10-07 03:01:22 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:22 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:22 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:22 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:22 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:22 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:22 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 03:01:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 03:01:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 03:01:22 --> Final output sent to browser
DEBUG - 2024-10-07 03:01:22 --> Total execution time: 0.2282
INFO - 2024-10-07 03:01:24 --> Config Class Initialized
INFO - 2024-10-07 03:01:24 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:24 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:24 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:24 --> URI Class Initialized
INFO - 2024-10-07 03:01:24 --> Router Class Initialized
INFO - 2024-10-07 03:01:24 --> Output Class Initialized
INFO - 2024-10-07 03:01:24 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:24 --> Input Class Initialized
INFO - 2024-10-07 03:01:24 --> Language Class Initialized
INFO - 2024-10-07 03:01:24 --> Loader Class Initialized
INFO - 2024-10-07 03:01:24 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:24 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:24 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:24 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:24 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:25 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:25 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:25 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:25 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-07 03:01:25 --> Config Class Initialized
INFO - 2024-10-07 03:01:25 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:25 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:25 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:25 --> URI Class Initialized
INFO - 2024-10-07 03:01:25 --> Router Class Initialized
INFO - 2024-10-07 03:01:25 --> Output Class Initialized
INFO - 2024-10-07 03:01:25 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:25 --> Input Class Initialized
INFO - 2024-10-07 03:01:25 --> Language Class Initialized
INFO - 2024-10-07 03:01:25 --> Loader Class Initialized
INFO - 2024-10-07 03:01:25 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:25 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:25 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:25 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:25 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:25 --> Controller Class Initialized
INFO - 2024-10-07 03:01:25 --> Model "Antrol_model" initialized
DEBUG - 2024-10-07 03:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:25 --> Config Class Initialized
INFO - 2024-10-07 03:01:25 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:25 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:25 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:25 --> URI Class Initialized
INFO - 2024-10-07 03:01:25 --> Router Class Initialized
INFO - 2024-10-07 03:01:25 --> Output Class Initialized
INFO - 2024-10-07 03:01:25 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:25 --> Input Class Initialized
INFO - 2024-10-07 03:01:25 --> Language Class Initialized
INFO - 2024-10-07 03:01:25 --> Loader Class Initialized
INFO - 2024-10-07 03:01:25 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:25 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:25 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:25 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-07 03:01:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-07 03:01:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-07 03:01:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-07 03:01:25 --> Final output sent to browser
DEBUG - 2024-10-07 03:01:25 --> Total execution time: 0.5876
INFO - 2024-10-07 03:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:25 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:25 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:25 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:26 --> Config Class Initialized
INFO - 2024-10-07 03:01:26 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:26 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:26 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:26 --> URI Class Initialized
INFO - 2024-10-07 03:01:26 --> Router Class Initialized
INFO - 2024-10-07 03:01:26 --> Output Class Initialized
INFO - 2024-10-07 03:01:26 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:26 --> Input Class Initialized
INFO - 2024-10-07 03:01:26 --> Language Class Initialized
ERROR - 2024-10-07 03:01:26 --> 404 Page Not Found: User/index
INFO - 2024-10-07 03:01:27 --> Config Class Initialized
INFO - 2024-10-07 03:01:27 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:27 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:27 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:27 --> URI Class Initialized
INFO - 2024-10-07 03:01:27 --> Router Class Initialized
INFO - 2024-10-07 03:01:27 --> Output Class Initialized
INFO - 2024-10-07 03:01:27 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:27 --> Input Class Initialized
INFO - 2024-10-07 03:01:27 --> Language Class Initialized
ERROR - 2024-10-07 03:01:27 --> 404 Page Not Found: User/index
INFO - 2024-10-07 03:01:28 --> Config Class Initialized
INFO - 2024-10-07 03:01:28 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:28 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:28 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:28 --> URI Class Initialized
INFO - 2024-10-07 03:01:28 --> Router Class Initialized
INFO - 2024-10-07 03:01:28 --> Output Class Initialized
INFO - 2024-10-07 03:01:28 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:28 --> Input Class Initialized
INFO - 2024-10-07 03:01:28 --> Language Class Initialized
INFO - 2024-10-07 03:01:28 --> Loader Class Initialized
INFO - 2024-10-07 03:01:28 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:28 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:28 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:28 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:28 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:28 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:28 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:28 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:28 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:33 --> Config Class Initialized
INFO - 2024-10-07 03:01:33 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:33 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:33 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:33 --> URI Class Initialized
INFO - 2024-10-07 03:01:33 --> Router Class Initialized
INFO - 2024-10-07 03:01:33 --> Output Class Initialized
INFO - 2024-10-07 03:01:33 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:33 --> Input Class Initialized
INFO - 2024-10-07 03:01:33 --> Language Class Initialized
INFO - 2024-10-07 03:01:33 --> Loader Class Initialized
INFO - 2024-10-07 03:01:33 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:33 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:33 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:33 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:33 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:33 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:33 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:33 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:33 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:34 --> Config Class Initialized
INFO - 2024-10-07 03:01:34 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:34 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:34 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:34 --> URI Class Initialized
INFO - 2024-10-07 03:01:34 --> Router Class Initialized
INFO - 2024-10-07 03:01:34 --> Output Class Initialized
INFO - 2024-10-07 03:01:34 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:34 --> Input Class Initialized
INFO - 2024-10-07 03:01:34 --> Language Class Initialized
INFO - 2024-10-07 03:01:34 --> Loader Class Initialized
INFO - 2024-10-07 03:01:34 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:34 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:34 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:34 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:34 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:34 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:34 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:34 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:34 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 03:01:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 03:01:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 03:01:34 --> Final output sent to browser
DEBUG - 2024-10-07 03:01:34 --> Total execution time: 0.2164
INFO - 2024-10-07 03:01:36 --> Config Class Initialized
INFO - 2024-10-07 03:01:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:36 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:36 --> URI Class Initialized
INFO - 2024-10-07 03:01:36 --> Router Class Initialized
INFO - 2024-10-07 03:01:36 --> Output Class Initialized
INFO - 2024-10-07 03:01:36 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:36 --> Input Class Initialized
INFO - 2024-10-07 03:01:36 --> Language Class Initialized
INFO - 2024-10-07 03:01:36 --> Loader Class Initialized
INFO - 2024-10-07 03:01:36 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:36 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:36 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:36 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:36 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:36 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-07 03:01:36 --> Config Class Initialized
INFO - 2024-10-07 03:01:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:36 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:36 --> URI Class Initialized
INFO - 2024-10-07 03:01:36 --> Router Class Initialized
INFO - 2024-10-07 03:01:36 --> Output Class Initialized
INFO - 2024-10-07 03:01:36 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:36 --> Input Class Initialized
INFO - 2024-10-07 03:01:36 --> Language Class Initialized
INFO - 2024-10-07 03:01:36 --> Loader Class Initialized
INFO - 2024-10-07 03:01:36 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:36 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:36 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:36 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:36 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:36 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:36 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 03:01:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 03:01:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 03:01:36 --> Final output sent to browser
DEBUG - 2024-10-07 03:01:36 --> Total execution time: 0.2306
INFO - 2024-10-07 03:01:38 --> Config Class Initialized
INFO - 2024-10-07 03:01:38 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:38 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:38 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:38 --> URI Class Initialized
INFO - 2024-10-07 03:01:38 --> Router Class Initialized
INFO - 2024-10-07 03:01:38 --> Output Class Initialized
INFO - 2024-10-07 03:01:38 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:38 --> Input Class Initialized
INFO - 2024-10-07 03:01:38 --> Language Class Initialized
INFO - 2024-10-07 03:01:38 --> Loader Class Initialized
INFO - 2024-10-07 03:01:38 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:38 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:38 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:38 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:38 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:38 --> Controller Class Initialized
DEBUG - 2024-10-07 03:01:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-07 03:01:38 --> Config Class Initialized
INFO - 2024-10-07 03:01:38 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:01:38 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:01:38 --> Utf8 Class Initialized
INFO - 2024-10-07 03:01:38 --> URI Class Initialized
INFO - 2024-10-07 03:01:38 --> Router Class Initialized
INFO - 2024-10-07 03:01:38 --> Output Class Initialized
INFO - 2024-10-07 03:01:38 --> Security Class Initialized
DEBUG - 2024-10-07 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:01:38 --> Input Class Initialized
INFO - 2024-10-07 03:01:38 --> Language Class Initialized
INFO - 2024-10-07 03:01:38 --> Loader Class Initialized
INFO - 2024-10-07 03:01:38 --> Helper loaded: url_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: file_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: security_helper
INFO - 2024-10-07 03:01:38 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:01:38 --> Database Driver Class Initialized
INFO - 2024-10-07 03:01:39 --> Email Class Initialized
DEBUG - 2024-10-07 03:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:01:39 --> Helper loaded: form_helper
INFO - 2024-10-07 03:01:39 --> Form Validation Class Initialized
INFO - 2024-10-07 03:01:39 --> Controller Class Initialized
INFO - 2024-10-07 03:01:39 --> Model "Antrol_model" initialized
DEBUG - 2024-10-07 03:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:01:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-07 03:01:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-07 03:01:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-07 03:01:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-07 03:01:39 --> Final output sent to browser
DEBUG - 2024-10-07 03:01:39 --> Total execution time: 0.5705
INFO - 2024-10-07 03:08:15 --> Config Class Initialized
INFO - 2024-10-07 03:08:15 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:08:15 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:08:15 --> Utf8 Class Initialized
INFO - 2024-10-07 03:08:15 --> URI Class Initialized
INFO - 2024-10-07 03:08:15 --> Router Class Initialized
INFO - 2024-10-07 03:08:15 --> Output Class Initialized
INFO - 2024-10-07 03:08:15 --> Security Class Initialized
DEBUG - 2024-10-07 03:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:08:15 --> Input Class Initialized
INFO - 2024-10-07 03:08:15 --> Language Class Initialized
INFO - 2024-10-07 03:08:15 --> Loader Class Initialized
INFO - 2024-10-07 03:08:15 --> Helper loaded: url_helper
INFO - 2024-10-07 03:08:15 --> Helper loaded: file_helper
INFO - 2024-10-07 03:08:15 --> Helper loaded: security_helper
INFO - 2024-10-07 03:08:15 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:08:15 --> Database Driver Class Initialized
INFO - 2024-10-07 03:08:16 --> Email Class Initialized
DEBUG - 2024-10-07 03:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:08:16 --> Helper loaded: form_helper
INFO - 2024-10-07 03:08:16 --> Form Validation Class Initialized
INFO - 2024-10-07 03:08:16 --> Controller Class Initialized
DEBUG - 2024-10-07 03:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:08:21 --> Config Class Initialized
INFO - 2024-10-07 03:08:21 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:08:21 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:08:21 --> Utf8 Class Initialized
INFO - 2024-10-07 03:08:21 --> URI Class Initialized
INFO - 2024-10-07 03:08:21 --> Router Class Initialized
INFO - 2024-10-07 03:08:21 --> Output Class Initialized
INFO - 2024-10-07 03:08:21 --> Security Class Initialized
DEBUG - 2024-10-07 03:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:08:21 --> Input Class Initialized
INFO - 2024-10-07 03:08:21 --> Language Class Initialized
ERROR - 2024-10-07 03:08:21 --> 404 Page Not Found: User/index
INFO - 2024-10-07 03:08:28 --> Config Class Initialized
INFO - 2024-10-07 03:08:28 --> Hooks Class Initialized
DEBUG - 2024-10-07 03:08:28 --> UTF-8 Support Enabled
INFO - 2024-10-07 03:08:28 --> Utf8 Class Initialized
INFO - 2024-10-07 03:08:28 --> URI Class Initialized
INFO - 2024-10-07 03:08:28 --> Router Class Initialized
INFO - 2024-10-07 03:08:28 --> Output Class Initialized
INFO - 2024-10-07 03:08:28 --> Security Class Initialized
DEBUG - 2024-10-07 03:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 03:08:28 --> Input Class Initialized
INFO - 2024-10-07 03:08:28 --> Language Class Initialized
INFO - 2024-10-07 03:08:28 --> Loader Class Initialized
INFO - 2024-10-07 03:08:28 --> Helper loaded: url_helper
INFO - 2024-10-07 03:08:28 --> Helper loaded: file_helper
INFO - 2024-10-07 03:08:28 --> Helper loaded: security_helper
INFO - 2024-10-07 03:08:28 --> Helper loaded: wpu_helper
INFO - 2024-10-07 03:08:28 --> Database Driver Class Initialized
INFO - 2024-10-07 03:08:29 --> Email Class Initialized
DEBUG - 2024-10-07 03:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 03:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 03:08:29 --> Helper loaded: form_helper
INFO - 2024-10-07 03:08:29 --> Form Validation Class Initialized
INFO - 2024-10-07 03:08:29 --> Controller Class Initialized
INFO - 2024-10-07 03:08:29 --> Model "Antrol_model" initialized
DEBUG - 2024-10-07 03:08:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-07 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-07 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-07 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-07 03:08:29 --> Final output sent to browser
DEBUG - 2024-10-07 03:08:29 --> Total execution time: 0.6220
INFO - 2024-10-07 04:07:02 --> Config Class Initialized
INFO - 2024-10-07 04:07:02 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:07:02 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:02 --> Utf8 Class Initialized
INFO - 2024-10-07 04:07:02 --> URI Class Initialized
DEBUG - 2024-10-07 04:07:02 --> No URI present. Default controller set.
INFO - 2024-10-07 04:07:02 --> Router Class Initialized
INFO - 2024-10-07 04:07:02 --> Output Class Initialized
INFO - 2024-10-07 04:07:02 --> Security Class Initialized
DEBUG - 2024-10-07 04:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:02 --> Input Class Initialized
INFO - 2024-10-07 04:07:02 --> Language Class Initialized
INFO - 2024-10-07 04:07:02 --> Loader Class Initialized
INFO - 2024-10-07 04:07:02 --> Helper loaded: url_helper
INFO - 2024-10-07 04:07:02 --> Helper loaded: file_helper
INFO - 2024-10-07 04:07:02 --> Helper loaded: security_helper
INFO - 2024-10-07 04:07:02 --> Helper loaded: wpu_helper
INFO - 2024-10-07 04:07:02 --> Database Driver Class Initialized
INFO - 2024-10-07 04:07:02 --> Email Class Initialized
DEBUG - 2024-10-07 04:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 04:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 04:07:02 --> Helper loaded: form_helper
INFO - 2024-10-07 04:07:02 --> Form Validation Class Initialized
INFO - 2024-10-07 04:07:02 --> Controller Class Initialized
DEBUG - 2024-10-07 04:07:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 04:07:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 04:07:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 04:07:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 04:07:02 --> Final output sent to browser
DEBUG - 2024-10-07 04:07:02 --> Total execution time: 0.2427
INFO - 2024-10-07 04:07:36 --> Config Class Initialized
INFO - 2024-10-07 04:07:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:07:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:07:36 --> URI Class Initialized
INFO - 2024-10-07 04:07:36 --> Router Class Initialized
INFO - 2024-10-07 04:07:36 --> Output Class Initialized
INFO - 2024-10-07 04:07:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:36 --> Input Class Initialized
INFO - 2024-10-07 04:07:36 --> Language Class Initialized
ERROR - 2024-10-07 04:07:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:07:36 --> Config Class Initialized
INFO - 2024-10-07 04:07:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:07:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:07:36 --> URI Class Initialized
INFO - 2024-10-07 04:07:36 --> Router Class Initialized
INFO - 2024-10-07 04:07:36 --> Output Class Initialized
INFO - 2024-10-07 04:07:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:36 --> Input Class Initialized
INFO - 2024-10-07 04:07:36 --> Language Class Initialized
ERROR - 2024-10-07 04:07:36 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:07:36 --> Config Class Initialized
INFO - 2024-10-07 04:07:36 --> Hooks Class Initialized
INFO - 2024-10-07 04:07:36 --> Config Class Initialized
INFO - 2024-10-07 04:07:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:07:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:36 --> Utf8 Class Initialized
DEBUG - 2024-10-07 04:07:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:07:36 --> URI Class Initialized
INFO - 2024-10-07 04:07:36 --> Router Class Initialized
INFO - 2024-10-07 04:07:36 --> URI Class Initialized
INFO - 2024-10-07 04:07:36 --> Router Class Initialized
INFO - 2024-10-07 04:07:36 --> Output Class Initialized
INFO - 2024-10-07 04:07:36 --> Output Class Initialized
INFO - 2024-10-07 04:07:36 --> Security Class Initialized
INFO - 2024-10-07 04:07:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:36 --> Input Class Initialized
DEBUG - 2024-10-07 04:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:36 --> Input Class Initialized
INFO - 2024-10-07 04:07:36 --> Language Class Initialized
INFO - 2024-10-07 04:07:36 --> Language Class Initialized
ERROR - 2024-10-07 04:07:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-10-07 04:07:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:07:37 --> Config Class Initialized
INFO - 2024-10-07 04:07:37 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:07:37 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:07:37 --> Utf8 Class Initialized
INFO - 2024-10-07 04:07:37 --> URI Class Initialized
INFO - 2024-10-07 04:07:37 --> Router Class Initialized
INFO - 2024-10-07 04:07:37 --> Output Class Initialized
INFO - 2024-10-07 04:07:37 --> Security Class Initialized
DEBUG - 2024-10-07 04:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:07:37 --> Input Class Initialized
INFO - 2024-10-07 04:07:37 --> Language Class Initialized
ERROR - 2024-10-07 04:07:37 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:08:17 --> Config Class Initialized
INFO - 2024-10-07 04:08:17 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:08:17 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:08:17 --> Utf8 Class Initialized
INFO - 2024-10-07 04:08:17 --> URI Class Initialized
INFO - 2024-10-07 04:08:17 --> Router Class Initialized
INFO - 2024-10-07 04:08:17 --> Output Class Initialized
INFO - 2024-10-07 04:08:17 --> Config Class Initialized
INFO - 2024-10-07 04:08:17 --> Hooks Class Initialized
INFO - 2024-10-07 04:08:17 --> Security Class Initialized
DEBUG - 2024-10-07 04:08:17 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:08:17 --> Utf8 Class Initialized
DEBUG - 2024-10-07 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:08:17 --> Input Class Initialized
INFO - 2024-10-07 04:08:17 --> Language Class Initialized
ERROR - 2024-10-07 04:08:17 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:08:17 --> URI Class Initialized
INFO - 2024-10-07 04:08:17 --> Router Class Initialized
INFO - 2024-10-07 04:08:17 --> Output Class Initialized
INFO - 2024-10-07 04:08:17 --> Security Class Initialized
DEBUG - 2024-10-07 04:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:08:17 --> Input Class Initialized
INFO - 2024-10-07 04:08:17 --> Language Class Initialized
ERROR - 2024-10-07 04:08:17 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:08:19 --> Config Class Initialized
INFO - 2024-10-07 04:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:08:19 --> Utf8 Class Initialized
INFO - 2024-10-07 04:08:19 --> URI Class Initialized
INFO - 2024-10-07 04:08:19 --> Router Class Initialized
INFO - 2024-10-07 04:08:19 --> Output Class Initialized
INFO - 2024-10-07 04:08:19 --> Security Class Initialized
DEBUG - 2024-10-07 04:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:08:19 --> Input Class Initialized
INFO - 2024-10-07 04:08:19 --> Language Class Initialized
ERROR - 2024-10-07 04:08:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:08:19 --> Config Class Initialized
INFO - 2024-10-07 04:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:08:19 --> Utf8 Class Initialized
INFO - 2024-10-07 04:08:19 --> URI Class Initialized
INFO - 2024-10-07 04:08:19 --> Router Class Initialized
INFO - 2024-10-07 04:08:19 --> Output Class Initialized
INFO - 2024-10-07 04:08:19 --> Security Class Initialized
DEBUG - 2024-10-07 04:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:08:19 --> Input Class Initialized
INFO - 2024-10-07 04:08:19 --> Language Class Initialized
ERROR - 2024-10-07 04:08:19 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:08:20 --> Config Class Initialized
INFO - 2024-10-07 04:08:20 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:08:20 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:08:20 --> Utf8 Class Initialized
INFO - 2024-10-07 04:08:20 --> URI Class Initialized
INFO - 2024-10-07 04:08:20 --> Router Class Initialized
INFO - 2024-10-07 04:08:20 --> Output Class Initialized
INFO - 2024-10-07 04:08:20 --> Security Class Initialized
DEBUG - 2024-10-07 04:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:08:20 --> Input Class Initialized
INFO - 2024-10-07 04:08:20 --> Language Class Initialized
ERROR - 2024-10-07 04:08:20 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:09 --> Config Class Initialized
INFO - 2024-10-07 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:09 --> URI Class Initialized
INFO - 2024-10-07 04:09:09 --> Router Class Initialized
INFO - 2024-10-07 04:09:09 --> Output Class Initialized
INFO - 2024-10-07 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:09 --> Input Class Initialized
INFO - 2024-10-07 04:09:09 --> Language Class Initialized
ERROR - 2024-10-07 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:09 --> Config Class Initialized
INFO - 2024-10-07 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:09 --> URI Class Initialized
INFO - 2024-10-07 04:09:09 --> Router Class Initialized
INFO - 2024-10-07 04:09:09 --> Output Class Initialized
INFO - 2024-10-07 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:09 --> Input Class Initialized
INFO - 2024-10-07 04:09:09 --> Language Class Initialized
ERROR - 2024-10-07 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:09 --> Config Class Initialized
INFO - 2024-10-07 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:09 --> URI Class Initialized
INFO - 2024-10-07 04:09:09 --> Router Class Initialized
INFO - 2024-10-07 04:09:09 --> Output Class Initialized
INFO - 2024-10-07 04:09:09 --> Security Class Initialized
INFO - 2024-10-07 04:09:09 --> Config Class Initialized
INFO - 2024-10-07 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:09 --> Input Class Initialized
INFO - 2024-10-07 04:09:09 --> Language Class Initialized
ERROR - 2024-10-07 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-07 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:09 --> URI Class Initialized
INFO - 2024-10-07 04:09:09 --> Router Class Initialized
INFO - 2024-10-07 04:09:09 --> Output Class Initialized
INFO - 2024-10-07 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:09 --> Input Class Initialized
INFO - 2024-10-07 04:09:09 --> Language Class Initialized
ERROR - 2024-10-07 04:09:09 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:09:09 --> Config Class Initialized
INFO - 2024-10-07 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:09 --> URI Class Initialized
INFO - 2024-10-07 04:09:09 --> Router Class Initialized
INFO - 2024-10-07 04:09:09 --> Output Class Initialized
INFO - 2024-10-07 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:09 --> Input Class Initialized
INFO - 2024-10-07 04:09:09 --> Language Class Initialized
ERROR - 2024-10-07 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:54 --> Config Class Initialized
INFO - 2024-10-07 04:09:54 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:54 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:54 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:54 --> URI Class Initialized
INFO - 2024-10-07 04:09:54 --> Router Class Initialized
INFO - 2024-10-07 04:09:54 --> Output Class Initialized
INFO - 2024-10-07 04:09:54 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:54 --> Input Class Initialized
INFO - 2024-10-07 04:09:54 --> Language Class Initialized
ERROR - 2024-10-07 04:09:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:54 --> Config Class Initialized
INFO - 2024-10-07 04:09:54 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:54 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:54 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:54 --> URI Class Initialized
INFO - 2024-10-07 04:09:54 --> Router Class Initialized
INFO - 2024-10-07 04:09:54 --> Output Class Initialized
INFO - 2024-10-07 04:09:54 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:54 --> Input Class Initialized
INFO - 2024-10-07 04:09:54 --> Language Class Initialized
ERROR - 2024-10-07 04:09:54 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:09:54 --> Config Class Initialized
INFO - 2024-10-07 04:09:54 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:54 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:54 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:54 --> URI Class Initialized
INFO - 2024-10-07 04:09:54 --> Router Class Initialized
INFO - 2024-10-07 04:09:54 --> Output Class Initialized
INFO - 2024-10-07 04:09:54 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:54 --> Input Class Initialized
INFO - 2024-10-07 04:09:54 --> Language Class Initialized
ERROR - 2024-10-07 04:09:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:54 --> Config Class Initialized
INFO - 2024-10-07 04:09:54 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:54 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:54 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:54 --> URI Class Initialized
INFO - 2024-10-07 04:09:54 --> Router Class Initialized
INFO - 2024-10-07 04:09:54 --> Output Class Initialized
INFO - 2024-10-07 04:09:54 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:54 --> Input Class Initialized
INFO - 2024-10-07 04:09:54 --> Language Class Initialized
ERROR - 2024-10-07 04:09:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:09:54 --> Config Class Initialized
INFO - 2024-10-07 04:09:54 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:09:54 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:09:54 --> Utf8 Class Initialized
INFO - 2024-10-07 04:09:54 --> URI Class Initialized
INFO - 2024-10-07 04:09:54 --> Router Class Initialized
INFO - 2024-10-07 04:09:54 --> Output Class Initialized
INFO - 2024-10-07 04:09:54 --> Security Class Initialized
DEBUG - 2024-10-07 04:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:09:54 --> Input Class Initialized
INFO - 2024-10-07 04:09:54 --> Language Class Initialized
ERROR - 2024-10-07 04:09:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:10:43 --> Config Class Initialized
INFO - 2024-10-07 04:10:43 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:10:43 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:10:43 --> Utf8 Class Initialized
INFO - 2024-10-07 04:10:43 --> URI Class Initialized
INFO - 2024-10-07 04:10:43 --> Router Class Initialized
INFO - 2024-10-07 04:10:43 --> Output Class Initialized
INFO - 2024-10-07 04:10:43 --> Security Class Initialized
DEBUG - 2024-10-07 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:10:43 --> Input Class Initialized
INFO - 2024-10-07 04:10:43 --> Language Class Initialized
ERROR - 2024-10-07 04:10:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:10:43 --> Config Class Initialized
INFO - 2024-10-07 04:10:43 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:10:43 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:10:43 --> Utf8 Class Initialized
INFO - 2024-10-07 04:10:43 --> URI Class Initialized
INFO - 2024-10-07 04:10:43 --> Config Class Initialized
INFO - 2024-10-07 04:10:43 --> Router Class Initialized
INFO - 2024-10-07 04:10:43 --> Hooks Class Initialized
INFO - 2024-10-07 04:10:43 --> Output Class Initialized
DEBUG - 2024-10-07 04:10:43 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:10:43 --> Utf8 Class Initialized
INFO - 2024-10-07 04:10:43 --> URI Class Initialized
INFO - 2024-10-07 04:10:43 --> Security Class Initialized
INFO - 2024-10-07 04:10:43 --> Router Class Initialized
DEBUG - 2024-10-07 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:10:43 --> Input Class Initialized
INFO - 2024-10-07 04:10:43 --> Language Class Initialized
ERROR - 2024-10-07 04:10:43 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:10:43 --> Output Class Initialized
INFO - 2024-10-07 04:10:43 --> Security Class Initialized
DEBUG - 2024-10-07 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:10:43 --> Input Class Initialized
INFO - 2024-10-07 04:10:43 --> Language Class Initialized
ERROR - 2024-10-07 04:10:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:10:44 --> Config Class Initialized
INFO - 2024-10-07 04:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:10:44 --> Utf8 Class Initialized
INFO - 2024-10-07 04:10:44 --> URI Class Initialized
INFO - 2024-10-07 04:10:44 --> Router Class Initialized
INFO - 2024-10-07 04:10:44 --> Output Class Initialized
INFO - 2024-10-07 04:10:44 --> Security Class Initialized
DEBUG - 2024-10-07 04:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:10:44 --> Input Class Initialized
INFO - 2024-10-07 04:10:44 --> Language Class Initialized
ERROR - 2024-10-07 04:10:44 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:10:44 --> Config Class Initialized
INFO - 2024-10-07 04:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:10:44 --> Utf8 Class Initialized
INFO - 2024-10-07 04:10:44 --> URI Class Initialized
INFO - 2024-10-07 04:10:44 --> Router Class Initialized
INFO - 2024-10-07 04:10:44 --> Output Class Initialized
INFO - 2024-10-07 04:10:44 --> Security Class Initialized
DEBUG - 2024-10-07 04:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:10:44 --> Input Class Initialized
INFO - 2024-10-07 04:10:44 --> Language Class Initialized
ERROR - 2024-10-07 04:10:44 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:11:36 --> Config Class Initialized
INFO - 2024-10-07 04:11:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:11:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:11:36 --> URI Class Initialized
INFO - 2024-10-07 04:11:36 --> Config Class Initialized
INFO - 2024-10-07 04:11:36 --> Hooks Class Initialized
INFO - 2024-10-07 04:11:36 --> Router Class Initialized
DEBUG - 2024-10-07 04:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:11:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:11:36 --> Output Class Initialized
INFO - 2024-10-07 04:11:36 --> URI Class Initialized
INFO - 2024-10-07 04:11:36 --> Config Class Initialized
INFO - 2024-10-07 04:11:36 --> Hooks Class Initialized
INFO - 2024-10-07 04:11:36 --> Router Class Initialized
INFO - 2024-10-07 04:11:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:11:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:11:36 --> Output Class Initialized
DEBUG - 2024-10-07 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:11:36 --> Input Class Initialized
INFO - 2024-10-07 04:11:36 --> URI Class Initialized
INFO - 2024-10-07 04:11:36 --> Config Class Initialized
INFO - 2024-10-07 04:11:36 --> Language Class Initialized
INFO - 2024-10-07 04:11:36 --> Security Class Initialized
INFO - 2024-10-07 04:11:36 --> Hooks Class Initialized
INFO - 2024-10-07 04:11:36 --> Router Class Initialized
ERROR - 2024-10-07 04:11:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-07 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:11:36 --> Input Class Initialized
INFO - 2024-10-07 04:11:36 --> Language Class Initialized
DEBUG - 2024-10-07 04:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:11:36 --> Utf8 Class Initialized
ERROR - 2024-10-07 04:11:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:11:36 --> Output Class Initialized
INFO - 2024-10-07 04:11:36 --> URI Class Initialized
INFO - 2024-10-07 04:11:36 --> Router Class Initialized
INFO - 2024-10-07 04:11:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:11:36 --> Input Class Initialized
INFO - 2024-10-07 04:11:36 --> Output Class Initialized
INFO - 2024-10-07 04:11:36 --> Language Class Initialized
ERROR - 2024-10-07 04:11:36 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-07 04:11:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:11:36 --> Input Class Initialized
INFO - 2024-10-07 04:11:36 --> Language Class Initialized
ERROR - 2024-10-07 04:11:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:11:36 --> Config Class Initialized
INFO - 2024-10-07 04:11:36 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:11:36 --> Utf8 Class Initialized
INFO - 2024-10-07 04:11:36 --> URI Class Initialized
INFO - 2024-10-07 04:11:36 --> Router Class Initialized
INFO - 2024-10-07 04:11:36 --> Output Class Initialized
INFO - 2024-10-07 04:11:36 --> Security Class Initialized
DEBUG - 2024-10-07 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:11:36 --> Input Class Initialized
INFO - 2024-10-07 04:11:36 --> Language Class Initialized
ERROR - 2024-10-07 04:11:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-07 04:40:02 --> Config Class Initialized
INFO - 2024-10-07 04:40:02 --> Hooks Class Initialized
DEBUG - 2024-10-07 04:40:02 --> UTF-8 Support Enabled
INFO - 2024-10-07 04:40:02 --> Utf8 Class Initialized
INFO - 2024-10-07 04:40:02 --> URI Class Initialized
INFO - 2024-10-07 04:40:02 --> Router Class Initialized
INFO - 2024-10-07 04:40:02 --> Output Class Initialized
INFO - 2024-10-07 04:40:02 --> Security Class Initialized
DEBUG - 2024-10-07 04:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 04:40:02 --> Input Class Initialized
INFO - 2024-10-07 04:40:02 --> Language Class Initialized
INFO - 2024-10-07 04:40:02 --> Loader Class Initialized
INFO - 2024-10-07 04:40:02 --> Helper loaded: url_helper
INFO - 2024-10-07 04:40:02 --> Helper loaded: file_helper
INFO - 2024-10-07 04:40:02 --> Helper loaded: security_helper
INFO - 2024-10-07 04:40:02 --> Helper loaded: wpu_helper
INFO - 2024-10-07 04:40:02 --> Database Driver Class Initialized
INFO - 2024-10-07 04:40:03 --> Email Class Initialized
DEBUG - 2024-10-07 04:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 04:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 04:40:03 --> Helper loaded: form_helper
INFO - 2024-10-07 04:40:03 --> Form Validation Class Initialized
INFO - 2024-10-07 04:40:03 --> Controller Class Initialized
DEBUG - 2024-10-07 04:40:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 09:03:09 --> Config Class Initialized
INFO - 2024-10-07 09:03:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 09:03:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 09:03:09 --> Utf8 Class Initialized
INFO - 2024-10-07 09:03:09 --> URI Class Initialized
DEBUG - 2024-10-07 09:03:09 --> No URI present. Default controller set.
INFO - 2024-10-07 09:03:09 --> Router Class Initialized
INFO - 2024-10-07 09:03:09 --> Output Class Initialized
INFO - 2024-10-07 09:03:09 --> Security Class Initialized
DEBUG - 2024-10-07 09:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 09:03:09 --> Input Class Initialized
INFO - 2024-10-07 09:03:09 --> Language Class Initialized
INFO - 2024-10-07 09:03:09 --> Loader Class Initialized
INFO - 2024-10-07 09:03:09 --> Helper loaded: url_helper
INFO - 2024-10-07 09:03:09 --> Helper loaded: file_helper
INFO - 2024-10-07 09:03:09 --> Helper loaded: security_helper
INFO - 2024-10-07 09:03:09 --> Helper loaded: wpu_helper
INFO - 2024-10-07 09:03:09 --> Database Driver Class Initialized
INFO - 2024-10-07 09:03:10 --> Email Class Initialized
DEBUG - 2024-10-07 09:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 09:03:10 --> Helper loaded: form_helper
INFO - 2024-10-07 09:03:10 --> Form Validation Class Initialized
INFO - 2024-10-07 09:03:10 --> Controller Class Initialized
DEBUG - 2024-10-07 09:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 09:03:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 09:03:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 09:03:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 09:03:10 --> Final output sent to browser
DEBUG - 2024-10-07 09:03:10 --> Total execution time: 0.2254
INFO - 2024-10-07 14:43:09 --> Config Class Initialized
INFO - 2024-10-07 14:43:09 --> Hooks Class Initialized
DEBUG - 2024-10-07 14:43:09 --> UTF-8 Support Enabled
INFO - 2024-10-07 14:43:09 --> Utf8 Class Initialized
INFO - 2024-10-07 14:43:09 --> URI Class Initialized
DEBUG - 2024-10-07 14:43:09 --> No URI present. Default controller set.
INFO - 2024-10-07 14:43:09 --> Router Class Initialized
INFO - 2024-10-07 14:43:09 --> Output Class Initialized
INFO - 2024-10-07 14:43:09 --> Security Class Initialized
DEBUG - 2024-10-07 14:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 14:43:09 --> Input Class Initialized
INFO - 2024-10-07 14:43:09 --> Language Class Initialized
INFO - 2024-10-07 14:43:09 --> Loader Class Initialized
INFO - 2024-10-07 14:43:09 --> Helper loaded: url_helper
INFO - 2024-10-07 14:43:09 --> Helper loaded: file_helper
INFO - 2024-10-07 14:43:09 --> Helper loaded: security_helper
INFO - 2024-10-07 14:43:09 --> Helper loaded: wpu_helper
INFO - 2024-10-07 14:43:09 --> Database Driver Class Initialized
INFO - 2024-10-07 14:43:10 --> Email Class Initialized
DEBUG - 2024-10-07 14:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 14:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 14:43:10 --> Helper loaded: form_helper
INFO - 2024-10-07 14:43:10 --> Form Validation Class Initialized
INFO - 2024-10-07 14:43:10 --> Controller Class Initialized
DEBUG - 2024-10-07 14:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 14:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 14:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 14:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 14:43:10 --> Final output sent to browser
DEBUG - 2024-10-07 14:43:10 --> Total execution time: 0.2137
INFO - 2024-10-07 15:31:43 --> Config Class Initialized
INFO - 2024-10-07 15:31:43 --> Hooks Class Initialized
DEBUG - 2024-10-07 15:31:43 --> UTF-8 Support Enabled
INFO - 2024-10-07 15:31:43 --> Utf8 Class Initialized
INFO - 2024-10-07 15:31:43 --> URI Class Initialized
INFO - 2024-10-07 15:31:43 --> Router Class Initialized
INFO - 2024-10-07 15:31:43 --> Output Class Initialized
INFO - 2024-10-07 15:31:43 --> Security Class Initialized
DEBUG - 2024-10-07 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 15:31:43 --> Input Class Initialized
INFO - 2024-10-07 15:31:43 --> Language Class Initialized
ERROR - 2024-10-07 15:31:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-07 15:31:43 --> Config Class Initialized
INFO - 2024-10-07 15:31:43 --> Hooks Class Initialized
DEBUG - 2024-10-07 15:31:43 --> UTF-8 Support Enabled
INFO - 2024-10-07 15:31:43 --> Utf8 Class Initialized
INFO - 2024-10-07 15:31:43 --> URI Class Initialized
DEBUG - 2024-10-07 15:31:43 --> No URI present. Default controller set.
INFO - 2024-10-07 15:31:43 --> Router Class Initialized
INFO - 2024-10-07 15:31:43 --> Output Class Initialized
INFO - 2024-10-07 15:31:43 --> Security Class Initialized
DEBUG - 2024-10-07 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-07 15:31:43 --> Input Class Initialized
INFO - 2024-10-07 15:31:43 --> Language Class Initialized
INFO - 2024-10-07 15:31:43 --> Loader Class Initialized
INFO - 2024-10-07 15:31:43 --> Helper loaded: url_helper
INFO - 2024-10-07 15:31:43 --> Helper loaded: file_helper
INFO - 2024-10-07 15:31:43 --> Helper loaded: security_helper
INFO - 2024-10-07 15:31:43 --> Helper loaded: wpu_helper
INFO - 2024-10-07 15:31:43 --> Database Driver Class Initialized
INFO - 2024-10-07 15:31:43 --> Email Class Initialized
DEBUG - 2024-10-07 15:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-07 15:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-07 15:31:43 --> Helper loaded: form_helper
INFO - 2024-10-07 15:31:43 --> Form Validation Class Initialized
INFO - 2024-10-07 15:31:43 --> Controller Class Initialized
DEBUG - 2024-10-07 15:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-07 15:31:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-07 15:31:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-07 15:31:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-07 15:31:43 --> Final output sent to browser
DEBUG - 2024-10-07 15:31:43 --> Total execution time: 0.2139
