<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-17 02:01:27 --> Config Class Initialized
INFO - 2024-09-17 02:01:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 02:01:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 02:01:27 --> Utf8 Class Initialized
INFO - 2024-09-17 02:01:27 --> URI Class Initialized
DEBUG - 2024-09-17 02:01:27 --> No URI present. Default controller set.
INFO - 2024-09-17 02:01:27 --> Router Class Initialized
INFO - 2024-09-17 02:01:27 --> Output Class Initialized
INFO - 2024-09-17 02:01:27 --> Security Class Initialized
DEBUG - 2024-09-17 02:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 02:01:27 --> Input Class Initialized
INFO - 2024-09-17 02:01:27 --> Language Class Initialized
INFO - 2024-09-17 02:01:27 --> Loader Class Initialized
INFO - 2024-09-17 02:01:27 --> Helper loaded: url_helper
INFO - 2024-09-17 02:01:27 --> Helper loaded: file_helper
INFO - 2024-09-17 02:01:27 --> Helper loaded: security_helper
INFO - 2024-09-17 02:01:27 --> Helper loaded: wpu_helper
INFO - 2024-09-17 02:01:27 --> Database Driver Class Initialized
INFO - 2024-09-17 02:01:29 --> Config Class Initialized
INFO - 2024-09-17 02:01:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 02:01:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 02:01:29 --> Utf8 Class Initialized
INFO - 2024-09-17 02:01:29 --> URI Class Initialized
DEBUG - 2024-09-17 02:01:29 --> No URI present. Default controller set.
INFO - 2024-09-17 02:01:29 --> Router Class Initialized
INFO - 2024-09-17 02:01:29 --> Output Class Initialized
INFO - 2024-09-17 02:01:29 --> Security Class Initialized
DEBUG - 2024-09-17 02:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 02:01:29 --> Input Class Initialized
INFO - 2024-09-17 02:01:29 --> Language Class Initialized
INFO - 2024-09-17 02:01:29 --> Loader Class Initialized
INFO - 2024-09-17 02:01:29 --> Helper loaded: url_helper
INFO - 2024-09-17 02:01:29 --> Helper loaded: file_helper
INFO - 2024-09-17 02:01:29 --> Helper loaded: security_helper
INFO - 2024-09-17 02:01:29 --> Helper loaded: wpu_helper
INFO - 2024-09-17 02:01:29 --> Database Driver Class Initialized
ERROR - 2024-09-17 02:01:59 --> Unable to connect to the database
INFO - 2024-09-17 02:01:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-17 03:14:31 --> Config Class Initialized
INFO - 2024-09-17 03:14:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 03:14:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 03:14:31 --> Utf8 Class Initialized
INFO - 2024-09-17 03:14:31 --> URI Class Initialized
DEBUG - 2024-09-17 03:14:31 --> No URI present. Default controller set.
INFO - 2024-09-17 03:14:31 --> Router Class Initialized
INFO - 2024-09-17 03:14:31 --> Output Class Initialized
INFO - 2024-09-17 03:14:31 --> Security Class Initialized
DEBUG - 2024-09-17 03:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 03:14:31 --> Input Class Initialized
INFO - 2024-09-17 03:14:31 --> Language Class Initialized
INFO - 2024-09-17 03:14:31 --> Loader Class Initialized
INFO - 2024-09-17 03:14:31 --> Helper loaded: url_helper
INFO - 2024-09-17 03:14:31 --> Helper loaded: file_helper
INFO - 2024-09-17 03:14:31 --> Helper loaded: security_helper
INFO - 2024-09-17 03:14:31 --> Helper loaded: wpu_helper
INFO - 2024-09-17 03:14:31 --> Database Driver Class Initialized
ERROR - 2024-09-17 03:15:01 --> Unable to connect to the database
INFO - 2024-09-17 03:15:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-17 05:03:20 --> Config Class Initialized
INFO - 2024-09-17 05:03:20 --> Hooks Class Initialized
DEBUG - 2024-09-17 05:03:20 --> UTF-8 Support Enabled
INFO - 2024-09-17 05:03:20 --> Utf8 Class Initialized
INFO - 2024-09-17 05:03:20 --> URI Class Initialized
DEBUG - 2024-09-17 05:03:20 --> No URI present. Default controller set.
INFO - 2024-09-17 05:03:20 --> Router Class Initialized
INFO - 2024-09-17 05:03:20 --> Output Class Initialized
INFO - 2024-09-17 05:03:20 --> Security Class Initialized
DEBUG - 2024-09-17 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 05:03:20 --> Input Class Initialized
INFO - 2024-09-17 05:03:20 --> Language Class Initialized
INFO - 2024-09-17 05:03:20 --> Loader Class Initialized
INFO - 2024-09-17 05:03:20 --> Helper loaded: url_helper
INFO - 2024-09-17 05:03:20 --> Helper loaded: file_helper
INFO - 2024-09-17 05:03:20 --> Helper loaded: security_helper
INFO - 2024-09-17 05:03:20 --> Helper loaded: wpu_helper
INFO - 2024-09-17 05:03:20 --> Database Driver Class Initialized
ERROR - 2024-09-17 05:03:50 --> Unable to connect to the database
INFO - 2024-09-17 05:03:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-17 05:48:52 --> Config Class Initialized
INFO - 2024-09-17 05:48:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 05:48:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 05:48:52 --> Utf8 Class Initialized
INFO - 2024-09-17 05:48:52 --> URI Class Initialized
DEBUG - 2024-09-17 05:48:52 --> No URI present. Default controller set.
INFO - 2024-09-17 05:48:52 --> Router Class Initialized
INFO - 2024-09-17 05:48:52 --> Output Class Initialized
INFO - 2024-09-17 05:48:52 --> Security Class Initialized
DEBUG - 2024-09-17 05:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 05:48:52 --> Input Class Initialized
INFO - 2024-09-17 05:48:52 --> Language Class Initialized
INFO - 2024-09-17 05:48:52 --> Loader Class Initialized
INFO - 2024-09-17 05:48:52 --> Helper loaded: url_helper
INFO - 2024-09-17 05:48:52 --> Helper loaded: file_helper
INFO - 2024-09-17 05:48:52 --> Helper loaded: security_helper
INFO - 2024-09-17 05:48:52 --> Helper loaded: wpu_helper
INFO - 2024-09-17 05:48:52 --> Database Driver Class Initialized
INFO - 2024-09-17 07:33:17 --> Config Class Initialized
INFO - 2024-09-17 07:33:17 --> Hooks Class Initialized
DEBUG - 2024-09-17 07:33:17 --> UTF-8 Support Enabled
INFO - 2024-09-17 07:33:17 --> Utf8 Class Initialized
INFO - 2024-09-17 07:33:17 --> URI Class Initialized
DEBUG - 2024-09-17 07:33:17 --> No URI present. Default controller set.
INFO - 2024-09-17 07:33:17 --> Router Class Initialized
INFO - 2024-09-17 07:33:17 --> Output Class Initialized
INFO - 2024-09-17 07:33:17 --> Security Class Initialized
DEBUG - 2024-09-17 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 07:33:17 --> Input Class Initialized
INFO - 2024-09-17 07:33:17 --> Language Class Initialized
INFO - 2024-09-17 07:33:17 --> Loader Class Initialized
INFO - 2024-09-17 07:33:17 --> Helper loaded: url_helper
INFO - 2024-09-17 07:33:17 --> Helper loaded: file_helper
INFO - 2024-09-17 07:33:17 --> Helper loaded: security_helper
INFO - 2024-09-17 07:33:17 --> Helper loaded: wpu_helper
INFO - 2024-09-17 07:33:17 --> Database Driver Class Initialized
INFO - 2024-09-17 07:33:46 --> Config Class Initialized
INFO - 2024-09-17 07:33:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 07:33:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 07:33:46 --> Utf8 Class Initialized
INFO - 2024-09-17 07:33:46 --> URI Class Initialized
DEBUG - 2024-09-17 07:33:46 --> No URI present. Default controller set.
INFO - 2024-09-17 07:33:46 --> Router Class Initialized
INFO - 2024-09-17 07:33:46 --> Output Class Initialized
INFO - 2024-09-17 07:33:46 --> Security Class Initialized
DEBUG - 2024-09-17 07:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 07:33:46 --> Input Class Initialized
INFO - 2024-09-17 07:33:46 --> Language Class Initialized
INFO - 2024-09-17 07:33:46 --> Loader Class Initialized
INFO - 2024-09-17 07:33:46 --> Helper loaded: url_helper
INFO - 2024-09-17 07:33:46 --> Helper loaded: file_helper
INFO - 2024-09-17 07:33:46 --> Helper loaded: security_helper
INFO - 2024-09-17 07:33:46 --> Helper loaded: wpu_helper
INFO - 2024-09-17 07:33:46 --> Database Driver Class Initialized
ERROR - 2024-09-17 07:33:48 --> Unable to connect to the database
INFO - 2024-09-17 07:33:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-09-17 07:34:16 --> Unable to connect to the database
INFO - 2024-09-17 07:34:16 --> Language file loaded: language/english/db_lang.php
