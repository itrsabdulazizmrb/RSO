<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-10 04:16:31 --> Config Class Initialized
INFO - 2024-12-10 04:16:31 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:31 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:31 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:31 --> URI Class Initialized
DEBUG - 2024-12-10 04:16:31 --> No URI present. Default controller set.
INFO - 2024-12-10 04:16:31 --> Router Class Initialized
INFO - 2024-12-10 04:16:31 --> Output Class Initialized
INFO - 2024-12-10 04:16:31 --> Security Class Initialized
DEBUG - 2024-12-10 04:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:31 --> Input Class Initialized
INFO - 2024-12-10 04:16:31 --> Language Class Initialized
INFO - 2024-12-10 04:16:31 --> Loader Class Initialized
INFO - 2024-12-10 04:16:31 --> Helper loaded: url_helper
INFO - 2024-12-10 04:16:31 --> Helper loaded: file_helper
INFO - 2024-12-10 04:16:31 --> Helper loaded: security_helper
INFO - 2024-12-10 04:16:31 --> Helper loaded: wpu_helper
INFO - 2024-12-10 04:16:31 --> Database Driver Class Initialized
INFO - 2024-12-10 04:16:31 --> Email Class Initialized
DEBUG - 2024-12-10 04:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-10 04:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 04:16:31 --> Helper loaded: form_helper
INFO - 2024-12-10 04:16:31 --> Form Validation Class Initialized
INFO - 2024-12-10 04:16:31 --> Controller Class Initialized
DEBUG - 2024-12-10 04:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-10 04:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-10 04:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-10 04:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-10 04:16:31 --> Final output sent to browser
DEBUG - 2024-12-10 04:16:31 --> Total execution time: 0.4319
INFO - 2024-12-10 04:16:56 --> Config Class Initialized
INFO - 2024-12-10 04:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:56 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:56 --> URI Class Initialized
INFO - 2024-12-10 04:16:56 --> Router Class Initialized
INFO - 2024-12-10 04:16:56 --> Output Class Initialized
INFO - 2024-12-10 04:16:56 --> Config Class Initialized
INFO - 2024-12-10 04:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:56 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:56 --> URI Class Initialized
INFO - 2024-12-10 04:16:56 --> Router Class Initialized
INFO - 2024-12-10 04:16:56 --> Security Class Initialized
DEBUG - 2024-12-10 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:56 --> Input Class Initialized
INFO - 2024-12-10 04:16:56 --> Language Class Initialized
INFO - 2024-12-10 04:16:56 --> Config Class Initialized
ERROR - 2024-12-10 04:16:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:56 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:56 --> URI Class Initialized
INFO - 2024-12-10 04:16:56 --> Output Class Initialized
INFO - 2024-12-10 04:16:56 --> Router Class Initialized
INFO - 2024-12-10 04:16:56 --> Security Class Initialized
INFO - 2024-12-10 04:16:56 --> Output Class Initialized
DEBUG - 2024-12-10 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:56 --> Input Class Initialized
INFO - 2024-12-10 04:16:56 --> Language Class Initialized
INFO - 2024-12-10 04:16:56 --> Security Class Initialized
ERROR - 2024-12-10 04:16:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:56 --> Input Class Initialized
INFO - 2024-12-10 04:16:56 --> Language Class Initialized
ERROR - 2024-12-10 04:16:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:16:57 --> Config Class Initialized
INFO - 2024-12-10 04:16:57 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:57 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:57 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:57 --> URI Class Initialized
INFO - 2024-12-10 04:16:57 --> Router Class Initialized
INFO - 2024-12-10 04:16:57 --> Output Class Initialized
INFO - 2024-12-10 04:16:57 --> Security Class Initialized
DEBUG - 2024-12-10 04:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:57 --> Input Class Initialized
INFO - 2024-12-10 04:16:57 --> Language Class Initialized
ERROR - 2024-12-10 04:16:57 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:16:58 --> Config Class Initialized
INFO - 2024-12-10 04:16:58 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:16:58 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:16:58 --> Utf8 Class Initialized
INFO - 2024-12-10 04:16:58 --> URI Class Initialized
INFO - 2024-12-10 04:16:58 --> Router Class Initialized
INFO - 2024-12-10 04:16:58 --> Output Class Initialized
INFO - 2024-12-10 04:16:58 --> Security Class Initialized
DEBUG - 2024-12-10 04:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:16:58 --> Input Class Initialized
INFO - 2024-12-10 04:16:58 --> Language Class Initialized
ERROR - 2024-12-10 04:16:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:17:27 --> Config Class Initialized
INFO - 2024-12-10 04:17:27 --> Hooks Class Initialized
INFO - 2024-12-10 04:17:27 --> Config Class Initialized
DEBUG - 2024-12-10 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:17:27 --> Hooks Class Initialized
INFO - 2024-12-10 04:17:27 --> Utf8 Class Initialized
INFO - 2024-12-10 04:17:27 --> URI Class Initialized
DEBUG - 2024-12-10 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:17:27 --> Utf8 Class Initialized
INFO - 2024-12-10 04:17:27 --> Router Class Initialized
INFO - 2024-12-10 04:17:27 --> URI Class Initialized
INFO - 2024-12-10 04:17:27 --> Output Class Initialized
INFO - 2024-12-10 04:17:27 --> Router Class Initialized
INFO - 2024-12-10 04:17:27 --> Security Class Initialized
INFO - 2024-12-10 04:17:27 --> Output Class Initialized
DEBUG - 2024-12-10 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:17:27 --> Input Class Initialized
INFO - 2024-12-10 04:17:27 --> Language Class Initialized
INFO - 2024-12-10 04:17:27 --> Security Class Initialized
ERROR - 2024-12-10 04:17:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:17:27 --> Input Class Initialized
INFO - 2024-12-10 04:17:27 --> Language Class Initialized
ERROR - 2024-12-10 04:17:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:17:27 --> Config Class Initialized
INFO - 2024-12-10 04:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:17:27 --> Config Class Initialized
INFO - 2024-12-10 04:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:17:27 --> Utf8 Class Initialized
INFO - 2024-12-10 04:17:27 --> Utf8 Class Initialized
INFO - 2024-12-10 04:17:27 --> URI Class Initialized
INFO - 2024-12-10 04:17:27 --> URI Class Initialized
INFO - 2024-12-10 04:17:27 --> Router Class Initialized
INFO - 2024-12-10 04:17:27 --> Router Class Initialized
INFO - 2024-12-10 04:17:27 --> Output Class Initialized
INFO - 2024-12-10 04:17:27 --> Output Class Initialized
INFO - 2024-12-10 04:17:27 --> Security Class Initialized
INFO - 2024-12-10 04:17:27 --> Security Class Initialized
DEBUG - 2024-12-10 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:17:27 --> Input Class Initialized
DEBUG - 2024-12-10 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:17:27 --> Input Class Initialized
INFO - 2024-12-10 04:17:27 --> Language Class Initialized
INFO - 2024-12-10 04:17:27 --> Language Class Initialized
ERROR - 2024-12-10 04:17:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-10 04:17:27 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:17:27 --> Config Class Initialized
INFO - 2024-12-10 04:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:17:27 --> Utf8 Class Initialized
INFO - 2024-12-10 04:17:27 --> URI Class Initialized
INFO - 2024-12-10 04:17:27 --> Router Class Initialized
INFO - 2024-12-10 04:17:27 --> Output Class Initialized
INFO - 2024-12-10 04:17:27 --> Security Class Initialized
DEBUG - 2024-12-10 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:17:27 --> Input Class Initialized
INFO - 2024-12-10 04:17:27 --> Language Class Initialized
ERROR - 2024-12-10 04:17:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:00 --> Config Class Initialized
INFO - 2024-12-10 04:18:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:00 --> Config Class Initialized
INFO - 2024-12-10 04:18:00 --> Hooks Class Initialized
INFO - 2024-12-10 04:18:00 --> Config Class Initialized
DEBUG - 2024-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:00 --> URI Class Initialized
INFO - 2024-12-10 04:18:00 --> URI Class Initialized
INFO - 2024-12-10 04:18:00 --> Router Class Initialized
INFO - 2024-12-10 04:18:00 --> Output Class Initialized
INFO - 2024-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:00 --> Input Class Initialized
INFO - 2024-12-10 04:18:00 --> Language Class Initialized
ERROR - 2024-12-10 04:18:00 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:00 --> URI Class Initialized
INFO - 2024-12-10 04:18:00 --> Router Class Initialized
INFO - 2024-12-10 04:18:00 --> Output Class Initialized
INFO - 2024-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:00 --> Input Class Initialized
INFO - 2024-12-10 04:18:00 --> Language Class Initialized
ERROR - 2024-12-10 04:18:00 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:00 --> Router Class Initialized
INFO - 2024-12-10 04:18:00 --> Output Class Initialized
INFO - 2024-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:00 --> Input Class Initialized
INFO - 2024-12-10 04:18:00 --> Language Class Initialized
ERROR - 2024-12-10 04:18:00 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:18:00 --> Config Class Initialized
INFO - 2024-12-10 04:18:00 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:00 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:00 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:00 --> URI Class Initialized
INFO - 2024-12-10 04:18:00 --> Router Class Initialized
INFO - 2024-12-10 04:18:00 --> Output Class Initialized
INFO - 2024-12-10 04:18:00 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:00 --> Input Class Initialized
INFO - 2024-12-10 04:18:00 --> Language Class Initialized
ERROR - 2024-12-10 04:18:00 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:01 --> Config Class Initialized
INFO - 2024-12-10 04:18:01 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:01 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:01 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:01 --> URI Class Initialized
INFO - 2024-12-10 04:18:01 --> Router Class Initialized
INFO - 2024-12-10 04:18:01 --> Output Class Initialized
INFO - 2024-12-10 04:18:01 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:01 --> Input Class Initialized
INFO - 2024-12-10 04:18:01 --> Language Class Initialized
ERROR - 2024-12-10 04:18:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:29 --> Config Class Initialized
INFO - 2024-12-10 04:18:29 --> Hooks Class Initialized
INFO - 2024-12-10 04:18:29 --> Config Class Initialized
INFO - 2024-12-10 04:18:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:29 --> Utf8 Class Initialized
DEBUG - 2024-12-10 04:18:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:29 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:29 --> URI Class Initialized
INFO - 2024-12-10 04:18:29 --> URI Class Initialized
INFO - 2024-12-10 04:18:29 --> Router Class Initialized
INFO - 2024-12-10 04:18:29 --> Router Class Initialized
INFO - 2024-12-10 04:18:29 --> Output Class Initialized
INFO - 2024-12-10 04:18:29 --> Output Class Initialized
INFO - 2024-12-10 04:18:29 --> Security Class Initialized
INFO - 2024-12-10 04:18:29 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-10 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:29 --> Input Class Initialized
INFO - 2024-12-10 04:18:29 --> Language Class Initialized
ERROR - 2024-12-10 04:18:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:29 --> Input Class Initialized
INFO - 2024-12-10 04:18:29 --> Language Class Initialized
ERROR - 2024-12-10 04:18:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:29 --> Config Class Initialized
INFO - 2024-12-10 04:18:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:29 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:29 --> URI Class Initialized
INFO - 2024-12-10 04:18:29 --> Router Class Initialized
INFO - 2024-12-10 04:18:29 --> Output Class Initialized
INFO - 2024-12-10 04:18:29 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:29 --> Input Class Initialized
INFO - 2024-12-10 04:18:29 --> Language Class Initialized
ERROR - 2024-12-10 04:18:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:18:30 --> Config Class Initialized
INFO - 2024-12-10 04:18:30 --> Config Class Initialized
INFO - 2024-12-10 04:18:30 --> Hooks Class Initialized
INFO - 2024-12-10 04:18:30 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2024-12-10 04:18:30 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:18:30 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:30 --> Utf8 Class Initialized
INFO - 2024-12-10 04:18:30 --> URI Class Initialized
INFO - 2024-12-10 04:18:30 --> URI Class Initialized
INFO - 2024-12-10 04:18:30 --> Router Class Initialized
INFO - 2024-12-10 04:18:30 --> Router Class Initialized
INFO - 2024-12-10 04:18:30 --> Output Class Initialized
INFO - 2024-12-10 04:18:30 --> Output Class Initialized
INFO - 2024-12-10 04:18:30 --> Security Class Initialized
INFO - 2024-12-10 04:18:30 --> Security Class Initialized
DEBUG - 2024-12-10 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:30 --> Input Class Initialized
INFO - 2024-12-10 04:18:30 --> Language Class Initialized
ERROR - 2024-12-10 04:18:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:18:30 --> Input Class Initialized
INFO - 2024-12-10 04:18:30 --> Language Class Initialized
ERROR - 2024-12-10 04:18:30 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:19:05 --> Config Class Initialized
INFO - 2024-12-10 04:19:05 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:05 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:05 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:05 --> URI Class Initialized
INFO - 2024-12-10 04:19:05 --> Config Class Initialized
INFO - 2024-12-10 04:19:05 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:05 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:05 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:05 --> Config Class Initialized
INFO - 2024-12-10 04:19:05 --> Hooks Class Initialized
INFO - 2024-12-10 04:19:05 --> URI Class Initialized
INFO - 2024-12-10 04:19:05 --> Config Class Initialized
INFO - 2024-12-10 04:19:05 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:05 --> UTF-8 Support Enabled
DEBUG - 2024-12-10 04:19:05 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:05 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:05 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:05 --> URI Class Initialized
INFO - 2024-12-10 04:19:05 --> Router Class Initialized
INFO - 2024-12-10 04:19:05 --> Output Class Initialized
INFO - 2024-12-10 04:19:05 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:05 --> Input Class Initialized
INFO - 2024-12-10 04:19:05 --> Language Class Initialized
ERROR - 2024-12-10 04:19:05 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:19:05 --> Router Class Initialized
INFO - 2024-12-10 04:19:05 --> Router Class Initialized
INFO - 2024-12-10 04:19:05 --> URI Class Initialized
INFO - 2024-12-10 04:19:05 --> Output Class Initialized
INFO - 2024-12-10 04:19:05 --> Router Class Initialized
INFO - 2024-12-10 04:19:05 --> Security Class Initialized
INFO - 2024-12-10 04:19:05 --> Output Class Initialized
INFO - 2024-12-10 04:19:05 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:05 --> Input Class Initialized
INFO - 2024-12-10 04:19:05 --> Language Class Initialized
ERROR - 2024-12-10 04:19:05 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:19:05 --> Output Class Initialized
INFO - 2024-12-10 04:19:05 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:05 --> Input Class Initialized
INFO - 2024-12-10 04:19:05 --> Language Class Initialized
ERROR - 2024-12-10 04:19:05 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:05 --> Input Class Initialized
INFO - 2024-12-10 04:19:05 --> Language Class Initialized
ERROR - 2024-12-10 04:19:05 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:19:06 --> Config Class Initialized
INFO - 2024-12-10 04:19:06 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:06 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:06 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:06 --> URI Class Initialized
INFO - 2024-12-10 04:19:06 --> Router Class Initialized
INFO - 2024-12-10 04:19:06 --> Output Class Initialized
INFO - 2024-12-10 04:19:06 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:06 --> Input Class Initialized
INFO - 2024-12-10 04:19:06 --> Language Class Initialized
ERROR - 2024-12-10 04:19:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:19:34 --> Config Class Initialized
INFO - 2024-12-10 04:19:34 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:34 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:34 --> URI Class Initialized
INFO - 2024-12-10 04:19:34 --> Router Class Initialized
INFO - 2024-12-10 04:19:34 --> Output Class Initialized
INFO - 2024-12-10 04:19:34 --> Config Class Initialized
INFO - 2024-12-10 04:19:34 --> Hooks Class Initialized
INFO - 2024-12-10 04:19:34 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:34 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:34 --> URI Class Initialized
INFO - 2024-12-10 04:19:34 --> Config Class Initialized
INFO - 2024-12-10 04:19:34 --> Hooks Class Initialized
INFO - 2024-12-10 04:19:34 --> Router Class Initialized
DEBUG - 2024-12-10 04:19:34 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:34 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:34 --> Output Class Initialized
INFO - 2024-12-10 04:19:34 --> URI Class Initialized
INFO - 2024-12-10 04:19:34 --> Router Class Initialized
INFO - 2024-12-10 04:19:34 --> Security Class Initialized
INFO - 2024-12-10 04:19:34 --> Output Class Initialized
DEBUG - 2024-12-10 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:34 --> Input Class Initialized
INFO - 2024-12-10 04:19:34 --> Security Class Initialized
INFO - 2024-12-10 04:19:34 --> Language Class Initialized
ERROR - 2024-12-10 04:19:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:34 --> Input Class Initialized
INFO - 2024-12-10 04:19:34 --> Language Class Initialized
ERROR - 2024-12-10 04:19:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-10 04:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:34 --> Input Class Initialized
INFO - 2024-12-10 04:19:34 --> Language Class Initialized
ERROR - 2024-12-10 04:19:34 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-10 04:19:35 --> Config Class Initialized
INFO - 2024-12-10 04:19:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:35 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:35 --> URI Class Initialized
INFO - 2024-12-10 04:19:35 --> Router Class Initialized
INFO - 2024-12-10 04:19:35 --> Output Class Initialized
INFO - 2024-12-10 04:19:35 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:35 --> Input Class Initialized
INFO - 2024-12-10 04:19:35 --> Language Class Initialized
ERROR - 2024-12-10 04:19:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 04:19:35 --> Config Class Initialized
INFO - 2024-12-10 04:19:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 04:19:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 04:19:35 --> Utf8 Class Initialized
INFO - 2024-12-10 04:19:35 --> URI Class Initialized
INFO - 2024-12-10 04:19:35 --> Router Class Initialized
INFO - 2024-12-10 04:19:35 --> Output Class Initialized
INFO - 2024-12-10 04:19:35 --> Security Class Initialized
DEBUG - 2024-12-10 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 04:19:35 --> Input Class Initialized
INFO - 2024-12-10 04:19:35 --> Language Class Initialized
ERROR - 2024-12-10 04:19:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-10 13:01:20 --> Config Class Initialized
INFO - 2024-12-10 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-12-10 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-12-10 13:01:20 --> Utf8 Class Initialized
INFO - 2024-12-10 13:01:20 --> URI Class Initialized
INFO - 2024-12-10 13:01:20 --> Router Class Initialized
INFO - 2024-12-10 13:01:20 --> Output Class Initialized
INFO - 2024-12-10 13:01:20 --> Security Class Initialized
DEBUG - 2024-12-10 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 13:01:20 --> Input Class Initialized
INFO - 2024-12-10 13:01:20 --> Language Class Initialized
ERROR - 2024-12-10 13:01:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-10 13:01:26 --> Config Class Initialized
INFO - 2024-12-10 13:01:26 --> Hooks Class Initialized
DEBUG - 2024-12-10 13:01:26 --> UTF-8 Support Enabled
INFO - 2024-12-10 13:01:26 --> Utf8 Class Initialized
INFO - 2024-12-10 13:01:26 --> URI Class Initialized
DEBUG - 2024-12-10 13:01:26 --> No URI present. Default controller set.
INFO - 2024-12-10 13:01:26 --> Router Class Initialized
INFO - 2024-12-10 13:01:26 --> Output Class Initialized
INFO - 2024-12-10 13:01:26 --> Security Class Initialized
DEBUG - 2024-12-10 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 13:01:26 --> Input Class Initialized
INFO - 2024-12-10 13:01:26 --> Language Class Initialized
INFO - 2024-12-10 13:01:26 --> Loader Class Initialized
INFO - 2024-12-10 13:01:26 --> Helper loaded: url_helper
INFO - 2024-12-10 13:01:26 --> Helper loaded: file_helper
INFO - 2024-12-10 13:01:26 --> Helper loaded: security_helper
INFO - 2024-12-10 13:01:26 --> Helper loaded: wpu_helper
INFO - 2024-12-10 13:01:26 --> Database Driver Class Initialized
ERROR - 2024-12-10 13:01:26 --> Unable to connect to the database
INFO - 2024-12-10 13:01:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-10 13:29:45 --> Config Class Initialized
INFO - 2024-12-10 13:29:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 13:29:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 13:29:45 --> Utf8 Class Initialized
INFO - 2024-12-10 13:29:45 --> URI Class Initialized
DEBUG - 2024-12-10 13:29:45 --> No URI present. Default controller set.
INFO - 2024-12-10 13:29:45 --> Router Class Initialized
INFO - 2024-12-10 13:29:45 --> Output Class Initialized
INFO - 2024-12-10 13:29:45 --> Security Class Initialized
DEBUG - 2024-12-10 13:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 13:29:45 --> Input Class Initialized
INFO - 2024-12-10 13:29:45 --> Language Class Initialized
INFO - 2024-12-10 13:29:45 --> Loader Class Initialized
INFO - 2024-12-10 13:29:45 --> Helper loaded: url_helper
INFO - 2024-12-10 13:29:45 --> Helper loaded: file_helper
INFO - 2024-12-10 13:29:45 --> Helper loaded: security_helper
INFO - 2024-12-10 13:29:45 --> Helper loaded: wpu_helper
INFO - 2024-12-10 13:29:45 --> Database Driver Class Initialized
ERROR - 2024-12-10 13:29:45 --> Unable to connect to the database
INFO - 2024-12-10 13:29:45 --> Language file loaded: language/english/db_lang.php
