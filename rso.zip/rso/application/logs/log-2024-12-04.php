<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-04 05:26:17 --> Config Class Initialized
INFO - 2024-12-04 05:26:17 --> Hooks Class Initialized
DEBUG - 2024-12-04 05:26:17 --> UTF-8 Support Enabled
INFO - 2024-12-04 05:26:17 --> Utf8 Class Initialized
INFO - 2024-12-04 05:26:17 --> URI Class Initialized
DEBUG - 2024-12-04 05:26:17 --> No URI present. Default controller set.
INFO - 2024-12-04 05:26:17 --> Router Class Initialized
INFO - 2024-12-04 05:26:17 --> Output Class Initialized
INFO - 2024-12-04 05:26:17 --> Security Class Initialized
DEBUG - 2024-12-04 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 05:26:17 --> Input Class Initialized
INFO - 2024-12-04 05:26:17 --> Language Class Initialized
INFO - 2024-12-04 05:26:17 --> Loader Class Initialized
INFO - 2024-12-04 05:26:17 --> Helper loaded: url_helper
INFO - 2024-12-04 05:26:17 --> Helper loaded: file_helper
INFO - 2024-12-04 05:26:17 --> Helper loaded: security_helper
INFO - 2024-12-04 05:26:17 --> Helper loaded: wpu_helper
INFO - 2024-12-04 05:26:17 --> Database Driver Class Initialized
INFO - 2024-12-04 05:46:26 --> Config Class Initialized
INFO - 2024-12-04 05:46:26 --> Hooks Class Initialized
DEBUG - 2024-12-04 05:46:26 --> UTF-8 Support Enabled
INFO - 2024-12-04 05:46:26 --> Utf8 Class Initialized
INFO - 2024-12-04 05:46:26 --> URI Class Initialized
DEBUG - 2024-12-04 05:46:26 --> No URI present. Default controller set.
INFO - 2024-12-04 05:46:26 --> Router Class Initialized
INFO - 2024-12-04 05:46:26 --> Output Class Initialized
INFO - 2024-12-04 05:46:26 --> Security Class Initialized
DEBUG - 2024-12-04 05:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 05:46:26 --> Input Class Initialized
INFO - 2024-12-04 05:46:26 --> Language Class Initialized
INFO - 2024-12-04 05:46:26 --> Loader Class Initialized
INFO - 2024-12-04 05:46:26 --> Helper loaded: url_helper
INFO - 2024-12-04 05:46:26 --> Helper loaded: file_helper
INFO - 2024-12-04 05:46:26 --> Helper loaded: security_helper
INFO - 2024-12-04 05:46:26 --> Helper loaded: wpu_helper
INFO - 2024-12-04 05:46:26 --> Database Driver Class Initialized
INFO - 2024-12-04 05:58:14 --> Config Class Initialized
INFO - 2024-12-04 05:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-04 05:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-04 05:58:14 --> Utf8 Class Initialized
INFO - 2024-12-04 05:58:14 --> URI Class Initialized
DEBUG - 2024-12-04 05:58:14 --> No URI present. Default controller set.
INFO - 2024-12-04 05:58:14 --> Router Class Initialized
INFO - 2024-12-04 05:58:14 --> Output Class Initialized
INFO - 2024-12-04 05:58:14 --> Security Class Initialized
DEBUG - 2024-12-04 05:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 05:58:14 --> Input Class Initialized
INFO - 2024-12-04 05:58:14 --> Language Class Initialized
INFO - 2024-12-04 05:58:14 --> Loader Class Initialized
INFO - 2024-12-04 05:58:14 --> Helper loaded: url_helper
INFO - 2024-12-04 05:58:14 --> Helper loaded: file_helper
INFO - 2024-12-04 05:58:14 --> Helper loaded: security_helper
INFO - 2024-12-04 05:58:14 --> Helper loaded: wpu_helper
INFO - 2024-12-04 05:58:14 --> Database Driver Class Initialized
INFO - 2024-12-04 05:59:05 --> Config Class Initialized
INFO - 2024-12-04 05:59:05 --> Hooks Class Initialized
DEBUG - 2024-12-04 05:59:05 --> UTF-8 Support Enabled
INFO - 2024-12-04 05:59:05 --> Utf8 Class Initialized
INFO - 2024-12-04 05:59:05 --> URI Class Initialized
DEBUG - 2024-12-04 05:59:05 --> No URI present. Default controller set.
INFO - 2024-12-04 05:59:05 --> Router Class Initialized
INFO - 2024-12-04 05:59:05 --> Output Class Initialized
INFO - 2024-12-04 05:59:05 --> Security Class Initialized
DEBUG - 2024-12-04 05:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 05:59:05 --> Input Class Initialized
INFO - 2024-12-04 05:59:05 --> Language Class Initialized
INFO - 2024-12-04 05:59:05 --> Loader Class Initialized
INFO - 2024-12-04 05:59:05 --> Helper loaded: url_helper
INFO - 2024-12-04 05:59:05 --> Helper loaded: file_helper
INFO - 2024-12-04 05:59:05 --> Helper loaded: security_helper
INFO - 2024-12-04 05:59:05 --> Helper loaded: wpu_helper
INFO - 2024-12-04 05:59:05 --> Database Driver Class Initialized
INFO - 2024-12-04 06:00:11 --> Config Class Initialized
INFO - 2024-12-04 06:00:11 --> Hooks Class Initialized
DEBUG - 2024-12-04 06:00:11 --> UTF-8 Support Enabled
INFO - 2024-12-04 06:00:11 --> Utf8 Class Initialized
INFO - 2024-12-04 06:00:11 --> URI Class Initialized
DEBUG - 2024-12-04 06:00:11 --> No URI present. Default controller set.
INFO - 2024-12-04 06:00:11 --> Router Class Initialized
INFO - 2024-12-04 06:00:11 --> Output Class Initialized
INFO - 2024-12-04 06:00:11 --> Security Class Initialized
DEBUG - 2024-12-04 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 06:00:11 --> Input Class Initialized
INFO - 2024-12-04 06:00:11 --> Language Class Initialized
INFO - 2024-12-04 06:00:11 --> Loader Class Initialized
INFO - 2024-12-04 06:00:11 --> Helper loaded: url_helper
INFO - 2024-12-04 06:00:11 --> Helper loaded: file_helper
INFO - 2024-12-04 06:00:11 --> Helper loaded: security_helper
INFO - 2024-12-04 06:00:11 --> Helper loaded: wpu_helper
INFO - 2024-12-04 06:00:11 --> Database Driver Class Initialized
INFO - 2024-12-04 06:18:38 --> Config Class Initialized
INFO - 2024-12-04 06:18:38 --> Hooks Class Initialized
DEBUG - 2024-12-04 06:18:38 --> UTF-8 Support Enabled
INFO - 2024-12-04 06:18:38 --> Utf8 Class Initialized
INFO - 2024-12-04 06:18:38 --> URI Class Initialized
DEBUG - 2024-12-04 06:18:38 --> No URI present. Default controller set.
INFO - 2024-12-04 06:18:38 --> Router Class Initialized
INFO - 2024-12-04 06:18:38 --> Output Class Initialized
INFO - 2024-12-04 06:18:38 --> Security Class Initialized
DEBUG - 2024-12-04 06:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 06:18:38 --> Input Class Initialized
INFO - 2024-12-04 06:18:38 --> Language Class Initialized
INFO - 2024-12-04 06:18:38 --> Loader Class Initialized
INFO - 2024-12-04 06:18:38 --> Helper loaded: url_helper
INFO - 2024-12-04 06:18:38 --> Helper loaded: file_helper
INFO - 2024-12-04 06:18:38 --> Helper loaded: security_helper
INFO - 2024-12-04 06:18:38 --> Helper loaded: wpu_helper
INFO - 2024-12-04 06:18:38 --> Database Driver Class Initialized
INFO - 2024-12-04 06:18:42 --> Config Class Initialized
INFO - 2024-12-04 06:18:42 --> Hooks Class Initialized
DEBUG - 2024-12-04 06:18:42 --> UTF-8 Support Enabled
INFO - 2024-12-04 06:18:42 --> Utf8 Class Initialized
INFO - 2024-12-04 06:18:42 --> URI Class Initialized
DEBUG - 2024-12-04 06:18:42 --> No URI present. Default controller set.
INFO - 2024-12-04 06:18:42 --> Router Class Initialized
INFO - 2024-12-04 06:18:42 --> Output Class Initialized
INFO - 2024-12-04 06:18:42 --> Security Class Initialized
DEBUG - 2024-12-04 06:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 06:18:42 --> Input Class Initialized
INFO - 2024-12-04 06:18:42 --> Language Class Initialized
INFO - 2024-12-04 06:18:42 --> Loader Class Initialized
INFO - 2024-12-04 06:18:42 --> Helper loaded: url_helper
INFO - 2024-12-04 06:18:42 --> Helper loaded: file_helper
INFO - 2024-12-04 06:18:42 --> Helper loaded: security_helper
INFO - 2024-12-04 06:18:42 --> Helper loaded: wpu_helper
INFO - 2024-12-04 06:18:42 --> Database Driver Class Initialized
INFO - 2024-12-04 08:49:02 --> Config Class Initialized
INFO - 2024-12-04 08:49:02 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:49:02 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:49:02 --> Utf8 Class Initialized
INFO - 2024-12-04 08:49:02 --> URI Class Initialized
DEBUG - 2024-12-04 08:49:02 --> No URI present. Default controller set.
INFO - 2024-12-04 08:49:02 --> Router Class Initialized
INFO - 2024-12-04 08:49:02 --> Output Class Initialized
INFO - 2024-12-04 08:49:02 --> Security Class Initialized
DEBUG - 2024-12-04 08:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:49:02 --> Input Class Initialized
INFO - 2024-12-04 08:49:02 --> Language Class Initialized
INFO - 2024-12-04 08:49:02 --> Loader Class Initialized
INFO - 2024-12-04 08:49:02 --> Helper loaded: url_helper
INFO - 2024-12-04 08:49:02 --> Helper loaded: file_helper
INFO - 2024-12-04 08:49:02 --> Helper loaded: security_helper
INFO - 2024-12-04 08:49:02 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:49:02 --> Database Driver Class Initialized
INFO - 2024-12-04 08:50:37 --> Config Class Initialized
INFO - 2024-12-04 08:50:37 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:50:37 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:50:37 --> Utf8 Class Initialized
INFO - 2024-12-04 08:50:37 --> URI Class Initialized
DEBUG - 2024-12-04 08:50:37 --> No URI present. Default controller set.
INFO - 2024-12-04 08:50:37 --> Router Class Initialized
INFO - 2024-12-04 08:50:37 --> Output Class Initialized
INFO - 2024-12-04 08:50:37 --> Security Class Initialized
DEBUG - 2024-12-04 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:50:37 --> Input Class Initialized
INFO - 2024-12-04 08:50:37 --> Language Class Initialized
INFO - 2024-12-04 08:50:37 --> Loader Class Initialized
INFO - 2024-12-04 08:50:37 --> Helper loaded: url_helper
INFO - 2024-12-04 08:50:37 --> Helper loaded: file_helper
INFO - 2024-12-04 08:50:37 --> Helper loaded: security_helper
INFO - 2024-12-04 08:50:37 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:50:37 --> Database Driver Class Initialized
INFO - 2024-12-04 08:53:08 --> Config Class Initialized
INFO - 2024-12-04 08:53:08 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:53:08 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:53:08 --> Utf8 Class Initialized
INFO - 2024-12-04 08:53:08 --> URI Class Initialized
DEBUG - 2024-12-04 08:53:08 --> No URI present. Default controller set.
INFO - 2024-12-04 08:53:08 --> Router Class Initialized
INFO - 2024-12-04 08:53:08 --> Output Class Initialized
INFO - 2024-12-04 08:53:08 --> Security Class Initialized
DEBUG - 2024-12-04 08:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:53:08 --> Input Class Initialized
INFO - 2024-12-04 08:53:08 --> Language Class Initialized
INFO - 2024-12-04 08:53:08 --> Loader Class Initialized
INFO - 2024-12-04 08:53:08 --> Helper loaded: url_helper
INFO - 2024-12-04 08:53:08 --> Helper loaded: file_helper
INFO - 2024-12-04 08:53:08 --> Helper loaded: security_helper
INFO - 2024-12-04 08:53:08 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:53:08 --> Database Driver Class Initialized
INFO - 2024-12-04 08:55:20 --> Config Class Initialized
INFO - 2024-12-04 08:55:20 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:55:20 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:55:20 --> Utf8 Class Initialized
INFO - 2024-12-04 08:55:20 --> URI Class Initialized
DEBUG - 2024-12-04 08:55:20 --> No URI present. Default controller set.
INFO - 2024-12-04 08:55:20 --> Router Class Initialized
INFO - 2024-12-04 08:55:20 --> Output Class Initialized
INFO - 2024-12-04 08:55:20 --> Security Class Initialized
DEBUG - 2024-12-04 08:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:55:20 --> Input Class Initialized
INFO - 2024-12-04 08:55:20 --> Language Class Initialized
INFO - 2024-12-04 08:55:20 --> Loader Class Initialized
INFO - 2024-12-04 08:55:20 --> Helper loaded: url_helper
INFO - 2024-12-04 08:55:20 --> Helper loaded: file_helper
INFO - 2024-12-04 08:55:20 --> Helper loaded: security_helper
INFO - 2024-12-04 08:55:20 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:55:20 --> Database Driver Class Initialized
ERROR - 2024-12-04 08:55:23 --> Unable to connect to the database
INFO - 2024-12-04 08:55:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-04 08:56:21 --> Config Class Initialized
INFO - 2024-12-04 08:56:21 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:56:21 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:56:21 --> Utf8 Class Initialized
INFO - 2024-12-04 08:56:21 --> URI Class Initialized
DEBUG - 2024-12-04 08:56:21 --> No URI present. Default controller set.
INFO - 2024-12-04 08:56:21 --> Router Class Initialized
INFO - 2024-12-04 08:56:21 --> Output Class Initialized
INFO - 2024-12-04 08:56:21 --> Security Class Initialized
DEBUG - 2024-12-04 08:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:56:21 --> Input Class Initialized
INFO - 2024-12-04 08:56:21 --> Language Class Initialized
INFO - 2024-12-04 08:56:21 --> Loader Class Initialized
INFO - 2024-12-04 08:56:21 --> Helper loaded: url_helper
INFO - 2024-12-04 08:56:21 --> Helper loaded: file_helper
INFO - 2024-12-04 08:56:21 --> Helper loaded: security_helper
INFO - 2024-12-04 08:56:21 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:56:21 --> Database Driver Class Initialized
INFO - 2024-12-04 08:58:08 --> Config Class Initialized
INFO - 2024-12-04 08:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:58:08 --> Utf8 Class Initialized
INFO - 2024-12-04 08:58:08 --> URI Class Initialized
DEBUG - 2024-12-04 08:58:08 --> No URI present. Default controller set.
INFO - 2024-12-04 08:58:08 --> Router Class Initialized
INFO - 2024-12-04 08:58:08 --> Output Class Initialized
INFO - 2024-12-04 08:58:08 --> Security Class Initialized
DEBUG - 2024-12-04 08:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:58:08 --> Input Class Initialized
INFO - 2024-12-04 08:58:08 --> Language Class Initialized
INFO - 2024-12-04 08:58:08 --> Loader Class Initialized
INFO - 2024-12-04 08:58:08 --> Helper loaded: url_helper
INFO - 2024-12-04 08:58:08 --> Helper loaded: file_helper
INFO - 2024-12-04 08:58:08 --> Helper loaded: security_helper
INFO - 2024-12-04 08:58:08 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:58:08 --> Database Driver Class Initialized
INFO - 2024-12-04 08:58:09 --> Email Class Initialized
DEBUG - 2024-12-04 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:58:09 --> Helper loaded: form_helper
INFO - 2024-12-04 08:58:09 --> Form Validation Class Initialized
INFO - 2024-12-04 08:58:09 --> Controller Class Initialized
DEBUG - 2024-12-04 08:58:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:58:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-04 08:58:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-04 08:58:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-04 08:58:09 --> Final output sent to browser
DEBUG - 2024-12-04 08:58:09 --> Total execution time: 0.4334
INFO - 2024-12-04 08:58:21 --> Config Class Initialized
INFO - 2024-12-04 08:58:21 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:58:21 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:58:21 --> Utf8 Class Initialized
INFO - 2024-12-04 08:58:21 --> URI Class Initialized
INFO - 2024-12-04 08:58:21 --> Router Class Initialized
INFO - 2024-12-04 08:58:21 --> Output Class Initialized
INFO - 2024-12-04 08:58:21 --> Security Class Initialized
DEBUG - 2024-12-04 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:58:21 --> Input Class Initialized
INFO - 2024-12-04 08:58:21 --> Language Class Initialized
INFO - 2024-12-04 08:58:21 --> Loader Class Initialized
INFO - 2024-12-04 08:58:21 --> Helper loaded: url_helper
INFO - 2024-12-04 08:58:21 --> Helper loaded: file_helper
INFO - 2024-12-04 08:58:21 --> Helper loaded: security_helper
INFO - 2024-12-04 08:58:21 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:58:21 --> Database Driver Class Initialized
INFO - 2024-12-04 08:58:22 --> Email Class Initialized
DEBUG - 2024-12-04 08:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:58:22 --> Helper loaded: form_helper
INFO - 2024-12-04 08:58:22 --> Form Validation Class Initialized
INFO - 2024-12-04 08:58:22 --> Controller Class Initialized
DEBUG - 2024-12-04 08:58:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:58:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-04 08:58:22 --> Config Class Initialized
INFO - 2024-12-04 08:58:22 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:58:22 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:58:22 --> Utf8 Class Initialized
INFO - 2024-12-04 08:58:22 --> URI Class Initialized
INFO - 2024-12-04 08:58:22 --> Router Class Initialized
INFO - 2024-12-04 08:58:22 --> Output Class Initialized
INFO - 2024-12-04 08:58:22 --> Security Class Initialized
DEBUG - 2024-12-04 08:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:58:22 --> Input Class Initialized
INFO - 2024-12-04 08:58:22 --> Language Class Initialized
INFO - 2024-12-04 08:58:22 --> Loader Class Initialized
INFO - 2024-12-04 08:58:22 --> Helper loaded: url_helper
INFO - 2024-12-04 08:58:22 --> Helper loaded: file_helper
INFO - 2024-12-04 08:58:22 --> Helper loaded: security_helper
INFO - 2024-12-04 08:58:22 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:58:22 --> Database Driver Class Initialized
INFO - 2024-12-04 08:58:22 --> Email Class Initialized
DEBUG - 2024-12-04 08:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:58:22 --> Helper loaded: form_helper
INFO - 2024-12-04 08:58:22 --> Form Validation Class Initialized
INFO - 2024-12-04 08:58:22 --> Controller Class Initialized
INFO - 2024-12-04 08:58:22 --> Model "Antrol_model" initialized
DEBUG - 2024-12-04 08:58:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:58:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-04 08:58:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-04 08:58:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-04 08:58:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-04 08:58:23 --> Final output sent to browser
DEBUG - 2024-12-04 08:58:23 --> Total execution time: 0.9917
INFO - 2024-12-04 08:59:09 --> Config Class Initialized
INFO - 2024-12-04 08:59:09 --> Hooks Class Initialized
DEBUG - 2024-12-04 08:59:09 --> UTF-8 Support Enabled
INFO - 2024-12-04 08:59:09 --> Utf8 Class Initialized
INFO - 2024-12-04 08:59:09 --> URI Class Initialized
INFO - 2024-12-04 08:59:09 --> Router Class Initialized
INFO - 2024-12-04 08:59:09 --> Output Class Initialized
INFO - 2024-12-04 08:59:09 --> Security Class Initialized
DEBUG - 2024-12-04 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 08:59:09 --> Input Class Initialized
INFO - 2024-12-04 08:59:09 --> Language Class Initialized
INFO - 2024-12-04 08:59:09 --> Loader Class Initialized
INFO - 2024-12-04 08:59:09 --> Helper loaded: url_helper
INFO - 2024-12-04 08:59:09 --> Helper loaded: file_helper
INFO - 2024-12-04 08:59:09 --> Helper loaded: security_helper
INFO - 2024-12-04 08:59:09 --> Helper loaded: wpu_helper
INFO - 2024-12-04 08:59:09 --> Database Driver Class Initialized
INFO - 2024-12-04 08:59:09 --> Email Class Initialized
DEBUG - 2024-12-04 08:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 08:59:09 --> Helper loaded: form_helper
INFO - 2024-12-04 08:59:09 --> Form Validation Class Initialized
INFO - 2024-12-04 08:59:09 --> Controller Class Initialized
INFO - 2024-12-04 08:59:09 --> Model "Antrol_model" initialized
DEBUG - 2024-12-04 08:59:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 08:59:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-04 08:59:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-04 08:59:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-04 08:59:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-04 08:59:10 --> Final output sent to browser
DEBUG - 2024-12-04 08:59:10 --> Total execution time: 1.0298
INFO - 2024-12-04 09:00:40 --> Config Class Initialized
INFO - 2024-12-04 09:00:40 --> Hooks Class Initialized
DEBUG - 2024-12-04 09:00:40 --> UTF-8 Support Enabled
INFO - 2024-12-04 09:00:40 --> Utf8 Class Initialized
INFO - 2024-12-04 09:00:40 --> URI Class Initialized
INFO - 2024-12-04 09:00:40 --> Router Class Initialized
INFO - 2024-12-04 09:00:40 --> Output Class Initialized
INFO - 2024-12-04 09:00:40 --> Security Class Initialized
DEBUG - 2024-12-04 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 09:00:40 --> Input Class Initialized
INFO - 2024-12-04 09:00:40 --> Language Class Initialized
INFO - 2024-12-04 09:00:40 --> Loader Class Initialized
INFO - 2024-12-04 09:00:40 --> Helper loaded: url_helper
INFO - 2024-12-04 09:00:40 --> Helper loaded: file_helper
INFO - 2024-12-04 09:00:40 --> Helper loaded: security_helper
INFO - 2024-12-04 09:00:40 --> Helper loaded: wpu_helper
INFO - 2024-12-04 09:00:40 --> Database Driver Class Initialized
INFO - 2024-12-04 09:00:41 --> Email Class Initialized
DEBUG - 2024-12-04 09:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 09:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 09:00:41 --> Helper loaded: form_helper
INFO - 2024-12-04 09:00:41 --> Form Validation Class Initialized
INFO - 2024-12-04 09:00:41 --> Controller Class Initialized
INFO - 2024-12-04 09:00:41 --> Model "Antrol_model" initialized
DEBUG - 2024-12-04 09:00:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 09:00:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-04 09:00:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-04 09:00:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-04 09:00:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-04 09:00:41 --> Final output sent to browser
DEBUG - 2024-12-04 09:00:41 --> Total execution time: 0.9500
INFO - 2024-12-04 14:50:47 --> Config Class Initialized
INFO - 2024-12-04 14:50:47 --> Hooks Class Initialized
DEBUG - 2024-12-04 14:50:47 --> UTF-8 Support Enabled
INFO - 2024-12-04 14:50:47 --> Utf8 Class Initialized
INFO - 2024-12-04 14:50:47 --> URI Class Initialized
DEBUG - 2024-12-04 14:50:47 --> No URI present. Default controller set.
INFO - 2024-12-04 14:50:47 --> Router Class Initialized
INFO - 2024-12-04 14:50:47 --> Output Class Initialized
INFO - 2024-12-04 14:50:47 --> Security Class Initialized
DEBUG - 2024-12-04 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 14:50:47 --> Input Class Initialized
INFO - 2024-12-04 14:50:47 --> Language Class Initialized
INFO - 2024-12-04 14:50:47 --> Loader Class Initialized
INFO - 2024-12-04 14:50:47 --> Helper loaded: url_helper
INFO - 2024-12-04 14:50:47 --> Helper loaded: file_helper
INFO - 2024-12-04 14:50:47 --> Helper loaded: security_helper
INFO - 2024-12-04 14:50:47 --> Helper loaded: wpu_helper
INFO - 2024-12-04 14:50:47 --> Database Driver Class Initialized
INFO - 2024-12-04 14:50:47 --> Email Class Initialized
DEBUG - 2024-12-04 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 14:50:47 --> Helper loaded: form_helper
INFO - 2024-12-04 14:50:47 --> Form Validation Class Initialized
INFO - 2024-12-04 14:50:47 --> Controller Class Initialized
DEBUG - 2024-12-04 14:50:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 14:50:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-04 14:50:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-04 14:50:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-04 14:50:47 --> Final output sent to browser
DEBUG - 2024-12-04 14:50:47 --> Total execution time: 0.4276
INFO - 2024-12-04 20:00:20 --> Config Class Initialized
INFO - 2024-12-04 20:00:20 --> Hooks Class Initialized
DEBUG - 2024-12-04 20:00:20 --> UTF-8 Support Enabled
INFO - 2024-12-04 20:00:20 --> Utf8 Class Initialized
INFO - 2024-12-04 20:00:20 --> URI Class Initialized
DEBUG - 2024-12-04 20:00:20 --> No URI present. Default controller set.
INFO - 2024-12-04 20:00:20 --> Router Class Initialized
INFO - 2024-12-04 20:00:20 --> Output Class Initialized
INFO - 2024-12-04 20:00:20 --> Security Class Initialized
DEBUG - 2024-12-04 20:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 20:00:20 --> Input Class Initialized
INFO - 2024-12-04 20:00:20 --> Language Class Initialized
INFO - 2024-12-04 20:00:20 --> Loader Class Initialized
INFO - 2024-12-04 20:00:20 --> Helper loaded: url_helper
INFO - 2024-12-04 20:00:20 --> Helper loaded: file_helper
INFO - 2024-12-04 20:00:20 --> Helper loaded: security_helper
INFO - 2024-12-04 20:00:20 --> Helper loaded: wpu_helper
INFO - 2024-12-04 20:00:20 --> Database Driver Class Initialized
INFO - 2024-12-04 20:00:21 --> Email Class Initialized
DEBUG - 2024-12-04 20:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 20:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 20:00:21 --> Helper loaded: form_helper
INFO - 2024-12-04 20:00:21 --> Form Validation Class Initialized
INFO - 2024-12-04 20:00:21 --> Controller Class Initialized
DEBUG - 2024-12-04 20:00:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 20:00:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-04 20:00:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-04 20:00:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-04 20:00:21 --> Final output sent to browser
DEBUG - 2024-12-04 20:00:21 --> Total execution time: 0.4356
INFO - 2024-12-04 20:00:22 --> Config Class Initialized
INFO - 2024-12-04 20:00:22 --> Hooks Class Initialized
DEBUG - 2024-12-04 20:00:22 --> UTF-8 Support Enabled
INFO - 2024-12-04 20:00:22 --> Utf8 Class Initialized
INFO - 2024-12-04 20:00:22 --> URI Class Initialized
DEBUG - 2024-12-04 20:00:22 --> No URI present. Default controller set.
INFO - 2024-12-04 20:00:22 --> Router Class Initialized
INFO - 2024-12-04 20:00:22 --> Output Class Initialized
INFO - 2024-12-04 20:00:22 --> Security Class Initialized
DEBUG - 2024-12-04 20:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 20:00:22 --> Input Class Initialized
INFO - 2024-12-04 20:00:22 --> Language Class Initialized
INFO - 2024-12-04 20:00:22 --> Loader Class Initialized
INFO - 2024-12-04 20:00:22 --> Helper loaded: url_helper
INFO - 2024-12-04 20:00:22 --> Helper loaded: file_helper
INFO - 2024-12-04 20:00:22 --> Helper loaded: security_helper
INFO - 2024-12-04 20:00:22 --> Helper loaded: wpu_helper
INFO - 2024-12-04 20:00:22 --> Database Driver Class Initialized
INFO - 2024-12-04 20:00:23 --> Email Class Initialized
DEBUG - 2024-12-04 20:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-04 20:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 20:00:23 --> Helper loaded: form_helper
INFO - 2024-12-04 20:00:23 --> Form Validation Class Initialized
INFO - 2024-12-04 20:00:23 --> Controller Class Initialized
DEBUG - 2024-12-04 20:00:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-04 20:00:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-04 20:00:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-04 20:00:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-04 20:00:23 --> Final output sent to browser
DEBUG - 2024-12-04 20:00:23 --> Total execution time: 0.4458
