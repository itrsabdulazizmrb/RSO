<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-19 08:48:09 --> Config Class Initialized
INFO - 2024-10-19 08:48:09 --> Hooks Class Initialized
DEBUG - 2024-10-19 08:48:09 --> UTF-8 Support Enabled
INFO - 2024-10-19 08:48:09 --> Utf8 Class Initialized
INFO - 2024-10-19 08:48:09 --> URI Class Initialized
DEBUG - 2024-10-19 08:48:09 --> No URI present. Default controller set.
INFO - 2024-10-19 08:48:09 --> Router Class Initialized
INFO - 2024-10-19 08:48:09 --> Output Class Initialized
INFO - 2024-10-19 08:48:09 --> Security Class Initialized
DEBUG - 2024-10-19 08:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 08:48:09 --> Input Class Initialized
INFO - 2024-10-19 08:48:09 --> Language Class Initialized
INFO - 2024-10-19 08:48:09 --> Loader Class Initialized
INFO - 2024-10-19 08:48:09 --> Helper loaded: url_helper
INFO - 2024-10-19 08:48:09 --> Helper loaded: file_helper
INFO - 2024-10-19 08:48:09 --> Helper loaded: security_helper
INFO - 2024-10-19 08:48:09 --> Helper loaded: wpu_helper
INFO - 2024-10-19 08:48:09 --> Database Driver Class Initialized
INFO - 2024-10-19 08:48:09 --> Email Class Initialized
DEBUG - 2024-10-19 08:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-19 08:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 08:48:09 --> Helper loaded: form_helper
INFO - 2024-10-19 08:48:09 --> Form Validation Class Initialized
INFO - 2024-10-19 08:48:09 --> Controller Class Initialized
DEBUG - 2024-10-19 08:48:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-19 08:48:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-19 08:48:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-19 08:48:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-19 08:48:09 --> Final output sent to browser
DEBUG - 2024-10-19 08:48:09 --> Total execution time: 0.2296
