<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-27 04:29:23 --> Config Class Initialized
INFO - 2024-09-27 04:29:23 --> Hooks Class Initialized
DEBUG - 2024-09-27 04:29:23 --> UTF-8 Support Enabled
INFO - 2024-09-27 04:29:23 --> Utf8 Class Initialized
INFO - 2024-09-27 04:29:23 --> URI Class Initialized
DEBUG - 2024-09-27 04:29:23 --> No URI present. Default controller set.
INFO - 2024-09-27 04:29:23 --> Router Class Initialized
INFO - 2024-09-27 04:29:23 --> Output Class Initialized
INFO - 2024-09-27 04:29:23 --> Security Class Initialized
DEBUG - 2024-09-27 04:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 04:29:23 --> Input Class Initialized
INFO - 2024-09-27 04:29:23 --> Language Class Initialized
INFO - 2024-09-27 04:29:23 --> Loader Class Initialized
INFO - 2024-09-27 04:29:23 --> Helper loaded: url_helper
INFO - 2024-09-27 04:29:23 --> Helper loaded: file_helper
INFO - 2024-09-27 04:29:23 --> Helper loaded: security_helper
INFO - 2024-09-27 04:29:23 --> Helper loaded: wpu_helper
INFO - 2024-09-27 04:29:23 --> Database Driver Class Initialized
INFO - 2024-09-27 04:29:26 --> Config Class Initialized
INFO - 2024-09-27 04:29:26 --> Hooks Class Initialized
DEBUG - 2024-09-27 04:29:26 --> UTF-8 Support Enabled
INFO - 2024-09-27 04:29:26 --> Utf8 Class Initialized
INFO - 2024-09-27 04:29:26 --> URI Class Initialized
DEBUG - 2024-09-27 04:29:26 --> No URI present. Default controller set.
INFO - 2024-09-27 04:29:26 --> Router Class Initialized
INFO - 2024-09-27 04:29:26 --> Output Class Initialized
INFO - 2024-09-27 04:29:26 --> Security Class Initialized
DEBUG - 2024-09-27 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 04:29:26 --> Input Class Initialized
INFO - 2024-09-27 04:29:26 --> Language Class Initialized
INFO - 2024-09-27 04:29:26 --> Loader Class Initialized
INFO - 2024-09-27 04:29:26 --> Helper loaded: url_helper
INFO - 2024-09-27 04:29:26 --> Helper loaded: file_helper
INFO - 2024-09-27 04:29:26 --> Helper loaded: security_helper
INFO - 2024-09-27 04:29:26 --> Helper loaded: wpu_helper
INFO - 2024-09-27 04:29:26 --> Database Driver Class Initialized
INFO - 2024-09-27 16:50:53 --> Config Class Initialized
INFO - 2024-09-27 16:50:53 --> Hooks Class Initialized
DEBUG - 2024-09-27 16:50:53 --> UTF-8 Support Enabled
INFO - 2024-09-27 16:50:53 --> Utf8 Class Initialized
INFO - 2024-09-27 16:50:53 --> URI Class Initialized
DEBUG - 2024-09-27 16:50:53 --> No URI present. Default controller set.
INFO - 2024-09-27 16:50:53 --> Router Class Initialized
INFO - 2024-09-27 16:50:53 --> Output Class Initialized
INFO - 2024-09-27 16:50:53 --> Security Class Initialized
DEBUG - 2024-09-27 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 16:50:53 --> Input Class Initialized
INFO - 2024-09-27 16:50:53 --> Language Class Initialized
INFO - 2024-09-27 16:50:53 --> Loader Class Initialized
INFO - 2024-09-27 16:50:53 --> Helper loaded: url_helper
INFO - 2024-09-27 16:50:53 --> Helper loaded: file_helper
INFO - 2024-09-27 16:50:53 --> Helper loaded: security_helper
INFO - 2024-09-27 16:50:53 --> Helper loaded: wpu_helper
INFO - 2024-09-27 16:50:53 --> Database Driver Class Initialized
