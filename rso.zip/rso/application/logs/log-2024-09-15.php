<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-15 05:06:58 --> Config Class Initialized
INFO - 2024-09-15 05:06:58 --> Hooks Class Initialized
DEBUG - 2024-09-15 05:06:58 --> UTF-8 Support Enabled
INFO - 2024-09-15 05:06:58 --> Utf8 Class Initialized
INFO - 2024-09-15 05:06:58 --> URI Class Initialized
DEBUG - 2024-09-15 05:06:58 --> No URI present. Default controller set.
INFO - 2024-09-15 05:06:58 --> Router Class Initialized
INFO - 2024-09-15 05:06:58 --> Output Class Initialized
INFO - 2024-09-15 05:06:58 --> Security Class Initialized
DEBUG - 2024-09-15 05:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 05:06:58 --> Input Class Initialized
INFO - 2024-09-15 05:06:58 --> Language Class Initialized
INFO - 2024-09-15 05:06:58 --> Loader Class Initialized
INFO - 2024-09-15 05:06:58 --> Helper loaded: url_helper
INFO - 2024-09-15 05:06:58 --> Helper loaded: file_helper
INFO - 2024-09-15 05:06:58 --> Helper loaded: security_helper
INFO - 2024-09-15 05:06:58 --> Helper loaded: wpu_helper
INFO - 2024-09-15 05:06:58 --> Database Driver Class Initialized
INFO - 2024-09-15 05:06:58 --> Email Class Initialized
DEBUG - 2024-09-15 05:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-15 05:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-15 05:06:58 --> Helper loaded: form_helper
INFO - 2024-09-15 05:06:58 --> Form Validation Class Initialized
INFO - 2024-09-15 05:06:58 --> Controller Class Initialized
DEBUG - 2024-09-15 05:06:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-15 05:06:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-15 05:06:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-15 05:06:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-15 05:06:58 --> Final output sent to browser
DEBUG - 2024-09-15 05:06:58 --> Total execution time: 0.2206
INFO - 2024-09-15 08:22:42 --> Config Class Initialized
INFO - 2024-09-15 08:22:42 --> Hooks Class Initialized
DEBUG - 2024-09-15 08:22:42 --> UTF-8 Support Enabled
INFO - 2024-09-15 08:22:42 --> Utf8 Class Initialized
INFO - 2024-09-15 08:22:42 --> URI Class Initialized
DEBUG - 2024-09-15 08:22:42 --> No URI present. Default controller set.
INFO - 2024-09-15 08:22:42 --> Router Class Initialized
INFO - 2024-09-15 08:22:42 --> Output Class Initialized
INFO - 2024-09-15 08:22:42 --> Security Class Initialized
DEBUG - 2024-09-15 08:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 08:22:42 --> Input Class Initialized
INFO - 2024-09-15 08:22:42 --> Language Class Initialized
INFO - 2024-09-15 08:22:42 --> Loader Class Initialized
INFO - 2024-09-15 08:22:42 --> Helper loaded: url_helper
INFO - 2024-09-15 08:22:42 --> Helper loaded: file_helper
INFO - 2024-09-15 08:22:42 --> Helper loaded: security_helper
INFO - 2024-09-15 08:22:42 --> Helper loaded: wpu_helper
INFO - 2024-09-15 08:22:42 --> Database Driver Class Initialized
ERROR - 2024-09-15 08:22:45 --> Unable to connect to the database
INFO - 2024-09-15 08:22:45 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:05:36 --> Config Class Initialized
INFO - 2024-09-15 20:05:36 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:05:36 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:05:36 --> Utf8 Class Initialized
INFO - 2024-09-15 20:05:36 --> URI Class Initialized
DEBUG - 2024-09-15 20:05:36 --> No URI present. Default controller set.
INFO - 2024-09-15 20:05:36 --> Router Class Initialized
INFO - 2024-09-15 20:05:36 --> Output Class Initialized
INFO - 2024-09-15 20:05:36 --> Security Class Initialized
DEBUG - 2024-09-15 20:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:05:36 --> Input Class Initialized
INFO - 2024-09-15 20:05:36 --> Language Class Initialized
INFO - 2024-09-15 20:05:36 --> Loader Class Initialized
INFO - 2024-09-15 20:05:36 --> Helper loaded: url_helper
INFO - 2024-09-15 20:05:36 --> Helper loaded: file_helper
INFO - 2024-09-15 20:05:36 --> Helper loaded: security_helper
INFO - 2024-09-15 20:05:36 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:05:36 --> Database Driver Class Initialized
INFO - 2024-09-15 20:05:40 --> Config Class Initialized
INFO - 2024-09-15 20:05:40 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:05:40 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:05:40 --> Utf8 Class Initialized
INFO - 2024-09-15 20:05:40 --> URI Class Initialized
DEBUG - 2024-09-15 20:05:40 --> No URI present. Default controller set.
INFO - 2024-09-15 20:05:40 --> Router Class Initialized
INFO - 2024-09-15 20:05:40 --> Output Class Initialized
INFO - 2024-09-15 20:05:40 --> Security Class Initialized
DEBUG - 2024-09-15 20:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:05:40 --> Input Class Initialized
INFO - 2024-09-15 20:05:40 --> Language Class Initialized
INFO - 2024-09-15 20:05:40 --> Loader Class Initialized
INFO - 2024-09-15 20:05:40 --> Helper loaded: url_helper
INFO - 2024-09-15 20:05:40 --> Helper loaded: file_helper
INFO - 2024-09-15 20:05:40 --> Helper loaded: security_helper
INFO - 2024-09-15 20:05:40 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:05:40 --> Database Driver Class Initialized
ERROR - 2024-09-15 20:05:42 --> Unable to connect to the database
ERROR - 2024-09-15 20:05:42 --> Unable to connect to the database
INFO - 2024-09-15 20:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:05:42 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:07:21 --> Config Class Initialized
INFO - 2024-09-15 20:07:21 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:07:21 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:07:21 --> Config Class Initialized
INFO - 2024-09-15 20:07:21 --> Utf8 Class Initialized
INFO - 2024-09-15 20:07:21 --> Hooks Class Initialized
INFO - 2024-09-15 20:07:21 --> URI Class Initialized
DEBUG - 2024-09-15 20:07:21 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:07:21 --> Utf8 Class Initialized
DEBUG - 2024-09-15 20:07:21 --> No URI present. Default controller set.
INFO - 2024-09-15 20:07:21 --> Router Class Initialized
INFO - 2024-09-15 20:07:21 --> URI Class Initialized
INFO - 2024-09-15 20:07:21 --> Output Class Initialized
DEBUG - 2024-09-15 20:07:21 --> No URI present. Default controller set.
INFO - 2024-09-15 20:07:21 --> Router Class Initialized
INFO - 2024-09-15 20:07:21 --> Security Class Initialized
INFO - 2024-09-15 20:07:21 --> Output Class Initialized
DEBUG - 2024-09-15 20:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:07:21 --> Input Class Initialized
INFO - 2024-09-15 20:07:21 --> Security Class Initialized
INFO - 2024-09-15 20:07:21 --> Language Class Initialized
DEBUG - 2024-09-15 20:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:07:21 --> Input Class Initialized
INFO - 2024-09-15 20:07:21 --> Language Class Initialized
INFO - 2024-09-15 20:07:21 --> Loader Class Initialized
INFO - 2024-09-15 20:07:21 --> Helper loaded: url_helper
INFO - 2024-09-15 20:07:21 --> Loader Class Initialized
INFO - 2024-09-15 20:07:21 --> Helper loaded: file_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: security_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: url_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: file_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: security_helper
INFO - 2024-09-15 20:07:21 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:07:21 --> Database Driver Class Initialized
INFO - 2024-09-15 20:07:21 --> Database Driver Class Initialized
ERROR - 2024-09-15 20:07:23 --> Unable to connect to the database
ERROR - 2024-09-15 20:07:23 --> Unable to connect to the database
INFO - 2024-09-15 20:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:07:24 --> Config Class Initialized
INFO - 2024-09-15 20:07:24 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:07:24 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:07:24 --> Utf8 Class Initialized
INFO - 2024-09-15 20:07:24 --> URI Class Initialized
DEBUG - 2024-09-15 20:07:24 --> No URI present. Default controller set.
INFO - 2024-09-15 20:07:24 --> Router Class Initialized
INFO - 2024-09-15 20:07:24 --> Output Class Initialized
INFO - 2024-09-15 20:07:24 --> Security Class Initialized
DEBUG - 2024-09-15 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:07:24 --> Input Class Initialized
INFO - 2024-09-15 20:07:24 --> Language Class Initialized
INFO - 2024-09-15 20:07:24 --> Loader Class Initialized
INFO - 2024-09-15 20:07:24 --> Helper loaded: url_helper
INFO - 2024-09-15 20:07:24 --> Helper loaded: file_helper
INFO - 2024-09-15 20:07:24 --> Helper loaded: security_helper
INFO - 2024-09-15 20:07:24 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:07:24 --> Database Driver Class Initialized
INFO - 2024-09-15 20:07:25 --> Config Class Initialized
INFO - 2024-09-15 20:07:25 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:07:25 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:07:25 --> Utf8 Class Initialized
INFO - 2024-09-15 20:07:25 --> URI Class Initialized
DEBUG - 2024-09-15 20:07:25 --> No URI present. Default controller set.
INFO - 2024-09-15 20:07:25 --> Router Class Initialized
INFO - 2024-09-15 20:07:25 --> Output Class Initialized
INFO - 2024-09-15 20:07:25 --> Security Class Initialized
DEBUG - 2024-09-15 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:07:25 --> Input Class Initialized
INFO - 2024-09-15 20:07:25 --> Language Class Initialized
INFO - 2024-09-15 20:07:25 --> Loader Class Initialized
INFO - 2024-09-15 20:07:25 --> Helper loaded: url_helper
INFO - 2024-09-15 20:07:25 --> Helper loaded: file_helper
INFO - 2024-09-15 20:07:25 --> Helper loaded: security_helper
INFO - 2024-09-15 20:07:25 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:07:25 --> Database Driver Class Initialized
ERROR - 2024-09-15 20:07:26 --> Unable to connect to the database
ERROR - 2024-09-15 20:07:26 --> Unable to connect to the database
INFO - 2024-09-15 20:07:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:07:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-15 20:21:06 --> Config Class Initialized
INFO - 2024-09-15 20:21:06 --> Hooks Class Initialized
DEBUG - 2024-09-15 20:21:06 --> UTF-8 Support Enabled
INFO - 2024-09-15 20:21:06 --> Utf8 Class Initialized
INFO - 2024-09-15 20:21:06 --> URI Class Initialized
DEBUG - 2024-09-15 20:21:06 --> No URI present. Default controller set.
INFO - 2024-09-15 20:21:06 --> Router Class Initialized
INFO - 2024-09-15 20:21:06 --> Output Class Initialized
INFO - 2024-09-15 20:21:06 --> Security Class Initialized
DEBUG - 2024-09-15 20:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-15 20:21:06 --> Input Class Initialized
INFO - 2024-09-15 20:21:06 --> Language Class Initialized
INFO - 2024-09-15 20:21:06 --> Loader Class Initialized
INFO - 2024-09-15 20:21:06 --> Helper loaded: url_helper
INFO - 2024-09-15 20:21:06 --> Helper loaded: file_helper
INFO - 2024-09-15 20:21:06 --> Helper loaded: security_helper
INFO - 2024-09-15 20:21:06 --> Helper loaded: wpu_helper
INFO - 2024-09-15 20:21:06 --> Database Driver Class Initialized
ERROR - 2024-09-15 20:21:06 --> Unable to connect to the database
INFO - 2024-09-15 20:21:06 --> Language file loaded: language/english/db_lang.php
