<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-13 01:13:24 --> Config Class Initialized
INFO - 2024-10-13 01:13:24 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:13:24 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:24 --> Utf8 Class Initialized
INFO - 2024-10-13 01:13:24 --> URI Class Initialized
DEBUG - 2024-10-13 01:13:24 --> No URI present. Default controller set.
INFO - 2024-10-13 01:13:24 --> Router Class Initialized
INFO - 2024-10-13 01:13:24 --> Output Class Initialized
INFO - 2024-10-13 01:13:24 --> Security Class Initialized
DEBUG - 2024-10-13 01:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:13:24 --> Input Class Initialized
INFO - 2024-10-13 01:13:24 --> Language Class Initialized
INFO - 2024-10-13 01:13:24 --> Loader Class Initialized
INFO - 2024-10-13 01:13:24 --> Helper loaded: url_helper
INFO - 2024-10-13 01:13:24 --> Helper loaded: file_helper
INFO - 2024-10-13 01:13:24 --> Helper loaded: security_helper
INFO - 2024-10-13 01:13:24 --> Helper loaded: wpu_helper
INFO - 2024-10-13 01:13:24 --> Database Driver Class Initialized
INFO - 2024-10-13 01:13:24 --> Email Class Initialized
DEBUG - 2024-10-13 01:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-13 01:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 01:13:24 --> Helper loaded: form_helper
INFO - 2024-10-13 01:13:24 --> Form Validation Class Initialized
INFO - 2024-10-13 01:13:24 --> Controller Class Initialized
DEBUG - 2024-10-13 01:13:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-13 01:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-13 01:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-13 01:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-13 01:13:24 --> Final output sent to browser
DEBUG - 2024-10-13 01:13:24 --> Total execution time: 0.2261
INFO - 2024-10-13 01:13:51 --> Config Class Initialized
INFO - 2024-10-13 01:13:51 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:51 --> Utf8 Class Initialized
INFO - 2024-10-13 01:13:51 --> URI Class Initialized
INFO - 2024-10-13 01:13:51 --> Router Class Initialized
INFO - 2024-10-13 01:13:51 --> Output Class Initialized
INFO - 2024-10-13 01:13:51 --> Config Class Initialized
INFO - 2024-10-13 01:13:51 --> Config Class Initialized
INFO - 2024-10-13 01:13:51 --> Hooks Class Initialized
INFO - 2024-10-13 01:13:51 --> Hooks Class Initialized
INFO - 2024-10-13 01:13:51 --> Security Class Initialized
DEBUG - 2024-10-13 01:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:51 --> Utf8 Class Initialized
DEBUG - 2024-10-13 01:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-13 01:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:51 --> Input Class Initialized
INFO - 2024-10-13 01:13:51 --> Utf8 Class Initialized
INFO - 2024-10-13 01:13:51 --> Language Class Initialized
INFO - 2024-10-13 01:13:51 --> URI Class Initialized
ERROR - 2024-10-13 01:13:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:13:51 --> URI Class Initialized
INFO - 2024-10-13 01:13:51 --> Router Class Initialized
INFO - 2024-10-13 01:13:51 --> Router Class Initialized
INFO - 2024-10-13 01:13:51 --> Output Class Initialized
INFO - 2024-10-13 01:13:51 --> Output Class Initialized
INFO - 2024-10-13 01:13:51 --> Security Class Initialized
INFO - 2024-10-13 01:13:51 --> Security Class Initialized
DEBUG - 2024-10-13 01:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:13:51 --> Input Class Initialized
INFO - 2024-10-13 01:13:51 --> Language Class Initialized
ERROR - 2024-10-13 01:13:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-13 01:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:13:51 --> Input Class Initialized
INFO - 2024-10-13 01:13:51 --> Language Class Initialized
ERROR - 2024-10-13 01:13:51 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-13 01:13:51 --> Config Class Initialized
INFO - 2024-10-13 01:13:51 --> Config Class Initialized
INFO - 2024-10-13 01:13:51 --> Hooks Class Initialized
INFO - 2024-10-13 01:13:51 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:51 --> Utf8 Class Initialized
DEBUG - 2024-10-13 01:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:13:51 --> Utf8 Class Initialized
INFO - 2024-10-13 01:13:51 --> URI Class Initialized
INFO - 2024-10-13 01:13:51 --> Router Class Initialized
INFO - 2024-10-13 01:13:51 --> URI Class Initialized
INFO - 2024-10-13 01:13:51 --> Output Class Initialized
INFO - 2024-10-13 01:13:51 --> Router Class Initialized
INFO - 2024-10-13 01:13:51 --> Security Class Initialized
INFO - 2024-10-13 01:13:51 --> Output Class Initialized
DEBUG - 2024-10-13 01:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:13:51 --> Input Class Initialized
INFO - 2024-10-13 01:13:51 --> Language Class Initialized
ERROR - 2024-10-13 01:13:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:13:51 --> Security Class Initialized
DEBUG - 2024-10-13 01:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:13:51 --> Input Class Initialized
INFO - 2024-10-13 01:13:51 --> Language Class Initialized
ERROR - 2024-10-13 01:13:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:14:15 --> Config Class Initialized
INFO - 2024-10-13 01:14:15 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:14:15 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:14:15 --> Utf8 Class Initialized
INFO - 2024-10-13 01:14:15 --> URI Class Initialized
INFO - 2024-10-13 01:14:15 --> Router Class Initialized
INFO - 2024-10-13 01:14:15 --> Output Class Initialized
INFO - 2024-10-13 01:14:15 --> Security Class Initialized
DEBUG - 2024-10-13 01:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:14:15 --> Input Class Initialized
INFO - 2024-10-13 01:14:15 --> Language Class Initialized
ERROR - 2024-10-13 01:14:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:14:18 --> Config Class Initialized
INFO - 2024-10-13 01:14:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:14:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:14:18 --> Utf8 Class Initialized
INFO - 2024-10-13 01:14:18 --> URI Class Initialized
INFO - 2024-10-13 01:14:18 --> Router Class Initialized
INFO - 2024-10-13 01:14:18 --> Output Class Initialized
INFO - 2024-10-13 01:14:18 --> Security Class Initialized
DEBUG - 2024-10-13 01:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:14:18 --> Input Class Initialized
INFO - 2024-10-13 01:14:18 --> Language Class Initialized
ERROR - 2024-10-13 01:14:18 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-13 01:14:18 --> Config Class Initialized
INFO - 2024-10-13 01:14:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:14:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:14:18 --> Utf8 Class Initialized
INFO - 2024-10-13 01:14:18 --> URI Class Initialized
INFO - 2024-10-13 01:14:18 --> Router Class Initialized
INFO - 2024-10-13 01:14:18 --> Output Class Initialized
INFO - 2024-10-13 01:14:18 --> Security Class Initialized
DEBUG - 2024-10-13 01:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:14:18 --> Input Class Initialized
INFO - 2024-10-13 01:14:18 --> Language Class Initialized
ERROR - 2024-10-13 01:14:18 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:14:18 --> Config Class Initialized
INFO - 2024-10-13 01:14:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:14:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:14:18 --> Utf8 Class Initialized
INFO - 2024-10-13 01:14:18 --> URI Class Initialized
INFO - 2024-10-13 01:14:18 --> Router Class Initialized
INFO - 2024-10-13 01:14:18 --> Output Class Initialized
INFO - 2024-10-13 01:14:18 --> Security Class Initialized
DEBUG - 2024-10-13 01:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:14:18 --> Input Class Initialized
INFO - 2024-10-13 01:14:18 --> Language Class Initialized
ERROR - 2024-10-13 01:14:18 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 01:14:19 --> Config Class Initialized
INFO - 2024-10-13 01:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-13 01:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-13 01:14:19 --> Utf8 Class Initialized
INFO - 2024-10-13 01:14:19 --> URI Class Initialized
INFO - 2024-10-13 01:14:19 --> Router Class Initialized
INFO - 2024-10-13 01:14:19 --> Output Class Initialized
INFO - 2024-10-13 01:14:19 --> Security Class Initialized
DEBUG - 2024-10-13 01:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 01:14:19 --> Input Class Initialized
INFO - 2024-10-13 01:14:19 --> Language Class Initialized
ERROR - 2024-10-13 01:14:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:44:02 --> Config Class Initialized
INFO - 2024-10-13 02:44:02 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:02 --> Utf8 Class Initialized
INFO - 2024-10-13 02:44:02 --> URI Class Initialized
DEBUG - 2024-10-13 02:44:02 --> No URI present. Default controller set.
INFO - 2024-10-13 02:44:02 --> Router Class Initialized
INFO - 2024-10-13 02:44:02 --> Output Class Initialized
INFO - 2024-10-13 02:44:02 --> Security Class Initialized
DEBUG - 2024-10-13 02:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:02 --> Input Class Initialized
INFO - 2024-10-13 02:44:02 --> Language Class Initialized
INFO - 2024-10-13 02:44:02 --> Loader Class Initialized
INFO - 2024-10-13 02:44:02 --> Helper loaded: url_helper
INFO - 2024-10-13 02:44:02 --> Helper loaded: file_helper
INFO - 2024-10-13 02:44:02 --> Helper loaded: security_helper
INFO - 2024-10-13 02:44:02 --> Helper loaded: wpu_helper
INFO - 2024-10-13 02:44:02 --> Database Driver Class Initialized
INFO - 2024-10-13 02:44:02 --> Email Class Initialized
DEBUG - 2024-10-13 02:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-13 02:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 02:44:02 --> Helper loaded: form_helper
INFO - 2024-10-13 02:44:02 --> Form Validation Class Initialized
INFO - 2024-10-13 02:44:02 --> Controller Class Initialized
DEBUG - 2024-10-13 02:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-13 02:44:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-13 02:44:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-13 02:44:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-13 02:44:02 --> Final output sent to browser
DEBUG - 2024-10-13 02:44:02 --> Total execution time: 0.2327
INFO - 2024-10-13 02:44:28 --> Config Class Initialized
INFO - 2024-10-13 02:44:28 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:44:28 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:28 --> Utf8 Class Initialized
INFO - 2024-10-13 02:44:28 --> URI Class Initialized
INFO - 2024-10-13 02:44:28 --> Router Class Initialized
INFO - 2024-10-13 02:44:28 --> Output Class Initialized
INFO - 2024-10-13 02:44:28 --> Security Class Initialized
DEBUG - 2024-10-13 02:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:29 --> Input Class Initialized
INFO - 2024-10-13 02:44:29 --> Language Class Initialized
ERROR - 2024-10-13 02:44:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:44:29 --> Config Class Initialized
INFO - 2024-10-13 02:44:29 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:44:29 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:29 --> Utf8 Class Initialized
INFO - 2024-10-13 02:44:29 --> URI Class Initialized
INFO - 2024-10-13 02:44:29 --> Router Class Initialized
INFO - 2024-10-13 02:44:29 --> Output Class Initialized
INFO - 2024-10-13 02:44:29 --> Security Class Initialized
DEBUG - 2024-10-13 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:29 --> Input Class Initialized
INFO - 2024-10-13 02:44:29 --> Language Class Initialized
ERROR - 2024-10-13 02:44:29 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-13 02:44:29 --> Config Class Initialized
INFO - 2024-10-13 02:44:29 --> Hooks Class Initialized
INFO - 2024-10-13 02:44:29 --> Config Class Initialized
INFO - 2024-10-13 02:44:29 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:44:29 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:29 --> Utf8 Class Initialized
DEBUG - 2024-10-13 02:44:29 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:29 --> URI Class Initialized
INFO - 2024-10-13 02:44:29 --> Utf8 Class Initialized
INFO - 2024-10-13 02:44:29 --> Router Class Initialized
INFO - 2024-10-13 02:44:29 --> URI Class Initialized
INFO - 2024-10-13 02:44:29 --> Router Class Initialized
INFO - 2024-10-13 02:44:29 --> Output Class Initialized
INFO - 2024-10-13 02:44:29 --> Security Class Initialized
INFO - 2024-10-13 02:44:29 --> Output Class Initialized
DEBUG - 2024-10-13 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:29 --> Input Class Initialized
INFO - 2024-10-13 02:44:29 --> Language Class Initialized
ERROR - 2024-10-13 02:44:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:44:29 --> Security Class Initialized
DEBUG - 2024-10-13 02:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:29 --> Input Class Initialized
INFO - 2024-10-13 02:44:29 --> Language Class Initialized
ERROR - 2024-10-13 02:44:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:44:32 --> Config Class Initialized
INFO - 2024-10-13 02:44:32 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:44:32 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:44:32 --> Utf8 Class Initialized
INFO - 2024-10-13 02:44:32 --> URI Class Initialized
INFO - 2024-10-13 02:44:32 --> Router Class Initialized
INFO - 2024-10-13 02:44:32 --> Output Class Initialized
INFO - 2024-10-13 02:44:32 --> Security Class Initialized
DEBUG - 2024-10-13 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:44:32 --> Input Class Initialized
INFO - 2024-10-13 02:44:32 --> Language Class Initialized
ERROR - 2024-10-13 02:44:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:45:18 --> Config Class Initialized
INFO - 2024-10-13 02:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:45:18 --> Utf8 Class Initialized
INFO - 2024-10-13 02:45:18 --> URI Class Initialized
INFO - 2024-10-13 02:45:18 --> Router Class Initialized
INFO - 2024-10-13 02:45:18 --> Output Class Initialized
INFO - 2024-10-13 02:45:18 --> Security Class Initialized
DEBUG - 2024-10-13 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:45:18 --> Input Class Initialized
INFO - 2024-10-13 02:45:18 --> Language Class Initialized
ERROR - 2024-10-13 02:45:18 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-13 02:45:18 --> Config Class Initialized
INFO - 2024-10-13 02:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:45:18 --> Utf8 Class Initialized
INFO - 2024-10-13 02:45:18 --> URI Class Initialized
INFO - 2024-10-13 02:45:18 --> Router Class Initialized
INFO - 2024-10-13 02:45:18 --> Output Class Initialized
INFO - 2024-10-13 02:45:18 --> Security Class Initialized
DEBUG - 2024-10-13 02:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:45:18 --> Input Class Initialized
INFO - 2024-10-13 02:45:18 --> Language Class Initialized
ERROR - 2024-10-13 02:45:18 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:45:19 --> Config Class Initialized
INFO - 2024-10-13 02:45:19 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:45:19 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:45:19 --> Utf8 Class Initialized
INFO - 2024-10-13 02:45:19 --> URI Class Initialized
INFO - 2024-10-13 02:45:19 --> Router Class Initialized
INFO - 2024-10-13 02:45:19 --> Output Class Initialized
INFO - 2024-10-13 02:45:19 --> Security Class Initialized
DEBUG - 2024-10-13 02:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:45:19 --> Input Class Initialized
INFO - 2024-10-13 02:45:19 --> Language Class Initialized
ERROR - 2024-10-13 02:45:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:45:19 --> Config Class Initialized
INFO - 2024-10-13 02:45:19 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:45:19 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:45:19 --> Utf8 Class Initialized
INFO - 2024-10-13 02:45:19 --> URI Class Initialized
INFO - 2024-10-13 02:45:19 --> Router Class Initialized
INFO - 2024-10-13 02:45:19 --> Output Class Initialized
INFO - 2024-10-13 02:45:19 --> Security Class Initialized
DEBUG - 2024-10-13 02:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:45:19 --> Input Class Initialized
INFO - 2024-10-13 02:45:19 --> Language Class Initialized
ERROR - 2024-10-13 02:45:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 02:45:19 --> Config Class Initialized
INFO - 2024-10-13 02:45:19 --> Hooks Class Initialized
DEBUG - 2024-10-13 02:45:19 --> UTF-8 Support Enabled
INFO - 2024-10-13 02:45:19 --> Utf8 Class Initialized
INFO - 2024-10-13 02:45:19 --> URI Class Initialized
INFO - 2024-10-13 02:45:19 --> Router Class Initialized
INFO - 2024-10-13 02:45:19 --> Output Class Initialized
INFO - 2024-10-13 02:45:19 --> Security Class Initialized
DEBUG - 2024-10-13 02:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 02:45:19 --> Input Class Initialized
INFO - 2024-10-13 02:45:19 --> Language Class Initialized
ERROR - 2024-10-13 02:45:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-13 08:57:38 --> Config Class Initialized
INFO - 2024-10-13 08:57:38 --> Hooks Class Initialized
DEBUG - 2024-10-13 08:57:38 --> UTF-8 Support Enabled
INFO - 2024-10-13 08:57:38 --> Utf8 Class Initialized
INFO - 2024-10-13 08:57:38 --> URI Class Initialized
DEBUG - 2024-10-13 08:57:38 --> No URI present. Default controller set.
INFO - 2024-10-13 08:57:38 --> Router Class Initialized
INFO - 2024-10-13 08:57:38 --> Output Class Initialized
INFO - 2024-10-13 08:57:38 --> Security Class Initialized
DEBUG - 2024-10-13 08:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-13 08:57:38 --> Input Class Initialized
INFO - 2024-10-13 08:57:38 --> Language Class Initialized
INFO - 2024-10-13 08:57:38 --> Loader Class Initialized
INFO - 2024-10-13 08:57:38 --> Helper loaded: url_helper
INFO - 2024-10-13 08:57:38 --> Helper loaded: file_helper
INFO - 2024-10-13 08:57:38 --> Helper loaded: security_helper
INFO - 2024-10-13 08:57:38 --> Helper loaded: wpu_helper
INFO - 2024-10-13 08:57:38 --> Database Driver Class Initialized
INFO - 2024-10-13 08:57:38 --> Email Class Initialized
DEBUG - 2024-10-13 08:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-13 08:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-13 08:57:38 --> Helper loaded: form_helper
INFO - 2024-10-13 08:57:38 --> Form Validation Class Initialized
INFO - 2024-10-13 08:57:38 --> Controller Class Initialized
DEBUG - 2024-10-13 08:57:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-13 08:57:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-13 08:57:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-13 08:57:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-13 08:57:38 --> Final output sent to browser
DEBUG - 2024-10-13 08:57:38 --> Total execution time: 0.2256
