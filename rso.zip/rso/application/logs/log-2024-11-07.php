<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-07 08:22:28 --> Config Class Initialized
INFO - 2024-11-07 08:22:28 --> Hooks Class Initialized
DEBUG - 2024-11-07 08:22:28 --> UTF-8 Support Enabled
INFO - 2024-11-07 08:22:28 --> Utf8 Class Initialized
INFO - 2024-11-07 08:22:28 --> URI Class Initialized
DEBUG - 2024-11-07 08:22:28 --> No URI present. Default controller set.
INFO - 2024-11-07 08:22:28 --> Router Class Initialized
INFO - 2024-11-07 08:22:28 --> Output Class Initialized
INFO - 2024-11-07 08:22:28 --> Security Class Initialized
DEBUG - 2024-11-07 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-07 08:22:28 --> Input Class Initialized
INFO - 2024-11-07 08:22:28 --> Language Class Initialized
INFO - 2024-11-07 08:22:28 --> Loader Class Initialized
INFO - 2024-11-07 08:22:28 --> Helper loaded: url_helper
INFO - 2024-11-07 08:22:28 --> Helper loaded: file_helper
INFO - 2024-11-07 08:22:28 --> Helper loaded: security_helper
INFO - 2024-11-07 08:22:28 --> Helper loaded: wpu_helper
INFO - 2024-11-07 08:22:28 --> Database Driver Class Initialized
ERROR - 2024-11-07 08:22:35 --> Unable to connect to the database
INFO - 2024-11-07 08:22:35 --> Language file loaded: language/english/db_lang.php
