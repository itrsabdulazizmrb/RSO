<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-25 01:00:24 --> Config Class Initialized
INFO - 2024-11-25 01:00:24 --> Hooks Class Initialized
DEBUG - 2024-11-25 01:00:24 --> UTF-8 Support Enabled
INFO - 2024-11-25 01:00:24 --> Utf8 Class Initialized
INFO - 2024-11-25 01:00:24 --> URI Class Initialized
DEBUG - 2024-11-25 01:00:24 --> No URI present. Default controller set.
INFO - 2024-11-25 01:00:24 --> Router Class Initialized
INFO - 2024-11-25 01:00:24 --> Output Class Initialized
INFO - 2024-11-25 01:00:24 --> Security Class Initialized
DEBUG - 2024-11-25 01:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 01:00:24 --> Input Class Initialized
INFO - 2024-11-25 01:00:24 --> Language Class Initialized
INFO - 2024-11-25 01:00:24 --> Loader Class Initialized
INFO - 2024-11-25 01:00:24 --> Helper loaded: url_helper
INFO - 2024-11-25 01:00:24 --> Helper loaded: file_helper
INFO - 2024-11-25 01:00:24 --> Helper loaded: security_helper
INFO - 2024-11-25 01:00:24 --> Helper loaded: wpu_helper
INFO - 2024-11-25 01:00:24 --> Database Driver Class Initialized
ERROR - 2024-11-25 01:00:31 --> Unable to connect to the database
INFO - 2024-11-25 01:00:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-25 08:02:44 --> Config Class Initialized
INFO - 2024-11-25 08:02:44 --> Hooks Class Initialized
DEBUG - 2024-11-25 08:02:44 --> UTF-8 Support Enabled
INFO - 2024-11-25 08:02:44 --> Utf8 Class Initialized
INFO - 2024-11-25 08:02:44 --> URI Class Initialized
DEBUG - 2024-11-25 08:02:44 --> No URI present. Default controller set.
INFO - 2024-11-25 08:02:44 --> Router Class Initialized
INFO - 2024-11-25 08:02:44 --> Output Class Initialized
INFO - 2024-11-25 08:02:44 --> Security Class Initialized
DEBUG - 2024-11-25 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 08:02:44 --> Input Class Initialized
INFO - 2024-11-25 08:02:44 --> Language Class Initialized
INFO - 2024-11-25 08:02:44 --> Loader Class Initialized
INFO - 2024-11-25 08:02:44 --> Helper loaded: url_helper
INFO - 2024-11-25 08:02:44 --> Helper loaded: file_helper
INFO - 2024-11-25 08:02:44 --> Helper loaded: security_helper
INFO - 2024-11-25 08:02:44 --> Helper loaded: wpu_helper
INFO - 2024-11-25 08:02:44 --> Database Driver Class Initialized
ERROR - 2024-11-25 08:02:51 --> Unable to connect to the database
INFO - 2024-11-25 08:02:51 --> Language file loaded: language/english/db_lang.php
