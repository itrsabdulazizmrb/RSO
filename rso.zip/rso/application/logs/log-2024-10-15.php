<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-15 07:40:08 --> Config Class Initialized
INFO - 2024-10-15 07:40:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 07:40:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 07:40:08 --> Utf8 Class Initialized
INFO - 2024-10-15 07:40:08 --> URI Class Initialized
INFO - 2024-10-15 07:40:08 --> Router Class Initialized
INFO - 2024-10-15 07:40:09 --> Output Class Initialized
INFO - 2024-10-15 07:40:09 --> Security Class Initialized
DEBUG - 2024-10-15 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 07:40:09 --> Input Class Initialized
INFO - 2024-10-15 07:40:09 --> Language Class Initialized
ERROR - 2024-10-15 07:40:09 --> 404 Page Not Found: Metrics/index
INFO - 2024-10-15 07:40:09 --> Config Class Initialized
INFO - 2024-10-15 07:40:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 07:40:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 07:40:09 --> Utf8 Class Initialized
INFO - 2024-10-15 07:40:09 --> URI Class Initialized
INFO - 2024-10-15 07:40:09 --> Router Class Initialized
INFO - 2024-10-15 07:40:09 --> Output Class Initialized
INFO - 2024-10-15 07:40:09 --> Security Class Initialized
DEBUG - 2024-10-15 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 07:40:09 --> Input Class Initialized
INFO - 2024-10-15 07:40:09 --> Language Class Initialized
ERROR - 2024-10-15 07:40:09 --> 404 Page Not Found: Metrics/index
INFO - 2024-10-15 07:49:23 --> Config Class Initialized
INFO - 2024-10-15 07:49:23 --> Hooks Class Initialized
DEBUG - 2024-10-15 07:49:23 --> UTF-8 Support Enabled
INFO - 2024-10-15 07:49:23 --> Utf8 Class Initialized
INFO - 2024-10-15 07:49:23 --> URI Class Initialized
DEBUG - 2024-10-15 07:49:23 --> No URI present. Default controller set.
INFO - 2024-10-15 07:49:23 --> Router Class Initialized
INFO - 2024-10-15 07:49:23 --> Output Class Initialized
INFO - 2024-10-15 07:49:23 --> Security Class Initialized
DEBUG - 2024-10-15 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 07:49:23 --> Input Class Initialized
INFO - 2024-10-15 07:49:23 --> Language Class Initialized
INFO - 2024-10-15 07:49:23 --> Loader Class Initialized
INFO - 2024-10-15 07:49:23 --> Helper loaded: url_helper
INFO - 2024-10-15 07:49:23 --> Helper loaded: file_helper
INFO - 2024-10-15 07:49:23 --> Helper loaded: security_helper
INFO - 2024-10-15 07:49:23 --> Helper loaded: wpu_helper
INFO - 2024-10-15 07:49:23 --> Database Driver Class Initialized
INFO - 2024-10-15 07:49:23 --> Email Class Initialized
DEBUG - 2024-10-15 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-15 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 07:49:23 --> Helper loaded: form_helper
INFO - 2024-10-15 07:49:23 --> Form Validation Class Initialized
INFO - 2024-10-15 07:49:23 --> Controller Class Initialized
DEBUG - 2024-10-15 07:49:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-15 07:49:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-15 07:49:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-15 07:49:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-15 07:49:23 --> Final output sent to browser
DEBUG - 2024-10-15 07:49:23 --> Total execution time: 0.2306
INFO - 2024-10-15 08:26:10 --> Config Class Initialized
INFO - 2024-10-15 08:26:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:10 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:10 --> URI Class Initialized
DEBUG - 2024-10-15 08:26:10 --> No URI present. Default controller set.
INFO - 2024-10-15 08:26:10 --> Router Class Initialized
INFO - 2024-10-15 08:26:10 --> Output Class Initialized
INFO - 2024-10-15 08:26:10 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:10 --> Input Class Initialized
INFO - 2024-10-15 08:26:10 --> Language Class Initialized
INFO - 2024-10-15 08:26:10 --> Loader Class Initialized
INFO - 2024-10-15 08:26:10 --> Helper loaded: url_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: file_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: security_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: wpu_helper
INFO - 2024-10-15 08:26:10 --> Database Driver Class Initialized
INFO - 2024-10-15 08:26:10 --> Config Class Initialized
INFO - 2024-10-15 08:26:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:10 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:10 --> URI Class Initialized
DEBUG - 2024-10-15 08:26:10 --> No URI present. Default controller set.
INFO - 2024-10-15 08:26:10 --> Router Class Initialized
INFO - 2024-10-15 08:26:10 --> Output Class Initialized
INFO - 2024-10-15 08:26:10 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:10 --> Input Class Initialized
INFO - 2024-10-15 08:26:10 --> Language Class Initialized
INFO - 2024-10-15 08:26:10 --> Loader Class Initialized
INFO - 2024-10-15 08:26:10 --> Helper loaded: url_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: file_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: security_helper
INFO - 2024-10-15 08:26:10 --> Helper loaded: wpu_helper
INFO - 2024-10-15 08:26:10 --> Database Driver Class Initialized
INFO - 2024-10-15 08:26:11 --> Email Class Initialized
DEBUG - 2024-10-15 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-15 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 08:26:11 --> Helper loaded: form_helper
INFO - 2024-10-15 08:26:11 --> Form Validation Class Initialized
INFO - 2024-10-15 08:26:11 --> Controller Class Initialized
DEBUG - 2024-10-15 08:26:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-15 08:26:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-15 08:26:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-15 08:26:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-15 08:26:11 --> Final output sent to browser
DEBUG - 2024-10-15 08:26:11 --> Total execution time: 0.4861
INFO - 2024-10-15 08:26:11 --> Config Class Initialized
INFO - 2024-10-15 08:26:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:11 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:11 --> URI Class Initialized
INFO - 2024-10-15 08:26:11 --> Router Class Initialized
INFO - 2024-10-15 08:26:11 --> Output Class Initialized
INFO - 2024-10-15 08:26:11 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:11 --> Input Class Initialized
INFO - 2024-10-15 08:26:11 --> Language Class Initialized
ERROR - 2024-10-15 08:26:11 --> 404 Page Not Found: App/index
INFO - 2024-10-15 08:26:12 --> Email Class Initialized
DEBUG - 2024-10-15 08:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-15 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 08:26:12 --> Helper loaded: form_helper
INFO - 2024-10-15 08:26:12 --> Form Validation Class Initialized
INFO - 2024-10-15 08:26:12 --> Controller Class Initialized
DEBUG - 2024-10-15 08:26:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-15 08:26:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-15 08:26:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-15 08:26:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-15 08:26:12 --> Final output sent to browser
DEBUG - 2024-10-15 08:26:12 --> Total execution time: 1.2924
INFO - 2024-10-15 08:26:12 --> Config Class Initialized
INFO - 2024-10-15 08:26:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:12 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:12 --> URI Class Initialized
INFO - 2024-10-15 08:26:12 --> Router Class Initialized
INFO - 2024-10-15 08:26:12 --> Output Class Initialized
INFO - 2024-10-15 08:26:12 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:12 --> Input Class Initialized
INFO - 2024-10-15 08:26:12 --> Language Class Initialized
ERROR - 2024-10-15 08:26:12 --> 404 Page Not Found: Login/index
INFO - 2024-10-15 08:26:12 --> Config Class Initialized
INFO - 2024-10-15 08:26:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:12 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:12 --> URI Class Initialized
INFO - 2024-10-15 08:26:12 --> Router Class Initialized
INFO - 2024-10-15 08:26:12 --> Output Class Initialized
INFO - 2024-10-15 08:26:12 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:12 --> Input Class Initialized
INFO - 2024-10-15 08:26:12 --> Language Class Initialized
ERROR - 2024-10-15 08:26:12 --> 404 Page Not Found: App/index
INFO - 2024-10-15 08:26:12 --> Config Class Initialized
INFO - 2024-10-15 08:26:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:26:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:26:12 --> Utf8 Class Initialized
INFO - 2024-10-15 08:26:12 --> URI Class Initialized
INFO - 2024-10-15 08:26:12 --> Router Class Initialized
INFO - 2024-10-15 08:26:12 --> Output Class Initialized
INFO - 2024-10-15 08:26:12 --> Security Class Initialized
DEBUG - 2024-10-15 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:26:12 --> Input Class Initialized
INFO - 2024-10-15 08:26:12 --> Language Class Initialized
ERROR - 2024-10-15 08:26:12 --> 404 Page Not Found: Login/index
INFO - 2024-10-15 08:52:49 --> Config Class Initialized
INFO - 2024-10-15 08:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-15 08:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-15 08:52:49 --> Utf8 Class Initialized
INFO - 2024-10-15 08:52:49 --> URI Class Initialized
DEBUG - 2024-10-15 08:52:49 --> No URI present. Default controller set.
INFO - 2024-10-15 08:52:49 --> Router Class Initialized
INFO - 2024-10-15 08:52:49 --> Output Class Initialized
INFO - 2024-10-15 08:52:49 --> Security Class Initialized
DEBUG - 2024-10-15 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 08:52:49 --> Input Class Initialized
INFO - 2024-10-15 08:52:49 --> Language Class Initialized
INFO - 2024-10-15 08:52:49 --> Loader Class Initialized
INFO - 2024-10-15 08:52:49 --> Helper loaded: url_helper
INFO - 2024-10-15 08:52:49 --> Helper loaded: file_helper
INFO - 2024-10-15 08:52:49 --> Helper loaded: security_helper
INFO - 2024-10-15 08:52:49 --> Helper loaded: wpu_helper
INFO - 2024-10-15 08:52:49 --> Database Driver Class Initialized
INFO - 2024-10-15 08:52:49 --> Email Class Initialized
DEBUG - 2024-10-15 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-15 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 08:52:49 --> Helper loaded: form_helper
INFO - 2024-10-15 08:52:49 --> Form Validation Class Initialized
INFO - 2024-10-15 08:52:49 --> Controller Class Initialized
DEBUG - 2024-10-15 08:52:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-15 08:52:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-15 08:52:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-15 08:52:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-15 08:52:49 --> Final output sent to browser
DEBUG - 2024-10-15 08:52:49 --> Total execution time: 0.2427
