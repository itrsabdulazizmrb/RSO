<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-02 00:04:41 --> Config Class Initialized
INFO - 2024-10-02 00:04:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:04:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:04:41 --> Utf8 Class Initialized
INFO - 2024-10-02 00:04:41 --> URI Class Initialized
INFO - 2024-10-02 00:04:41 --> Router Class Initialized
INFO - 2024-10-02 00:04:41 --> Output Class Initialized
INFO - 2024-10-02 00:04:41 --> Security Class Initialized
DEBUG - 2024-10-02 00:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:04:41 --> Input Class Initialized
INFO - 2024-10-02 00:04:41 --> Language Class Initialized
INFO - 2024-10-02 00:04:41 --> Loader Class Initialized
INFO - 2024-10-02 00:04:41 --> Helper loaded: url_helper
INFO - 2024-10-02 00:04:41 --> Helper loaded: file_helper
INFO - 2024-10-02 00:04:41 --> Helper loaded: security_helper
INFO - 2024-10-02 00:04:41 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:04:41 --> Database Driver Class Initialized
INFO - 2024-10-02 00:04:42 --> Email Class Initialized
DEBUG - 2024-10-02 00:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:04:42 --> Helper loaded: form_helper
INFO - 2024-10-02 00:04:42 --> Form Validation Class Initialized
INFO - 2024-10-02 00:04:42 --> Controller Class Initialized
INFO - 2024-10-02 00:04:42 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 00:04:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:04:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 00:04:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 00:04:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 00:04:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 00:04:42 --> Final output sent to browser
DEBUG - 2024-10-02 00:04:42 --> Total execution time: 0.4888
INFO - 2024-10-02 00:05:25 --> Config Class Initialized
INFO - 2024-10-02 00:05:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:05:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:05:25 --> Utf8 Class Initialized
INFO - 2024-10-02 00:05:25 --> URI Class Initialized
INFO - 2024-10-02 00:05:25 --> Router Class Initialized
INFO - 2024-10-02 00:05:25 --> Output Class Initialized
INFO - 2024-10-02 00:05:25 --> Security Class Initialized
DEBUG - 2024-10-02 00:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:05:25 --> Input Class Initialized
INFO - 2024-10-02 00:05:25 --> Language Class Initialized
INFO - 2024-10-02 00:05:25 --> Loader Class Initialized
INFO - 2024-10-02 00:05:25 --> Helper loaded: url_helper
INFO - 2024-10-02 00:05:25 --> Helper loaded: file_helper
INFO - 2024-10-02 00:05:25 --> Helper loaded: security_helper
INFO - 2024-10-02 00:05:25 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:05:25 --> Database Driver Class Initialized
INFO - 2024-10-02 00:05:25 --> Email Class Initialized
DEBUG - 2024-10-02 00:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:05:25 --> Helper loaded: form_helper
INFO - 2024-10-02 00:05:25 --> Form Validation Class Initialized
INFO - 2024-10-02 00:05:25 --> Controller Class Initialized
INFO - 2024-10-02 00:05:25 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 00:05:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:05:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 00:05:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 00:05:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 00:05:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 00:05:26 --> Final output sent to browser
DEBUG - 2024-10-02 00:05:26 --> Total execution time: 0.5880
INFO - 2024-10-02 00:05:43 --> Config Class Initialized
INFO - 2024-10-02 00:05:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:05:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:05:43 --> Utf8 Class Initialized
INFO - 2024-10-02 00:05:43 --> URI Class Initialized
INFO - 2024-10-02 00:05:43 --> Router Class Initialized
INFO - 2024-10-02 00:05:43 --> Output Class Initialized
INFO - 2024-10-02 00:05:43 --> Security Class Initialized
DEBUG - 2024-10-02 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:05:43 --> Input Class Initialized
INFO - 2024-10-02 00:05:43 --> Language Class Initialized
INFO - 2024-10-02 00:05:43 --> Loader Class Initialized
INFO - 2024-10-02 00:05:43 --> Helper loaded: url_helper
INFO - 2024-10-02 00:05:43 --> Helper loaded: file_helper
INFO - 2024-10-02 00:05:43 --> Helper loaded: security_helper
INFO - 2024-10-02 00:05:43 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:05:43 --> Database Driver Class Initialized
INFO - 2024-10-02 00:05:43 --> Email Class Initialized
DEBUG - 2024-10-02 00:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:05:43 --> Helper loaded: form_helper
INFO - 2024-10-02 00:05:43 --> Form Validation Class Initialized
INFO - 2024-10-02 00:05:43 --> Controller Class Initialized
INFO - 2024-10-02 00:05:43 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 00:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 00:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 00:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 00:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 00:05:43 --> Final output sent to browser
DEBUG - 2024-10-02 00:05:43 --> Total execution time: 0.5076
INFO - 2024-10-02 00:20:03 --> Config Class Initialized
INFO - 2024-10-02 00:20:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:20:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:20:03 --> Utf8 Class Initialized
INFO - 2024-10-02 00:20:03 --> URI Class Initialized
INFO - 2024-10-02 00:20:03 --> Router Class Initialized
INFO - 2024-10-02 00:20:03 --> Output Class Initialized
INFO - 2024-10-02 00:20:03 --> Security Class Initialized
DEBUG - 2024-10-02 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:20:03 --> Input Class Initialized
INFO - 2024-10-02 00:20:03 --> Language Class Initialized
INFO - 2024-10-02 00:20:03 --> Loader Class Initialized
INFO - 2024-10-02 00:20:03 --> Helper loaded: url_helper
INFO - 2024-10-02 00:20:03 --> Helper loaded: file_helper
INFO - 2024-10-02 00:20:03 --> Helper loaded: security_helper
INFO - 2024-10-02 00:20:03 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:20:03 --> Database Driver Class Initialized
INFO - 2024-10-02 00:20:04 --> Email Class Initialized
DEBUG - 2024-10-02 00:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:20:04 --> Helper loaded: form_helper
INFO - 2024-10-02 00:20:04 --> Form Validation Class Initialized
INFO - 2024-10-02 00:20:04 --> Controller Class Initialized
INFO - 2024-10-02 00:20:05 --> Config Class Initialized
INFO - 2024-10-02 00:20:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:20:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:20:05 --> Utf8 Class Initialized
INFO - 2024-10-02 00:20:05 --> URI Class Initialized
INFO - 2024-10-02 00:20:05 --> Router Class Initialized
INFO - 2024-10-02 00:20:05 --> Output Class Initialized
INFO - 2024-10-02 00:20:05 --> Security Class Initialized
DEBUG - 2024-10-02 00:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:20:05 --> Input Class Initialized
INFO - 2024-10-02 00:20:05 --> Language Class Initialized
INFO - 2024-10-02 00:20:05 --> Loader Class Initialized
INFO - 2024-10-02 00:20:05 --> Helper loaded: url_helper
INFO - 2024-10-02 00:20:05 --> Helper loaded: file_helper
INFO - 2024-10-02 00:20:05 --> Helper loaded: security_helper
INFO - 2024-10-02 00:20:05 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:20:05 --> Database Driver Class Initialized
INFO - 2024-10-02 00:20:06 --> Email Class Initialized
DEBUG - 2024-10-02 00:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:20:06 --> Helper loaded: form_helper
INFO - 2024-10-02 00:20:06 --> Form Validation Class Initialized
INFO - 2024-10-02 00:20:06 --> Controller Class Initialized
DEBUG - 2024-10-02 00:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:20:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 00:20:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 00:20:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 00:20:06 --> Final output sent to browser
DEBUG - 2024-10-02 00:20:06 --> Total execution time: 0.2201
INFO - 2024-10-02 00:20:11 --> Config Class Initialized
INFO - 2024-10-02 00:20:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:20:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:20:11 --> Utf8 Class Initialized
INFO - 2024-10-02 00:20:11 --> URI Class Initialized
INFO - 2024-10-02 00:20:11 --> Router Class Initialized
INFO - 2024-10-02 00:20:11 --> Output Class Initialized
INFO - 2024-10-02 00:20:11 --> Security Class Initialized
DEBUG - 2024-10-02 00:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:20:11 --> Input Class Initialized
INFO - 2024-10-02 00:20:11 --> Language Class Initialized
INFO - 2024-10-02 00:20:11 --> Loader Class Initialized
INFO - 2024-10-02 00:20:11 --> Helper loaded: url_helper
INFO - 2024-10-02 00:20:11 --> Helper loaded: file_helper
INFO - 2024-10-02 00:20:11 --> Helper loaded: security_helper
INFO - 2024-10-02 00:20:11 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:20:11 --> Database Driver Class Initialized
INFO - 2024-10-02 00:20:12 --> Email Class Initialized
DEBUG - 2024-10-02 00:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:20:12 --> Helper loaded: form_helper
INFO - 2024-10-02 00:20:12 --> Form Validation Class Initialized
INFO - 2024-10-02 00:20:12 --> Controller Class Initialized
DEBUG - 2024-10-02 00:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:20:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-02 00:20:13 --> Config Class Initialized
INFO - 2024-10-02 00:20:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:20:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:20:13 --> Utf8 Class Initialized
INFO - 2024-10-02 00:20:13 --> URI Class Initialized
INFO - 2024-10-02 00:20:13 --> Router Class Initialized
INFO - 2024-10-02 00:20:13 --> Output Class Initialized
INFO - 2024-10-02 00:20:13 --> Security Class Initialized
DEBUG - 2024-10-02 00:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:20:13 --> Input Class Initialized
INFO - 2024-10-02 00:20:13 --> Language Class Initialized
INFO - 2024-10-02 00:20:13 --> Loader Class Initialized
INFO - 2024-10-02 00:20:13 --> Helper loaded: url_helper
INFO - 2024-10-02 00:20:13 --> Helper loaded: file_helper
INFO - 2024-10-02 00:20:13 --> Helper loaded: security_helper
INFO - 2024-10-02 00:20:13 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:20:13 --> Database Driver Class Initialized
INFO - 2024-10-02 00:20:13 --> Email Class Initialized
DEBUG - 2024-10-02 00:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:20:13 --> Helper loaded: form_helper
INFO - 2024-10-02 00:20:13 --> Form Validation Class Initialized
INFO - 2024-10-02 00:20:13 --> Controller Class Initialized
INFO - 2024-10-02 00:20:13 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 00:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:20:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 00:20:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 00:20:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 00:20:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 00:20:14 --> Final output sent to browser
DEBUG - 2024-10-02 00:20:14 --> Total execution time: 0.8345
INFO - 2024-10-02 00:25:42 --> Config Class Initialized
INFO - 2024-10-02 00:25:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 00:25:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 00:25:42 --> Utf8 Class Initialized
INFO - 2024-10-02 00:25:42 --> URI Class Initialized
DEBUG - 2024-10-02 00:25:42 --> No URI present. Default controller set.
INFO - 2024-10-02 00:25:42 --> Router Class Initialized
INFO - 2024-10-02 00:25:42 --> Output Class Initialized
INFO - 2024-10-02 00:25:42 --> Security Class Initialized
DEBUG - 2024-10-02 00:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 00:25:42 --> Input Class Initialized
INFO - 2024-10-02 00:25:42 --> Language Class Initialized
INFO - 2024-10-02 00:25:42 --> Loader Class Initialized
INFO - 2024-10-02 00:25:42 --> Helper loaded: url_helper
INFO - 2024-10-02 00:25:42 --> Helper loaded: file_helper
INFO - 2024-10-02 00:25:42 --> Helper loaded: security_helper
INFO - 2024-10-02 00:25:42 --> Helper loaded: wpu_helper
INFO - 2024-10-02 00:25:42 --> Database Driver Class Initialized
INFO - 2024-10-02 00:25:42 --> Email Class Initialized
DEBUG - 2024-10-02 00:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 00:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 00:25:42 --> Helper loaded: form_helper
INFO - 2024-10-02 00:25:42 --> Form Validation Class Initialized
INFO - 2024-10-02 00:25:42 --> Controller Class Initialized
DEBUG - 2024-10-02 00:25:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 00:25:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 00:25:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 00:25:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 00:25:42 --> Final output sent to browser
DEBUG - 2024-10-02 00:25:42 --> Total execution time: 0.2253
INFO - 2024-10-02 02:52:38 --> Config Class Initialized
INFO - 2024-10-02 02:52:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 02:52:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 02:52:38 --> Utf8 Class Initialized
INFO - 2024-10-02 02:52:38 --> URI Class Initialized
DEBUG - 2024-10-02 02:52:38 --> No URI present. Default controller set.
INFO - 2024-10-02 02:52:38 --> Router Class Initialized
INFO - 2024-10-02 02:52:38 --> Output Class Initialized
INFO - 2024-10-02 02:52:38 --> Security Class Initialized
DEBUG - 2024-10-02 02:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 02:52:38 --> Input Class Initialized
INFO - 2024-10-02 02:52:38 --> Language Class Initialized
INFO - 2024-10-02 02:52:38 --> Loader Class Initialized
INFO - 2024-10-02 02:52:38 --> Helper loaded: url_helper
INFO - 2024-10-02 02:52:38 --> Helper loaded: file_helper
INFO - 2024-10-02 02:52:38 --> Helper loaded: security_helper
INFO - 2024-10-02 02:52:38 --> Helper loaded: wpu_helper
INFO - 2024-10-02 02:52:38 --> Database Driver Class Initialized
INFO - 2024-10-02 02:52:38 --> Email Class Initialized
DEBUG - 2024-10-02 02:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 02:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 02:52:38 --> Helper loaded: form_helper
INFO - 2024-10-02 02:52:38 --> Form Validation Class Initialized
INFO - 2024-10-02 02:52:38 --> Controller Class Initialized
DEBUG - 2024-10-02 02:52:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 02:52:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 02:52:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 02:52:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 02:52:38 --> Final output sent to browser
DEBUG - 2024-10-02 02:52:38 --> Total execution time: 0.2370
INFO - 2024-10-02 02:52:42 --> Config Class Initialized
INFO - 2024-10-02 02:52:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 02:52:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 02:52:42 --> Utf8 Class Initialized
INFO - 2024-10-02 02:52:42 --> URI Class Initialized
INFO - 2024-10-02 02:52:42 --> Router Class Initialized
INFO - 2024-10-02 02:52:42 --> Output Class Initialized
INFO - 2024-10-02 02:52:42 --> Security Class Initialized
DEBUG - 2024-10-02 02:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 02:52:42 --> Input Class Initialized
INFO - 2024-10-02 02:52:42 --> Language Class Initialized
INFO - 2024-10-02 02:52:42 --> Loader Class Initialized
INFO - 2024-10-02 02:52:42 --> Helper loaded: url_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: file_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: security_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: wpu_helper
INFO - 2024-10-02 02:52:42 --> Database Driver Class Initialized
INFO - 2024-10-02 02:52:42 --> Email Class Initialized
DEBUG - 2024-10-02 02:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 02:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 02:52:42 --> Helper loaded: form_helper
INFO - 2024-10-02 02:52:42 --> Form Validation Class Initialized
INFO - 2024-10-02 02:52:42 --> Controller Class Initialized
DEBUG - 2024-10-02 02:52:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 02:52:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-02 02:52:42 --> Config Class Initialized
INFO - 2024-10-02 02:52:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 02:52:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 02:52:42 --> Utf8 Class Initialized
INFO - 2024-10-02 02:52:42 --> URI Class Initialized
INFO - 2024-10-02 02:52:42 --> Router Class Initialized
INFO - 2024-10-02 02:52:42 --> Output Class Initialized
INFO - 2024-10-02 02:52:42 --> Security Class Initialized
DEBUG - 2024-10-02 02:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 02:52:42 --> Input Class Initialized
INFO - 2024-10-02 02:52:42 --> Language Class Initialized
INFO - 2024-10-02 02:52:42 --> Loader Class Initialized
INFO - 2024-10-02 02:52:42 --> Helper loaded: url_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: file_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: security_helper
INFO - 2024-10-02 02:52:42 --> Helper loaded: wpu_helper
INFO - 2024-10-02 02:52:42 --> Database Driver Class Initialized
INFO - 2024-10-02 02:52:43 --> Email Class Initialized
DEBUG - 2024-10-02 02:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 02:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 02:52:43 --> Helper loaded: form_helper
INFO - 2024-10-02 02:52:43 --> Form Validation Class Initialized
INFO - 2024-10-02 02:52:43 --> Controller Class Initialized
INFO - 2024-10-02 02:52:43 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 02:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 02:52:43 --> Final output sent to browser
DEBUG - 2024-10-02 02:52:43 --> Total execution time: 0.7924
INFO - 2024-10-02 02:53:20 --> Config Class Initialized
INFO - 2024-10-02 02:53:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 02:53:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 02:53:20 --> Utf8 Class Initialized
INFO - 2024-10-02 02:53:20 --> URI Class Initialized
DEBUG - 2024-10-02 02:53:20 --> No URI present. Default controller set.
INFO - 2024-10-02 02:53:20 --> Router Class Initialized
INFO - 2024-10-02 02:53:20 --> Output Class Initialized
INFO - 2024-10-02 02:53:20 --> Security Class Initialized
DEBUG - 2024-10-02 02:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 02:53:20 --> Input Class Initialized
INFO - 2024-10-02 02:53:20 --> Language Class Initialized
INFO - 2024-10-02 02:53:20 --> Loader Class Initialized
INFO - 2024-10-02 02:53:20 --> Helper loaded: url_helper
INFO - 2024-10-02 02:53:20 --> Helper loaded: file_helper
INFO - 2024-10-02 02:53:20 --> Helper loaded: security_helper
INFO - 2024-10-02 02:53:20 --> Helper loaded: wpu_helper
INFO - 2024-10-02 02:53:20 --> Database Driver Class Initialized
INFO - 2024-10-02 02:53:20 --> Email Class Initialized
DEBUG - 2024-10-02 02:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 02:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 02:53:20 --> Helper loaded: form_helper
INFO - 2024-10-02 02:53:20 --> Form Validation Class Initialized
INFO - 2024-10-02 02:53:20 --> Controller Class Initialized
DEBUG - 2024-10-02 02:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 02:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 02:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 02:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 02:53:20 --> Final output sent to browser
DEBUG - 2024-10-02 02:53:20 --> Total execution time: 0.2202
INFO - 2024-10-02 03:08:25 --> Config Class Initialized
INFO - 2024-10-02 03:08:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 03:08:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 03:08:25 --> Utf8 Class Initialized
INFO - 2024-10-02 03:08:25 --> URI Class Initialized
INFO - 2024-10-02 03:08:25 --> Router Class Initialized
INFO - 2024-10-02 03:08:25 --> Output Class Initialized
INFO - 2024-10-02 03:08:25 --> Security Class Initialized
DEBUG - 2024-10-02 03:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 03:08:25 --> Input Class Initialized
INFO - 2024-10-02 03:08:25 --> Language Class Initialized
INFO - 2024-10-02 03:08:25 --> Loader Class Initialized
INFO - 2024-10-02 03:08:25 --> Helper loaded: url_helper
INFO - 2024-10-02 03:08:25 --> Helper loaded: file_helper
INFO - 2024-10-02 03:08:25 --> Helper loaded: security_helper
INFO - 2024-10-02 03:08:25 --> Helper loaded: wpu_helper
INFO - 2024-10-02 03:08:25 --> Database Driver Class Initialized
INFO - 2024-10-02 03:08:26 --> Email Class Initialized
DEBUG - 2024-10-02 03:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 03:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 03:08:26 --> Helper loaded: form_helper
INFO - 2024-10-02 03:08:26 --> Form Validation Class Initialized
INFO - 2024-10-02 03:08:26 --> Controller Class Initialized
INFO - 2024-10-02 03:08:26 --> Config Class Initialized
INFO - 2024-10-02 03:08:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 03:08:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 03:08:26 --> Utf8 Class Initialized
INFO - 2024-10-02 03:08:26 --> URI Class Initialized
INFO - 2024-10-02 03:08:26 --> Router Class Initialized
INFO - 2024-10-02 03:08:26 --> Output Class Initialized
INFO - 2024-10-02 03:08:26 --> Security Class Initialized
DEBUG - 2024-10-02 03:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 03:08:26 --> Input Class Initialized
INFO - 2024-10-02 03:08:26 --> Language Class Initialized
INFO - 2024-10-02 03:08:26 --> Loader Class Initialized
INFO - 2024-10-02 03:08:26 --> Helper loaded: url_helper
INFO - 2024-10-02 03:08:26 --> Helper loaded: file_helper
INFO - 2024-10-02 03:08:26 --> Helper loaded: security_helper
INFO - 2024-10-02 03:08:26 --> Helper loaded: wpu_helper
INFO - 2024-10-02 03:08:26 --> Database Driver Class Initialized
INFO - 2024-10-02 03:08:26 --> Email Class Initialized
DEBUG - 2024-10-02 03:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 03:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 03:08:26 --> Helper loaded: form_helper
INFO - 2024-10-02 03:08:26 --> Form Validation Class Initialized
INFO - 2024-10-02 03:08:26 --> Controller Class Initialized
DEBUG - 2024-10-02 03:08:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 03:08:26 --> Final output sent to browser
DEBUG - 2024-10-02 03:08:26 --> Total execution time: 0.2242
INFO - 2024-10-02 04:05:30 --> Config Class Initialized
INFO - 2024-10-02 04:05:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:05:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:05:30 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:30 --> URI Class Initialized
DEBUG - 2024-10-02 04:05:30 --> No URI present. Default controller set.
INFO - 2024-10-02 04:05:30 --> Router Class Initialized
INFO - 2024-10-02 04:05:30 --> Output Class Initialized
INFO - 2024-10-02 04:05:30 --> Security Class Initialized
DEBUG - 2024-10-02 04:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:05:30 --> Input Class Initialized
INFO - 2024-10-02 04:05:30 --> Language Class Initialized
INFO - 2024-10-02 04:05:30 --> Loader Class Initialized
INFO - 2024-10-02 04:05:30 --> Helper loaded: url_helper
INFO - 2024-10-02 04:05:30 --> Helper loaded: file_helper
INFO - 2024-10-02 04:05:30 --> Helper loaded: security_helper
INFO - 2024-10-02 04:05:30 --> Helper loaded: wpu_helper
INFO - 2024-10-02 04:05:30 --> Database Driver Class Initialized
INFO - 2024-10-02 04:05:30 --> Email Class Initialized
DEBUG - 2024-10-02 04:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 04:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 04:05:30 --> Helper loaded: form_helper
INFO - 2024-10-02 04:05:30 --> Form Validation Class Initialized
INFO - 2024-10-02 04:05:30 --> Controller Class Initialized
DEBUG - 2024-10-02 04:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 04:05:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 04:05:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 04:05:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 04:05:30 --> Final output sent to browser
DEBUG - 2024-10-02 04:05:30 --> Total execution time: 0.2373
INFO - 2024-10-02 04:05:56 --> Config Class Initialized
INFO - 2024-10-02 04:05:56 --> Config Class Initialized
INFO - 2024-10-02 04:05:56 --> Hooks Class Initialized
INFO - 2024-10-02 04:05:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:05:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-02 04:05:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:05:56 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:56 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:56 --> URI Class Initialized
INFO - 2024-10-02 04:05:56 --> URI Class Initialized
INFO - 2024-10-02 04:05:56 --> Router Class Initialized
INFO - 2024-10-02 04:05:56 --> Router Class Initialized
INFO - 2024-10-02 04:05:56 --> Output Class Initialized
INFO - 2024-10-02 04:05:56 --> Output Class Initialized
INFO - 2024-10-02 04:05:56 --> Security Class Initialized
INFO - 2024-10-02 04:05:56 --> Security Class Initialized
DEBUG - 2024-10-02 04:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-02 04:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:05:56 --> Input Class Initialized
INFO - 2024-10-02 04:05:56 --> Input Class Initialized
INFO - 2024-10-02 04:05:56 --> Language Class Initialized
INFO - 2024-10-02 04:05:56 --> Language Class Initialized
ERROR - 2024-10-02 04:05:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-10-02 04:05:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:05:57 --> Config Class Initialized
INFO - 2024-10-02 04:05:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:05:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:05:57 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:57 --> URI Class Initialized
INFO - 2024-10-02 04:05:57 --> Router Class Initialized
INFO - 2024-10-02 04:05:57 --> Output Class Initialized
INFO - 2024-10-02 04:05:57 --> Security Class Initialized
DEBUG - 2024-10-02 04:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:05:57 --> Input Class Initialized
INFO - 2024-10-02 04:05:57 --> Language Class Initialized
ERROR - 2024-10-02 04:05:57 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:05:57 --> Config Class Initialized
INFO - 2024-10-02 04:05:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:05:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:05:57 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:57 --> URI Class Initialized
INFO - 2024-10-02 04:05:57 --> Router Class Initialized
INFO - 2024-10-02 04:05:57 --> Output Class Initialized
INFO - 2024-10-02 04:05:57 --> Security Class Initialized
DEBUG - 2024-10-02 04:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:05:57 --> Input Class Initialized
INFO - 2024-10-02 04:05:57 --> Language Class Initialized
ERROR - 2024-10-02 04:05:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:05:57 --> Config Class Initialized
INFO - 2024-10-02 04:05:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:05:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:05:57 --> Utf8 Class Initialized
INFO - 2024-10-02 04:05:57 --> URI Class Initialized
INFO - 2024-10-02 04:05:57 --> Router Class Initialized
INFO - 2024-10-02 04:05:57 --> Output Class Initialized
INFO - 2024-10-02 04:05:57 --> Security Class Initialized
DEBUG - 2024-10-02 04:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:05:57 --> Input Class Initialized
INFO - 2024-10-02 04:05:57 --> Language Class Initialized
ERROR - 2024-10-02 04:05:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:06:33 --> Config Class Initialized
INFO - 2024-10-02 04:06:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:06:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:06:33 --> Utf8 Class Initialized
INFO - 2024-10-02 04:06:33 --> URI Class Initialized
INFO - 2024-10-02 04:06:33 --> Router Class Initialized
INFO - 2024-10-02 04:06:33 --> Output Class Initialized
INFO - 2024-10-02 04:06:33 --> Security Class Initialized
DEBUG - 2024-10-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:06:33 --> Input Class Initialized
INFO - 2024-10-02 04:06:33 --> Language Class Initialized
ERROR - 2024-10-02 04:06:33 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:06:33 --> Config Class Initialized
INFO - 2024-10-02 04:06:33 --> Hooks Class Initialized
INFO - 2024-10-02 04:06:33 --> Config Class Initialized
INFO - 2024-10-02 04:06:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2024-10-02 04:06:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:06:33 --> Utf8 Class Initialized
INFO - 2024-10-02 04:06:33 --> URI Class Initialized
INFO - 2024-10-02 04:06:33 --> Router Class Initialized
INFO - 2024-10-02 04:06:33 --> Output Class Initialized
INFO - 2024-10-02 04:06:33 --> Security Class Initialized
DEBUG - 2024-10-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:06:33 --> Input Class Initialized
INFO - 2024-10-02 04:06:33 --> Language Class Initialized
ERROR - 2024-10-02 04:06:33 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:06:33 --> Utf8 Class Initialized
INFO - 2024-10-02 04:06:33 --> URI Class Initialized
INFO - 2024-10-02 04:06:33 --> Router Class Initialized
INFO - 2024-10-02 04:06:33 --> Output Class Initialized
INFO - 2024-10-02 04:06:33 --> Security Class Initialized
DEBUG - 2024-10-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:06:33 --> Input Class Initialized
INFO - 2024-10-02 04:06:33 --> Language Class Initialized
ERROR - 2024-10-02 04:06:33 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:06:33 --> Config Class Initialized
INFO - 2024-10-02 04:06:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:06:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:06:33 --> Utf8 Class Initialized
INFO - 2024-10-02 04:06:33 --> URI Class Initialized
INFO - 2024-10-02 04:06:33 --> Router Class Initialized
INFO - 2024-10-02 04:06:33 --> Output Class Initialized
INFO - 2024-10-02 04:06:33 --> Security Class Initialized
DEBUG - 2024-10-02 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:06:33 --> Input Class Initialized
INFO - 2024-10-02 04:06:33 --> Language Class Initialized
ERROR - 2024-10-02 04:06:33 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:06:34 --> Config Class Initialized
INFO - 2024-10-02 04:06:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:06:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:06:34 --> Utf8 Class Initialized
INFO - 2024-10-02 04:06:34 --> URI Class Initialized
INFO - 2024-10-02 04:06:34 --> Router Class Initialized
INFO - 2024-10-02 04:06:34 --> Output Class Initialized
INFO - 2024-10-02 04:06:34 --> Security Class Initialized
DEBUG - 2024-10-02 04:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:06:34 --> Input Class Initialized
INFO - 2024-10-02 04:06:34 --> Language Class Initialized
ERROR - 2024-10-02 04:06:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:07 --> Config Class Initialized
INFO - 2024-10-02 04:07:07 --> Hooks Class Initialized
INFO - 2024-10-02 04:07:07 --> Config Class Initialized
DEBUG - 2024-10-02 04:07:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:07 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:07 --> Hooks Class Initialized
INFO - 2024-10-02 04:07:07 --> URI Class Initialized
DEBUG - 2024-10-02 04:07:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:07 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:07 --> Router Class Initialized
INFO - 2024-10-02 04:07:07 --> URI Class Initialized
INFO - 2024-10-02 04:07:07 --> Output Class Initialized
INFO - 2024-10-02 04:07:07 --> Router Class Initialized
INFO - 2024-10-02 04:07:07 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:07 --> Input Class Initialized
INFO - 2024-10-02 04:07:07 --> Output Class Initialized
INFO - 2024-10-02 04:07:07 --> Language Class Initialized
ERROR - 2024-10-02 04:07:07 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:07 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:07 --> Input Class Initialized
INFO - 2024-10-02 04:07:07 --> Language Class Initialized
ERROR - 2024-10-02 04:07:07 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:07 --> Config Class Initialized
INFO - 2024-10-02 04:07:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:07 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:07 --> URI Class Initialized
INFO - 2024-10-02 04:07:07 --> Router Class Initialized
INFO - 2024-10-02 04:07:07 --> Output Class Initialized
INFO - 2024-10-02 04:07:07 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:07 --> Input Class Initialized
INFO - 2024-10-02 04:07:07 --> Language Class Initialized
ERROR - 2024-10-02 04:07:07 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:09 --> Config Class Initialized
INFO - 2024-10-02 04:07:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:09 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:09 --> URI Class Initialized
INFO - 2024-10-02 04:07:09 --> Router Class Initialized
INFO - 2024-10-02 04:07:09 --> Output Class Initialized
INFO - 2024-10-02 04:07:09 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:09 --> Input Class Initialized
INFO - 2024-10-02 04:07:09 --> Language Class Initialized
ERROR - 2024-10-02 04:07:09 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:07:11 --> Config Class Initialized
INFO - 2024-10-02 04:07:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:11 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:11 --> URI Class Initialized
INFO - 2024-10-02 04:07:11 --> Router Class Initialized
INFO - 2024-10-02 04:07:11 --> Output Class Initialized
INFO - 2024-10-02 04:07:11 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:11 --> Input Class Initialized
INFO - 2024-10-02 04:07:11 --> Language Class Initialized
ERROR - 2024-10-02 04:07:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:13 --> Config Class Initialized
INFO - 2024-10-02 04:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:13 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:13 --> URI Class Initialized
INFO - 2024-10-02 04:07:13 --> Router Class Initialized
INFO - 2024-10-02 04:07:13 --> Output Class Initialized
INFO - 2024-10-02 04:07:13 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:13 --> Input Class Initialized
INFO - 2024-10-02 04:07:13 --> Language Class Initialized
ERROR - 2024-10-02 04:07:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:42 --> Config Class Initialized
INFO - 2024-10-02 04:07:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:42 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:42 --> URI Class Initialized
INFO - 2024-10-02 04:07:42 --> Router Class Initialized
INFO - 2024-10-02 04:07:42 --> Config Class Initialized
INFO - 2024-10-02 04:07:42 --> Hooks Class Initialized
INFO - 2024-10-02 04:07:42 --> Config Class Initialized
INFO - 2024-10-02 04:07:42 --> Output Class Initialized
INFO - 2024-10-02 04:07:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:42 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:42 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:42 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:42 --> URI Class Initialized
DEBUG - 2024-10-02 04:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:42 --> Input Class Initialized
INFO - 2024-10-02 04:07:42 --> URI Class Initialized
INFO - 2024-10-02 04:07:42 --> Router Class Initialized
INFO - 2024-10-02 04:07:42 --> Language Class Initialized
ERROR - 2024-10-02 04:07:42 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:07:42 --> Router Class Initialized
INFO - 2024-10-02 04:07:42 --> Output Class Initialized
INFO - 2024-10-02 04:07:42 --> Output Class Initialized
INFO - 2024-10-02 04:07:42 --> Security Class Initialized
INFO - 2024-10-02 04:07:42 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:42 --> Input Class Initialized
DEBUG - 2024-10-02 04:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:42 --> Input Class Initialized
INFO - 2024-10-02 04:07:42 --> Language Class Initialized
INFO - 2024-10-02 04:07:42 --> Language Class Initialized
ERROR - 2024-10-02 04:07:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-10-02 04:07:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:43 --> Config Class Initialized
INFO - 2024-10-02 04:07:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:43 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:43 --> URI Class Initialized
INFO - 2024-10-02 04:07:43 --> Router Class Initialized
INFO - 2024-10-02 04:07:43 --> Output Class Initialized
INFO - 2024-10-02 04:07:43 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:43 --> Input Class Initialized
INFO - 2024-10-02 04:07:43 --> Language Class Initialized
ERROR - 2024-10-02 04:07:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:07:43 --> Config Class Initialized
INFO - 2024-10-02 04:07:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:07:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:07:43 --> Utf8 Class Initialized
INFO - 2024-10-02 04:07:43 --> URI Class Initialized
INFO - 2024-10-02 04:07:43 --> Router Class Initialized
INFO - 2024-10-02 04:07:43 --> Output Class Initialized
INFO - 2024-10-02 04:07:43 --> Security Class Initialized
DEBUG - 2024-10-02 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:07:43 --> Input Class Initialized
INFO - 2024-10-02 04:07:43 --> Language Class Initialized
ERROR - 2024-10-02 04:07:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:08:32 --> Config Class Initialized
INFO - 2024-10-02 04:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:08:32 --> Utf8 Class Initialized
INFO - 2024-10-02 04:08:32 --> URI Class Initialized
INFO - 2024-10-02 04:08:32 --> Config Class Initialized
INFO - 2024-10-02 04:08:32 --> Hooks Class Initialized
INFO - 2024-10-02 04:08:32 --> Config Class Initialized
INFO - 2024-10-02 04:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:08:32 --> Utf8 Class Initialized
INFO - 2024-10-02 04:08:32 --> Router Class Initialized
DEBUG - 2024-10-02 04:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:08:32 --> Utf8 Class Initialized
INFO - 2024-10-02 04:08:32 --> URI Class Initialized
INFO - 2024-10-02 04:08:32 --> Router Class Initialized
INFO - 2024-10-02 04:08:32 --> URI Class Initialized
INFO - 2024-10-02 04:08:32 --> Output Class Initialized
INFO - 2024-10-02 04:08:32 --> Router Class Initialized
INFO - 2024-10-02 04:08:32 --> Security Class Initialized
INFO - 2024-10-02 04:08:32 --> Output Class Initialized
INFO - 2024-10-02 04:08:32 --> Output Class Initialized
DEBUG - 2024-10-02 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:08:32 --> Input Class Initialized
INFO - 2024-10-02 04:08:32 --> Security Class Initialized
INFO - 2024-10-02 04:08:32 --> Language Class Initialized
ERROR - 2024-10-02 04:08:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:08:32 --> Security Class Initialized
DEBUG - 2024-10-02 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:08:32 --> Input Class Initialized
INFO - 2024-10-02 04:08:32 --> Language Class Initialized
DEBUG - 2024-10-02 04:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-02 04:08:32 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:08:32 --> Input Class Initialized
INFO - 2024-10-02 04:08:32 --> Language Class Initialized
ERROR - 2024-10-02 04:08:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:08:32 --> Config Class Initialized
INFO - 2024-10-02 04:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:08:32 --> Utf8 Class Initialized
INFO - 2024-10-02 04:08:32 --> URI Class Initialized
INFO - 2024-10-02 04:08:32 --> Router Class Initialized
INFO - 2024-10-02 04:08:32 --> Output Class Initialized
INFO - 2024-10-02 04:08:32 --> Security Class Initialized
DEBUG - 2024-10-02 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:08:32 --> Input Class Initialized
INFO - 2024-10-02 04:08:32 --> Language Class Initialized
ERROR - 2024-10-02 04:08:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:08:33 --> Config Class Initialized
INFO - 2024-10-02 04:08:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:08:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:08:33 --> Utf8 Class Initialized
INFO - 2024-10-02 04:08:33 --> URI Class Initialized
INFO - 2024-10-02 04:08:33 --> Router Class Initialized
INFO - 2024-10-02 04:08:33 --> Output Class Initialized
INFO - 2024-10-02 04:08:33 --> Security Class Initialized
DEBUG - 2024-10-02 04:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:08:33 --> Input Class Initialized
INFO - 2024-10-02 04:08:33 --> Language Class Initialized
ERROR - 2024-10-02 04:08:33 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:09:06 --> Config Class Initialized
INFO - 2024-10-02 04:09:06 --> Config Class Initialized
INFO - 2024-10-02 04:09:06 --> Hooks Class Initialized
INFO - 2024-10-02 04:09:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:09:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-02 04:09:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:09:06 --> Utf8 Class Initialized
INFO - 2024-10-02 04:09:06 --> URI Class Initialized
INFO - 2024-10-02 04:09:06 --> Router Class Initialized
INFO - 2024-10-02 04:09:06 --> Output Class Initialized
INFO - 2024-10-02 04:09:06 --> Security Class Initialized
INFO - 2024-10-02 04:09:06 --> Utf8 Class Initialized
DEBUG - 2024-10-02 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:09:06 --> Input Class Initialized
INFO - 2024-10-02 04:09:06 --> URI Class Initialized
INFO - 2024-10-02 04:09:06 --> Language Class Initialized
ERROR - 2024-10-02 04:09:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:09:06 --> Router Class Initialized
INFO - 2024-10-02 04:09:06 --> Output Class Initialized
INFO - 2024-10-02 04:09:06 --> Security Class Initialized
DEBUG - 2024-10-02 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:09:06 --> Input Class Initialized
INFO - 2024-10-02 04:09:06 --> Language Class Initialized
ERROR - 2024-10-02 04:09:06 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 04:09:09 --> Config Class Initialized
INFO - 2024-10-02 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-02 04:09:09 --> URI Class Initialized
INFO - 2024-10-02 04:09:09 --> Router Class Initialized
INFO - 2024-10-02 04:09:09 --> Output Class Initialized
INFO - 2024-10-02 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:09:09 --> Input Class Initialized
INFO - 2024-10-02 04:09:09 --> Language Class Initialized
ERROR - 2024-10-02 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 04:09:09 --> Config Class Initialized
INFO - 2024-10-02 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-02 04:09:09 --> URI Class Initialized
INFO - 2024-10-02 04:09:09 --> Router Class Initialized
INFO - 2024-10-02 04:09:09 --> Output Class Initialized
INFO - 2024-10-02 04:09:09 --> Config Class Initialized
INFO - 2024-10-02 04:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 04:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 04:09:09 --> Utf8 Class Initialized
INFO - 2024-10-02 04:09:09 --> URI Class Initialized
INFO - 2024-10-02 04:09:09 --> Router Class Initialized
INFO - 2024-10-02 04:09:09 --> Output Class Initialized
INFO - 2024-10-02 04:09:09 --> Security Class Initialized
DEBUG - 2024-10-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:09:09 --> Input Class Initialized
INFO - 2024-10-02 04:09:09 --> Language Class Initialized
INFO - 2024-10-02 04:09:09 --> Security Class Initialized
ERROR - 2024-10-02 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 04:09:09 --> Input Class Initialized
INFO - 2024-10-02 04:09:09 --> Language Class Initialized
ERROR - 2024-10-02 04:09:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 06:50:21 --> Config Class Initialized
INFO - 2024-10-02 06:50:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 06:50:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 06:50:21 --> Utf8 Class Initialized
INFO - 2024-10-02 06:50:21 --> URI Class Initialized
DEBUG - 2024-10-02 06:50:21 --> No URI present. Default controller set.
INFO - 2024-10-02 06:50:21 --> Router Class Initialized
INFO - 2024-10-02 06:50:21 --> Output Class Initialized
INFO - 2024-10-02 06:50:21 --> Security Class Initialized
DEBUG - 2024-10-02 06:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 06:50:21 --> Input Class Initialized
INFO - 2024-10-02 06:50:21 --> Language Class Initialized
INFO - 2024-10-02 06:50:21 --> Loader Class Initialized
INFO - 2024-10-02 06:50:21 --> Helper loaded: url_helper
INFO - 2024-10-02 06:50:21 --> Helper loaded: file_helper
INFO - 2024-10-02 06:50:21 --> Helper loaded: security_helper
INFO - 2024-10-02 06:50:21 --> Helper loaded: wpu_helper
INFO - 2024-10-02 06:50:21 --> Database Driver Class Initialized
INFO - 2024-10-02 06:50:22 --> Email Class Initialized
DEBUG - 2024-10-02 06:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 06:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 06:50:22 --> Helper loaded: form_helper
INFO - 2024-10-02 06:50:22 --> Form Validation Class Initialized
INFO - 2024-10-02 06:50:22 --> Controller Class Initialized
DEBUG - 2024-10-02 06:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 06:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 06:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 06:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 06:50:22 --> Final output sent to browser
DEBUG - 2024-10-02 06:50:22 --> Total execution time: 0.2500
INFO - 2024-10-02 06:50:25 --> Config Class Initialized
INFO - 2024-10-02 06:50:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 06:50:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 06:50:25 --> Utf8 Class Initialized
INFO - 2024-10-02 06:50:25 --> URI Class Initialized
DEBUG - 2024-10-02 06:50:25 --> No URI present. Default controller set.
INFO - 2024-10-02 06:50:25 --> Router Class Initialized
INFO - 2024-10-02 06:50:25 --> Output Class Initialized
INFO - 2024-10-02 06:50:25 --> Security Class Initialized
DEBUG - 2024-10-02 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 06:50:25 --> Input Class Initialized
INFO - 2024-10-02 06:50:25 --> Language Class Initialized
INFO - 2024-10-02 06:50:25 --> Loader Class Initialized
INFO - 2024-10-02 06:50:25 --> Helper loaded: url_helper
INFO - 2024-10-02 06:50:25 --> Helper loaded: file_helper
INFO - 2024-10-02 06:50:25 --> Helper loaded: security_helper
INFO - 2024-10-02 06:50:25 --> Helper loaded: wpu_helper
INFO - 2024-10-02 06:50:25 --> Database Driver Class Initialized
INFO - 2024-10-02 06:50:25 --> Email Class Initialized
DEBUG - 2024-10-02 06:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 06:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 06:50:25 --> Helper loaded: form_helper
INFO - 2024-10-02 06:50:25 --> Form Validation Class Initialized
INFO - 2024-10-02 06:50:25 --> Controller Class Initialized
DEBUG - 2024-10-02 06:50:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 06:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 06:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 06:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 06:50:25 --> Final output sent to browser
DEBUG - 2024-10-02 06:50:25 --> Total execution time: 0.2239
INFO - 2024-10-02 07:53:38 --> Config Class Initialized
INFO - 2024-10-02 07:53:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 07:53:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 07:53:38 --> Utf8 Class Initialized
INFO - 2024-10-02 07:53:38 --> URI Class Initialized
DEBUG - 2024-10-02 07:53:38 --> No URI present. Default controller set.
INFO - 2024-10-02 07:53:38 --> Router Class Initialized
INFO - 2024-10-02 07:53:38 --> Output Class Initialized
INFO - 2024-10-02 07:53:38 --> Security Class Initialized
DEBUG - 2024-10-02 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 07:53:38 --> Input Class Initialized
INFO - 2024-10-02 07:53:38 --> Language Class Initialized
INFO - 2024-10-02 07:53:38 --> Loader Class Initialized
INFO - 2024-10-02 07:53:38 --> Helper loaded: url_helper
INFO - 2024-10-02 07:53:38 --> Helper loaded: file_helper
INFO - 2024-10-02 07:53:38 --> Helper loaded: security_helper
INFO - 2024-10-02 07:53:38 --> Helper loaded: wpu_helper
INFO - 2024-10-02 07:53:38 --> Database Driver Class Initialized
INFO - 2024-10-02 07:53:38 --> Email Class Initialized
DEBUG - 2024-10-02 07:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 07:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 07:53:38 --> Helper loaded: form_helper
INFO - 2024-10-02 07:53:38 --> Form Validation Class Initialized
INFO - 2024-10-02 07:53:38 --> Controller Class Initialized
DEBUG - 2024-10-02 07:53:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 07:53:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 07:53:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 07:53:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 07:53:38 --> Final output sent to browser
DEBUG - 2024-10-02 07:53:38 --> Total execution time: 0.2440
INFO - 2024-10-02 09:18:05 --> Config Class Initialized
INFO - 2024-10-02 09:18:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 09:18:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 09:18:05 --> Utf8 Class Initialized
INFO - 2024-10-02 09:18:05 --> URI Class Initialized
DEBUG - 2024-10-02 09:18:05 --> No URI present. Default controller set.
INFO - 2024-10-02 09:18:05 --> Router Class Initialized
INFO - 2024-10-02 09:18:05 --> Output Class Initialized
INFO - 2024-10-02 09:18:05 --> Security Class Initialized
DEBUG - 2024-10-02 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 09:18:05 --> Input Class Initialized
INFO - 2024-10-02 09:18:05 --> Language Class Initialized
INFO - 2024-10-02 09:18:05 --> Loader Class Initialized
INFO - 2024-10-02 09:18:05 --> Helper loaded: url_helper
INFO - 2024-10-02 09:18:05 --> Helper loaded: file_helper
INFO - 2024-10-02 09:18:05 --> Helper loaded: security_helper
INFO - 2024-10-02 09:18:05 --> Helper loaded: wpu_helper
INFO - 2024-10-02 09:18:05 --> Database Driver Class Initialized
INFO - 2024-10-02 09:18:05 --> Email Class Initialized
DEBUG - 2024-10-02 09:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 09:18:05 --> Helper loaded: form_helper
INFO - 2024-10-02 09:18:05 --> Form Validation Class Initialized
INFO - 2024-10-02 09:18:05 --> Controller Class Initialized
DEBUG - 2024-10-02 09:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 09:18:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 09:18:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 09:18:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 09:18:05 --> Final output sent to browser
DEBUG - 2024-10-02 09:18:05 --> Total execution time: 0.2364
INFO - 2024-10-02 09:24:13 --> Config Class Initialized
INFO - 2024-10-02 09:24:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 09:24:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 09:24:13 --> Utf8 Class Initialized
INFO - 2024-10-02 09:24:13 --> URI Class Initialized
DEBUG - 2024-10-02 09:24:13 --> No URI present. Default controller set.
INFO - 2024-10-02 09:24:13 --> Router Class Initialized
INFO - 2024-10-02 09:24:13 --> Output Class Initialized
INFO - 2024-10-02 09:24:13 --> Security Class Initialized
DEBUG - 2024-10-02 09:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 09:24:13 --> Input Class Initialized
INFO - 2024-10-02 09:24:13 --> Language Class Initialized
INFO - 2024-10-02 09:24:13 --> Loader Class Initialized
INFO - 2024-10-02 09:24:13 --> Helper loaded: url_helper
INFO - 2024-10-02 09:24:13 --> Helper loaded: file_helper
INFO - 2024-10-02 09:24:13 --> Helper loaded: security_helper
INFO - 2024-10-02 09:24:13 --> Helper loaded: wpu_helper
INFO - 2024-10-02 09:24:13 --> Database Driver Class Initialized
INFO - 2024-10-02 09:24:14 --> Email Class Initialized
DEBUG - 2024-10-02 09:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 09:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 09:24:14 --> Helper loaded: form_helper
INFO - 2024-10-02 09:24:14 --> Form Validation Class Initialized
INFO - 2024-10-02 09:24:14 --> Controller Class Initialized
DEBUG - 2024-10-02 09:24:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 09:24:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 09:24:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 09:24:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 09:24:14 --> Final output sent to browser
DEBUG - 2024-10-02 09:24:14 --> Total execution time: 0.2468
INFO - 2024-10-02 12:26:58 --> Config Class Initialized
INFO - 2024-10-02 12:26:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 12:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 12:26:58 --> Utf8 Class Initialized
INFO - 2024-10-02 12:26:58 --> URI Class Initialized
DEBUG - 2024-10-02 12:26:58 --> No URI present. Default controller set.
INFO - 2024-10-02 12:26:58 --> Router Class Initialized
INFO - 2024-10-02 12:26:58 --> Output Class Initialized
INFO - 2024-10-02 12:26:58 --> Security Class Initialized
DEBUG - 2024-10-02 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 12:26:58 --> Input Class Initialized
INFO - 2024-10-02 12:26:58 --> Language Class Initialized
INFO - 2024-10-02 12:26:58 --> Loader Class Initialized
INFO - 2024-10-02 12:26:58 --> Helper loaded: url_helper
INFO - 2024-10-02 12:26:58 --> Helper loaded: file_helper
INFO - 2024-10-02 12:26:58 --> Helper loaded: security_helper
INFO - 2024-10-02 12:26:58 --> Helper loaded: wpu_helper
INFO - 2024-10-02 12:26:58 --> Database Driver Class Initialized
INFO - 2024-10-02 12:26:58 --> Email Class Initialized
DEBUG - 2024-10-02 12:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 12:26:58 --> Helper loaded: form_helper
INFO - 2024-10-02 12:26:58 --> Form Validation Class Initialized
INFO - 2024-10-02 12:26:58 --> Controller Class Initialized
DEBUG - 2024-10-02 12:26:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 12:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 12:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 12:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 12:26:58 --> Final output sent to browser
DEBUG - 2024-10-02 12:26:58 --> Total execution time: 0.2226
INFO - 2024-10-02 12:27:09 --> Config Class Initialized
INFO - 2024-10-02 12:27:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 12:27:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 12:27:09 --> Utf8 Class Initialized
INFO - 2024-10-02 12:27:09 --> URI Class Initialized
DEBUG - 2024-10-02 12:27:09 --> No URI present. Default controller set.
INFO - 2024-10-02 12:27:09 --> Router Class Initialized
INFO - 2024-10-02 12:27:09 --> Output Class Initialized
INFO - 2024-10-02 12:27:09 --> Security Class Initialized
DEBUG - 2024-10-02 12:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 12:27:09 --> Input Class Initialized
INFO - 2024-10-02 12:27:09 --> Language Class Initialized
INFO - 2024-10-02 12:27:09 --> Loader Class Initialized
INFO - 2024-10-02 12:27:09 --> Helper loaded: url_helper
INFO - 2024-10-02 12:27:09 --> Helper loaded: file_helper
INFO - 2024-10-02 12:27:09 --> Helper loaded: security_helper
INFO - 2024-10-02 12:27:09 --> Helper loaded: wpu_helper
INFO - 2024-10-02 12:27:09 --> Database Driver Class Initialized
INFO - 2024-10-02 12:27:09 --> Email Class Initialized
DEBUG - 2024-10-02 12:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 12:27:09 --> Helper loaded: form_helper
INFO - 2024-10-02 12:27:09 --> Form Validation Class Initialized
INFO - 2024-10-02 12:27:09 --> Controller Class Initialized
DEBUG - 2024-10-02 12:27:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 12:27:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 12:27:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 12:27:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 12:27:09 --> Final output sent to browser
DEBUG - 2024-10-02 12:27:09 --> Total execution time: 0.2264
INFO - 2024-10-02 12:29:16 --> Config Class Initialized
INFO - 2024-10-02 12:29:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 12:29:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 12:29:16 --> Utf8 Class Initialized
INFO - 2024-10-02 12:29:16 --> URI Class Initialized
DEBUG - 2024-10-02 12:29:16 --> No URI present. Default controller set.
INFO - 2024-10-02 12:29:16 --> Router Class Initialized
INFO - 2024-10-02 12:29:16 --> Output Class Initialized
INFO - 2024-10-02 12:29:16 --> Security Class Initialized
DEBUG - 2024-10-02 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 12:29:16 --> Input Class Initialized
INFO - 2024-10-02 12:29:16 --> Language Class Initialized
INFO - 2024-10-02 12:29:16 --> Loader Class Initialized
INFO - 2024-10-02 12:29:16 --> Helper loaded: url_helper
INFO - 2024-10-02 12:29:16 --> Helper loaded: file_helper
INFO - 2024-10-02 12:29:16 --> Helper loaded: security_helper
INFO - 2024-10-02 12:29:16 --> Helper loaded: wpu_helper
INFO - 2024-10-02 12:29:16 --> Database Driver Class Initialized
INFO - 2024-10-02 12:29:16 --> Email Class Initialized
DEBUG - 2024-10-02 12:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 12:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 12:29:16 --> Helper loaded: form_helper
INFO - 2024-10-02 12:29:16 --> Form Validation Class Initialized
INFO - 2024-10-02 12:29:16 --> Controller Class Initialized
DEBUG - 2024-10-02 12:29:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 12:29:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 12:29:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 12:29:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 12:29:16 --> Final output sent to browser
DEBUG - 2024-10-02 12:29:16 --> Total execution time: 0.2324
INFO - 2024-10-02 12:29:16 --> Config Class Initialized
INFO - 2024-10-02 12:29:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 12:29:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 12:29:16 --> Utf8 Class Initialized
INFO - 2024-10-02 13:26:57 --> Config Class Initialized
INFO - 2024-10-02 13:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:26:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:26:57 --> Utf8 Class Initialized
INFO - 2024-10-02 13:26:57 --> URI Class Initialized
DEBUG - 2024-10-02 13:26:57 --> No URI present. Default controller set.
INFO - 2024-10-02 13:26:57 --> Router Class Initialized
INFO - 2024-10-02 13:26:57 --> Output Class Initialized
INFO - 2024-10-02 13:26:57 --> Security Class Initialized
DEBUG - 2024-10-02 13:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:26:57 --> Input Class Initialized
INFO - 2024-10-02 13:26:57 --> Language Class Initialized
INFO - 2024-10-02 13:26:57 --> Loader Class Initialized
INFO - 2024-10-02 13:26:57 --> Helper loaded: url_helper
INFO - 2024-10-02 13:26:57 --> Helper loaded: file_helper
INFO - 2024-10-02 13:26:57 --> Helper loaded: security_helper
INFO - 2024-10-02 13:26:57 --> Helper loaded: wpu_helper
INFO - 2024-10-02 13:26:57 --> Database Driver Class Initialized
INFO - 2024-10-02 13:26:58 --> Email Class Initialized
DEBUG - 2024-10-02 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 13:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:26:58 --> Helper loaded: form_helper
INFO - 2024-10-02 13:26:58 --> Form Validation Class Initialized
INFO - 2024-10-02 13:26:58 --> Controller Class Initialized
DEBUG - 2024-10-02 13:26:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 13:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 13:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 13:26:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 13:26:58 --> Final output sent to browser
DEBUG - 2024-10-02 13:26:58 --> Total execution time: 0.2546
INFO - 2024-10-02 13:45:57 --> Config Class Initialized
INFO - 2024-10-02 13:45:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:57 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:57 --> URI Class Initialized
DEBUG - 2024-10-02 13:45:57 --> No URI present. Default controller set.
INFO - 2024-10-02 13:45:57 --> Router Class Initialized
INFO - 2024-10-02 13:45:57 --> Output Class Initialized
INFO - 2024-10-02 13:45:57 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:57 --> Input Class Initialized
INFO - 2024-10-02 13:45:57 --> Language Class Initialized
INFO - 2024-10-02 13:45:57 --> Loader Class Initialized
INFO - 2024-10-02 13:45:57 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:57 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:57 --> Helper loaded: security_helper
INFO - 2024-10-02 13:45:57 --> Helper loaded: wpu_helper
INFO - 2024-10-02 13:45:57 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:57 --> Email Class Initialized
DEBUG - 2024-10-02 13:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 13:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:57 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:57 --> Form Validation Class Initialized
INFO - 2024-10-02 13:45:57 --> Controller Class Initialized
DEBUG - 2024-10-02 13:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 13:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 13:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 13:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 13:45:57 --> Final output sent to browser
DEBUG - 2024-10-02 13:45:57 --> Total execution time: 0.2280
INFO - 2024-10-02 13:56:27 --> Config Class Initialized
INFO - 2024-10-02 13:56:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:56:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:56:27 --> Utf8 Class Initialized
INFO - 2024-10-02 13:56:27 --> URI Class Initialized
DEBUG - 2024-10-02 13:56:27 --> No URI present. Default controller set.
INFO - 2024-10-02 13:56:27 --> Router Class Initialized
INFO - 2024-10-02 13:56:27 --> Output Class Initialized
INFO - 2024-10-02 13:56:27 --> Security Class Initialized
DEBUG - 2024-10-02 13:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:56:27 --> Input Class Initialized
INFO - 2024-10-02 13:56:27 --> Language Class Initialized
INFO - 2024-10-02 13:56:27 --> Loader Class Initialized
INFO - 2024-10-02 13:56:27 --> Helper loaded: url_helper
INFO - 2024-10-02 13:56:27 --> Helper loaded: file_helper
INFO - 2024-10-02 13:56:27 --> Helper loaded: security_helper
INFO - 2024-10-02 13:56:27 --> Helper loaded: wpu_helper
INFO - 2024-10-02 13:56:27 --> Database Driver Class Initialized
INFO - 2024-10-02 13:56:27 --> Email Class Initialized
DEBUG - 2024-10-02 13:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 13:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:56:27 --> Helper loaded: form_helper
INFO - 2024-10-02 13:56:27 --> Form Validation Class Initialized
INFO - 2024-10-02 13:56:27 --> Controller Class Initialized
DEBUG - 2024-10-02 13:56:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 13:56:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 13:56:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 13:56:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 13:56:27 --> Final output sent to browser
DEBUG - 2024-10-02 13:56:27 --> Total execution time: 0.2229
INFO - 2024-10-02 14:09:29 --> Config Class Initialized
INFO - 2024-10-02 14:09:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:29 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:29 --> URI Class Initialized
DEBUG - 2024-10-02 14:09:29 --> No URI present. Default controller set.
INFO - 2024-10-02 14:09:29 --> Router Class Initialized
INFO - 2024-10-02 14:09:29 --> Output Class Initialized
INFO - 2024-10-02 14:09:29 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:29 --> Input Class Initialized
INFO - 2024-10-02 14:09:29 --> Language Class Initialized
INFO - 2024-10-02 14:09:29 --> Loader Class Initialized
INFO - 2024-10-02 14:09:29 --> Helper loaded: url_helper
INFO - 2024-10-02 14:09:29 --> Helper loaded: file_helper
INFO - 2024-10-02 14:09:29 --> Helper loaded: security_helper
INFO - 2024-10-02 14:09:29 --> Helper loaded: wpu_helper
INFO - 2024-10-02 14:09:29 --> Database Driver Class Initialized
INFO - 2024-10-02 14:09:29 --> Email Class Initialized
DEBUG - 2024-10-02 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:09:29 --> Helper loaded: form_helper
INFO - 2024-10-02 14:09:29 --> Form Validation Class Initialized
INFO - 2024-10-02 14:09:29 --> Controller Class Initialized
DEBUG - 2024-10-02 14:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 14:09:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 14:09:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 14:09:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 14:09:29 --> Final output sent to browser
DEBUG - 2024-10-02 14:09:29 --> Total execution time: 0.2599
INFO - 2024-10-02 14:09:32 --> Config Class Initialized
INFO - 2024-10-02 14:09:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:32 --> URI Class Initialized
DEBUG - 2024-10-02 14:09:32 --> No URI present. Default controller set.
INFO - 2024-10-02 14:09:32 --> Router Class Initialized
INFO - 2024-10-02 14:09:32 --> Output Class Initialized
INFO - 2024-10-02 14:09:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:32 --> Input Class Initialized
INFO - 2024-10-02 14:09:32 --> Language Class Initialized
INFO - 2024-10-02 14:09:32 --> Loader Class Initialized
INFO - 2024-10-02 14:09:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:09:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:09:32 --> Helper loaded: security_helper
INFO - 2024-10-02 14:09:32 --> Helper loaded: wpu_helper
INFO - 2024-10-02 14:09:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:09:32 --> Email Class Initialized
DEBUG - 2024-10-02 14:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 14:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:09:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:09:32 --> Form Validation Class Initialized
INFO - 2024-10-02 14:09:32 --> Controller Class Initialized
DEBUG - 2024-10-02 14:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 14:09:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 14:09:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 14:09:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 14:09:32 --> Final output sent to browser
DEBUG - 2024-10-02 14:09:32 --> Total execution time: 0.2682
INFO - 2024-10-02 14:09:42 --> Config Class Initialized
INFO - 2024-10-02 14:09:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:42 --> URI Class Initialized
INFO - 2024-10-02 14:09:42 --> Router Class Initialized
INFO - 2024-10-02 14:09:42 --> Output Class Initialized
INFO - 2024-10-02 14:09:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:42 --> Input Class Initialized
INFO - 2024-10-02 14:09:42 --> Language Class Initialized
ERROR - 2024-10-02 14:09:42 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 14:09:42 --> Config Class Initialized
INFO - 2024-10-02 14:09:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:42 --> URI Class Initialized
INFO - 2024-10-02 14:09:42 --> Router Class Initialized
INFO - 2024-10-02 14:09:42 --> Output Class Initialized
INFO - 2024-10-02 14:09:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:42 --> Input Class Initialized
INFO - 2024-10-02 14:09:42 --> Language Class Initialized
ERROR - 2024-10-02 14:09:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:42 --> Config Class Initialized
INFO - 2024-10-02 14:09:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:42 --> URI Class Initialized
INFO - 2024-10-02 14:09:42 --> Router Class Initialized
INFO - 2024-10-02 14:09:42 --> Config Class Initialized
INFO - 2024-10-02 14:09:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:42 --> URI Class Initialized
INFO - 2024-10-02 14:09:42 --> Router Class Initialized
INFO - 2024-10-02 14:09:42 --> Config Class Initialized
INFO - 2024-10-02 14:09:42 --> Hooks Class Initialized
INFO - 2024-10-02 14:09:42 --> Output Class Initialized
DEBUG - 2024-10-02 14:09:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:42 --> Security Class Initialized
INFO - 2024-10-02 14:09:42 --> URI Class Initialized
DEBUG - 2024-10-02 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:42 --> Input Class Initialized
INFO - 2024-10-02 14:09:42 --> Router Class Initialized
INFO - 2024-10-02 14:09:42 --> Language Class Initialized
ERROR - 2024-10-02 14:09:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:42 --> Output Class Initialized
INFO - 2024-10-02 14:09:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:42 --> Input Class Initialized
INFO - 2024-10-02 14:09:42 --> Language Class Initialized
ERROR - 2024-10-02 14:09:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:42 --> Output Class Initialized
INFO - 2024-10-02 14:09:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:42 --> Input Class Initialized
INFO - 2024-10-02 14:09:42 --> Language Class Initialized
ERROR - 2024-10-02 14:09:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:43 --> Config Class Initialized
INFO - 2024-10-02 14:09:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:43 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:43 --> URI Class Initialized
INFO - 2024-10-02 14:09:43 --> Router Class Initialized
INFO - 2024-10-02 14:09:43 --> Output Class Initialized
INFO - 2024-10-02 14:09:43 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:43 --> Input Class Initialized
INFO - 2024-10-02 14:09:43 --> Language Class Initialized
ERROR - 2024-10-02 14:09:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:44 --> Config Class Initialized
INFO - 2024-10-02 14:09:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:44 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:44 --> URI Class Initialized
INFO - 2024-10-02 14:09:44 --> Router Class Initialized
INFO - 2024-10-02 14:09:44 --> Output Class Initialized
INFO - 2024-10-02 14:09:44 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:44 --> Input Class Initialized
INFO - 2024-10-02 14:09:44 --> Language Class Initialized
ERROR - 2024-10-02 14:09:44 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:44 --> Config Class Initialized
INFO - 2024-10-02 14:09:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:44 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:44 --> URI Class Initialized
INFO - 2024-10-02 14:09:44 --> Router Class Initialized
INFO - 2024-10-02 14:09:44 --> Output Class Initialized
INFO - 2024-10-02 14:09:44 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:44 --> Input Class Initialized
INFO - 2024-10-02 14:09:44 --> Language Class Initialized
ERROR - 2024-10-02 14:09:44 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:56 --> Config Class Initialized
INFO - 2024-10-02 14:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:56 --> URI Class Initialized
INFO - 2024-10-02 14:09:56 --> Router Class Initialized
INFO - 2024-10-02 14:09:56 --> Output Class Initialized
INFO - 2024-10-02 14:09:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:56 --> Input Class Initialized
INFO - 2024-10-02 14:09:56 --> Language Class Initialized
ERROR - 2024-10-02 14:09:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:56 --> Config Class Initialized
INFO - 2024-10-02 14:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:56 --> URI Class Initialized
INFO - 2024-10-02 14:09:56 --> Router Class Initialized
INFO - 2024-10-02 14:09:56 --> Output Class Initialized
INFO - 2024-10-02 14:09:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:56 --> Input Class Initialized
INFO - 2024-10-02 14:09:56 --> Language Class Initialized
ERROR - 2024-10-02 14:09:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:56 --> Config Class Initialized
INFO - 2024-10-02 14:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:56 --> URI Class Initialized
INFO - 2024-10-02 14:09:56 --> Router Class Initialized
INFO - 2024-10-02 14:09:56 --> Output Class Initialized
INFO - 2024-10-02 14:09:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:56 --> Input Class Initialized
INFO - 2024-10-02 14:09:56 --> Language Class Initialized
ERROR - 2024-10-02 14:09:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:57 --> Config Class Initialized
INFO - 2024-10-02 14:09:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:57 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:57 --> URI Class Initialized
INFO - 2024-10-02 14:09:57 --> Router Class Initialized
INFO - 2024-10-02 14:09:57 --> Output Class Initialized
INFO - 2024-10-02 14:09:57 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:57 --> Input Class Initialized
INFO - 2024-10-02 14:09:57 --> Language Class Initialized
ERROR - 2024-10-02 14:09:57 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 14:09:57 --> Config Class Initialized
INFO - 2024-10-02 14:09:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:57 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:57 --> URI Class Initialized
INFO - 2024-10-02 14:09:57 --> Config Class Initialized
INFO - 2024-10-02 14:09:57 --> Hooks Class Initialized
INFO - 2024-10-02 14:09:57 --> Router Class Initialized
DEBUG - 2024-10-02 14:09:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:57 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:57 --> URI Class Initialized
INFO - 2024-10-02 14:09:57 --> Router Class Initialized
INFO - 2024-10-02 14:09:57 --> Output Class Initialized
INFO - 2024-10-02 14:09:57 --> Output Class Initialized
INFO - 2024-10-02 14:09:57 --> Security Class Initialized
INFO - 2024-10-02 14:09:57 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:57 --> Input Class Initialized
DEBUG - 2024-10-02 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:57 --> Input Class Initialized
INFO - 2024-10-02 14:09:57 --> Language Class Initialized
INFO - 2024-10-02 14:09:57 --> Language Class Initialized
ERROR - 2024-10-02 14:09:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-10-02 14:09:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:57 --> Config Class Initialized
INFO - 2024-10-02 14:09:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:57 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:57 --> URI Class Initialized
INFO - 2024-10-02 14:09:57 --> Router Class Initialized
INFO - 2024-10-02 14:09:57 --> Output Class Initialized
INFO - 2024-10-02 14:09:57 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:57 --> Input Class Initialized
INFO - 2024-10-02 14:09:57 --> Language Class Initialized
ERROR - 2024-10-02 14:09:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:58 --> Config Class Initialized
INFO - 2024-10-02 14:09:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:58 --> URI Class Initialized
INFO - 2024-10-02 14:09:58 --> Router Class Initialized
INFO - 2024-10-02 14:09:58 --> Output Class Initialized
INFO - 2024-10-02 14:09:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:58 --> Input Class Initialized
INFO - 2024-10-02 14:09:58 --> Language Class Initialized
ERROR - 2024-10-02 14:09:58 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 14:09:58 --> Config Class Initialized
INFO - 2024-10-02 14:09:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:58 --> URI Class Initialized
INFO - 2024-10-02 14:09:58 --> Router Class Initialized
INFO - 2024-10-02 14:09:58 --> Output Class Initialized
INFO - 2024-10-02 14:09:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:58 --> Input Class Initialized
INFO - 2024-10-02 14:09:58 --> Language Class Initialized
ERROR - 2024-10-02 14:09:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 14:09:58 --> Config Class Initialized
INFO - 2024-10-02 14:09:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:58 --> URI Class Initialized
INFO - 2024-10-02 14:09:58 --> Router Class Initialized
INFO - 2024-10-02 14:09:58 --> Output Class Initialized
INFO - 2024-10-02 14:09:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:58 --> Input Class Initialized
INFO - 2024-10-02 14:09:58 --> Language Class Initialized
ERROR - 2024-10-02 14:09:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 16:04:35 --> Config Class Initialized
INFO - 2024-10-02 16:04:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:04:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:04:35 --> Utf8 Class Initialized
INFO - 2024-10-02 16:04:35 --> URI Class Initialized
DEBUG - 2024-10-02 16:04:35 --> No URI present. Default controller set.
INFO - 2024-10-02 16:04:35 --> Router Class Initialized
INFO - 2024-10-02 16:04:35 --> Output Class Initialized
INFO - 2024-10-02 16:04:35 --> Security Class Initialized
DEBUG - 2024-10-02 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:04:35 --> Input Class Initialized
INFO - 2024-10-02 16:04:35 --> Language Class Initialized
INFO - 2024-10-02 16:04:35 --> Loader Class Initialized
INFO - 2024-10-02 16:04:35 --> Helper loaded: url_helper
INFO - 2024-10-02 16:04:35 --> Helper loaded: file_helper
INFO - 2024-10-02 16:04:35 --> Helper loaded: security_helper
INFO - 2024-10-02 16:04:35 --> Helper loaded: wpu_helper
INFO - 2024-10-02 16:04:35 --> Database Driver Class Initialized
INFO - 2024-10-02 16:04:35 --> Email Class Initialized
DEBUG - 2024-10-02 16:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:04:35 --> Helper loaded: form_helper
INFO - 2024-10-02 16:04:35 --> Form Validation Class Initialized
INFO - 2024-10-02 16:04:35 --> Controller Class Initialized
DEBUG - 2024-10-02 16:04:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 16:04:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 16:04:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 16:04:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 16:04:35 --> Final output sent to browser
DEBUG - 2024-10-02 16:04:35 --> Total execution time: 0.2336
INFO - 2024-10-02 16:04:51 --> Config Class Initialized
INFO - 2024-10-02 16:04:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:04:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:04:51 --> Utf8 Class Initialized
INFO - 2024-10-02 16:04:51 --> URI Class Initialized
INFO - 2024-10-02 16:04:51 --> Router Class Initialized
INFO - 2024-10-02 16:04:51 --> Output Class Initialized
INFO - 2024-10-02 16:04:51 --> Security Class Initialized
DEBUG - 2024-10-02 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:04:51 --> Input Class Initialized
INFO - 2024-10-02 16:04:51 --> Language Class Initialized
ERROR - 2024-10-02 16:04:51 --> 404 Page Not Found: Public/home
INFO - 2024-10-02 16:04:53 --> Config Class Initialized
INFO - 2024-10-02 16:04:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:04:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:04:53 --> Utf8 Class Initialized
INFO - 2024-10-02 16:04:53 --> URI Class Initialized
DEBUG - 2024-10-02 16:04:53 --> No URI present. Default controller set.
INFO - 2024-10-02 16:04:53 --> Router Class Initialized
INFO - 2024-10-02 16:04:53 --> Output Class Initialized
INFO - 2024-10-02 16:04:53 --> Security Class Initialized
DEBUG - 2024-10-02 16:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:04:53 --> Input Class Initialized
INFO - 2024-10-02 16:04:53 --> Language Class Initialized
INFO - 2024-10-02 16:04:53 --> Loader Class Initialized
INFO - 2024-10-02 16:04:53 --> Helper loaded: url_helper
INFO - 2024-10-02 16:04:53 --> Helper loaded: file_helper
INFO - 2024-10-02 16:04:53 --> Helper loaded: security_helper
INFO - 2024-10-02 16:04:53 --> Helper loaded: wpu_helper
INFO - 2024-10-02 16:04:53 --> Database Driver Class Initialized
INFO - 2024-10-02 16:04:54 --> Email Class Initialized
DEBUG - 2024-10-02 16:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 16:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:04:54 --> Helper loaded: form_helper
INFO - 2024-10-02 16:04:54 --> Form Validation Class Initialized
INFO - 2024-10-02 16:04:54 --> Controller Class Initialized
DEBUG - 2024-10-02 16:04:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 16:04:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 16:04:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 16:04:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 16:04:54 --> Final output sent to browser
DEBUG - 2024-10-02 16:04:54 --> Total execution time: 0.2235
INFO - 2024-10-02 16:05:11 --> Config Class Initialized
INFO - 2024-10-02 16:05:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:05:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:05:11 --> Utf8 Class Initialized
INFO - 2024-10-02 16:05:11 --> URI Class Initialized
INFO - 2024-10-02 16:05:11 --> Router Class Initialized
INFO - 2024-10-02 16:05:11 --> Output Class Initialized
INFO - 2024-10-02 16:05:11 --> Security Class Initialized
DEBUG - 2024-10-02 16:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:05:11 --> Input Class Initialized
INFO - 2024-10-02 16:05:11 --> Language Class Initialized
ERROR - 2024-10-02 16:05:11 --> 404 Page Not Found: Static/admin
INFO - 2024-10-02 18:02:56 --> Config Class Initialized
INFO - 2024-10-02 18:02:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:02:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:02:56 --> Utf8 Class Initialized
INFO - 2024-10-02 18:02:56 --> URI Class Initialized
DEBUG - 2024-10-02 18:02:56 --> No URI present. Default controller set.
INFO - 2024-10-02 18:02:56 --> Router Class Initialized
INFO - 2024-10-02 18:02:56 --> Output Class Initialized
INFO - 2024-10-02 18:02:56 --> Security Class Initialized
DEBUG - 2024-10-02 18:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:02:56 --> Input Class Initialized
INFO - 2024-10-02 18:02:56 --> Language Class Initialized
INFO - 2024-10-02 18:02:56 --> Loader Class Initialized
INFO - 2024-10-02 18:02:56 --> Helper loaded: url_helper
INFO - 2024-10-02 18:02:56 --> Helper loaded: file_helper
INFO - 2024-10-02 18:02:56 --> Helper loaded: security_helper
INFO - 2024-10-02 18:02:56 --> Helper loaded: wpu_helper
INFO - 2024-10-02 18:02:56 --> Database Driver Class Initialized
INFO - 2024-10-02 18:02:57 --> Email Class Initialized
DEBUG - 2024-10-02 18:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 18:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 18:02:57 --> Helper loaded: form_helper
INFO - 2024-10-02 18:02:57 --> Form Validation Class Initialized
INFO - 2024-10-02 18:02:57 --> Controller Class Initialized
DEBUG - 2024-10-02 18:02:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 18:02:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 18:02:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 18:02:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 18:02:57 --> Final output sent to browser
DEBUG - 2024-10-02 18:02:57 --> Total execution time: 0.4879
INFO - 2024-10-02 18:03:17 --> Config Class Initialized
INFO - 2024-10-02 18:03:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:17 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:17 --> URI Class Initialized
INFO - 2024-10-02 18:03:17 --> Router Class Initialized
INFO - 2024-10-02 18:03:17 --> Output Class Initialized
INFO - 2024-10-02 18:03:17 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:17 --> Input Class Initialized
INFO - 2024-10-02 18:03:17 --> Language Class Initialized
ERROR - 2024-10-02 18:03:17 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 18:03:17 --> Config Class Initialized
INFO - 2024-10-02 18:03:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:17 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:17 --> URI Class Initialized
INFO - 2024-10-02 18:03:17 --> Router Class Initialized
INFO - 2024-10-02 18:03:17 --> Output Class Initialized
INFO - 2024-10-02 18:03:17 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:17 --> Input Class Initialized
INFO - 2024-10-02 18:03:17 --> Language Class Initialized
ERROR - 2024-10-02 18:03:17 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:17 --> Config Class Initialized
INFO - 2024-10-02 18:03:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:17 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:17 --> URI Class Initialized
INFO - 2024-10-02 18:03:17 --> Router Class Initialized
INFO - 2024-10-02 18:03:17 --> Output Class Initialized
INFO - 2024-10-02 18:03:17 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:17 --> Input Class Initialized
INFO - 2024-10-02 18:03:17 --> Language Class Initialized
ERROR - 2024-10-02 18:03:17 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:19 --> Config Class Initialized
INFO - 2024-10-02 18:03:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:19 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:19 --> URI Class Initialized
INFO - 2024-10-02 18:03:19 --> Router Class Initialized
INFO - 2024-10-02 18:03:19 --> Output Class Initialized
INFO - 2024-10-02 18:03:19 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:19 --> Input Class Initialized
INFO - 2024-10-02 18:03:19 --> Language Class Initialized
ERROR - 2024-10-02 18:03:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:21 --> Config Class Initialized
INFO - 2024-10-02 18:03:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:21 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:21 --> URI Class Initialized
INFO - 2024-10-02 18:03:21 --> Router Class Initialized
INFO - 2024-10-02 18:03:21 --> Output Class Initialized
INFO - 2024-10-02 18:03:21 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:21 --> Input Class Initialized
INFO - 2024-10-02 18:03:21 --> Language Class Initialized
ERROR - 2024-10-02 18:03:21 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:50 --> Config Class Initialized
INFO - 2024-10-02 18:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:50 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:50 --> URI Class Initialized
INFO - 2024-10-02 18:03:50 --> Router Class Initialized
INFO - 2024-10-02 18:03:50 --> Output Class Initialized
INFO - 2024-10-02 18:03:50 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:50 --> Input Class Initialized
INFO - 2024-10-02 18:03:50 --> Language Class Initialized
ERROR - 2024-10-02 18:03:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:50 --> Config Class Initialized
INFO - 2024-10-02 18:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:50 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:50 --> URI Class Initialized
INFO - 2024-10-02 18:03:50 --> Router Class Initialized
INFO - 2024-10-02 18:03:50 --> Output Class Initialized
INFO - 2024-10-02 18:03:50 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:50 --> Input Class Initialized
INFO - 2024-10-02 18:03:50 --> Language Class Initialized
ERROR - 2024-10-02 18:03:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:50 --> Config Class Initialized
INFO - 2024-10-02 18:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:50 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:50 --> Config Class Initialized
INFO - 2024-10-02 18:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:50 --> URI Class Initialized
INFO - 2024-10-02 18:03:50 --> Router Class Initialized
INFO - 2024-10-02 18:03:50 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:50 --> URI Class Initialized
INFO - 2024-10-02 18:03:50 --> Router Class Initialized
INFO - 2024-10-02 18:03:50 --> Output Class Initialized
INFO - 2024-10-02 18:03:50 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:50 --> Input Class Initialized
INFO - 2024-10-02 18:03:50 --> Language Class Initialized
ERROR - 2024-10-02 18:03:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:50 --> Output Class Initialized
INFO - 2024-10-02 18:03:50 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:50 --> Input Class Initialized
INFO - 2024-10-02 18:03:50 --> Language Class Initialized
ERROR - 2024-10-02 18:03:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:03:51 --> Config Class Initialized
INFO - 2024-10-02 18:03:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:03:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:03:51 --> Utf8 Class Initialized
INFO - 2024-10-02 18:03:51 --> URI Class Initialized
INFO - 2024-10-02 18:03:51 --> Router Class Initialized
INFO - 2024-10-02 18:03:51 --> Output Class Initialized
INFO - 2024-10-02 18:03:51 --> Security Class Initialized
DEBUG - 2024-10-02 18:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:03:51 --> Input Class Initialized
INFO - 2024-10-02 18:03:51 --> Language Class Initialized
ERROR - 2024-10-02 18:03:51 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 18:04:25 --> Config Class Initialized
INFO - 2024-10-02 18:04:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:04:25 --> Config Class Initialized
INFO - 2024-10-02 18:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 18:04:25 --> Hooks Class Initialized
INFO - 2024-10-02 18:04:25 --> URI Class Initialized
DEBUG - 2024-10-02 18:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 18:04:25 --> Router Class Initialized
INFO - 2024-10-02 18:04:25 --> URI Class Initialized
INFO - 2024-10-02 18:04:25 --> Output Class Initialized
INFO - 2024-10-02 18:04:25 --> Router Class Initialized
INFO - 2024-10-02 18:04:25 --> Security Class Initialized
INFO - 2024-10-02 18:04:25 --> Output Class Initialized
DEBUG - 2024-10-02 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:04:25 --> Input Class Initialized
INFO - 2024-10-02 18:04:25 --> Security Class Initialized
INFO - 2024-10-02 18:04:25 --> Language Class Initialized
ERROR - 2024-10-02 18:04:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-02 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:04:25 --> Input Class Initialized
INFO - 2024-10-02 18:04:25 --> Language Class Initialized
ERROR - 2024-10-02 18:04:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:04:25 --> Config Class Initialized
INFO - 2024-10-02 18:04:25 --> Hooks Class Initialized
INFO - 2024-10-02 18:04:25 --> Config Class Initialized
INFO - 2024-10-02 18:04:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 18:04:25 --> URI Class Initialized
DEBUG - 2024-10-02 18:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 18:04:25 --> Router Class Initialized
INFO - 2024-10-02 18:04:25 --> URI Class Initialized
INFO - 2024-10-02 18:04:25 --> Output Class Initialized
INFO - 2024-10-02 18:04:25 --> Router Class Initialized
INFO - 2024-10-02 18:04:25 --> Security Class Initialized
INFO - 2024-10-02 18:04:25 --> Output Class Initialized
DEBUG - 2024-10-02 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:04:25 --> Input Class Initialized
INFO - 2024-10-02 18:04:25 --> Language Class Initialized
INFO - 2024-10-02 18:04:25 --> Security Class Initialized
ERROR - 2024-10-02 18:04:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-10-02 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:04:25 --> Input Class Initialized
INFO - 2024-10-02 18:04:25 --> Language Class Initialized
ERROR - 2024-10-02 18:04:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 18:04:25 --> Config Class Initialized
INFO - 2024-10-02 18:04:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 18:04:25 --> URI Class Initialized
INFO - 2024-10-02 18:04:25 --> Router Class Initialized
INFO - 2024-10-02 18:04:25 --> Output Class Initialized
INFO - 2024-10-02 18:04:25 --> Security Class Initialized
DEBUG - 2024-10-02 18:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:04:25 --> Input Class Initialized
INFO - 2024-10-02 18:04:25 --> Language Class Initialized
ERROR - 2024-10-02 18:04:25 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 18:33:43 --> Config Class Initialized
INFO - 2024-10-02 18:33:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 18:33:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 18:33:43 --> Utf8 Class Initialized
INFO - 2024-10-02 18:33:43 --> URI Class Initialized
DEBUG - 2024-10-02 18:33:43 --> No URI present. Default controller set.
INFO - 2024-10-02 18:33:43 --> Router Class Initialized
INFO - 2024-10-02 18:33:43 --> Output Class Initialized
INFO - 2024-10-02 18:33:43 --> Security Class Initialized
DEBUG - 2024-10-02 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 18:33:43 --> Input Class Initialized
INFO - 2024-10-02 18:33:43 --> Language Class Initialized
INFO - 2024-10-02 18:33:43 --> Loader Class Initialized
INFO - 2024-10-02 18:33:43 --> Helper loaded: url_helper
INFO - 2024-10-02 18:33:43 --> Helper loaded: file_helper
INFO - 2024-10-02 18:33:43 --> Helper loaded: security_helper
INFO - 2024-10-02 18:33:43 --> Helper loaded: wpu_helper
INFO - 2024-10-02 18:33:43 --> Database Driver Class Initialized
INFO - 2024-10-02 18:33:43 --> Email Class Initialized
DEBUG - 2024-10-02 18:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 18:33:43 --> Helper loaded: form_helper
INFO - 2024-10-02 18:33:43 --> Form Validation Class Initialized
INFO - 2024-10-02 18:33:43 --> Controller Class Initialized
DEBUG - 2024-10-02 18:33:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 18:33:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 18:33:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 18:33:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 18:33:43 --> Final output sent to browser
DEBUG - 2024-10-02 18:33:43 --> Total execution time: 0.2303
INFO - 2024-10-02 22:03:54 --> Config Class Initialized
INFO - 2024-10-02 22:03:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:03:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:03:54 --> Utf8 Class Initialized
INFO - 2024-10-02 22:03:54 --> URI Class Initialized
DEBUG - 2024-10-02 22:03:54 --> No URI present. Default controller set.
INFO - 2024-10-02 22:03:54 --> Router Class Initialized
INFO - 2024-10-02 22:03:54 --> Output Class Initialized
INFO - 2024-10-02 22:03:54 --> Security Class Initialized
DEBUG - 2024-10-02 22:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:03:54 --> Input Class Initialized
INFO - 2024-10-02 22:03:54 --> Language Class Initialized
INFO - 2024-10-02 22:03:54 --> Loader Class Initialized
INFO - 2024-10-02 22:03:54 --> Helper loaded: url_helper
INFO - 2024-10-02 22:03:54 --> Helper loaded: file_helper
INFO - 2024-10-02 22:03:54 --> Helper loaded: security_helper
INFO - 2024-10-02 22:03:54 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:03:54 --> Database Driver Class Initialized
INFO - 2024-10-02 22:03:54 --> Email Class Initialized
DEBUG - 2024-10-02 22:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:03:54 --> Helper loaded: form_helper
INFO - 2024-10-02 22:03:54 --> Form Validation Class Initialized
INFO - 2024-10-02 22:03:54 --> Controller Class Initialized
DEBUG - 2024-10-02 22:03:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:03:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 22:03:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 22:03:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 22:03:54 --> Final output sent to browser
DEBUG - 2024-10-02 22:03:54 --> Total execution time: 0.2167
INFO - 2024-10-02 22:04:13 --> Config Class Initialized
INFO - 2024-10-02 22:04:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:13 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:13 --> URI Class Initialized
INFO - 2024-10-02 22:04:13 --> Router Class Initialized
INFO - 2024-10-02 22:04:13 --> Output Class Initialized
INFO - 2024-10-02 22:04:13 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:13 --> Input Class Initialized
INFO - 2024-10-02 22:04:13 --> Language Class Initialized
ERROR - 2024-10-02 22:04:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:13 --> Config Class Initialized
INFO - 2024-10-02 22:04:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:13 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:13 --> URI Class Initialized
INFO - 2024-10-02 22:04:13 --> Router Class Initialized
INFO - 2024-10-02 22:04:13 --> Output Class Initialized
INFO - 2024-10-02 22:04:13 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:13 --> Input Class Initialized
INFO - 2024-10-02 22:04:13 --> Language Class Initialized
ERROR - 2024-10-02 22:04:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:13 --> Config Class Initialized
INFO - 2024-10-02 22:04:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:13 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:13 --> URI Class Initialized
INFO - 2024-10-02 22:04:13 --> Router Class Initialized
INFO - 2024-10-02 22:04:13 --> Output Class Initialized
INFO - 2024-10-02 22:04:13 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:13 --> Input Class Initialized
INFO - 2024-10-02 22:04:13 --> Language Class Initialized
ERROR - 2024-10-02 22:04:13 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 22:04:15 --> Config Class Initialized
INFO - 2024-10-02 22:04:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:15 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:15 --> URI Class Initialized
INFO - 2024-10-02 22:04:15 --> Router Class Initialized
INFO - 2024-10-02 22:04:15 --> Output Class Initialized
INFO - 2024-10-02 22:04:15 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:15 --> Input Class Initialized
INFO - 2024-10-02 22:04:15 --> Language Class Initialized
ERROR - 2024-10-02 22:04:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:15 --> Config Class Initialized
INFO - 2024-10-02 22:04:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:15 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:15 --> URI Class Initialized
INFO - 2024-10-02 22:04:15 --> Router Class Initialized
INFO - 2024-10-02 22:04:15 --> Output Class Initialized
INFO - 2024-10-02 22:04:15 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:15 --> Input Class Initialized
INFO - 2024-10-02 22:04:15 --> Language Class Initialized
ERROR - 2024-10-02 22:04:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:46 --> Config Class Initialized
INFO - 2024-10-02 22:04:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:46 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:46 --> URI Class Initialized
INFO - 2024-10-02 22:04:46 --> Router Class Initialized
INFO - 2024-10-02 22:04:46 --> Output Class Initialized
INFO - 2024-10-02 22:04:46 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:46 --> Input Class Initialized
INFO - 2024-10-02 22:04:46 --> Language Class Initialized
ERROR - 2024-10-02 22:04:46 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:47 --> Config Class Initialized
INFO - 2024-10-02 22:04:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:47 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:47 --> URI Class Initialized
INFO - 2024-10-02 22:04:47 --> Router Class Initialized
INFO - 2024-10-02 22:04:47 --> Output Class Initialized
INFO - 2024-10-02 22:04:47 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:47 --> Input Class Initialized
INFO - 2024-10-02 22:04:47 --> Language Class Initialized
ERROR - 2024-10-02 22:04:47 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 22:04:48 --> Config Class Initialized
INFO - 2024-10-02 22:04:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:48 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:48 --> URI Class Initialized
INFO - 2024-10-02 22:04:48 --> Router Class Initialized
INFO - 2024-10-02 22:04:48 --> Output Class Initialized
INFO - 2024-10-02 22:04:48 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:48 --> Input Class Initialized
INFO - 2024-10-02 22:04:48 --> Language Class Initialized
ERROR - 2024-10-02 22:04:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:48 --> Config Class Initialized
INFO - 2024-10-02 22:04:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:48 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:48 --> URI Class Initialized
INFO - 2024-10-02 22:04:48 --> Router Class Initialized
INFO - 2024-10-02 22:04:48 --> Output Class Initialized
INFO - 2024-10-02 22:04:48 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:48 --> Input Class Initialized
INFO - 2024-10-02 22:04:48 --> Language Class Initialized
ERROR - 2024-10-02 22:04:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:04:48 --> Config Class Initialized
INFO - 2024-10-02 22:04:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:04:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:04:48 --> Utf8 Class Initialized
INFO - 2024-10-02 22:04:48 --> URI Class Initialized
INFO - 2024-10-02 22:04:48 --> Router Class Initialized
INFO - 2024-10-02 22:04:48 --> Output Class Initialized
INFO - 2024-10-02 22:04:48 --> Security Class Initialized
DEBUG - 2024-10-02 22:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:04:48 --> Input Class Initialized
INFO - 2024-10-02 22:04:48 --> Language Class Initialized
ERROR - 2024-10-02 22:04:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:05:04 --> Config Class Initialized
INFO - 2024-10-02 22:05:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:04 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:04 --> URI Class Initialized
DEBUG - 2024-10-02 22:05:04 --> No URI present. Default controller set.
INFO - 2024-10-02 22:05:04 --> Router Class Initialized
INFO - 2024-10-02 22:05:04 --> Output Class Initialized
INFO - 2024-10-02 22:05:04 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:04 --> Input Class Initialized
INFO - 2024-10-02 22:05:04 --> Language Class Initialized
INFO - 2024-10-02 22:05:04 --> Loader Class Initialized
INFO - 2024-10-02 22:05:04 --> Helper loaded: url_helper
INFO - 2024-10-02 22:05:04 --> Helper loaded: file_helper
INFO - 2024-10-02 22:05:04 --> Helper loaded: security_helper
INFO - 2024-10-02 22:05:04 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:05:04 --> Database Driver Class Initialized
INFO - 2024-10-02 22:05:05 --> Email Class Initialized
DEBUG - 2024-10-02 22:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:05:05 --> Helper loaded: form_helper
INFO - 2024-10-02 22:05:05 --> Form Validation Class Initialized
INFO - 2024-10-02 22:05:05 --> Controller Class Initialized
DEBUG - 2024-10-02 22:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:05:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 22:05:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 22:05:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 22:05:05 --> Final output sent to browser
DEBUG - 2024-10-02 22:05:05 --> Total execution time: 0.2356
INFO - 2024-10-02 22:05:19 --> Config Class Initialized
INFO - 2024-10-02 22:05:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:19 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:19 --> URI Class Initialized
INFO - 2024-10-02 22:05:19 --> Router Class Initialized
INFO - 2024-10-02 22:05:19 --> Output Class Initialized
INFO - 2024-10-02 22:05:19 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:19 --> Input Class Initialized
INFO - 2024-10-02 22:05:19 --> Language Class Initialized
INFO - 2024-10-02 22:05:19 --> Loader Class Initialized
INFO - 2024-10-02 22:05:19 --> Helper loaded: url_helper
INFO - 2024-10-02 22:05:19 --> Helper loaded: file_helper
INFO - 2024-10-02 22:05:19 --> Helper loaded: security_helper
INFO - 2024-10-02 22:05:19 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:05:19 --> Database Driver Class Initialized
INFO - 2024-10-02 22:05:19 --> Email Class Initialized
DEBUG - 2024-10-02 22:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:05:19 --> Helper loaded: form_helper
INFO - 2024-10-02 22:05:19 --> Form Validation Class Initialized
INFO - 2024-10-02 22:05:19 --> Controller Class Initialized
DEBUG - 2024-10-02 22:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:05:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-02 22:05:20 --> Config Class Initialized
INFO - 2024-10-02 22:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:20 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:20 --> URI Class Initialized
INFO - 2024-10-02 22:05:20 --> Router Class Initialized
INFO - 2024-10-02 22:05:20 --> Output Class Initialized
INFO - 2024-10-02 22:05:20 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:20 --> Input Class Initialized
INFO - 2024-10-02 22:05:20 --> Language Class Initialized
INFO - 2024-10-02 22:05:20 --> Loader Class Initialized
INFO - 2024-10-02 22:05:20 --> Helper loaded: url_helper
INFO - 2024-10-02 22:05:20 --> Helper loaded: file_helper
INFO - 2024-10-02 22:05:20 --> Helper loaded: security_helper
INFO - 2024-10-02 22:05:20 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:05:20 --> Database Driver Class Initialized
INFO - 2024-10-02 22:05:20 --> Email Class Initialized
DEBUG - 2024-10-02 22:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:05:20 --> Helper loaded: form_helper
INFO - 2024-10-02 22:05:20 --> Form Validation Class Initialized
INFO - 2024-10-02 22:05:20 --> Controller Class Initialized
INFO - 2024-10-02 22:05:20 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:05:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:05:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:05:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 22:05:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:05:20 --> Final output sent to browser
DEBUG - 2024-10-02 22:05:20 --> Total execution time: 0.7247
INFO - 2024-10-02 22:05:31 --> Config Class Initialized
INFO - 2024-10-02 22:05:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:31 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:31 --> URI Class Initialized
INFO - 2024-10-02 22:05:31 --> Router Class Initialized
INFO - 2024-10-02 22:05:31 --> Output Class Initialized
INFO - 2024-10-02 22:05:31 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:31 --> Input Class Initialized
INFO - 2024-10-02 22:05:31 --> Language Class Initialized
ERROR - 2024-10-02 22:05:31 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-10-02 22:05:31 --> Config Class Initialized
INFO - 2024-10-02 22:05:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:31 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:31 --> URI Class Initialized
INFO - 2024-10-02 22:05:31 --> Router Class Initialized
INFO - 2024-10-02 22:05:31 --> Output Class Initialized
INFO - 2024-10-02 22:05:31 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:31 --> Input Class Initialized
INFO - 2024-10-02 22:05:31 --> Language Class Initialized
ERROR - 2024-10-02 22:05:31 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:05:31 --> Config Class Initialized
INFO - 2024-10-02 22:05:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:31 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:31 --> URI Class Initialized
INFO - 2024-10-02 22:05:31 --> Router Class Initialized
INFO - 2024-10-02 22:05:31 --> Output Class Initialized
INFO - 2024-10-02 22:05:31 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:31 --> Input Class Initialized
INFO - 2024-10-02 22:05:31 --> Language Class Initialized
ERROR - 2024-10-02 22:05:31 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:05:32 --> Config Class Initialized
INFO - 2024-10-02 22:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:32 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:32 --> URI Class Initialized
INFO - 2024-10-02 22:05:32 --> Router Class Initialized
INFO - 2024-10-02 22:05:32 --> Output Class Initialized
INFO - 2024-10-02 22:05:32 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:32 --> Input Class Initialized
INFO - 2024-10-02 22:05:32 --> Language Class Initialized
ERROR - 2024-10-02 22:05:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:05:32 --> Config Class Initialized
INFO - 2024-10-02 22:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:05:32 --> Utf8 Class Initialized
INFO - 2024-10-02 22:05:32 --> URI Class Initialized
INFO - 2024-10-02 22:05:32 --> Router Class Initialized
INFO - 2024-10-02 22:05:32 --> Output Class Initialized
INFO - 2024-10-02 22:05:32 --> Security Class Initialized
DEBUG - 2024-10-02 22:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:05:32 --> Input Class Initialized
INFO - 2024-10-02 22:05:32 --> Language Class Initialized
ERROR - 2024-10-02 22:05:32 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-10-02 22:08:09 --> Config Class Initialized
INFO - 2024-10-02 22:08:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:08:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:08:09 --> Utf8 Class Initialized
INFO - 2024-10-02 22:08:09 --> URI Class Initialized
DEBUG - 2024-10-02 22:08:09 --> No URI present. Default controller set.
INFO - 2024-10-02 22:08:09 --> Router Class Initialized
INFO - 2024-10-02 22:08:09 --> Output Class Initialized
INFO - 2024-10-02 22:08:09 --> Security Class Initialized
DEBUG - 2024-10-02 22:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:08:09 --> Input Class Initialized
INFO - 2024-10-02 22:08:09 --> Language Class Initialized
INFO - 2024-10-02 22:08:09 --> Loader Class Initialized
INFO - 2024-10-02 22:08:09 --> Helper loaded: url_helper
INFO - 2024-10-02 22:08:09 --> Helper loaded: file_helper
INFO - 2024-10-02 22:08:09 --> Helper loaded: security_helper
INFO - 2024-10-02 22:08:09 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:08:09 --> Database Driver Class Initialized
INFO - 2024-10-02 22:08:09 --> Email Class Initialized
DEBUG - 2024-10-02 22:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:08:09 --> Helper loaded: form_helper
INFO - 2024-10-02 22:08:09 --> Form Validation Class Initialized
INFO - 2024-10-02 22:08:09 --> Controller Class Initialized
DEBUG - 2024-10-02 22:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-02 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-02 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-02 22:08:09 --> Final output sent to browser
DEBUG - 2024-10-02 22:08:09 --> Total execution time: 0.2187
INFO - 2024-10-02 22:08:11 --> Config Class Initialized
INFO - 2024-10-02 22:08:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:08:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:08:11 --> Utf8 Class Initialized
INFO - 2024-10-02 22:08:11 --> URI Class Initialized
INFO - 2024-10-02 22:08:11 --> Router Class Initialized
INFO - 2024-10-02 22:08:11 --> Output Class Initialized
INFO - 2024-10-02 22:08:11 --> Security Class Initialized
DEBUG - 2024-10-02 22:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:08:11 --> Input Class Initialized
INFO - 2024-10-02 22:08:11 --> Language Class Initialized
INFO - 2024-10-02 22:08:11 --> Loader Class Initialized
INFO - 2024-10-02 22:08:11 --> Helper loaded: url_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: file_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: security_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:08:11 --> Database Driver Class Initialized
INFO - 2024-10-02 22:08:11 --> Email Class Initialized
DEBUG - 2024-10-02 22:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:08:11 --> Helper loaded: form_helper
INFO - 2024-10-02 22:08:11 --> Form Validation Class Initialized
INFO - 2024-10-02 22:08:11 --> Controller Class Initialized
DEBUG - 2024-10-02 22:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:08:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-02 22:08:11 --> Config Class Initialized
INFO - 2024-10-02 22:08:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:08:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:08:11 --> Utf8 Class Initialized
INFO - 2024-10-02 22:08:11 --> URI Class Initialized
INFO - 2024-10-02 22:08:11 --> Router Class Initialized
INFO - 2024-10-02 22:08:11 --> Output Class Initialized
INFO - 2024-10-02 22:08:11 --> Security Class Initialized
DEBUG - 2024-10-02 22:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:08:11 --> Input Class Initialized
INFO - 2024-10-02 22:08:11 --> Language Class Initialized
INFO - 2024-10-02 22:08:11 --> Loader Class Initialized
INFO - 2024-10-02 22:08:11 --> Helper loaded: url_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: file_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: security_helper
INFO - 2024-10-02 22:08:11 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:08:11 --> Database Driver Class Initialized
INFO - 2024-10-02 22:08:12 --> Email Class Initialized
DEBUG - 2024-10-02 22:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:08:12 --> Helper loaded: form_helper
INFO - 2024-10-02 22:08:12 --> Form Validation Class Initialized
INFO - 2024-10-02 22:08:12 --> Controller Class Initialized
INFO - 2024-10-02 22:08:12 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:08:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:08:12 --> Final output sent to browser
DEBUG - 2024-10-02 22:08:12 --> Total execution time: 0.5188
INFO - 2024-10-02 22:12:10 --> Config Class Initialized
INFO - 2024-10-02 22:12:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:12:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:12:10 --> Utf8 Class Initialized
INFO - 2024-10-02 22:12:10 --> URI Class Initialized
INFO - 2024-10-02 22:12:10 --> Router Class Initialized
INFO - 2024-10-02 22:12:10 --> Output Class Initialized
INFO - 2024-10-02 22:12:10 --> Security Class Initialized
DEBUG - 2024-10-02 22:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:12:10 --> Input Class Initialized
INFO - 2024-10-02 22:12:10 --> Language Class Initialized
INFO - 2024-10-02 22:12:10 --> Loader Class Initialized
INFO - 2024-10-02 22:12:10 --> Helper loaded: url_helper
INFO - 2024-10-02 22:12:10 --> Helper loaded: file_helper
INFO - 2024-10-02 22:12:10 --> Helper loaded: security_helper
INFO - 2024-10-02 22:12:10 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:12:10 --> Database Driver Class Initialized
INFO - 2024-10-02 22:12:11 --> Email Class Initialized
DEBUG - 2024-10-02 22:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:12:11 --> Helper loaded: form_helper
INFO - 2024-10-02 22:12:11 --> Form Validation Class Initialized
INFO - 2024-10-02 22:12:11 --> Controller Class Initialized
INFO - 2024-10-02 22:12:11 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:12:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:12:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:12:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:12:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 22:12:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:12:11 --> Final output sent to browser
DEBUG - 2024-10-02 22:12:11 --> Total execution time: 0.5358
INFO - 2024-10-02 22:14:52 --> Config Class Initialized
INFO - 2024-10-02 22:14:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:14:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:14:52 --> Utf8 Class Initialized
INFO - 2024-10-02 22:14:52 --> URI Class Initialized
DEBUG - 2024-10-02 22:14:52 --> No URI present. Default controller set.
INFO - 2024-10-02 22:14:52 --> Router Class Initialized
INFO - 2024-10-02 22:14:52 --> Output Class Initialized
INFO - 2024-10-02 22:14:52 --> Security Class Initialized
DEBUG - 2024-10-02 22:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:14:52 --> Input Class Initialized
INFO - 2024-10-02 22:14:52 --> Language Class Initialized
INFO - 2024-10-02 22:14:52 --> Loader Class Initialized
INFO - 2024-10-02 22:14:52 --> Helper loaded: url_helper
INFO - 2024-10-02 22:14:52 --> Helper loaded: file_helper
INFO - 2024-10-02 22:14:52 --> Helper loaded: security_helper
INFO - 2024-10-02 22:14:52 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:14:52 --> Database Driver Class Initialized
INFO - 2024-10-02 22:14:52 --> Email Class Initialized
DEBUG - 2024-10-02 22:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:14:52 --> Helper loaded: form_helper
INFO - 2024-10-02 22:14:52 --> Form Validation Class Initialized
INFO - 2024-10-02 22:14:52 --> Controller Class Initialized
DEBUG - 2024-10-02 22:14:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:14:52 --> Config Class Initialized
INFO - 2024-10-02 22:14:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:14:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:14:52 --> Utf8 Class Initialized
INFO - 2024-10-02 22:14:52 --> URI Class Initialized
INFO - 2024-10-02 22:14:52 --> Router Class Initialized
INFO - 2024-10-02 22:14:52 --> Output Class Initialized
INFO - 2024-10-02 22:14:52 --> Security Class Initialized
DEBUG - 2024-10-02 22:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:14:52 --> Input Class Initialized
INFO - 2024-10-02 22:14:52 --> Language Class Initialized
ERROR - 2024-10-02 22:14:52 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:14:58 --> Config Class Initialized
INFO - 2024-10-02 22:14:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:14:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:14:58 --> Utf8 Class Initialized
INFO - 2024-10-02 22:14:58 --> URI Class Initialized
DEBUG - 2024-10-02 22:14:58 --> No URI present. Default controller set.
INFO - 2024-10-02 22:14:58 --> Router Class Initialized
INFO - 2024-10-02 22:14:58 --> Output Class Initialized
INFO - 2024-10-02 22:14:58 --> Security Class Initialized
DEBUG - 2024-10-02 22:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:14:58 --> Input Class Initialized
INFO - 2024-10-02 22:14:58 --> Language Class Initialized
INFO - 2024-10-02 22:14:58 --> Loader Class Initialized
INFO - 2024-10-02 22:14:58 --> Helper loaded: url_helper
INFO - 2024-10-02 22:14:58 --> Helper loaded: file_helper
INFO - 2024-10-02 22:14:58 --> Helper loaded: security_helper
INFO - 2024-10-02 22:14:58 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:14:58 --> Database Driver Class Initialized
INFO - 2024-10-02 22:14:58 --> Email Class Initialized
DEBUG - 2024-10-02 22:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:14:58 --> Helper loaded: form_helper
INFO - 2024-10-02 22:14:58 --> Form Validation Class Initialized
INFO - 2024-10-02 22:14:58 --> Controller Class Initialized
DEBUG - 2024-10-02 22:14:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:14:58 --> Config Class Initialized
INFO - 2024-10-02 22:14:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:14:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:14:58 --> Utf8 Class Initialized
INFO - 2024-10-02 22:14:58 --> URI Class Initialized
INFO - 2024-10-02 22:14:58 --> Router Class Initialized
INFO - 2024-10-02 22:14:58 --> Output Class Initialized
INFO - 2024-10-02 22:14:58 --> Security Class Initialized
DEBUG - 2024-10-02 22:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:14:58 --> Input Class Initialized
INFO - 2024-10-02 22:14:58 --> Language Class Initialized
ERROR - 2024-10-02 22:14:58 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:15:10 --> Config Class Initialized
INFO - 2024-10-02 22:15:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:10 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:10 --> URI Class Initialized
INFO - 2024-10-02 22:15:10 --> Router Class Initialized
INFO - 2024-10-02 22:15:10 --> Output Class Initialized
INFO - 2024-10-02 22:15:10 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:10 --> Input Class Initialized
INFO - 2024-10-02 22:15:10 --> Language Class Initialized
INFO - 2024-10-02 22:15:10 --> Loader Class Initialized
INFO - 2024-10-02 22:15:10 --> Helper loaded: url_helper
INFO - 2024-10-02 22:15:10 --> Helper loaded: file_helper
INFO - 2024-10-02 22:15:10 --> Helper loaded: security_helper
INFO - 2024-10-02 22:15:10 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:15:10 --> Database Driver Class Initialized
INFO - 2024-10-02 22:15:10 --> Email Class Initialized
DEBUG - 2024-10-02 22:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:15:10 --> Helper loaded: form_helper
INFO - 2024-10-02 22:15:10 --> Form Validation Class Initialized
INFO - 2024-10-02 22:15:10 --> Controller Class Initialized
INFO - 2024-10-02 22:15:10 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:15:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:15:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:15:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:15:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 22:15:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:15:11 --> Final output sent to browser
DEBUG - 2024-10-02 22:15:11 --> Total execution time: 0.5575
INFO - 2024-10-02 22:15:11 --> Config Class Initialized
INFO - 2024-10-02 22:15:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:11 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:11 --> URI Class Initialized
INFO - 2024-10-02 22:15:11 --> Router Class Initialized
INFO - 2024-10-02 22:15:11 --> Output Class Initialized
INFO - 2024-10-02 22:15:11 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:11 --> Input Class Initialized
INFO - 2024-10-02 22:15:11 --> Language Class Initialized
INFO - 2024-10-02 22:15:11 --> Loader Class Initialized
INFO - 2024-10-02 22:15:11 --> Helper loaded: url_helper
INFO - 2024-10-02 22:15:11 --> Helper loaded: file_helper
INFO - 2024-10-02 22:15:11 --> Helper loaded: security_helper
INFO - 2024-10-02 22:15:11 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:15:11 --> Database Driver Class Initialized
INFO - 2024-10-02 22:15:12 --> Email Class Initialized
DEBUG - 2024-10-02 22:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:15:12 --> Helper loaded: form_helper
INFO - 2024-10-02 22:15:12 --> Form Validation Class Initialized
INFO - 2024-10-02 22:15:12 --> Controller Class Initialized
INFO - 2024-10-02 22:15:12 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-02 22:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:15:12 --> Final output sent to browser
DEBUG - 2024-10-02 22:15:12 --> Total execution time: 0.5350
INFO - 2024-10-02 22:15:17 --> Config Class Initialized
INFO - 2024-10-02 22:15:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:17 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:17 --> URI Class Initialized
DEBUG - 2024-10-02 22:15:17 --> No URI present. Default controller set.
INFO - 2024-10-02 22:15:17 --> Router Class Initialized
INFO - 2024-10-02 22:15:17 --> Output Class Initialized
INFO - 2024-10-02 22:15:17 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:17 --> Input Class Initialized
INFO - 2024-10-02 22:15:17 --> Language Class Initialized
INFO - 2024-10-02 22:15:17 --> Loader Class Initialized
INFO - 2024-10-02 22:15:17 --> Helper loaded: url_helper
INFO - 2024-10-02 22:15:17 --> Helper loaded: file_helper
INFO - 2024-10-02 22:15:17 --> Helper loaded: security_helper
INFO - 2024-10-02 22:15:17 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:15:17 --> Database Driver Class Initialized
INFO - 2024-10-02 22:15:17 --> Email Class Initialized
DEBUG - 2024-10-02 22:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:15:17 --> Helper loaded: form_helper
INFO - 2024-10-02 22:15:17 --> Form Validation Class Initialized
INFO - 2024-10-02 22:15:17 --> Controller Class Initialized
DEBUG - 2024-10-02 22:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:15:17 --> Config Class Initialized
INFO - 2024-10-02 22:15:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:17 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:17 --> URI Class Initialized
INFO - 2024-10-02 22:15:17 --> Router Class Initialized
INFO - 2024-10-02 22:15:17 --> Output Class Initialized
INFO - 2024-10-02 22:15:17 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:17 --> Input Class Initialized
INFO - 2024-10-02 22:15:17 --> Language Class Initialized
ERROR - 2024-10-02 22:15:17 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:15:39 --> Config Class Initialized
INFO - 2024-10-02 22:15:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:39 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:39 --> URI Class Initialized
INFO - 2024-10-02 22:15:39 --> Router Class Initialized
INFO - 2024-10-02 22:15:39 --> Output Class Initialized
INFO - 2024-10-02 22:15:39 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:39 --> Input Class Initialized
INFO - 2024-10-02 22:15:39 --> Language Class Initialized
INFO - 2024-10-02 22:15:39 --> Loader Class Initialized
INFO - 2024-10-02 22:15:39 --> Helper loaded: url_helper
INFO - 2024-10-02 22:15:39 --> Helper loaded: file_helper
INFO - 2024-10-02 22:15:39 --> Helper loaded: security_helper
INFO - 2024-10-02 22:15:39 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:15:39 --> Database Driver Class Initialized
INFO - 2024-10-02 22:15:39 --> Email Class Initialized
DEBUG - 2024-10-02 22:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:15:39 --> Helper loaded: form_helper
INFO - 2024-10-02 22:15:39 --> Form Validation Class Initialized
INFO - 2024-10-02 22:15:39 --> Controller Class Initialized
INFO - 2024-10-02 22:15:39 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:15:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:15:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:15:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:15:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-10-02 22:15:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:15:39 --> Final output sent to browser
DEBUG - 2024-10-02 22:15:39 --> Total execution time: 0.4640
INFO - 2024-10-02 22:15:59 --> Config Class Initialized
INFO - 2024-10-02 22:15:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:15:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:15:59 --> Utf8 Class Initialized
INFO - 2024-10-02 22:15:59 --> URI Class Initialized
INFO - 2024-10-02 22:15:59 --> Router Class Initialized
INFO - 2024-10-02 22:15:59 --> Output Class Initialized
INFO - 2024-10-02 22:15:59 --> Security Class Initialized
DEBUG - 2024-10-02 22:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:15:59 --> Input Class Initialized
INFO - 2024-10-02 22:15:59 --> Language Class Initialized
INFO - 2024-10-02 22:15:59 --> Loader Class Initialized
INFO - 2024-10-02 22:15:59 --> Helper loaded: url_helper
INFO - 2024-10-02 22:15:59 --> Helper loaded: file_helper
INFO - 2024-10-02 22:15:59 --> Helper loaded: security_helper
INFO - 2024-10-02 22:15:59 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:15:59 --> Database Driver Class Initialized
INFO - 2024-10-02 22:15:59 --> Email Class Initialized
DEBUG - 2024-10-02 22:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:15:59 --> Helper loaded: form_helper
INFO - 2024-10-02 22:15:59 --> Form Validation Class Initialized
INFO - 2024-10-02 22:15:59 --> Controller Class Initialized
INFO - 2024-10-02 22:15:59 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:15:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:15:59 --> Final output sent to browser
DEBUG - 2024-10-02 22:15:59 --> Total execution time: 0.6626
INFO - 2024-10-02 22:16:04 --> Config Class Initialized
INFO - 2024-10-02 22:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:04 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:04 --> URI Class Initialized
DEBUG - 2024-10-02 22:16:04 --> No URI present. Default controller set.
INFO - 2024-10-02 22:16:04 --> Router Class Initialized
INFO - 2024-10-02 22:16:04 --> Output Class Initialized
INFO - 2024-10-02 22:16:04 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:04 --> Input Class Initialized
INFO - 2024-10-02 22:16:04 --> Language Class Initialized
INFO - 2024-10-02 22:16:04 --> Loader Class Initialized
INFO - 2024-10-02 22:16:04 --> Helper loaded: url_helper
INFO - 2024-10-02 22:16:04 --> Helper loaded: file_helper
INFO - 2024-10-02 22:16:04 --> Helper loaded: security_helper
INFO - 2024-10-02 22:16:04 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:16:04 --> Database Driver Class Initialized
INFO - 2024-10-02 22:16:04 --> Email Class Initialized
DEBUG - 2024-10-02 22:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:16:04 --> Helper loaded: form_helper
INFO - 2024-10-02 22:16:04 --> Form Validation Class Initialized
INFO - 2024-10-02 22:16:04 --> Controller Class Initialized
DEBUG - 2024-10-02 22:16:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:16:04 --> Config Class Initialized
INFO - 2024-10-02 22:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:04 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:04 --> URI Class Initialized
INFO - 2024-10-02 22:16:04 --> Router Class Initialized
INFO - 2024-10-02 22:16:04 --> Output Class Initialized
INFO - 2024-10-02 22:16:04 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:04 --> Input Class Initialized
INFO - 2024-10-02 22:16:04 --> Language Class Initialized
ERROR - 2024-10-02 22:16:04 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:16:22 --> Config Class Initialized
INFO - 2024-10-02 22:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:22 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:22 --> URI Class Initialized
INFO - 2024-10-02 22:16:22 --> Router Class Initialized
INFO - 2024-10-02 22:16:22 --> Output Class Initialized
INFO - 2024-10-02 22:16:22 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:22 --> Input Class Initialized
INFO - 2024-10-02 22:16:22 --> Language Class Initialized
INFO - 2024-10-02 22:16:22 --> Loader Class Initialized
INFO - 2024-10-02 22:16:22 --> Helper loaded: url_helper
INFO - 2024-10-02 22:16:22 --> Helper loaded: file_helper
INFO - 2024-10-02 22:16:22 --> Helper loaded: security_helper
INFO - 2024-10-02 22:16:22 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:16:22 --> Database Driver Class Initialized
INFO - 2024-10-02 22:16:23 --> Email Class Initialized
DEBUG - 2024-10-02 22:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:16:23 --> Helper loaded: form_helper
INFO - 2024-10-02 22:16:23 --> Form Validation Class Initialized
INFO - 2024-10-02 22:16:23 --> Controller Class Initialized
INFO - 2024-10-02 22:16:23 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:16:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:16:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:16:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:16:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-10-02 22:16:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:16:23 --> Final output sent to browser
DEBUG - 2024-10-02 22:16:23 --> Total execution time: 0.5307
INFO - 2024-10-02 22:16:49 --> Config Class Initialized
INFO - 2024-10-02 22:16:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:49 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:49 --> URI Class Initialized
DEBUG - 2024-10-02 22:16:49 --> No URI present. Default controller set.
INFO - 2024-10-02 22:16:49 --> Router Class Initialized
INFO - 2024-10-02 22:16:49 --> Output Class Initialized
INFO - 2024-10-02 22:16:49 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:49 --> Input Class Initialized
INFO - 2024-10-02 22:16:49 --> Language Class Initialized
INFO - 2024-10-02 22:16:49 --> Loader Class Initialized
INFO - 2024-10-02 22:16:49 --> Helper loaded: url_helper
INFO - 2024-10-02 22:16:49 --> Helper loaded: file_helper
INFO - 2024-10-02 22:16:49 --> Helper loaded: security_helper
INFO - 2024-10-02 22:16:49 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:16:49 --> Database Driver Class Initialized
INFO - 2024-10-02 22:16:49 --> Email Class Initialized
DEBUG - 2024-10-02 22:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:16:49 --> Helper loaded: form_helper
INFO - 2024-10-02 22:16:49 --> Form Validation Class Initialized
INFO - 2024-10-02 22:16:49 --> Controller Class Initialized
DEBUG - 2024-10-02 22:16:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:16:49 --> Config Class Initialized
INFO - 2024-10-02 22:16:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:49 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:49 --> URI Class Initialized
INFO - 2024-10-02 22:16:49 --> Router Class Initialized
INFO - 2024-10-02 22:16:49 --> Output Class Initialized
INFO - 2024-10-02 22:16:49 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:49 --> Input Class Initialized
INFO - 2024-10-02 22:16:49 --> Language Class Initialized
ERROR - 2024-10-02 22:16:49 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:16:55 --> Config Class Initialized
INFO - 2024-10-02 22:16:55 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:55 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:55 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:55 --> URI Class Initialized
INFO - 2024-10-02 22:16:55 --> Router Class Initialized
INFO - 2024-10-02 22:16:55 --> Output Class Initialized
INFO - 2024-10-02 22:16:55 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:55 --> Input Class Initialized
INFO - 2024-10-02 22:16:55 --> Language Class Initialized
ERROR - 2024-10-02 22:16:55 --> 404 Page Not Found: Login/index
INFO - 2024-10-02 22:16:56 --> Config Class Initialized
INFO - 2024-10-02 22:16:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:16:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:16:56 --> Utf8 Class Initialized
INFO - 2024-10-02 22:16:56 --> URI Class Initialized
INFO - 2024-10-02 22:16:56 --> Router Class Initialized
INFO - 2024-10-02 22:16:56 --> Output Class Initialized
INFO - 2024-10-02 22:16:56 --> Security Class Initialized
DEBUG - 2024-10-02 22:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:16:56 --> Input Class Initialized
INFO - 2024-10-02 22:16:56 --> Language Class Initialized
INFO - 2024-10-02 22:16:56 --> Loader Class Initialized
INFO - 2024-10-02 22:16:56 --> Helper loaded: url_helper
INFO - 2024-10-02 22:16:56 --> Helper loaded: file_helper
INFO - 2024-10-02 22:16:56 --> Helper loaded: security_helper
INFO - 2024-10-02 22:16:56 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:16:56 --> Database Driver Class Initialized
INFO - 2024-10-02 22:16:56 --> Email Class Initialized
DEBUG - 2024-10-02 22:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:16:56 --> Helper loaded: form_helper
INFO - 2024-10-02 22:16:56 --> Form Validation Class Initialized
INFO - 2024-10-02 22:16:56 --> Controller Class Initialized
INFO - 2024-10-02 22:16:56 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:16:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:17:00 --> Final output sent to browser
DEBUG - 2024-10-02 22:17:00 --> Total execution time: 3.4271
INFO - 2024-10-02 22:17:01 --> Config Class Initialized
INFO - 2024-10-02 22:17:01 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:17:01 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:17:01 --> Utf8 Class Initialized
INFO - 2024-10-02 22:17:01 --> URI Class Initialized
DEBUG - 2024-10-02 22:17:01 --> No URI present. Default controller set.
INFO - 2024-10-02 22:17:01 --> Router Class Initialized
INFO - 2024-10-02 22:17:01 --> Output Class Initialized
INFO - 2024-10-02 22:17:01 --> Security Class Initialized
DEBUG - 2024-10-02 22:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:17:01 --> Input Class Initialized
INFO - 2024-10-02 22:17:01 --> Language Class Initialized
INFO - 2024-10-02 22:17:01 --> Loader Class Initialized
INFO - 2024-10-02 22:17:01 --> Helper loaded: url_helper
INFO - 2024-10-02 22:17:01 --> Helper loaded: file_helper
INFO - 2024-10-02 22:17:01 --> Helper loaded: security_helper
INFO - 2024-10-02 22:17:01 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:17:01 --> Database Driver Class Initialized
INFO - 2024-10-02 22:17:01 --> Email Class Initialized
DEBUG - 2024-10-02 22:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:17:01 --> Helper loaded: form_helper
INFO - 2024-10-02 22:17:01 --> Form Validation Class Initialized
INFO - 2024-10-02 22:17:01 --> Controller Class Initialized
DEBUG - 2024-10-02 22:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:17:01 --> Config Class Initialized
INFO - 2024-10-02 22:17:01 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:17:01 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:17:01 --> Utf8 Class Initialized
INFO - 2024-10-02 22:17:01 --> URI Class Initialized
INFO - 2024-10-02 22:17:01 --> Router Class Initialized
INFO - 2024-10-02 22:17:01 --> Output Class Initialized
INFO - 2024-10-02 22:17:01 --> Security Class Initialized
DEBUG - 2024-10-02 22:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:17:01 --> Input Class Initialized
INFO - 2024-10-02 22:17:01 --> Language Class Initialized
ERROR - 2024-10-02 22:17:01 --> 404 Page Not Found: User/index
INFO - 2024-10-02 22:18:46 --> Config Class Initialized
INFO - 2024-10-02 22:18:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 22:18:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 22:18:46 --> Utf8 Class Initialized
INFO - 2024-10-02 22:18:46 --> URI Class Initialized
INFO - 2024-10-02 22:18:46 --> Router Class Initialized
INFO - 2024-10-02 22:18:46 --> Output Class Initialized
INFO - 2024-10-02 22:18:46 --> Security Class Initialized
DEBUG - 2024-10-02 22:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 22:18:46 --> Input Class Initialized
INFO - 2024-10-02 22:18:46 --> Language Class Initialized
INFO - 2024-10-02 22:18:46 --> Loader Class Initialized
INFO - 2024-10-02 22:18:46 --> Helper loaded: url_helper
INFO - 2024-10-02 22:18:46 --> Helper loaded: file_helper
INFO - 2024-10-02 22:18:46 --> Helper loaded: security_helper
INFO - 2024-10-02 22:18:46 --> Helper loaded: wpu_helper
INFO - 2024-10-02 22:18:46 --> Database Driver Class Initialized
INFO - 2024-10-02 22:18:46 --> Email Class Initialized
DEBUG - 2024-10-02 22:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-02 22:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 22:18:46 --> Helper loaded: form_helper
INFO - 2024-10-02 22:18:46 --> Form Validation Class Initialized
INFO - 2024-10-02 22:18:46 --> Controller Class Initialized
INFO - 2024-10-02 22:18:46 --> Model "Antrol_model" initialized
DEBUG - 2024-10-02 22:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-02 22:18:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-02 22:18:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-02 22:18:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-10-02 22:18:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-02 22:18:46 --> Final output sent to browser
DEBUG - 2024-10-02 22:18:46 --> Total execution time: 0.5183
