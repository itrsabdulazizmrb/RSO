<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-15 08:13:23 --> Config Class Initialized
INFO - 2024-11-15 08:13:23 --> Hooks Class Initialized
DEBUG - 2024-11-15 08:13:23 --> UTF-8 Support Enabled
INFO - 2024-11-15 08:13:23 --> Utf8 Class Initialized
INFO - 2024-11-15 08:13:23 --> URI Class Initialized
DEBUG - 2024-11-15 08:13:23 --> No URI present. Default controller set.
INFO - 2024-11-15 08:13:23 --> Router Class Initialized
INFO - 2024-11-15 08:13:23 --> Output Class Initialized
INFO - 2024-11-15 08:13:23 --> Security Class Initialized
DEBUG - 2024-11-15 08:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 08:13:23 --> Input Class Initialized
INFO - 2024-11-15 08:13:23 --> Language Class Initialized
INFO - 2024-11-15 08:13:23 --> Loader Class Initialized
INFO - 2024-11-15 08:13:23 --> Helper loaded: url_helper
INFO - 2024-11-15 08:13:23 --> Helper loaded: file_helper
INFO - 2024-11-15 08:13:23 --> Helper loaded: security_helper
INFO - 2024-11-15 08:13:23 --> Helper loaded: wpu_helper
INFO - 2024-11-15 08:13:23 --> Database Driver Class Initialized
INFO - 2024-11-15 08:13:24 --> Email Class Initialized
DEBUG - 2024-11-15 08:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-15 08:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 08:13:24 --> Helper loaded: form_helper
INFO - 2024-11-15 08:13:24 --> Form Validation Class Initialized
INFO - 2024-11-15 08:13:24 --> Controller Class Initialized
DEBUG - 2024-11-15 08:13:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-15 08:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-15 08:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-15 08:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-15 08:13:24 --> Final output sent to browser
DEBUG - 2024-11-15 08:13:24 --> Total execution time: 0.4362
INFO - 2024-11-15 09:46:04 --> Config Class Initialized
INFO - 2024-11-15 09:46:04 --> Hooks Class Initialized
DEBUG - 2024-11-15 09:46:04 --> UTF-8 Support Enabled
INFO - 2024-11-15 09:46:04 --> Utf8 Class Initialized
INFO - 2024-11-15 09:46:04 --> URI Class Initialized
DEBUG - 2024-11-15 09:46:04 --> No URI present. Default controller set.
INFO - 2024-11-15 09:46:04 --> Router Class Initialized
INFO - 2024-11-15 09:46:04 --> Output Class Initialized
INFO - 2024-11-15 09:46:04 --> Security Class Initialized
DEBUG - 2024-11-15 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 09:46:04 --> Input Class Initialized
INFO - 2024-11-15 09:46:04 --> Language Class Initialized
INFO - 2024-11-15 09:46:04 --> Loader Class Initialized
INFO - 2024-11-15 09:46:04 --> Helper loaded: url_helper
INFO - 2024-11-15 09:46:04 --> Helper loaded: file_helper
INFO - 2024-11-15 09:46:04 --> Helper loaded: security_helper
INFO - 2024-11-15 09:46:04 --> Helper loaded: wpu_helper
INFO - 2024-11-15 09:46:04 --> Database Driver Class Initialized
INFO - 2024-11-15 09:46:05 --> Email Class Initialized
DEBUG - 2024-11-15 09:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-15 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 09:46:05 --> Helper loaded: form_helper
INFO - 2024-11-15 09:46:05 --> Form Validation Class Initialized
INFO - 2024-11-15 09:46:05 --> Controller Class Initialized
DEBUG - 2024-11-15 09:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-15 09:46:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-15 09:46:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-15 09:46:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-15 09:46:05 --> Final output sent to browser
DEBUG - 2024-11-15 09:46:05 --> Total execution time: 0.4512
INFO - 2024-11-15 15:53:25 --> Config Class Initialized
INFO - 2024-11-15 15:53:25 --> Hooks Class Initialized
DEBUG - 2024-11-15 15:53:25 --> UTF-8 Support Enabled
INFO - 2024-11-15 15:53:25 --> Utf8 Class Initialized
INFO - 2024-11-15 15:53:25 --> URI Class Initialized
DEBUG - 2024-11-15 15:53:25 --> No URI present. Default controller set.
INFO - 2024-11-15 15:53:25 --> Router Class Initialized
INFO - 2024-11-15 15:53:25 --> Output Class Initialized
INFO - 2024-11-15 15:53:25 --> Security Class Initialized
DEBUG - 2024-11-15 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 15:53:25 --> Input Class Initialized
INFO - 2024-11-15 15:53:25 --> Language Class Initialized
INFO - 2024-11-15 15:53:25 --> Loader Class Initialized
INFO - 2024-11-15 15:53:25 --> Helper loaded: url_helper
INFO - 2024-11-15 15:53:25 --> Helper loaded: file_helper
INFO - 2024-11-15 15:53:25 --> Helper loaded: security_helper
INFO - 2024-11-15 15:53:25 --> Helper loaded: wpu_helper
INFO - 2024-11-15 15:53:25 --> Database Driver Class Initialized
INFO - 2024-11-15 15:53:25 --> Email Class Initialized
DEBUG - 2024-11-15 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-15 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 15:53:25 --> Helper loaded: form_helper
INFO - 2024-11-15 15:53:25 --> Form Validation Class Initialized
INFO - 2024-11-15 15:53:25 --> Controller Class Initialized
DEBUG - 2024-11-15 15:53:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-15 15:53:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-15 15:53:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-15 15:53:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-15 15:53:25 --> Final output sent to browser
DEBUG - 2024-11-15 15:53:25 --> Total execution time: 0.4351
INFO - 2024-11-15 20:39:13 --> Config Class Initialized
INFO - 2024-11-15 20:39:13 --> Hooks Class Initialized
DEBUG - 2024-11-15 20:39:13 --> UTF-8 Support Enabled
INFO - 2024-11-15 20:39:13 --> Utf8 Class Initialized
INFO - 2024-11-15 20:39:13 --> URI Class Initialized
DEBUG - 2024-11-15 20:39:13 --> No URI present. Default controller set.
INFO - 2024-11-15 20:39:13 --> Router Class Initialized
INFO - 2024-11-15 20:39:13 --> Output Class Initialized
INFO - 2024-11-15 20:39:13 --> Security Class Initialized
DEBUG - 2024-11-15 20:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 20:39:13 --> Input Class Initialized
INFO - 2024-11-15 20:39:13 --> Language Class Initialized
INFO - 2024-11-15 20:39:13 --> Loader Class Initialized
INFO - 2024-11-15 20:39:13 --> Helper loaded: url_helper
INFO - 2024-11-15 20:39:13 --> Helper loaded: file_helper
INFO - 2024-11-15 20:39:13 --> Helper loaded: security_helper
INFO - 2024-11-15 20:39:13 --> Helper loaded: wpu_helper
INFO - 2024-11-15 20:39:13 --> Database Driver Class Initialized
INFO - 2024-11-15 20:39:13 --> Email Class Initialized
DEBUG - 2024-11-15 20:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-15 20:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 20:39:13 --> Helper loaded: form_helper
INFO - 2024-11-15 20:39:13 --> Form Validation Class Initialized
INFO - 2024-11-15 20:39:13 --> Controller Class Initialized
DEBUG - 2024-11-15 20:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-15 20:39:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-15 20:39:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-15 20:39:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-15 20:39:13 --> Final output sent to browser
DEBUG - 2024-11-15 20:39:13 --> Total execution time: 0.4086
