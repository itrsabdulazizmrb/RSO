<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-27 04:26:19 --> 404 Page Not Found: Admin/URL_API_ANDA
ERROR - 2023-11-27 05:27:58 --> 404 Page Not Found: Admin/admin
ERROR - 2023-11-27 05:27:59 --> 404 Page Not Found: Admin/admin
ERROR - 2023-11-27 05:27:59 --> 404 Page Not Found: Admin/admin
ERROR - 2023-11-27 05:28:09 --> 404 Page Not Found: Admin/admin
ERROR - 2023-11-27 05:28:40 --> Severity: error --> Exception: Call to a member function get_faktur_by_no() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 666
ERROR - 2023-11-27 05:28:42 --> Severity: error --> Exception: Call to a member function get_faktur_by_no() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 666
ERROR - 2023-11-27 05:54:59 --> Severity: error --> Exception: Call to a member function update_total_terbayar() on null C:\xampp\htdocs\simba\application\models\Faktur_model.php 146
ERROR - 2023-11-27 05:55:01 --> Severity: error --> Exception: Call to a member function update_total_terbayar() on null C:\xampp\htdocs\simba\application\models\Faktur_model.php 146
ERROR - 2023-11-27 05:56:11 --> Severity: error --> Exception: Call to a member function update_total_terbayar() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 681
ERROR - 2023-11-27 06:01:29 --> Severity: error --> Exception: Call to undefined method Faktur_model::get_faktur_by_no() C:\xampp\htdocs\simba\application\controllers\Admin.php 666
ERROR - 2023-11-27 06:01:32 --> Severity: error --> Exception: Call to undefined method Faktur_model::get_faktur_by_no() C:\xampp\htdocs\simba\application\controllers\Admin.php 666
