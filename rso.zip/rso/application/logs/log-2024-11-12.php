<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-12 08:17:29 --> Config Class Initialized
INFO - 2024-11-12 08:17:29 --> Hooks Class Initialized
DEBUG - 2024-11-12 08:17:29 --> UTF-8 Support Enabled
INFO - 2024-11-12 08:17:29 --> Utf8 Class Initialized
INFO - 2024-11-12 08:17:29 --> URI Class Initialized
DEBUG - 2024-11-12 08:17:29 --> No URI present. Default controller set.
INFO - 2024-11-12 08:17:29 --> Router Class Initialized
INFO - 2024-11-12 08:17:29 --> Output Class Initialized
INFO - 2024-11-12 08:17:29 --> Security Class Initialized
DEBUG - 2024-11-12 08:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 08:17:29 --> Input Class Initialized
INFO - 2024-11-12 08:17:29 --> Language Class Initialized
INFO - 2024-11-12 08:17:29 --> Loader Class Initialized
INFO - 2024-11-12 08:17:29 --> Helper loaded: url_helper
INFO - 2024-11-12 08:17:29 --> Helper loaded: file_helper
INFO - 2024-11-12 08:17:29 --> Helper loaded: security_helper
INFO - 2024-11-12 08:17:29 --> Helper loaded: wpu_helper
INFO - 2024-11-12 08:17:29 --> Database Driver Class Initialized
INFO - 2024-11-12 08:17:29 --> Email Class Initialized
DEBUG - 2024-11-12 08:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-12 08:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 08:17:29 --> Helper loaded: form_helper
INFO - 2024-11-12 08:17:29 --> Form Validation Class Initialized
INFO - 2024-11-12 08:17:29 --> Controller Class Initialized
DEBUG - 2024-11-12 08:17:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-12 08:17:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-12 08:17:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-12 08:17:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-12 08:17:29 --> Final output sent to browser
DEBUG - 2024-11-12 08:17:29 --> Total execution time: 0.2624
INFO - 2024-11-12 18:59:57 --> Config Class Initialized
INFO - 2024-11-12 18:59:57 --> Hooks Class Initialized
DEBUG - 2024-11-12 18:59:57 --> UTF-8 Support Enabled
INFO - 2024-11-12 18:59:57 --> Utf8 Class Initialized
INFO - 2024-11-12 18:59:57 --> URI Class Initialized
INFO - 2024-11-12 18:59:57 --> Router Class Initialized
INFO - 2024-11-12 18:59:57 --> Output Class Initialized
INFO - 2024-11-12 18:59:57 --> Security Class Initialized
DEBUG - 2024-11-12 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 18:59:57 --> Input Class Initialized
INFO - 2024-11-12 18:59:57 --> Language Class Initialized
ERROR - 2024-11-12 18:59:57 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-12 18:59:57 --> Config Class Initialized
INFO - 2024-11-12 18:59:57 --> Hooks Class Initialized
DEBUG - 2024-11-12 18:59:57 --> UTF-8 Support Enabled
INFO - 2024-11-12 18:59:57 --> Utf8 Class Initialized
INFO - 2024-11-12 18:59:57 --> URI Class Initialized
DEBUG - 2024-11-12 18:59:57 --> No URI present. Default controller set.
INFO - 2024-11-12 18:59:57 --> Router Class Initialized
INFO - 2024-11-12 18:59:57 --> Output Class Initialized
INFO - 2024-11-12 18:59:57 --> Security Class Initialized
DEBUG - 2024-11-12 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 18:59:57 --> Input Class Initialized
INFO - 2024-11-12 18:59:57 --> Language Class Initialized
INFO - 2024-11-12 18:59:57 --> Loader Class Initialized
INFO - 2024-11-12 18:59:57 --> Helper loaded: url_helper
INFO - 2024-11-12 18:59:57 --> Helper loaded: file_helper
INFO - 2024-11-12 18:59:57 --> Helper loaded: security_helper
INFO - 2024-11-12 18:59:57 --> Helper loaded: wpu_helper
INFO - 2024-11-12 18:59:57 --> Database Driver Class Initialized
INFO - 2024-11-12 18:59:58 --> Email Class Initialized
DEBUG - 2024-11-12 18:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-12 18:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 18:59:58 --> Helper loaded: form_helper
INFO - 2024-11-12 18:59:58 --> Form Validation Class Initialized
INFO - 2024-11-12 18:59:58 --> Controller Class Initialized
DEBUG - 2024-11-12 18:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-12 18:59:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-12 18:59:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-12 18:59:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-12 18:59:58 --> Final output sent to browser
DEBUG - 2024-11-12 18:59:58 --> Total execution time: 0.3077
