<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-03 04:08:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\models\Faktur_model.php 86
ERROR - 2023-11-03 04:08:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\models\Faktur_model.php 86
ERROR - 2023-11-03 04:09:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\models\Faktur_model.php 86
ERROR - 2023-11-03 04:35:01 --> 404 Page Not Found: Assets/monitor.jpg
