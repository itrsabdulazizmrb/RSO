<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-03 08:28:39 --> Config Class Initialized
INFO - 2024-11-03 08:28:39 --> Hooks Class Initialized
DEBUG - 2024-11-03 08:28:39 --> UTF-8 Support Enabled
INFO - 2024-11-03 08:28:39 --> Utf8 Class Initialized
INFO - 2024-11-03 08:28:39 --> URI Class Initialized
DEBUG - 2024-11-03 08:28:39 --> No URI present. Default controller set.
INFO - 2024-11-03 08:28:39 --> Router Class Initialized
INFO - 2024-11-03 08:28:39 --> Output Class Initialized
INFO - 2024-11-03 08:28:39 --> Security Class Initialized
DEBUG - 2024-11-03 08:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 08:28:39 --> Input Class Initialized
INFO - 2024-11-03 08:28:39 --> Language Class Initialized
INFO - 2024-11-03 08:28:39 --> Loader Class Initialized
INFO - 2024-11-03 08:28:39 --> Helper loaded: url_helper
INFO - 2024-11-03 08:28:39 --> Helper loaded: file_helper
INFO - 2024-11-03 08:28:39 --> Helper loaded: security_helper
INFO - 2024-11-03 08:28:39 --> Helper loaded: wpu_helper
INFO - 2024-11-03 08:28:39 --> Database Driver Class Initialized
ERROR - 2024-11-03 08:28:46 --> Unable to connect to the database
INFO - 2024-11-03 08:28:46 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-03 22:20:15 --> Config Class Initialized
INFO - 2024-11-03 22:20:15 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:20:15 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:20:15 --> Utf8 Class Initialized
INFO - 2024-11-03 22:20:15 --> URI Class Initialized
DEBUG - 2024-11-03 22:20:15 --> No URI present. Default controller set.
INFO - 2024-11-03 22:20:15 --> Router Class Initialized
INFO - 2024-11-03 22:20:15 --> Output Class Initialized
INFO - 2024-11-03 22:20:15 --> Security Class Initialized
DEBUG - 2024-11-03 22:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:20:15 --> Input Class Initialized
INFO - 2024-11-03 22:20:15 --> Language Class Initialized
INFO - 2024-11-03 22:20:15 --> Loader Class Initialized
INFO - 2024-11-03 22:20:15 --> Helper loaded: url_helper
INFO - 2024-11-03 22:20:15 --> Helper loaded: file_helper
INFO - 2024-11-03 22:20:15 --> Helper loaded: security_helper
INFO - 2024-11-03 22:20:15 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:20:15 --> Database Driver Class Initialized
INFO - 2024-11-03 22:20:16 --> Email Class Initialized
DEBUG - 2024-11-03 22:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:20:16 --> Helper loaded: form_helper
INFO - 2024-11-03 22:20:16 --> Form Validation Class Initialized
INFO - 2024-11-03 22:20:16 --> Controller Class Initialized
DEBUG - 2024-11-03 22:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:20:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-03 22:20:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-03 22:20:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-03 22:20:16 --> Final output sent to browser
DEBUG - 2024-11-03 22:20:16 --> Total execution time: 0.4302
INFO - 2024-11-03 22:20:18 --> Config Class Initialized
INFO - 2024-11-03 22:20:18 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:20:18 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:20:18 --> Utf8 Class Initialized
INFO - 2024-11-03 22:20:18 --> URI Class Initialized
INFO - 2024-11-03 22:20:18 --> Router Class Initialized
INFO - 2024-11-03 22:20:18 --> Output Class Initialized
INFO - 2024-11-03 22:20:18 --> Security Class Initialized
DEBUG - 2024-11-03 22:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:20:18 --> Input Class Initialized
INFO - 2024-11-03 22:20:18 --> Language Class Initialized
INFO - 2024-11-03 22:20:18 --> Loader Class Initialized
INFO - 2024-11-03 22:20:18 --> Helper loaded: url_helper
INFO - 2024-11-03 22:20:18 --> Helper loaded: file_helper
INFO - 2024-11-03 22:20:18 --> Helper loaded: security_helper
INFO - 2024-11-03 22:20:18 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:20:18 --> Database Driver Class Initialized
INFO - 2024-11-03 22:20:18 --> Email Class Initialized
DEBUG - 2024-11-03 22:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:20:19 --> Helper loaded: form_helper
INFO - 2024-11-03 22:20:19 --> Form Validation Class Initialized
INFO - 2024-11-03 22:20:19 --> Controller Class Initialized
DEBUG - 2024-11-03 22:20:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:20:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-03 22:20:19 --> Config Class Initialized
INFO - 2024-11-03 22:20:19 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:20:19 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:20:19 --> Utf8 Class Initialized
INFO - 2024-11-03 22:20:19 --> URI Class Initialized
INFO - 2024-11-03 22:20:19 --> Router Class Initialized
INFO - 2024-11-03 22:20:19 --> Output Class Initialized
INFO - 2024-11-03 22:20:19 --> Security Class Initialized
DEBUG - 2024-11-03 22:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:20:19 --> Input Class Initialized
INFO - 2024-11-03 22:20:19 --> Language Class Initialized
INFO - 2024-11-03 22:20:19 --> Loader Class Initialized
INFO - 2024-11-03 22:20:19 --> Helper loaded: url_helper
INFO - 2024-11-03 22:20:19 --> Helper loaded: file_helper
INFO - 2024-11-03 22:20:19 --> Helper loaded: security_helper
INFO - 2024-11-03 22:20:19 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:20:19 --> Database Driver Class Initialized
INFO - 2024-11-03 22:20:19 --> Email Class Initialized
DEBUG - 2024-11-03 22:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:20:19 --> Helper loaded: form_helper
INFO - 2024-11-03 22:20:19 --> Form Validation Class Initialized
INFO - 2024-11-03 22:20:19 --> Controller Class Initialized
INFO - 2024-11-03 22:20:19 --> Model "Antrol_model" initialized
DEBUG - 2024-11-03 22:20:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:20:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-03 22:20:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-03 22:20:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-03 22:20:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-03 22:20:20 --> Final output sent to browser
DEBUG - 2024-11-03 22:20:20 --> Total execution time: 0.8491
INFO - 2024-11-03 22:22:21 --> Config Class Initialized
INFO - 2024-11-03 22:22:21 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:22:21 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:22:21 --> Utf8 Class Initialized
INFO - 2024-11-03 22:22:21 --> URI Class Initialized
INFO - 2024-11-03 22:22:21 --> Router Class Initialized
INFO - 2024-11-03 22:22:21 --> Output Class Initialized
INFO - 2024-11-03 22:22:21 --> Security Class Initialized
DEBUG - 2024-11-03 22:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:22:21 --> Input Class Initialized
INFO - 2024-11-03 22:22:21 --> Language Class Initialized
INFO - 2024-11-03 22:22:21 --> Loader Class Initialized
INFO - 2024-11-03 22:22:21 --> Helper loaded: url_helper
INFO - 2024-11-03 22:22:21 --> Helper loaded: file_helper
INFO - 2024-11-03 22:22:21 --> Helper loaded: security_helper
INFO - 2024-11-03 22:22:21 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:22:21 --> Database Driver Class Initialized
ERROR - 2024-11-03 22:22:28 --> Unable to connect to the database
INFO - 2024-11-03 22:22:28 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-03 22:24:53 --> Config Class Initialized
INFO - 2024-11-03 22:24:53 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:24:53 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:24:53 --> Utf8 Class Initialized
INFO - 2024-11-03 22:24:53 --> URI Class Initialized
INFO - 2024-11-03 22:24:53 --> Router Class Initialized
INFO - 2024-11-03 22:24:53 --> Output Class Initialized
INFO - 2024-11-03 22:24:53 --> Security Class Initialized
DEBUG - 2024-11-03 22:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:24:53 --> Input Class Initialized
INFO - 2024-11-03 22:24:53 --> Language Class Initialized
INFO - 2024-11-03 22:24:53 --> Loader Class Initialized
INFO - 2024-11-03 22:24:53 --> Helper loaded: url_helper
INFO - 2024-11-03 22:24:53 --> Helper loaded: file_helper
INFO - 2024-11-03 22:24:53 --> Helper loaded: security_helper
INFO - 2024-11-03 22:24:53 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:24:53 --> Database Driver Class Initialized
INFO - 2024-11-03 22:24:53 --> Email Class Initialized
DEBUG - 2024-11-03 22:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:24:53 --> Helper loaded: form_helper
INFO - 2024-11-03 22:24:53 --> Form Validation Class Initialized
INFO - 2024-11-03 22:24:53 --> Controller Class Initialized
INFO - 2024-11-03 22:24:53 --> Model "Antrol_model" initialized
DEBUG - 2024-11-03 22:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:24:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-03 22:24:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-03 22:24:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-03 22:24:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-03 22:24:54 --> Final output sent to browser
DEBUG - 2024-11-03 22:24:54 --> Total execution time: 0.8696
INFO - 2024-11-03 22:25:04 --> Config Class Initialized
INFO - 2024-11-03 22:25:04 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:25:04 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:25:04 --> Utf8 Class Initialized
INFO - 2024-11-03 22:25:04 --> URI Class Initialized
INFO - 2024-11-03 22:25:04 --> Router Class Initialized
INFO - 2024-11-03 22:25:04 --> Output Class Initialized
INFO - 2024-11-03 22:25:04 --> Security Class Initialized
DEBUG - 2024-11-03 22:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:25:04 --> Input Class Initialized
INFO - 2024-11-03 22:25:04 --> Language Class Initialized
INFO - 2024-11-03 22:25:04 --> Loader Class Initialized
INFO - 2024-11-03 22:25:04 --> Helper loaded: url_helper
INFO - 2024-11-03 22:25:04 --> Helper loaded: file_helper
INFO - 2024-11-03 22:25:04 --> Helper loaded: security_helper
INFO - 2024-11-03 22:25:04 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:25:04 --> Database Driver Class Initialized
INFO - 2024-11-03 22:25:05 --> Email Class Initialized
DEBUG - 2024-11-03 22:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:25:05 --> Helper loaded: form_helper
INFO - 2024-11-03 22:25:05 --> Form Validation Class Initialized
INFO - 2024-11-03 22:25:05 --> Controller Class Initialized
INFO - 2024-11-03 22:25:05 --> Model "Antrol_model" initialized
DEBUG - 2024-11-03 22:25:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:25:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-03 22:25:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-03 22:25:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-03 22:25:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-03 22:25:05 --> Final output sent to browser
DEBUG - 2024-11-03 22:25:05 --> Total execution time: 0.8811
INFO - 2024-11-03 22:28:20 --> Config Class Initialized
INFO - 2024-11-03 22:28:20 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:28:20 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:28:20 --> Utf8 Class Initialized
INFO - 2024-11-03 22:28:20 --> URI Class Initialized
INFO - 2024-11-03 22:28:20 --> Router Class Initialized
INFO - 2024-11-03 22:28:20 --> Output Class Initialized
INFO - 2024-11-03 22:28:20 --> Security Class Initialized
DEBUG - 2024-11-03 22:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:28:20 --> Input Class Initialized
INFO - 2024-11-03 22:28:20 --> Language Class Initialized
INFO - 2024-11-03 22:28:20 --> Loader Class Initialized
INFO - 2024-11-03 22:28:20 --> Helper loaded: url_helper
INFO - 2024-11-03 22:28:20 --> Helper loaded: file_helper
INFO - 2024-11-03 22:28:20 --> Helper loaded: security_helper
INFO - 2024-11-03 22:28:20 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:28:20 --> Database Driver Class Initialized
INFO - 2024-11-03 22:28:20 --> Email Class Initialized
DEBUG - 2024-11-03 22:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-03 22:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 22:28:20 --> Helper loaded: form_helper
INFO - 2024-11-03 22:28:20 --> Form Validation Class Initialized
INFO - 2024-11-03 22:28:20 --> Controller Class Initialized
INFO - 2024-11-03 22:28:20 --> Model "Antrol_model" initialized
DEBUG - 2024-11-03 22:28:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-03 22:28:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-03 22:28:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-03 22:28:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-03 22:28:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-03 22:28:21 --> Final output sent to browser
DEBUG - 2024-11-03 22:28:21 --> Total execution time: 0.8382
INFO - 2024-11-03 22:30:17 --> Config Class Initialized
INFO - 2024-11-03 22:30:17 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:30:17 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:30:17 --> Utf8 Class Initialized
INFO - 2024-11-03 22:30:17 --> URI Class Initialized
INFO - 2024-11-03 22:30:17 --> Router Class Initialized
INFO - 2024-11-03 22:30:17 --> Output Class Initialized
INFO - 2024-11-03 22:30:17 --> Security Class Initialized
DEBUG - 2024-11-03 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:30:17 --> Input Class Initialized
INFO - 2024-11-03 22:30:17 --> Language Class Initialized
INFO - 2024-11-03 22:30:17 --> Loader Class Initialized
INFO - 2024-11-03 22:30:17 --> Helper loaded: url_helper
INFO - 2024-11-03 22:30:17 --> Helper loaded: file_helper
INFO - 2024-11-03 22:30:17 --> Helper loaded: security_helper
INFO - 2024-11-03 22:30:17 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:30:17 --> Database Driver Class Initialized
ERROR - 2024-11-03 22:30:24 --> Unable to connect to the database
INFO - 2024-11-03 22:30:24 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-03 22:32:50 --> Config Class Initialized
INFO - 2024-11-03 22:32:50 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:32:50 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:32:50 --> Utf8 Class Initialized
INFO - 2024-11-03 22:32:50 --> URI Class Initialized
INFO - 2024-11-03 22:32:50 --> Router Class Initialized
INFO - 2024-11-03 22:32:50 --> Output Class Initialized
INFO - 2024-11-03 22:32:50 --> Security Class Initialized
DEBUG - 2024-11-03 22:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:32:50 --> Input Class Initialized
INFO - 2024-11-03 22:32:50 --> Language Class Initialized
INFO - 2024-11-03 22:32:50 --> Loader Class Initialized
INFO - 2024-11-03 22:32:50 --> Helper loaded: url_helper
INFO - 2024-11-03 22:32:50 --> Helper loaded: file_helper
INFO - 2024-11-03 22:32:50 --> Helper loaded: security_helper
INFO - 2024-11-03 22:32:50 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:32:50 --> Database Driver Class Initialized
ERROR - 2024-11-03 22:32:57 --> Unable to connect to the database
INFO - 2024-11-03 22:32:57 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-03 22:32:58 --> Config Class Initialized
INFO - 2024-11-03 22:32:58 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:32:58 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:32:58 --> Utf8 Class Initialized
INFO - 2024-11-03 22:32:58 --> URI Class Initialized
INFO - 2024-11-03 22:32:58 --> Router Class Initialized
INFO - 2024-11-03 22:32:58 --> Output Class Initialized
INFO - 2024-11-03 22:32:58 --> Security Class Initialized
DEBUG - 2024-11-03 22:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:32:58 --> Input Class Initialized
INFO - 2024-11-03 22:32:58 --> Language Class Initialized
INFO - 2024-11-03 22:32:58 --> Loader Class Initialized
INFO - 2024-11-03 22:32:58 --> Helper loaded: url_helper
INFO - 2024-11-03 22:32:58 --> Helper loaded: file_helper
INFO - 2024-11-03 22:32:58 --> Helper loaded: security_helper
INFO - 2024-11-03 22:32:58 --> Helper loaded: wpu_helper
INFO - 2024-11-03 22:32:58 --> Database Driver Class Initialized
ERROR - 2024-11-03 22:33:05 --> Unable to connect to the database
INFO - 2024-11-03 22:33:05 --> Language file loaded: language/english/db_lang.php
