<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-28 06:29:13 --> Config Class Initialized
INFO - 2024-09-28 06:29:13 --> Hooks Class Initialized
DEBUG - 2024-09-28 06:29:13 --> UTF-8 Support Enabled
INFO - 2024-09-28 06:29:13 --> Utf8 Class Initialized
INFO - 2024-09-28 06:29:13 --> URI Class Initialized
INFO - 2024-09-28 06:29:13 --> Router Class Initialized
INFO - 2024-09-28 06:29:13 --> Output Class Initialized
INFO - 2024-09-28 06:29:13 --> Security Class Initialized
DEBUG - 2024-09-28 06:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-28 06:29:13 --> Input Class Initialized
INFO - 2024-09-28 06:29:13 --> Language Class Initialized
INFO - 2024-09-28 06:29:13 --> Loader Class Initialized
INFO - 2024-09-28 06:29:13 --> Helper loaded: url_helper
INFO - 2024-09-28 06:29:13 --> Helper loaded: file_helper
INFO - 2024-09-28 06:29:13 --> Helper loaded: security_helper
INFO - 2024-09-28 06:29:13 --> Helper loaded: wpu_helper
INFO - 2024-09-28 06:29:13 --> Database Driver Class Initialized
INFO - 2024-09-28 06:29:24 --> Config Class Initialized
INFO - 2024-09-28 06:29:24 --> Hooks Class Initialized
DEBUG - 2024-09-28 06:29:24 --> UTF-8 Support Enabled
INFO - 2024-09-28 06:29:24 --> Utf8 Class Initialized
INFO - 2024-09-28 06:29:24 --> URI Class Initialized
DEBUG - 2024-09-28 06:29:24 --> No URI present. Default controller set.
INFO - 2024-09-28 06:29:24 --> Router Class Initialized
INFO - 2024-09-28 06:29:24 --> Output Class Initialized
INFO - 2024-09-28 06:29:24 --> Security Class Initialized
DEBUG - 2024-09-28 06:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-28 06:29:24 --> Input Class Initialized
INFO - 2024-09-28 06:29:24 --> Language Class Initialized
INFO - 2024-09-28 06:29:24 --> Loader Class Initialized
INFO - 2024-09-28 06:29:24 --> Helper loaded: url_helper
INFO - 2024-09-28 06:29:24 --> Helper loaded: file_helper
INFO - 2024-09-28 06:29:24 --> Helper loaded: security_helper
INFO - 2024-09-28 06:29:24 --> Helper loaded: wpu_helper
INFO - 2024-09-28 06:29:25 --> Database Driver Class Initialized
INFO - 2024-09-28 06:30:22 --> Config Class Initialized
INFO - 2024-09-28 06:30:22 --> Hooks Class Initialized
DEBUG - 2024-09-28 06:30:22 --> UTF-8 Support Enabled
INFO - 2024-09-28 06:30:22 --> Utf8 Class Initialized
INFO - 2024-09-28 06:30:22 --> URI Class Initialized
DEBUG - 2024-09-28 06:30:22 --> No URI present. Default controller set.
INFO - 2024-09-28 06:30:22 --> Router Class Initialized
INFO - 2024-09-28 06:30:22 --> Output Class Initialized
INFO - 2024-09-28 06:30:22 --> Security Class Initialized
DEBUG - 2024-09-28 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-28 06:30:22 --> Input Class Initialized
INFO - 2024-09-28 06:30:22 --> Language Class Initialized
INFO - 2024-09-28 06:30:22 --> Loader Class Initialized
INFO - 2024-09-28 06:30:22 --> Helper loaded: url_helper
INFO - 2024-09-28 06:30:22 --> Helper loaded: file_helper
INFO - 2024-09-28 06:30:22 --> Helper loaded: security_helper
INFO - 2024-09-28 06:30:22 --> Helper loaded: wpu_helper
INFO - 2024-09-28 06:30:22 --> Database Driver Class Initialized
