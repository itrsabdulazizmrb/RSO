<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-10 08:19:13 --> Config Class Initialized
INFO - 2024-11-10 08:19:13 --> Hooks Class Initialized
DEBUG - 2024-11-10 08:19:13 --> UTF-8 Support Enabled
INFO - 2024-11-10 08:19:13 --> Utf8 Class Initialized
INFO - 2024-11-10 08:19:13 --> URI Class Initialized
DEBUG - 2024-11-10 08:19:13 --> No URI present. Default controller set.
INFO - 2024-11-10 08:19:13 --> Router Class Initialized
INFO - 2024-11-10 08:19:13 --> Output Class Initialized
INFO - 2024-11-10 08:19:13 --> Security Class Initialized
DEBUG - 2024-11-10 08:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 08:19:13 --> Input Class Initialized
INFO - 2024-11-10 08:19:13 --> Language Class Initialized
INFO - 2024-11-10 08:19:13 --> Loader Class Initialized
INFO - 2024-11-10 08:19:13 --> Helper loaded: url_helper
INFO - 2024-11-10 08:19:13 --> Helper loaded: file_helper
INFO - 2024-11-10 08:19:13 --> Helper loaded: security_helper
INFO - 2024-11-10 08:19:13 --> Helper loaded: wpu_helper
INFO - 2024-11-10 08:19:13 --> Database Driver Class Initialized
INFO - 2024-11-10 22:29:49 --> Config Class Initialized
INFO - 2024-11-10 22:29:49 --> Hooks Class Initialized
DEBUG - 2024-11-10 22:29:49 --> UTF-8 Support Enabled
INFO - 2024-11-10 22:29:49 --> Utf8 Class Initialized
INFO - 2024-11-10 22:29:49 --> URI Class Initialized
DEBUG - 2024-11-10 22:29:49 --> No URI present. Default controller set.
INFO - 2024-11-10 22:29:49 --> Router Class Initialized
INFO - 2024-11-10 22:29:49 --> Output Class Initialized
INFO - 2024-11-10 22:29:49 --> Security Class Initialized
DEBUG - 2024-11-10 22:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 22:29:49 --> Input Class Initialized
INFO - 2024-11-10 22:29:49 --> Language Class Initialized
INFO - 2024-11-10 22:29:49 --> Loader Class Initialized
INFO - 2024-11-10 22:29:49 --> Helper loaded: url_helper
INFO - 2024-11-10 22:29:49 --> Helper loaded: file_helper
INFO - 2024-11-10 22:29:49 --> Helper loaded: security_helper
INFO - 2024-11-10 22:29:49 --> Helper loaded: wpu_helper
INFO - 2024-11-10 22:29:49 --> Database Driver Class Initialized
INFO - 2024-11-10 22:41:26 --> Config Class Initialized
INFO - 2024-11-10 22:41:26 --> Hooks Class Initialized
DEBUG - 2024-11-10 22:41:26 --> UTF-8 Support Enabled
INFO - 2024-11-10 22:41:26 --> Utf8 Class Initialized
INFO - 2024-11-10 22:41:26 --> URI Class Initialized
DEBUG - 2024-11-10 22:41:26 --> No URI present. Default controller set.
INFO - 2024-11-10 22:41:26 --> Router Class Initialized
INFO - 2024-11-10 22:41:26 --> Output Class Initialized
INFO - 2024-11-10 22:41:26 --> Security Class Initialized
DEBUG - 2024-11-10 22:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 22:41:26 --> Input Class Initialized
INFO - 2024-11-10 22:41:26 --> Language Class Initialized
INFO - 2024-11-10 22:41:26 --> Loader Class Initialized
INFO - 2024-11-10 22:41:26 --> Helper loaded: url_helper
INFO - 2024-11-10 22:41:26 --> Helper loaded: file_helper
INFO - 2024-11-10 22:41:26 --> Helper loaded: security_helper
INFO - 2024-11-10 22:41:26 --> Helper loaded: wpu_helper
INFO - 2024-11-10 22:41:26 --> Database Driver Class Initialized
INFO - 2024-11-10 22:41:26 --> Email Class Initialized
DEBUG - 2024-11-10 22:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-10 22:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-10 22:41:26 --> Helper loaded: form_helper
INFO - 2024-11-10 22:41:26 --> Form Validation Class Initialized
INFO - 2024-11-10 22:41:26 --> Controller Class Initialized
DEBUG - 2024-11-10 22:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-10 22:41:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-10 22:41:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-10 22:41:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-10 22:41:26 --> Final output sent to browser
DEBUG - 2024-11-10 22:41:26 --> Total execution time: 0.2709
INFO - 2024-11-10 22:41:31 --> Config Class Initialized
INFO - 2024-11-10 22:41:31 --> Hooks Class Initialized
DEBUG - 2024-11-10 22:41:31 --> UTF-8 Support Enabled
INFO - 2024-11-10 22:41:31 --> Utf8 Class Initialized
INFO - 2024-11-10 22:41:31 --> URI Class Initialized
INFO - 2024-11-10 22:41:31 --> Router Class Initialized
INFO - 2024-11-10 22:41:31 --> Output Class Initialized
INFO - 2024-11-10 22:41:31 --> Security Class Initialized
DEBUG - 2024-11-10 22:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 22:41:31 --> Input Class Initialized
INFO - 2024-11-10 22:41:31 --> Language Class Initialized
INFO - 2024-11-10 22:41:31 --> Loader Class Initialized
INFO - 2024-11-10 22:41:31 --> Helper loaded: url_helper
INFO - 2024-11-10 22:41:31 --> Helper loaded: file_helper
INFO - 2024-11-10 22:41:31 --> Helper loaded: security_helper
INFO - 2024-11-10 22:41:31 --> Helper loaded: wpu_helper
INFO - 2024-11-10 22:41:31 --> Database Driver Class Initialized
INFO - 2024-11-10 22:41:31 --> Email Class Initialized
DEBUG - 2024-11-10 22:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-10 22:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-10 22:41:31 --> Helper loaded: form_helper
INFO - 2024-11-10 22:41:31 --> Form Validation Class Initialized
INFO - 2024-11-10 22:41:31 --> Controller Class Initialized
DEBUG - 2024-11-10 22:41:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-10 22:41:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-10 22:41:32 --> Config Class Initialized
INFO - 2024-11-10 22:41:32 --> Hooks Class Initialized
DEBUG - 2024-11-10 22:41:32 --> UTF-8 Support Enabled
INFO - 2024-11-10 22:41:32 --> Utf8 Class Initialized
INFO - 2024-11-10 22:41:32 --> URI Class Initialized
INFO - 2024-11-10 22:41:32 --> Router Class Initialized
INFO - 2024-11-10 22:41:32 --> Output Class Initialized
INFO - 2024-11-10 22:41:32 --> Security Class Initialized
DEBUG - 2024-11-10 22:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 22:41:32 --> Input Class Initialized
INFO - 2024-11-10 22:41:32 --> Language Class Initialized
INFO - 2024-11-10 22:41:32 --> Loader Class Initialized
INFO - 2024-11-10 22:41:32 --> Helper loaded: url_helper
INFO - 2024-11-10 22:41:32 --> Helper loaded: file_helper
INFO - 2024-11-10 22:41:32 --> Helper loaded: security_helper
INFO - 2024-11-10 22:41:32 --> Helper loaded: wpu_helper
INFO - 2024-11-10 22:41:32 --> Database Driver Class Initialized
INFO - 2024-11-10 22:41:32 --> Email Class Initialized
DEBUG - 2024-11-10 22:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-10 22:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-10 22:41:32 --> Helper loaded: form_helper
INFO - 2024-11-10 22:41:32 --> Form Validation Class Initialized
INFO - 2024-11-10 22:41:32 --> Controller Class Initialized
INFO - 2024-11-10 22:41:32 --> Model "Antrol_model" initialized
DEBUG - 2024-11-10 22:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-10 22:41:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-10 22:41:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-10 22:41:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-10 22:41:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-10 22:41:32 --> Final output sent to browser
DEBUG - 2024-11-10 22:41:32 --> Total execution time: 0.6465
