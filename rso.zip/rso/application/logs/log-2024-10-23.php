<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-23 00:04:04 --> Config Class Initialized
INFO - 2024-10-23 00:04:04 --> Hooks Class Initialized
DEBUG - 2024-10-23 00:04:04 --> UTF-8 Support Enabled
INFO - 2024-10-23 00:04:04 --> Utf8 Class Initialized
INFO - 2024-10-23 00:04:04 --> URI Class Initialized
DEBUG - 2024-10-23 00:04:04 --> No URI present. Default controller set.
INFO - 2024-10-23 00:04:04 --> Router Class Initialized
INFO - 2024-10-23 00:04:04 --> Output Class Initialized
INFO - 2024-10-23 00:04:04 --> Security Class Initialized
DEBUG - 2024-10-23 00:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 00:04:04 --> Input Class Initialized
INFO - 2024-10-23 00:04:04 --> Language Class Initialized
INFO - 2024-10-23 00:04:04 --> Loader Class Initialized
INFO - 2024-10-23 00:04:04 --> Helper loaded: url_helper
INFO - 2024-10-23 00:04:04 --> Helper loaded: file_helper
INFO - 2024-10-23 00:04:04 --> Helper loaded: security_helper
INFO - 2024-10-23 00:04:04 --> Helper loaded: wpu_helper
INFO - 2024-10-23 00:04:04 --> Database Driver Class Initialized
ERROR - 2024-10-23 00:04:07 --> Unable to connect to the database
INFO - 2024-10-23 00:04:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-23 08:45:16 --> Config Class Initialized
INFO - 2024-10-23 08:45:16 --> Hooks Class Initialized
DEBUG - 2024-10-23 08:45:16 --> UTF-8 Support Enabled
INFO - 2024-10-23 08:45:16 --> Utf8 Class Initialized
INFO - 2024-10-23 08:45:16 --> URI Class Initialized
DEBUG - 2024-10-23 08:45:16 --> No URI present. Default controller set.
INFO - 2024-10-23 08:45:16 --> Router Class Initialized
INFO - 2024-10-23 08:45:16 --> Output Class Initialized
INFO - 2024-10-23 08:45:16 --> Security Class Initialized
DEBUG - 2024-10-23 08:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 08:45:16 --> Input Class Initialized
INFO - 2024-10-23 08:45:16 --> Language Class Initialized
INFO - 2024-10-23 08:45:16 --> Loader Class Initialized
INFO - 2024-10-23 08:45:16 --> Helper loaded: url_helper
INFO - 2024-10-23 08:45:16 --> Helper loaded: file_helper
INFO - 2024-10-23 08:45:16 --> Helper loaded: security_helper
INFO - 2024-10-23 08:45:16 --> Helper loaded: wpu_helper
INFO - 2024-10-23 08:45:16 --> Database Driver Class Initialized
ERROR - 2024-10-23 08:45:19 --> Unable to connect to the database
INFO - 2024-10-23 08:45:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-23 10:58:38 --> Config Class Initialized
INFO - 2024-10-23 10:58:38 --> Hooks Class Initialized
DEBUG - 2024-10-23 10:58:38 --> UTF-8 Support Enabled
INFO - 2024-10-23 10:58:38 --> Utf8 Class Initialized
INFO - 2024-10-23 10:58:38 --> URI Class Initialized
INFO - 2024-10-23 10:58:38 --> Router Class Initialized
INFO - 2024-10-23 10:58:38 --> Output Class Initialized
INFO - 2024-10-23 10:58:38 --> Security Class Initialized
DEBUG - 2024-10-23 10:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 10:58:38 --> Input Class Initialized
INFO - 2024-10-23 10:58:38 --> Language Class Initialized
ERROR - 2024-10-23 10:58:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 10:58:39 --> Config Class Initialized
INFO - 2024-10-23 10:58:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 10:58:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 10:58:39 --> Utf8 Class Initialized
INFO - 2024-10-23 10:58:39 --> URI Class Initialized
INFO - 2024-10-23 10:58:39 --> Router Class Initialized
INFO - 2024-10-23 10:58:39 --> Output Class Initialized
INFO - 2024-10-23 10:58:39 --> Security Class Initialized
DEBUG - 2024-10-23 10:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 10:58:39 --> Input Class Initialized
INFO - 2024-10-23 10:58:39 --> Language Class Initialized
ERROR - 2024-10-23 10:58:39 --> 404 Page Not Found: Well-known/index.php
INFO - 2024-10-23 11:44:42 --> Config Class Initialized
INFO - 2024-10-23 11:44:42 --> Hooks Class Initialized
DEBUG - 2024-10-23 11:44:42 --> UTF-8 Support Enabled
INFO - 2024-10-23 11:44:42 --> Utf8 Class Initialized
INFO - 2024-10-23 11:44:42 --> URI Class Initialized
DEBUG - 2024-10-23 11:44:42 --> No URI present. Default controller set.
INFO - 2024-10-23 11:44:42 --> Router Class Initialized
INFO - 2024-10-23 11:44:42 --> Output Class Initialized
INFO - 2024-10-23 11:44:42 --> Security Class Initialized
DEBUG - 2024-10-23 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 11:44:42 --> Input Class Initialized
INFO - 2024-10-23 11:44:42 --> Language Class Initialized
INFO - 2024-10-23 11:44:42 --> Loader Class Initialized
INFO - 2024-10-23 11:44:42 --> Helper loaded: url_helper
INFO - 2024-10-23 11:44:42 --> Helper loaded: file_helper
INFO - 2024-10-23 11:44:42 --> Helper loaded: security_helper
INFO - 2024-10-23 11:44:42 --> Helper loaded: wpu_helper
INFO - 2024-10-23 11:44:42 --> Database Driver Class Initialized
ERROR - 2024-10-23 11:44:43 --> Unable to connect to the database
INFO - 2024-10-23 11:44:43 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-23 11:44:44 --> Config Class Initialized
INFO - 2024-10-23 11:44:44 --> Hooks Class Initialized
DEBUG - 2024-10-23 11:44:44 --> UTF-8 Support Enabled
INFO - 2024-10-23 11:44:44 --> Utf8 Class Initialized
INFO - 2024-10-23 11:44:44 --> URI Class Initialized
DEBUG - 2024-10-23 11:44:44 --> No URI present. Default controller set.
INFO - 2024-10-23 11:44:44 --> Router Class Initialized
INFO - 2024-10-23 11:44:44 --> Output Class Initialized
INFO - 2024-10-23 11:44:44 --> Security Class Initialized
DEBUG - 2024-10-23 11:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 11:44:44 --> Input Class Initialized
INFO - 2024-10-23 11:44:44 --> Language Class Initialized
INFO - 2024-10-23 11:44:44 --> Loader Class Initialized
INFO - 2024-10-23 11:44:44 --> Helper loaded: url_helper
INFO - 2024-10-23 11:44:44 --> Helper loaded: file_helper
INFO - 2024-10-23 11:44:44 --> Helper loaded: security_helper
INFO - 2024-10-23 11:44:44 --> Helper loaded: wpu_helper
INFO - 2024-10-23 11:44:44 --> Database Driver Class Initialized
ERROR - 2024-10-23 11:44:47 --> Unable to connect to the database
INFO - 2024-10-23 11:44:47 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-23 16:07:22 --> Config Class Initialized
INFO - 2024-10-23 16:07:22 --> Hooks Class Initialized
DEBUG - 2024-10-23 16:07:22 --> UTF-8 Support Enabled
INFO - 2024-10-23 16:07:22 --> Utf8 Class Initialized
INFO - 2024-10-23 16:07:22 --> URI Class Initialized
INFO - 2024-10-23 16:07:22 --> Router Class Initialized
INFO - 2024-10-23 16:07:22 --> Output Class Initialized
INFO - 2024-10-23 16:07:22 --> Security Class Initialized
DEBUG - 2024-10-23 16:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 16:07:22 --> Input Class Initialized
INFO - 2024-10-23 16:07:22 --> Language Class Initialized
ERROR - 2024-10-23 16:07:22 --> 404 Page Not Found: Well-known/ya.php
INFO - 2024-10-23 16:57:20 --> Config Class Initialized
INFO - 2024-10-23 16:57:20 --> Hooks Class Initialized
DEBUG - 2024-10-23 16:57:20 --> UTF-8 Support Enabled
INFO - 2024-10-23 16:57:20 --> Utf8 Class Initialized
INFO - 2024-10-23 16:57:20 --> URI Class Initialized
INFO - 2024-10-23 16:57:20 --> Router Class Initialized
INFO - 2024-10-23 16:57:20 --> Output Class Initialized
INFO - 2024-10-23 16:57:20 --> Security Class Initialized
DEBUG - 2024-10-23 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 16:57:20 --> Input Class Initialized
INFO - 2024-10-23 16:57:20 --> Language Class Initialized
ERROR - 2024-10-23 16:57:20 --> 404 Page Not Found: Well-known/t.php
