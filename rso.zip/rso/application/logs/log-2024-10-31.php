<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-31 08:36:02 --> Config Class Initialized
INFO - 2024-10-31 08:36:02 --> Hooks Class Initialized
DEBUG - 2024-10-31 08:36:02 --> UTF-8 Support Enabled
INFO - 2024-10-31 08:36:02 --> Utf8 Class Initialized
INFO - 2024-10-31 08:36:02 --> URI Class Initialized
DEBUG - 2024-10-31 08:36:02 --> No URI present. Default controller set.
INFO - 2024-10-31 08:36:02 --> Router Class Initialized
INFO - 2024-10-31 08:36:02 --> Output Class Initialized
INFO - 2024-10-31 08:36:02 --> Security Class Initialized
DEBUG - 2024-10-31 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 08:36:02 --> Input Class Initialized
INFO - 2024-10-31 08:36:02 --> Language Class Initialized
INFO - 2024-10-31 08:36:02 --> Loader Class Initialized
INFO - 2024-10-31 08:36:02 --> Helper loaded: url_helper
INFO - 2024-10-31 08:36:02 --> Helper loaded: file_helper
INFO - 2024-10-31 08:36:02 --> Helper loaded: security_helper
INFO - 2024-10-31 08:36:02 --> Helper loaded: wpu_helper
INFO - 2024-10-31 08:36:02 --> Database Driver Class Initialized
ERROR - 2024-10-31 08:36:09 --> Unable to connect to the database
INFO - 2024-10-31 08:36:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-31 13:22:47 --> Config Class Initialized
INFO - 2024-10-31 13:22:47 --> Hooks Class Initialized
DEBUG - 2024-10-31 13:22:47 --> UTF-8 Support Enabled
INFO - 2024-10-31 13:22:47 --> Utf8 Class Initialized
INFO - 2024-10-31 13:22:47 --> URI Class Initialized
DEBUG - 2024-10-31 13:22:47 --> No URI present. Default controller set.
INFO - 2024-10-31 13:22:47 --> Router Class Initialized
INFO - 2024-10-31 13:22:47 --> Output Class Initialized
INFO - 2024-10-31 13:22:47 --> Security Class Initialized
DEBUG - 2024-10-31 13:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 13:22:47 --> Input Class Initialized
INFO - 2024-10-31 13:22:47 --> Language Class Initialized
INFO - 2024-10-31 13:22:47 --> Loader Class Initialized
INFO - 2024-10-31 13:22:47 --> Helper loaded: url_helper
INFO - 2024-10-31 13:22:47 --> Helper loaded: file_helper
INFO - 2024-10-31 13:22:47 --> Helper loaded: security_helper
INFO - 2024-10-31 13:22:47 --> Helper loaded: wpu_helper
INFO - 2024-10-31 13:22:47 --> Database Driver Class Initialized
ERROR - 2024-10-31 13:22:54 --> Unable to connect to the database
INFO - 2024-10-31 13:22:54 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-31 22:46:13 --> Config Class Initialized
INFO - 2024-10-31 22:46:13 --> Hooks Class Initialized
DEBUG - 2024-10-31 22:46:13 --> UTF-8 Support Enabled
INFO - 2024-10-31 22:46:13 --> Utf8 Class Initialized
INFO - 2024-10-31 22:46:13 --> URI Class Initialized
DEBUG - 2024-10-31 22:46:13 --> No URI present. Default controller set.
INFO - 2024-10-31 22:46:13 --> Router Class Initialized
INFO - 2024-10-31 22:46:13 --> Output Class Initialized
INFO - 2024-10-31 22:46:13 --> Security Class Initialized
DEBUG - 2024-10-31 22:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 22:46:13 --> Input Class Initialized
INFO - 2024-10-31 22:46:13 --> Language Class Initialized
INFO - 2024-10-31 22:46:13 --> Loader Class Initialized
INFO - 2024-10-31 22:46:13 --> Helper loaded: url_helper
INFO - 2024-10-31 22:46:13 --> Helper loaded: file_helper
INFO - 2024-10-31 22:46:13 --> Helper loaded: security_helper
INFO - 2024-10-31 22:46:13 --> Helper loaded: wpu_helper
INFO - 2024-10-31 22:46:13 --> Database Driver Class Initialized
ERROR - 2024-10-31 22:46:20 --> Unable to connect to the database
INFO - 2024-10-31 22:46:20 --> Language file loaded: language/english/db_lang.php
