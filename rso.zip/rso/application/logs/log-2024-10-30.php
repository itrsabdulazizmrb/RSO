<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-30 04:11:04 --> Config Class Initialized
INFO - 2024-10-30 04:11:04 --> Hooks Class Initialized
DEBUG - 2024-10-30 04:11:04 --> UTF-8 Support Enabled
INFO - 2024-10-30 04:11:04 --> Utf8 Class Initialized
INFO - 2024-10-30 04:11:04 --> URI Class Initialized
DEBUG - 2024-10-30 04:11:04 --> No URI present. Default controller set.
INFO - 2024-10-30 04:11:04 --> Router Class Initialized
INFO - 2024-10-30 04:11:04 --> Output Class Initialized
INFO - 2024-10-30 04:11:04 --> Security Class Initialized
DEBUG - 2024-10-30 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 04:11:04 --> Input Class Initialized
INFO - 2024-10-30 04:11:04 --> Language Class Initialized
INFO - 2024-10-30 04:11:04 --> Loader Class Initialized
INFO - 2024-10-30 04:11:04 --> Helper loaded: url_helper
INFO - 2024-10-30 04:11:04 --> Helper loaded: file_helper
INFO - 2024-10-30 04:11:04 --> Helper loaded: security_helper
INFO - 2024-10-30 04:11:04 --> Helper loaded: wpu_helper
INFO - 2024-10-30 04:11:04 --> Database Driver Class Initialized
INFO - 2024-10-30 04:14:34 --> Config Class Initialized
INFO - 2024-10-30 04:14:34 --> Hooks Class Initialized
DEBUG - 2024-10-30 04:14:34 --> UTF-8 Support Enabled
INFO - 2024-10-30 04:14:34 --> Utf8 Class Initialized
INFO - 2024-10-30 04:14:34 --> URI Class Initialized
DEBUG - 2024-10-30 04:14:34 --> No URI present. Default controller set.
INFO - 2024-10-30 04:14:34 --> Router Class Initialized
INFO - 2024-10-30 04:14:34 --> Output Class Initialized
INFO - 2024-10-30 04:14:34 --> Security Class Initialized
DEBUG - 2024-10-30 04:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 04:14:34 --> Input Class Initialized
INFO - 2024-10-30 04:14:34 --> Language Class Initialized
INFO - 2024-10-30 04:14:34 --> Loader Class Initialized
INFO - 2024-10-30 04:14:34 --> Helper loaded: url_helper
INFO - 2024-10-30 04:14:34 --> Helper loaded: file_helper
INFO - 2024-10-30 04:14:34 --> Helper loaded: security_helper
INFO - 2024-10-30 04:14:34 --> Helper loaded: wpu_helper
INFO - 2024-10-30 04:14:34 --> Database Driver Class Initialized
ERROR - 2024-10-30 04:14:41 --> Unable to connect to the database
INFO - 2024-10-30 04:14:41 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-30 04:14:59 --> Config Class Initialized
INFO - 2024-10-30 04:14:59 --> Hooks Class Initialized
DEBUG - 2024-10-30 04:14:59 --> UTF-8 Support Enabled
INFO - 2024-10-30 04:14:59 --> Utf8 Class Initialized
INFO - 2024-10-30 04:14:59 --> URI Class Initialized
DEBUG - 2024-10-30 04:14:59 --> No URI present. Default controller set.
INFO - 2024-10-30 04:14:59 --> Router Class Initialized
INFO - 2024-10-30 04:14:59 --> Output Class Initialized
INFO - 2024-10-30 04:14:59 --> Security Class Initialized
DEBUG - 2024-10-30 04:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 04:14:59 --> Input Class Initialized
INFO - 2024-10-30 04:14:59 --> Language Class Initialized
INFO - 2024-10-30 04:14:59 --> Loader Class Initialized
INFO - 2024-10-30 04:14:59 --> Helper loaded: url_helper
INFO - 2024-10-30 04:14:59 --> Helper loaded: file_helper
INFO - 2024-10-30 04:14:59 --> Helper loaded: security_helper
INFO - 2024-10-30 04:14:59 --> Helper loaded: wpu_helper
INFO - 2024-10-30 04:14:59 --> Database Driver Class Initialized
INFO - 2024-10-30 04:16:19 --> Config Class Initialized
INFO - 2024-10-30 04:16:19 --> Hooks Class Initialized
DEBUG - 2024-10-30 04:16:19 --> UTF-8 Support Enabled
INFO - 2024-10-30 04:16:19 --> Utf8 Class Initialized
INFO - 2024-10-30 04:16:19 --> URI Class Initialized
DEBUG - 2024-10-30 04:16:19 --> No URI present. Default controller set.
INFO - 2024-10-30 04:16:19 --> Router Class Initialized
INFO - 2024-10-30 04:16:19 --> Output Class Initialized
INFO - 2024-10-30 04:16:19 --> Security Class Initialized
DEBUG - 2024-10-30 04:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 04:16:19 --> Input Class Initialized
INFO - 2024-10-30 04:16:19 --> Language Class Initialized
INFO - 2024-10-30 04:16:19 --> Loader Class Initialized
INFO - 2024-10-30 04:16:19 --> Helper loaded: url_helper
INFO - 2024-10-30 04:16:19 --> Helper loaded: file_helper
INFO - 2024-10-30 04:16:19 --> Helper loaded: security_helper
INFO - 2024-10-30 04:16:19 --> Helper loaded: wpu_helper
INFO - 2024-10-30 04:16:19 --> Database Driver Class Initialized
INFO - 2024-10-30 08:34:34 --> Config Class Initialized
INFO - 2024-10-30 08:34:34 --> Hooks Class Initialized
DEBUG - 2024-10-30 08:34:34 --> UTF-8 Support Enabled
INFO - 2024-10-30 08:34:34 --> Utf8 Class Initialized
INFO - 2024-10-30 08:34:34 --> URI Class Initialized
DEBUG - 2024-10-30 08:34:34 --> No URI present. Default controller set.
INFO - 2024-10-30 08:34:34 --> Router Class Initialized
INFO - 2024-10-30 08:34:34 --> Output Class Initialized
INFO - 2024-10-30 08:34:34 --> Security Class Initialized
DEBUG - 2024-10-30 08:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 08:34:34 --> Input Class Initialized
INFO - 2024-10-30 08:34:34 --> Language Class Initialized
INFO - 2024-10-30 08:34:34 --> Loader Class Initialized
INFO - 2024-10-30 08:34:34 --> Helper loaded: url_helper
INFO - 2024-10-30 08:34:34 --> Helper loaded: file_helper
INFO - 2024-10-30 08:34:34 --> Helper loaded: security_helper
INFO - 2024-10-30 08:34:34 --> Helper loaded: wpu_helper
INFO - 2024-10-30 08:34:34 --> Database Driver Class Initialized
INFO - 2024-10-30 08:35:14 --> Config Class Initialized
INFO - 2024-10-30 08:35:14 --> Hooks Class Initialized
DEBUG - 2024-10-30 08:35:14 --> UTF-8 Support Enabled
INFO - 2024-10-30 08:35:14 --> Utf8 Class Initialized
INFO - 2024-10-30 08:35:14 --> URI Class Initialized
DEBUG - 2024-10-30 08:35:14 --> No URI present. Default controller set.
INFO - 2024-10-30 08:35:14 --> Router Class Initialized
INFO - 2024-10-30 08:35:14 --> Output Class Initialized
INFO - 2024-10-30 08:35:14 --> Security Class Initialized
DEBUG - 2024-10-30 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 08:35:14 --> Input Class Initialized
INFO - 2024-10-30 08:35:14 --> Language Class Initialized
INFO - 2024-10-30 08:35:14 --> Loader Class Initialized
INFO - 2024-10-30 08:35:14 --> Helper loaded: url_helper
INFO - 2024-10-30 08:35:14 --> Helper loaded: file_helper
INFO - 2024-10-30 08:35:14 --> Helper loaded: security_helper
INFO - 2024-10-30 08:35:14 --> Helper loaded: wpu_helper
INFO - 2024-10-30 08:35:14 --> Database Driver Class Initialized
INFO - 2024-10-30 22:39:52 --> Config Class Initialized
INFO - 2024-10-30 22:39:52 --> Hooks Class Initialized
DEBUG - 2024-10-30 22:39:52 --> UTF-8 Support Enabled
INFO - 2024-10-30 22:39:52 --> Utf8 Class Initialized
INFO - 2024-10-30 22:39:52 --> URI Class Initialized
INFO - 2024-10-30 22:39:52 --> Router Class Initialized
INFO - 2024-10-30 22:39:52 --> Output Class Initialized
INFO - 2024-10-30 22:39:52 --> Security Class Initialized
DEBUG - 2024-10-30 22:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 22:39:52 --> Input Class Initialized
INFO - 2024-10-30 22:39:52 --> Language Class Initialized
INFO - 2024-10-30 22:39:52 --> Loader Class Initialized
INFO - 2024-10-30 22:39:52 --> Helper loaded: url_helper
INFO - 2024-10-30 22:39:52 --> Helper loaded: file_helper
INFO - 2024-10-30 22:39:52 --> Helper loaded: security_helper
INFO - 2024-10-30 22:39:52 --> Helper loaded: wpu_helper
INFO - 2024-10-30 22:39:52 --> Database Driver Class Initialized
ERROR - 2024-10-30 22:39:59 --> Unable to connect to the database
INFO - 2024-10-30 22:39:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-30 22:40:02 --> Config Class Initialized
INFO - 2024-10-30 22:40:02 --> Hooks Class Initialized
DEBUG - 2024-10-30 22:40:02 --> UTF-8 Support Enabled
INFO - 2024-10-30 22:40:02 --> Utf8 Class Initialized
INFO - 2024-10-30 22:40:02 --> URI Class Initialized
INFO - 2024-10-30 22:40:02 --> Router Class Initialized
INFO - 2024-10-30 22:40:02 --> Output Class Initialized
INFO - 2024-10-30 22:40:02 --> Security Class Initialized
DEBUG - 2024-10-30 22:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 22:40:02 --> Input Class Initialized
INFO - 2024-10-30 22:40:02 --> Language Class Initialized
INFO - 2024-10-30 22:40:02 --> Loader Class Initialized
INFO - 2024-10-30 22:40:02 --> Helper loaded: url_helper
INFO - 2024-10-30 22:40:02 --> Helper loaded: file_helper
INFO - 2024-10-30 22:40:02 --> Helper loaded: security_helper
INFO - 2024-10-30 22:40:02 --> Helper loaded: wpu_helper
INFO - 2024-10-30 22:40:02 --> Database Driver Class Initialized
ERROR - 2024-10-30 22:40:10 --> Unable to connect to the database
INFO - 2024-10-30 22:40:10 --> Language file loaded: language/english/db_lang.php
