<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-16 05:05:39 --> Config Class Initialized
INFO - 2024-09-16 05:05:39 --> Hooks Class Initialized
DEBUG - 2024-09-16 05:05:39 --> UTF-8 Support Enabled
INFO - 2024-09-16 05:05:39 --> Utf8 Class Initialized
INFO - 2024-09-16 05:05:39 --> URI Class Initialized
DEBUG - 2024-09-16 05:05:39 --> No URI present. Default controller set.
INFO - 2024-09-16 05:05:39 --> Router Class Initialized
INFO - 2024-09-16 05:05:39 --> Output Class Initialized
INFO - 2024-09-16 05:05:39 --> Security Class Initialized
DEBUG - 2024-09-16 05:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 05:05:39 --> Input Class Initialized
INFO - 2024-09-16 05:05:39 --> Language Class Initialized
INFO - 2024-09-16 05:05:39 --> Loader Class Initialized
INFO - 2024-09-16 05:05:39 --> Helper loaded: url_helper
INFO - 2024-09-16 05:05:39 --> Helper loaded: file_helper
INFO - 2024-09-16 05:05:39 --> Helper loaded: security_helper
INFO - 2024-09-16 05:05:39 --> Helper loaded: wpu_helper
INFO - 2024-09-16 05:05:39 --> Database Driver Class Initialized
ERROR - 2024-09-16 05:05:40 --> Unable to connect to the database
INFO - 2024-09-16 05:05:40 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-16 07:29:48 --> Config Class Initialized
INFO - 2024-09-16 07:29:48 --> Hooks Class Initialized
DEBUG - 2024-09-16 07:29:48 --> UTF-8 Support Enabled
INFO - 2024-09-16 07:29:48 --> Utf8 Class Initialized
INFO - 2024-09-16 07:29:48 --> URI Class Initialized
DEBUG - 2024-09-16 07:29:48 --> No URI present. Default controller set.
INFO - 2024-09-16 07:29:48 --> Router Class Initialized
INFO - 2024-09-16 07:29:48 --> Output Class Initialized
INFO - 2024-09-16 07:29:48 --> Security Class Initialized
DEBUG - 2024-09-16 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 07:29:48 --> Input Class Initialized
INFO - 2024-09-16 07:29:48 --> Language Class Initialized
INFO - 2024-09-16 07:29:48 --> Loader Class Initialized
INFO - 2024-09-16 07:29:48 --> Helper loaded: url_helper
INFO - 2024-09-16 07:29:48 --> Helper loaded: file_helper
INFO - 2024-09-16 07:29:48 --> Helper loaded: security_helper
INFO - 2024-09-16 07:29:48 --> Helper loaded: wpu_helper
INFO - 2024-09-16 07:29:48 --> Database Driver Class Initialized
INFO - 2024-09-16 07:29:52 --> Config Class Initialized
INFO - 2024-09-16 07:29:52 --> Hooks Class Initialized
DEBUG - 2024-09-16 07:29:52 --> UTF-8 Support Enabled
INFO - 2024-09-16 07:29:52 --> Utf8 Class Initialized
INFO - 2024-09-16 07:29:52 --> URI Class Initialized
DEBUG - 2024-09-16 07:29:52 --> No URI present. Default controller set.
INFO - 2024-09-16 07:29:52 --> Router Class Initialized
INFO - 2024-09-16 07:29:52 --> Output Class Initialized
INFO - 2024-09-16 07:29:52 --> Security Class Initialized
DEBUG - 2024-09-16 07:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 07:29:52 --> Input Class Initialized
INFO - 2024-09-16 07:29:52 --> Language Class Initialized
INFO - 2024-09-16 07:29:52 --> Loader Class Initialized
INFO - 2024-09-16 07:29:52 --> Helper loaded: url_helper
INFO - 2024-09-16 07:29:52 --> Helper loaded: file_helper
INFO - 2024-09-16 07:29:52 --> Helper loaded: security_helper
INFO - 2024-09-16 07:29:52 --> Helper loaded: wpu_helper
INFO - 2024-09-16 07:29:52 --> Database Driver Class Initialized
ERROR - 2024-09-16 07:30:22 --> Unable to connect to the database
INFO - 2024-09-16 07:30:22 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-16 13:13:36 --> Config Class Initialized
INFO - 2024-09-16 13:13:36 --> Hooks Class Initialized
DEBUG - 2024-09-16 13:13:36 --> UTF-8 Support Enabled
INFO - 2024-09-16 13:13:36 --> Utf8 Class Initialized
INFO - 2024-09-16 13:13:36 --> URI Class Initialized
DEBUG - 2024-09-16 13:13:36 --> No URI present. Default controller set.
INFO - 2024-09-16 13:13:36 --> Router Class Initialized
INFO - 2024-09-16 13:13:36 --> Output Class Initialized
INFO - 2024-09-16 13:13:36 --> Security Class Initialized
DEBUG - 2024-09-16 13:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 13:13:36 --> Input Class Initialized
INFO - 2024-09-16 13:13:36 --> Language Class Initialized
INFO - 2024-09-16 13:13:36 --> Loader Class Initialized
INFO - 2024-09-16 13:13:36 --> Helper loaded: url_helper
INFO - 2024-09-16 13:13:36 --> Helper loaded: file_helper
INFO - 2024-09-16 13:13:36 --> Helper loaded: security_helper
INFO - 2024-09-16 13:13:36 --> Helper loaded: wpu_helper
INFO - 2024-09-16 13:13:36 --> Database Driver Class Initialized
INFO - 2024-09-16 13:13:40 --> Config Class Initialized
INFO - 2024-09-16 13:13:40 --> Hooks Class Initialized
DEBUG - 2024-09-16 13:13:40 --> UTF-8 Support Enabled
INFO - 2024-09-16 13:13:40 --> Utf8 Class Initialized
INFO - 2024-09-16 13:13:40 --> URI Class Initialized
DEBUG - 2024-09-16 13:13:40 --> No URI present. Default controller set.
INFO - 2024-09-16 13:13:40 --> Router Class Initialized
INFO - 2024-09-16 13:13:40 --> Output Class Initialized
INFO - 2024-09-16 13:13:40 --> Security Class Initialized
DEBUG - 2024-09-16 13:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-16 13:13:40 --> Input Class Initialized
INFO - 2024-09-16 13:13:40 --> Language Class Initialized
INFO - 2024-09-16 13:13:40 --> Loader Class Initialized
INFO - 2024-09-16 13:13:40 --> Helper loaded: url_helper
INFO - 2024-09-16 13:13:40 --> Helper loaded: file_helper
INFO - 2024-09-16 13:13:40 --> Helper loaded: security_helper
INFO - 2024-09-16 13:13:40 --> Helper loaded: wpu_helper
INFO - 2024-09-16 13:13:40 --> Database Driver Class Initialized
ERROR - 2024-09-16 13:14:06 --> Unable to connect to the database
INFO - 2024-09-16 13:14:06 --> Language file loaded: language/english/db_lang.php
