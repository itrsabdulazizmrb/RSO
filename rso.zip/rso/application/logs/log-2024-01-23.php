<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-23 01:28:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2024-01-23 01:29:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
