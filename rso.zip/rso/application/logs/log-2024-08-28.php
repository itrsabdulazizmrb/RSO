<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-28 00:24:46 --> Config Class Initialized
INFO - 2024-08-28 00:24:46 --> Hooks Class Initialized
DEBUG - 2024-08-28 00:24:46 --> UTF-8 Support Enabled
INFO - 2024-08-28 00:24:46 --> Utf8 Class Initialized
INFO - 2024-08-28 00:24:46 --> URI Class Initialized
DEBUG - 2024-08-28 00:24:46 --> No URI present. Default controller set.
INFO - 2024-08-28 00:24:46 --> Router Class Initialized
INFO - 2024-08-28 00:24:46 --> Output Class Initialized
INFO - 2024-08-28 00:24:46 --> Security Class Initialized
DEBUG - 2024-08-28 00:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 00:24:46 --> Input Class Initialized
INFO - 2024-08-28 00:24:46 --> Language Class Initialized
INFO - 2024-08-28 00:24:46 --> Loader Class Initialized
INFO - 2024-08-28 00:24:46 --> Helper loaded: url_helper
INFO - 2024-08-28 00:24:46 --> Helper loaded: file_helper
INFO - 2024-08-28 00:24:46 --> Helper loaded: security_helper
INFO - 2024-08-28 00:24:46 --> Helper loaded: wpu_helper
INFO - 2024-08-28 00:24:46 --> Database Driver Class Initialized
INFO - 2024-08-28 00:24:46 --> Email Class Initialized
DEBUG - 2024-08-28 00:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 00:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 00:24:46 --> Helper loaded: form_helper
INFO - 2024-08-28 00:24:46 --> Form Validation Class Initialized
INFO - 2024-08-28 00:24:46 --> Controller Class Initialized
DEBUG - 2024-08-28 00:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-28 00:24:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-28 00:24:46 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-28 00:24:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-28 00:24:46 --> Final output sent to browser
DEBUG - 2024-08-28 00:24:46 --> Total execution time: 0.0802
INFO - 2024-08-28 00:26:21 --> Config Class Initialized
INFO - 2024-08-28 00:26:21 --> Hooks Class Initialized
DEBUG - 2024-08-28 00:26:21 --> UTF-8 Support Enabled
INFO - 2024-08-28 00:26:21 --> Utf8 Class Initialized
INFO - 2024-08-28 00:26:21 --> URI Class Initialized
INFO - 2024-08-28 00:26:21 --> Router Class Initialized
INFO - 2024-08-28 00:26:21 --> Output Class Initialized
INFO - 2024-08-28 00:26:21 --> Security Class Initialized
DEBUG - 2024-08-28 00:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 00:26:21 --> Input Class Initialized
INFO - 2024-08-28 00:26:21 --> Language Class Initialized
INFO - 2024-08-28 00:26:21 --> Loader Class Initialized
INFO - 2024-08-28 00:26:21 --> Helper loaded: url_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: file_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: security_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: wpu_helper
INFO - 2024-08-28 00:26:21 --> Database Driver Class Initialized
INFO - 2024-08-28 00:26:21 --> Email Class Initialized
DEBUG - 2024-08-28 00:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 00:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 00:26:21 --> Helper loaded: form_helper
INFO - 2024-08-28 00:26:21 --> Form Validation Class Initialized
INFO - 2024-08-28 00:26:21 --> Controller Class Initialized
DEBUG - 2024-08-28 00:26:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-28 00:26:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-28 00:26:21 --> Config Class Initialized
INFO - 2024-08-28 00:26:21 --> Hooks Class Initialized
DEBUG - 2024-08-28 00:26:21 --> UTF-8 Support Enabled
INFO - 2024-08-28 00:26:21 --> Utf8 Class Initialized
INFO - 2024-08-28 00:26:21 --> URI Class Initialized
INFO - 2024-08-28 00:26:21 --> Router Class Initialized
INFO - 2024-08-28 00:26:21 --> Output Class Initialized
INFO - 2024-08-28 00:26:21 --> Security Class Initialized
DEBUG - 2024-08-28 00:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 00:26:21 --> Input Class Initialized
INFO - 2024-08-28 00:26:21 --> Language Class Initialized
INFO - 2024-08-28 00:26:21 --> Loader Class Initialized
INFO - 2024-08-28 00:26:21 --> Helper loaded: url_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: file_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: security_helper
INFO - 2024-08-28 00:26:21 --> Helper loaded: wpu_helper
INFO - 2024-08-28 00:26:21 --> Database Driver Class Initialized
INFO - 2024-08-28 00:26:21 --> Email Class Initialized
DEBUG - 2024-08-28 00:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 00:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 00:26:22 --> Helper loaded: form_helper
INFO - 2024-08-28 00:26:22 --> Form Validation Class Initialized
INFO - 2024-08-28 00:26:22 --> Controller Class Initialized
INFO - 2024-08-28 00:26:22 --> Model "User_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Permintaan_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Faktur_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Pesanan_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Supplier_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Jenis_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Inventaris_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Barang_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Perbaikan_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Penghapusan_model" initialized
INFO - 2024-08-28 00:26:22 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-28 00:26:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-28 00:26:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-28 00:26:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-28 00:26:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-28 00:26:22 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-28 00:26:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-28 00:26:22 --> Final output sent to browser
DEBUG - 2024-08-28 00:26:22 --> Total execution time: 0.0848
INFO - 2024-08-28 00:26:24 --> Config Class Initialized
INFO - 2024-08-28 00:26:24 --> Hooks Class Initialized
DEBUG - 2024-08-28 00:26:24 --> UTF-8 Support Enabled
INFO - 2024-08-28 00:26:24 --> Utf8 Class Initialized
INFO - 2024-08-28 00:26:24 --> URI Class Initialized
INFO - 2024-08-28 00:26:24 --> Router Class Initialized
INFO - 2024-08-28 00:26:24 --> Output Class Initialized
INFO - 2024-08-28 00:26:24 --> Security Class Initialized
DEBUG - 2024-08-28 00:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 00:26:24 --> Input Class Initialized
INFO - 2024-08-28 00:26:24 --> Language Class Initialized
INFO - 2024-08-28 00:26:24 --> Loader Class Initialized
INFO - 2024-08-28 00:26:24 --> Helper loaded: url_helper
INFO - 2024-08-28 00:26:24 --> Helper loaded: file_helper
INFO - 2024-08-28 00:26:24 --> Helper loaded: security_helper
INFO - 2024-08-28 00:26:24 --> Helper loaded: wpu_helper
INFO - 2024-08-28 00:26:24 --> Database Driver Class Initialized
INFO - 2024-08-28 00:26:24 --> Email Class Initialized
DEBUG - 2024-08-28 00:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-28 00:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 00:26:24 --> Helper loaded: form_helper
INFO - 2024-08-28 00:26:24 --> Form Validation Class Initialized
INFO - 2024-08-28 00:26:24 --> Controller Class Initialized
INFO - 2024-08-28 00:26:24 --> Model "User_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Faktur_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Supplier_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Jenis_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Barang_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Penghapusan_model" initialized
INFO - 2024-08-28 00:26:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-28 00:26:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-28 00:26:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-28 00:26:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-28 00:26:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-28 00:26:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-28 00:26:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-28 00:26:24 --> Final output sent to browser
DEBUG - 2024-08-28 00:26:24 --> Total execution time: 0.0789
