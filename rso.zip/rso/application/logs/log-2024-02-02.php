<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-02 01:44:50 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 300
ERROR - 2024-02-02 13:44:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\simba\application\models\Faktur_model.php 70
ERROR - 2024-02-02 14:03:38 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:05:50 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:06:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2024-02-02 14:06:44 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:06:50 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:06:53 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:07:03 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:07:04 --> 404 Page Not Found: Pengurus/index
ERROR - 2024-02-02 14:31:53 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 300
ERROR - 2024-02-02 14:53:31 --> 404 Page Not Found: Pengurus/permintaan
ERROR - 2024-02-02 15:22:31 --> 404 Page Not Found: User/barang
ERROR - 2024-02-02 15:22:34 --> 404 Page Not Found: User/barang
ERROR - 2024-02-02 17:50:23 --> Query error: Table 'simba.tbl_surat' doesn't exist - Invalid query: SELECT *
FROM `tbl_surat`
JOIN `tbl_klasifikasi` ON `tbl_klasifikasi`.`id_klasifikasi`=`tbl_surat`.`id_klasifikasi`
ORDER BY `tanggal_surat` DESC
ERROR - 2024-02-02 17:55:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 126
ERROR - 2024-02-02 17:56:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 128
ERROR - 2024-02-02 17:57:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 128
ERROR - 2024-02-02 17:57:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 128
ERROR - 2024-02-02 18:00:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 153
ERROR - 2024-02-02 18:02:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 112
ERROR - 2024-02-02 18:02:40 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 113
ERROR - 2024-02-02 18:04:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 111
ERROR - 2024-02-02 18:04:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\cetakfaktur.php 111
ERROR - 2024-02-02 18:05:29 --> Query error: Table 'simba.tbl_surat' doesn't exist - Invalid query: SELECT *
FROM `tbl_surat`
JOIN `tbl_klasifikasi` ON `tbl_klasifikasi`.`id_klasifikasi`=`tbl_surat`.`id_klasifikasi`
WHERE `tanggal_surat` >= ''
AND `tanggal_surat` <= ''
ERROR - 2024-02-02 18:13:15 --> 404 Page Not Found: Admin/cetaksurat
ERROR - 2024-02-02 18:13:18 --> 404 Page Not Found: Admin/cetaksurat
ERROR - 2024-02-02 18:13:26 --> 404 Page Not Found: Admin/cetaksurat
ERROR - 2024-02-02 18:15:21 --> Query error: Table 'simba.tbl_surat' doesn't exist - Invalid query: SELECT *
FROM `tbl_surat`
JOIN `tbl_klasifikasi` ON `tbl_klasifikasi`.`id_klasifikasi`=`tbl_surat`.`id_klasifikasi`
WHERE `tanggal_surat` >= '2024-02-28'
AND `tanggal_surat` <= '2024-02-27'
ERROR - 2024-02-02 18:29:01 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:29:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:29:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:29:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:31:14 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:32:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:32:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:33:09 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-02-02 18:43:22 --> 404 Page Not Found: Admin/listreport
ERROR - 2024-02-02 18:43:47 --> 404 Page Not Found: Admin/listreport
ERROR - 2024-02-02 18:49:06 --> 404 Page Not Found: Data/pdf
ERROR - 2024-02-02 19:22:05 --> 404 Page Not Found: Data/pdf
ERROR - 2024-02-02 19:59:52 --> 404 Page Not Found: 
ERROR - 2024-02-02 19:59:55 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:00:14 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:00:30 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:01:49 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:01:58 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:02:09 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:02:55 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:03:30 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:05:47 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:05:49 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:05:49 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:05:50 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:06:01 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:06:39 --> 404 Page Not Found: Admin/editfaktur
ERROR - 2024-02-02 20:12:37 --> Severity: error --> Exception: Call to undefined function show_403() C:\xampp\htdocs\simba\application\controllers\Admin.php 612
ERROR - 2024-02-02 20:15:15 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:21:01 --> Severity: Compile Error --> Cannot redeclare Admin::editpesanan() C:\xampp\htdocs\simba\application\controllers\Admin.php 621
ERROR - 2024-02-02 20:21:02 --> Severity: Compile Error --> Cannot redeclare Admin::editpesanan() C:\xampp\htdocs\simba\application\controllers\Admin.php 621
ERROR - 2024-02-02 20:21:43 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:24:16 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:24:18 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:24:24 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:24:29 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:24:49 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:24:49 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:24:49 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:24:49 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:26:34 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:26:34 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:26:34 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:26:34 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:26:36 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:26:36 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:26:36 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:26:36 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:26:42 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:27:18 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:27:32 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:27:42 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:28:10 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:28:16 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:29:08 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:29:10 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:29:12 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:29:25 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:29:31 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:29:33 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:29:52 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:29:58 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:30:05 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:30:09 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:30:15 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:30:35 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Faktur_model.php 257
ERROR - 2024-02-02 20:30:35 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:31:34 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Faktur_model.php 257
ERROR - 2024-02-02 20:31:34 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:31:35 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:31:36 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:33:43 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 246
ERROR - 2024-02-02 20:33:56 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:34:46 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:34:54 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:34:56 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:34:58 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:34:58 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:36:12 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:36:12 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 245
ERROR - 2024-02-02 20:36:13 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 245
ERROR - 2024-02-02 20:36:14 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 245
ERROR - 2024-02-02 20:37:08 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:37:35 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:37:38 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:37:45 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:37:47 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:38:19 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:38:29 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:38:37 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:38:38 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:39:21 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 230
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Faktur_model.php 231
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Faktur_model.php 232
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 233
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: tanggal_jatuh_tempo C:\xampp\htdocs\simba\application\models\Faktur_model.php 234
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: tanggal_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 235
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: petugas_penerima C:\xampp\htdocs\simba\application\models\Faktur_model.php 236
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Faktur_model.php 240
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: total_pembayaran C:\xampp\htdocs\simba\application\models\Faktur_model.php 242
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Faktur_model.php 243
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Faktur_model.php 244
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined index: no_faktur C:\xampp\htdocs\simba\application\models\Faktur_model.php 247
ERROR - 2024-02-02 20:39:52 --> Severity: Notice --> Undefined property: stdClass::$surat_pesanan C:\xampp\htdocs\simba\application\views\admin\e_faktur.php 44
ERROR - 2024-02-02 20:44:11 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined property: stdClass::$nama_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 35
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined property: stdClass::$bidang C:\xampp\htdocs\simba\application\views\admin\e_user.php 44
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined property: stdClass::$bidang C:\xampp\htdocs\simba\application\views\admin\e_user.php 62
ERROR - 2024-02-02 20:44:43 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 65
ERROR - 2024-02-02 20:50:05 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:50:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:50:43 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:50:43 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:50:43 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:50:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:50:44 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:50:44 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:50:44 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:50:59 --> 404 Page Not Found: 
ERROR - 2024-02-02 20:51:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:51:01 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:51:01 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:51:01 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:51:08 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:51:08 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:51:08 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:51:08 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:51:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:51:10 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:51:10 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:51:10 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:52:12 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:52:12 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:52:12 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:52:12 --> Severity: Notice --> Undefined property: stdClass::$id_user C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 30
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'nama_pegawai' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 35
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'jabatan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 44
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'jabatan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 53
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'username' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 62
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'password' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 71
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'id_role' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 78
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'id_user' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 86
ERROR - 2024-02-02 20:52:23 --> Severity: Notice --> Trying to get property 'id_role' of non-object C:\xampp\htdocs\simba\application\views\admin\e_user.php 89
ERROR - 2024-02-02 23:45:40 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 299
ERROR - 2024-02-02 23:46:03 --> 404 Page Not Found: 
ERROR - 2024-02-02 23:48:25 --> Query error: Duplicate entry '2147483647' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_user` (`nip`, `nama_pegawai`, `jabatan`, `unit`, `username`, `password`, `id_role`) VALUES ('198405132009042001', 'dr. Aan Widhi Anningrum', 'Direktur', 'Direktur', 'draan', '$2y$10$Myky8e5N.TBDdpe236d3qOsRMCeynWSN.nnenB2zvBhqDkvQ55beO', '1')
ERROR - 2024-02-02 23:48:55 --> Query error: Duplicate entry '2147483647' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_user` (`nip`, `nama_pegawai`, `jabatan`, `unit`, `username`, `password`, `id_role`) VALUES ('198405132009042001', 'dr. Aan Widhi Anningrum', 'Direktur', 'Direktur', 'draan', '$2y$10$G2QO2slkiKJKXzegUs9y1.PTNqZGdca6JeAU5ry.jvRjdkDp32IAa', '1')
ERROR - 2024-02-02 23:49:51 --> Query error: Duplicate entry '2147483647' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_user` (`nip`, `nama_pegawai`, `jabatan`, `unit`, `username`, `password`, `id_role`) VALUES ('198405132009042001', 'Anggi', 'Staf', 'Keuangan', 'anggi', '$2y$10$lTu027nAY/jP9bmHnLo/TOQT2UYLe1WjIZ9zphGdGYYuuyTWWpi36', '3')
ERROR - 2024-02-02 23:53:26 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 299
