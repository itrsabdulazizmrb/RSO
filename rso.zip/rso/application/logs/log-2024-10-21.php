<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-21 03:02:21 --> Config Class Initialized
INFO - 2024-10-21 03:02:21 --> Hooks Class Initialized
DEBUG - 2024-10-21 03:02:21 --> UTF-8 Support Enabled
INFO - 2024-10-21 03:02:21 --> Utf8 Class Initialized
INFO - 2024-10-21 03:02:21 --> URI Class Initialized
DEBUG - 2024-10-21 03:02:21 --> No URI present. Default controller set.
INFO - 2024-10-21 03:02:21 --> Router Class Initialized
INFO - 2024-10-21 03:02:21 --> Output Class Initialized
INFO - 2024-10-21 03:02:21 --> Security Class Initialized
DEBUG - 2024-10-21 03:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 03:02:21 --> Input Class Initialized
INFO - 2024-10-21 03:02:21 --> Language Class Initialized
INFO - 2024-10-21 03:02:21 --> Loader Class Initialized
INFO - 2024-10-21 03:02:21 --> Helper loaded: url_helper
INFO - 2024-10-21 03:02:21 --> Helper loaded: file_helper
INFO - 2024-10-21 03:02:21 --> Helper loaded: security_helper
INFO - 2024-10-21 03:02:21 --> Helper loaded: wpu_helper
INFO - 2024-10-21 03:02:21 --> Database Driver Class Initialized
INFO - 2024-10-21 03:02:21 --> Email Class Initialized
DEBUG - 2024-10-21 03:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-21 03:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 03:02:21 --> Helper loaded: form_helper
INFO - 2024-10-21 03:02:21 --> Form Validation Class Initialized
INFO - 2024-10-21 03:02:21 --> Controller Class Initialized
DEBUG - 2024-10-21 03:02:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-21 03:02:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-21 03:02:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-21 03:02:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-21 03:02:21 --> Final output sent to browser
DEBUG - 2024-10-21 03:02:21 --> Total execution time: 0.2270
INFO - 2024-10-21 05:57:46 --> Config Class Initialized
INFO - 2024-10-21 05:57:46 --> Hooks Class Initialized
DEBUG - 2024-10-21 05:57:46 --> UTF-8 Support Enabled
INFO - 2024-10-21 05:57:46 --> Utf8 Class Initialized
INFO - 2024-10-21 05:57:46 --> URI Class Initialized
DEBUG - 2024-10-21 05:57:46 --> No URI present. Default controller set.
INFO - 2024-10-21 05:57:46 --> Router Class Initialized
INFO - 2024-10-21 05:57:46 --> Output Class Initialized
INFO - 2024-10-21 05:57:46 --> Security Class Initialized
DEBUG - 2024-10-21 05:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 05:57:46 --> Input Class Initialized
INFO - 2024-10-21 05:57:46 --> Language Class Initialized
INFO - 2024-10-21 05:57:46 --> Loader Class Initialized
INFO - 2024-10-21 05:57:46 --> Helper loaded: url_helper
INFO - 2024-10-21 05:57:46 --> Helper loaded: file_helper
INFO - 2024-10-21 05:57:46 --> Helper loaded: security_helper
INFO - 2024-10-21 05:57:46 --> Helper loaded: wpu_helper
INFO - 2024-10-21 05:57:46 --> Database Driver Class Initialized
INFO - 2024-10-21 05:57:46 --> Email Class Initialized
DEBUG - 2024-10-21 05:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-21 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 05:57:46 --> Helper loaded: form_helper
INFO - 2024-10-21 05:57:46 --> Form Validation Class Initialized
INFO - 2024-10-21 05:57:46 --> Controller Class Initialized
DEBUG - 2024-10-21 05:57:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-21 05:57:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-21 05:57:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-21 05:57:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-21 05:57:46 --> Final output sent to browser
DEBUG - 2024-10-21 05:57:46 --> Total execution time: 0.2621
INFO - 2024-10-21 05:57:48 --> Config Class Initialized
INFO - 2024-10-21 05:57:48 --> Hooks Class Initialized
DEBUG - 2024-10-21 05:57:48 --> UTF-8 Support Enabled
INFO - 2024-10-21 05:57:48 --> Utf8 Class Initialized
INFO - 2024-10-21 05:57:48 --> URI Class Initialized
INFO - 2024-10-21 05:57:48 --> Router Class Initialized
INFO - 2024-10-21 05:57:48 --> Output Class Initialized
INFO - 2024-10-21 05:57:48 --> Security Class Initialized
DEBUG - 2024-10-21 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 05:57:48 --> Input Class Initialized
INFO - 2024-10-21 05:57:48 --> Language Class Initialized
INFO - 2024-10-21 05:57:48 --> Loader Class Initialized
INFO - 2024-10-21 05:57:48 --> Helper loaded: url_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: file_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: security_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: wpu_helper
INFO - 2024-10-21 05:57:48 --> Database Driver Class Initialized
INFO - 2024-10-21 05:57:48 --> Email Class Initialized
DEBUG - 2024-10-21 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-21 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 05:57:48 --> Helper loaded: form_helper
INFO - 2024-10-21 05:57:48 --> Form Validation Class Initialized
INFO - 2024-10-21 05:57:48 --> Controller Class Initialized
DEBUG - 2024-10-21 05:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-21 05:57:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-21 05:57:48 --> Config Class Initialized
INFO - 2024-10-21 05:57:48 --> Hooks Class Initialized
DEBUG - 2024-10-21 05:57:48 --> UTF-8 Support Enabled
INFO - 2024-10-21 05:57:48 --> Utf8 Class Initialized
INFO - 2024-10-21 05:57:48 --> URI Class Initialized
INFO - 2024-10-21 05:57:48 --> Router Class Initialized
INFO - 2024-10-21 05:57:48 --> Output Class Initialized
INFO - 2024-10-21 05:57:48 --> Security Class Initialized
DEBUG - 2024-10-21 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 05:57:48 --> Input Class Initialized
INFO - 2024-10-21 05:57:48 --> Language Class Initialized
INFO - 2024-10-21 05:57:48 --> Loader Class Initialized
INFO - 2024-10-21 05:57:48 --> Helper loaded: url_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: file_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: security_helper
INFO - 2024-10-21 05:57:48 --> Helper loaded: wpu_helper
INFO - 2024-10-21 05:57:48 --> Database Driver Class Initialized
INFO - 2024-10-21 05:57:48 --> Email Class Initialized
DEBUG - 2024-10-21 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-21 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 05:57:48 --> Helper loaded: form_helper
INFO - 2024-10-21 05:57:48 --> Form Validation Class Initialized
INFO - 2024-10-21 05:57:48 --> Controller Class Initialized
INFO - 2024-10-21 05:57:48 --> Model "Antrol_model" initialized
DEBUG - 2024-10-21 05:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-21 05:57:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-21 05:57:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-21 05:57:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-21 05:57:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-21 05:57:49 --> Final output sent to browser
DEBUG - 2024-10-21 05:57:49 --> Total execution time: 0.6589
INFO - 2024-10-21 08:48:10 --> Config Class Initialized
INFO - 2024-10-21 08:48:10 --> Hooks Class Initialized
DEBUG - 2024-10-21 08:48:10 --> UTF-8 Support Enabled
INFO - 2024-10-21 08:48:10 --> Utf8 Class Initialized
INFO - 2024-10-21 08:48:10 --> URI Class Initialized
DEBUG - 2024-10-21 08:48:10 --> No URI present. Default controller set.
INFO - 2024-10-21 08:48:10 --> Router Class Initialized
INFO - 2024-10-21 08:48:10 --> Output Class Initialized
INFO - 2024-10-21 08:48:10 --> Security Class Initialized
DEBUG - 2024-10-21 08:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-21 08:48:10 --> Input Class Initialized
INFO - 2024-10-21 08:48:10 --> Language Class Initialized
INFO - 2024-10-21 08:48:10 --> Loader Class Initialized
INFO - 2024-10-21 08:48:10 --> Helper loaded: url_helper
INFO - 2024-10-21 08:48:10 --> Helper loaded: file_helper
INFO - 2024-10-21 08:48:10 --> Helper loaded: security_helper
INFO - 2024-10-21 08:48:10 --> Helper loaded: wpu_helper
INFO - 2024-10-21 08:48:10 --> Database Driver Class Initialized
INFO - 2024-10-21 08:48:10 --> Email Class Initialized
DEBUG - 2024-10-21 08:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-21 08:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-21 08:48:10 --> Helper loaded: form_helper
INFO - 2024-10-21 08:48:10 --> Form Validation Class Initialized
INFO - 2024-10-21 08:48:10 --> Controller Class Initialized
DEBUG - 2024-10-21 08:48:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-21 08:48:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-21 08:48:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-21 08:48:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-21 08:48:10 --> Final output sent to browser
DEBUG - 2024-10-21 08:48:10 --> Total execution time: 0.2415
