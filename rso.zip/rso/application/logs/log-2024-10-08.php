<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-08 01:40:09 --> Config Class Initialized
INFO - 2024-10-08 01:40:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 01:40:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 01:40:09 --> Utf8 Class Initialized
INFO - 2024-10-08 01:40:09 --> URI Class Initialized
DEBUG - 2024-10-08 01:40:09 --> No URI present. Default controller set.
INFO - 2024-10-08 01:40:09 --> Router Class Initialized
INFO - 2024-10-08 01:40:09 --> Output Class Initialized
INFO - 2024-10-08 01:40:09 --> Security Class Initialized
DEBUG - 2024-10-08 01:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 01:40:09 --> Input Class Initialized
INFO - 2024-10-08 01:40:09 --> Language Class Initialized
INFO - 2024-10-08 01:40:09 --> Loader Class Initialized
INFO - 2024-10-08 01:40:09 --> Helper loaded: url_helper
INFO - 2024-10-08 01:40:09 --> Helper loaded: file_helper
INFO - 2024-10-08 01:40:09 --> Helper loaded: security_helper
INFO - 2024-10-08 01:40:09 --> Helper loaded: wpu_helper
INFO - 2024-10-08 01:40:09 --> Database Driver Class Initialized
INFO - 2024-10-08 01:40:09 --> Email Class Initialized
DEBUG - 2024-10-08 01:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 01:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 01:40:09 --> Helper loaded: form_helper
INFO - 2024-10-08 01:40:09 --> Form Validation Class Initialized
INFO - 2024-10-08 01:40:09 --> Controller Class Initialized
DEBUG - 2024-10-08 01:40:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 01:40:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-08 01:40:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-08 01:40:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-08 01:40:09 --> Final output sent to browser
DEBUG - 2024-10-08 01:40:09 --> Total execution time: 0.2209
INFO - 2024-10-08 01:40:12 --> Config Class Initialized
INFO - 2024-10-08 01:40:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 01:40:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 01:40:12 --> Utf8 Class Initialized
INFO - 2024-10-08 01:40:12 --> URI Class Initialized
INFO - 2024-10-08 01:40:12 --> Router Class Initialized
INFO - 2024-10-08 01:40:12 --> Output Class Initialized
INFO - 2024-10-08 01:40:12 --> Security Class Initialized
DEBUG - 2024-10-08 01:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 01:40:12 --> Input Class Initialized
INFO - 2024-10-08 01:40:12 --> Language Class Initialized
INFO - 2024-10-08 01:40:12 --> Loader Class Initialized
INFO - 2024-10-08 01:40:12 --> Helper loaded: url_helper
INFO - 2024-10-08 01:40:12 --> Helper loaded: file_helper
INFO - 2024-10-08 01:40:12 --> Helper loaded: security_helper
INFO - 2024-10-08 01:40:12 --> Helper loaded: wpu_helper
INFO - 2024-10-08 01:40:12 --> Database Driver Class Initialized
INFO - 2024-10-08 01:40:13 --> Email Class Initialized
DEBUG - 2024-10-08 01:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 01:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 01:40:13 --> Helper loaded: form_helper
INFO - 2024-10-08 01:40:13 --> Form Validation Class Initialized
INFO - 2024-10-08 01:40:13 --> Controller Class Initialized
DEBUG - 2024-10-08 01:40:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 01:40:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-08 01:40:13 --> Config Class Initialized
INFO - 2024-10-08 01:40:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 01:40:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 01:40:13 --> Utf8 Class Initialized
INFO - 2024-10-08 01:40:13 --> URI Class Initialized
INFO - 2024-10-08 01:40:13 --> Router Class Initialized
INFO - 2024-10-08 01:40:13 --> Output Class Initialized
INFO - 2024-10-08 01:40:13 --> Security Class Initialized
DEBUG - 2024-10-08 01:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 01:40:13 --> Input Class Initialized
INFO - 2024-10-08 01:40:13 --> Language Class Initialized
INFO - 2024-10-08 01:40:13 --> Loader Class Initialized
INFO - 2024-10-08 01:40:13 --> Helper loaded: url_helper
INFO - 2024-10-08 01:40:13 --> Helper loaded: file_helper
INFO - 2024-10-08 01:40:13 --> Helper loaded: security_helper
INFO - 2024-10-08 01:40:13 --> Helper loaded: wpu_helper
INFO - 2024-10-08 01:40:13 --> Database Driver Class Initialized
INFO - 2024-10-08 01:40:13 --> Email Class Initialized
DEBUG - 2024-10-08 01:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 01:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 01:40:13 --> Helper loaded: form_helper
INFO - 2024-10-08 01:40:13 --> Form Validation Class Initialized
INFO - 2024-10-08 01:40:13 --> Controller Class Initialized
INFO - 2024-10-08 01:40:13 --> Model "Antrol_model" initialized
DEBUG - 2024-10-08 01:40:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 01:40:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-08 01:40:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-08 01:40:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-08 01:40:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-08 01:40:13 --> Final output sent to browser
DEBUG - 2024-10-08 01:40:13 --> Total execution time: 0.5549
INFO - 2024-10-08 09:02:15 --> Config Class Initialized
INFO - 2024-10-08 09:02:15 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:15 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:15 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:15 --> URI Class Initialized
DEBUG - 2024-10-08 09:02:15 --> No URI present. Default controller set.
INFO - 2024-10-08 09:02:15 --> Router Class Initialized
INFO - 2024-10-08 09:02:15 --> Output Class Initialized
INFO - 2024-10-08 09:02:15 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:15 --> Input Class Initialized
INFO - 2024-10-08 09:02:15 --> Language Class Initialized
INFO - 2024-10-08 09:02:15 --> Loader Class Initialized
INFO - 2024-10-08 09:02:15 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:15 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:15 --> Helper loaded: security_helper
INFO - 2024-10-08 09:02:15 --> Helper loaded: wpu_helper
INFO - 2024-10-08 09:02:15 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:16 --> Email Class Initialized
DEBUG - 2024-10-08 09:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 09:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:16 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:16 --> Form Validation Class Initialized
INFO - 2024-10-08 09:02:16 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 09:02:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-08 09:02:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-08 09:02:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-08 09:02:16 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:16 --> Total execution time: 0.7078
INFO - 2024-10-08 22:08:44 --> Config Class Initialized
INFO - 2024-10-08 22:08:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 22:08:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 22:08:44 --> Utf8 Class Initialized
INFO - 2024-10-08 22:08:44 --> URI Class Initialized
DEBUG - 2024-10-08 22:08:44 --> No URI present. Default controller set.
INFO - 2024-10-08 22:08:44 --> Router Class Initialized
INFO - 2024-10-08 22:08:44 --> Output Class Initialized
INFO - 2024-10-08 22:08:44 --> Security Class Initialized
DEBUG - 2024-10-08 22:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 22:08:44 --> Input Class Initialized
INFO - 2024-10-08 22:08:44 --> Language Class Initialized
INFO - 2024-10-08 22:08:44 --> Loader Class Initialized
INFO - 2024-10-08 22:08:44 --> Helper loaded: url_helper
INFO - 2024-10-08 22:08:44 --> Helper loaded: file_helper
INFO - 2024-10-08 22:08:44 --> Helper loaded: security_helper
INFO - 2024-10-08 22:08:44 --> Helper loaded: wpu_helper
INFO - 2024-10-08 22:08:44 --> Database Driver Class Initialized
INFO - 2024-10-08 22:08:44 --> Email Class Initialized
DEBUG - 2024-10-08 22:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 22:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 22:08:44 --> Helper loaded: form_helper
INFO - 2024-10-08 22:08:44 --> Form Validation Class Initialized
INFO - 2024-10-08 22:08:44 --> Controller Class Initialized
DEBUG - 2024-10-08 22:08:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 22:08:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-08 22:08:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-08 22:08:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-08 22:08:44 --> Final output sent to browser
DEBUG - 2024-10-08 22:08:44 --> Total execution time: 0.2170
INFO - 2024-10-08 22:08:47 --> Config Class Initialized
INFO - 2024-10-08 22:08:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 22:08:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 22:08:47 --> Utf8 Class Initialized
INFO - 2024-10-08 22:08:47 --> URI Class Initialized
INFO - 2024-10-08 22:08:47 --> Router Class Initialized
INFO - 2024-10-08 22:08:47 --> Output Class Initialized
INFO - 2024-10-08 22:08:47 --> Security Class Initialized
DEBUG - 2024-10-08 22:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 22:08:47 --> Input Class Initialized
INFO - 2024-10-08 22:08:47 --> Language Class Initialized
INFO - 2024-10-08 22:08:47 --> Loader Class Initialized
INFO - 2024-10-08 22:08:47 --> Helper loaded: url_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: file_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: security_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: wpu_helper
INFO - 2024-10-08 22:08:47 --> Database Driver Class Initialized
INFO - 2024-10-08 22:08:47 --> Email Class Initialized
DEBUG - 2024-10-08 22:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 22:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 22:08:47 --> Helper loaded: form_helper
INFO - 2024-10-08 22:08:47 --> Form Validation Class Initialized
INFO - 2024-10-08 22:08:47 --> Controller Class Initialized
DEBUG - 2024-10-08 22:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 22:08:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-08 22:08:47 --> Config Class Initialized
INFO - 2024-10-08 22:08:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 22:08:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 22:08:47 --> Utf8 Class Initialized
INFO - 2024-10-08 22:08:47 --> URI Class Initialized
INFO - 2024-10-08 22:08:47 --> Router Class Initialized
INFO - 2024-10-08 22:08:47 --> Output Class Initialized
INFO - 2024-10-08 22:08:47 --> Security Class Initialized
DEBUG - 2024-10-08 22:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 22:08:47 --> Input Class Initialized
INFO - 2024-10-08 22:08:47 --> Language Class Initialized
INFO - 2024-10-08 22:08:47 --> Loader Class Initialized
INFO - 2024-10-08 22:08:47 --> Helper loaded: url_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: file_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: security_helper
INFO - 2024-10-08 22:08:47 --> Helper loaded: wpu_helper
INFO - 2024-10-08 22:08:47 --> Database Driver Class Initialized
INFO - 2024-10-08 22:08:47 --> Email Class Initialized
DEBUG - 2024-10-08 22:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 22:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 22:08:47 --> Helper loaded: form_helper
INFO - 2024-10-08 22:08:47 --> Form Validation Class Initialized
INFO - 2024-10-08 22:08:47 --> Controller Class Initialized
INFO - 2024-10-08 22:08:47 --> Model "Antrol_model" initialized
DEBUG - 2024-10-08 22:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 22:08:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-08 22:08:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-08 22:08:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-08 22:08:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-08 22:08:47 --> Final output sent to browser
DEBUG - 2024-10-08 22:08:47 --> Total execution time: 0.5639
INFO - 2024-10-08 22:09:03 --> Config Class Initialized
INFO - 2024-10-08 22:09:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 22:09:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 22:09:03 --> Utf8 Class Initialized
INFO - 2024-10-08 22:09:03 --> URI Class Initialized
INFO - 2024-10-08 22:09:03 --> Router Class Initialized
INFO - 2024-10-08 22:09:03 --> Output Class Initialized
INFO - 2024-10-08 22:09:03 --> Security Class Initialized
DEBUG - 2024-10-08 22:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 22:09:03 --> Input Class Initialized
INFO - 2024-10-08 22:09:03 --> Language Class Initialized
INFO - 2024-10-08 22:09:03 --> Loader Class Initialized
INFO - 2024-10-08 22:09:03 --> Helper loaded: url_helper
INFO - 2024-10-08 22:09:03 --> Helper loaded: file_helper
INFO - 2024-10-08 22:09:03 --> Helper loaded: security_helper
INFO - 2024-10-08 22:09:03 --> Helper loaded: wpu_helper
INFO - 2024-10-08 22:09:03 --> Database Driver Class Initialized
INFO - 2024-10-08 22:09:03 --> Email Class Initialized
DEBUG - 2024-10-08 22:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 22:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 22:09:03 --> Helper loaded: form_helper
INFO - 2024-10-08 22:09:03 --> Form Validation Class Initialized
INFO - 2024-10-08 22:09:03 --> Controller Class Initialized
INFO - 2024-10-08 22:09:03 --> Model "Antrol_model" initialized
DEBUG - 2024-10-08 22:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 22:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-08 22:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-08 22:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-08 22:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-08 22:09:03 --> Final output sent to browser
DEBUG - 2024-10-08 22:09:03 --> Total execution time: 0.5793
INFO - 2024-10-08 23:13:11 --> Config Class Initialized
INFO - 2024-10-08 23:13:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 23:13:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 23:13:11 --> Utf8 Class Initialized
INFO - 2024-10-08 23:13:11 --> URI Class Initialized
INFO - 2024-10-08 23:13:11 --> Router Class Initialized
INFO - 2024-10-08 23:13:11 --> Output Class Initialized
INFO - 2024-10-08 23:13:11 --> Security Class Initialized
DEBUG - 2024-10-08 23:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 23:13:11 --> Input Class Initialized
INFO - 2024-10-08 23:13:11 --> Language Class Initialized
INFO - 2024-10-08 23:13:11 --> Loader Class Initialized
INFO - 2024-10-08 23:13:11 --> Helper loaded: url_helper
INFO - 2024-10-08 23:13:11 --> Helper loaded: file_helper
INFO - 2024-10-08 23:13:11 --> Helper loaded: security_helper
INFO - 2024-10-08 23:13:11 --> Helper loaded: wpu_helper
INFO - 2024-10-08 23:13:11 --> Database Driver Class Initialized
INFO - 2024-10-08 23:13:11 --> Email Class Initialized
DEBUG - 2024-10-08 23:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-08 23:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 23:13:11 --> Helper loaded: form_helper
INFO - 2024-10-08 23:13:11 --> Form Validation Class Initialized
INFO - 2024-10-08 23:13:11 --> Controller Class Initialized
INFO - 2024-10-08 23:13:11 --> Model "Antrol_model" initialized
DEBUG - 2024-10-08 23:13:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-08 23:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-08 23:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-08 23:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-08 23:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-08 23:13:12 --> Final output sent to browser
DEBUG - 2024-10-08 23:13:12 --> Total execution time: 0.5901
