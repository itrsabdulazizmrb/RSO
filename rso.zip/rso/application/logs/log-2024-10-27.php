<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-27 08:36:10 --> Config Class Initialized
INFO - 2024-10-27 08:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:36:10 --> Utf8 Class Initialized
INFO - 2024-10-27 08:36:10 --> URI Class Initialized
DEBUG - 2024-10-27 08:36:10 --> No URI present. Default controller set.
INFO - 2024-10-27 08:36:10 --> Router Class Initialized
INFO - 2024-10-27 08:36:10 --> Output Class Initialized
INFO - 2024-10-27 08:36:10 --> Security Class Initialized
DEBUG - 2024-10-27 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:36:10 --> Input Class Initialized
INFO - 2024-10-27 08:36:10 --> Language Class Initialized
INFO - 2024-10-27 08:36:10 --> Loader Class Initialized
INFO - 2024-10-27 08:36:10 --> Helper loaded: url_helper
INFO - 2024-10-27 08:36:10 --> Helper loaded: file_helper
INFO - 2024-10-27 08:36:10 --> Helper loaded: security_helper
INFO - 2024-10-27 08:36:10 --> Helper loaded: wpu_helper
INFO - 2024-10-27 08:36:10 --> Database Driver Class Initialized
INFO - 2024-10-27 08:36:10 --> Email Class Initialized
DEBUG - 2024-10-27 08:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-27 08:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:36:10 --> Helper loaded: form_helper
INFO - 2024-10-27 08:36:10 --> Form Validation Class Initialized
INFO - 2024-10-27 08:36:10 --> Controller Class Initialized
DEBUG - 2024-10-27 08:36:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-27 08:36:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-27 08:36:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-27 08:36:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-27 08:36:10 --> Final output sent to browser
DEBUG - 2024-10-27 08:36:10 --> Total execution time: 0.2195
INFO - 2024-10-27 12:12:16 --> Config Class Initialized
INFO - 2024-10-27 12:12:16 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:12:16 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:12:16 --> Utf8 Class Initialized
INFO - 2024-10-27 12:12:16 --> URI Class Initialized
DEBUG - 2024-10-27 12:12:16 --> No URI present. Default controller set.
INFO - 2024-10-27 12:12:16 --> Router Class Initialized
INFO - 2024-10-27 12:12:16 --> Output Class Initialized
INFO - 2024-10-27 12:12:16 --> Security Class Initialized
DEBUG - 2024-10-27 12:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:12:16 --> Input Class Initialized
INFO - 2024-10-27 12:12:16 --> Language Class Initialized
INFO - 2024-10-27 12:12:16 --> Loader Class Initialized
INFO - 2024-10-27 12:12:16 --> Helper loaded: url_helper
INFO - 2024-10-27 12:12:16 --> Helper loaded: file_helper
INFO - 2024-10-27 12:12:16 --> Helper loaded: security_helper
INFO - 2024-10-27 12:12:16 --> Helper loaded: wpu_helper
INFO - 2024-10-27 12:12:16 --> Database Driver Class Initialized
INFO - 2024-10-27 12:12:17 --> Email Class Initialized
DEBUG - 2024-10-27 12:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-27 12:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:12:17 --> Helper loaded: form_helper
INFO - 2024-10-27 12:12:17 --> Form Validation Class Initialized
INFO - 2024-10-27 12:12:17 --> Controller Class Initialized
DEBUG - 2024-10-27 12:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-27 12:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-27 12:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-27 12:12:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-27 12:12:17 --> Final output sent to browser
DEBUG - 2024-10-27 12:12:17 --> Total execution time: 0.2306
INFO - 2024-10-27 12:12:19 --> Config Class Initialized
INFO - 2024-10-27 12:12:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:12:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:12:19 --> Utf8 Class Initialized
INFO - 2024-10-27 12:12:19 --> URI Class Initialized
INFO - 2024-10-27 12:12:19 --> Router Class Initialized
INFO - 2024-10-27 12:12:19 --> Output Class Initialized
INFO - 2024-10-27 12:12:19 --> Security Class Initialized
DEBUG - 2024-10-27 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:12:19 --> Input Class Initialized
INFO - 2024-10-27 12:12:19 --> Language Class Initialized
INFO - 2024-10-27 12:12:19 --> Loader Class Initialized
INFO - 2024-10-27 12:12:19 --> Helper loaded: url_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: file_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: security_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: wpu_helper
INFO - 2024-10-27 12:12:19 --> Database Driver Class Initialized
INFO - 2024-10-27 12:12:19 --> Email Class Initialized
DEBUG - 2024-10-27 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-27 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:12:19 --> Helper loaded: form_helper
INFO - 2024-10-27 12:12:19 --> Form Validation Class Initialized
INFO - 2024-10-27 12:12:19 --> Controller Class Initialized
DEBUG - 2024-10-27 12:12:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-27 12:12:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-27 12:12:19 --> Config Class Initialized
INFO - 2024-10-27 12:12:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:12:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:12:19 --> Utf8 Class Initialized
INFO - 2024-10-27 12:12:19 --> URI Class Initialized
INFO - 2024-10-27 12:12:19 --> Router Class Initialized
INFO - 2024-10-27 12:12:19 --> Output Class Initialized
INFO - 2024-10-27 12:12:19 --> Security Class Initialized
DEBUG - 2024-10-27 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:12:19 --> Input Class Initialized
INFO - 2024-10-27 12:12:19 --> Language Class Initialized
INFO - 2024-10-27 12:12:19 --> Loader Class Initialized
INFO - 2024-10-27 12:12:19 --> Helper loaded: url_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: file_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: security_helper
INFO - 2024-10-27 12:12:19 --> Helper loaded: wpu_helper
INFO - 2024-10-27 12:12:19 --> Database Driver Class Initialized
INFO - 2024-10-27 12:12:19 --> Email Class Initialized
DEBUG - 2024-10-27 12:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-27 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:12:19 --> Helper loaded: form_helper
INFO - 2024-10-27 12:12:19 --> Form Validation Class Initialized
INFO - 2024-10-27 12:12:19 --> Controller Class Initialized
INFO - 2024-10-27 12:12:19 --> Model "Antrol_model" initialized
DEBUG - 2024-10-27 12:12:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-27 12:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-27 12:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-27 12:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-27 12:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-27 12:12:20 --> Final output sent to browser
DEBUG - 2024-10-27 12:12:20 --> Total execution time: 0.6262
