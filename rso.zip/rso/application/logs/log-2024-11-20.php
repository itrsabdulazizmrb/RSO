<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-20 03:31:09 --> Config Class Initialized
INFO - 2024-11-20 03:31:09 --> Hooks Class Initialized
DEBUG - 2024-11-20 03:31:09 --> UTF-8 Support Enabled
INFO - 2024-11-20 03:31:09 --> Utf8 Class Initialized
INFO - 2024-11-20 03:31:09 --> URI Class Initialized
DEBUG - 2024-11-20 03:31:09 --> No URI present. Default controller set.
INFO - 2024-11-20 03:31:09 --> Router Class Initialized
INFO - 2024-11-20 03:31:09 --> Output Class Initialized
INFO - 2024-11-20 03:31:09 --> Security Class Initialized
DEBUG - 2024-11-20 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 03:31:09 --> Input Class Initialized
INFO - 2024-11-20 03:31:09 --> Language Class Initialized
INFO - 2024-11-20 03:31:09 --> Loader Class Initialized
INFO - 2024-11-20 03:31:09 --> Helper loaded: url_helper
INFO - 2024-11-20 03:31:09 --> Helper loaded: file_helper
INFO - 2024-11-20 03:31:09 --> Helper loaded: security_helper
INFO - 2024-11-20 03:31:09 --> Helper loaded: wpu_helper
INFO - 2024-11-20 03:31:09 --> Database Driver Class Initialized
ERROR - 2024-11-20 03:31:09 --> Unable to connect to the database
INFO - 2024-11-20 03:31:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-20 03:31:12 --> Config Class Initialized
INFO - 2024-11-20 03:31:12 --> Hooks Class Initialized
DEBUG - 2024-11-20 03:31:12 --> UTF-8 Support Enabled
INFO - 2024-11-20 03:31:12 --> Utf8 Class Initialized
INFO - 2024-11-20 03:31:12 --> URI Class Initialized
DEBUG - 2024-11-20 03:31:12 --> No URI present. Default controller set.
INFO - 2024-11-20 03:31:12 --> Router Class Initialized
INFO - 2024-11-20 03:31:12 --> Output Class Initialized
INFO - 2024-11-20 03:31:12 --> Security Class Initialized
DEBUG - 2024-11-20 03:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 03:31:12 --> Input Class Initialized
INFO - 2024-11-20 03:31:12 --> Language Class Initialized
INFO - 2024-11-20 03:31:12 --> Loader Class Initialized
INFO - 2024-11-20 03:31:12 --> Helper loaded: url_helper
INFO - 2024-11-20 03:31:12 --> Helper loaded: file_helper
INFO - 2024-11-20 03:31:12 --> Helper loaded: security_helper
INFO - 2024-11-20 03:31:12 --> Helper loaded: wpu_helper
INFO - 2024-11-20 03:31:12 --> Database Driver Class Initialized
ERROR - 2024-11-20 03:31:12 --> Unable to connect to the database
INFO - 2024-11-20 03:31:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-20 08:06:15 --> Config Class Initialized
INFO - 2024-11-20 08:06:15 --> Hooks Class Initialized
DEBUG - 2024-11-20 08:06:15 --> UTF-8 Support Enabled
INFO - 2024-11-20 08:06:15 --> Utf8 Class Initialized
INFO - 2024-11-20 08:06:15 --> URI Class Initialized
DEBUG - 2024-11-20 08:06:15 --> No URI present. Default controller set.
INFO - 2024-11-20 08:06:15 --> Router Class Initialized
INFO - 2024-11-20 08:06:15 --> Output Class Initialized
INFO - 2024-11-20 08:06:15 --> Security Class Initialized
DEBUG - 2024-11-20 08:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 08:06:15 --> Input Class Initialized
INFO - 2024-11-20 08:06:15 --> Language Class Initialized
INFO - 2024-11-20 08:06:15 --> Loader Class Initialized
INFO - 2024-11-20 08:06:15 --> Helper loaded: url_helper
INFO - 2024-11-20 08:06:15 --> Helper loaded: file_helper
INFO - 2024-11-20 08:06:15 --> Helper loaded: security_helper
INFO - 2024-11-20 08:06:15 --> Helper loaded: wpu_helper
INFO - 2024-11-20 08:06:15 --> Database Driver Class Initialized
ERROR - 2024-11-20 08:06:15 --> Unable to connect to the database
INFO - 2024-11-20 08:06:15 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-20 18:10:45 --> Config Class Initialized
INFO - 2024-11-20 18:10:45 --> Hooks Class Initialized
DEBUG - 2024-11-20 18:10:45 --> UTF-8 Support Enabled
INFO - 2024-11-20 18:10:45 --> Utf8 Class Initialized
INFO - 2024-11-20 18:10:45 --> URI Class Initialized
DEBUG - 2024-11-20 18:10:45 --> No URI present. Default controller set.
INFO - 2024-11-20 18:10:45 --> Router Class Initialized
INFO - 2024-11-20 18:10:45 --> Output Class Initialized
INFO - 2024-11-20 18:10:45 --> Security Class Initialized
DEBUG - 2024-11-20 18:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 18:10:45 --> Input Class Initialized
INFO - 2024-11-20 18:10:45 --> Language Class Initialized
INFO - 2024-11-20 18:10:45 --> Loader Class Initialized
INFO - 2024-11-20 18:10:45 --> Helper loaded: url_helper
INFO - 2024-11-20 18:10:45 --> Helper loaded: file_helper
INFO - 2024-11-20 18:10:45 --> Helper loaded: security_helper
INFO - 2024-11-20 18:10:45 --> Helper loaded: wpu_helper
INFO - 2024-11-20 18:10:45 --> Database Driver Class Initialized
ERROR - 2024-11-20 18:10:45 --> Unable to connect to the database
INFO - 2024-11-20 18:10:45 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Securityyml/index
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Envdev/index
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Envsave/index
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Config/production.config.php
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Backup/config.php.bak
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Testphp/index
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Envexample/index
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Htdocs/config.php.disabled
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Textpattern/config.php.bkp
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
DEBUG - 2024-11-20 22:19:36 --> No URI present. Default controller set.
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Caches/configs
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Loader Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Helper loaded: url_helper
INFO - 2024-11-20 22:19:36 --> Helper loaded: file_helper
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Application/Common
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Helper loaded: security_helper
INFO - 2024-11-20 22:19:36 --> Helper loaded: wpu_helper
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Database Driver Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Installation/configuration.php.backup
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Envprod/index
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Config/settings.inc.php.backup
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: App/etc
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
ERROR - 2024-11-20 22:19:36 --> Unable to connect to the database
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
INFO - 2024-11-20 22:19:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Env_1/index
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Envdevelopmentlocal/index
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Config Class Initialized
INFO - 2024-11-20 22:19:36 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:36 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> URI Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Router Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Output Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
INFO - 2024-11-20 22:19:36 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
DEBUG - 2024-11-20 22:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:36 --> Input Class Initialized
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Database/config.php.orig
INFO - 2024-11-20 22:19:36 --> Language Class Initialized
ERROR - 2024-11-20 22:19:36 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Tmp/config.php.bak
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Site/default
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Backup/db.php.bak
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Backup/database.php.bak
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: App/settings
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Configphpbak/index
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Envbackup/index
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Envlocal/index
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: App/etc
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Old/config.php
INFO - 2024-11-20 22:19:37 --> Config Class Initialized
INFO - 2024-11-20 22:19:37 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:37 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:37 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:37 --> URI Class Initialized
INFO - 2024-11-20 22:19:37 --> Router Class Initialized
INFO - 2024-11-20 22:19:37 --> Output Class Initialized
INFO - 2024-11-20 22:19:37 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:37 --> Input Class Initialized
INFO - 2024-11-20 22:19:37 --> Language Class Initialized
ERROR - 2024-11-20 22:19:37 --> 404 Page Not Found: Typo3conf/localconf.php.orig
INFO - 2024-11-20 22:19:38 --> Config Class Initialized
INFO - 2024-11-20 22:19:38 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:38 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:38 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:38 --> URI Class Initialized
INFO - 2024-11-20 22:19:38 --> Router Class Initialized
INFO - 2024-11-20 22:19:38 --> Output Class Initialized
INFO - 2024-11-20 22:19:38 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:38 --> Input Class Initialized
INFO - 2024-11-20 22:19:38 --> Language Class Initialized
ERROR - 2024-11-20 22:19:38 --> 404 Page Not Found: Config/security.yml
INFO - 2024-11-20 22:19:38 --> Config Class Initialized
INFO - 2024-11-20 22:19:38 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:19:38 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:19:38 --> Utf8 Class Initialized
INFO - 2024-11-20 22:19:38 --> URI Class Initialized
INFO - 2024-11-20 22:19:38 --> Router Class Initialized
INFO - 2024-11-20 22:19:38 --> Output Class Initialized
INFO - 2024-11-20 22:19:38 --> Security Class Initialized
DEBUG - 2024-11-20 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:19:38 --> Input Class Initialized
INFO - 2024-11-20 22:19:38 --> Language Class Initialized
ERROR - 2024-11-20 22:19:38 --> 404 Page Not Found: App/etc
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Backup/config.php.bak
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Application/Common
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/etc
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Awsenv/index
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/settings
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/config
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Backup/settings.php.bak
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Common/config
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:16 --> Security Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: App/etc
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Config Class Initialized
INFO - 2024-11-20 22:22:16 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:16 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:16 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:16 --> URI Class Initialized
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
DEBUG - 2024-11-20 22:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:16 --> Input Class Initialized
INFO - 2024-11-20 22:22:16 --> Language Class Initialized
ERROR - 2024-11-20 22:22:16 --> 404 Page Not Found: Backup/database.php.bak
INFO - 2024-11-20 22:22:16 --> Router Class Initialized
INFO - 2024-11-20 22:22:16 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: App/etc
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envprodlocal/index
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Db/config.json.bak
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envdev/index
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Common/config
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Caches/configs
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Backup/db.php.bak
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envexample/index
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Config/security.yml
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envdevlocal/index
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envbak/index
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: App/config
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envlive/index
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Env_1/index
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envlocal/index
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Envbackup/index
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Config/settings.inc.php.backup
INFO - 2024-11-20 22:22:17 --> Config Class Initialized
INFO - 2024-11-20 22:22:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:17 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:17 --> URI Class Initialized
INFO - 2024-11-20 22:22:17 --> Router Class Initialized
INFO - 2024-11-20 22:22:17 --> Output Class Initialized
INFO - 2024-11-20 22:22:17 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:17 --> Input Class Initialized
INFO - 2024-11-20 22:22:17 --> Language Class Initialized
ERROR - 2024-11-20 22:22:17 --> 404 Page Not Found: Database/config.php.orig
INFO - 2024-11-20 22:22:18 --> Config Class Initialized
INFO - 2024-11-20 22:22:18 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:18 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:18 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:18 --> URI Class Initialized
INFO - 2024-11-20 22:22:18 --> Router Class Initialized
INFO - 2024-11-20 22:22:18 --> Output Class Initialized
INFO - 2024-11-20 22:22:18 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:18 --> Input Class Initialized
INFO - 2024-11-20 22:22:18 --> Language Class Initialized
ERROR - 2024-11-20 22:22:18 --> 404 Page Not Found: Envold/index
INFO - 2024-11-20 22:22:18 --> Config Class Initialized
INFO - 2024-11-20 22:22:18 --> Hooks Class Initialized
DEBUG - 2024-11-20 22:22:18 --> UTF-8 Support Enabled
INFO - 2024-11-20 22:22:18 --> Utf8 Class Initialized
INFO - 2024-11-20 22:22:18 --> URI Class Initialized
INFO - 2024-11-20 22:22:18 --> Router Class Initialized
INFO - 2024-11-20 22:22:18 --> Output Class Initialized
INFO - 2024-11-20 22:22:18 --> Security Class Initialized
DEBUG - 2024-11-20 22:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 22:22:18 --> Input Class Initialized
INFO - 2024-11-20 22:22:18 --> Language Class Initialized
ERROR - 2024-11-20 22:22:18 --> 404 Page Not Found: Configphpbak/index
