<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-29 00:08:51 --> Config Class Initialized
INFO - 2024-11-29 00:08:51 --> Hooks Class Initialized
DEBUG - 2024-11-29 00:08:51 --> UTF-8 Support Enabled
INFO - 2024-11-29 00:08:51 --> Utf8 Class Initialized
INFO - 2024-11-29 00:08:51 --> URI Class Initialized
DEBUG - 2024-11-29 00:08:51 --> No URI present. Default controller set.
INFO - 2024-11-29 00:08:51 --> Router Class Initialized
INFO - 2024-11-29 00:08:51 --> Output Class Initialized
INFO - 2024-11-29 00:08:51 --> Security Class Initialized
DEBUG - 2024-11-29 00:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 00:08:51 --> Input Class Initialized
INFO - 2024-11-29 00:08:51 --> Language Class Initialized
INFO - 2024-11-29 00:08:51 --> Loader Class Initialized
INFO - 2024-11-29 00:08:51 --> Helper loaded: url_helper
INFO - 2024-11-29 00:08:51 --> Helper loaded: file_helper
INFO - 2024-11-29 00:08:51 --> Helper loaded: security_helper
INFO - 2024-11-29 00:08:51 --> Helper loaded: wpu_helper
INFO - 2024-11-29 00:08:51 --> Database Driver Class Initialized
INFO - 2024-11-29 00:08:51 --> Email Class Initialized
DEBUG - 2024-11-29 00:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 00:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 00:08:51 --> Helper loaded: form_helper
INFO - 2024-11-29 00:08:51 --> Form Validation Class Initialized
INFO - 2024-11-29 00:08:51 --> Controller Class Initialized
DEBUG - 2024-11-29 00:08:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 00:08:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-29 00:08:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-29 00:08:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-29 00:08:51 --> Final output sent to browser
DEBUG - 2024-11-29 00:08:51 --> Total execution time: 0.4874
INFO - 2024-11-29 00:08:54 --> Config Class Initialized
INFO - 2024-11-29 00:08:54 --> Hooks Class Initialized
DEBUG - 2024-11-29 00:08:54 --> UTF-8 Support Enabled
INFO - 2024-11-29 00:08:54 --> Utf8 Class Initialized
INFO - 2024-11-29 00:08:54 --> URI Class Initialized
INFO - 2024-11-29 00:08:54 --> Router Class Initialized
INFO - 2024-11-29 00:08:54 --> Output Class Initialized
INFO - 2024-11-29 00:08:54 --> Security Class Initialized
DEBUG - 2024-11-29 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 00:08:54 --> Input Class Initialized
INFO - 2024-11-29 00:08:54 --> Language Class Initialized
INFO - 2024-11-29 00:08:54 --> Loader Class Initialized
INFO - 2024-11-29 00:08:54 --> Helper loaded: url_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: file_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: security_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: wpu_helper
INFO - 2024-11-29 00:08:54 --> Database Driver Class Initialized
INFO - 2024-11-29 00:08:54 --> Email Class Initialized
DEBUG - 2024-11-29 00:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 00:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 00:08:54 --> Helper loaded: form_helper
INFO - 2024-11-29 00:08:54 --> Form Validation Class Initialized
INFO - 2024-11-29 00:08:54 --> Controller Class Initialized
DEBUG - 2024-11-29 00:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 00:08:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-29 00:08:54 --> Config Class Initialized
INFO - 2024-11-29 00:08:54 --> Hooks Class Initialized
DEBUG - 2024-11-29 00:08:54 --> UTF-8 Support Enabled
INFO - 2024-11-29 00:08:54 --> Utf8 Class Initialized
INFO - 2024-11-29 00:08:54 --> URI Class Initialized
INFO - 2024-11-29 00:08:54 --> Router Class Initialized
INFO - 2024-11-29 00:08:54 --> Output Class Initialized
INFO - 2024-11-29 00:08:54 --> Security Class Initialized
DEBUG - 2024-11-29 00:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 00:08:54 --> Input Class Initialized
INFO - 2024-11-29 00:08:54 --> Language Class Initialized
INFO - 2024-11-29 00:08:54 --> Loader Class Initialized
INFO - 2024-11-29 00:08:54 --> Helper loaded: url_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: file_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: security_helper
INFO - 2024-11-29 00:08:54 --> Helper loaded: wpu_helper
INFO - 2024-11-29 00:08:54 --> Database Driver Class Initialized
INFO - 2024-11-29 00:08:55 --> Email Class Initialized
DEBUG - 2024-11-29 00:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 00:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 00:08:55 --> Helper loaded: form_helper
INFO - 2024-11-29 00:08:55 --> Form Validation Class Initialized
INFO - 2024-11-29 00:08:55 --> Controller Class Initialized
INFO - 2024-11-29 00:08:55 --> Model "Antrol_model" initialized
DEBUG - 2024-11-29 00:08:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 00:08:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-29 00:08:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-29 00:08:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-29 00:08:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-29 00:08:55 --> Final output sent to browser
DEBUG - 2024-11-29 00:08:55 --> Total execution time: 1.1304
INFO - 2024-11-29 00:19:54 --> Config Class Initialized
INFO - 2024-11-29 00:19:54 --> Hooks Class Initialized
DEBUG - 2024-11-29 00:19:54 --> UTF-8 Support Enabled
INFO - 2024-11-29 00:19:54 --> Utf8 Class Initialized
INFO - 2024-11-29 00:19:54 --> URI Class Initialized
DEBUG - 2024-11-29 00:19:54 --> No URI present. Default controller set.
INFO - 2024-11-29 00:19:54 --> Router Class Initialized
INFO - 2024-11-29 00:19:54 --> Output Class Initialized
INFO - 2024-11-29 00:19:54 --> Security Class Initialized
DEBUG - 2024-11-29 00:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 00:19:54 --> Input Class Initialized
INFO - 2024-11-29 00:19:54 --> Language Class Initialized
INFO - 2024-11-29 00:19:54 --> Loader Class Initialized
INFO - 2024-11-29 00:19:54 --> Helper loaded: url_helper
INFO - 2024-11-29 00:19:54 --> Helper loaded: file_helper
INFO - 2024-11-29 00:19:54 --> Helper loaded: security_helper
INFO - 2024-11-29 00:19:54 --> Helper loaded: wpu_helper
INFO - 2024-11-29 00:19:54 --> Database Driver Class Initialized
INFO - 2024-11-29 00:19:55 --> Email Class Initialized
DEBUG - 2024-11-29 00:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 00:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 00:19:55 --> Helper loaded: form_helper
INFO - 2024-11-29 00:19:55 --> Form Validation Class Initialized
INFO - 2024-11-29 00:19:55 --> Controller Class Initialized
DEBUG - 2024-11-29 00:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 00:19:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-29 00:19:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-29 00:19:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-29 00:19:55 --> Final output sent to browser
DEBUG - 2024-11-29 00:19:55 --> Total execution time: 0.4363
INFO - 2024-11-29 02:02:43 --> Config Class Initialized
INFO - 2024-11-29 02:02:43 --> Hooks Class Initialized
DEBUG - 2024-11-29 02:02:43 --> UTF-8 Support Enabled
INFO - 2024-11-29 02:02:43 --> Utf8 Class Initialized
INFO - 2024-11-29 02:02:43 --> URI Class Initialized
INFO - 2024-11-29 02:02:43 --> Router Class Initialized
INFO - 2024-11-29 02:02:43 --> Output Class Initialized
INFO - 2024-11-29 02:02:43 --> Security Class Initialized
DEBUG - 2024-11-29 02:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 02:02:43 --> Input Class Initialized
INFO - 2024-11-29 02:02:43 --> Language Class Initialized
INFO - 2024-11-29 02:02:43 --> Loader Class Initialized
INFO - 2024-11-29 02:02:43 --> Helper loaded: url_helper
INFO - 2024-11-29 02:02:43 --> Helper loaded: file_helper
INFO - 2024-11-29 02:02:43 --> Helper loaded: security_helper
INFO - 2024-11-29 02:02:43 --> Helper loaded: wpu_helper
INFO - 2024-11-29 02:02:43 --> Database Driver Class Initialized
INFO - 2024-11-29 02:02:43 --> Email Class Initialized
DEBUG - 2024-11-29 02:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 02:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 02:02:43 --> Helper loaded: form_helper
INFO - 2024-11-29 02:02:43 --> Form Validation Class Initialized
INFO - 2024-11-29 02:02:43 --> Controller Class Initialized
INFO - 2024-11-29 02:02:43 --> Model "Antrol_model" initialized
DEBUG - 2024-11-29 02:02:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 02:02:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-29 02:02:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-29 02:02:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-29 02:02:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-29 02:02:44 --> Final output sent to browser
DEBUG - 2024-11-29 02:02:44 --> Total execution time: 1.1485
INFO - 2024-11-29 06:29:57 --> Config Class Initialized
INFO - 2024-11-29 06:29:57 --> Hooks Class Initialized
DEBUG - 2024-11-29 06:29:57 --> UTF-8 Support Enabled
INFO - 2024-11-29 06:29:57 --> Utf8 Class Initialized
INFO - 2024-11-29 06:29:57 --> URI Class Initialized
INFO - 2024-11-29 06:29:57 --> Router Class Initialized
INFO - 2024-11-29 06:29:57 --> Output Class Initialized
INFO - 2024-11-29 06:29:57 --> Security Class Initialized
DEBUG - 2024-11-29 06:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 06:29:57 --> Input Class Initialized
INFO - 2024-11-29 06:29:57 --> Language Class Initialized
ERROR - 2024-11-29 06:29:57 --> 404 Page Not Found: Phpinfophp/index
INFO - 2024-11-29 06:29:59 --> Config Class Initialized
INFO - 2024-11-29 06:29:59 --> Hooks Class Initialized
DEBUG - 2024-11-29 06:29:59 --> UTF-8 Support Enabled
INFO - 2024-11-29 06:29:59 --> Utf8 Class Initialized
INFO - 2024-11-29 06:29:59 --> URI Class Initialized
INFO - 2024-11-29 06:29:59 --> Router Class Initialized
INFO - 2024-11-29 06:29:59 --> Output Class Initialized
INFO - 2024-11-29 06:29:59 --> Security Class Initialized
DEBUG - 2024-11-29 06:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 06:29:59 --> Input Class Initialized
INFO - 2024-11-29 06:29:59 --> Language Class Initialized
ERROR - 2024-11-29 06:29:59 --> 404 Page Not Found: _profiler/phpinfo
INFO - 2024-11-29 06:30:01 --> Config Class Initialized
INFO - 2024-11-29 06:30:01 --> Hooks Class Initialized
DEBUG - 2024-11-29 06:30:01 --> UTF-8 Support Enabled
INFO - 2024-11-29 06:30:01 --> Utf8 Class Initialized
INFO - 2024-11-29 06:30:01 --> URI Class Initialized
DEBUG - 2024-11-29 06:30:01 --> No URI present. Default controller set.
INFO - 2024-11-29 06:30:01 --> Router Class Initialized
INFO - 2024-11-29 06:30:01 --> Output Class Initialized
INFO - 2024-11-29 06:30:01 --> Security Class Initialized
DEBUG - 2024-11-29 06:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 06:30:01 --> Input Class Initialized
INFO - 2024-11-29 06:30:01 --> Language Class Initialized
INFO - 2024-11-29 06:30:01 --> Loader Class Initialized
INFO - 2024-11-29 06:30:01 --> Helper loaded: url_helper
INFO - 2024-11-29 06:30:01 --> Helper loaded: file_helper
INFO - 2024-11-29 06:30:01 --> Helper loaded: security_helper
INFO - 2024-11-29 06:30:01 --> Helper loaded: wpu_helper
INFO - 2024-11-29 06:30:01 --> Database Driver Class Initialized
INFO - 2024-11-29 06:30:02 --> Email Class Initialized
DEBUG - 2024-11-29 06:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-29 06:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 06:30:02 --> Helper loaded: form_helper
INFO - 2024-11-29 06:30:02 --> Form Validation Class Initialized
INFO - 2024-11-29 06:30:02 --> Controller Class Initialized
DEBUG - 2024-11-29 06:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-29 06:30:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-29 06:30:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-29 06:30:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-29 06:30:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-29 06:30:02 --> Final output sent to browser
DEBUG - 2024-11-29 06:30:02 --> Total execution time: 0.4192
