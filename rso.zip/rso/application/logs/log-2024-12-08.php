<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-08 02:18:44 --> Config Class Initialized
INFO - 2024-12-08 02:18:44 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:18:44 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:18:44 --> Utf8 Class Initialized
INFO - 2024-12-08 02:18:44 --> URI Class Initialized
DEBUG - 2024-12-08 02:18:44 --> No URI present. Default controller set.
INFO - 2024-12-08 02:18:44 --> Router Class Initialized
INFO - 2024-12-08 02:18:44 --> Output Class Initialized
INFO - 2024-12-08 02:18:44 --> Security Class Initialized
DEBUG - 2024-12-08 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:18:44 --> Input Class Initialized
INFO - 2024-12-08 02:18:44 --> Language Class Initialized
INFO - 2024-12-08 02:18:44 --> Loader Class Initialized
INFO - 2024-12-08 02:18:44 --> Helper loaded: url_helper
INFO - 2024-12-08 02:18:44 --> Helper loaded: file_helper
INFO - 2024-12-08 02:18:44 --> Helper loaded: security_helper
INFO - 2024-12-08 02:18:44 --> Helper loaded: wpu_helper
INFO - 2024-12-08 02:18:44 --> Database Driver Class Initialized
INFO - 2024-12-08 02:18:44 --> Email Class Initialized
DEBUG - 2024-12-08 02:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 02:18:44 --> Helper loaded: form_helper
INFO - 2024-12-08 02:18:44 --> Form Validation Class Initialized
INFO - 2024-12-08 02:18:44 --> Controller Class Initialized
DEBUG - 2024-12-08 02:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-08 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-08 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-08 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-08 02:18:44 --> Final output sent to browser
DEBUG - 2024-12-08 02:18:44 --> Total execution time: 0.4178
INFO - 2024-12-08 02:19:16 --> Config Class Initialized
INFO - 2024-12-08 02:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:16 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:16 --> URI Class Initialized
INFO - 2024-12-08 02:19:16 --> Router Class Initialized
INFO - 2024-12-08 02:19:16 --> Output Class Initialized
INFO - 2024-12-08 02:19:16 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:16 --> Input Class Initialized
INFO - 2024-12-08 02:19:16 --> Language Class Initialized
ERROR - 2024-12-08 02:19:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:16 --> Config Class Initialized
INFO - 2024-12-08 02:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:16 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:16 --> URI Class Initialized
INFO - 2024-12-08 02:19:16 --> Router Class Initialized
INFO - 2024-12-08 02:19:16 --> Output Class Initialized
INFO - 2024-12-08 02:19:16 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:16 --> Input Class Initialized
INFO - 2024-12-08 02:19:16 --> Language Class Initialized
ERROR - 2024-12-08 02:19:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:16 --> Config Class Initialized
INFO - 2024-12-08 02:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:16 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:16 --> URI Class Initialized
INFO - 2024-12-08 02:19:16 --> Router Class Initialized
INFO - 2024-12-08 02:19:16 --> Output Class Initialized
INFO - 2024-12-08 02:19:16 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:16 --> Input Class Initialized
INFO - 2024-12-08 02:19:16 --> Language Class Initialized
ERROR - 2024-12-08 02:19:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:16 --> Config Class Initialized
INFO - 2024-12-08 02:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:16 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:16 --> URI Class Initialized
INFO - 2024-12-08 02:19:16 --> Router Class Initialized
INFO - 2024-12-08 02:19:16 --> Output Class Initialized
INFO - 2024-12-08 02:19:16 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:16 --> Input Class Initialized
INFO - 2024-12-08 02:19:16 --> Language Class Initialized
ERROR - 2024-12-08 02:19:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:16 --> Config Class Initialized
INFO - 2024-12-08 02:19:16 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:16 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:16 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:16 --> URI Class Initialized
INFO - 2024-12-08 02:19:16 --> Router Class Initialized
INFO - 2024-12-08 02:19:16 --> Output Class Initialized
INFO - 2024-12-08 02:19:16 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:16 --> Input Class Initialized
INFO - 2024-12-08 02:19:16 --> Language Class Initialized
ERROR - 2024-12-08 02:19:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 02:19:57 --> Config Class Initialized
INFO - 2024-12-08 02:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:57 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:57 --> URI Class Initialized
INFO - 2024-12-08 02:19:57 --> Router Class Initialized
INFO - 2024-12-08 02:19:57 --> Output Class Initialized
INFO - 2024-12-08 02:19:57 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:57 --> Input Class Initialized
INFO - 2024-12-08 02:19:57 --> Language Class Initialized
ERROR - 2024-12-08 02:19:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:57 --> Config Class Initialized
INFO - 2024-12-08 02:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:57 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:57 --> URI Class Initialized
INFO - 2024-12-08 02:19:57 --> Router Class Initialized
INFO - 2024-12-08 02:19:57 --> Output Class Initialized
INFO - 2024-12-08 02:19:57 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:57 --> Input Class Initialized
INFO - 2024-12-08 02:19:57 --> Language Class Initialized
ERROR - 2024-12-08 02:19:57 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 02:19:57 --> Config Class Initialized
INFO - 2024-12-08 02:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:57 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:57 --> URI Class Initialized
INFO - 2024-12-08 02:19:57 --> Router Class Initialized
INFO - 2024-12-08 02:19:57 --> Config Class Initialized
INFO - 2024-12-08 02:19:57 --> Hooks Class Initialized
INFO - 2024-12-08 02:19:57 --> Output Class Initialized
DEBUG - 2024-12-08 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:57 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:57 --> Security Class Initialized
INFO - 2024-12-08 02:19:57 --> URI Class Initialized
INFO - 2024-12-08 02:19:57 --> Router Class Initialized
DEBUG - 2024-12-08 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:57 --> Input Class Initialized
INFO - 2024-12-08 02:19:57 --> Language Class Initialized
ERROR - 2024-12-08 02:19:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:57 --> Output Class Initialized
INFO - 2024-12-08 02:19:57 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:57 --> Input Class Initialized
INFO - 2024-12-08 02:19:57 --> Language Class Initialized
ERROR - 2024-12-08 02:19:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:19:57 --> Config Class Initialized
INFO - 2024-12-08 02:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:19:57 --> Utf8 Class Initialized
INFO - 2024-12-08 02:19:57 --> URI Class Initialized
INFO - 2024-12-08 02:19:57 --> Router Class Initialized
INFO - 2024-12-08 02:19:57 --> Output Class Initialized
INFO - 2024-12-08 02:19:57 --> Security Class Initialized
DEBUG - 2024-12-08 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:19:57 --> Input Class Initialized
INFO - 2024-12-08 02:19:57 --> Language Class Initialized
ERROR - 2024-12-08 02:19:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:20:48 --> Config Class Initialized
INFO - 2024-12-08 02:20:48 --> Config Class Initialized
INFO - 2024-12-08 02:20:48 --> Hooks Class Initialized
INFO - 2024-12-08 02:20:48 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:20:48 --> Utf8 Class Initialized
DEBUG - 2024-12-08 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:20:48 --> Utf8 Class Initialized
INFO - 2024-12-08 02:20:48 --> URI Class Initialized
INFO - 2024-12-08 02:20:48 --> Config Class Initialized
INFO - 2024-12-08 02:20:48 --> Hooks Class Initialized
INFO - 2024-12-08 02:20:48 --> Router Class Initialized
INFO - 2024-12-08 02:20:48 --> URI Class Initialized
DEBUG - 2024-12-08 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:20:48 --> Utf8 Class Initialized
INFO - 2024-12-08 02:20:48 --> Output Class Initialized
INFO - 2024-12-08 02:20:48 --> Router Class Initialized
INFO - 2024-12-08 02:20:48 --> URI Class Initialized
INFO - 2024-12-08 02:20:48 --> Security Class Initialized
INFO - 2024-12-08 02:20:48 --> Output Class Initialized
INFO - 2024-12-08 02:20:48 --> Router Class Initialized
DEBUG - 2024-12-08 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:20:48 --> Input Class Initialized
INFO - 2024-12-08 02:20:48 --> Language Class Initialized
ERROR - 2024-12-08 02:20:48 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 02:20:48 --> Security Class Initialized
INFO - 2024-12-08 02:20:48 --> Output Class Initialized
DEBUG - 2024-12-08 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:20:48 --> Input Class Initialized
INFO - 2024-12-08 02:20:48 --> Language Class Initialized
INFO - 2024-12-08 02:20:48 --> Security Class Initialized
ERROR - 2024-12-08 02:20:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-08 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:20:48 --> Input Class Initialized
INFO - 2024-12-08 02:20:48 --> Language Class Initialized
ERROR - 2024-12-08 02:20:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:20:48 --> Config Class Initialized
INFO - 2024-12-08 02:20:48 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:20:48 --> Utf8 Class Initialized
INFO - 2024-12-08 02:20:48 --> URI Class Initialized
INFO - 2024-12-08 02:20:48 --> Router Class Initialized
INFO - 2024-12-08 02:20:48 --> Output Class Initialized
INFO - 2024-12-08 02:20:48 --> Security Class Initialized
INFO - 2024-12-08 02:20:48 --> Config Class Initialized
INFO - 2024-12-08 02:20:48 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:20:48 --> Input Class Initialized
INFO - 2024-12-08 02:20:48 --> Language Class Initialized
ERROR - 2024-12-08 02:20:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-08 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:20:48 --> Utf8 Class Initialized
INFO - 2024-12-08 02:20:48 --> URI Class Initialized
INFO - 2024-12-08 02:20:48 --> Router Class Initialized
INFO - 2024-12-08 02:20:48 --> Output Class Initialized
INFO - 2024-12-08 02:20:48 --> Security Class Initialized
DEBUG - 2024-12-08 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:20:48 --> Input Class Initialized
INFO - 2024-12-08 02:20:48 --> Language Class Initialized
ERROR - 2024-12-08 02:20:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:21:30 --> Config Class Initialized
INFO - 2024-12-08 02:21:30 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:21:30 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:21:30 --> Utf8 Class Initialized
INFO - 2024-12-08 02:21:30 --> URI Class Initialized
INFO - 2024-12-08 02:21:30 --> Router Class Initialized
INFO - 2024-12-08 02:21:30 --> Output Class Initialized
INFO - 2024-12-08 02:21:30 --> Security Class Initialized
DEBUG - 2024-12-08 02:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:21:30 --> Input Class Initialized
INFO - 2024-12-08 02:21:30 --> Language Class Initialized
ERROR - 2024-12-08 02:21:30 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 02:21:30 --> Config Class Initialized
INFO - 2024-12-08 02:21:30 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:21:30 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:21:30 --> Utf8 Class Initialized
INFO - 2024-12-08 02:21:30 --> URI Class Initialized
INFO - 2024-12-08 02:21:30 --> Router Class Initialized
INFO - 2024-12-08 02:21:30 --> Output Class Initialized
INFO - 2024-12-08 02:21:30 --> Security Class Initialized
DEBUG - 2024-12-08 02:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:21:30 --> Input Class Initialized
INFO - 2024-12-08 02:21:30 --> Language Class Initialized
ERROR - 2024-12-08 02:21:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:21:30 --> Config Class Initialized
INFO - 2024-12-08 02:21:30 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:21:30 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:21:30 --> Utf8 Class Initialized
INFO - 2024-12-08 02:21:30 --> URI Class Initialized
INFO - 2024-12-08 02:21:30 --> Router Class Initialized
INFO - 2024-12-08 02:21:30 --> Config Class Initialized
INFO - 2024-12-08 02:21:30 --> Hooks Class Initialized
INFO - 2024-12-08 02:21:30 --> Output Class Initialized
DEBUG - 2024-12-08 02:21:30 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:21:30 --> Utf8 Class Initialized
INFO - 2024-12-08 02:21:30 --> Security Class Initialized
INFO - 2024-12-08 02:21:30 --> URI Class Initialized
DEBUG - 2024-12-08 02:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:21:30 --> Input Class Initialized
INFO - 2024-12-08 02:21:30 --> Router Class Initialized
INFO - 2024-12-08 02:21:30 --> Language Class Initialized
ERROR - 2024-12-08 02:21:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:21:30 --> Output Class Initialized
INFO - 2024-12-08 02:21:30 --> Security Class Initialized
DEBUG - 2024-12-08 02:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:21:30 --> Input Class Initialized
INFO - 2024-12-08 02:21:30 --> Language Class Initialized
ERROR - 2024-12-08 02:21:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:21:34 --> Config Class Initialized
INFO - 2024-12-08 02:21:34 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:21:34 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:21:34 --> Utf8 Class Initialized
INFO - 2024-12-08 02:21:34 --> URI Class Initialized
INFO - 2024-12-08 02:21:34 --> Router Class Initialized
INFO - 2024-12-08 02:21:34 --> Output Class Initialized
INFO - 2024-12-08 02:21:34 --> Security Class Initialized
DEBUG - 2024-12-08 02:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:21:34 --> Input Class Initialized
INFO - 2024-12-08 02:21:34 --> Language Class Initialized
ERROR - 2024-12-08 02:21:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:22:24 --> Config Class Initialized
INFO - 2024-12-08 02:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:22:24 --> Utf8 Class Initialized
INFO - 2024-12-08 02:22:24 --> URI Class Initialized
INFO - 2024-12-08 02:22:24 --> Router Class Initialized
INFO - 2024-12-08 02:22:24 --> Output Class Initialized
INFO - 2024-12-08 02:22:24 --> Security Class Initialized
DEBUG - 2024-12-08 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:22:24 --> Input Class Initialized
INFO - 2024-12-08 02:22:24 --> Language Class Initialized
ERROR - 2024-12-08 02:22:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:22:24 --> Config Class Initialized
INFO - 2024-12-08 02:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:22:24 --> Utf8 Class Initialized
INFO - 2024-12-08 02:22:24 --> URI Class Initialized
INFO - 2024-12-08 02:22:24 --> Router Class Initialized
INFO - 2024-12-08 02:22:24 --> Config Class Initialized
INFO - 2024-12-08 02:22:24 --> Hooks Class Initialized
INFO - 2024-12-08 02:22:24 --> Output Class Initialized
DEBUG - 2024-12-08 02:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:22:24 --> Utf8 Class Initialized
INFO - 2024-12-08 02:22:24 --> Security Class Initialized
INFO - 2024-12-08 02:22:24 --> URI Class Initialized
DEBUG - 2024-12-08 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:22:24 --> Input Class Initialized
INFO - 2024-12-08 02:22:24 --> Language Class Initialized
INFO - 2024-12-08 02:22:24 --> Router Class Initialized
ERROR - 2024-12-08 02:22:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:22:24 --> Output Class Initialized
INFO - 2024-12-08 02:22:24 --> Security Class Initialized
DEBUG - 2024-12-08 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:22:24 --> Input Class Initialized
INFO - 2024-12-08 02:22:24 --> Language Class Initialized
ERROR - 2024-12-08 02:22:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:22:24 --> Config Class Initialized
INFO - 2024-12-08 02:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:22:24 --> Utf8 Class Initialized
INFO - 2024-12-08 02:22:24 --> URI Class Initialized
INFO - 2024-12-08 02:22:24 --> Router Class Initialized
INFO - 2024-12-08 02:22:24 --> Output Class Initialized
INFO - 2024-12-08 02:22:24 --> Security Class Initialized
DEBUG - 2024-12-08 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:22:24 --> Input Class Initialized
INFO - 2024-12-08 02:22:24 --> Language Class Initialized
ERROR - 2024-12-08 02:22:24 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 02:22:24 --> Config Class Initialized
INFO - 2024-12-08 02:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:22:24 --> Utf8 Class Initialized
INFO - 2024-12-08 02:22:24 --> URI Class Initialized
INFO - 2024-12-08 02:22:24 --> Router Class Initialized
INFO - 2024-12-08 02:22:24 --> Output Class Initialized
INFO - 2024-12-08 02:22:24 --> Security Class Initialized
DEBUG - 2024-12-08 02:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:22:24 --> Input Class Initialized
INFO - 2024-12-08 02:22:25 --> Language Class Initialized
ERROR - 2024-12-08 02:22:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:23:27 --> Config Class Initialized
INFO - 2024-12-08 02:23:27 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:23:27 --> Utf8 Class Initialized
INFO - 2024-12-08 02:23:27 --> URI Class Initialized
INFO - 2024-12-08 02:23:27 --> Router Class Initialized
INFO - 2024-12-08 02:23:27 --> Config Class Initialized
INFO - 2024-12-08 02:23:27 --> Hooks Class Initialized
INFO - 2024-12-08 02:23:27 --> Output Class Initialized
DEBUG - 2024-12-08 02:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:23:27 --> Utf8 Class Initialized
INFO - 2024-12-08 02:23:27 --> Security Class Initialized
INFO - 2024-12-08 02:23:27 --> URI Class Initialized
DEBUG - 2024-12-08 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:23:27 --> Input Class Initialized
INFO - 2024-12-08 02:23:27 --> Language Class Initialized
ERROR - 2024-12-08 02:23:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:23:27 --> Router Class Initialized
INFO - 2024-12-08 02:23:27 --> Output Class Initialized
INFO - 2024-12-08 02:23:27 --> Security Class Initialized
DEBUG - 2024-12-08 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:23:27 --> Input Class Initialized
INFO - 2024-12-08 02:23:27 --> Language Class Initialized
ERROR - 2024-12-08 02:23:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:23:27 --> Config Class Initialized
INFO - 2024-12-08 02:23:27 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:23:27 --> Utf8 Class Initialized
INFO - 2024-12-08 02:23:27 --> URI Class Initialized
INFO - 2024-12-08 02:23:27 --> Router Class Initialized
INFO - 2024-12-08 02:23:27 --> Output Class Initialized
INFO - 2024-12-08 02:23:27 --> Security Class Initialized
DEBUG - 2024-12-08 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:23:27 --> Input Class Initialized
INFO - 2024-12-08 02:23:27 --> Language Class Initialized
ERROR - 2024-12-08 02:23:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:23:27 --> Config Class Initialized
INFO - 2024-12-08 02:23:27 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:23:27 --> Utf8 Class Initialized
INFO - 2024-12-08 02:23:27 --> URI Class Initialized
INFO - 2024-12-08 02:23:27 --> Router Class Initialized
INFO - 2024-12-08 02:23:27 --> Output Class Initialized
INFO - 2024-12-08 02:23:27 --> Security Class Initialized
DEBUG - 2024-12-08 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:23:27 --> Input Class Initialized
INFO - 2024-12-08 02:23:27 --> Language Class Initialized
ERROR - 2024-12-08 02:23:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 02:23:27 --> Config Class Initialized
INFO - 2024-12-08 02:23:27 --> Hooks Class Initialized
DEBUG - 2024-12-08 02:23:27 --> UTF-8 Support Enabled
INFO - 2024-12-08 02:23:27 --> Utf8 Class Initialized
INFO - 2024-12-08 02:23:27 --> URI Class Initialized
INFO - 2024-12-08 02:23:27 --> Router Class Initialized
INFO - 2024-12-08 02:23:27 --> Output Class Initialized
INFO - 2024-12-08 02:23:27 --> Security Class Initialized
DEBUG - 2024-12-08 02:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 02:23:27 --> Input Class Initialized
INFO - 2024-12-08 02:23:27 --> Language Class Initialized
ERROR - 2024-12-08 02:23:27 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:22:08 --> Config Class Initialized
INFO - 2024-12-08 03:22:08 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:22:08 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:08 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:08 --> URI Class Initialized
DEBUG - 2024-12-08 03:22:08 --> No URI present. Default controller set.
INFO - 2024-12-08 03:22:08 --> Router Class Initialized
INFO - 2024-12-08 03:22:08 --> Output Class Initialized
INFO - 2024-12-08 03:22:08 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:08 --> Input Class Initialized
INFO - 2024-12-08 03:22:08 --> Language Class Initialized
INFO - 2024-12-08 03:22:08 --> Loader Class Initialized
INFO - 2024-12-08 03:22:08 --> Helper loaded: url_helper
INFO - 2024-12-08 03:22:08 --> Helper loaded: file_helper
INFO - 2024-12-08 03:22:08 --> Helper loaded: security_helper
INFO - 2024-12-08 03:22:08 --> Helper loaded: wpu_helper
INFO - 2024-12-08 03:22:08 --> Database Driver Class Initialized
INFO - 2024-12-08 03:22:08 --> Email Class Initialized
DEBUG - 2024-12-08 03:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 03:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 03:22:08 --> Helper loaded: form_helper
INFO - 2024-12-08 03:22:08 --> Form Validation Class Initialized
INFO - 2024-12-08 03:22:08 --> Controller Class Initialized
DEBUG - 2024-12-08 03:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-08 03:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-08 03:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-08 03:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-08 03:22:08 --> Final output sent to browser
DEBUG - 2024-12-08 03:22:08 --> Total execution time: 0.4500
INFO - 2024-12-08 03:22:35 --> Config Class Initialized
INFO - 2024-12-08 03:22:35 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:22:35 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:35 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:35 --> URI Class Initialized
INFO - 2024-12-08 03:22:35 --> Router Class Initialized
INFO - 2024-12-08 03:22:35 --> Output Class Initialized
INFO - 2024-12-08 03:22:35 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:35 --> Input Class Initialized
INFO - 2024-12-08 03:22:35 --> Language Class Initialized
ERROR - 2024-12-08 03:22:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:22:35 --> Config Class Initialized
INFO - 2024-12-08 03:22:35 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:22:35 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:35 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:35 --> URI Class Initialized
INFO - 2024-12-08 03:22:35 --> Router Class Initialized
INFO - 2024-12-08 03:22:35 --> Output Class Initialized
INFO - 2024-12-08 03:22:35 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:35 --> Input Class Initialized
INFO - 2024-12-08 03:22:35 --> Language Class Initialized
ERROR - 2024-12-08 03:22:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:22:35 --> Config Class Initialized
INFO - 2024-12-08 03:22:35 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:22:35 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:35 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:35 --> URI Class Initialized
INFO - 2024-12-08 03:22:35 --> Router Class Initialized
INFO - 2024-12-08 03:22:35 --> Output Class Initialized
INFO - 2024-12-08 03:22:35 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:35 --> Input Class Initialized
INFO - 2024-12-08 03:22:35 --> Language Class Initialized
ERROR - 2024-12-08 03:22:35 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:22:36 --> Config Class Initialized
INFO - 2024-12-08 03:22:36 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:22:36 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:36 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:36 --> URI Class Initialized
INFO - 2024-12-08 03:22:36 --> Router Class Initialized
INFO - 2024-12-08 03:22:36 --> Output Class Initialized
INFO - 2024-12-08 03:22:36 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:36 --> Input Class Initialized
INFO - 2024-12-08 03:22:36 --> Language Class Initialized
INFO - 2024-12-08 03:22:36 --> Config Class Initialized
INFO - 2024-12-08 03:22:36 --> Hooks Class Initialized
ERROR - 2024-12-08 03:22:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-08 03:22:36 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:22:36 --> Utf8 Class Initialized
INFO - 2024-12-08 03:22:36 --> URI Class Initialized
INFO - 2024-12-08 03:22:36 --> Router Class Initialized
INFO - 2024-12-08 03:22:36 --> Output Class Initialized
INFO - 2024-12-08 03:22:36 --> Security Class Initialized
DEBUG - 2024-12-08 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:22:36 --> Input Class Initialized
INFO - 2024-12-08 03:22:36 --> Language Class Initialized
ERROR - 2024-12-08 03:22:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:12 --> Config Class Initialized
INFO - 2024-12-08 03:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:12 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:12 --> Config Class Initialized
INFO - 2024-12-08 03:23:12 --> Hooks Class Initialized
INFO - 2024-12-08 03:23:12 --> URI Class Initialized
INFO - 2024-12-08 03:23:12 --> Router Class Initialized
DEBUG - 2024-12-08 03:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:12 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:12 --> Config Class Initialized
INFO - 2024-12-08 03:23:12 --> Hooks Class Initialized
INFO - 2024-12-08 03:23:12 --> URI Class Initialized
INFO - 2024-12-08 03:23:12 --> Output Class Initialized
INFO - 2024-12-08 03:23:12 --> Router Class Initialized
DEBUG - 2024-12-08 03:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:12 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:12 --> Security Class Initialized
INFO - 2024-12-08 03:23:12 --> URI Class Initialized
INFO - 2024-12-08 03:23:12 --> Output Class Initialized
DEBUG - 2024-12-08 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:12 --> Input Class Initialized
INFO - 2024-12-08 03:23:12 --> Router Class Initialized
INFO - 2024-12-08 03:23:12 --> Language Class Initialized
INFO - 2024-12-08 03:23:12 --> Security Class Initialized
ERROR - 2024-12-08 03:23:12 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:12 --> Output Class Initialized
DEBUG - 2024-12-08 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:12 --> Input Class Initialized
INFO - 2024-12-08 03:23:12 --> Language Class Initialized
ERROR - 2024-12-08 03:23:12 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:12 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:12 --> Input Class Initialized
INFO - 2024-12-08 03:23:12 --> Language Class Initialized
ERROR - 2024-12-08 03:23:12 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:23:12 --> Config Class Initialized
INFO - 2024-12-08 03:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:12 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:12 --> URI Class Initialized
INFO - 2024-12-08 03:23:12 --> Router Class Initialized
INFO - 2024-12-08 03:23:12 --> Output Class Initialized
INFO - 2024-12-08 03:23:12 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:12 --> Input Class Initialized
INFO - 2024-12-08 03:23:12 --> Language Class Initialized
ERROR - 2024-12-08 03:23:12 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:13 --> Config Class Initialized
INFO - 2024-12-08 03:23:13 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:13 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:13 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:13 --> URI Class Initialized
INFO - 2024-12-08 03:23:13 --> Router Class Initialized
INFO - 2024-12-08 03:23:13 --> Output Class Initialized
INFO - 2024-12-08 03:23:13 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:13 --> Input Class Initialized
INFO - 2024-12-08 03:23:13 --> Language Class Initialized
ERROR - 2024-12-08 03:23:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:47 --> Config Class Initialized
INFO - 2024-12-08 03:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:47 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:47 --> URI Class Initialized
INFO - 2024-12-08 03:23:47 --> Router Class Initialized
INFO - 2024-12-08 03:23:47 --> Output Class Initialized
INFO - 2024-12-08 03:23:47 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:47 --> Input Class Initialized
INFO - 2024-12-08 03:23:47 --> Language Class Initialized
ERROR - 2024-12-08 03:23:47 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:23:47 --> Config Class Initialized
INFO - 2024-12-08 03:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:47 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:47 --> URI Class Initialized
INFO - 2024-12-08 03:23:47 --> Router Class Initialized
INFO - 2024-12-08 03:23:47 --> Output Class Initialized
INFO - 2024-12-08 03:23:47 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:47 --> Input Class Initialized
INFO - 2024-12-08 03:23:47 --> Language Class Initialized
ERROR - 2024-12-08 03:23:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:47 --> Config Class Initialized
INFO - 2024-12-08 03:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:47 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:47 --> URI Class Initialized
INFO - 2024-12-08 03:23:47 --> Router Class Initialized
INFO - 2024-12-08 03:23:47 --> Output Class Initialized
INFO - 2024-12-08 03:23:47 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:47 --> Input Class Initialized
INFO - 2024-12-08 03:23:47 --> Language Class Initialized
ERROR - 2024-12-08 03:23:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:47 --> Config Class Initialized
INFO - 2024-12-08 03:23:47 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:47 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:47 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:47 --> URI Class Initialized
INFO - 2024-12-08 03:23:47 --> Router Class Initialized
INFO - 2024-12-08 03:23:47 --> Output Class Initialized
INFO - 2024-12-08 03:23:47 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:47 --> Input Class Initialized
INFO - 2024-12-08 03:23:47 --> Language Class Initialized
ERROR - 2024-12-08 03:23:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:23:48 --> Config Class Initialized
INFO - 2024-12-08 03:23:48 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:23:48 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:23:48 --> Utf8 Class Initialized
INFO - 2024-12-08 03:23:48 --> URI Class Initialized
INFO - 2024-12-08 03:23:48 --> Router Class Initialized
INFO - 2024-12-08 03:23:48 --> Output Class Initialized
INFO - 2024-12-08 03:23:48 --> Security Class Initialized
DEBUG - 2024-12-08 03:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:23:48 --> Input Class Initialized
INFO - 2024-12-08 03:23:48 --> Language Class Initialized
ERROR - 2024-12-08 03:23:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:23 --> Config Class Initialized
INFO - 2024-12-08 03:24:23 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:23 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:23 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:23 --> URI Class Initialized
INFO - 2024-12-08 03:24:23 --> Router Class Initialized
INFO - 2024-12-08 03:24:23 --> Output Class Initialized
INFO - 2024-12-08 03:24:23 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:23 --> Input Class Initialized
INFO - 2024-12-08 03:24:23 --> Language Class Initialized
ERROR - 2024-12-08 03:24:23 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:24:23 --> Config Class Initialized
INFO - 2024-12-08 03:24:23 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:23 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:23 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:23 --> URI Class Initialized
INFO - 2024-12-08 03:24:23 --> Router Class Initialized
INFO - 2024-12-08 03:24:23 --> Config Class Initialized
INFO - 2024-12-08 03:24:23 --> Hooks Class Initialized
INFO - 2024-12-08 03:24:23 --> Output Class Initialized
DEBUG - 2024-12-08 03:24:23 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:23 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:23 --> Security Class Initialized
INFO - 2024-12-08 03:24:23 --> URI Class Initialized
DEBUG - 2024-12-08 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:23 --> Router Class Initialized
INFO - 2024-12-08 03:24:23 --> Input Class Initialized
INFO - 2024-12-08 03:24:23 --> Language Class Initialized
INFO - 2024-12-08 03:24:23 --> Output Class Initialized
ERROR - 2024-12-08 03:24:23 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:23 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:23 --> Input Class Initialized
INFO - 2024-12-08 03:24:23 --> Language Class Initialized
ERROR - 2024-12-08 03:24:23 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:24 --> Config Class Initialized
INFO - 2024-12-08 03:24:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:24 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:24 --> URI Class Initialized
INFO - 2024-12-08 03:24:24 --> Router Class Initialized
INFO - 2024-12-08 03:24:24 --> Output Class Initialized
INFO - 2024-12-08 03:24:24 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:24 --> Input Class Initialized
INFO - 2024-12-08 03:24:24 --> Language Class Initialized
ERROR - 2024-12-08 03:24:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:24 --> Config Class Initialized
INFO - 2024-12-08 03:24:24 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:24 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:24 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:24 --> URI Class Initialized
INFO - 2024-12-08 03:24:24 --> Router Class Initialized
INFO - 2024-12-08 03:24:24 --> Output Class Initialized
INFO - 2024-12-08 03:24:24 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:24 --> Input Class Initialized
INFO - 2024-12-08 03:24:24 --> Language Class Initialized
ERROR - 2024-12-08 03:24:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:55 --> Config Class Initialized
INFO - 2024-12-08 03:24:55 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:55 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:55 --> URI Class Initialized
INFO - 2024-12-08 03:24:55 --> Router Class Initialized
INFO - 2024-12-08 03:24:55 --> Output Class Initialized
INFO - 2024-12-08 03:24:55 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:55 --> Input Class Initialized
INFO - 2024-12-08 03:24:55 --> Language Class Initialized
ERROR - 2024-12-08 03:24:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:55 --> Config Class Initialized
INFO - 2024-12-08 03:24:55 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:55 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:55 --> URI Class Initialized
INFO - 2024-12-08 03:24:55 --> Router Class Initialized
INFO - 2024-12-08 03:24:55 --> Output Class Initialized
INFO - 2024-12-08 03:24:55 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:55 --> Input Class Initialized
INFO - 2024-12-08 03:24:55 --> Language Class Initialized
ERROR - 2024-12-08 03:24:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:55 --> Config Class Initialized
INFO - 2024-12-08 03:24:55 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:55 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:55 --> URI Class Initialized
INFO - 2024-12-08 03:24:55 --> Router Class Initialized
INFO - 2024-12-08 03:24:55 --> Output Class Initialized
INFO - 2024-12-08 03:24:55 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:55 --> Input Class Initialized
INFO - 2024-12-08 03:24:55 --> Language Class Initialized
ERROR - 2024-12-08 03:24:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:24:55 --> Config Class Initialized
INFO - 2024-12-08 03:24:55 --> Hooks Class Initialized
INFO - 2024-12-08 03:24:55 --> Config Class Initialized
INFO - 2024-12-08 03:24:55 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:55 --> Utf8 Class Initialized
DEBUG - 2024-12-08 03:24:55 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:24:55 --> Utf8 Class Initialized
INFO - 2024-12-08 03:24:55 --> URI Class Initialized
INFO - 2024-12-08 03:24:55 --> URI Class Initialized
INFO - 2024-12-08 03:24:55 --> Router Class Initialized
INFO - 2024-12-08 03:24:55 --> Router Class Initialized
INFO - 2024-12-08 03:24:56 --> Output Class Initialized
INFO - 2024-12-08 03:24:56 --> Output Class Initialized
INFO - 2024-12-08 03:24:56 --> Security Class Initialized
INFO - 2024-12-08 03:24:56 --> Security Class Initialized
DEBUG - 2024-12-08 03:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:56 --> Input Class Initialized
INFO - 2024-12-08 03:24:56 --> Language Class Initialized
ERROR - 2024-12-08 03:24:56 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-12-08 03:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:24:56 --> Input Class Initialized
INFO - 2024-12-08 03:24:56 --> Language Class Initialized
ERROR - 2024-12-08 03:24:56 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:25:29 --> Config Class Initialized
INFO - 2024-12-08 03:25:29 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:25:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:25:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:25:29 --> Config Class Initialized
INFO - 2024-12-08 03:25:29 --> Hooks Class Initialized
INFO - 2024-12-08 03:25:29 --> URI Class Initialized
DEBUG - 2024-12-08 03:25:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:25:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:25:29 --> Router Class Initialized
INFO - 2024-12-08 03:25:29 --> Config Class Initialized
INFO - 2024-12-08 03:25:29 --> Hooks Class Initialized
INFO - 2024-12-08 03:25:29 --> URI Class Initialized
INFO - 2024-12-08 03:25:29 --> Output Class Initialized
DEBUG - 2024-12-08 03:25:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:25:29 --> Router Class Initialized
INFO - 2024-12-08 03:25:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:25:29 --> Security Class Initialized
INFO - 2024-12-08 03:25:29 --> URI Class Initialized
INFO - 2024-12-08 03:25:29 --> Output Class Initialized
INFO - 2024-12-08 03:25:29 --> Router Class Initialized
DEBUG - 2024-12-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:25:29 --> Input Class Initialized
INFO - 2024-12-08 03:25:29 --> Language Class Initialized
INFO - 2024-12-08 03:25:29 --> Security Class Initialized
ERROR - 2024-12-08 03:25:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:25:29 --> Config Class Initialized
INFO - 2024-12-08 03:25:29 --> Hooks Class Initialized
INFO - 2024-12-08 03:25:29 --> Output Class Initialized
DEBUG - 2024-12-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:25:29 --> Input Class Initialized
DEBUG - 2024-12-08 03:25:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:25:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:25:29 --> Language Class Initialized
INFO - 2024-12-08 03:25:29 --> Security Class Initialized
ERROR - 2024-12-08 03:25:29 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-08 03:25:29 --> URI Class Initialized
INFO - 2024-12-08 03:25:29 --> Router Class Initialized
DEBUG - 2024-12-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:25:29 --> Input Class Initialized
INFO - 2024-12-08 03:25:29 --> Language Class Initialized
INFO - 2024-12-08 03:25:29 --> Output Class Initialized
ERROR - 2024-12-08 03:25:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:25:29 --> Security Class Initialized
DEBUG - 2024-12-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:25:29 --> Input Class Initialized
INFO - 2024-12-08 03:25:29 --> Language Class Initialized
ERROR - 2024-12-08 03:25:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 03:25:29 --> Config Class Initialized
INFO - 2024-12-08 03:25:29 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:25:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:25:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:25:29 --> URI Class Initialized
INFO - 2024-12-08 03:25:29 --> Router Class Initialized
INFO - 2024-12-08 03:25:29 --> Output Class Initialized
INFO - 2024-12-08 03:25:29 --> Security Class Initialized
DEBUG - 2024-12-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:25:29 --> Input Class Initialized
INFO - 2024-12-08 03:25:29 --> Language Class Initialized
ERROR - 2024-12-08 03:25:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-08 08:29:49 --> Config Class Initialized
INFO - 2024-12-08 08:29:49 --> Hooks Class Initialized
DEBUG - 2024-12-08 08:29:49 --> UTF-8 Support Enabled
INFO - 2024-12-08 08:29:49 --> Utf8 Class Initialized
INFO - 2024-12-08 08:29:49 --> URI Class Initialized
INFO - 2024-12-08 08:29:49 --> Router Class Initialized
INFO - 2024-12-08 08:29:49 --> Output Class Initialized
INFO - 2024-12-08 08:29:49 --> Security Class Initialized
DEBUG - 2024-12-08 08:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 08:29:49 --> Input Class Initialized
INFO - 2024-12-08 08:29:49 --> Language Class Initialized
ERROR - 2024-12-08 08:29:49 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-08 08:29:57 --> Config Class Initialized
INFO - 2024-12-08 08:29:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 08:29:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 08:29:57 --> Utf8 Class Initialized
INFO - 2024-12-08 08:29:57 --> URI Class Initialized
INFO - 2024-12-08 08:29:57 --> Router Class Initialized
INFO - 2024-12-08 08:29:57 --> Output Class Initialized
INFO - 2024-12-08 08:29:57 --> Security Class Initialized
DEBUG - 2024-12-08 08:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 08:29:57 --> Input Class Initialized
INFO - 2024-12-08 08:29:57 --> Language Class Initialized
ERROR - 2024-12-08 08:29:57 --> 404 Page Not Found: Sitemaptxt/index
INFO - 2024-12-08 08:29:57 --> Config Class Initialized
INFO - 2024-12-08 08:29:57 --> Hooks Class Initialized
DEBUG - 2024-12-08 08:29:57 --> UTF-8 Support Enabled
INFO - 2024-12-08 08:29:57 --> Utf8 Class Initialized
INFO - 2024-12-08 08:29:57 --> URI Class Initialized
INFO - 2024-12-08 08:29:57 --> Router Class Initialized
INFO - 2024-12-08 08:29:57 --> Output Class Initialized
INFO - 2024-12-08 08:29:57 --> Security Class Initialized
DEBUG - 2024-12-08 08:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 08:29:57 --> Input Class Initialized
INFO - 2024-12-08 08:29:57 --> Language Class Initialized
ERROR - 2024-12-08 08:29:57 --> 404 Page Not Found: Sitemapxmlgz/index
INFO - 2024-12-08 08:29:58 --> Config Class Initialized
INFO - 2024-12-08 08:29:58 --> Hooks Class Initialized
DEBUG - 2024-12-08 08:29:58 --> UTF-8 Support Enabled
INFO - 2024-12-08 08:29:58 --> Utf8 Class Initialized
INFO - 2024-12-08 08:29:58 --> URI Class Initialized
INFO - 2024-12-08 08:29:58 --> Router Class Initialized
INFO - 2024-12-08 08:29:58 --> Output Class Initialized
INFO - 2024-12-08 08:29:58 --> Security Class Initialized
DEBUG - 2024-12-08 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 08:29:58 --> Input Class Initialized
INFO - 2024-12-08 08:29:58 --> Language Class Initialized
ERROR - 2024-12-08 08:29:58 --> 404 Page Not Found: Sitemapsxml/index
INFO - 2024-12-08 14:18:40 --> Config Class Initialized
INFO - 2024-12-08 14:18:40 --> Hooks Class Initialized
DEBUG - 2024-12-08 14:18:40 --> UTF-8 Support Enabled
INFO - 2024-12-08 14:18:40 --> Utf8 Class Initialized
INFO - 2024-12-08 14:18:40 --> URI Class Initialized
DEBUG - 2024-12-08 14:18:40 --> No URI present. Default controller set.
INFO - 2024-12-08 14:18:40 --> Router Class Initialized
INFO - 2024-12-08 14:18:40 --> Output Class Initialized
INFO - 2024-12-08 14:18:40 --> Security Class Initialized
DEBUG - 2024-12-08 14:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 14:18:40 --> Input Class Initialized
INFO - 2024-12-08 14:18:40 --> Language Class Initialized
INFO - 2024-12-08 14:18:40 --> Loader Class Initialized
INFO - 2024-12-08 14:18:40 --> Helper loaded: url_helper
INFO - 2024-12-08 14:18:40 --> Helper loaded: file_helper
INFO - 2024-12-08 14:18:40 --> Helper loaded: security_helper
INFO - 2024-12-08 14:18:40 --> Helper loaded: wpu_helper
INFO - 2024-12-08 14:18:40 --> Database Driver Class Initialized
INFO - 2024-12-08 14:18:41 --> Email Class Initialized
DEBUG - 2024-12-08 14:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 14:18:41 --> Helper loaded: form_helper
INFO - 2024-12-08 14:18:41 --> Form Validation Class Initialized
INFO - 2024-12-08 14:18:41 --> Controller Class Initialized
DEBUG - 2024-12-08 14:18:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-08 14:18:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-08 14:18:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-08 14:18:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-08 14:18:41 --> Final output sent to browser
DEBUG - 2024-12-08 14:18:41 --> Total execution time: 0.4017
INFO - 2024-12-08 21:32:09 --> Config Class Initialized
INFO - 2024-12-08 21:32:09 --> Hooks Class Initialized
DEBUG - 2024-12-08 21:32:09 --> UTF-8 Support Enabled
INFO - 2024-12-08 21:32:09 --> Utf8 Class Initialized
INFO - 2024-12-08 21:32:09 --> URI Class Initialized
DEBUG - 2024-12-08 21:32:09 --> No URI present. Default controller set.
INFO - 2024-12-08 21:32:09 --> Router Class Initialized
INFO - 2024-12-08 21:32:09 --> Output Class Initialized
INFO - 2024-12-08 21:32:09 --> Security Class Initialized
DEBUG - 2024-12-08 21:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 21:32:09 --> Input Class Initialized
INFO - 2024-12-08 21:32:09 --> Language Class Initialized
INFO - 2024-12-08 21:32:09 --> Loader Class Initialized
INFO - 2024-12-08 21:32:09 --> Helper loaded: url_helper
INFO - 2024-12-08 21:32:09 --> Helper loaded: file_helper
INFO - 2024-12-08 21:32:09 --> Helper loaded: security_helper
INFO - 2024-12-08 21:32:09 --> Helper loaded: wpu_helper
INFO - 2024-12-08 21:32:09 --> Database Driver Class Initialized
INFO - 2024-12-08 21:32:09 --> Email Class Initialized
DEBUG - 2024-12-08 21:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-08 21:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-08 21:32:09 --> Helper loaded: form_helper
INFO - 2024-12-08 21:32:09 --> Form Validation Class Initialized
INFO - 2024-12-08 21:32:09 --> Controller Class Initialized
DEBUG - 2024-12-08 21:32:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-08 21:32:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-08 21:32:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-08 21:32:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-08 21:32:09 --> Final output sent to browser
DEBUG - 2024-12-08 21:32:09 --> Total execution time: 0.4146
