<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-11 00:16:40 --> Config Class Initialized
INFO - 2024-09-11 00:16:40 --> Hooks Class Initialized
DEBUG - 2024-09-11 00:16:40 --> UTF-8 Support Enabled
INFO - 2024-09-11 00:16:40 --> Utf8 Class Initialized
INFO - 2024-09-11 00:16:40 --> URI Class Initialized
DEBUG - 2024-09-11 00:16:40 --> No URI present. Default controller set.
INFO - 2024-09-11 00:16:40 --> Router Class Initialized
INFO - 2024-09-11 00:16:40 --> Output Class Initialized
INFO - 2024-09-11 00:16:40 --> Security Class Initialized
DEBUG - 2024-09-11 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 00:16:40 --> Input Class Initialized
INFO - 2024-09-11 00:16:40 --> Language Class Initialized
INFO - 2024-09-11 00:16:40 --> Loader Class Initialized
INFO - 2024-09-11 00:16:40 --> Helper loaded: url_helper
INFO - 2024-09-11 00:16:40 --> Helper loaded: file_helper
INFO - 2024-09-11 00:16:40 --> Helper loaded: security_helper
INFO - 2024-09-11 00:16:40 --> Helper loaded: wpu_helper
INFO - 2024-09-11 00:16:40 --> Database Driver Class Initialized
INFO - 2024-09-11 00:16:41 --> Email Class Initialized
DEBUG - 2024-09-11 00:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 00:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 00:16:41 --> Helper loaded: form_helper
INFO - 2024-09-11 00:16:41 --> Form Validation Class Initialized
INFO - 2024-09-11 00:16:41 --> Controller Class Initialized
DEBUG - 2024-09-11 00:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 00:16:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 00:16:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 00:16:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 00:16:41 --> Final output sent to browser
DEBUG - 2024-09-11 00:16:41 --> Total execution time: 0.2587
INFO - 2024-09-11 00:46:48 --> Config Class Initialized
INFO - 2024-09-11 00:46:48 --> Hooks Class Initialized
DEBUG - 2024-09-11 00:46:48 --> UTF-8 Support Enabled
INFO - 2024-09-11 00:46:48 --> Utf8 Class Initialized
INFO - 2024-09-11 00:46:48 --> URI Class Initialized
DEBUG - 2024-09-11 00:46:48 --> No URI present. Default controller set.
INFO - 2024-09-11 00:46:48 --> Router Class Initialized
INFO - 2024-09-11 00:46:48 --> Output Class Initialized
INFO - 2024-09-11 00:46:48 --> Security Class Initialized
DEBUG - 2024-09-11 00:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 00:46:48 --> Input Class Initialized
INFO - 2024-09-11 00:46:48 --> Language Class Initialized
INFO - 2024-09-11 00:46:48 --> Loader Class Initialized
INFO - 2024-09-11 00:46:48 --> Helper loaded: url_helper
INFO - 2024-09-11 00:46:48 --> Helper loaded: file_helper
INFO - 2024-09-11 00:46:48 --> Helper loaded: security_helper
INFO - 2024-09-11 00:46:48 --> Helper loaded: wpu_helper
INFO - 2024-09-11 00:46:48 --> Database Driver Class Initialized
INFO - 2024-09-11 00:46:48 --> Email Class Initialized
DEBUG - 2024-09-11 00:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 00:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 00:46:48 --> Helper loaded: form_helper
INFO - 2024-09-11 00:46:48 --> Form Validation Class Initialized
INFO - 2024-09-11 00:46:48 --> Controller Class Initialized
DEBUG - 2024-09-11 00:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 00:46:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 00:46:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 00:46:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 00:46:48 --> Final output sent to browser
DEBUG - 2024-09-11 00:46:48 --> Total execution time: 0.2206
INFO - 2024-09-11 01:16:20 --> Config Class Initialized
INFO - 2024-09-11 01:16:20 --> Hooks Class Initialized
DEBUG - 2024-09-11 01:16:20 --> UTF-8 Support Enabled
INFO - 2024-09-11 01:16:20 --> Utf8 Class Initialized
INFO - 2024-09-11 01:16:20 --> URI Class Initialized
DEBUG - 2024-09-11 01:16:20 --> No URI present. Default controller set.
INFO - 2024-09-11 01:16:20 --> Router Class Initialized
INFO - 2024-09-11 01:16:20 --> Output Class Initialized
INFO - 2024-09-11 01:16:20 --> Security Class Initialized
DEBUG - 2024-09-11 01:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 01:16:20 --> Input Class Initialized
INFO - 2024-09-11 01:16:20 --> Language Class Initialized
INFO - 2024-09-11 01:16:20 --> Loader Class Initialized
INFO - 2024-09-11 01:16:20 --> Helper loaded: url_helper
INFO - 2024-09-11 01:16:20 --> Helper loaded: file_helper
INFO - 2024-09-11 01:16:20 --> Helper loaded: security_helper
INFO - 2024-09-11 01:16:20 --> Helper loaded: wpu_helper
INFO - 2024-09-11 01:16:20 --> Database Driver Class Initialized
INFO - 2024-09-11 01:16:20 --> Email Class Initialized
DEBUG - 2024-09-11 01:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 01:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 01:16:20 --> Helper loaded: form_helper
INFO - 2024-09-11 01:16:20 --> Form Validation Class Initialized
INFO - 2024-09-11 01:16:20 --> Controller Class Initialized
DEBUG - 2024-09-11 01:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 01:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 01:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 01:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 01:16:20 --> Final output sent to browser
DEBUG - 2024-09-11 01:16:20 --> Total execution time: 0.2285
INFO - 2024-09-11 01:48:29 --> Config Class Initialized
INFO - 2024-09-11 01:48:29 --> Hooks Class Initialized
DEBUG - 2024-09-11 01:48:29 --> UTF-8 Support Enabled
INFO - 2024-09-11 01:48:29 --> Utf8 Class Initialized
INFO - 2024-09-11 01:48:29 --> URI Class Initialized
DEBUG - 2024-09-11 01:48:29 --> No URI present. Default controller set.
INFO - 2024-09-11 01:48:29 --> Router Class Initialized
INFO - 2024-09-11 01:48:29 --> Output Class Initialized
INFO - 2024-09-11 01:48:29 --> Security Class Initialized
DEBUG - 2024-09-11 01:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 01:48:29 --> Input Class Initialized
INFO - 2024-09-11 01:48:29 --> Language Class Initialized
INFO - 2024-09-11 01:48:29 --> Loader Class Initialized
INFO - 2024-09-11 01:48:29 --> Helper loaded: url_helper
INFO - 2024-09-11 01:48:29 --> Helper loaded: file_helper
INFO - 2024-09-11 01:48:29 --> Helper loaded: security_helper
INFO - 2024-09-11 01:48:29 --> Helper loaded: wpu_helper
INFO - 2024-09-11 01:48:29 --> Database Driver Class Initialized
INFO - 2024-09-11 01:48:29 --> Email Class Initialized
DEBUG - 2024-09-11 01:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 01:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 01:48:29 --> Helper loaded: form_helper
INFO - 2024-09-11 01:48:29 --> Form Validation Class Initialized
INFO - 2024-09-11 01:48:29 --> Controller Class Initialized
DEBUG - 2024-09-11 01:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 01:48:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 01:48:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 01:48:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 01:48:29 --> Final output sent to browser
DEBUG - 2024-09-11 01:48:29 --> Total execution time: 0.2351
INFO - 2024-09-11 02:10:28 --> Config Class Initialized
INFO - 2024-09-11 02:10:28 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:10:28 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:10:28 --> Utf8 Class Initialized
INFO - 2024-09-11 02:10:28 --> URI Class Initialized
DEBUG - 2024-09-11 02:10:28 --> No URI present. Default controller set.
INFO - 2024-09-11 02:10:28 --> Router Class Initialized
INFO - 2024-09-11 02:10:28 --> Output Class Initialized
INFO - 2024-09-11 02:10:28 --> Security Class Initialized
DEBUG - 2024-09-11 02:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:10:28 --> Input Class Initialized
INFO - 2024-09-11 02:10:28 --> Language Class Initialized
INFO - 2024-09-11 02:10:28 --> Loader Class Initialized
INFO - 2024-09-11 02:10:28 --> Helper loaded: url_helper
INFO - 2024-09-11 02:10:28 --> Helper loaded: file_helper
INFO - 2024-09-11 02:10:28 --> Helper loaded: security_helper
INFO - 2024-09-11 02:10:28 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:10:28 --> Database Driver Class Initialized
INFO - 2024-09-11 02:10:28 --> Email Class Initialized
DEBUG - 2024-09-11 02:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:10:28 --> Helper loaded: form_helper
INFO - 2024-09-11 02:10:28 --> Form Validation Class Initialized
INFO - 2024-09-11 02:10:28 --> Controller Class Initialized
DEBUG - 2024-09-11 02:10:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:10:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:10:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:10:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:10:28 --> Final output sent to browser
DEBUG - 2024-09-11 02:10:28 --> Total execution time: 0.2256
INFO - 2024-09-11 02:10:31 --> Config Class Initialized
INFO - 2024-09-11 02:10:31 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:10:31 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:10:31 --> Utf8 Class Initialized
INFO - 2024-09-11 02:10:31 --> URI Class Initialized
INFO - 2024-09-11 02:10:31 --> Router Class Initialized
INFO - 2024-09-11 02:10:31 --> Output Class Initialized
INFO - 2024-09-11 02:10:31 --> Security Class Initialized
DEBUG - 2024-09-11 02:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:10:31 --> Input Class Initialized
INFO - 2024-09-11 02:10:31 --> Language Class Initialized
INFO - 2024-09-11 02:10:31 --> Loader Class Initialized
INFO - 2024-09-11 02:10:31 --> Helper loaded: url_helper
INFO - 2024-09-11 02:10:31 --> Helper loaded: file_helper
INFO - 2024-09-11 02:10:31 --> Helper loaded: security_helper
INFO - 2024-09-11 02:10:31 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:10:31 --> Database Driver Class Initialized
INFO - 2024-09-11 02:10:31 --> Email Class Initialized
DEBUG - 2024-09-11 02:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:10:31 --> Helper loaded: form_helper
INFO - 2024-09-11 02:10:31 --> Form Validation Class Initialized
INFO - 2024-09-11 02:10:31 --> Controller Class Initialized
DEBUG - 2024-09-11 02:10:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:10:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-11 02:10:32 --> Config Class Initialized
INFO - 2024-09-11 02:10:32 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:10:32 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:10:32 --> Utf8 Class Initialized
INFO - 2024-09-11 02:10:32 --> URI Class Initialized
INFO - 2024-09-11 02:10:32 --> Router Class Initialized
INFO - 2024-09-11 02:10:32 --> Output Class Initialized
INFO - 2024-09-11 02:10:32 --> Security Class Initialized
DEBUG - 2024-09-11 02:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:10:32 --> Input Class Initialized
INFO - 2024-09-11 02:10:32 --> Language Class Initialized
INFO - 2024-09-11 02:10:32 --> Loader Class Initialized
INFO - 2024-09-11 02:10:32 --> Helper loaded: url_helper
INFO - 2024-09-11 02:10:32 --> Helper loaded: file_helper
INFO - 2024-09-11 02:10:32 --> Helper loaded: security_helper
INFO - 2024-09-11 02:10:32 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:10:32 --> Database Driver Class Initialized
INFO - 2024-09-11 02:10:32 --> Email Class Initialized
DEBUG - 2024-09-11 02:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:10:32 --> Helper loaded: form_helper
INFO - 2024-09-11 02:10:32 --> Form Validation Class Initialized
INFO - 2024-09-11 02:10:32 --> Controller Class Initialized
INFO - 2024-09-11 02:10:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 02:10:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:10:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-11 02:10:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-11 02:10:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-11 02:10:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-11 02:10:32 --> Final output sent to browser
DEBUG - 2024-09-11 02:10:32 --> Total execution time: 0.6808
INFO - 2024-09-11 02:10:39 --> Config Class Initialized
INFO - 2024-09-11 02:10:39 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:10:39 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:10:39 --> Utf8 Class Initialized
INFO - 2024-09-11 02:10:39 --> URI Class Initialized
INFO - 2024-09-11 02:10:39 --> Router Class Initialized
INFO - 2024-09-11 02:10:39 --> Output Class Initialized
INFO - 2024-09-11 02:10:39 --> Security Class Initialized
DEBUG - 2024-09-11 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:10:39 --> Input Class Initialized
INFO - 2024-09-11 02:10:39 --> Language Class Initialized
INFO - 2024-09-11 02:10:39 --> Loader Class Initialized
INFO - 2024-09-11 02:10:39 --> Helper loaded: url_helper
INFO - 2024-09-11 02:10:39 --> Helper loaded: file_helper
INFO - 2024-09-11 02:10:39 --> Helper loaded: security_helper
INFO - 2024-09-11 02:10:39 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:10:39 --> Database Driver Class Initialized
INFO - 2024-09-11 02:10:39 --> Email Class Initialized
DEBUG - 2024-09-11 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:10:39 --> Helper loaded: form_helper
INFO - 2024-09-11 02:10:39 --> Form Validation Class Initialized
INFO - 2024-09-11 02:10:39 --> Controller Class Initialized
INFO - 2024-09-11 02:10:39 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 02:10:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-11 02:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-11 02:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-11 02:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-11 02:10:40 --> Final output sent to browser
DEBUG - 2024-09-11 02:10:40 --> Total execution time: 0.8108
INFO - 2024-09-11 02:10:42 --> Config Class Initialized
INFO - 2024-09-11 02:10:42 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:10:42 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:10:42 --> Utf8 Class Initialized
INFO - 2024-09-11 02:10:42 --> URI Class Initialized
INFO - 2024-09-11 02:10:42 --> Router Class Initialized
INFO - 2024-09-11 02:10:42 --> Output Class Initialized
INFO - 2024-09-11 02:10:42 --> Security Class Initialized
DEBUG - 2024-09-11 02:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:10:42 --> Input Class Initialized
INFO - 2024-09-11 02:10:42 --> Language Class Initialized
INFO - 2024-09-11 02:10:42 --> Loader Class Initialized
INFO - 2024-09-11 02:10:42 --> Helper loaded: url_helper
INFO - 2024-09-11 02:10:42 --> Helper loaded: file_helper
INFO - 2024-09-11 02:10:42 --> Helper loaded: security_helper
INFO - 2024-09-11 02:10:42 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:10:42 --> Database Driver Class Initialized
INFO - 2024-09-11 02:10:42 --> Email Class Initialized
DEBUG - 2024-09-11 02:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:10:42 --> Helper loaded: form_helper
INFO - 2024-09-11 02:10:42 --> Form Validation Class Initialized
INFO - 2024-09-11 02:10:42 --> Controller Class Initialized
INFO - 2024-09-11 02:10:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 02:10:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:10:44 --> Final output sent to browser
DEBUG - 2024-09-11 02:10:44 --> Total execution time: 1.9326
INFO - 2024-09-11 02:12:46 --> Config Class Initialized
INFO - 2024-09-11 02:12:46 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:12:46 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:12:46 --> Utf8 Class Initialized
INFO - 2024-09-11 02:12:46 --> URI Class Initialized
INFO - 2024-09-11 02:12:46 --> Router Class Initialized
INFO - 2024-09-11 02:12:46 --> Output Class Initialized
INFO - 2024-09-11 02:12:46 --> Security Class Initialized
DEBUG - 2024-09-11 02:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:12:46 --> Input Class Initialized
INFO - 2024-09-11 02:12:46 --> Language Class Initialized
INFO - 2024-09-11 02:12:46 --> Loader Class Initialized
INFO - 2024-09-11 02:12:46 --> Helper loaded: url_helper
INFO - 2024-09-11 02:12:46 --> Helper loaded: file_helper
INFO - 2024-09-11 02:12:46 --> Helper loaded: security_helper
INFO - 2024-09-11 02:12:46 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:12:46 --> Database Driver Class Initialized
INFO - 2024-09-11 02:12:46 --> Email Class Initialized
DEBUG - 2024-09-11 02:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:12:46 --> Helper loaded: form_helper
INFO - 2024-09-11 02:12:46 --> Form Validation Class Initialized
INFO - 2024-09-11 02:12:46 --> Controller Class Initialized
INFO - 2024-09-11 02:12:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 02:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:12:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-11 02:12:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-11 02:12:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-11 02:12:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-11 02:12:47 --> Final output sent to browser
DEBUG - 2024-09-11 02:12:47 --> Total execution time: 0.7526
INFO - 2024-09-11 02:18:48 --> Config Class Initialized
INFO - 2024-09-11 02:18:48 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:18:48 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:18:48 --> Utf8 Class Initialized
INFO - 2024-09-11 02:18:48 --> URI Class Initialized
DEBUG - 2024-09-11 02:18:48 --> No URI present. Default controller set.
INFO - 2024-09-11 02:18:48 --> Router Class Initialized
INFO - 2024-09-11 02:18:48 --> Output Class Initialized
INFO - 2024-09-11 02:18:48 --> Security Class Initialized
DEBUG - 2024-09-11 02:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:18:48 --> Input Class Initialized
INFO - 2024-09-11 02:18:48 --> Language Class Initialized
INFO - 2024-09-11 02:18:48 --> Loader Class Initialized
INFO - 2024-09-11 02:18:48 --> Helper loaded: url_helper
INFO - 2024-09-11 02:18:48 --> Helper loaded: file_helper
INFO - 2024-09-11 02:18:48 --> Helper loaded: security_helper
INFO - 2024-09-11 02:18:48 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:18:48 --> Database Driver Class Initialized
INFO - 2024-09-11 02:18:49 --> Email Class Initialized
DEBUG - 2024-09-11 02:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:18:49 --> Helper loaded: form_helper
INFO - 2024-09-11 02:18:49 --> Form Validation Class Initialized
INFO - 2024-09-11 02:18:49 --> Controller Class Initialized
DEBUG - 2024-09-11 02:18:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:18:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:18:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:18:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:18:49 --> Final output sent to browser
DEBUG - 2024-09-11 02:18:49 --> Total execution time: 0.2470
INFO - 2024-09-11 02:18:50 --> Config Class Initialized
INFO - 2024-09-11 02:18:50 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:18:50 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:18:50 --> Utf8 Class Initialized
INFO - 2024-09-11 02:18:50 --> URI Class Initialized
DEBUG - 2024-09-11 02:18:50 --> No URI present. Default controller set.
INFO - 2024-09-11 02:18:50 --> Router Class Initialized
INFO - 2024-09-11 02:18:50 --> Output Class Initialized
INFO - 2024-09-11 02:18:50 --> Security Class Initialized
DEBUG - 2024-09-11 02:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:18:50 --> Input Class Initialized
INFO - 2024-09-11 02:18:50 --> Language Class Initialized
INFO - 2024-09-11 02:18:50 --> Loader Class Initialized
INFO - 2024-09-11 02:18:50 --> Helper loaded: url_helper
INFO - 2024-09-11 02:18:50 --> Helper loaded: file_helper
INFO - 2024-09-11 02:18:50 --> Helper loaded: security_helper
INFO - 2024-09-11 02:18:50 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:18:50 --> Database Driver Class Initialized
INFO - 2024-09-11 02:18:50 --> Email Class Initialized
DEBUG - 2024-09-11 02:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:18:50 --> Helper loaded: form_helper
INFO - 2024-09-11 02:18:50 --> Form Validation Class Initialized
INFO - 2024-09-11 02:18:50 --> Controller Class Initialized
DEBUG - 2024-09-11 02:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:18:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:18:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:18:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:18:50 --> Final output sent to browser
DEBUG - 2024-09-11 02:18:50 --> Total execution time: 0.2318
INFO - 2024-09-11 02:19:57 --> Config Class Initialized
INFO - 2024-09-11 02:19:57 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:19:57 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:19:57 --> Utf8 Class Initialized
INFO - 2024-09-11 02:19:57 --> URI Class Initialized
DEBUG - 2024-09-11 02:19:57 --> No URI present. Default controller set.
INFO - 2024-09-11 02:19:57 --> Router Class Initialized
INFO - 2024-09-11 02:19:57 --> Output Class Initialized
INFO - 2024-09-11 02:19:57 --> Security Class Initialized
DEBUG - 2024-09-11 02:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:19:57 --> Input Class Initialized
INFO - 2024-09-11 02:19:57 --> Language Class Initialized
INFO - 2024-09-11 02:19:57 --> Loader Class Initialized
INFO - 2024-09-11 02:19:57 --> Helper loaded: url_helper
INFO - 2024-09-11 02:19:57 --> Helper loaded: file_helper
INFO - 2024-09-11 02:19:57 --> Helper loaded: security_helper
INFO - 2024-09-11 02:19:57 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:19:57 --> Database Driver Class Initialized
INFO - 2024-09-11 02:19:57 --> Email Class Initialized
DEBUG - 2024-09-11 02:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:19:57 --> Helper loaded: form_helper
INFO - 2024-09-11 02:19:57 --> Form Validation Class Initialized
INFO - 2024-09-11 02:19:57 --> Controller Class Initialized
DEBUG - 2024-09-11 02:19:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:19:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:19:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:19:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:19:57 --> Final output sent to browser
DEBUG - 2024-09-11 02:19:57 --> Total execution time: 0.2427
INFO - 2024-09-11 02:31:01 --> Config Class Initialized
INFO - 2024-09-11 02:31:01 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:31:01 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:31:01 --> Utf8 Class Initialized
INFO - 2024-09-11 02:31:01 --> URI Class Initialized
DEBUG - 2024-09-11 02:31:01 --> No URI present. Default controller set.
INFO - 2024-09-11 02:31:01 --> Router Class Initialized
INFO - 2024-09-11 02:31:01 --> Output Class Initialized
INFO - 2024-09-11 02:31:01 --> Security Class Initialized
DEBUG - 2024-09-11 02:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:31:01 --> Input Class Initialized
INFO - 2024-09-11 02:31:01 --> Language Class Initialized
INFO - 2024-09-11 02:31:01 --> Loader Class Initialized
INFO - 2024-09-11 02:31:01 --> Helper loaded: url_helper
INFO - 2024-09-11 02:31:01 --> Helper loaded: file_helper
INFO - 2024-09-11 02:31:01 --> Helper loaded: security_helper
INFO - 2024-09-11 02:31:01 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:31:01 --> Database Driver Class Initialized
INFO - 2024-09-11 02:31:01 --> Email Class Initialized
DEBUG - 2024-09-11 02:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:31:01 --> Helper loaded: form_helper
INFO - 2024-09-11 02:31:01 --> Form Validation Class Initialized
INFO - 2024-09-11 02:31:01 --> Controller Class Initialized
DEBUG - 2024-09-11 02:31:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:31:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:31:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:31:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:31:01 --> Final output sent to browser
DEBUG - 2024-09-11 02:31:01 --> Total execution time: 0.2092
INFO - 2024-09-11 02:48:34 --> Config Class Initialized
INFO - 2024-09-11 02:48:34 --> Hooks Class Initialized
DEBUG - 2024-09-11 02:48:34 --> UTF-8 Support Enabled
INFO - 2024-09-11 02:48:34 --> Utf8 Class Initialized
INFO - 2024-09-11 02:48:34 --> URI Class Initialized
DEBUG - 2024-09-11 02:48:34 --> No URI present. Default controller set.
INFO - 2024-09-11 02:48:34 --> Router Class Initialized
INFO - 2024-09-11 02:48:34 --> Output Class Initialized
INFO - 2024-09-11 02:48:34 --> Security Class Initialized
DEBUG - 2024-09-11 02:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 02:48:34 --> Input Class Initialized
INFO - 2024-09-11 02:48:34 --> Language Class Initialized
INFO - 2024-09-11 02:48:34 --> Loader Class Initialized
INFO - 2024-09-11 02:48:34 --> Helper loaded: url_helper
INFO - 2024-09-11 02:48:34 --> Helper loaded: file_helper
INFO - 2024-09-11 02:48:34 --> Helper loaded: security_helper
INFO - 2024-09-11 02:48:34 --> Helper loaded: wpu_helper
INFO - 2024-09-11 02:48:34 --> Database Driver Class Initialized
INFO - 2024-09-11 02:48:34 --> Email Class Initialized
DEBUG - 2024-09-11 02:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 02:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 02:48:34 --> Helper loaded: form_helper
INFO - 2024-09-11 02:48:34 --> Form Validation Class Initialized
INFO - 2024-09-11 02:48:34 --> Controller Class Initialized
DEBUG - 2024-09-11 02:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 02:48:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 02:48:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 02:48:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 02:48:34 --> Final output sent to browser
DEBUG - 2024-09-11 02:48:34 --> Total execution time: 0.2386
INFO - 2024-09-11 03:17:21 --> Config Class Initialized
INFO - 2024-09-11 03:17:21 --> Hooks Class Initialized
DEBUG - 2024-09-11 03:17:21 --> UTF-8 Support Enabled
INFO - 2024-09-11 03:17:21 --> Utf8 Class Initialized
INFO - 2024-09-11 03:17:21 --> URI Class Initialized
DEBUG - 2024-09-11 03:17:21 --> No URI present. Default controller set.
INFO - 2024-09-11 03:17:21 --> Router Class Initialized
INFO - 2024-09-11 03:17:21 --> Output Class Initialized
INFO - 2024-09-11 03:17:21 --> Security Class Initialized
DEBUG - 2024-09-11 03:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 03:17:21 --> Input Class Initialized
INFO - 2024-09-11 03:17:21 --> Language Class Initialized
INFO - 2024-09-11 03:17:21 --> Loader Class Initialized
INFO - 2024-09-11 03:17:21 --> Helper loaded: url_helper
INFO - 2024-09-11 03:17:21 --> Helper loaded: file_helper
INFO - 2024-09-11 03:17:21 --> Helper loaded: security_helper
INFO - 2024-09-11 03:17:21 --> Helper loaded: wpu_helper
INFO - 2024-09-11 03:17:21 --> Database Driver Class Initialized
INFO - 2024-09-11 03:17:21 --> Email Class Initialized
DEBUG - 2024-09-11 03:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 03:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 03:17:21 --> Helper loaded: form_helper
INFO - 2024-09-11 03:17:21 --> Form Validation Class Initialized
INFO - 2024-09-11 03:17:21 --> Controller Class Initialized
DEBUG - 2024-09-11 03:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 03:17:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 03:17:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 03:17:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 03:17:21 --> Final output sent to browser
DEBUG - 2024-09-11 03:17:21 --> Total execution time: 0.2210
INFO - 2024-09-11 03:21:13 --> Config Class Initialized
INFO - 2024-09-11 03:21:13 --> Hooks Class Initialized
DEBUG - 2024-09-11 03:21:13 --> UTF-8 Support Enabled
INFO - 2024-09-11 03:21:13 --> Utf8 Class Initialized
INFO - 2024-09-11 03:21:13 --> URI Class Initialized
INFO - 2024-09-11 03:21:13 --> Router Class Initialized
INFO - 2024-09-11 03:21:13 --> Output Class Initialized
INFO - 2024-09-11 03:21:13 --> Security Class Initialized
DEBUG - 2024-09-11 03:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 03:21:13 --> Input Class Initialized
INFO - 2024-09-11 03:21:13 --> Language Class Initialized
INFO - 2024-09-11 03:21:13 --> Loader Class Initialized
INFO - 2024-09-11 03:21:13 --> Helper loaded: url_helper
INFO - 2024-09-11 03:21:13 --> Helper loaded: file_helper
INFO - 2024-09-11 03:21:13 --> Helper loaded: security_helper
INFO - 2024-09-11 03:21:13 --> Helper loaded: wpu_helper
INFO - 2024-09-11 03:21:13 --> Database Driver Class Initialized
INFO - 2024-09-11 03:21:13 --> Email Class Initialized
DEBUG - 2024-09-11 03:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 03:21:13 --> Helper loaded: form_helper
INFO - 2024-09-11 03:21:13 --> Form Validation Class Initialized
INFO - 2024-09-11 03:21:13 --> Controller Class Initialized
INFO - 2024-09-11 03:21:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 03:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 03:21:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-11 03:21:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-11 03:21:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-11 03:21:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-11 03:21:14 --> Final output sent to browser
DEBUG - 2024-09-11 03:21:14 --> Total execution time: 0.9749
INFO - 2024-09-11 03:49:24 --> Config Class Initialized
INFO - 2024-09-11 03:49:24 --> Hooks Class Initialized
DEBUG - 2024-09-11 03:49:24 --> UTF-8 Support Enabled
INFO - 2024-09-11 03:49:24 --> Utf8 Class Initialized
INFO - 2024-09-11 03:49:24 --> URI Class Initialized
DEBUG - 2024-09-11 03:49:24 --> No URI present. Default controller set.
INFO - 2024-09-11 03:49:24 --> Router Class Initialized
INFO - 2024-09-11 03:49:24 --> Output Class Initialized
INFO - 2024-09-11 03:49:24 --> Security Class Initialized
DEBUG - 2024-09-11 03:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 03:49:24 --> Input Class Initialized
INFO - 2024-09-11 03:49:24 --> Language Class Initialized
INFO - 2024-09-11 03:49:24 --> Loader Class Initialized
INFO - 2024-09-11 03:49:24 --> Helper loaded: url_helper
INFO - 2024-09-11 03:49:24 --> Helper loaded: file_helper
INFO - 2024-09-11 03:49:24 --> Helper loaded: security_helper
INFO - 2024-09-11 03:49:24 --> Helper loaded: wpu_helper
INFO - 2024-09-11 03:49:24 --> Database Driver Class Initialized
INFO - 2024-09-11 03:49:24 --> Email Class Initialized
DEBUG - 2024-09-11 03:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 03:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 03:49:24 --> Helper loaded: form_helper
INFO - 2024-09-11 03:49:24 --> Form Validation Class Initialized
INFO - 2024-09-11 03:49:24 --> Controller Class Initialized
DEBUG - 2024-09-11 03:49:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 03:49:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 03:49:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 03:49:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 03:49:24 --> Final output sent to browser
DEBUG - 2024-09-11 03:49:24 --> Total execution time: 0.2116
INFO - 2024-09-11 04:15:12 --> Config Class Initialized
INFO - 2024-09-11 04:15:12 --> Hooks Class Initialized
DEBUG - 2024-09-11 04:15:12 --> UTF-8 Support Enabled
INFO - 2024-09-11 04:15:12 --> Utf8 Class Initialized
INFO - 2024-09-11 04:15:12 --> URI Class Initialized
INFO - 2024-09-11 04:15:12 --> Router Class Initialized
INFO - 2024-09-11 04:15:12 --> Output Class Initialized
INFO - 2024-09-11 04:15:12 --> Security Class Initialized
DEBUG - 2024-09-11 04:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 04:15:12 --> Input Class Initialized
INFO - 2024-09-11 04:15:12 --> Language Class Initialized
INFO - 2024-09-11 04:15:12 --> Loader Class Initialized
INFO - 2024-09-11 04:15:12 --> Helper loaded: url_helper
INFO - 2024-09-11 04:15:12 --> Helper loaded: file_helper
INFO - 2024-09-11 04:15:12 --> Helper loaded: security_helper
INFO - 2024-09-11 04:15:12 --> Helper loaded: wpu_helper
INFO - 2024-09-11 04:15:12 --> Database Driver Class Initialized
INFO - 2024-09-11 04:15:13 --> Email Class Initialized
DEBUG - 2024-09-11 04:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 04:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 04:15:13 --> Helper loaded: form_helper
INFO - 2024-09-11 04:15:13 --> Form Validation Class Initialized
INFO - 2024-09-11 04:15:13 --> Controller Class Initialized
INFO - 2024-09-11 04:15:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-11 04:15:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 04:15:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-11 04:15:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-11 04:15:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-11 04:15:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-11 04:15:13 --> Final output sent to browser
DEBUG - 2024-09-11 04:15:13 --> Total execution time: 0.7326
INFO - 2024-09-11 04:18:28 --> Config Class Initialized
INFO - 2024-09-11 04:18:28 --> Hooks Class Initialized
DEBUG - 2024-09-11 04:18:28 --> UTF-8 Support Enabled
INFO - 2024-09-11 04:18:28 --> Utf8 Class Initialized
INFO - 2024-09-11 04:18:28 --> URI Class Initialized
DEBUG - 2024-09-11 04:18:28 --> No URI present. Default controller set.
INFO - 2024-09-11 04:18:28 --> Router Class Initialized
INFO - 2024-09-11 04:18:28 --> Output Class Initialized
INFO - 2024-09-11 04:18:28 --> Security Class Initialized
DEBUG - 2024-09-11 04:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 04:18:28 --> Input Class Initialized
INFO - 2024-09-11 04:18:28 --> Language Class Initialized
INFO - 2024-09-11 04:18:28 --> Loader Class Initialized
INFO - 2024-09-11 04:18:28 --> Helper loaded: url_helper
INFO - 2024-09-11 04:18:28 --> Helper loaded: file_helper
INFO - 2024-09-11 04:18:28 --> Helper loaded: security_helper
INFO - 2024-09-11 04:18:28 --> Helper loaded: wpu_helper
INFO - 2024-09-11 04:18:28 --> Database Driver Class Initialized
INFO - 2024-09-11 04:18:28 --> Email Class Initialized
DEBUG - 2024-09-11 04:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 04:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 04:18:28 --> Helper loaded: form_helper
INFO - 2024-09-11 04:18:28 --> Form Validation Class Initialized
INFO - 2024-09-11 04:18:28 --> Controller Class Initialized
DEBUG - 2024-09-11 04:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 04:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 04:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 04:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 04:18:28 --> Final output sent to browser
DEBUG - 2024-09-11 04:18:28 --> Total execution time: 0.2418
INFO - 2024-09-11 04:46:29 --> Config Class Initialized
INFO - 2024-09-11 04:46:29 --> Hooks Class Initialized
DEBUG - 2024-09-11 04:46:29 --> UTF-8 Support Enabled
INFO - 2024-09-11 04:46:29 --> Utf8 Class Initialized
INFO - 2024-09-11 04:46:29 --> URI Class Initialized
DEBUG - 2024-09-11 04:46:29 --> No URI present. Default controller set.
INFO - 2024-09-11 04:46:29 --> Router Class Initialized
INFO - 2024-09-11 04:46:29 --> Output Class Initialized
INFO - 2024-09-11 04:46:29 --> Security Class Initialized
DEBUG - 2024-09-11 04:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 04:46:29 --> Input Class Initialized
INFO - 2024-09-11 04:46:29 --> Language Class Initialized
INFO - 2024-09-11 04:46:29 --> Loader Class Initialized
INFO - 2024-09-11 04:46:29 --> Helper loaded: url_helper
INFO - 2024-09-11 04:46:29 --> Helper loaded: file_helper
INFO - 2024-09-11 04:46:29 --> Helper loaded: security_helper
INFO - 2024-09-11 04:46:29 --> Helper loaded: wpu_helper
INFO - 2024-09-11 04:46:29 --> Database Driver Class Initialized
INFO - 2024-09-11 04:46:30 --> Email Class Initialized
DEBUG - 2024-09-11 04:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 04:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 04:46:30 --> Helper loaded: form_helper
INFO - 2024-09-11 04:46:30 --> Form Validation Class Initialized
INFO - 2024-09-11 04:46:30 --> Controller Class Initialized
DEBUG - 2024-09-11 04:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 04:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 04:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 04:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 04:46:30 --> Final output sent to browser
DEBUG - 2024-09-11 04:46:30 --> Total execution time: 1.4319
INFO - 2024-09-11 05:17:13 --> Config Class Initialized
INFO - 2024-09-11 05:17:13 --> Hooks Class Initialized
DEBUG - 2024-09-11 05:17:13 --> UTF-8 Support Enabled
INFO - 2024-09-11 05:17:13 --> Utf8 Class Initialized
INFO - 2024-09-11 05:17:13 --> URI Class Initialized
DEBUG - 2024-09-11 05:17:13 --> No URI present. Default controller set.
INFO - 2024-09-11 05:17:13 --> Router Class Initialized
INFO - 2024-09-11 05:17:13 --> Output Class Initialized
INFO - 2024-09-11 05:17:13 --> Security Class Initialized
DEBUG - 2024-09-11 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 05:17:13 --> Input Class Initialized
INFO - 2024-09-11 05:17:13 --> Language Class Initialized
INFO - 2024-09-11 05:17:13 --> Loader Class Initialized
INFO - 2024-09-11 05:17:13 --> Helper loaded: url_helper
INFO - 2024-09-11 05:17:13 --> Helper loaded: file_helper
INFO - 2024-09-11 05:17:13 --> Helper loaded: security_helper
INFO - 2024-09-11 05:17:13 --> Helper loaded: wpu_helper
INFO - 2024-09-11 05:17:13 --> Database Driver Class Initialized
INFO - 2024-09-11 05:17:14 --> Email Class Initialized
DEBUG - 2024-09-11 05:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 05:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 05:17:14 --> Helper loaded: form_helper
INFO - 2024-09-11 05:17:14 --> Form Validation Class Initialized
INFO - 2024-09-11 05:17:14 --> Controller Class Initialized
DEBUG - 2024-09-11 05:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 05:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 05:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 05:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 05:17:14 --> Final output sent to browser
DEBUG - 2024-09-11 05:17:14 --> Total execution time: 0.4779
INFO - 2024-09-11 05:32:17 --> Config Class Initialized
INFO - 2024-09-11 05:32:17 --> Hooks Class Initialized
DEBUG - 2024-09-11 05:32:17 --> UTF-8 Support Enabled
INFO - 2024-09-11 05:32:17 --> Utf8 Class Initialized
INFO - 2024-09-11 05:32:17 --> URI Class Initialized
DEBUG - 2024-09-11 05:32:17 --> No URI present. Default controller set.
INFO - 2024-09-11 05:32:17 --> Router Class Initialized
INFO - 2024-09-11 05:32:17 --> Output Class Initialized
INFO - 2024-09-11 05:32:17 --> Security Class Initialized
DEBUG - 2024-09-11 05:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 05:32:17 --> Input Class Initialized
INFO - 2024-09-11 05:32:17 --> Language Class Initialized
INFO - 2024-09-11 05:32:17 --> Loader Class Initialized
INFO - 2024-09-11 05:32:17 --> Helper loaded: url_helper
INFO - 2024-09-11 05:32:17 --> Helper loaded: file_helper
INFO - 2024-09-11 05:32:17 --> Helper loaded: security_helper
INFO - 2024-09-11 05:32:17 --> Helper loaded: wpu_helper
INFO - 2024-09-11 05:32:17 --> Database Driver Class Initialized
INFO - 2024-09-11 05:32:17 --> Email Class Initialized
DEBUG - 2024-09-11 05:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 05:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 05:32:17 --> Helper loaded: form_helper
INFO - 2024-09-11 05:32:17 --> Form Validation Class Initialized
INFO - 2024-09-11 05:32:17 --> Controller Class Initialized
DEBUG - 2024-09-11 05:32:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 05:32:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 05:32:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 05:32:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 05:32:17 --> Final output sent to browser
DEBUG - 2024-09-11 05:32:17 --> Total execution time: 0.2328
INFO - 2024-09-11 05:45:49 --> Config Class Initialized
INFO - 2024-09-11 05:45:49 --> Hooks Class Initialized
DEBUG - 2024-09-11 05:45:49 --> UTF-8 Support Enabled
INFO - 2024-09-11 05:45:49 --> Utf8 Class Initialized
INFO - 2024-09-11 05:45:49 --> URI Class Initialized
DEBUG - 2024-09-11 05:45:49 --> No URI present. Default controller set.
INFO - 2024-09-11 05:45:49 --> Router Class Initialized
INFO - 2024-09-11 05:45:49 --> Output Class Initialized
INFO - 2024-09-11 05:45:49 --> Security Class Initialized
DEBUG - 2024-09-11 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 05:45:49 --> Input Class Initialized
INFO - 2024-09-11 05:45:49 --> Language Class Initialized
INFO - 2024-09-11 05:45:49 --> Loader Class Initialized
INFO - 2024-09-11 05:45:49 --> Helper loaded: url_helper
INFO - 2024-09-11 05:45:49 --> Helper loaded: file_helper
INFO - 2024-09-11 05:45:49 --> Helper loaded: security_helper
INFO - 2024-09-11 05:45:49 --> Helper loaded: wpu_helper
INFO - 2024-09-11 05:45:49 --> Database Driver Class Initialized
INFO - 2024-09-11 05:45:49 --> Email Class Initialized
DEBUG - 2024-09-11 05:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 05:45:49 --> Helper loaded: form_helper
INFO - 2024-09-11 05:45:49 --> Form Validation Class Initialized
INFO - 2024-09-11 05:45:49 --> Controller Class Initialized
DEBUG - 2024-09-11 05:45:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 05:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 05:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 05:45:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 05:45:49 --> Final output sent to browser
DEBUG - 2024-09-11 05:45:49 --> Total execution time: 0.2246
INFO - 2024-09-11 06:17:13 --> Config Class Initialized
INFO - 2024-09-11 06:17:13 --> Hooks Class Initialized
DEBUG - 2024-09-11 06:17:13 --> UTF-8 Support Enabled
INFO - 2024-09-11 06:17:13 --> Utf8 Class Initialized
INFO - 2024-09-11 06:17:13 --> URI Class Initialized
DEBUG - 2024-09-11 06:17:13 --> No URI present. Default controller set.
INFO - 2024-09-11 06:17:13 --> Router Class Initialized
INFO - 2024-09-11 06:17:13 --> Output Class Initialized
INFO - 2024-09-11 06:17:13 --> Security Class Initialized
DEBUG - 2024-09-11 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 06:17:13 --> Input Class Initialized
INFO - 2024-09-11 06:17:13 --> Language Class Initialized
INFO - 2024-09-11 06:17:13 --> Loader Class Initialized
INFO - 2024-09-11 06:17:13 --> Helper loaded: url_helper
INFO - 2024-09-11 06:17:13 --> Helper loaded: file_helper
INFO - 2024-09-11 06:17:13 --> Helper loaded: security_helper
INFO - 2024-09-11 06:17:13 --> Helper loaded: wpu_helper
INFO - 2024-09-11 06:17:13 --> Database Driver Class Initialized
INFO - 2024-09-11 06:17:14 --> Email Class Initialized
DEBUG - 2024-09-11 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-11 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-11 06:17:14 --> Helper loaded: form_helper
INFO - 2024-09-11 06:17:14 --> Form Validation Class Initialized
INFO - 2024-09-11 06:17:14 --> Controller Class Initialized
DEBUG - 2024-09-11 06:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-11 06:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-11 06:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-11 06:17:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-11 06:17:14 --> Final output sent to browser
DEBUG - 2024-09-11 06:17:14 --> Total execution time: 0.2867
INFO - 2024-09-11 06:48:05 --> Config Class Initialized
INFO - 2024-09-11 06:48:05 --> Hooks Class Initialized
DEBUG - 2024-09-11 06:48:05 --> UTF-8 Support Enabled
INFO - 2024-09-11 06:48:05 --> Utf8 Class Initialized
INFO - 2024-09-11 06:48:05 --> URI Class Initialized
DEBUG - 2024-09-11 06:48:05 --> No URI present. Default controller set.
INFO - 2024-09-11 06:48:05 --> Router Class Initialized
INFO - 2024-09-11 06:48:05 --> Output Class Initialized
INFO - 2024-09-11 06:48:05 --> Security Class Initialized
DEBUG - 2024-09-11 06:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 06:48:05 --> Input Class Initialized
INFO - 2024-09-11 06:48:05 --> Language Class Initialized
INFO - 2024-09-11 06:48:05 --> Loader Class Initialized
INFO - 2024-09-11 06:48:05 --> Helper loaded: url_helper
INFO - 2024-09-11 06:48:05 --> Helper loaded: file_helper
INFO - 2024-09-11 06:48:05 --> Helper loaded: security_helper
INFO - 2024-09-11 06:48:05 --> Helper loaded: wpu_helper
INFO - 2024-09-11 06:48:05 --> Database Driver Class Initialized
INFO - 2024-09-11 07:15:45 --> Config Class Initialized
INFO - 2024-09-11 07:15:45 --> Hooks Class Initialized
DEBUG - 2024-09-11 07:15:45 --> UTF-8 Support Enabled
INFO - 2024-09-11 07:15:45 --> Utf8 Class Initialized
INFO - 2024-09-11 07:15:45 --> URI Class Initialized
DEBUG - 2024-09-11 07:15:45 --> No URI present. Default controller set.
INFO - 2024-09-11 07:15:45 --> Router Class Initialized
INFO - 2024-09-11 07:15:45 --> Output Class Initialized
INFO - 2024-09-11 07:15:45 --> Security Class Initialized
DEBUG - 2024-09-11 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 07:15:45 --> Input Class Initialized
INFO - 2024-09-11 07:15:45 --> Language Class Initialized
INFO - 2024-09-11 07:15:45 --> Loader Class Initialized
INFO - 2024-09-11 07:15:45 --> Helper loaded: url_helper
INFO - 2024-09-11 07:15:45 --> Helper loaded: file_helper
INFO - 2024-09-11 07:15:45 --> Helper loaded: security_helper
INFO - 2024-09-11 07:15:45 --> Helper loaded: wpu_helper
INFO - 2024-09-11 07:15:45 --> Database Driver Class Initialized
INFO - 2024-09-11 07:44:55 --> Config Class Initialized
INFO - 2024-09-11 07:44:55 --> Hooks Class Initialized
DEBUG - 2024-09-11 07:44:55 --> UTF-8 Support Enabled
INFO - 2024-09-11 07:44:55 --> Utf8 Class Initialized
INFO - 2024-09-11 07:44:55 --> URI Class Initialized
DEBUG - 2024-09-11 07:44:55 --> No URI present. Default controller set.
INFO - 2024-09-11 07:44:55 --> Router Class Initialized
INFO - 2024-09-11 07:44:55 --> Output Class Initialized
INFO - 2024-09-11 07:44:55 --> Security Class Initialized
DEBUG - 2024-09-11 07:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 07:44:55 --> Input Class Initialized
INFO - 2024-09-11 07:44:55 --> Language Class Initialized
INFO - 2024-09-11 07:44:55 --> Loader Class Initialized
INFO - 2024-09-11 07:44:55 --> Helper loaded: url_helper
INFO - 2024-09-11 07:44:55 --> Helper loaded: file_helper
INFO - 2024-09-11 07:44:55 --> Helper loaded: security_helper
INFO - 2024-09-11 07:44:55 --> Helper loaded: wpu_helper
INFO - 2024-09-11 07:44:55 --> Database Driver Class Initialized
INFO - 2024-09-11 08:15:50 --> Config Class Initialized
INFO - 2024-09-11 08:15:50 --> Hooks Class Initialized
DEBUG - 2024-09-11 08:15:50 --> UTF-8 Support Enabled
INFO - 2024-09-11 08:15:50 --> Utf8 Class Initialized
INFO - 2024-09-11 08:15:50 --> URI Class Initialized
DEBUG - 2024-09-11 08:15:50 --> No URI present. Default controller set.
INFO - 2024-09-11 08:15:50 --> Router Class Initialized
INFO - 2024-09-11 08:15:50 --> Output Class Initialized
INFO - 2024-09-11 08:15:50 --> Security Class Initialized
DEBUG - 2024-09-11 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 08:15:50 --> Input Class Initialized
INFO - 2024-09-11 08:15:50 --> Language Class Initialized
INFO - 2024-09-11 08:15:50 --> Loader Class Initialized
INFO - 2024-09-11 08:15:50 --> Helper loaded: url_helper
INFO - 2024-09-11 08:15:50 --> Helper loaded: file_helper
INFO - 2024-09-11 08:15:50 --> Helper loaded: security_helper
INFO - 2024-09-11 08:15:50 --> Helper loaded: wpu_helper
INFO - 2024-09-11 08:15:50 --> Database Driver Class Initialized
INFO - 2024-09-11 08:31:28 --> Config Class Initialized
INFO - 2024-09-11 08:31:28 --> Hooks Class Initialized
DEBUG - 2024-09-11 08:31:28 --> UTF-8 Support Enabled
INFO - 2024-09-11 08:31:28 --> Utf8 Class Initialized
INFO - 2024-09-11 08:31:28 --> URI Class Initialized
DEBUG - 2024-09-11 08:31:28 --> No URI present. Default controller set.
INFO - 2024-09-11 08:31:28 --> Router Class Initialized
INFO - 2024-09-11 08:31:28 --> Output Class Initialized
INFO - 2024-09-11 08:31:28 --> Security Class Initialized
DEBUG - 2024-09-11 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 08:31:28 --> Input Class Initialized
INFO - 2024-09-11 08:31:28 --> Language Class Initialized
INFO - 2024-09-11 08:31:28 --> Loader Class Initialized
INFO - 2024-09-11 08:31:28 --> Helper loaded: url_helper
INFO - 2024-09-11 08:31:28 --> Helper loaded: file_helper
INFO - 2024-09-11 08:31:28 --> Helper loaded: security_helper
INFO - 2024-09-11 08:31:28 --> Helper loaded: wpu_helper
INFO - 2024-09-11 08:31:28 --> Database Driver Class Initialized
ERROR - 2024-09-11 08:31:58 --> Unable to connect to the database
INFO - 2024-09-11 08:31:58 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 08:48:34 --> Config Class Initialized
INFO - 2024-09-11 08:48:34 --> Hooks Class Initialized
DEBUG - 2024-09-11 08:48:34 --> UTF-8 Support Enabled
INFO - 2024-09-11 08:48:34 --> Utf8 Class Initialized
INFO - 2024-09-11 08:48:34 --> URI Class Initialized
DEBUG - 2024-09-11 08:48:34 --> No URI present. Default controller set.
INFO - 2024-09-11 08:48:34 --> Router Class Initialized
INFO - 2024-09-11 08:48:34 --> Output Class Initialized
INFO - 2024-09-11 08:48:34 --> Security Class Initialized
DEBUG - 2024-09-11 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 08:48:34 --> Input Class Initialized
INFO - 2024-09-11 08:48:34 --> Language Class Initialized
INFO - 2024-09-11 08:48:34 --> Loader Class Initialized
INFO - 2024-09-11 08:48:34 --> Helper loaded: url_helper
INFO - 2024-09-11 08:48:34 --> Helper loaded: file_helper
INFO - 2024-09-11 08:48:34 --> Helper loaded: security_helper
INFO - 2024-09-11 08:48:34 --> Helper loaded: wpu_helper
INFO - 2024-09-11 08:48:34 --> Database Driver Class Initialized
INFO - 2024-09-11 09:17:33 --> Config Class Initialized
INFO - 2024-09-11 09:17:33 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:17:33 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:17:33 --> Utf8 Class Initialized
INFO - 2024-09-11 09:17:33 --> URI Class Initialized
DEBUG - 2024-09-11 09:17:33 --> No URI present. Default controller set.
INFO - 2024-09-11 09:17:33 --> Router Class Initialized
INFO - 2024-09-11 09:17:33 --> Output Class Initialized
INFO - 2024-09-11 09:17:33 --> Security Class Initialized
DEBUG - 2024-09-11 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:17:33 --> Input Class Initialized
INFO - 2024-09-11 09:17:33 --> Language Class Initialized
INFO - 2024-09-11 09:17:33 --> Loader Class Initialized
INFO - 2024-09-11 09:17:33 --> Helper loaded: url_helper
INFO - 2024-09-11 09:17:33 --> Helper loaded: file_helper
INFO - 2024-09-11 09:17:33 --> Helper loaded: security_helper
INFO - 2024-09-11 09:17:33 --> Helper loaded: wpu_helper
INFO - 2024-09-11 09:17:33 --> Database Driver Class Initialized
INFO - 2024-09-11 09:47:34 --> Config Class Initialized
INFO - 2024-09-11 09:47:34 --> Hooks Class Initialized
DEBUG - 2024-09-11 09:47:34 --> UTF-8 Support Enabled
INFO - 2024-09-11 09:47:34 --> Utf8 Class Initialized
INFO - 2024-09-11 09:47:34 --> URI Class Initialized
DEBUG - 2024-09-11 09:47:34 --> No URI present. Default controller set.
INFO - 2024-09-11 09:47:34 --> Router Class Initialized
INFO - 2024-09-11 09:47:34 --> Output Class Initialized
INFO - 2024-09-11 09:47:34 --> Security Class Initialized
DEBUG - 2024-09-11 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 09:47:34 --> Input Class Initialized
INFO - 2024-09-11 09:47:34 --> Language Class Initialized
INFO - 2024-09-11 09:47:34 --> Loader Class Initialized
INFO - 2024-09-11 09:47:34 --> Helper loaded: url_helper
INFO - 2024-09-11 09:47:34 --> Helper loaded: file_helper
INFO - 2024-09-11 09:47:34 --> Helper loaded: security_helper
INFO - 2024-09-11 09:47:34 --> Helper loaded: wpu_helper
INFO - 2024-09-11 09:47:34 --> Database Driver Class Initialized
INFO - 2024-09-11 10:22:59 --> Config Class Initialized
INFO - 2024-09-11 10:22:59 --> Hooks Class Initialized
DEBUG - 2024-09-11 10:22:59 --> UTF-8 Support Enabled
INFO - 2024-09-11 10:22:59 --> Utf8 Class Initialized
INFO - 2024-09-11 10:22:59 --> URI Class Initialized
DEBUG - 2024-09-11 10:22:59 --> No URI present. Default controller set.
INFO - 2024-09-11 10:22:59 --> Router Class Initialized
INFO - 2024-09-11 10:22:59 --> Output Class Initialized
INFO - 2024-09-11 10:22:59 --> Security Class Initialized
DEBUG - 2024-09-11 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 10:22:59 --> Input Class Initialized
INFO - 2024-09-11 10:22:59 --> Language Class Initialized
INFO - 2024-09-11 10:22:59 --> Loader Class Initialized
INFO - 2024-09-11 10:22:59 --> Helper loaded: url_helper
INFO - 2024-09-11 10:22:59 --> Helper loaded: file_helper
INFO - 2024-09-11 10:22:59 --> Helper loaded: security_helper
INFO - 2024-09-11 10:22:59 --> Helper loaded: wpu_helper
INFO - 2024-09-11 10:22:59 --> Database Driver Class Initialized
INFO - 2024-09-11 10:47:45 --> Config Class Initialized
INFO - 2024-09-11 10:47:45 --> Hooks Class Initialized
DEBUG - 2024-09-11 10:47:45 --> UTF-8 Support Enabled
INFO - 2024-09-11 10:47:45 --> Utf8 Class Initialized
INFO - 2024-09-11 10:47:45 --> URI Class Initialized
DEBUG - 2024-09-11 10:47:45 --> No URI present. Default controller set.
INFO - 2024-09-11 10:47:45 --> Router Class Initialized
INFO - 2024-09-11 10:47:45 --> Output Class Initialized
INFO - 2024-09-11 10:47:45 --> Security Class Initialized
DEBUG - 2024-09-11 10:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 10:47:45 --> Input Class Initialized
INFO - 2024-09-11 10:47:45 --> Language Class Initialized
INFO - 2024-09-11 10:47:45 --> Loader Class Initialized
INFO - 2024-09-11 10:47:45 --> Helper loaded: url_helper
INFO - 2024-09-11 10:47:45 --> Helper loaded: file_helper
INFO - 2024-09-11 10:47:45 --> Helper loaded: security_helper
INFO - 2024-09-11 10:47:45 --> Helper loaded: wpu_helper
INFO - 2024-09-11 10:47:45 --> Database Driver Class Initialized
INFO - 2024-09-11 11:21:43 --> Config Class Initialized
INFO - 2024-09-11 11:21:43 --> Hooks Class Initialized
DEBUG - 2024-09-11 11:21:43 --> UTF-8 Support Enabled
INFO - 2024-09-11 11:21:43 --> Utf8 Class Initialized
INFO - 2024-09-11 11:21:43 --> URI Class Initialized
DEBUG - 2024-09-11 11:21:43 --> No URI present. Default controller set.
INFO - 2024-09-11 11:21:43 --> Router Class Initialized
INFO - 2024-09-11 11:21:43 --> Output Class Initialized
INFO - 2024-09-11 11:21:43 --> Security Class Initialized
DEBUG - 2024-09-11 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 11:21:43 --> Input Class Initialized
INFO - 2024-09-11 11:21:43 --> Language Class Initialized
INFO - 2024-09-11 11:21:43 --> Loader Class Initialized
INFO - 2024-09-11 11:21:43 --> Helper loaded: url_helper
INFO - 2024-09-11 11:21:43 --> Helper loaded: file_helper
INFO - 2024-09-11 11:21:43 --> Helper loaded: security_helper
INFO - 2024-09-11 11:21:43 --> Helper loaded: wpu_helper
INFO - 2024-09-11 11:21:43 --> Database Driver Class Initialized
INFO - 2024-09-11 11:31:57 --> Config Class Initialized
INFO - 2024-09-11 11:31:57 --> Hooks Class Initialized
DEBUG - 2024-09-11 11:31:57 --> UTF-8 Support Enabled
INFO - 2024-09-11 11:31:57 --> Utf8 Class Initialized
INFO - 2024-09-11 11:31:57 --> URI Class Initialized
DEBUG - 2024-09-11 11:31:57 --> No URI present. Default controller set.
INFO - 2024-09-11 11:31:57 --> Router Class Initialized
INFO - 2024-09-11 11:31:57 --> Output Class Initialized
INFO - 2024-09-11 11:31:57 --> Security Class Initialized
DEBUG - 2024-09-11 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 11:31:57 --> Input Class Initialized
INFO - 2024-09-11 11:31:57 --> Language Class Initialized
INFO - 2024-09-11 11:31:57 --> Loader Class Initialized
INFO - 2024-09-11 11:31:57 --> Helper loaded: url_helper
INFO - 2024-09-11 11:31:57 --> Helper loaded: file_helper
INFO - 2024-09-11 11:31:57 --> Helper loaded: security_helper
INFO - 2024-09-11 11:31:57 --> Helper loaded: wpu_helper
INFO - 2024-09-11 11:31:57 --> Database Driver Class Initialized
ERROR - 2024-09-11 11:32:27 --> Unable to connect to the database
INFO - 2024-09-11 11:32:27 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 11:50:42 --> Config Class Initialized
INFO - 2024-09-11 11:50:42 --> Hooks Class Initialized
DEBUG - 2024-09-11 11:50:42 --> UTF-8 Support Enabled
INFO - 2024-09-11 11:50:42 --> Utf8 Class Initialized
INFO - 2024-09-11 11:50:42 --> URI Class Initialized
DEBUG - 2024-09-11 11:50:42 --> No URI present. Default controller set.
INFO - 2024-09-11 11:50:42 --> Router Class Initialized
INFO - 2024-09-11 11:50:42 --> Output Class Initialized
INFO - 2024-09-11 11:50:42 --> Security Class Initialized
DEBUG - 2024-09-11 11:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 11:50:42 --> Input Class Initialized
INFO - 2024-09-11 11:50:42 --> Language Class Initialized
INFO - 2024-09-11 11:50:42 --> Loader Class Initialized
INFO - 2024-09-11 11:50:42 --> Helper loaded: url_helper
INFO - 2024-09-11 11:50:42 --> Helper loaded: file_helper
INFO - 2024-09-11 11:50:42 --> Helper loaded: security_helper
INFO - 2024-09-11 11:50:42 --> Helper loaded: wpu_helper
INFO - 2024-09-11 11:50:42 --> Database Driver Class Initialized
INFO - 2024-09-11 12:17:55 --> Config Class Initialized
INFO - 2024-09-11 12:17:55 --> Hooks Class Initialized
DEBUG - 2024-09-11 12:17:55 --> UTF-8 Support Enabled
INFO - 2024-09-11 12:17:55 --> Utf8 Class Initialized
INFO - 2024-09-11 12:17:55 --> URI Class Initialized
DEBUG - 2024-09-11 12:17:55 --> No URI present. Default controller set.
INFO - 2024-09-11 12:17:55 --> Router Class Initialized
INFO - 2024-09-11 12:17:55 --> Output Class Initialized
INFO - 2024-09-11 12:17:55 --> Security Class Initialized
DEBUG - 2024-09-11 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 12:17:55 --> Input Class Initialized
INFO - 2024-09-11 12:17:55 --> Language Class Initialized
INFO - 2024-09-11 12:17:55 --> Loader Class Initialized
INFO - 2024-09-11 12:17:55 --> Helper loaded: url_helper
INFO - 2024-09-11 12:17:55 --> Helper loaded: file_helper
INFO - 2024-09-11 12:17:55 --> Helper loaded: security_helper
INFO - 2024-09-11 12:17:55 --> Helper loaded: wpu_helper
INFO - 2024-09-11 12:17:55 --> Database Driver Class Initialized
INFO - 2024-09-11 12:49:30 --> Config Class Initialized
INFO - 2024-09-11 12:49:30 --> Hooks Class Initialized
DEBUG - 2024-09-11 12:49:30 --> UTF-8 Support Enabled
INFO - 2024-09-11 12:49:30 --> Utf8 Class Initialized
INFO - 2024-09-11 12:49:30 --> URI Class Initialized
DEBUG - 2024-09-11 12:49:30 --> No URI present. Default controller set.
INFO - 2024-09-11 12:49:30 --> Router Class Initialized
INFO - 2024-09-11 12:49:30 --> Output Class Initialized
INFO - 2024-09-11 12:49:30 --> Security Class Initialized
DEBUG - 2024-09-11 12:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 12:49:30 --> Input Class Initialized
INFO - 2024-09-11 12:49:30 --> Language Class Initialized
INFO - 2024-09-11 12:49:30 --> Loader Class Initialized
INFO - 2024-09-11 12:49:30 --> Helper loaded: url_helper
INFO - 2024-09-11 12:49:30 --> Helper loaded: file_helper
INFO - 2024-09-11 12:49:30 --> Helper loaded: security_helper
INFO - 2024-09-11 12:49:30 --> Helper loaded: wpu_helper
INFO - 2024-09-11 12:49:30 --> Database Driver Class Initialized
INFO - 2024-09-11 13:21:11 --> Config Class Initialized
INFO - 2024-09-11 13:21:11 --> Hooks Class Initialized
DEBUG - 2024-09-11 13:21:11 --> UTF-8 Support Enabled
INFO - 2024-09-11 13:21:11 --> Utf8 Class Initialized
INFO - 2024-09-11 13:21:11 --> URI Class Initialized
DEBUG - 2024-09-11 13:21:11 --> No URI present. Default controller set.
INFO - 2024-09-11 13:21:11 --> Router Class Initialized
INFO - 2024-09-11 13:21:11 --> Output Class Initialized
INFO - 2024-09-11 13:21:11 --> Security Class Initialized
DEBUG - 2024-09-11 13:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 13:21:11 --> Input Class Initialized
INFO - 2024-09-11 13:21:11 --> Language Class Initialized
INFO - 2024-09-11 13:21:11 --> Loader Class Initialized
INFO - 2024-09-11 13:21:11 --> Helper loaded: url_helper
INFO - 2024-09-11 13:21:11 --> Helper loaded: file_helper
INFO - 2024-09-11 13:21:11 --> Helper loaded: security_helper
INFO - 2024-09-11 13:21:11 --> Helper loaded: wpu_helper
INFO - 2024-09-11 13:21:11 --> Database Driver Class Initialized
INFO - 2024-09-11 13:51:38 --> Config Class Initialized
INFO - 2024-09-11 13:51:38 --> Hooks Class Initialized
DEBUG - 2024-09-11 13:51:38 --> UTF-8 Support Enabled
INFO - 2024-09-11 13:51:38 --> Utf8 Class Initialized
INFO - 2024-09-11 13:51:38 --> URI Class Initialized
DEBUG - 2024-09-11 13:51:38 --> No URI present. Default controller set.
INFO - 2024-09-11 13:51:38 --> Router Class Initialized
INFO - 2024-09-11 13:51:38 --> Output Class Initialized
INFO - 2024-09-11 13:51:38 --> Security Class Initialized
DEBUG - 2024-09-11 13:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 13:51:38 --> Input Class Initialized
INFO - 2024-09-11 13:51:38 --> Language Class Initialized
INFO - 2024-09-11 13:51:38 --> Loader Class Initialized
INFO - 2024-09-11 13:51:38 --> Helper loaded: url_helper
INFO - 2024-09-11 13:51:38 --> Helper loaded: file_helper
INFO - 2024-09-11 13:51:38 --> Helper loaded: security_helper
INFO - 2024-09-11 13:51:38 --> Helper loaded: wpu_helper
INFO - 2024-09-11 13:51:38 --> Database Driver Class Initialized
INFO - 2024-09-11 14:17:23 --> Config Class Initialized
INFO - 2024-09-11 14:17:23 --> Hooks Class Initialized
DEBUG - 2024-09-11 14:17:23 --> UTF-8 Support Enabled
INFO - 2024-09-11 14:17:23 --> Utf8 Class Initialized
INFO - 2024-09-11 14:17:23 --> URI Class Initialized
DEBUG - 2024-09-11 14:17:23 --> No URI present. Default controller set.
INFO - 2024-09-11 14:17:23 --> Router Class Initialized
INFO - 2024-09-11 14:17:23 --> Output Class Initialized
INFO - 2024-09-11 14:17:23 --> Security Class Initialized
DEBUG - 2024-09-11 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 14:17:23 --> Input Class Initialized
INFO - 2024-09-11 14:17:23 --> Language Class Initialized
INFO - 2024-09-11 14:17:23 --> Loader Class Initialized
INFO - 2024-09-11 14:17:23 --> Helper loaded: url_helper
INFO - 2024-09-11 14:17:23 --> Helper loaded: file_helper
INFO - 2024-09-11 14:17:23 --> Helper loaded: security_helper
INFO - 2024-09-11 14:17:23 --> Helper loaded: wpu_helper
INFO - 2024-09-11 14:17:23 --> Database Driver Class Initialized
INFO - 2024-09-11 14:32:54 --> Config Class Initialized
INFO - 2024-09-11 14:32:54 --> Hooks Class Initialized
DEBUG - 2024-09-11 14:32:54 --> UTF-8 Support Enabled
INFO - 2024-09-11 14:32:54 --> Utf8 Class Initialized
INFO - 2024-09-11 14:32:54 --> URI Class Initialized
DEBUG - 2024-09-11 14:32:54 --> No URI present. Default controller set.
INFO - 2024-09-11 14:32:54 --> Router Class Initialized
INFO - 2024-09-11 14:32:54 --> Output Class Initialized
INFO - 2024-09-11 14:32:54 --> Security Class Initialized
DEBUG - 2024-09-11 14:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 14:32:54 --> Input Class Initialized
INFO - 2024-09-11 14:32:54 --> Language Class Initialized
INFO - 2024-09-11 14:32:54 --> Loader Class Initialized
INFO - 2024-09-11 14:32:54 --> Helper loaded: url_helper
INFO - 2024-09-11 14:32:54 --> Helper loaded: file_helper
INFO - 2024-09-11 14:32:54 --> Helper loaded: security_helper
INFO - 2024-09-11 14:32:54 --> Helper loaded: wpu_helper
INFO - 2024-09-11 14:32:54 --> Database Driver Class Initialized
ERROR - 2024-09-11 14:33:23 --> Unable to connect to the database
INFO - 2024-09-11 14:33:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 14:46:47 --> Config Class Initialized
INFO - 2024-09-11 14:46:47 --> Hooks Class Initialized
DEBUG - 2024-09-11 14:46:47 --> UTF-8 Support Enabled
INFO - 2024-09-11 14:46:47 --> Utf8 Class Initialized
INFO - 2024-09-11 14:46:47 --> URI Class Initialized
DEBUG - 2024-09-11 14:46:47 --> No URI present. Default controller set.
INFO - 2024-09-11 14:46:47 --> Router Class Initialized
INFO - 2024-09-11 14:46:47 --> Output Class Initialized
INFO - 2024-09-11 14:46:47 --> Security Class Initialized
DEBUG - 2024-09-11 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 14:46:47 --> Input Class Initialized
INFO - 2024-09-11 14:46:47 --> Language Class Initialized
INFO - 2024-09-11 14:46:47 --> Loader Class Initialized
INFO - 2024-09-11 14:46:47 --> Helper loaded: url_helper
INFO - 2024-09-11 14:46:47 --> Helper loaded: file_helper
INFO - 2024-09-11 14:46:47 --> Helper loaded: security_helper
INFO - 2024-09-11 14:46:47 --> Helper loaded: wpu_helper
INFO - 2024-09-11 14:46:47 --> Database Driver Class Initialized
INFO - 2024-09-11 15:22:51 --> Config Class Initialized
INFO - 2024-09-11 15:22:51 --> Hooks Class Initialized
DEBUG - 2024-09-11 15:22:51 --> UTF-8 Support Enabled
INFO - 2024-09-11 15:22:51 --> Utf8 Class Initialized
INFO - 2024-09-11 15:22:51 --> URI Class Initialized
DEBUG - 2024-09-11 15:22:51 --> No URI present. Default controller set.
INFO - 2024-09-11 15:22:51 --> Router Class Initialized
INFO - 2024-09-11 15:22:51 --> Output Class Initialized
INFO - 2024-09-11 15:22:51 --> Security Class Initialized
DEBUG - 2024-09-11 15:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 15:22:51 --> Input Class Initialized
INFO - 2024-09-11 15:22:51 --> Language Class Initialized
INFO - 2024-09-11 15:22:51 --> Loader Class Initialized
INFO - 2024-09-11 15:22:51 --> Helper loaded: url_helper
INFO - 2024-09-11 15:22:51 --> Helper loaded: file_helper
INFO - 2024-09-11 15:22:51 --> Helper loaded: security_helper
INFO - 2024-09-11 15:22:51 --> Helper loaded: wpu_helper
INFO - 2024-09-11 15:22:51 --> Database Driver Class Initialized
ERROR - 2024-09-11 15:22:58 --> Unable to connect to the database
INFO - 2024-09-11 15:22:58 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 15:54:02 --> Config Class Initialized
INFO - 2024-09-11 15:54:02 --> Hooks Class Initialized
DEBUG - 2024-09-11 15:54:02 --> UTF-8 Support Enabled
INFO - 2024-09-11 15:54:02 --> Utf8 Class Initialized
INFO - 2024-09-11 15:54:02 --> URI Class Initialized
DEBUG - 2024-09-11 15:54:02 --> No URI present. Default controller set.
INFO - 2024-09-11 15:54:02 --> Router Class Initialized
INFO - 2024-09-11 15:54:02 --> Output Class Initialized
INFO - 2024-09-11 15:54:02 --> Security Class Initialized
DEBUG - 2024-09-11 15:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 15:54:02 --> Input Class Initialized
INFO - 2024-09-11 15:54:02 --> Language Class Initialized
INFO - 2024-09-11 15:54:02 --> Loader Class Initialized
INFO - 2024-09-11 15:54:02 --> Helper loaded: url_helper
INFO - 2024-09-11 15:54:02 --> Helper loaded: file_helper
INFO - 2024-09-11 15:54:02 --> Helper loaded: security_helper
INFO - 2024-09-11 15:54:02 --> Helper loaded: wpu_helper
INFO - 2024-09-11 15:54:02 --> Database Driver Class Initialized
ERROR - 2024-09-11 15:54:09 --> Unable to connect to the database
INFO - 2024-09-11 15:54:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 16:26:35 --> Config Class Initialized
INFO - 2024-09-11 16:26:35 --> Hooks Class Initialized
DEBUG - 2024-09-11 16:26:35 --> UTF-8 Support Enabled
INFO - 2024-09-11 16:26:35 --> Utf8 Class Initialized
INFO - 2024-09-11 16:26:35 --> URI Class Initialized
DEBUG - 2024-09-11 16:26:35 --> No URI present. Default controller set.
INFO - 2024-09-11 16:26:35 --> Router Class Initialized
INFO - 2024-09-11 16:26:35 --> Output Class Initialized
INFO - 2024-09-11 16:26:35 --> Security Class Initialized
DEBUG - 2024-09-11 16:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 16:26:35 --> Input Class Initialized
INFO - 2024-09-11 16:26:35 --> Language Class Initialized
INFO - 2024-09-11 16:26:35 --> Loader Class Initialized
INFO - 2024-09-11 16:26:35 --> Helper loaded: url_helper
INFO - 2024-09-11 16:26:35 --> Helper loaded: file_helper
INFO - 2024-09-11 16:26:35 --> Helper loaded: security_helper
INFO - 2024-09-11 16:26:35 --> Helper loaded: wpu_helper
INFO - 2024-09-11 16:26:35 --> Database Driver Class Initialized
ERROR - 2024-09-11 16:26:42 --> Unable to connect to the database
INFO - 2024-09-11 16:26:42 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 16:56:07 --> Config Class Initialized
INFO - 2024-09-11 16:56:07 --> Hooks Class Initialized
DEBUG - 2024-09-11 16:56:07 --> UTF-8 Support Enabled
INFO - 2024-09-11 16:56:07 --> Utf8 Class Initialized
INFO - 2024-09-11 16:56:07 --> URI Class Initialized
DEBUG - 2024-09-11 16:56:07 --> No URI present. Default controller set.
INFO - 2024-09-11 16:56:07 --> Router Class Initialized
INFO - 2024-09-11 16:56:07 --> Output Class Initialized
INFO - 2024-09-11 16:56:07 --> Security Class Initialized
DEBUG - 2024-09-11 16:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 16:56:07 --> Input Class Initialized
INFO - 2024-09-11 16:56:07 --> Language Class Initialized
INFO - 2024-09-11 16:56:07 --> Loader Class Initialized
INFO - 2024-09-11 16:56:07 --> Helper loaded: url_helper
INFO - 2024-09-11 16:56:07 --> Helper loaded: file_helper
INFO - 2024-09-11 16:56:07 --> Helper loaded: security_helper
INFO - 2024-09-11 16:56:07 --> Helper loaded: wpu_helper
INFO - 2024-09-11 16:56:07 --> Database Driver Class Initialized
ERROR - 2024-09-11 16:56:14 --> Unable to connect to the database
INFO - 2024-09-11 16:56:14 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 17:19:28 --> Config Class Initialized
INFO - 2024-09-11 17:19:28 --> Hooks Class Initialized
DEBUG - 2024-09-11 17:19:28 --> UTF-8 Support Enabled
INFO - 2024-09-11 17:19:28 --> Utf8 Class Initialized
INFO - 2024-09-11 17:19:28 --> URI Class Initialized
DEBUG - 2024-09-11 17:19:28 --> No URI present. Default controller set.
INFO - 2024-09-11 17:19:28 --> Router Class Initialized
INFO - 2024-09-11 17:19:28 --> Output Class Initialized
INFO - 2024-09-11 17:19:28 --> Security Class Initialized
DEBUG - 2024-09-11 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 17:19:28 --> Input Class Initialized
INFO - 2024-09-11 17:19:28 --> Language Class Initialized
INFO - 2024-09-11 17:19:28 --> Loader Class Initialized
INFO - 2024-09-11 17:19:28 --> Helper loaded: url_helper
INFO - 2024-09-11 17:19:28 --> Helper loaded: file_helper
INFO - 2024-09-11 17:19:28 --> Helper loaded: security_helper
INFO - 2024-09-11 17:19:28 --> Helper loaded: wpu_helper
INFO - 2024-09-11 17:19:28 --> Database Driver Class Initialized
ERROR - 2024-09-11 17:19:35 --> Unable to connect to the database
INFO - 2024-09-11 17:19:35 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 17:31:04 --> Config Class Initialized
INFO - 2024-09-11 17:31:04 --> Hooks Class Initialized
DEBUG - 2024-09-11 17:31:04 --> UTF-8 Support Enabled
INFO - 2024-09-11 17:31:04 --> Utf8 Class Initialized
INFO - 2024-09-11 17:31:04 --> URI Class Initialized
DEBUG - 2024-09-11 17:31:04 --> No URI present. Default controller set.
INFO - 2024-09-11 17:31:04 --> Router Class Initialized
INFO - 2024-09-11 17:31:04 --> Output Class Initialized
INFO - 2024-09-11 17:31:04 --> Security Class Initialized
DEBUG - 2024-09-11 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 17:31:04 --> Input Class Initialized
INFO - 2024-09-11 17:31:04 --> Language Class Initialized
INFO - 2024-09-11 17:31:04 --> Loader Class Initialized
INFO - 2024-09-11 17:31:04 --> Helper loaded: url_helper
INFO - 2024-09-11 17:31:04 --> Helper loaded: file_helper
INFO - 2024-09-11 17:31:04 --> Helper loaded: security_helper
INFO - 2024-09-11 17:31:04 --> Helper loaded: wpu_helper
INFO - 2024-09-11 17:31:04 --> Database Driver Class Initialized
ERROR - 2024-09-11 17:31:12 --> Unable to connect to the database
INFO - 2024-09-11 17:31:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 17:47:58 --> Config Class Initialized
INFO - 2024-09-11 17:47:58 --> Hooks Class Initialized
DEBUG - 2024-09-11 17:47:58 --> UTF-8 Support Enabled
INFO - 2024-09-11 17:47:58 --> Utf8 Class Initialized
INFO - 2024-09-11 17:47:58 --> URI Class Initialized
DEBUG - 2024-09-11 17:47:58 --> No URI present. Default controller set.
INFO - 2024-09-11 17:47:58 --> Router Class Initialized
INFO - 2024-09-11 17:47:58 --> Output Class Initialized
INFO - 2024-09-11 17:47:58 --> Security Class Initialized
DEBUG - 2024-09-11 17:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 17:47:58 --> Input Class Initialized
INFO - 2024-09-11 17:47:58 --> Language Class Initialized
INFO - 2024-09-11 17:47:58 --> Loader Class Initialized
INFO - 2024-09-11 17:47:58 --> Helper loaded: url_helper
INFO - 2024-09-11 17:47:58 --> Helper loaded: file_helper
INFO - 2024-09-11 17:47:58 --> Helper loaded: security_helper
INFO - 2024-09-11 17:47:58 --> Helper loaded: wpu_helper
INFO - 2024-09-11 17:47:58 --> Database Driver Class Initialized
ERROR - 2024-09-11 17:48:06 --> Unable to connect to the database
INFO - 2024-09-11 17:48:06 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 18:15:42 --> Config Class Initialized
INFO - 2024-09-11 18:15:42 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:15:42 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:15:42 --> Utf8 Class Initialized
INFO - 2024-09-11 18:15:42 --> URI Class Initialized
DEBUG - 2024-09-11 18:15:42 --> No URI present. Default controller set.
INFO - 2024-09-11 18:15:42 --> Router Class Initialized
INFO - 2024-09-11 18:15:42 --> Output Class Initialized
INFO - 2024-09-11 18:15:42 --> Security Class Initialized
DEBUG - 2024-09-11 18:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:15:42 --> Input Class Initialized
INFO - 2024-09-11 18:15:42 --> Language Class Initialized
INFO - 2024-09-11 18:15:42 --> Loader Class Initialized
INFO - 2024-09-11 18:15:42 --> Helper loaded: url_helper
INFO - 2024-09-11 18:15:42 --> Helper loaded: file_helper
INFO - 2024-09-11 18:15:42 --> Helper loaded: security_helper
INFO - 2024-09-11 18:15:42 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:15:42 --> Database Driver Class Initialized
ERROR - 2024-09-11 18:15:49 --> Unable to connect to the database
INFO - 2024-09-11 18:15:49 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 18:44:41 --> Config Class Initialized
INFO - 2024-09-11 18:44:41 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:44:41 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:44:41 --> Utf8 Class Initialized
INFO - 2024-09-11 18:44:41 --> URI Class Initialized
DEBUG - 2024-09-11 18:44:41 --> No URI present. Default controller set.
INFO - 2024-09-11 18:44:41 --> Router Class Initialized
INFO - 2024-09-11 18:44:41 --> Output Class Initialized
INFO - 2024-09-11 18:44:41 --> Security Class Initialized
DEBUG - 2024-09-11 18:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:44:41 --> Input Class Initialized
INFO - 2024-09-11 18:44:41 --> Language Class Initialized
INFO - 2024-09-11 18:44:41 --> Loader Class Initialized
INFO - 2024-09-11 18:44:41 --> Helper loaded: url_helper
INFO - 2024-09-11 18:44:41 --> Helper loaded: file_helper
INFO - 2024-09-11 18:44:41 --> Helper loaded: security_helper
INFO - 2024-09-11 18:44:41 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:44:41 --> Database Driver Class Initialized
ERROR - 2024-09-11 18:44:48 --> Unable to connect to the database
INFO - 2024-09-11 18:44:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 18:47:53 --> Config Class Initialized
INFO - 2024-09-11 18:47:53 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:47:53 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:47:53 --> Utf8 Class Initialized
INFO - 2024-09-11 18:47:53 --> URI Class Initialized
DEBUG - 2024-09-11 18:47:53 --> No URI present. Default controller set.
INFO - 2024-09-11 18:47:53 --> Router Class Initialized
INFO - 2024-09-11 18:47:53 --> Output Class Initialized
INFO - 2024-09-11 18:47:53 --> Security Class Initialized
DEBUG - 2024-09-11 18:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:47:53 --> Input Class Initialized
INFO - 2024-09-11 18:47:53 --> Language Class Initialized
INFO - 2024-09-11 18:47:53 --> Loader Class Initialized
INFO - 2024-09-11 18:47:53 --> Helper loaded: url_helper
INFO - 2024-09-11 18:47:53 --> Helper loaded: file_helper
INFO - 2024-09-11 18:47:53 --> Helper loaded: security_helper
INFO - 2024-09-11 18:47:53 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:47:53 --> Database Driver Class Initialized
INFO - 2024-09-11 18:47:57 --> Config Class Initialized
INFO - 2024-09-11 18:47:57 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:47:57 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:47:57 --> Utf8 Class Initialized
INFO - 2024-09-11 18:47:57 --> URI Class Initialized
DEBUG - 2024-09-11 18:47:57 --> No URI present. Default controller set.
INFO - 2024-09-11 18:47:57 --> Router Class Initialized
INFO - 2024-09-11 18:47:57 --> Output Class Initialized
INFO - 2024-09-11 18:47:57 --> Security Class Initialized
DEBUG - 2024-09-11 18:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:47:57 --> Input Class Initialized
INFO - 2024-09-11 18:47:57 --> Language Class Initialized
INFO - 2024-09-11 18:47:57 --> Loader Class Initialized
INFO - 2024-09-11 18:47:57 --> Helper loaded: url_helper
INFO - 2024-09-11 18:47:57 --> Helper loaded: file_helper
INFO - 2024-09-11 18:47:57 --> Helper loaded: security_helper
INFO - 2024-09-11 18:47:57 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:47:57 --> Database Driver Class Initialized
ERROR - 2024-09-11 18:48:00 --> Unable to connect to the database
INFO - 2024-09-11 18:48:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-09-11 18:48:04 --> Unable to connect to the database
INFO - 2024-09-11 18:48:04 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 18:50:14 --> Config Class Initialized
INFO - 2024-09-11 18:50:14 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:50:14 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:50:14 --> Utf8 Class Initialized
INFO - 2024-09-11 18:50:14 --> URI Class Initialized
DEBUG - 2024-09-11 18:50:14 --> No URI present. Default controller set.
INFO - 2024-09-11 18:50:14 --> Router Class Initialized
INFO - 2024-09-11 18:50:14 --> Output Class Initialized
INFO - 2024-09-11 18:50:14 --> Security Class Initialized
DEBUG - 2024-09-11 18:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:50:14 --> Input Class Initialized
INFO - 2024-09-11 18:50:14 --> Language Class Initialized
INFO - 2024-09-11 18:50:14 --> Loader Class Initialized
INFO - 2024-09-11 18:50:14 --> Helper loaded: url_helper
INFO - 2024-09-11 18:50:14 --> Helper loaded: file_helper
INFO - 2024-09-11 18:50:14 --> Helper loaded: security_helper
INFO - 2024-09-11 18:50:14 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:50:14 --> Database Driver Class Initialized
ERROR - 2024-09-11 18:50:21 --> Unable to connect to the database
INFO - 2024-09-11 18:50:21 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 18:52:05 --> Config Class Initialized
INFO - 2024-09-11 18:52:05 --> Hooks Class Initialized
DEBUG - 2024-09-11 18:52:05 --> UTF-8 Support Enabled
INFO - 2024-09-11 18:52:05 --> Utf8 Class Initialized
INFO - 2024-09-11 18:52:05 --> URI Class Initialized
DEBUG - 2024-09-11 18:52:05 --> No URI present. Default controller set.
INFO - 2024-09-11 18:52:05 --> Router Class Initialized
INFO - 2024-09-11 18:52:05 --> Output Class Initialized
INFO - 2024-09-11 18:52:05 --> Security Class Initialized
DEBUG - 2024-09-11 18:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 18:52:05 --> Input Class Initialized
INFO - 2024-09-11 18:52:05 --> Language Class Initialized
INFO - 2024-09-11 18:52:05 --> Loader Class Initialized
INFO - 2024-09-11 18:52:05 --> Helper loaded: url_helper
INFO - 2024-09-11 18:52:05 --> Helper loaded: file_helper
INFO - 2024-09-11 18:52:05 --> Helper loaded: security_helper
INFO - 2024-09-11 18:52:05 --> Helper loaded: wpu_helper
INFO - 2024-09-11 18:52:05 --> Database Driver Class Initialized
ERROR - 2024-09-11 18:52:12 --> Unable to connect to the database
INFO - 2024-09-11 18:52:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 19:16:00 --> Config Class Initialized
INFO - 2024-09-11 19:16:00 --> Hooks Class Initialized
DEBUG - 2024-09-11 19:16:00 --> UTF-8 Support Enabled
INFO - 2024-09-11 19:16:00 --> Utf8 Class Initialized
INFO - 2024-09-11 19:16:00 --> URI Class Initialized
DEBUG - 2024-09-11 19:16:00 --> No URI present. Default controller set.
INFO - 2024-09-11 19:16:00 --> Router Class Initialized
INFO - 2024-09-11 19:16:00 --> Output Class Initialized
INFO - 2024-09-11 19:16:00 --> Security Class Initialized
DEBUG - 2024-09-11 19:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 19:16:00 --> Input Class Initialized
INFO - 2024-09-11 19:16:00 --> Language Class Initialized
INFO - 2024-09-11 19:16:00 --> Loader Class Initialized
INFO - 2024-09-11 19:16:00 --> Helper loaded: url_helper
INFO - 2024-09-11 19:16:00 --> Helper loaded: file_helper
INFO - 2024-09-11 19:16:00 --> Helper loaded: security_helper
INFO - 2024-09-11 19:16:00 --> Helper loaded: wpu_helper
INFO - 2024-09-11 19:16:00 --> Database Driver Class Initialized
ERROR - 2024-09-11 19:16:07 --> Unable to connect to the database
INFO - 2024-09-11 19:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 19:46:41 --> Config Class Initialized
INFO - 2024-09-11 19:46:41 --> Hooks Class Initialized
DEBUG - 2024-09-11 19:46:41 --> UTF-8 Support Enabled
INFO - 2024-09-11 19:46:41 --> Utf8 Class Initialized
INFO - 2024-09-11 19:46:41 --> URI Class Initialized
DEBUG - 2024-09-11 19:46:41 --> No URI present. Default controller set.
INFO - 2024-09-11 19:46:41 --> Router Class Initialized
INFO - 2024-09-11 19:46:41 --> Output Class Initialized
INFO - 2024-09-11 19:46:41 --> Security Class Initialized
DEBUG - 2024-09-11 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 19:46:41 --> Input Class Initialized
INFO - 2024-09-11 19:46:41 --> Language Class Initialized
INFO - 2024-09-11 19:46:41 --> Loader Class Initialized
INFO - 2024-09-11 19:46:41 --> Helper loaded: url_helper
INFO - 2024-09-11 19:46:41 --> Helper loaded: file_helper
INFO - 2024-09-11 19:46:41 --> Helper loaded: security_helper
INFO - 2024-09-11 19:46:41 --> Helper loaded: wpu_helper
INFO - 2024-09-11 19:46:41 --> Database Driver Class Initialized
ERROR - 2024-09-11 19:46:48 --> Unable to connect to the database
INFO - 2024-09-11 19:46:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 20:15:29 --> Config Class Initialized
INFO - 2024-09-11 20:15:29 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:15:29 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:15:29 --> Utf8 Class Initialized
INFO - 2024-09-11 20:15:29 --> URI Class Initialized
DEBUG - 2024-09-11 20:15:29 --> No URI present. Default controller set.
INFO - 2024-09-11 20:15:29 --> Router Class Initialized
INFO - 2024-09-11 20:15:29 --> Output Class Initialized
INFO - 2024-09-11 20:15:29 --> Security Class Initialized
DEBUG - 2024-09-11 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:15:29 --> Input Class Initialized
INFO - 2024-09-11 20:15:29 --> Language Class Initialized
INFO - 2024-09-11 20:15:29 --> Loader Class Initialized
INFO - 2024-09-11 20:15:29 --> Helper loaded: url_helper
INFO - 2024-09-11 20:15:29 --> Helper loaded: file_helper
INFO - 2024-09-11 20:15:29 --> Helper loaded: security_helper
INFO - 2024-09-11 20:15:29 --> Helper loaded: wpu_helper
INFO - 2024-09-11 20:15:29 --> Database Driver Class Initialized
ERROR - 2024-09-11 20:15:37 --> Unable to connect to the database
INFO - 2024-09-11 20:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 20:32:12 --> Config Class Initialized
INFO - 2024-09-11 20:32:12 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:32:12 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:32:12 --> Utf8 Class Initialized
INFO - 2024-09-11 20:32:12 --> URI Class Initialized
DEBUG - 2024-09-11 20:32:12 --> No URI present. Default controller set.
INFO - 2024-09-11 20:32:12 --> Router Class Initialized
INFO - 2024-09-11 20:32:12 --> Output Class Initialized
INFO - 2024-09-11 20:32:12 --> Security Class Initialized
DEBUG - 2024-09-11 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:32:12 --> Input Class Initialized
INFO - 2024-09-11 20:32:12 --> Language Class Initialized
INFO - 2024-09-11 20:32:12 --> Loader Class Initialized
INFO - 2024-09-11 20:32:12 --> Helper loaded: url_helper
INFO - 2024-09-11 20:32:12 --> Helper loaded: file_helper
INFO - 2024-09-11 20:32:12 --> Helper loaded: security_helper
INFO - 2024-09-11 20:32:12 --> Helper loaded: wpu_helper
INFO - 2024-09-11 20:32:12 --> Database Driver Class Initialized
ERROR - 2024-09-11 20:32:19 --> Unable to connect to the database
INFO - 2024-09-11 20:32:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 20:46:35 --> Config Class Initialized
INFO - 2024-09-11 20:46:35 --> Hooks Class Initialized
DEBUG - 2024-09-11 20:46:35 --> UTF-8 Support Enabled
INFO - 2024-09-11 20:46:35 --> Utf8 Class Initialized
INFO - 2024-09-11 20:46:35 --> URI Class Initialized
DEBUG - 2024-09-11 20:46:35 --> No URI present. Default controller set.
INFO - 2024-09-11 20:46:35 --> Router Class Initialized
INFO - 2024-09-11 20:46:35 --> Output Class Initialized
INFO - 2024-09-11 20:46:35 --> Security Class Initialized
DEBUG - 2024-09-11 20:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 20:46:35 --> Input Class Initialized
INFO - 2024-09-11 20:46:35 --> Language Class Initialized
INFO - 2024-09-11 20:46:35 --> Loader Class Initialized
INFO - 2024-09-11 20:46:35 --> Helper loaded: url_helper
INFO - 2024-09-11 20:46:35 --> Helper loaded: file_helper
INFO - 2024-09-11 20:46:35 --> Helper loaded: security_helper
INFO - 2024-09-11 20:46:35 --> Helper loaded: wpu_helper
INFO - 2024-09-11 20:46:35 --> Database Driver Class Initialized
ERROR - 2024-09-11 20:46:42 --> Unable to connect to the database
INFO - 2024-09-11 20:46:42 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 21:17:28 --> Config Class Initialized
INFO - 2024-09-11 21:17:28 --> Hooks Class Initialized
DEBUG - 2024-09-11 21:17:28 --> UTF-8 Support Enabled
INFO - 2024-09-11 21:17:28 --> Utf8 Class Initialized
INFO - 2024-09-11 21:17:28 --> URI Class Initialized
DEBUG - 2024-09-11 21:17:28 --> No URI present. Default controller set.
INFO - 2024-09-11 21:17:28 --> Router Class Initialized
INFO - 2024-09-11 21:17:28 --> Output Class Initialized
INFO - 2024-09-11 21:17:28 --> Security Class Initialized
DEBUG - 2024-09-11 21:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 21:17:28 --> Input Class Initialized
INFO - 2024-09-11 21:17:28 --> Language Class Initialized
INFO - 2024-09-11 21:17:28 --> Loader Class Initialized
INFO - 2024-09-11 21:17:28 --> Helper loaded: url_helper
INFO - 2024-09-11 21:17:28 --> Helper loaded: file_helper
INFO - 2024-09-11 21:17:28 --> Helper loaded: security_helper
INFO - 2024-09-11 21:17:28 --> Helper loaded: wpu_helper
INFO - 2024-09-11 21:17:28 --> Database Driver Class Initialized
ERROR - 2024-09-11 21:17:35 --> Unable to connect to the database
INFO - 2024-09-11 21:17:35 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 21:47:08 --> Config Class Initialized
INFO - 2024-09-11 21:47:08 --> Hooks Class Initialized
DEBUG - 2024-09-11 21:47:08 --> UTF-8 Support Enabled
INFO - 2024-09-11 21:47:08 --> Utf8 Class Initialized
INFO - 2024-09-11 21:47:08 --> URI Class Initialized
DEBUG - 2024-09-11 21:47:08 --> No URI present. Default controller set.
INFO - 2024-09-11 21:47:08 --> Router Class Initialized
INFO - 2024-09-11 21:47:08 --> Output Class Initialized
INFO - 2024-09-11 21:47:08 --> Security Class Initialized
DEBUG - 2024-09-11 21:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 21:47:08 --> Input Class Initialized
INFO - 2024-09-11 21:47:08 --> Language Class Initialized
INFO - 2024-09-11 21:47:08 --> Loader Class Initialized
INFO - 2024-09-11 21:47:08 --> Helper loaded: url_helper
INFO - 2024-09-11 21:47:08 --> Helper loaded: file_helper
INFO - 2024-09-11 21:47:08 --> Helper loaded: security_helper
INFO - 2024-09-11 21:47:08 --> Helper loaded: wpu_helper
INFO - 2024-09-11 21:47:08 --> Database Driver Class Initialized
ERROR - 2024-09-11 21:47:15 --> Unable to connect to the database
INFO - 2024-09-11 21:47:15 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 22:16:52 --> Config Class Initialized
INFO - 2024-09-11 22:16:52 --> Hooks Class Initialized
DEBUG - 2024-09-11 22:16:52 --> UTF-8 Support Enabled
INFO - 2024-09-11 22:16:52 --> Utf8 Class Initialized
INFO - 2024-09-11 22:16:52 --> URI Class Initialized
DEBUG - 2024-09-11 22:16:52 --> No URI present. Default controller set.
INFO - 2024-09-11 22:16:52 --> Router Class Initialized
INFO - 2024-09-11 22:16:52 --> Output Class Initialized
INFO - 2024-09-11 22:16:52 --> Security Class Initialized
DEBUG - 2024-09-11 22:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 22:16:52 --> Input Class Initialized
INFO - 2024-09-11 22:16:52 --> Language Class Initialized
INFO - 2024-09-11 22:16:52 --> Loader Class Initialized
INFO - 2024-09-11 22:16:52 --> Helper loaded: url_helper
INFO - 2024-09-11 22:16:52 --> Helper loaded: file_helper
INFO - 2024-09-11 22:16:52 --> Helper loaded: security_helper
INFO - 2024-09-11 22:16:52 --> Helper loaded: wpu_helper
INFO - 2024-09-11 22:16:52 --> Database Driver Class Initialized
ERROR - 2024-09-11 22:16:59 --> Unable to connect to the database
INFO - 2024-09-11 22:16:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 22:48:02 --> Config Class Initialized
INFO - 2024-09-11 22:48:02 --> Hooks Class Initialized
DEBUG - 2024-09-11 22:48:02 --> UTF-8 Support Enabled
INFO - 2024-09-11 22:48:02 --> Utf8 Class Initialized
INFO - 2024-09-11 22:48:02 --> URI Class Initialized
DEBUG - 2024-09-11 22:48:02 --> No URI present. Default controller set.
INFO - 2024-09-11 22:48:02 --> Router Class Initialized
INFO - 2024-09-11 22:48:02 --> Output Class Initialized
INFO - 2024-09-11 22:48:02 --> Security Class Initialized
DEBUG - 2024-09-11 22:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 22:48:02 --> Input Class Initialized
INFO - 2024-09-11 22:48:02 --> Language Class Initialized
INFO - 2024-09-11 22:48:02 --> Loader Class Initialized
INFO - 2024-09-11 22:48:02 --> Helper loaded: url_helper
INFO - 2024-09-11 22:48:02 --> Helper loaded: file_helper
INFO - 2024-09-11 22:48:02 --> Helper loaded: security_helper
INFO - 2024-09-11 22:48:02 --> Helper loaded: wpu_helper
INFO - 2024-09-11 22:48:02 --> Database Driver Class Initialized
ERROR - 2024-09-11 22:48:10 --> Unable to connect to the database
INFO - 2024-09-11 22:48:10 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 23:18:53 --> Config Class Initialized
INFO - 2024-09-11 23:18:53 --> Hooks Class Initialized
DEBUG - 2024-09-11 23:18:53 --> UTF-8 Support Enabled
INFO - 2024-09-11 23:18:53 --> Utf8 Class Initialized
INFO - 2024-09-11 23:18:53 --> URI Class Initialized
DEBUG - 2024-09-11 23:18:53 --> No URI present. Default controller set.
INFO - 2024-09-11 23:18:53 --> Router Class Initialized
INFO - 2024-09-11 23:18:53 --> Output Class Initialized
INFO - 2024-09-11 23:18:53 --> Security Class Initialized
DEBUG - 2024-09-11 23:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 23:18:53 --> Input Class Initialized
INFO - 2024-09-11 23:18:53 --> Language Class Initialized
INFO - 2024-09-11 23:18:53 --> Loader Class Initialized
INFO - 2024-09-11 23:18:53 --> Helper loaded: url_helper
INFO - 2024-09-11 23:18:53 --> Helper loaded: file_helper
INFO - 2024-09-11 23:18:53 --> Helper loaded: security_helper
INFO - 2024-09-11 23:18:53 --> Helper loaded: wpu_helper
INFO - 2024-09-11 23:18:53 --> Database Driver Class Initialized
ERROR - 2024-09-11 23:19:00 --> Unable to connect to the database
INFO - 2024-09-11 23:19:00 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 23:33:41 --> Config Class Initialized
INFO - 2024-09-11 23:33:41 --> Hooks Class Initialized
DEBUG - 2024-09-11 23:33:41 --> UTF-8 Support Enabled
INFO - 2024-09-11 23:33:41 --> Utf8 Class Initialized
INFO - 2024-09-11 23:33:41 --> URI Class Initialized
DEBUG - 2024-09-11 23:33:41 --> No URI present. Default controller set.
INFO - 2024-09-11 23:33:41 --> Router Class Initialized
INFO - 2024-09-11 23:33:41 --> Output Class Initialized
INFO - 2024-09-11 23:33:41 --> Security Class Initialized
DEBUG - 2024-09-11 23:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 23:33:41 --> Input Class Initialized
INFO - 2024-09-11 23:33:41 --> Language Class Initialized
INFO - 2024-09-11 23:33:41 --> Loader Class Initialized
INFO - 2024-09-11 23:33:41 --> Helper loaded: url_helper
INFO - 2024-09-11 23:33:41 --> Helper loaded: file_helper
INFO - 2024-09-11 23:33:41 --> Helper loaded: security_helper
INFO - 2024-09-11 23:33:41 --> Helper loaded: wpu_helper
INFO - 2024-09-11 23:33:41 --> Database Driver Class Initialized
ERROR - 2024-09-11 23:33:48 --> Unable to connect to the database
INFO - 2024-09-11 23:33:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-11 23:47:11 --> Config Class Initialized
INFO - 2024-09-11 23:47:11 --> Hooks Class Initialized
DEBUG - 2024-09-11 23:47:11 --> UTF-8 Support Enabled
INFO - 2024-09-11 23:47:11 --> Utf8 Class Initialized
INFO - 2024-09-11 23:47:11 --> URI Class Initialized
DEBUG - 2024-09-11 23:47:11 --> No URI present. Default controller set.
INFO - 2024-09-11 23:47:11 --> Router Class Initialized
INFO - 2024-09-11 23:47:11 --> Output Class Initialized
INFO - 2024-09-11 23:47:11 --> Security Class Initialized
DEBUG - 2024-09-11 23:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-11 23:47:11 --> Input Class Initialized
INFO - 2024-09-11 23:47:11 --> Language Class Initialized
INFO - 2024-09-11 23:47:11 --> Loader Class Initialized
INFO - 2024-09-11 23:47:11 --> Helper loaded: url_helper
INFO - 2024-09-11 23:47:11 --> Helper loaded: file_helper
INFO - 2024-09-11 23:47:11 --> Helper loaded: security_helper
INFO - 2024-09-11 23:47:11 --> Helper loaded: wpu_helper
INFO - 2024-09-11 23:47:11 --> Database Driver Class Initialized
ERROR - 2024-09-11 23:47:18 --> Unable to connect to the database
INFO - 2024-09-11 23:47:18 --> Language file loaded: language/english/db_lang.php
