<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-19 04:15:53 --> Config Class Initialized
INFO - 2024-09-19 04:15:53 --> Hooks Class Initialized
DEBUG - 2024-09-19 04:15:53 --> UTF-8 Support Enabled
INFO - 2024-09-19 04:15:53 --> Utf8 Class Initialized
INFO - 2024-09-19 04:15:53 --> URI Class Initialized
DEBUG - 2024-09-19 04:15:53 --> No URI present. Default controller set.
INFO - 2024-09-19 04:15:53 --> Router Class Initialized
INFO - 2024-09-19 04:15:53 --> Output Class Initialized
INFO - 2024-09-19 04:15:53 --> Security Class Initialized
DEBUG - 2024-09-19 04:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 04:15:53 --> Input Class Initialized
INFO - 2024-09-19 04:15:53 --> Language Class Initialized
INFO - 2024-09-19 04:15:53 --> Loader Class Initialized
INFO - 2024-09-19 04:15:53 --> Helper loaded: url_helper
INFO - 2024-09-19 04:15:53 --> Helper loaded: file_helper
INFO - 2024-09-19 04:15:53 --> Helper loaded: security_helper
INFO - 2024-09-19 04:15:53 --> Helper loaded: wpu_helper
INFO - 2024-09-19 04:15:53 --> Database Driver Class Initialized
INFO - 2024-09-19 04:15:56 --> Config Class Initialized
INFO - 2024-09-19 04:15:56 --> Hooks Class Initialized
DEBUG - 2024-09-19 04:15:56 --> UTF-8 Support Enabled
INFO - 2024-09-19 04:15:56 --> Utf8 Class Initialized
INFO - 2024-09-19 04:15:56 --> URI Class Initialized
DEBUG - 2024-09-19 04:15:56 --> No URI present. Default controller set.
INFO - 2024-09-19 04:15:56 --> Router Class Initialized
INFO - 2024-09-19 04:15:56 --> Output Class Initialized
INFO - 2024-09-19 04:15:56 --> Security Class Initialized
DEBUG - 2024-09-19 04:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 04:15:56 --> Input Class Initialized
INFO - 2024-09-19 04:15:56 --> Language Class Initialized
INFO - 2024-09-19 04:15:56 --> Loader Class Initialized
INFO - 2024-09-19 04:15:56 --> Helper loaded: url_helper
INFO - 2024-09-19 04:15:56 --> Helper loaded: file_helper
INFO - 2024-09-19 04:15:56 --> Helper loaded: security_helper
INFO - 2024-09-19 04:15:56 --> Helper loaded: wpu_helper
INFO - 2024-09-19 04:15:56 --> Database Driver Class Initialized
ERROR - 2024-09-19 04:16:25 --> Unable to connect to the database
INFO - 2024-09-19 04:16:25 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 06:05:58 --> Config Class Initialized
INFO - 2024-09-19 06:05:58 --> Hooks Class Initialized
DEBUG - 2024-09-19 06:05:58 --> UTF-8 Support Enabled
INFO - 2024-09-19 06:05:58 --> Utf8 Class Initialized
INFO - 2024-09-19 06:05:58 --> URI Class Initialized
DEBUG - 2024-09-19 06:05:58 --> No URI present. Default controller set.
INFO - 2024-09-19 06:05:58 --> Router Class Initialized
INFO - 2024-09-19 06:05:58 --> Output Class Initialized
INFO - 2024-09-19 06:05:58 --> Security Class Initialized
DEBUG - 2024-09-19 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 06:05:58 --> Input Class Initialized
INFO - 2024-09-19 06:05:58 --> Language Class Initialized
INFO - 2024-09-19 06:05:58 --> Loader Class Initialized
INFO - 2024-09-19 06:05:58 --> Helper loaded: url_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: file_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: security_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: wpu_helper
INFO - 2024-09-19 06:05:58 --> Database Driver Class Initialized
INFO - 2024-09-19 06:05:58 --> Config Class Initialized
INFO - 2024-09-19 06:05:58 --> Hooks Class Initialized
DEBUG - 2024-09-19 06:05:58 --> UTF-8 Support Enabled
INFO - 2024-09-19 06:05:58 --> Utf8 Class Initialized
INFO - 2024-09-19 06:05:58 --> URI Class Initialized
DEBUG - 2024-09-19 06:05:58 --> No URI present. Default controller set.
INFO - 2024-09-19 06:05:58 --> Router Class Initialized
INFO - 2024-09-19 06:05:58 --> Output Class Initialized
INFO - 2024-09-19 06:05:58 --> Security Class Initialized
DEBUG - 2024-09-19 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 06:05:58 --> Input Class Initialized
INFO - 2024-09-19 06:05:58 --> Language Class Initialized
INFO - 2024-09-19 06:05:58 --> Loader Class Initialized
INFO - 2024-09-19 06:05:58 --> Helper loaded: url_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: file_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: security_helper
INFO - 2024-09-19 06:05:58 --> Helper loaded: wpu_helper
INFO - 2024-09-19 06:05:58 --> Database Driver Class Initialized
INFO - 2024-09-19 17:13:32 --> Config Class Initialized
INFO - 2024-09-19 17:13:32 --> Hooks Class Initialized
DEBUG - 2024-09-19 17:13:32 --> UTF-8 Support Enabled
INFO - 2024-09-19 17:13:32 --> Utf8 Class Initialized
INFO - 2024-09-19 17:13:32 --> URI Class Initialized
DEBUG - 2024-09-19 17:13:32 --> No URI present. Default controller set.
INFO - 2024-09-19 17:13:32 --> Router Class Initialized
INFO - 2024-09-19 17:13:32 --> Output Class Initialized
INFO - 2024-09-19 17:13:32 --> Security Class Initialized
DEBUG - 2024-09-19 17:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 17:13:32 --> Input Class Initialized
INFO - 2024-09-19 17:13:32 --> Language Class Initialized
INFO - 2024-09-19 17:13:32 --> Loader Class Initialized
INFO - 2024-09-19 17:13:32 --> Helper loaded: url_helper
INFO - 2024-09-19 17:13:32 --> Helper loaded: file_helper
INFO - 2024-09-19 17:13:32 --> Helper loaded: security_helper
INFO - 2024-09-19 17:13:32 --> Helper loaded: wpu_helper
INFO - 2024-09-19 17:13:32 --> Database Driver Class Initialized
ERROR - 2024-09-19 17:14:04 --> Unable to connect to the database
INFO - 2024-09-19 17:14:04 --> Language file loaded: language/english/db_lang.php
