<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-18 09:15:52 --> Config Class Initialized
INFO - 2024-09-18 09:15:52 --> Hooks Class Initialized
DEBUG - 2024-09-18 09:15:52 --> UTF-8 Support Enabled
INFO - 2024-09-18 09:15:52 --> Utf8 Class Initialized
INFO - 2024-09-18 09:15:52 --> URI Class Initialized
DEBUG - 2024-09-18 09:15:52 --> No URI present. Default controller set.
INFO - 2024-09-18 09:15:52 --> Router Class Initialized
INFO - 2024-09-18 09:15:52 --> Output Class Initialized
INFO - 2024-09-18 09:15:52 --> Security Class Initialized
DEBUG - 2024-09-18 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-18 09:15:52 --> Input Class Initialized
INFO - 2024-09-18 09:15:52 --> Language Class Initialized
INFO - 2024-09-18 09:15:52 --> Loader Class Initialized
INFO - 2024-09-18 09:15:52 --> Helper loaded: url_helper
INFO - 2024-09-18 09:15:52 --> Helper loaded: file_helper
INFO - 2024-09-18 09:15:52 --> Helper loaded: security_helper
INFO - 2024-09-18 09:15:52 --> Helper loaded: wpu_helper
INFO - 2024-09-18 09:15:52 --> Database Driver Class Initialized
ERROR - 2024-09-18 09:16:23 --> Unable to connect to the database
INFO - 2024-09-18 09:16:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-18 18:50:52 --> Config Class Initialized
INFO - 2024-09-18 18:50:52 --> Hooks Class Initialized
DEBUG - 2024-09-18 18:50:52 --> UTF-8 Support Enabled
INFO - 2024-09-18 18:50:52 --> Utf8 Class Initialized
INFO - 2024-09-18 18:50:52 --> URI Class Initialized
DEBUG - 2024-09-18 18:50:52 --> No URI present. Default controller set.
INFO - 2024-09-18 18:50:52 --> Router Class Initialized
INFO - 2024-09-18 18:50:52 --> Output Class Initialized
INFO - 2024-09-18 18:50:52 --> Security Class Initialized
DEBUG - 2024-09-18 18:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-18 18:50:52 --> Input Class Initialized
INFO - 2024-09-18 18:50:52 --> Language Class Initialized
INFO - 2024-09-18 18:50:52 --> Loader Class Initialized
INFO - 2024-09-18 18:50:52 --> Helper loaded: url_helper
INFO - 2024-09-18 18:50:52 --> Helper loaded: file_helper
INFO - 2024-09-18 18:50:52 --> Helper loaded: security_helper
INFO - 2024-09-18 18:50:52 --> Helper loaded: wpu_helper
INFO - 2024-09-18 18:50:52 --> Database Driver Class Initialized
INFO - 2024-09-18 18:52:01 --> Config Class Initialized
INFO - 2024-09-18 18:52:01 --> Hooks Class Initialized
DEBUG - 2024-09-18 18:52:01 --> UTF-8 Support Enabled
INFO - 2024-09-18 18:52:01 --> Utf8 Class Initialized
INFO - 2024-09-18 18:52:01 --> URI Class Initialized
DEBUG - 2024-09-18 18:52:01 --> No URI present. Default controller set.
INFO - 2024-09-18 18:52:01 --> Router Class Initialized
INFO - 2024-09-18 18:52:01 --> Output Class Initialized
INFO - 2024-09-18 18:52:01 --> Security Class Initialized
DEBUG - 2024-09-18 18:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-18 18:52:01 --> Input Class Initialized
INFO - 2024-09-18 18:52:01 --> Language Class Initialized
INFO - 2024-09-18 18:52:01 --> Loader Class Initialized
INFO - 2024-09-18 18:52:01 --> Helper loaded: url_helper
INFO - 2024-09-18 18:52:01 --> Helper loaded: file_helper
INFO - 2024-09-18 18:52:01 --> Helper loaded: security_helper
INFO - 2024-09-18 18:52:01 --> Helper loaded: wpu_helper
INFO - 2024-09-18 18:52:01 --> Database Driver Class Initialized
