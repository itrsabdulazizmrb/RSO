<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-24 00:12:27 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 121
ERROR - 2024-01-24 00:12:28 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 121
ERROR - 2024-01-24 00:12:29 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 121
ERROR - 2024-01-24 00:12:29 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 121
ERROR - 2024-01-24 00:12:29 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 121
ERROR - 2024-01-24 00:13:21 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:13:21 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:13:22 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:13:22 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:13:22 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:13:26 --> Severity: error --> Exception: Too few arguments to function Faktur_model::update_total_terbayar(), 2 passed in C:\xampp\htdocs\simba\application\controllers\Admin.php on line 641 and exactly 3 expected C:\xampp\htdocs\simba\application\models\Faktur_model.php 122
ERROR - 2024-01-24 00:42:05 --> Severity: error --> Exception: Call to undefined method Pesanan_model::getUnit() C:\xampp\htdocs\simba\application\controllers\Admin.php 481
ERROR - 2024-01-24 01:01:19 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `nip`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '27'
ERROR - 2024-01-24 01:01:19 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `unit`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '27'
ERROR - 2024-01-24 01:01:20 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `unit`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '28'
ERROR - 2024-01-24 01:01:20 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `nip`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '28'
ERROR - 2024-01-24 01:01:21 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `nip`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '27'
ERROR - 2024-01-24 01:01:21 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `unit`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '27'
ERROR - 2024-01-24 01:01:22 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `unit`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '28'
ERROR - 2024-01-24 01:01:22 --> Query error: Unknown column 'id_pesanan' in 'where clause' - Invalid query: SELECT `nip`
FROM `tbl_permintaan`
WHERE `id_pesanan` = '28'
ERROR - 2024-01-24 01:04:42 --> Query error: Column 'catatan' cannot be null - Invalid query: INSERT INTO `tbl_faktur` (`no_faktur`, `id_pesanan`, `id_supplier`, `id_jenis_faktur`, `tanggal_jatuh_tempo`, `tanggal_faktur`, `petugas_penerima`, `bukti_faktur`, `total_pembayaran`, `catatan`, `status`) VALUES ('1110119999333330', '28', ' 2', ' 2', '2024-01-25', '2024-01-24', 'Gintoki', NULL, '2700000', NULL, 'Belum')
