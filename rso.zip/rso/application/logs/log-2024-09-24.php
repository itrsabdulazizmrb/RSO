<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-24 08:48:40 --> Config Class Initialized
INFO - 2024-09-24 08:48:40 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:48:40 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:48:40 --> Utf8 Class Initialized
INFO - 2024-09-24 08:48:40 --> URI Class Initialized
DEBUG - 2024-09-24 08:48:40 --> No URI present. Default controller set.
INFO - 2024-09-24 08:48:40 --> Router Class Initialized
INFO - 2024-09-24 08:48:40 --> Output Class Initialized
INFO - 2024-09-24 08:48:40 --> Security Class Initialized
DEBUG - 2024-09-24 08:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:48:40 --> Input Class Initialized
INFO - 2024-09-24 08:48:40 --> Language Class Initialized
INFO - 2024-09-24 08:48:40 --> Loader Class Initialized
INFO - 2024-09-24 08:48:40 --> Helper loaded: url_helper
INFO - 2024-09-24 08:48:40 --> Helper loaded: file_helper
INFO - 2024-09-24 08:48:40 --> Helper loaded: security_helper
INFO - 2024-09-24 08:48:40 --> Helper loaded: wpu_helper
INFO - 2024-09-24 08:48:40 --> Database Driver Class Initialized
INFO - 2024-09-24 08:48:40 --> Email Class Initialized
DEBUG - 2024-09-24 08:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-24 08:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:48:40 --> Helper loaded: form_helper
INFO - 2024-09-24 08:48:40 --> Form Validation Class Initialized
INFO - 2024-09-24 08:48:40 --> Controller Class Initialized
DEBUG - 2024-09-24 08:48:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-24 08:48:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-24 08:48:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-24 08:48:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-24 08:48:40 --> Final output sent to browser
DEBUG - 2024-09-24 08:48:40 --> Total execution time: 0.2247
INFO - 2024-09-24 08:48:42 --> Config Class Initialized
INFO - 2024-09-24 08:48:42 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:48:42 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:48:42 --> Utf8 Class Initialized
INFO - 2024-09-24 08:48:42 --> URI Class Initialized
INFO - 2024-09-24 08:48:42 --> Router Class Initialized
INFO - 2024-09-24 08:48:42 --> Output Class Initialized
INFO - 2024-09-24 08:48:42 --> Security Class Initialized
DEBUG - 2024-09-24 08:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:48:42 --> Input Class Initialized
INFO - 2024-09-24 08:48:42 --> Language Class Initialized
INFO - 2024-09-24 08:48:42 --> Loader Class Initialized
INFO - 2024-09-24 08:48:42 --> Helper loaded: url_helper
INFO - 2024-09-24 08:48:42 --> Helper loaded: file_helper
INFO - 2024-09-24 08:48:42 --> Helper loaded: security_helper
INFO - 2024-09-24 08:48:42 --> Helper loaded: wpu_helper
INFO - 2024-09-24 08:48:42 --> Database Driver Class Initialized
INFO - 2024-09-24 08:48:43 --> Email Class Initialized
DEBUG - 2024-09-24 08:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-24 08:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:48:43 --> Helper loaded: form_helper
INFO - 2024-09-24 08:48:43 --> Form Validation Class Initialized
INFO - 2024-09-24 08:48:43 --> Controller Class Initialized
DEBUG - 2024-09-24 08:48:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-24 08:48:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-24 08:48:43 --> Config Class Initialized
INFO - 2024-09-24 08:48:44 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:48:44 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:48:44 --> Utf8 Class Initialized
INFO - 2024-09-24 08:48:44 --> URI Class Initialized
INFO - 2024-09-24 08:48:44 --> Router Class Initialized
INFO - 2024-09-24 08:48:44 --> Output Class Initialized
INFO - 2024-09-24 08:48:44 --> Security Class Initialized
DEBUG - 2024-09-24 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:48:44 --> Input Class Initialized
INFO - 2024-09-24 08:48:44 --> Language Class Initialized
INFO - 2024-09-24 08:48:44 --> Loader Class Initialized
INFO - 2024-09-24 08:48:44 --> Helper loaded: url_helper
INFO - 2024-09-24 08:48:44 --> Helper loaded: file_helper
INFO - 2024-09-24 08:48:44 --> Helper loaded: security_helper
INFO - 2024-09-24 08:48:44 --> Helper loaded: wpu_helper
INFO - 2024-09-24 08:48:44 --> Database Driver Class Initialized
INFO - 2024-09-24 08:48:44 --> Email Class Initialized
DEBUG - 2024-09-24 08:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-24 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:48:44 --> Helper loaded: form_helper
INFO - 2024-09-24 08:48:44 --> Form Validation Class Initialized
INFO - 2024-09-24 08:48:44 --> Controller Class Initialized
INFO - 2024-09-24 08:48:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-24 08:48:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-24 08:48:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-24 08:48:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-24 08:48:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-24 08:48:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-24 08:48:44 --> Final output sent to browser
DEBUG - 2024-09-24 08:48:44 --> Total execution time: 0.8454
