<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-18 01:26:49 --> Config Class Initialized
INFO - 2024-12-18 01:26:49 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:26:49 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:26:49 --> Utf8 Class Initialized
INFO - 2024-12-18 01:26:49 --> URI Class Initialized
DEBUG - 2024-12-18 01:26:49 --> No URI present. Default controller set.
INFO - 2024-12-18 01:26:49 --> Router Class Initialized
INFO - 2024-12-18 01:26:49 --> Output Class Initialized
INFO - 2024-12-18 01:26:49 --> Security Class Initialized
DEBUG - 2024-12-18 01:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:26:49 --> Input Class Initialized
INFO - 2024-12-18 01:26:49 --> Language Class Initialized
INFO - 2024-12-18 01:26:49 --> Loader Class Initialized
INFO - 2024-12-18 01:26:49 --> Helper loaded: url_helper
INFO - 2024-12-18 01:26:49 --> Helper loaded: file_helper
INFO - 2024-12-18 01:26:49 --> Helper loaded: security_helper
INFO - 2024-12-18 01:26:49 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:26:49 --> Database Driver Class Initialized
INFO - 2024-12-18 01:26:50 --> Email Class Initialized
DEBUG - 2024-12-18 01:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:26:50 --> Helper loaded: form_helper
INFO - 2024-12-18 01:26:50 --> Form Validation Class Initialized
INFO - 2024-12-18 01:26:50 --> Controller Class Initialized
DEBUG - 2024-12-18 01:26:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:26:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-18 01:26:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-18 01:26:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-18 01:26:50 --> Final output sent to browser
DEBUG - 2024-12-18 01:26:50 --> Total execution time: 0.4170
INFO - 2024-12-18 01:29:57 --> Config Class Initialized
INFO - 2024-12-18 01:29:57 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:29:57 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:29:57 --> Utf8 Class Initialized
INFO - 2024-12-18 01:29:57 --> URI Class Initialized
DEBUG - 2024-12-18 01:29:57 --> No URI present. Default controller set.
INFO - 2024-12-18 01:29:57 --> Router Class Initialized
INFO - 2024-12-18 01:29:57 --> Output Class Initialized
INFO - 2024-12-18 01:29:57 --> Security Class Initialized
DEBUG - 2024-12-18 01:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:29:57 --> Input Class Initialized
INFO - 2024-12-18 01:29:57 --> Language Class Initialized
INFO - 2024-12-18 01:29:57 --> Loader Class Initialized
INFO - 2024-12-18 01:29:57 --> Helper loaded: url_helper
INFO - 2024-12-18 01:29:57 --> Helper loaded: file_helper
INFO - 2024-12-18 01:29:57 --> Helper loaded: security_helper
INFO - 2024-12-18 01:29:57 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:29:57 --> Database Driver Class Initialized
INFO - 2024-12-18 01:29:58 --> Email Class Initialized
DEBUG - 2024-12-18 01:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:29:58 --> Helper loaded: form_helper
INFO - 2024-12-18 01:29:58 --> Form Validation Class Initialized
INFO - 2024-12-18 01:29:58 --> Controller Class Initialized
DEBUG - 2024-12-18 01:29:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:29:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-18 01:29:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-18 01:29:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-18 01:29:58 --> Final output sent to browser
DEBUG - 2024-12-18 01:29:58 --> Total execution time: 0.4284
INFO - 2024-12-18 01:30:05 --> Config Class Initialized
INFO - 2024-12-18 01:30:05 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:30:05 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:30:05 --> Utf8 Class Initialized
INFO - 2024-12-18 01:30:05 --> URI Class Initialized
INFO - 2024-12-18 01:30:05 --> Router Class Initialized
INFO - 2024-12-18 01:30:05 --> Output Class Initialized
INFO - 2024-12-18 01:30:05 --> Security Class Initialized
DEBUG - 2024-12-18 01:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:30:05 --> Input Class Initialized
INFO - 2024-12-18 01:30:05 --> Language Class Initialized
INFO - 2024-12-18 01:30:05 --> Loader Class Initialized
INFO - 2024-12-18 01:30:05 --> Helper loaded: url_helper
INFO - 2024-12-18 01:30:05 --> Helper loaded: file_helper
INFO - 2024-12-18 01:30:05 --> Helper loaded: security_helper
INFO - 2024-12-18 01:30:05 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:30:05 --> Database Driver Class Initialized
INFO - 2024-12-18 01:30:06 --> Email Class Initialized
DEBUG - 2024-12-18 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:30:06 --> Helper loaded: form_helper
INFO - 2024-12-18 01:30:06 --> Form Validation Class Initialized
INFO - 2024-12-18 01:30:06 --> Controller Class Initialized
DEBUG - 2024-12-18 01:30:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:30:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-18 01:30:06 --> Config Class Initialized
INFO - 2024-12-18 01:30:06 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:30:06 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:30:06 --> Utf8 Class Initialized
INFO - 2024-12-18 01:30:06 --> URI Class Initialized
INFO - 2024-12-18 01:30:06 --> Router Class Initialized
INFO - 2024-12-18 01:30:06 --> Output Class Initialized
INFO - 2024-12-18 01:30:06 --> Security Class Initialized
DEBUG - 2024-12-18 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:30:06 --> Input Class Initialized
INFO - 2024-12-18 01:30:06 --> Language Class Initialized
INFO - 2024-12-18 01:30:06 --> Loader Class Initialized
INFO - 2024-12-18 01:30:06 --> Helper loaded: url_helper
INFO - 2024-12-18 01:30:06 --> Helper loaded: file_helper
INFO - 2024-12-18 01:30:06 --> Helper loaded: security_helper
INFO - 2024-12-18 01:30:06 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:30:06 --> Database Driver Class Initialized
INFO - 2024-12-18 01:30:07 --> Email Class Initialized
DEBUG - 2024-12-18 01:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:30:07 --> Helper loaded: form_helper
INFO - 2024-12-18 01:30:07 --> Form Validation Class Initialized
INFO - 2024-12-18 01:30:07 --> Controller Class Initialized
INFO - 2024-12-18 01:30:07 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:30:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:30:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:30:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:30:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-18 01:30:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:30:07 --> Final output sent to browser
DEBUG - 2024-12-18 01:30:07 --> Total execution time: 1.0387
INFO - 2024-12-18 01:31:20 --> Config Class Initialized
INFO - 2024-12-18 01:31:20 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:31:20 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:31:20 --> Utf8 Class Initialized
INFO - 2024-12-18 01:31:20 --> URI Class Initialized
INFO - 2024-12-18 01:31:20 --> Router Class Initialized
INFO - 2024-12-18 01:31:20 --> Output Class Initialized
INFO - 2024-12-18 01:31:20 --> Security Class Initialized
DEBUG - 2024-12-18 01:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:31:20 --> Input Class Initialized
INFO - 2024-12-18 01:31:20 --> Language Class Initialized
INFO - 2024-12-18 01:31:20 --> Loader Class Initialized
INFO - 2024-12-18 01:31:20 --> Helper loaded: url_helper
INFO - 2024-12-18 01:31:20 --> Helper loaded: file_helper
INFO - 2024-12-18 01:31:20 --> Helper loaded: security_helper
INFO - 2024-12-18 01:31:20 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:31:20 --> Database Driver Class Initialized
INFO - 2024-12-18 01:31:21 --> Email Class Initialized
DEBUG - 2024-12-18 01:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:31:21 --> Helper loaded: form_helper
INFO - 2024-12-18 01:31:21 --> Form Validation Class Initialized
INFO - 2024-12-18 01:31:21 --> Controller Class Initialized
INFO - 2024-12-18 01:31:21 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:31:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:31:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:31:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-18 01:31:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:31:22 --> Final output sent to browser
DEBUG - 2024-12-18 01:31:22 --> Total execution time: 1.0647
INFO - 2024-12-18 01:31:24 --> Config Class Initialized
INFO - 2024-12-18 01:31:24 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:31:24 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:31:24 --> Utf8 Class Initialized
INFO - 2024-12-18 01:31:24 --> URI Class Initialized
INFO - 2024-12-18 01:31:24 --> Router Class Initialized
INFO - 2024-12-18 01:31:24 --> Output Class Initialized
INFO - 2024-12-18 01:31:24 --> Security Class Initialized
DEBUG - 2024-12-18 01:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:31:24 --> Input Class Initialized
INFO - 2024-12-18 01:31:24 --> Language Class Initialized
INFO - 2024-12-18 01:31:24 --> Loader Class Initialized
INFO - 2024-12-18 01:31:24 --> Helper loaded: url_helper
INFO - 2024-12-18 01:31:24 --> Helper loaded: file_helper
INFO - 2024-12-18 01:31:24 --> Helper loaded: security_helper
INFO - 2024-12-18 01:31:24 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:31:24 --> Database Driver Class Initialized
INFO - 2024-12-18 01:31:24 --> Email Class Initialized
DEBUG - 2024-12-18 01:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:31:24 --> Helper loaded: form_helper
INFO - 2024-12-18 01:31:24 --> Form Validation Class Initialized
INFO - 2024-12-18 01:31:24 --> Controller Class Initialized
INFO - 2024-12-18 01:31:24 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:31:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:31:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:31:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:31:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-18 01:31:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:31:25 --> Final output sent to browser
DEBUG - 2024-12-18 01:31:25 --> Total execution time: 1.1758
INFO - 2024-12-18 01:32:06 --> Config Class Initialized
INFO - 2024-12-18 01:32:06 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:32:06 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:32:06 --> Utf8 Class Initialized
INFO - 2024-12-18 01:32:06 --> URI Class Initialized
INFO - 2024-12-18 01:32:06 --> Router Class Initialized
INFO - 2024-12-18 01:32:06 --> Output Class Initialized
INFO - 2024-12-18 01:32:06 --> Security Class Initialized
DEBUG - 2024-12-18 01:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:32:06 --> Input Class Initialized
INFO - 2024-12-18 01:32:06 --> Language Class Initialized
INFO - 2024-12-18 01:32:06 --> Loader Class Initialized
INFO - 2024-12-18 01:32:06 --> Helper loaded: url_helper
INFO - 2024-12-18 01:32:06 --> Helper loaded: file_helper
INFO - 2024-12-18 01:32:06 --> Helper loaded: security_helper
INFO - 2024-12-18 01:32:06 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:32:06 --> Database Driver Class Initialized
INFO - 2024-12-18 01:32:07 --> Email Class Initialized
DEBUG - 2024-12-18 01:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:32:07 --> Helper loaded: form_helper
INFO - 2024-12-18 01:32:07 --> Form Validation Class Initialized
INFO - 2024-12-18 01:32:07 --> Controller Class Initialized
INFO - 2024-12-18 01:32:07 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:32:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:32:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:32:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:32:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-18 01:32:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:32:07 --> Final output sent to browser
DEBUG - 2024-12-18 01:32:07 --> Total execution time: 0.9880
INFO - 2024-12-18 01:32:27 --> Config Class Initialized
INFO - 2024-12-18 01:32:27 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:32:27 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:32:27 --> Utf8 Class Initialized
INFO - 2024-12-18 01:32:27 --> URI Class Initialized
INFO - 2024-12-18 01:32:27 --> Router Class Initialized
INFO - 2024-12-18 01:32:27 --> Output Class Initialized
INFO - 2024-12-18 01:32:27 --> Security Class Initialized
DEBUG - 2024-12-18 01:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:32:27 --> Input Class Initialized
INFO - 2024-12-18 01:32:27 --> Language Class Initialized
INFO - 2024-12-18 01:32:27 --> Loader Class Initialized
INFO - 2024-12-18 01:32:27 --> Helper loaded: url_helper
INFO - 2024-12-18 01:32:27 --> Helper loaded: file_helper
INFO - 2024-12-18 01:32:27 --> Helper loaded: security_helper
INFO - 2024-12-18 01:32:27 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:32:27 --> Database Driver Class Initialized
INFO - 2024-12-18 01:32:28 --> Email Class Initialized
DEBUG - 2024-12-18 01:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:32:28 --> Helper loaded: form_helper
INFO - 2024-12-18 01:32:28 --> Form Validation Class Initialized
INFO - 2024-12-18 01:32:28 --> Controller Class Initialized
INFO - 2024-12-18 01:32:28 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:32:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:32:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:32:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:32:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-18 01:32:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:32:28 --> Final output sent to browser
DEBUG - 2024-12-18 01:32:28 --> Total execution time: 1.0567
INFO - 2024-12-18 01:32:30 --> Config Class Initialized
INFO - 2024-12-18 01:32:30 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:32:30 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:32:30 --> Utf8 Class Initialized
INFO - 2024-12-18 01:32:30 --> URI Class Initialized
INFO - 2024-12-18 01:32:30 --> Router Class Initialized
INFO - 2024-12-18 01:32:30 --> Output Class Initialized
INFO - 2024-12-18 01:32:30 --> Security Class Initialized
DEBUG - 2024-12-18 01:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:32:30 --> Input Class Initialized
INFO - 2024-12-18 01:32:30 --> Language Class Initialized
INFO - 2024-12-18 01:32:30 --> Loader Class Initialized
INFO - 2024-12-18 01:32:30 --> Helper loaded: url_helper
INFO - 2024-12-18 01:32:30 --> Helper loaded: file_helper
INFO - 2024-12-18 01:32:30 --> Helper loaded: security_helper
INFO - 2024-12-18 01:32:30 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:32:30 --> Database Driver Class Initialized
INFO - 2024-12-18 01:32:31 --> Email Class Initialized
DEBUG - 2024-12-18 01:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:32:31 --> Helper loaded: form_helper
INFO - 2024-12-18 01:32:31 --> Form Validation Class Initialized
INFO - 2024-12-18 01:32:31 --> Controller Class Initialized
INFO - 2024-12-18 01:32:31 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:32:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:32:35 --> Final output sent to browser
DEBUG - 2024-12-18 01:32:35 --> Total execution time: 4.3680
INFO - 2024-12-18 01:32:38 --> Config Class Initialized
INFO - 2024-12-18 01:32:38 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:32:38 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:32:38 --> Utf8 Class Initialized
INFO - 2024-12-18 01:32:38 --> URI Class Initialized
INFO - 2024-12-18 01:32:38 --> Router Class Initialized
INFO - 2024-12-18 01:32:38 --> Output Class Initialized
INFO - 2024-12-18 01:32:38 --> Security Class Initialized
DEBUG - 2024-12-18 01:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:32:38 --> Input Class Initialized
INFO - 2024-12-18 01:32:38 --> Language Class Initialized
INFO - 2024-12-18 01:32:38 --> Loader Class Initialized
INFO - 2024-12-18 01:32:38 --> Helper loaded: url_helper
INFO - 2024-12-18 01:32:38 --> Helper loaded: file_helper
INFO - 2024-12-18 01:32:38 --> Helper loaded: security_helper
INFO - 2024-12-18 01:32:38 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:32:38 --> Database Driver Class Initialized
INFO - 2024-12-18 01:32:38 --> Email Class Initialized
DEBUG - 2024-12-18 01:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:32:38 --> Helper loaded: form_helper
INFO - 2024-12-18 01:32:38 --> Form Validation Class Initialized
INFO - 2024-12-18 01:32:38 --> Controller Class Initialized
INFO - 2024-12-18 01:32:38 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:32:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:32:42 --> Final output sent to browser
DEBUG - 2024-12-18 01:32:42 --> Total execution time: 4.0108
INFO - 2024-12-18 01:33:35 --> Config Class Initialized
INFO - 2024-12-18 01:33:35 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:33:35 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:33:35 --> Utf8 Class Initialized
INFO - 2024-12-18 01:33:35 --> URI Class Initialized
INFO - 2024-12-18 01:33:35 --> Router Class Initialized
INFO - 2024-12-18 01:33:35 --> Output Class Initialized
INFO - 2024-12-18 01:33:35 --> Security Class Initialized
DEBUG - 2024-12-18 01:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:33:35 --> Input Class Initialized
INFO - 2024-12-18 01:33:35 --> Language Class Initialized
INFO - 2024-12-18 01:33:35 --> Loader Class Initialized
INFO - 2024-12-18 01:33:35 --> Helper loaded: url_helper
INFO - 2024-12-18 01:33:35 --> Helper loaded: file_helper
INFO - 2024-12-18 01:33:35 --> Helper loaded: security_helper
INFO - 2024-12-18 01:33:35 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:33:35 --> Database Driver Class Initialized
INFO - 2024-12-18 01:33:36 --> Email Class Initialized
DEBUG - 2024-12-18 01:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:33:36 --> Helper loaded: form_helper
INFO - 2024-12-18 01:33:36 --> Form Validation Class Initialized
INFO - 2024-12-18 01:33:36 --> Controller Class Initialized
INFO - 2024-12-18 01:33:36 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:33:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:33:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:33:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:33:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-18 01:33:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:33:36 --> Final output sent to browser
DEBUG - 2024-12-18 01:33:36 --> Total execution time: 1.2278
INFO - 2024-12-18 01:38:28 --> Config Class Initialized
INFO - 2024-12-18 01:38:28 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:38:28 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:38:28 --> Utf8 Class Initialized
INFO - 2024-12-18 01:38:28 --> URI Class Initialized
INFO - 2024-12-18 01:38:28 --> Router Class Initialized
INFO - 2024-12-18 01:38:28 --> Output Class Initialized
INFO - 2024-12-18 01:38:28 --> Security Class Initialized
DEBUG - 2024-12-18 01:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:38:28 --> Input Class Initialized
INFO - 2024-12-18 01:38:28 --> Language Class Initialized
INFO - 2024-12-18 01:38:28 --> Loader Class Initialized
INFO - 2024-12-18 01:38:28 --> Helper loaded: url_helper
INFO - 2024-12-18 01:38:28 --> Helper loaded: file_helper
INFO - 2024-12-18 01:38:28 --> Helper loaded: security_helper
INFO - 2024-12-18 01:38:28 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:38:28 --> Database Driver Class Initialized
INFO - 2024-12-18 01:38:29 --> Email Class Initialized
DEBUG - 2024-12-18 01:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:38:29 --> Helper loaded: form_helper
INFO - 2024-12-18 01:38:29 --> Form Validation Class Initialized
INFO - 2024-12-18 01:38:29 --> Controller Class Initialized
INFO - 2024-12-18 01:38:29 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:38:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:38:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:38:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-18 01:38:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:38:29 --> Final output sent to browser
DEBUG - 2024-12-18 01:38:29 --> Total execution time: 1.1229
INFO - 2024-12-18 01:38:40 --> Config Class Initialized
INFO - 2024-12-18 01:38:40 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:38:40 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:38:40 --> Utf8 Class Initialized
INFO - 2024-12-18 01:38:40 --> URI Class Initialized
DEBUG - 2024-12-18 01:38:40 --> No URI present. Default controller set.
INFO - 2024-12-18 01:38:40 --> Router Class Initialized
INFO - 2024-12-18 01:38:40 --> Output Class Initialized
INFO - 2024-12-18 01:38:40 --> Security Class Initialized
DEBUG - 2024-12-18 01:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:38:40 --> Input Class Initialized
INFO - 2024-12-18 01:38:40 --> Language Class Initialized
INFO - 2024-12-18 01:38:40 --> Loader Class Initialized
INFO - 2024-12-18 01:38:40 --> Helper loaded: url_helper
INFO - 2024-12-18 01:38:40 --> Helper loaded: file_helper
INFO - 2024-12-18 01:38:40 --> Helper loaded: security_helper
INFO - 2024-12-18 01:38:40 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:38:40 --> Database Driver Class Initialized
INFO - 2024-12-18 01:38:41 --> Email Class Initialized
DEBUG - 2024-12-18 01:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:38:41 --> Helper loaded: form_helper
INFO - 2024-12-18 01:38:41 --> Form Validation Class Initialized
INFO - 2024-12-18 01:38:41 --> Controller Class Initialized
DEBUG - 2024-12-18 01:38:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:38:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-18 01:38:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-18 01:38:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-18 01:38:41 --> Final output sent to browser
DEBUG - 2024-12-18 01:38:41 --> Total execution time: 0.4284
INFO - 2024-12-18 01:40:33 --> Config Class Initialized
INFO - 2024-12-18 01:40:33 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:40:33 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:40:33 --> Utf8 Class Initialized
INFO - 2024-12-18 01:40:33 --> URI Class Initialized
INFO - 2024-12-18 01:40:33 --> Router Class Initialized
INFO - 2024-12-18 01:40:33 --> Output Class Initialized
INFO - 2024-12-18 01:40:33 --> Security Class Initialized
DEBUG - 2024-12-18 01:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:40:33 --> Input Class Initialized
INFO - 2024-12-18 01:40:33 --> Language Class Initialized
INFO - 2024-12-18 01:40:33 --> Loader Class Initialized
INFO - 2024-12-18 01:40:33 --> Helper loaded: url_helper
INFO - 2024-12-18 01:40:33 --> Helper loaded: file_helper
INFO - 2024-12-18 01:40:33 --> Helper loaded: security_helper
INFO - 2024-12-18 01:40:33 --> Helper loaded: wpu_helper
INFO - 2024-12-18 01:40:33 --> Database Driver Class Initialized
INFO - 2024-12-18 01:40:33 --> Email Class Initialized
DEBUG - 2024-12-18 01:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-18 01:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:40:33 --> Helper loaded: form_helper
INFO - 2024-12-18 01:40:33 --> Form Validation Class Initialized
INFO - 2024-12-18 01:40:33 --> Controller Class Initialized
INFO - 2024-12-18 01:40:33 --> Model "Antrol_model" initialized
DEBUG - 2024-12-18 01:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-18 01:40:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-18 01:40:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-18 01:40:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-18 01:40:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-18 01:40:34 --> Final output sent to browser
DEBUG - 2024-12-18 01:40:34 --> Total execution time: 1.1387
