<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-14 08:19:44 --> Config Class Initialized
INFO - 2024-10-14 08:19:44 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:19:44 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:19:44 --> Utf8 Class Initialized
INFO - 2024-10-14 08:19:44 --> URI Class Initialized
DEBUG - 2024-10-14 08:19:44 --> No URI present. Default controller set.
INFO - 2024-10-14 08:19:44 --> Router Class Initialized
INFO - 2024-10-14 08:19:44 --> Output Class Initialized
INFO - 2024-10-14 08:19:44 --> Security Class Initialized
DEBUG - 2024-10-14 08:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:19:44 --> Input Class Initialized
INFO - 2024-10-14 08:19:44 --> Language Class Initialized
INFO - 2024-10-14 08:19:44 --> Loader Class Initialized
INFO - 2024-10-14 08:19:44 --> Helper loaded: url_helper
INFO - 2024-10-14 08:19:44 --> Helper loaded: file_helper
INFO - 2024-10-14 08:19:44 --> Helper loaded: security_helper
INFO - 2024-10-14 08:19:44 --> Helper loaded: wpu_helper
INFO - 2024-10-14 08:19:44 --> Database Driver Class Initialized
INFO - 2024-10-14 08:19:44 --> Email Class Initialized
DEBUG - 2024-10-14 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-14 08:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:19:44 --> Helper loaded: form_helper
INFO - 2024-10-14 08:19:44 --> Form Validation Class Initialized
INFO - 2024-10-14 08:19:44 --> Controller Class Initialized
DEBUG - 2024-10-14 08:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-14 08:19:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-14 08:19:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-14 08:19:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-14 08:19:44 --> Final output sent to browser
DEBUG - 2024-10-14 08:19:44 --> Total execution time: 0.2367
INFO - 2024-10-14 08:19:45 --> Config Class Initialized
INFO - 2024-10-14 08:19:45 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:19:45 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:19:45 --> Utf8 Class Initialized
INFO - 2024-10-14 08:19:45 --> URI Class Initialized
INFO - 2024-10-14 08:19:45 --> Router Class Initialized
INFO - 2024-10-14 08:19:45 --> Output Class Initialized
INFO - 2024-10-14 08:19:45 --> Security Class Initialized
DEBUG - 2024-10-14 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:19:45 --> Input Class Initialized
INFO - 2024-10-14 08:19:45 --> Language Class Initialized
ERROR - 2024-10-14 08:19:45 --> 404 Page Not Found: Login/index
INFO - 2024-10-14 08:19:46 --> Config Class Initialized
INFO - 2024-10-14 08:19:46 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:19:46 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:19:46 --> Utf8 Class Initialized
INFO - 2024-10-14 08:19:46 --> URI Class Initialized
INFO - 2024-10-14 08:19:46 --> Router Class Initialized
INFO - 2024-10-14 08:19:46 --> Output Class Initialized
INFO - 2024-10-14 08:19:46 --> Security Class Initialized
DEBUG - 2024-10-14 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:19:46 --> Input Class Initialized
INFO - 2024-10-14 08:19:46 --> Language Class Initialized
ERROR - 2024-10-14 08:19:46 --> 404 Page Not Found: Login/index
INFO - 2024-10-14 08:54:10 --> Config Class Initialized
INFO - 2024-10-14 08:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-14 08:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-14 08:54:10 --> Utf8 Class Initialized
INFO - 2024-10-14 08:54:10 --> URI Class Initialized
DEBUG - 2024-10-14 08:54:10 --> No URI present. Default controller set.
INFO - 2024-10-14 08:54:10 --> Router Class Initialized
INFO - 2024-10-14 08:54:10 --> Output Class Initialized
INFO - 2024-10-14 08:54:10 --> Security Class Initialized
DEBUG - 2024-10-14 08:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 08:54:10 --> Input Class Initialized
INFO - 2024-10-14 08:54:10 --> Language Class Initialized
INFO - 2024-10-14 08:54:10 --> Loader Class Initialized
INFO - 2024-10-14 08:54:10 --> Helper loaded: url_helper
INFO - 2024-10-14 08:54:10 --> Helper loaded: file_helper
INFO - 2024-10-14 08:54:10 --> Helper loaded: security_helper
INFO - 2024-10-14 08:54:10 --> Helper loaded: wpu_helper
INFO - 2024-10-14 08:54:10 --> Database Driver Class Initialized
INFO - 2024-10-14 08:54:10 --> Email Class Initialized
DEBUG - 2024-10-14 08:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-14 08:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 08:54:10 --> Helper loaded: form_helper
INFO - 2024-10-14 08:54:10 --> Form Validation Class Initialized
INFO - 2024-10-14 08:54:10 --> Controller Class Initialized
DEBUG - 2024-10-14 08:54:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-14 08:54:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-14 08:54:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-14 08:54:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-14 08:54:10 --> Final output sent to browser
DEBUG - 2024-10-14 08:54:10 --> Total execution time: 0.2246
INFO - 2024-10-14 19:39:14 --> Config Class Initialized
INFO - 2024-10-14 19:39:14 --> Hooks Class Initialized
DEBUG - 2024-10-14 19:39:14 --> UTF-8 Support Enabled
INFO - 2024-10-14 19:39:14 --> Utf8 Class Initialized
INFO - 2024-10-14 19:39:14 --> URI Class Initialized
DEBUG - 2024-10-14 19:39:14 --> No URI present. Default controller set.
INFO - 2024-10-14 19:39:14 --> Router Class Initialized
INFO - 2024-10-14 19:39:14 --> Output Class Initialized
INFO - 2024-10-14 19:39:14 --> Security Class Initialized
DEBUG - 2024-10-14 19:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 19:39:14 --> Input Class Initialized
INFO - 2024-10-14 19:39:14 --> Language Class Initialized
INFO - 2024-10-14 19:39:14 --> Loader Class Initialized
INFO - 2024-10-14 19:39:14 --> Helper loaded: url_helper
INFO - 2024-10-14 19:39:14 --> Helper loaded: file_helper
INFO - 2024-10-14 19:39:14 --> Helper loaded: security_helper
INFO - 2024-10-14 19:39:14 --> Helper loaded: wpu_helper
INFO - 2024-10-14 19:39:14 --> Database Driver Class Initialized
INFO - 2024-10-14 19:39:15 --> Email Class Initialized
DEBUG - 2024-10-14 19:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-14 19:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 19:39:15 --> Helper loaded: form_helper
INFO - 2024-10-14 19:39:15 --> Form Validation Class Initialized
INFO - 2024-10-14 19:39:15 --> Controller Class Initialized
DEBUG - 2024-10-14 19:39:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-14 19:39:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-14 19:39:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-14 19:39:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-14 19:39:15 --> Final output sent to browser
DEBUG - 2024-10-14 19:39:15 --> Total execution time: 0.2129
INFO - 2024-10-14 19:39:32 --> Config Class Initialized
INFO - 2024-10-14 19:39:32 --> Hooks Class Initialized
DEBUG - 2024-10-14 19:39:32 --> UTF-8 Support Enabled
INFO - 2024-10-14 19:39:32 --> Utf8 Class Initialized
INFO - 2024-10-14 19:39:32 --> URI Class Initialized
DEBUG - 2024-10-14 19:39:32 --> No URI present. Default controller set.
INFO - 2024-10-14 19:39:32 --> Router Class Initialized
INFO - 2024-10-14 19:39:32 --> Output Class Initialized
INFO - 2024-10-14 19:39:32 --> Security Class Initialized
DEBUG - 2024-10-14 19:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 19:39:32 --> Input Class Initialized
INFO - 2024-10-14 19:39:32 --> Language Class Initialized
INFO - 2024-10-14 19:39:32 --> Loader Class Initialized
INFO - 2024-10-14 19:39:32 --> Helper loaded: url_helper
INFO - 2024-10-14 19:39:32 --> Helper loaded: file_helper
INFO - 2024-10-14 19:39:32 --> Helper loaded: security_helper
INFO - 2024-10-14 19:39:32 --> Helper loaded: wpu_helper
INFO - 2024-10-14 19:39:32 --> Database Driver Class Initialized
INFO - 2024-10-14 19:39:32 --> Email Class Initialized
DEBUG - 2024-10-14 19:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-14 19:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 19:39:32 --> Helper loaded: form_helper
INFO - 2024-10-14 19:39:32 --> Form Validation Class Initialized
INFO - 2024-10-14 19:39:32 --> Controller Class Initialized
DEBUG - 2024-10-14 19:39:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-14 19:39:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-14 19:39:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-14 19:39:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-14 19:39:32 --> Final output sent to browser
DEBUG - 2024-10-14 19:39:32 --> Total execution time: 0.2139
INFO - 2024-10-14 20:28:43 --> Config Class Initialized
INFO - 2024-10-14 20:28:43 --> Hooks Class Initialized
DEBUG - 2024-10-14 20:28:43 --> UTF-8 Support Enabled
INFO - 2024-10-14 20:28:43 --> Utf8 Class Initialized
INFO - 2024-10-14 20:28:43 --> URI Class Initialized
DEBUG - 2024-10-14 20:28:43 --> No URI present. Default controller set.
INFO - 2024-10-14 20:28:43 --> Router Class Initialized
INFO - 2024-10-14 20:28:43 --> Output Class Initialized
INFO - 2024-10-14 20:28:43 --> Security Class Initialized
DEBUG - 2024-10-14 20:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-14 20:28:43 --> Input Class Initialized
INFO - 2024-10-14 20:28:43 --> Language Class Initialized
INFO - 2024-10-14 20:28:43 --> Loader Class Initialized
INFO - 2024-10-14 20:28:43 --> Helper loaded: url_helper
INFO - 2024-10-14 20:28:43 --> Helper loaded: file_helper
INFO - 2024-10-14 20:28:43 --> Helper loaded: security_helper
INFO - 2024-10-14 20:28:43 --> Helper loaded: wpu_helper
INFO - 2024-10-14 20:28:43 --> Database Driver Class Initialized
INFO - 2024-10-14 20:28:43 --> Email Class Initialized
DEBUG - 2024-10-14 20:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-14 20:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-14 20:28:43 --> Helper loaded: form_helper
INFO - 2024-10-14 20:28:43 --> Form Validation Class Initialized
INFO - 2024-10-14 20:28:43 --> Controller Class Initialized
DEBUG - 2024-10-14 20:28:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-14 20:28:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-14 20:28:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-14 20:28:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-14 20:28:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-14 20:28:43 --> Final output sent to browser
DEBUG - 2024-10-14 20:28:43 --> Total execution time: 0.2182
