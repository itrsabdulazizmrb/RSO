<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-13 03:21:22 --> Config Class Initialized
INFO - 2024-12-13 03:21:22 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:21:22 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:21:22 --> Utf8 Class Initialized
INFO - 2024-12-13 03:21:22 --> URI Class Initialized
DEBUG - 2024-12-13 03:21:22 --> No URI present. Default controller set.
INFO - 2024-12-13 03:21:22 --> Router Class Initialized
INFO - 2024-12-13 03:21:22 --> Output Class Initialized
INFO - 2024-12-13 03:21:22 --> Security Class Initialized
DEBUG - 2024-12-13 03:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:21:22 --> Input Class Initialized
INFO - 2024-12-13 03:21:22 --> Language Class Initialized
INFO - 2024-12-13 03:21:22 --> Loader Class Initialized
INFO - 2024-12-13 03:21:22 --> Helper loaded: url_helper
INFO - 2024-12-13 03:21:22 --> Helper loaded: file_helper
INFO - 2024-12-13 03:21:22 --> Helper loaded: security_helper
INFO - 2024-12-13 03:21:22 --> Helper loaded: wpu_helper
INFO - 2024-12-13 03:21:22 --> Database Driver Class Initialized
INFO - 2024-12-13 03:21:23 --> Email Class Initialized
DEBUG - 2024-12-13 03:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:21:23 --> Helper loaded: form_helper
INFO - 2024-12-13 03:21:23 --> Form Validation Class Initialized
INFO - 2024-12-13 03:21:23 --> Controller Class Initialized
DEBUG - 2024-12-13 03:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:21:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-13 03:21:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-13 03:21:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-13 03:21:23 --> Final output sent to browser
DEBUG - 2024-12-13 03:21:23 --> Total execution time: 0.4428
INFO - 2024-12-13 03:21:27 --> Config Class Initialized
INFO - 2024-12-13 03:21:27 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:21:27 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:21:27 --> Utf8 Class Initialized
INFO - 2024-12-13 03:21:27 --> URI Class Initialized
INFO - 2024-12-13 03:21:27 --> Router Class Initialized
INFO - 2024-12-13 03:21:27 --> Output Class Initialized
INFO - 2024-12-13 03:21:27 --> Security Class Initialized
DEBUG - 2024-12-13 03:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:21:27 --> Input Class Initialized
INFO - 2024-12-13 03:21:27 --> Language Class Initialized
INFO - 2024-12-13 03:21:27 --> Loader Class Initialized
INFO - 2024-12-13 03:21:27 --> Helper loaded: url_helper
INFO - 2024-12-13 03:21:27 --> Helper loaded: file_helper
INFO - 2024-12-13 03:21:27 --> Helper loaded: security_helper
INFO - 2024-12-13 03:21:27 --> Helper loaded: wpu_helper
INFO - 2024-12-13 03:21:27 --> Database Driver Class Initialized
INFO - 2024-12-13 03:21:28 --> Email Class Initialized
DEBUG - 2024-12-13 03:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:21:28 --> Helper loaded: form_helper
INFO - 2024-12-13 03:21:28 --> Form Validation Class Initialized
INFO - 2024-12-13 03:21:28 --> Controller Class Initialized
DEBUG - 2024-12-13 03:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:21:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-13 03:21:28 --> Config Class Initialized
INFO - 2024-12-13 03:21:28 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:21:28 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:21:28 --> Utf8 Class Initialized
INFO - 2024-12-13 03:21:28 --> URI Class Initialized
INFO - 2024-12-13 03:21:28 --> Router Class Initialized
INFO - 2024-12-13 03:21:28 --> Output Class Initialized
INFO - 2024-12-13 03:21:28 --> Security Class Initialized
DEBUG - 2024-12-13 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:21:28 --> Input Class Initialized
INFO - 2024-12-13 03:21:28 --> Language Class Initialized
INFO - 2024-12-13 03:21:28 --> Loader Class Initialized
INFO - 2024-12-13 03:21:28 --> Helper loaded: url_helper
INFO - 2024-12-13 03:21:28 --> Helper loaded: file_helper
INFO - 2024-12-13 03:21:28 --> Helper loaded: security_helper
INFO - 2024-12-13 03:21:28 --> Helper loaded: wpu_helper
INFO - 2024-12-13 03:21:28 --> Database Driver Class Initialized
INFO - 2024-12-13 03:21:29 --> Email Class Initialized
DEBUG - 2024-12-13 03:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:21:29 --> Helper loaded: form_helper
INFO - 2024-12-13 03:21:29 --> Form Validation Class Initialized
INFO - 2024-12-13 03:21:29 --> Controller Class Initialized
INFO - 2024-12-13 03:21:29 --> Model "Antrol_model" initialized
DEBUG - 2024-12-13 03:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-13 03:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-13 03:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-13 03:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-13 03:21:29 --> Final output sent to browser
DEBUG - 2024-12-13 03:21:29 --> Total execution time: 1.1679
INFO - 2024-12-13 03:21:59 --> Config Class Initialized
INFO - 2024-12-13 03:21:59 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:21:59 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:21:59 --> Utf8 Class Initialized
INFO - 2024-12-13 03:21:59 --> URI Class Initialized
INFO - 2024-12-13 03:21:59 --> Router Class Initialized
INFO - 2024-12-13 03:21:59 --> Output Class Initialized
INFO - 2024-12-13 03:21:59 --> Security Class Initialized
DEBUG - 2024-12-13 03:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:21:59 --> Input Class Initialized
INFO - 2024-12-13 03:21:59 --> Language Class Initialized
INFO - 2024-12-13 03:21:59 --> Loader Class Initialized
INFO - 2024-12-13 03:21:59 --> Helper loaded: url_helper
INFO - 2024-12-13 03:21:59 --> Helper loaded: file_helper
INFO - 2024-12-13 03:21:59 --> Helper loaded: security_helper
INFO - 2024-12-13 03:21:59 --> Helper loaded: wpu_helper
INFO - 2024-12-13 03:21:59 --> Database Driver Class Initialized
INFO - 2024-12-13 03:21:59 --> Email Class Initialized
DEBUG - 2024-12-13 03:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:21:59 --> Helper loaded: form_helper
INFO - 2024-12-13 03:21:59 --> Form Validation Class Initialized
INFO - 2024-12-13 03:21:59 --> Controller Class Initialized
INFO - 2024-12-13 03:21:59 --> Model "Antrol_model" initialized
DEBUG - 2024-12-13 03:21:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:22:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-13 03:22:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-13 03:22:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-13 03:22:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-13 03:22:00 --> Final output sent to browser
DEBUG - 2024-12-13 03:22:00 --> Total execution time: 1.1760
INFO - 2024-12-13 03:22:10 --> Config Class Initialized
INFO - 2024-12-13 03:22:10 --> Hooks Class Initialized
DEBUG - 2024-12-13 03:22:10 --> UTF-8 Support Enabled
INFO - 2024-12-13 03:22:10 --> Utf8 Class Initialized
INFO - 2024-12-13 03:22:10 --> URI Class Initialized
INFO - 2024-12-13 03:22:10 --> Router Class Initialized
INFO - 2024-12-13 03:22:10 --> Output Class Initialized
INFO - 2024-12-13 03:22:10 --> Security Class Initialized
DEBUG - 2024-12-13 03:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 03:22:10 --> Input Class Initialized
INFO - 2024-12-13 03:22:10 --> Language Class Initialized
INFO - 2024-12-13 03:22:10 --> Loader Class Initialized
INFO - 2024-12-13 03:22:10 --> Helper loaded: url_helper
INFO - 2024-12-13 03:22:10 --> Helper loaded: file_helper
INFO - 2024-12-13 03:22:10 --> Helper loaded: security_helper
INFO - 2024-12-13 03:22:10 --> Helper loaded: wpu_helper
INFO - 2024-12-13 03:22:10 --> Database Driver Class Initialized
INFO - 2024-12-13 03:22:10 --> Email Class Initialized
DEBUG - 2024-12-13 03:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 03:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 03:22:10 --> Helper loaded: form_helper
INFO - 2024-12-13 03:22:10 --> Form Validation Class Initialized
INFO - 2024-12-13 03:22:10 --> Controller Class Initialized
INFO - 2024-12-13 03:22:10 --> Model "Antrol_model" initialized
DEBUG - 2024-12-13 03:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 03:22:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-13 03:22:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-13 03:22:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-13 03:22:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-13 03:22:11 --> Final output sent to browser
DEBUG - 2024-12-13 03:22:11 --> Total execution time: 0.9510
INFO - 2024-12-13 15:30:24 --> Config Class Initialized
INFO - 2024-12-13 15:30:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 15:30:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 15:30:24 --> Utf8 Class Initialized
INFO - 2024-12-13 15:30:24 --> URI Class Initialized
INFO - 2024-12-13 15:30:24 --> Router Class Initialized
INFO - 2024-12-13 15:30:24 --> Output Class Initialized
INFO - 2024-12-13 15:30:24 --> Security Class Initialized
DEBUG - 2024-12-13 15:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 15:30:24 --> Input Class Initialized
INFO - 2024-12-13 15:30:24 --> Language Class Initialized
ERROR - 2024-12-13 15:30:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-13 15:30:36 --> Config Class Initialized
INFO - 2024-12-13 15:30:36 --> Hooks Class Initialized
DEBUG - 2024-12-13 15:30:36 --> UTF-8 Support Enabled
INFO - 2024-12-13 15:30:36 --> Utf8 Class Initialized
INFO - 2024-12-13 15:30:36 --> URI Class Initialized
DEBUG - 2024-12-13 15:30:36 --> No URI present. Default controller set.
INFO - 2024-12-13 15:30:36 --> Router Class Initialized
INFO - 2024-12-13 15:30:36 --> Output Class Initialized
INFO - 2024-12-13 15:30:36 --> Security Class Initialized
DEBUG - 2024-12-13 15:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 15:30:36 --> Input Class Initialized
INFO - 2024-12-13 15:30:36 --> Language Class Initialized
INFO - 2024-12-13 15:30:36 --> Loader Class Initialized
INFO - 2024-12-13 15:30:36 --> Helper loaded: url_helper
INFO - 2024-12-13 15:30:36 --> Helper loaded: file_helper
INFO - 2024-12-13 15:30:36 --> Helper loaded: security_helper
INFO - 2024-12-13 15:30:36 --> Helper loaded: wpu_helper
INFO - 2024-12-13 15:30:36 --> Database Driver Class Initialized
INFO - 2024-12-13 15:30:37 --> Email Class Initialized
DEBUG - 2024-12-13 15:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 15:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 15:30:37 --> Helper loaded: form_helper
INFO - 2024-12-13 15:30:37 --> Form Validation Class Initialized
INFO - 2024-12-13 15:30:37 --> Controller Class Initialized
DEBUG - 2024-12-13 15:30:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 15:30:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-13 15:30:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-13 15:30:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-13 15:30:37 --> Final output sent to browser
DEBUG - 2024-12-13 15:30:37 --> Total execution time: 0.4147
INFO - 2024-12-13 17:44:00 --> Config Class Initialized
INFO - 2024-12-13 17:44:00 --> Hooks Class Initialized
DEBUG - 2024-12-13 17:44:00 --> UTF-8 Support Enabled
INFO - 2024-12-13 17:44:00 --> Utf8 Class Initialized
INFO - 2024-12-13 17:44:00 --> URI Class Initialized
DEBUG - 2024-12-13 17:44:00 --> No URI present. Default controller set.
INFO - 2024-12-13 17:44:00 --> Router Class Initialized
INFO - 2024-12-13 17:44:00 --> Output Class Initialized
INFO - 2024-12-13 17:44:00 --> Security Class Initialized
DEBUG - 2024-12-13 17:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 17:44:00 --> Input Class Initialized
INFO - 2024-12-13 17:44:00 --> Language Class Initialized
INFO - 2024-12-13 17:44:00 --> Loader Class Initialized
INFO - 2024-12-13 17:44:00 --> Helper loaded: url_helper
INFO - 2024-12-13 17:44:00 --> Helper loaded: file_helper
INFO - 2024-12-13 17:44:00 --> Helper loaded: security_helper
INFO - 2024-12-13 17:44:00 --> Helper loaded: wpu_helper
INFO - 2024-12-13 17:44:00 --> Database Driver Class Initialized
INFO - 2024-12-13 17:44:00 --> Email Class Initialized
DEBUG - 2024-12-13 17:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 17:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 17:44:00 --> Helper loaded: form_helper
INFO - 2024-12-13 17:44:00 --> Form Validation Class Initialized
INFO - 2024-12-13 17:44:00 --> Controller Class Initialized
DEBUG - 2024-12-13 17:44:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 17:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-13 17:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-13 17:44:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-13 17:44:00 --> Final output sent to browser
DEBUG - 2024-12-13 17:44:00 --> Total execution time: 0.4133
INFO - 2024-12-13 20:07:24 --> Config Class Initialized
INFO - 2024-12-13 20:07:24 --> Hooks Class Initialized
DEBUG - 2024-12-13 20:07:24 --> UTF-8 Support Enabled
INFO - 2024-12-13 20:07:24 --> Utf8 Class Initialized
INFO - 2024-12-13 20:07:24 --> URI Class Initialized
INFO - 2024-12-13 20:07:24 --> Router Class Initialized
INFO - 2024-12-13 20:07:24 --> Output Class Initialized
INFO - 2024-12-13 20:07:24 --> Security Class Initialized
DEBUG - 2024-12-13 20:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 20:07:24 --> Input Class Initialized
INFO - 2024-12-13 20:07:24 --> Language Class Initialized
ERROR - 2024-12-13 20:07:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-13 20:07:25 --> Config Class Initialized
INFO - 2024-12-13 20:07:25 --> Hooks Class Initialized
DEBUG - 2024-12-13 20:07:25 --> UTF-8 Support Enabled
INFO - 2024-12-13 20:07:25 --> Utf8 Class Initialized
INFO - 2024-12-13 20:07:25 --> URI Class Initialized
DEBUG - 2024-12-13 20:07:25 --> No URI present. Default controller set.
INFO - 2024-12-13 20:07:25 --> Router Class Initialized
INFO - 2024-12-13 20:07:25 --> Output Class Initialized
INFO - 2024-12-13 20:07:25 --> Security Class Initialized
DEBUG - 2024-12-13 20:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 20:07:25 --> Input Class Initialized
INFO - 2024-12-13 20:07:25 --> Language Class Initialized
INFO - 2024-12-13 20:07:25 --> Loader Class Initialized
INFO - 2024-12-13 20:07:25 --> Helper loaded: url_helper
INFO - 2024-12-13 20:07:25 --> Helper loaded: file_helper
INFO - 2024-12-13 20:07:25 --> Helper loaded: security_helper
INFO - 2024-12-13 20:07:25 --> Helper loaded: wpu_helper
INFO - 2024-12-13 20:07:25 --> Database Driver Class Initialized
INFO - 2024-12-13 20:07:25 --> Email Class Initialized
DEBUG - 2024-12-13 20:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 20:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 20:07:25 --> Helper loaded: form_helper
INFO - 2024-12-13 20:07:25 --> Form Validation Class Initialized
INFO - 2024-12-13 20:07:25 --> Controller Class Initialized
DEBUG - 2024-12-13 20:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 20:07:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-13 20:07:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-13 20:07:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-13 20:07:25 --> Final output sent to browser
DEBUG - 2024-12-13 20:07:25 --> Total execution time: 0.6637
INFO - 2024-12-13 21:21:56 --> Config Class Initialized
INFO - 2024-12-13 21:21:56 --> Hooks Class Initialized
DEBUG - 2024-12-13 21:21:56 --> UTF-8 Support Enabled
INFO - 2024-12-13 21:21:56 --> Utf8 Class Initialized
INFO - 2024-12-13 21:21:56 --> URI Class Initialized
DEBUG - 2024-12-13 21:21:56 --> No URI present. Default controller set.
INFO - 2024-12-13 21:21:56 --> Router Class Initialized
INFO - 2024-12-13 21:21:56 --> Output Class Initialized
INFO - 2024-12-13 21:21:56 --> Security Class Initialized
DEBUG - 2024-12-13 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 21:21:56 --> Input Class Initialized
INFO - 2024-12-13 21:21:56 --> Language Class Initialized
INFO - 2024-12-13 21:21:56 --> Loader Class Initialized
INFO - 2024-12-13 21:21:56 --> Helper loaded: url_helper
INFO - 2024-12-13 21:21:57 --> Helper loaded: file_helper
INFO - 2024-12-13 21:21:57 --> Helper loaded: security_helper
INFO - 2024-12-13 21:21:57 --> Helper loaded: wpu_helper
INFO - 2024-12-13 21:21:57 --> Database Driver Class Initialized
INFO - 2024-12-13 21:21:57 --> Email Class Initialized
DEBUG - 2024-12-13 21:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-13 21:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 21:21:57 --> Helper loaded: form_helper
INFO - 2024-12-13 21:21:57 --> Form Validation Class Initialized
INFO - 2024-12-13 21:21:57 --> Controller Class Initialized
DEBUG - 2024-12-13 21:21:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-13 21:21:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-13 21:21:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-13 21:21:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-13 21:21:57 --> Final output sent to browser
DEBUG - 2024-12-13 21:21:57 --> Total execution time: 0.6908
