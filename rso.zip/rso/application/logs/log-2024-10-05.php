<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-05 06:46:37 --> Config Class Initialized
INFO - 2024-10-05 06:46:37 --> Hooks Class Initialized
DEBUG - 2024-10-05 06:46:37 --> UTF-8 Support Enabled
INFO - 2024-10-05 06:46:37 --> Utf8 Class Initialized
INFO - 2024-10-05 06:46:37 --> URI Class Initialized
DEBUG - 2024-10-05 06:46:37 --> No URI present. Default controller set.
INFO - 2024-10-05 06:46:37 --> Router Class Initialized
INFO - 2024-10-05 06:46:37 --> Output Class Initialized
INFO - 2024-10-05 06:46:37 --> Security Class Initialized
DEBUG - 2024-10-05 06:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 06:46:37 --> Input Class Initialized
INFO - 2024-10-05 06:46:37 --> Language Class Initialized
INFO - 2024-10-05 06:46:37 --> Loader Class Initialized
INFO - 2024-10-05 06:46:37 --> Helper loaded: url_helper
INFO - 2024-10-05 06:46:37 --> Helper loaded: file_helper
INFO - 2024-10-05 06:46:37 --> Helper loaded: security_helper
INFO - 2024-10-05 06:46:37 --> Helper loaded: wpu_helper
INFO - 2024-10-05 06:46:37 --> Database Driver Class Initialized
INFO - 2024-10-05 06:46:37 --> Email Class Initialized
DEBUG - 2024-10-05 06:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-05 06:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 06:46:37 --> Helper loaded: form_helper
INFO - 2024-10-05 06:46:37 --> Form Validation Class Initialized
INFO - 2024-10-05 06:46:37 --> Controller Class Initialized
DEBUG - 2024-10-05 06:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-05 06:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-05 06:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-05 06:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-05 06:46:37 --> Final output sent to browser
DEBUG - 2024-10-05 06:46:37 --> Total execution time: 0.2260
INFO - 2024-10-05 09:06:14 --> Config Class Initialized
INFO - 2024-10-05 09:06:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 09:06:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 09:06:14 --> Utf8 Class Initialized
INFO - 2024-10-05 09:06:14 --> URI Class Initialized
DEBUG - 2024-10-05 09:06:14 --> No URI present. Default controller set.
INFO - 2024-10-05 09:06:14 --> Router Class Initialized
INFO - 2024-10-05 09:06:14 --> Output Class Initialized
INFO - 2024-10-05 09:06:14 --> Security Class Initialized
DEBUG - 2024-10-05 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 09:06:14 --> Input Class Initialized
INFO - 2024-10-05 09:06:14 --> Language Class Initialized
INFO - 2024-10-05 09:06:14 --> Loader Class Initialized
INFO - 2024-10-05 09:06:14 --> Helper loaded: url_helper
INFO - 2024-10-05 09:06:14 --> Helper loaded: file_helper
INFO - 2024-10-05 09:06:14 --> Helper loaded: security_helper
INFO - 2024-10-05 09:06:14 --> Helper loaded: wpu_helper
INFO - 2024-10-05 09:06:14 --> Database Driver Class Initialized
INFO - 2024-10-05 09:06:14 --> Email Class Initialized
DEBUG - 2024-10-05 09:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-05 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 09:06:14 --> Helper loaded: form_helper
INFO - 2024-10-05 09:06:14 --> Form Validation Class Initialized
INFO - 2024-10-05 09:06:14 --> Controller Class Initialized
DEBUG - 2024-10-05 09:06:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-05 09:06:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-05 09:06:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-05 09:06:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-05 09:06:14 --> Final output sent to browser
DEBUG - 2024-10-05 09:06:14 --> Total execution time: 0.2228
INFO - 2024-10-05 18:50:21 --> Config Class Initialized
INFO - 2024-10-05 18:50:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:50:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:50:21 --> Utf8 Class Initialized
INFO - 2024-10-05 18:50:21 --> URI Class Initialized
DEBUG - 2024-10-05 18:50:21 --> No URI present. Default controller set.
INFO - 2024-10-05 18:50:21 --> Router Class Initialized
INFO - 2024-10-05 18:50:21 --> Output Class Initialized
INFO - 2024-10-05 18:50:21 --> Security Class Initialized
DEBUG - 2024-10-05 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:50:21 --> Input Class Initialized
INFO - 2024-10-05 18:50:21 --> Language Class Initialized
INFO - 2024-10-05 18:50:21 --> Loader Class Initialized
INFO - 2024-10-05 18:50:21 --> Helper loaded: url_helper
INFO - 2024-10-05 18:50:21 --> Helper loaded: file_helper
INFO - 2024-10-05 18:50:21 --> Helper loaded: security_helper
INFO - 2024-10-05 18:50:21 --> Helper loaded: wpu_helper
INFO - 2024-10-05 18:50:21 --> Database Driver Class Initialized
INFO - 2024-10-05 18:50:21 --> Email Class Initialized
DEBUG - 2024-10-05 18:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-05 18:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:50:21 --> Helper loaded: form_helper
INFO - 2024-10-05 18:50:21 --> Form Validation Class Initialized
INFO - 2024-10-05 18:50:21 --> Controller Class Initialized
DEBUG - 2024-10-05 18:50:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-05 18:50:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-05 18:50:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-05 18:50:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-05 18:50:21 --> Final output sent to browser
DEBUG - 2024-10-05 18:50:21 --> Total execution time: 0.2169
INFO - 2024-10-05 18:50:22 --> Config Class Initialized
INFO - 2024-10-05 18:50:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:50:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:50:22 --> Utf8 Class Initialized
INFO - 2024-10-05 18:50:22 --> URI Class Initialized
DEBUG - 2024-10-05 18:50:22 --> No URI present. Default controller set.
INFO - 2024-10-05 18:50:22 --> Router Class Initialized
INFO - 2024-10-05 18:50:22 --> Output Class Initialized
INFO - 2024-10-05 18:50:22 --> Security Class Initialized
DEBUG - 2024-10-05 18:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:50:22 --> Input Class Initialized
INFO - 2024-10-05 18:50:22 --> Language Class Initialized
INFO - 2024-10-05 18:50:22 --> Loader Class Initialized
INFO - 2024-10-05 18:50:22 --> Helper loaded: url_helper
INFO - 2024-10-05 18:50:22 --> Helper loaded: file_helper
INFO - 2024-10-05 18:50:22 --> Helper loaded: security_helper
INFO - 2024-10-05 18:50:22 --> Helper loaded: wpu_helper
INFO - 2024-10-05 18:50:22 --> Database Driver Class Initialized
INFO - 2024-10-05 18:50:22 --> Email Class Initialized
DEBUG - 2024-10-05 18:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-05 18:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:50:22 --> Helper loaded: form_helper
INFO - 2024-10-05 18:50:22 --> Form Validation Class Initialized
INFO - 2024-10-05 18:50:22 --> Controller Class Initialized
DEBUG - 2024-10-05 18:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-05 18:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-05 18:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-05 18:50:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-05 18:50:22 --> Final output sent to browser
DEBUG - 2024-10-05 18:50:22 --> Total execution time: 0.2154
INFO - 2024-10-05 19:56:17 --> Config Class Initialized
INFO - 2024-10-05 19:56:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:17 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:17 --> URI Class Initialized
INFO - 2024-10-05 19:56:17 --> Router Class Initialized
INFO - 2024-10-05 19:56:17 --> Output Class Initialized
INFO - 2024-10-05 19:56:17 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:17 --> Input Class Initialized
INFO - 2024-10-05 19:56:17 --> Language Class Initialized
ERROR - 2024-10-05 19:56:17 --> 404 Page Not Found: Envexemple/index
INFO - 2024-10-05 19:56:18 --> Config Class Initialized
INFO - 2024-10-05 19:56:18 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:18 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:18 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:18 --> URI Class Initialized
INFO - 2024-10-05 19:56:18 --> Router Class Initialized
INFO - 2024-10-05 19:56:18 --> Output Class Initialized
INFO - 2024-10-05 19:56:18 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:18 --> Input Class Initialized
INFO - 2024-10-05 19:56:18 --> Language Class Initialized
ERROR - 2024-10-05 19:56:18 --> 404 Page Not Found: Env_exemple/index
INFO - 2024-10-05 19:56:19 --> Config Class Initialized
INFO - 2024-10-05 19:56:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:19 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:19 --> URI Class Initialized
INFO - 2024-10-05 19:56:19 --> Router Class Initialized
INFO - 2024-10-05 19:56:19 --> Output Class Initialized
INFO - 2024-10-05 19:56:19 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:19 --> Input Class Initialized
INFO - 2024-10-05 19:56:19 --> Language Class Initialized
ERROR - 2024-10-05 19:56:19 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-10-05 19:56:19 --> Config Class Initialized
INFO - 2024-10-05 19:56:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:19 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:19 --> URI Class Initialized
INFO - 2024-10-05 19:56:19 --> Router Class Initialized
INFO - 2024-10-05 19:56:19 --> Output Class Initialized
INFO - 2024-10-05 19:56:19 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:19 --> Input Class Initialized
INFO - 2024-10-05 19:56:19 --> Language Class Initialized
ERROR - 2024-10-05 19:56:19 --> 404 Page Not Found: Aws/credentials
INFO - 2024-10-05 19:56:20 --> Config Class Initialized
INFO - 2024-10-05 19:56:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:20 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:20 --> URI Class Initialized
INFO - 2024-10-05 19:56:20 --> Router Class Initialized
INFO - 2024-10-05 19:56:20 --> Output Class Initialized
INFO - 2024-10-05 19:56:20 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:20 --> Input Class Initialized
INFO - 2024-10-05 19:56:20 --> Language Class Initialized
ERROR - 2024-10-05 19:56:20 --> 404 Page Not Found: Phpinfophp/index
INFO - 2024-10-05 19:56:20 --> Config Class Initialized
INFO - 2024-10-05 19:56:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:20 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:20 --> URI Class Initialized
INFO - 2024-10-05 19:56:20 --> Router Class Initialized
INFO - 2024-10-05 19:56:20 --> Output Class Initialized
INFO - 2024-10-05 19:56:20 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:20 --> Input Class Initialized
INFO - 2024-10-05 19:56:20 --> Language Class Initialized
ERROR - 2024-10-05 19:56:20 --> 404 Page Not Found: Phpinfo/index
INFO - 2024-10-05 19:56:21 --> Config Class Initialized
INFO - 2024-10-05 19:56:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:21 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:21 --> URI Class Initialized
INFO - 2024-10-05 19:56:21 --> Router Class Initialized
INFO - 2024-10-05 19:56:21 --> Output Class Initialized
INFO - 2024-10-05 19:56:21 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:21 --> Input Class Initialized
INFO - 2024-10-05 19:56:21 --> Language Class Initialized
ERROR - 2024-10-05 19:56:21 --> 404 Page Not Found: Info/index
INFO - 2024-10-05 19:56:21 --> Config Class Initialized
INFO - 2024-10-05 19:56:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:21 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:21 --> URI Class Initialized
INFO - 2024-10-05 19:56:21 --> Router Class Initialized
INFO - 2024-10-05 19:56:21 --> Output Class Initialized
INFO - 2024-10-05 19:56:21 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:21 --> Input Class Initialized
INFO - 2024-10-05 19:56:21 --> Language Class Initialized
ERROR - 2024-10-05 19:56:21 --> 404 Page Not Found: Php_info/index
INFO - 2024-10-05 19:56:22 --> Config Class Initialized
INFO - 2024-10-05 19:56:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:22 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:22 --> URI Class Initialized
INFO - 2024-10-05 19:56:22 --> Router Class Initialized
INFO - 2024-10-05 19:56:22 --> Output Class Initialized
INFO - 2024-10-05 19:56:22 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:22 --> Input Class Initialized
INFO - 2024-10-05 19:56:22 --> Language Class Initialized
ERROR - 2024-10-05 19:56:22 --> 404 Page Not Found: Php_infophp/index
INFO - 2024-10-05 19:56:22 --> Config Class Initialized
INFO - 2024-10-05 19:56:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:22 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:22 --> URI Class Initialized
INFO - 2024-10-05 19:56:22 --> Router Class Initialized
INFO - 2024-10-05 19:56:22 --> Output Class Initialized
INFO - 2024-10-05 19:56:22 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:22 --> Input Class Initialized
INFO - 2024-10-05 19:56:22 --> Language Class Initialized
ERROR - 2024-10-05 19:56:22 --> 404 Page Not Found: Infophp/index
INFO - 2024-10-05 19:56:23 --> Config Class Initialized
INFO - 2024-10-05 19:56:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:23 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:23 --> URI Class Initialized
INFO - 2024-10-05 19:56:23 --> Router Class Initialized
INFO - 2024-10-05 19:56:23 --> Output Class Initialized
INFO - 2024-10-05 19:56:23 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:23 --> Input Class Initialized
INFO - 2024-10-05 19:56:23 --> Language Class Initialized
ERROR - 2024-10-05 19:56:23 --> 404 Page Not Found: _profiler/phpinfo.php
INFO - 2024-10-05 19:56:24 --> Config Class Initialized
INFO - 2024-10-05 19:56:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:56:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:56:24 --> Utf8 Class Initialized
INFO - 2024-10-05 19:56:24 --> URI Class Initialized
INFO - 2024-10-05 19:56:24 --> Router Class Initialized
INFO - 2024-10-05 19:56:24 --> Output Class Initialized
INFO - 2024-10-05 19:56:24 --> Security Class Initialized
DEBUG - 2024-10-05 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:56:24 --> Input Class Initialized
INFO - 2024-10-05 19:56:24 --> Language Class Initialized
ERROR - 2024-10-05 19:56:24 --> 404 Page Not Found: _profiler/phpinfo
