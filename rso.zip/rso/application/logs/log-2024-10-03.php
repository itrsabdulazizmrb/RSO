<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-03 00:32:34 --> Config Class Initialized
INFO - 2024-10-03 00:32:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:32:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:32:34 --> Utf8 Class Initialized
INFO - 2024-10-03 00:32:34 --> URI Class Initialized
DEBUG - 2024-10-03 00:32:34 --> No URI present. Default controller set.
INFO - 2024-10-03 00:32:34 --> Router Class Initialized
INFO - 2024-10-03 00:32:34 --> Output Class Initialized
INFO - 2024-10-03 00:32:34 --> Security Class Initialized
DEBUG - 2024-10-03 00:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:32:34 --> Input Class Initialized
INFO - 2024-10-03 00:32:34 --> Language Class Initialized
INFO - 2024-10-03 00:32:34 --> Loader Class Initialized
INFO - 2024-10-03 00:32:34 --> Helper loaded: url_helper
INFO - 2024-10-03 00:32:34 --> Helper loaded: file_helper
INFO - 2024-10-03 00:32:34 --> Helper loaded: security_helper
INFO - 2024-10-03 00:32:34 --> Helper loaded: wpu_helper
INFO - 2024-10-03 00:32:34 --> Database Driver Class Initialized
INFO - 2024-10-03 00:32:34 --> Email Class Initialized
DEBUG - 2024-10-03 00:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 00:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 00:32:34 --> Helper loaded: form_helper
INFO - 2024-10-03 00:32:34 --> Form Validation Class Initialized
INFO - 2024-10-03 00:32:34 --> Controller Class Initialized
DEBUG - 2024-10-03 00:32:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 00:32:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 00:32:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 00:32:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 00:32:34 --> Final output sent to browser
DEBUG - 2024-10-03 00:32:34 --> Total execution time: 0.2250
INFO - 2024-10-03 00:32:39 --> Config Class Initialized
INFO - 2024-10-03 00:32:39 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:32:39 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:32:39 --> Utf8 Class Initialized
INFO - 2024-10-03 00:32:39 --> URI Class Initialized
INFO - 2024-10-03 00:32:39 --> Router Class Initialized
INFO - 2024-10-03 00:32:39 --> Output Class Initialized
INFO - 2024-10-03 00:32:39 --> Security Class Initialized
DEBUG - 2024-10-03 00:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:32:39 --> Input Class Initialized
INFO - 2024-10-03 00:32:39 --> Language Class Initialized
ERROR - 2024-10-03 00:32:39 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-03 00:32:40 --> Config Class Initialized
INFO - 2024-10-03 00:32:40 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:32:40 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:32:40 --> Utf8 Class Initialized
INFO - 2024-10-03 00:32:40 --> URI Class Initialized
INFO - 2024-10-03 00:32:40 --> Router Class Initialized
INFO - 2024-10-03 00:32:40 --> Output Class Initialized
INFO - 2024-10-03 00:32:40 --> Security Class Initialized
DEBUG - 2024-10-03 00:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:32:40 --> Input Class Initialized
INFO - 2024-10-03 00:32:40 --> Language Class Initialized
ERROR - 2024-10-03 00:32:40 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-03 00:32:40 --> Config Class Initialized
INFO - 2024-10-03 00:32:40 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:32:40 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:32:40 --> Utf8 Class Initialized
INFO - 2024-10-03 00:32:40 --> URI Class Initialized
INFO - 2024-10-03 00:32:40 --> Router Class Initialized
INFO - 2024-10-03 00:32:40 --> Output Class Initialized
INFO - 2024-10-03 00:32:40 --> Security Class Initialized
DEBUG - 2024-10-03 00:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:32:40 --> Input Class Initialized
INFO - 2024-10-03 00:32:40 --> Language Class Initialized
ERROR - 2024-10-03 00:32:40 --> 404 Page Not Found: Configjson/index
INFO - 2024-10-03 00:35:29 --> Config Class Initialized
INFO - 2024-10-03 00:35:29 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:35:29 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:35:29 --> Utf8 Class Initialized
INFO - 2024-10-03 00:35:29 --> URI Class Initialized
DEBUG - 2024-10-03 00:35:29 --> No URI present. Default controller set.
INFO - 2024-10-03 00:35:29 --> Router Class Initialized
INFO - 2024-10-03 00:35:29 --> Output Class Initialized
INFO - 2024-10-03 00:35:29 --> Security Class Initialized
DEBUG - 2024-10-03 00:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:35:29 --> Input Class Initialized
INFO - 2024-10-03 00:35:29 --> Language Class Initialized
INFO - 2024-10-03 00:35:29 --> Loader Class Initialized
INFO - 2024-10-03 00:35:29 --> Helper loaded: url_helper
INFO - 2024-10-03 00:35:29 --> Helper loaded: file_helper
INFO - 2024-10-03 00:35:29 --> Helper loaded: security_helper
INFO - 2024-10-03 00:35:29 --> Helper loaded: wpu_helper
INFO - 2024-10-03 00:35:29 --> Database Driver Class Initialized
INFO - 2024-10-03 00:35:29 --> Email Class Initialized
DEBUG - 2024-10-03 00:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 00:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 00:35:29 --> Helper loaded: form_helper
INFO - 2024-10-03 00:35:29 --> Form Validation Class Initialized
INFO - 2024-10-03 00:35:29 --> Controller Class Initialized
DEBUG - 2024-10-03 00:35:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 00:35:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 00:35:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 00:35:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 00:35:29 --> Final output sent to browser
DEBUG - 2024-10-03 00:35:29 --> Total execution time: 0.2152
INFO - 2024-10-03 00:35:35 --> Config Class Initialized
INFO - 2024-10-03 00:35:35 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:35:35 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:35:35 --> Utf8 Class Initialized
INFO - 2024-10-03 00:35:35 --> URI Class Initialized
INFO - 2024-10-03 00:35:35 --> Router Class Initialized
INFO - 2024-10-03 00:35:35 --> Output Class Initialized
INFO - 2024-10-03 00:35:35 --> Security Class Initialized
DEBUG - 2024-10-03 00:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:35:35 --> Input Class Initialized
INFO - 2024-10-03 00:35:35 --> Language Class Initialized
ERROR - 2024-10-03 00:35:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-03 00:35:36 --> Config Class Initialized
INFO - 2024-10-03 00:35:36 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:35:36 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:35:36 --> Utf8 Class Initialized
INFO - 2024-10-03 00:35:36 --> URI Class Initialized
INFO - 2024-10-03 00:35:36 --> Router Class Initialized
INFO - 2024-10-03 00:35:36 --> Output Class Initialized
INFO - 2024-10-03 00:35:36 --> Security Class Initialized
DEBUG - 2024-10-03 00:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:35:36 --> Input Class Initialized
INFO - 2024-10-03 00:35:36 --> Language Class Initialized
ERROR - 2024-10-03 00:35:36 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-03 00:35:41 --> Config Class Initialized
INFO - 2024-10-03 00:35:41 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:35:41 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:35:41 --> Utf8 Class Initialized
INFO - 2024-10-03 00:35:41 --> URI Class Initialized
INFO - 2024-10-03 00:35:41 --> Router Class Initialized
INFO - 2024-10-03 00:35:41 --> Output Class Initialized
INFO - 2024-10-03 00:35:41 --> Security Class Initialized
DEBUG - 2024-10-03 00:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:35:41 --> Input Class Initialized
INFO - 2024-10-03 00:35:41 --> Language Class Initialized
ERROR - 2024-10-03 00:35:41 --> 404 Page Not Found: Configjson/index
INFO - 2024-10-03 00:45:29 --> Config Class Initialized
INFO - 2024-10-03 00:45:29 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:45:29 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:45:29 --> Utf8 Class Initialized
INFO - 2024-10-03 00:45:29 --> URI Class Initialized
DEBUG - 2024-10-03 00:45:29 --> No URI present. Default controller set.
INFO - 2024-10-03 00:45:29 --> Router Class Initialized
INFO - 2024-10-03 00:45:29 --> Output Class Initialized
INFO - 2024-10-03 00:45:29 --> Security Class Initialized
DEBUG - 2024-10-03 00:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:45:29 --> Input Class Initialized
INFO - 2024-10-03 00:45:29 --> Language Class Initialized
INFO - 2024-10-03 00:45:29 --> Loader Class Initialized
INFO - 2024-10-03 00:45:29 --> Helper loaded: url_helper
INFO - 2024-10-03 00:45:29 --> Helper loaded: file_helper
INFO - 2024-10-03 00:45:29 --> Helper loaded: security_helper
INFO - 2024-10-03 00:45:29 --> Helper loaded: wpu_helper
INFO - 2024-10-03 00:45:29 --> Database Driver Class Initialized
INFO - 2024-10-03 00:45:29 --> Email Class Initialized
DEBUG - 2024-10-03 00:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 00:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 00:45:29 --> Helper loaded: form_helper
INFO - 2024-10-03 00:45:29 --> Form Validation Class Initialized
INFO - 2024-10-03 00:45:29 --> Controller Class Initialized
DEBUG - 2024-10-03 00:45:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 00:45:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 00:45:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 00:45:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 00:45:29 --> Final output sent to browser
DEBUG - 2024-10-03 00:45:29 --> Total execution time: 0.2258
INFO - 2024-10-03 00:45:34 --> Config Class Initialized
INFO - 2024-10-03 00:45:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:45:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:45:34 --> Utf8 Class Initialized
INFO - 2024-10-03 00:45:34 --> URI Class Initialized
INFO - 2024-10-03 00:45:34 --> Router Class Initialized
INFO - 2024-10-03 00:45:34 --> Output Class Initialized
INFO - 2024-10-03 00:45:34 --> Security Class Initialized
DEBUG - 2024-10-03 00:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:45:34 --> Input Class Initialized
INFO - 2024-10-03 00:45:34 --> Language Class Initialized
ERROR - 2024-10-03 00:45:34 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-03 00:45:34 --> Config Class Initialized
INFO - 2024-10-03 00:45:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:45:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:45:34 --> Utf8 Class Initialized
INFO - 2024-10-03 00:45:34 --> URI Class Initialized
INFO - 2024-10-03 00:45:34 --> Router Class Initialized
INFO - 2024-10-03 00:45:34 --> Output Class Initialized
INFO - 2024-10-03 00:45:34 --> Security Class Initialized
DEBUG - 2024-10-03 00:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:45:34 --> Input Class Initialized
INFO - 2024-10-03 00:45:34 --> Language Class Initialized
ERROR - 2024-10-03 00:45:34 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-03 00:45:34 --> Config Class Initialized
INFO - 2024-10-03 00:45:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:45:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:45:34 --> Utf8 Class Initialized
INFO - 2024-10-03 00:45:34 --> URI Class Initialized
INFO - 2024-10-03 00:45:34 --> Router Class Initialized
INFO - 2024-10-03 00:45:34 --> Output Class Initialized
INFO - 2024-10-03 00:45:34 --> Security Class Initialized
DEBUG - 2024-10-03 00:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:45:34 --> Input Class Initialized
INFO - 2024-10-03 00:45:34 --> Language Class Initialized
ERROR - 2024-10-03 00:45:34 --> 404 Page Not Found: Configjson/index
INFO - 2024-10-03 00:46:26 --> Config Class Initialized
INFO - 2024-10-03 00:46:26 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:46:26 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:46:26 --> Utf8 Class Initialized
INFO - 2024-10-03 00:46:26 --> URI Class Initialized
DEBUG - 2024-10-03 00:46:26 --> No URI present. Default controller set.
INFO - 2024-10-03 00:46:26 --> Router Class Initialized
INFO - 2024-10-03 00:46:26 --> Output Class Initialized
INFO - 2024-10-03 00:46:26 --> Security Class Initialized
DEBUG - 2024-10-03 00:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:46:26 --> Input Class Initialized
INFO - 2024-10-03 00:46:26 --> Language Class Initialized
INFO - 2024-10-03 00:46:26 --> Loader Class Initialized
INFO - 2024-10-03 00:46:26 --> Helper loaded: url_helper
INFO - 2024-10-03 00:46:26 --> Helper loaded: file_helper
INFO - 2024-10-03 00:46:26 --> Helper loaded: security_helper
INFO - 2024-10-03 00:46:26 --> Helper loaded: wpu_helper
INFO - 2024-10-03 00:46:26 --> Database Driver Class Initialized
INFO - 2024-10-03 00:46:26 --> Email Class Initialized
DEBUG - 2024-10-03 00:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 00:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 00:46:26 --> Helper loaded: form_helper
INFO - 2024-10-03 00:46:26 --> Form Validation Class Initialized
INFO - 2024-10-03 00:46:26 --> Controller Class Initialized
DEBUG - 2024-10-03 00:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 00:46:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 00:46:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 00:46:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 00:46:26 --> Final output sent to browser
DEBUG - 2024-10-03 00:46:26 --> Total execution time: 0.2238
INFO - 2024-10-03 00:46:31 --> Config Class Initialized
INFO - 2024-10-03 00:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:46:31 --> Utf8 Class Initialized
INFO - 2024-10-03 00:46:31 --> URI Class Initialized
INFO - 2024-10-03 00:46:31 --> Router Class Initialized
INFO - 2024-10-03 00:46:31 --> Output Class Initialized
INFO - 2024-10-03 00:46:31 --> Security Class Initialized
DEBUG - 2024-10-03 00:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:46:31 --> Input Class Initialized
INFO - 2024-10-03 00:46:31 --> Language Class Initialized
ERROR - 2024-10-03 00:46:31 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-03 00:46:31 --> Config Class Initialized
INFO - 2024-10-03 00:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:46:31 --> Utf8 Class Initialized
INFO - 2024-10-03 00:46:31 --> URI Class Initialized
INFO - 2024-10-03 00:46:31 --> Router Class Initialized
INFO - 2024-10-03 00:46:31 --> Output Class Initialized
INFO - 2024-10-03 00:46:31 --> Security Class Initialized
DEBUG - 2024-10-03 00:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:46:31 --> Input Class Initialized
INFO - 2024-10-03 00:46:31 --> Language Class Initialized
ERROR - 2024-10-03 00:46:31 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-03 00:46:34 --> Config Class Initialized
INFO - 2024-10-03 00:46:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 00:46:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 00:46:34 --> Utf8 Class Initialized
INFO - 2024-10-03 00:46:34 --> URI Class Initialized
INFO - 2024-10-03 00:46:34 --> Router Class Initialized
INFO - 2024-10-03 00:46:34 --> Output Class Initialized
INFO - 2024-10-03 00:46:34 --> Security Class Initialized
DEBUG - 2024-10-03 00:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 00:46:34 --> Input Class Initialized
INFO - 2024-10-03 00:46:34 --> Language Class Initialized
ERROR - 2024-10-03 00:46:34 --> 404 Page Not Found: Configjson/index
INFO - 2024-10-03 09:08:36 --> Config Class Initialized
INFO - 2024-10-03 09:08:36 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:08:36 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:08:36 --> Utf8 Class Initialized
INFO - 2024-10-03 09:08:36 --> URI Class Initialized
DEBUG - 2024-10-03 09:08:36 --> No URI present. Default controller set.
INFO - 2024-10-03 09:08:36 --> Router Class Initialized
INFO - 2024-10-03 09:08:36 --> Output Class Initialized
INFO - 2024-10-03 09:08:36 --> Security Class Initialized
DEBUG - 2024-10-03 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:08:36 --> Input Class Initialized
INFO - 2024-10-03 09:08:36 --> Language Class Initialized
INFO - 2024-10-03 09:08:36 --> Loader Class Initialized
INFO - 2024-10-03 09:08:36 --> Helper loaded: url_helper
INFO - 2024-10-03 09:08:36 --> Helper loaded: file_helper
INFO - 2024-10-03 09:08:36 --> Helper loaded: security_helper
INFO - 2024-10-03 09:08:36 --> Helper loaded: wpu_helper
INFO - 2024-10-03 09:08:36 --> Database Driver Class Initialized
INFO - 2024-10-03 09:08:36 --> Email Class Initialized
DEBUG - 2024-10-03 09:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 09:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:08:36 --> Helper loaded: form_helper
INFO - 2024-10-03 09:08:36 --> Form Validation Class Initialized
INFO - 2024-10-03 09:08:36 --> Controller Class Initialized
DEBUG - 2024-10-03 09:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 09:08:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 09:08:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 09:08:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 09:08:36 --> Final output sent to browser
DEBUG - 2024-10-03 09:08:36 --> Total execution time: 0.2403
INFO - 2024-10-03 14:35:15 --> Config Class Initialized
INFO - 2024-10-03 14:35:15 --> Hooks Class Initialized
DEBUG - 2024-10-03 14:35:15 --> UTF-8 Support Enabled
INFO - 2024-10-03 14:35:15 --> Utf8 Class Initialized
INFO - 2024-10-03 14:35:15 --> URI Class Initialized
DEBUG - 2024-10-03 14:35:15 --> No URI present. Default controller set.
INFO - 2024-10-03 14:35:15 --> Router Class Initialized
INFO - 2024-10-03 14:35:15 --> Output Class Initialized
INFO - 2024-10-03 14:35:15 --> Security Class Initialized
DEBUG - 2024-10-03 14:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 14:35:15 --> Input Class Initialized
INFO - 2024-10-03 14:35:15 --> Language Class Initialized
INFO - 2024-10-03 14:35:15 --> Loader Class Initialized
INFO - 2024-10-03 14:35:15 --> Helper loaded: url_helper
INFO - 2024-10-03 14:35:15 --> Helper loaded: file_helper
INFO - 2024-10-03 14:35:15 --> Helper loaded: security_helper
INFO - 2024-10-03 14:35:15 --> Helper loaded: wpu_helper
INFO - 2024-10-03 14:35:15 --> Database Driver Class Initialized
INFO - 2024-10-03 14:35:15 --> Email Class Initialized
DEBUG - 2024-10-03 14:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 14:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 14:35:15 --> Helper loaded: form_helper
INFO - 2024-10-03 14:35:15 --> Form Validation Class Initialized
INFO - 2024-10-03 14:35:15 --> Controller Class Initialized
DEBUG - 2024-10-03 14:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 14:35:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-03 14:35:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 14:35:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 14:35:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 14:35:15 --> Final output sent to browser
DEBUG - 2024-10-03 14:35:15 --> Total execution time: 0.2206
INFO - 2024-10-03 19:08:01 --> Config Class Initialized
INFO - 2024-10-03 19:08:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 19:08:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 19:08:01 --> Utf8 Class Initialized
INFO - 2024-10-03 19:08:01 --> URI Class Initialized
DEBUG - 2024-10-03 19:08:01 --> No URI present. Default controller set.
INFO - 2024-10-03 19:08:01 --> Router Class Initialized
INFO - 2024-10-03 19:08:01 --> Output Class Initialized
INFO - 2024-10-03 19:08:01 --> Security Class Initialized
DEBUG - 2024-10-03 19:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 19:08:01 --> Input Class Initialized
INFO - 2024-10-03 19:08:01 --> Language Class Initialized
INFO - 2024-10-03 19:08:01 --> Loader Class Initialized
INFO - 2024-10-03 19:08:01 --> Helper loaded: url_helper
INFO - 2024-10-03 19:08:01 --> Helper loaded: file_helper
INFO - 2024-10-03 19:08:01 --> Helper loaded: security_helper
INFO - 2024-10-03 19:08:01 --> Helper loaded: wpu_helper
INFO - 2024-10-03 19:08:01 --> Database Driver Class Initialized
INFO - 2024-10-03 19:08:01 --> Email Class Initialized
DEBUG - 2024-10-03 19:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 19:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 19:08:01 --> Helper loaded: form_helper
INFO - 2024-10-03 19:08:01 --> Form Validation Class Initialized
INFO - 2024-10-03 19:08:01 --> Controller Class Initialized
DEBUG - 2024-10-03 19:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 19:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 19:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 19:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 19:08:01 --> Final output sent to browser
DEBUG - 2024-10-03 19:08:01 --> Total execution time: 0.2230
INFO - 2024-10-03 19:08:02 --> Config Class Initialized
INFO - 2024-10-03 19:08:02 --> Hooks Class Initialized
DEBUG - 2024-10-03 19:08:02 --> UTF-8 Support Enabled
INFO - 2024-10-03 19:08:02 --> Utf8 Class Initialized
INFO - 2024-10-03 19:08:02 --> URI Class Initialized
DEBUG - 2024-10-03 19:08:02 --> No URI present. Default controller set.
INFO - 2024-10-03 19:08:02 --> Router Class Initialized
INFO - 2024-10-03 19:08:02 --> Output Class Initialized
INFO - 2024-10-03 19:08:02 --> Security Class Initialized
DEBUG - 2024-10-03 19:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 19:08:02 --> Input Class Initialized
INFO - 2024-10-03 19:08:02 --> Language Class Initialized
INFO - 2024-10-03 19:08:02 --> Loader Class Initialized
INFO - 2024-10-03 19:08:02 --> Helper loaded: url_helper
INFO - 2024-10-03 19:08:02 --> Helper loaded: file_helper
INFO - 2024-10-03 19:08:02 --> Helper loaded: security_helper
INFO - 2024-10-03 19:08:02 --> Helper loaded: wpu_helper
INFO - 2024-10-03 19:08:02 --> Database Driver Class Initialized
INFO - 2024-10-03 19:08:02 --> Email Class Initialized
DEBUG - 2024-10-03 19:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 19:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 19:08:02 --> Helper loaded: form_helper
INFO - 2024-10-03 19:08:02 --> Form Validation Class Initialized
INFO - 2024-10-03 19:08:02 --> Controller Class Initialized
DEBUG - 2024-10-03 19:08:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 19:08:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 19:08:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 19:08:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 19:08:02 --> Final output sent to browser
DEBUG - 2024-10-03 19:08:02 --> Total execution time: 0.2346
INFO - 2024-10-03 21:37:09 --> Config Class Initialized
INFO - 2024-10-03 21:37:09 --> Hooks Class Initialized
DEBUG - 2024-10-03 21:37:09 --> UTF-8 Support Enabled
INFO - 2024-10-03 21:37:09 --> Utf8 Class Initialized
INFO - 2024-10-03 21:37:09 --> URI Class Initialized
DEBUG - 2024-10-03 21:37:09 --> No URI present. Default controller set.
INFO - 2024-10-03 21:37:09 --> Router Class Initialized
INFO - 2024-10-03 21:37:09 --> Output Class Initialized
INFO - 2024-10-03 21:37:09 --> Security Class Initialized
DEBUG - 2024-10-03 21:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 21:37:09 --> Input Class Initialized
INFO - 2024-10-03 21:37:09 --> Language Class Initialized
INFO - 2024-10-03 21:37:09 --> Loader Class Initialized
INFO - 2024-10-03 21:37:09 --> Helper loaded: url_helper
INFO - 2024-10-03 21:37:09 --> Helper loaded: file_helper
INFO - 2024-10-03 21:37:09 --> Helper loaded: security_helper
INFO - 2024-10-03 21:37:09 --> Helper loaded: wpu_helper
INFO - 2024-10-03 21:37:09 --> Database Driver Class Initialized
INFO - 2024-10-03 21:37:10 --> Email Class Initialized
DEBUG - 2024-10-03 21:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 21:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 21:37:10 --> Helper loaded: form_helper
INFO - 2024-10-03 21:37:10 --> Form Validation Class Initialized
INFO - 2024-10-03 21:37:10 --> Controller Class Initialized
DEBUG - 2024-10-03 21:37:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 21:37:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 21:37:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 21:37:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 21:37:10 --> Final output sent to browser
DEBUG - 2024-10-03 21:37:10 --> Total execution time: 0.2896
INFO - 2024-10-03 21:37:11 --> Config Class Initialized
INFO - 2024-10-03 21:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-03 21:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-03 21:37:11 --> Utf8 Class Initialized
INFO - 2024-10-03 21:37:11 --> URI Class Initialized
INFO - 2024-10-03 21:37:11 --> Router Class Initialized
INFO - 2024-10-03 21:37:11 --> Output Class Initialized
INFO - 2024-10-03 21:37:11 --> Security Class Initialized
DEBUG - 2024-10-03 21:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 21:37:11 --> Input Class Initialized
INFO - 2024-10-03 21:37:11 --> Language Class Initialized
INFO - 2024-10-03 21:37:11 --> Loader Class Initialized
INFO - 2024-10-03 21:37:11 --> Helper loaded: url_helper
INFO - 2024-10-03 21:37:11 --> Helper loaded: file_helper
INFO - 2024-10-03 21:37:11 --> Helper loaded: security_helper
INFO - 2024-10-03 21:37:11 --> Helper loaded: wpu_helper
INFO - 2024-10-03 21:37:11 --> Database Driver Class Initialized
INFO - 2024-10-03 21:37:12 --> Email Class Initialized
DEBUG - 2024-10-03 21:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 21:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 21:37:12 --> Helper loaded: form_helper
INFO - 2024-10-03 21:37:12 --> Form Validation Class Initialized
INFO - 2024-10-03 21:37:12 --> Controller Class Initialized
DEBUG - 2024-10-03 21:37:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 21:37:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-03 21:37:12 --> Config Class Initialized
INFO - 2024-10-03 21:37:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 21:37:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 21:37:12 --> Utf8 Class Initialized
INFO - 2024-10-03 21:37:12 --> URI Class Initialized
INFO - 2024-10-03 21:37:12 --> Router Class Initialized
INFO - 2024-10-03 21:37:12 --> Output Class Initialized
INFO - 2024-10-03 21:37:12 --> Security Class Initialized
DEBUG - 2024-10-03 21:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 21:37:12 --> Input Class Initialized
INFO - 2024-10-03 21:37:12 --> Language Class Initialized
INFO - 2024-10-03 21:37:12 --> Loader Class Initialized
INFO - 2024-10-03 21:37:12 --> Helper loaded: url_helper
INFO - 2024-10-03 21:37:12 --> Helper loaded: file_helper
INFO - 2024-10-03 21:37:12 --> Helper loaded: security_helper
INFO - 2024-10-03 21:37:12 --> Helper loaded: wpu_helper
INFO - 2024-10-03 21:37:12 --> Database Driver Class Initialized
INFO - 2024-10-03 21:37:12 --> Email Class Initialized
DEBUG - 2024-10-03 21:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 21:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 21:37:12 --> Helper loaded: form_helper
INFO - 2024-10-03 21:37:12 --> Form Validation Class Initialized
INFO - 2024-10-03 21:37:12 --> Controller Class Initialized
INFO - 2024-10-03 21:37:12 --> Model "Antrol_model" initialized
DEBUG - 2024-10-03 21:37:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 21:37:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-03 21:37:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-03 21:37:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-03 21:37:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-03 21:37:12 --> Final output sent to browser
DEBUG - 2024-10-03 21:37:12 --> Total execution time: 0.5181
INFO - 2024-10-03 22:36:46 --> Config Class Initialized
INFO - 2024-10-03 22:36:46 --> Hooks Class Initialized
DEBUG - 2024-10-03 22:36:46 --> UTF-8 Support Enabled
INFO - 2024-10-03 22:36:46 --> Utf8 Class Initialized
INFO - 2024-10-03 22:36:46 --> URI Class Initialized
DEBUG - 2024-10-03 22:36:46 --> No URI present. Default controller set.
INFO - 2024-10-03 22:36:46 --> Router Class Initialized
INFO - 2024-10-03 22:36:46 --> Output Class Initialized
INFO - 2024-10-03 22:36:46 --> Security Class Initialized
DEBUG - 2024-10-03 22:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 22:36:46 --> Input Class Initialized
INFO - 2024-10-03 22:36:46 --> Language Class Initialized
INFO - 2024-10-03 22:36:46 --> Loader Class Initialized
INFO - 2024-10-03 22:36:46 --> Helper loaded: url_helper
INFO - 2024-10-03 22:36:46 --> Helper loaded: file_helper
INFO - 2024-10-03 22:36:46 --> Helper loaded: security_helper
INFO - 2024-10-03 22:36:46 --> Helper loaded: wpu_helper
INFO - 2024-10-03 22:36:46 --> Database Driver Class Initialized
INFO - 2024-10-03 22:36:46 --> Email Class Initialized
DEBUG - 2024-10-03 22:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-03 22:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 22:36:46 --> Helper loaded: form_helper
INFO - 2024-10-03 22:36:46 --> Form Validation Class Initialized
INFO - 2024-10-03 22:36:46 --> Controller Class Initialized
DEBUG - 2024-10-03 22:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-03 22:36:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-03 22:36:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-03 22:36:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-03 22:36:46 --> Final output sent to browser
DEBUG - 2024-10-03 22:36:46 --> Total execution time: 0.2278
