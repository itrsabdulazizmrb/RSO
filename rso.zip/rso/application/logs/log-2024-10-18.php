<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-18 08:48:52 --> Config Class Initialized
INFO - 2024-10-18 08:48:52 --> Hooks Class Initialized
DEBUG - 2024-10-18 08:48:52 --> UTF-8 Support Enabled
INFO - 2024-10-18 08:48:52 --> Utf8 Class Initialized
INFO - 2024-10-18 08:48:52 --> URI Class Initialized
DEBUG - 2024-10-18 08:48:52 --> No URI present. Default controller set.
INFO - 2024-10-18 08:48:52 --> Router Class Initialized
INFO - 2024-10-18 08:48:52 --> Output Class Initialized
INFO - 2024-10-18 08:48:52 --> Security Class Initialized
DEBUG - 2024-10-18 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-18 08:48:52 --> Input Class Initialized
INFO - 2024-10-18 08:48:52 --> Language Class Initialized
INFO - 2024-10-18 08:48:52 --> Loader Class Initialized
INFO - 2024-10-18 08:48:52 --> Helper loaded: url_helper
INFO - 2024-10-18 08:48:52 --> Helper loaded: file_helper
INFO - 2024-10-18 08:48:52 --> Helper loaded: security_helper
INFO - 2024-10-18 08:48:52 --> Helper loaded: wpu_helper
INFO - 2024-10-18 08:48:52 --> Database Driver Class Initialized
INFO - 2024-10-18 08:48:52 --> Email Class Initialized
DEBUG - 2024-10-18 08:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-18 08:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-18 08:48:52 --> Helper loaded: form_helper
INFO - 2024-10-18 08:48:52 --> Form Validation Class Initialized
INFO - 2024-10-18 08:48:52 --> Controller Class Initialized
DEBUG - 2024-10-18 08:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-18 08:48:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-18 08:48:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-18 08:48:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-18 08:48:52 --> Final output sent to browser
DEBUG - 2024-10-18 08:48:52 --> Total execution time: 0.2361
INFO - 2024-10-18 18:21:38 --> Config Class Initialized
INFO - 2024-10-18 18:21:38 --> Hooks Class Initialized
DEBUG - 2024-10-18 18:21:38 --> UTF-8 Support Enabled
INFO - 2024-10-18 18:21:38 --> Utf8 Class Initialized
INFO - 2024-10-18 18:21:38 --> URI Class Initialized
DEBUG - 2024-10-18 18:21:38 --> No URI present. Default controller set.
INFO - 2024-10-18 18:21:38 --> Router Class Initialized
INFO - 2024-10-18 18:21:38 --> Output Class Initialized
INFO - 2024-10-18 18:21:38 --> Security Class Initialized
DEBUG - 2024-10-18 18:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-18 18:21:38 --> Input Class Initialized
INFO - 2024-10-18 18:21:38 --> Language Class Initialized
INFO - 2024-10-18 18:21:38 --> Loader Class Initialized
INFO - 2024-10-18 18:21:38 --> Helper loaded: url_helper
INFO - 2024-10-18 18:21:38 --> Helper loaded: file_helper
INFO - 2024-10-18 18:21:38 --> Helper loaded: security_helper
INFO - 2024-10-18 18:21:38 --> Helper loaded: wpu_helper
INFO - 2024-10-18 18:21:38 --> Database Driver Class Initialized
INFO - 2024-10-18 18:21:38 --> Email Class Initialized
DEBUG - 2024-10-18 18:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-18 18:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-18 18:21:38 --> Helper loaded: form_helper
INFO - 2024-10-18 18:21:38 --> Form Validation Class Initialized
INFO - 2024-10-18 18:21:38 --> Controller Class Initialized
DEBUG - 2024-10-18 18:21:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-18 18:21:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-18 18:21:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-18 18:21:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-18 18:21:38 --> Final output sent to browser
DEBUG - 2024-10-18 18:21:38 --> Total execution time: 0.2405
