<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-19 18:34:27 --> Severity: Compile Error --> Cannot redeclare Admin::deleteuser() C:\xampp\htdocs\simba\application\controllers\Admin.php 198
ERROR - 2024-01-19 18:34:29 --> Severity: Compile Error --> Cannot redeclare Admin::deleteuser() C:\xampp\htdocs\simba\application\controllers\Admin.php 198
ERROR - 2024-01-19 18:34:30 --> Severity: Compile Error --> Cannot redeclare Admin::deleteuser() C:\xampp\htdocs\simba\application\controllers\Admin.php 198
ERROR - 2024-01-19 18:34:32 --> Severity: Compile Error --> Cannot redeclare Admin::deleteuser() C:\xampp\htdocs\simba\application\controllers\Admin.php 198
ERROR - 2024-01-19 18:40:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\admin\supplier.php 42
ERROR - 2024-01-19 18:48:07 --> Query error: Unknown column 'id_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `id_user` IS NULL
ERROR - 2024-01-19 18:49:09 --> Query error: Unknown column 'id_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `id_user` IS NULL
ERROR - 2024-01-19 18:49:11 --> Query error: Unknown column 'id_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `id_user` IS NULL
ERROR - 2024-01-19 18:51:06 --> Query error: Unknown column 'id_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `id_user` IS NULL
ERROR - 2024-01-19 18:52:21 --> Query error: Unknown column 'id_user' in 'where clause' - Invalid query: SELECT *
FROM `tbl_user`
WHERE `id_user` IS NULL
