<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-06 00:00:15 --> Config Class Initialized
INFO - 2024-09-06 00:00:15 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:15 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:15 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:15 --> URI Class Initialized
INFO - 2024-09-06 00:00:15 --> Router Class Initialized
INFO - 2024-09-06 00:00:15 --> Output Class Initialized
INFO - 2024-09-06 00:00:15 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:15 --> Input Class Initialized
INFO - 2024-09-06 00:00:15 --> Language Class Initialized
INFO - 2024-09-06 00:00:15 --> Loader Class Initialized
INFO - 2024-09-06 00:00:15 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:15 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:15 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:15 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:15 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:15 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:15 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:15 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:15 --> Controller Class Initialized
INFO - 2024-09-06 00:00:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:00:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:00:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-06 00:00:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:00:15 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:15 --> Total execution time: 0.1368
INFO - 2024-09-06 00:00:16 --> Config Class Initialized
INFO - 2024-09-06 00:00:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:16 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:16 --> URI Class Initialized
INFO - 2024-09-06 00:00:16 --> Router Class Initialized
INFO - 2024-09-06 00:00:16 --> Output Class Initialized
INFO - 2024-09-06 00:00:16 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:16 --> Input Class Initialized
INFO - 2024-09-06 00:00:16 --> Language Class Initialized
INFO - 2024-09-06 00:00:16 --> Loader Class Initialized
INFO - 2024-09-06 00:00:16 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:16 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:16 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:16 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:16 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:16 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:16 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:16 --> Controller Class Initialized
INFO - 2024-09-06 00:00:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:00:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:00:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:00:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-06 00:00:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:00:16 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:16 --> Total execution time: 0.1148
INFO - 2024-09-06 00:00:17 --> Config Class Initialized
INFO - 2024-09-06 00:00:17 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:17 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:17 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:17 --> URI Class Initialized
INFO - 2024-09-06 00:00:17 --> Router Class Initialized
INFO - 2024-09-06 00:00:17 --> Output Class Initialized
INFO - 2024-09-06 00:00:17 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:17 --> Input Class Initialized
INFO - 2024-09-06 00:00:17 --> Language Class Initialized
INFO - 2024-09-06 00:00:17 --> Loader Class Initialized
INFO - 2024-09-06 00:00:17 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:17 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:17 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:17 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:17 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:17 --> Controller Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:17 --> Config Class Initialized
INFO - 2024-09-06 00:00:17 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:17 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:17 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:17 --> URI Class Initialized
INFO - 2024-09-06 00:00:17 --> Router Class Initialized
INFO - 2024-09-06 00:00:17 --> Output Class Initialized
INFO - 2024-09-06 00:00:17 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:17 --> Input Class Initialized
INFO - 2024-09-06 00:00:17 --> Language Class Initialized
INFO - 2024-09-06 00:00:17 --> Loader Class Initialized
INFO - 2024-09-06 00:00:17 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:17 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:17 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:17 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:17 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:17 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:17 --> Controller Class Initialized
DEBUG - 2024-09-06 00:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-06 00:00:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-06 00:00:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-06 00:00:17 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:17 --> Total execution time: 0.0478
INFO - 2024-09-06 00:00:22 --> Config Class Initialized
INFO - 2024-09-06 00:00:22 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:22 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:22 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:22 --> URI Class Initialized
INFO - 2024-09-06 00:00:22 --> Router Class Initialized
INFO - 2024-09-06 00:00:22 --> Output Class Initialized
INFO - 2024-09-06 00:00:22 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:22 --> Input Class Initialized
INFO - 2024-09-06 00:00:22 --> Language Class Initialized
INFO - 2024-09-06 00:00:22 --> Loader Class Initialized
INFO - 2024-09-06 00:00:22 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:22 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:22 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:22 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:22 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:22 --> Controller Class Initialized
INFO - 2024-09-06 00:00:22 --> Config Class Initialized
INFO - 2024-09-06 00:00:22 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:22 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:22 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:22 --> URI Class Initialized
INFO - 2024-09-06 00:00:22 --> Router Class Initialized
INFO - 2024-09-06 00:00:22 --> Output Class Initialized
INFO - 2024-09-06 00:00:22 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:22 --> Input Class Initialized
INFO - 2024-09-06 00:00:22 --> Language Class Initialized
INFO - 2024-09-06 00:00:22 --> Loader Class Initialized
INFO - 2024-09-06 00:00:22 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:22 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:22 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:22 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:22 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:22 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:22 --> Controller Class Initialized
DEBUG - 2024-09-06 00:00:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-06 00:00:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-06 00:00:22 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-06 00:00:22 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:22 --> Total execution time: 0.0671
INFO - 2024-09-06 00:00:24 --> Config Class Initialized
INFO - 2024-09-06 00:00:24 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:24 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:24 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:24 --> URI Class Initialized
INFO - 2024-09-06 00:00:24 --> Router Class Initialized
INFO - 2024-09-06 00:00:24 --> Output Class Initialized
INFO - 2024-09-06 00:00:24 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:24 --> Input Class Initialized
INFO - 2024-09-06 00:00:24 --> Language Class Initialized
INFO - 2024-09-06 00:00:24 --> Loader Class Initialized
INFO - 2024-09-06 00:00:24 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:24 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:24 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:24 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:24 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:24 --> Controller Class Initialized
DEBUG - 2024-09-06 00:00:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 00:00:24 --> Config Class Initialized
INFO - 2024-09-06 00:00:24 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:24 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:24 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:24 --> URI Class Initialized
INFO - 2024-09-06 00:00:24 --> Router Class Initialized
INFO - 2024-09-06 00:00:24 --> Output Class Initialized
INFO - 2024-09-06 00:00:24 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:24 --> Input Class Initialized
INFO - 2024-09-06 00:00:24 --> Language Class Initialized
INFO - 2024-09-06 00:00:24 --> Loader Class Initialized
INFO - 2024-09-06 00:00:24 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:24 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:24 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:24 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:24 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:24 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:24 --> Controller Class Initialized
INFO - 2024-09-06 00:00:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:00:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:00:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:00:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-06 00:00:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:00:24 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:24 --> Total execution time: 0.1239
INFO - 2024-09-06 00:00:48 --> Config Class Initialized
INFO - 2024-09-06 00:00:48 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:48 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:48 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:48 --> URI Class Initialized
INFO - 2024-09-06 00:00:48 --> Router Class Initialized
INFO - 2024-09-06 00:00:48 --> Output Class Initialized
INFO - 2024-09-06 00:00:48 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:48 --> Input Class Initialized
INFO - 2024-09-06 00:00:48 --> Language Class Initialized
INFO - 2024-09-06 00:00:48 --> Loader Class Initialized
INFO - 2024-09-06 00:00:48 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:48 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:48 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:48 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:48 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:48 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:48 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:48 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:48 --> Controller Class Initialized
INFO - 2024-09-06 00:00:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:00:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:00:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:00:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-06 00:00:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:00:48 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:48 --> Total execution time: 0.1592
INFO - 2024-09-06 00:00:49 --> Config Class Initialized
INFO - 2024-09-06 00:00:49 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:49 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:49 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:49 --> URI Class Initialized
INFO - 2024-09-06 00:00:49 --> Router Class Initialized
INFO - 2024-09-06 00:00:49 --> Output Class Initialized
INFO - 2024-09-06 00:00:49 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:49 --> Input Class Initialized
INFO - 2024-09-06 00:00:49 --> Language Class Initialized
ERROR - 2024-09-06 00:00:49 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\antrol\application\controllers\Report.php 12
INFO - 2024-09-06 00:00:59 --> Config Class Initialized
INFO - 2024-09-06 00:00:59 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:00:59 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:00:59 --> Utf8 Class Initialized
INFO - 2024-09-06 00:00:59 --> URI Class Initialized
INFO - 2024-09-06 00:00:59 --> Router Class Initialized
INFO - 2024-09-06 00:00:59 --> Output Class Initialized
INFO - 2024-09-06 00:00:59 --> Security Class Initialized
DEBUG - 2024-09-06 00:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:00:59 --> Input Class Initialized
INFO - 2024-09-06 00:00:59 --> Language Class Initialized
INFO - 2024-09-06 00:00:59 --> Loader Class Initialized
INFO - 2024-09-06 00:00:59 --> Helper loaded: url_helper
INFO - 2024-09-06 00:00:59 --> Helper loaded: file_helper
INFO - 2024-09-06 00:00:59 --> Helper loaded: security_helper
INFO - 2024-09-06 00:00:59 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:00:59 --> Database Driver Class Initialized
INFO - 2024-09-06 00:00:59 --> Email Class Initialized
DEBUG - 2024-09-06 00:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:00:59 --> Helper loaded: form_helper
INFO - 2024-09-06 00:00:59 --> Form Validation Class Initialized
INFO - 2024-09-06 00:00:59 --> Controller Class Initialized
INFO - 2024-09-06 00:00:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:00:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:00:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:00:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:00:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-06 00:00:59 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:00:59 --> Final output sent to browser
DEBUG - 2024-09-06 00:00:59 --> Total execution time: 0.1297
INFO - 2024-09-06 00:01:05 --> Config Class Initialized
INFO - 2024-09-06 00:01:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:01:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:01:05 --> Utf8 Class Initialized
INFO - 2024-09-06 00:01:05 --> URI Class Initialized
INFO - 2024-09-06 00:01:05 --> Router Class Initialized
INFO - 2024-09-06 00:01:05 --> Output Class Initialized
INFO - 2024-09-06 00:01:05 --> Security Class Initialized
DEBUG - 2024-09-06 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:01:05 --> Input Class Initialized
INFO - 2024-09-06 00:01:05 --> Language Class Initialized
INFO - 2024-09-06 00:01:05 --> Loader Class Initialized
INFO - 2024-09-06 00:01:05 --> Helper loaded: url_helper
INFO - 2024-09-06 00:01:05 --> Helper loaded: file_helper
INFO - 2024-09-06 00:01:05 --> Helper loaded: security_helper
INFO - 2024-09-06 00:01:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:01:05 --> Database Driver Class Initialized
INFO - 2024-09-06 00:01:05 --> Email Class Initialized
DEBUG - 2024-09-06 00:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:01:05 --> Helper loaded: form_helper
INFO - 2024-09-06 00:01:05 --> Form Validation Class Initialized
INFO - 2024-09-06 00:01:05 --> Controller Class Initialized
INFO - 2024-09-06 00:01:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:01:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:01:07 --> Final output sent to browser
DEBUG - 2024-09-06 00:01:07 --> Total execution time: 1.8575
INFO - 2024-09-06 00:01:26 --> Config Class Initialized
INFO - 2024-09-06 00:01:26 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:01:26 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:01:26 --> Utf8 Class Initialized
INFO - 2024-09-06 00:01:26 --> URI Class Initialized
INFO - 2024-09-06 00:01:26 --> Router Class Initialized
INFO - 2024-09-06 00:01:26 --> Output Class Initialized
INFO - 2024-09-06 00:01:26 --> Security Class Initialized
DEBUG - 2024-09-06 00:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:01:26 --> Input Class Initialized
INFO - 2024-09-06 00:01:26 --> Language Class Initialized
INFO - 2024-09-06 00:01:26 --> Loader Class Initialized
INFO - 2024-09-06 00:01:26 --> Helper loaded: url_helper
INFO - 2024-09-06 00:01:26 --> Helper loaded: file_helper
INFO - 2024-09-06 00:01:26 --> Helper loaded: security_helper
INFO - 2024-09-06 00:01:26 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:01:26 --> Database Driver Class Initialized
INFO - 2024-09-06 00:01:26 --> Email Class Initialized
DEBUG - 2024-09-06 00:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:01:26 --> Helper loaded: form_helper
INFO - 2024-09-06 00:01:26 --> Form Validation Class Initialized
INFO - 2024-09-06 00:01:26 --> Controller Class Initialized
INFO - 2024-09-06 00:01:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:01:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:01:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-06 00:01:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-06 00:01:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-06 00:01:26 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-06 00:01:26 --> Final output sent to browser
DEBUG - 2024-09-06 00:01:26 --> Total execution time: 0.1387
INFO - 2024-09-06 00:01:27 --> Config Class Initialized
INFO - 2024-09-06 00:01:27 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:01:27 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:01:27 --> Utf8 Class Initialized
INFO - 2024-09-06 00:01:27 --> URI Class Initialized
INFO - 2024-09-06 00:01:27 --> Router Class Initialized
INFO - 2024-09-06 00:01:27 --> Output Class Initialized
INFO - 2024-09-06 00:01:27 --> Security Class Initialized
DEBUG - 2024-09-06 00:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:01:27 --> Input Class Initialized
INFO - 2024-09-06 00:01:27 --> Language Class Initialized
INFO - 2024-09-06 00:01:27 --> Loader Class Initialized
INFO - 2024-09-06 00:01:27 --> Helper loaded: url_helper
INFO - 2024-09-06 00:01:27 --> Helper loaded: file_helper
INFO - 2024-09-06 00:01:27 --> Helper loaded: security_helper
INFO - 2024-09-06 00:01:27 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:01:27 --> Database Driver Class Initialized
INFO - 2024-09-06 00:01:27 --> Email Class Initialized
DEBUG - 2024-09-06 00:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:01:27 --> Helper loaded: form_helper
INFO - 2024-09-06 00:01:27 --> Form Validation Class Initialized
INFO - 2024-09-06 00:01:27 --> Controller Class Initialized
INFO - 2024-09-06 00:01:27 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 00:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:01:28 --> Final output sent to browser
DEBUG - 2024-09-06 00:01:28 --> Total execution time: 0.5540
INFO - 2024-09-06 00:11:46 --> Config Class Initialized
INFO - 2024-09-06 00:11:46 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:11:46 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:11:46 --> Utf8 Class Initialized
INFO - 2024-09-06 00:11:46 --> URI Class Initialized
DEBUG - 2024-09-06 00:11:46 --> No URI present. Default controller set.
INFO - 2024-09-06 00:11:46 --> Router Class Initialized
INFO - 2024-09-06 00:11:46 --> Output Class Initialized
INFO - 2024-09-06 00:11:46 --> Security Class Initialized
DEBUG - 2024-09-06 00:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:11:46 --> Input Class Initialized
INFO - 2024-09-06 00:11:46 --> Language Class Initialized
INFO - 2024-09-06 00:11:46 --> Loader Class Initialized
INFO - 2024-09-06 00:11:46 --> Helper loaded: url_helper
INFO - 2024-09-06 00:11:46 --> Helper loaded: file_helper
INFO - 2024-09-06 00:11:46 --> Helper loaded: security_helper
INFO - 2024-09-06 00:11:46 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:11:46 --> Database Driver Class Initialized
INFO - 2024-09-06 00:11:46 --> Email Class Initialized
DEBUG - 2024-09-06 00:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:11:46 --> Helper loaded: form_helper
INFO - 2024-09-06 00:11:46 --> Form Validation Class Initialized
INFO - 2024-09-06 00:11:46 --> Controller Class Initialized
DEBUG - 2024-09-06 00:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 00:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 00:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 00:11:46 --> Final output sent to browser
DEBUG - 2024-09-06 00:11:46 --> Total execution time: 0.2223
INFO - 2024-09-06 00:42:37 --> Config Class Initialized
INFO - 2024-09-06 00:42:37 --> Hooks Class Initialized
DEBUG - 2024-09-06 00:42:37 --> UTF-8 Support Enabled
INFO - 2024-09-06 00:42:37 --> Utf8 Class Initialized
INFO - 2024-09-06 00:42:37 --> URI Class Initialized
DEBUG - 2024-09-06 00:42:37 --> No URI present. Default controller set.
INFO - 2024-09-06 00:42:37 --> Router Class Initialized
INFO - 2024-09-06 00:42:37 --> Output Class Initialized
INFO - 2024-09-06 00:42:37 --> Security Class Initialized
DEBUG - 2024-09-06 00:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 00:42:37 --> Input Class Initialized
INFO - 2024-09-06 00:42:37 --> Language Class Initialized
INFO - 2024-09-06 00:42:37 --> Loader Class Initialized
INFO - 2024-09-06 00:42:37 --> Helper loaded: url_helper
INFO - 2024-09-06 00:42:37 --> Helper loaded: file_helper
INFO - 2024-09-06 00:42:37 --> Helper loaded: security_helper
INFO - 2024-09-06 00:42:37 --> Helper loaded: wpu_helper
INFO - 2024-09-06 00:42:37 --> Database Driver Class Initialized
INFO - 2024-09-06 00:42:37 --> Email Class Initialized
DEBUG - 2024-09-06 00:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 00:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 00:42:37 --> Helper loaded: form_helper
INFO - 2024-09-06 00:42:37 --> Form Validation Class Initialized
INFO - 2024-09-06 00:42:37 --> Controller Class Initialized
DEBUG - 2024-09-06 00:42:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 00:42:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 00:42:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 00:42:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 00:42:37 --> Final output sent to browser
DEBUG - 2024-09-06 00:42:37 --> Total execution time: 0.2318
INFO - 2024-09-06 01:12:15 --> Config Class Initialized
INFO - 2024-09-06 01:12:15 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:12:15 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:12:15 --> Utf8 Class Initialized
INFO - 2024-09-06 01:12:15 --> URI Class Initialized
DEBUG - 2024-09-06 01:12:15 --> No URI present. Default controller set.
INFO - 2024-09-06 01:12:15 --> Router Class Initialized
INFO - 2024-09-06 01:12:15 --> Output Class Initialized
INFO - 2024-09-06 01:12:15 --> Security Class Initialized
DEBUG - 2024-09-06 01:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:12:15 --> Input Class Initialized
INFO - 2024-09-06 01:12:15 --> Language Class Initialized
INFO - 2024-09-06 01:12:15 --> Loader Class Initialized
INFO - 2024-09-06 01:12:15 --> Helper loaded: url_helper
INFO - 2024-09-06 01:12:15 --> Helper loaded: file_helper
INFO - 2024-09-06 01:12:15 --> Helper loaded: security_helper
INFO - 2024-09-06 01:12:15 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:12:15 --> Database Driver Class Initialized
INFO - 2024-09-06 01:12:15 --> Email Class Initialized
DEBUG - 2024-09-06 01:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:12:15 --> Helper loaded: form_helper
INFO - 2024-09-06 01:12:15 --> Form Validation Class Initialized
INFO - 2024-09-06 01:12:15 --> Controller Class Initialized
DEBUG - 2024-09-06 01:12:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:12:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:12:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:12:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:12:15 --> Final output sent to browser
DEBUG - 2024-09-06 01:12:15 --> Total execution time: 0.2174
INFO - 2024-09-06 01:19:05 --> Config Class Initialized
INFO - 2024-09-06 01:19:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:05 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:05 --> URI Class Initialized
INFO - 2024-09-06 01:19:05 --> Router Class Initialized
INFO - 2024-09-06 01:19:05 --> Output Class Initialized
INFO - 2024-09-06 01:19:05 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:05 --> Input Class Initialized
INFO - 2024-09-06 01:19:05 --> Language Class Initialized
INFO - 2024-09-06 01:19:05 --> Loader Class Initialized
INFO - 2024-09-06 01:19:05 --> Helper loaded: url_helper
INFO - 2024-09-06 01:19:05 --> Helper loaded: file_helper
INFO - 2024-09-06 01:19:05 --> Helper loaded: security_helper
INFO - 2024-09-06 01:19:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:19:05 --> Database Driver Class Initialized
INFO - 2024-09-06 01:19:05 --> Email Class Initialized
DEBUG - 2024-09-06 01:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:19:05 --> Helper loaded: form_helper
INFO - 2024-09-06 01:19:05 --> Form Validation Class Initialized
INFO - 2024-09-06 01:19:05 --> Controller Class Initialized
INFO - 2024-09-06 01:19:06 --> Config Class Initialized
INFO - 2024-09-06 01:19:06 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:06 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:06 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:06 --> URI Class Initialized
INFO - 2024-09-06 01:19:06 --> Router Class Initialized
INFO - 2024-09-06 01:19:06 --> Output Class Initialized
INFO - 2024-09-06 01:19:06 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:06 --> Input Class Initialized
INFO - 2024-09-06 01:19:06 --> Language Class Initialized
INFO - 2024-09-06 01:19:06 --> Loader Class Initialized
INFO - 2024-09-06 01:19:06 --> Helper loaded: url_helper
INFO - 2024-09-06 01:19:06 --> Helper loaded: file_helper
INFO - 2024-09-06 01:19:06 --> Helper loaded: security_helper
INFO - 2024-09-06 01:19:06 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:19:06 --> Database Driver Class Initialized
INFO - 2024-09-06 01:19:06 --> Email Class Initialized
DEBUG - 2024-09-06 01:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:19:06 --> Helper loaded: form_helper
INFO - 2024-09-06 01:19:06 --> Form Validation Class Initialized
INFO - 2024-09-06 01:19:06 --> Controller Class Initialized
DEBUG - 2024-09-06 01:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:19:06 --> Final output sent to browser
DEBUG - 2024-09-06 01:19:06 --> Total execution time: 0.2167
INFO - 2024-09-06 01:19:08 --> Config Class Initialized
INFO - 2024-09-06 01:19:08 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:08 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:08 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:08 --> URI Class Initialized
INFO - 2024-09-06 01:19:08 --> Router Class Initialized
INFO - 2024-09-06 01:19:08 --> Output Class Initialized
INFO - 2024-09-06 01:19:08 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:08 --> Input Class Initialized
INFO - 2024-09-06 01:19:08 --> Language Class Initialized
INFO - 2024-09-06 01:19:08 --> Loader Class Initialized
INFO - 2024-09-06 01:19:08 --> Helper loaded: url_helper
INFO - 2024-09-06 01:19:08 --> Helper loaded: file_helper
INFO - 2024-09-06 01:19:08 --> Helper loaded: security_helper
INFO - 2024-09-06 01:19:08 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:19:08 --> Database Driver Class Initialized
INFO - 2024-09-06 01:19:08 --> Email Class Initialized
DEBUG - 2024-09-06 01:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:19:08 --> Helper loaded: form_helper
INFO - 2024-09-06 01:19:08 --> Form Validation Class Initialized
INFO - 2024-09-06 01:19:08 --> Controller Class Initialized
DEBUG - 2024-09-06 01:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:19:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 01:19:09 --> Config Class Initialized
INFO - 2024-09-06 01:19:09 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:09 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:09 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:09 --> URI Class Initialized
INFO - 2024-09-06 01:19:09 --> Router Class Initialized
INFO - 2024-09-06 01:19:09 --> Output Class Initialized
INFO - 2024-09-06 01:19:09 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:09 --> Input Class Initialized
INFO - 2024-09-06 01:19:09 --> Language Class Initialized
INFO - 2024-09-06 01:19:09 --> Loader Class Initialized
INFO - 2024-09-06 01:19:09 --> Helper loaded: url_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: file_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: security_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:19:09 --> Database Driver Class Initialized
INFO - 2024-09-06 01:19:09 --> Email Class Initialized
DEBUG - 2024-09-06 01:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:19:09 --> Helper loaded: form_helper
INFO - 2024-09-06 01:19:09 --> Form Validation Class Initialized
INFO - 2024-09-06 01:19:09 --> Controller Class Initialized
INFO - 2024-09-06 01:19:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 01:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:19:09 --> Config Class Initialized
INFO - 2024-09-06 01:19:09 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:09 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:09 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:09 --> URI Class Initialized
INFO - 2024-09-06 01:19:09 --> Router Class Initialized
INFO - 2024-09-06 01:19:09 --> Output Class Initialized
INFO - 2024-09-06 01:19:09 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:09 --> Input Class Initialized
INFO - 2024-09-06 01:19:09 --> Language Class Initialized
INFO - 2024-09-06 01:19:09 --> Loader Class Initialized
INFO - 2024-09-06 01:19:09 --> Helper loaded: url_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: file_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: security_helper
INFO - 2024-09-06 01:19:09 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:19:09 --> Database Driver Class Initialized
INFO - 2024-09-06 01:19:09 --> Email Class Initialized
DEBUG - 2024-09-06 01:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 01:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 01:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 01:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 01:19:09 --> Final output sent to browser
DEBUG - 2024-09-06 01:19:09 --> Total execution time: 0.5916
INFO - 2024-09-06 01:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:19:09 --> Helper loaded: form_helper
INFO - 2024-09-06 01:19:09 --> Form Validation Class Initialized
INFO - 2024-09-06 01:19:09 --> Controller Class Initialized
DEBUG - 2024-09-06 01:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:19:10 --> Config Class Initialized
INFO - 2024-09-06 01:19:10 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:10 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:10 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:10 --> URI Class Initialized
INFO - 2024-09-06 01:19:10 --> Router Class Initialized
INFO - 2024-09-06 01:19:10 --> Output Class Initialized
INFO - 2024-09-06 01:19:10 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:10 --> Input Class Initialized
INFO - 2024-09-06 01:19:10 --> Language Class Initialized
ERROR - 2024-09-06 01:19:10 --> 404 Page Not Found: User/index
INFO - 2024-09-06 01:19:16 --> Config Class Initialized
INFO - 2024-09-06 01:19:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:19:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:19:16 --> Utf8 Class Initialized
INFO - 2024-09-06 01:19:16 --> URI Class Initialized
INFO - 2024-09-06 01:19:16 --> Router Class Initialized
INFO - 2024-09-06 01:19:16 --> Output Class Initialized
INFO - 2024-09-06 01:19:16 --> Security Class Initialized
DEBUG - 2024-09-06 01:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:19:16 --> Input Class Initialized
INFO - 2024-09-06 01:19:16 --> Language Class Initialized
ERROR - 2024-09-06 01:19:16 --> 404 Page Not Found: User/index
INFO - 2024-09-06 01:25:19 --> Config Class Initialized
INFO - 2024-09-06 01:25:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:19 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:19 --> URI Class Initialized
DEBUG - 2024-09-06 01:25:19 --> No URI present. Default controller set.
INFO - 2024-09-06 01:25:19 --> Router Class Initialized
INFO - 2024-09-06 01:25:19 --> Output Class Initialized
INFO - 2024-09-06 01:25:19 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:19 --> Input Class Initialized
INFO - 2024-09-06 01:25:19 --> Language Class Initialized
INFO - 2024-09-06 01:25:19 --> Loader Class Initialized
INFO - 2024-09-06 01:25:19 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:19 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:19 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:19 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:19 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:19 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:19 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:19 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:25:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:25:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:25:19 --> Final output sent to browser
DEBUG - 2024-09-06 01:25:19 --> Total execution time: 0.2194
INFO - 2024-09-06 01:25:21 --> Config Class Initialized
INFO - 2024-09-06 01:25:21 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:21 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:21 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:21 --> URI Class Initialized
INFO - 2024-09-06 01:25:21 --> Router Class Initialized
INFO - 2024-09-06 01:25:21 --> Output Class Initialized
INFO - 2024-09-06 01:25:21 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:21 --> Input Class Initialized
INFO - 2024-09-06 01:25:21 --> Language Class Initialized
INFO - 2024-09-06 01:25:21 --> Loader Class Initialized
INFO - 2024-09-06 01:25:21 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:21 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:21 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:21 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:21 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:22 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:22 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:22 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:22 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 01:25:22 --> Config Class Initialized
INFO - 2024-09-06 01:25:22 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:22 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:22 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:22 --> URI Class Initialized
INFO - 2024-09-06 01:25:22 --> Router Class Initialized
INFO - 2024-09-06 01:25:22 --> Output Class Initialized
INFO - 2024-09-06 01:25:22 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:22 --> Input Class Initialized
INFO - 2024-09-06 01:25:22 --> Language Class Initialized
INFO - 2024-09-06 01:25:22 --> Loader Class Initialized
INFO - 2024-09-06 01:25:22 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:22 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:22 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:22 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:22 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:22 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:22 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:22 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:22 --> Controller Class Initialized
INFO - 2024-09-06 01:25:22 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 01:25:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 01:25:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 01:25:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 01:25:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 01:25:22 --> Final output sent to browser
DEBUG - 2024-09-06 01:25:22 --> Total execution time: 0.5502
INFO - 2024-09-06 01:25:26 --> Config Class Initialized
INFO - 2024-09-06 01:25:26 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:26 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:26 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:26 --> URI Class Initialized
INFO - 2024-09-06 01:25:26 --> Router Class Initialized
INFO - 2024-09-06 01:25:26 --> Output Class Initialized
INFO - 2024-09-06 01:25:26 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:26 --> Input Class Initialized
INFO - 2024-09-06 01:25:26 --> Language Class Initialized
INFO - 2024-09-06 01:25:26 --> Loader Class Initialized
INFO - 2024-09-06 01:25:26 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:26 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:26 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:26 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:26 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:26 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:26 --> Config Class Initialized
INFO - 2024-09-06 01:25:26 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:26 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:26 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:26 --> URI Class Initialized
INFO - 2024-09-06 01:25:26 --> Router Class Initialized
INFO - 2024-09-06 01:25:26 --> Output Class Initialized
INFO - 2024-09-06 01:25:26 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:26 --> Input Class Initialized
INFO - 2024-09-06 01:25:26 --> Language Class Initialized
INFO - 2024-09-06 01:25:26 --> Loader Class Initialized
INFO - 2024-09-06 01:25:26 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:26 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:26 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:26 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:26 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:26 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:26 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:25:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:25:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:25:26 --> Final output sent to browser
DEBUG - 2024-09-06 01:25:26 --> Total execution time: 0.2101
INFO - 2024-09-06 01:25:29 --> Config Class Initialized
INFO - 2024-09-06 01:25:29 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:29 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:29 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:29 --> URI Class Initialized
INFO - 2024-09-06 01:25:29 --> Router Class Initialized
INFO - 2024-09-06 01:25:29 --> Output Class Initialized
INFO - 2024-09-06 01:25:29 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:29 --> Input Class Initialized
INFO - 2024-09-06 01:25:29 --> Language Class Initialized
INFO - 2024-09-06 01:25:29 --> Loader Class Initialized
INFO - 2024-09-06 01:25:29 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:29 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:29 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:29 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:29 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:29 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 01:25:29 --> Config Class Initialized
INFO - 2024-09-06 01:25:29 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:29 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:29 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:29 --> URI Class Initialized
INFO - 2024-09-06 01:25:29 --> Router Class Initialized
INFO - 2024-09-06 01:25:29 --> Output Class Initialized
INFO - 2024-09-06 01:25:29 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:29 --> Input Class Initialized
INFO - 2024-09-06 01:25:29 --> Language Class Initialized
INFO - 2024-09-06 01:25:29 --> Loader Class Initialized
INFO - 2024-09-06 01:25:29 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:29 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:29 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:30 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:30 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:30 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:30 --> Controller Class Initialized
INFO - 2024-09-06 01:25:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 01:25:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 01:25:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 01:25:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 01:25:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 01:25:30 --> Final output sent to browser
DEBUG - 2024-09-06 01:25:30 --> Total execution time: 0.5270
INFO - 2024-09-06 01:25:34 --> Config Class Initialized
INFO - 2024-09-06 01:25:34 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:34 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:34 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:34 --> URI Class Initialized
INFO - 2024-09-06 01:25:34 --> Router Class Initialized
INFO - 2024-09-06 01:25:34 --> Output Class Initialized
INFO - 2024-09-06 01:25:34 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:34 --> Input Class Initialized
INFO - 2024-09-06 01:25:34 --> Language Class Initialized
INFO - 2024-09-06 01:25:34 --> Loader Class Initialized
INFO - 2024-09-06 01:25:34 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:34 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:34 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:34 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:34 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:34 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:34 --> Config Class Initialized
INFO - 2024-09-06 01:25:34 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:25:34 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:25:34 --> Utf8 Class Initialized
INFO - 2024-09-06 01:25:34 --> URI Class Initialized
INFO - 2024-09-06 01:25:34 --> Router Class Initialized
INFO - 2024-09-06 01:25:34 --> Output Class Initialized
INFO - 2024-09-06 01:25:34 --> Security Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:25:34 --> Input Class Initialized
INFO - 2024-09-06 01:25:34 --> Language Class Initialized
INFO - 2024-09-06 01:25:34 --> Loader Class Initialized
INFO - 2024-09-06 01:25:34 --> Helper loaded: url_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: file_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: security_helper
INFO - 2024-09-06 01:25:34 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:25:34 --> Database Driver Class Initialized
INFO - 2024-09-06 01:25:34 --> Email Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:25:34 --> Helper loaded: form_helper
INFO - 2024-09-06 01:25:34 --> Form Validation Class Initialized
INFO - 2024-09-06 01:25:34 --> Controller Class Initialized
DEBUG - 2024-09-06 01:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:25:34 --> Final output sent to browser
DEBUG - 2024-09-06 01:25:34 --> Total execution time: 0.2114
INFO - 2024-09-06 01:34:10 --> Config Class Initialized
INFO - 2024-09-06 01:34:10 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:34:10 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:34:10 --> Utf8 Class Initialized
INFO - 2024-09-06 01:34:10 --> URI Class Initialized
INFO - 2024-09-06 01:34:10 --> Router Class Initialized
INFO - 2024-09-06 01:34:10 --> Output Class Initialized
INFO - 2024-09-06 01:34:10 --> Security Class Initialized
DEBUG - 2024-09-06 01:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:34:10 --> Input Class Initialized
INFO - 2024-09-06 01:34:10 --> Language Class Initialized
ERROR - 2024-09-06 01:34:10 --> 404 Page Not Found: User/index
INFO - 2024-09-06 01:34:16 --> Config Class Initialized
INFO - 2024-09-06 01:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:34:16 --> Utf8 Class Initialized
INFO - 2024-09-06 01:34:16 --> URI Class Initialized
INFO - 2024-09-06 01:34:16 --> Router Class Initialized
INFO - 2024-09-06 01:34:16 --> Output Class Initialized
INFO - 2024-09-06 01:34:16 --> Security Class Initialized
DEBUG - 2024-09-06 01:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:34:16 --> Input Class Initialized
INFO - 2024-09-06 01:34:16 --> Language Class Initialized
INFO - 2024-09-06 01:34:16 --> Loader Class Initialized
INFO - 2024-09-06 01:34:16 --> Helper loaded: url_helper
INFO - 2024-09-06 01:34:16 --> Helper loaded: file_helper
INFO - 2024-09-06 01:34:16 --> Helper loaded: security_helper
INFO - 2024-09-06 01:34:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:34:16 --> Database Driver Class Initialized
INFO - 2024-09-06 01:34:16 --> Email Class Initialized
DEBUG - 2024-09-06 01:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:34:16 --> Helper loaded: form_helper
INFO - 2024-09-06 01:34:16 --> Form Validation Class Initialized
INFO - 2024-09-06 01:34:16 --> Controller Class Initialized
DEBUG - 2024-09-06 01:34:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:34:17 --> Config Class Initialized
INFO - 2024-09-06 01:34:17 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:34:17 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:34:17 --> Utf8 Class Initialized
INFO - 2024-09-06 01:34:17 --> URI Class Initialized
INFO - 2024-09-06 01:34:17 --> Router Class Initialized
INFO - 2024-09-06 01:34:17 --> Output Class Initialized
INFO - 2024-09-06 01:34:17 --> Security Class Initialized
DEBUG - 2024-09-06 01:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:34:17 --> Input Class Initialized
INFO - 2024-09-06 01:34:17 --> Language Class Initialized
INFO - 2024-09-06 01:34:17 --> Loader Class Initialized
INFO - 2024-09-06 01:34:17 --> Helper loaded: url_helper
INFO - 2024-09-06 01:34:17 --> Helper loaded: file_helper
INFO - 2024-09-06 01:34:17 --> Helper loaded: security_helper
INFO - 2024-09-06 01:34:17 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:34:17 --> Database Driver Class Initialized
INFO - 2024-09-06 01:34:17 --> Email Class Initialized
DEBUG - 2024-09-06 01:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:34:17 --> Helper loaded: form_helper
INFO - 2024-09-06 01:34:17 --> Form Validation Class Initialized
INFO - 2024-09-06 01:34:17 --> Controller Class Initialized
DEBUG - 2024-09-06 01:34:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:34:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:34:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:34:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:34:17 --> Final output sent to browser
DEBUG - 2024-09-06 01:34:17 --> Total execution time: 0.2211
INFO - 2024-09-06 01:34:19 --> Config Class Initialized
INFO - 2024-09-06 01:34:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:34:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:34:19 --> Utf8 Class Initialized
INFO - 2024-09-06 01:34:19 --> URI Class Initialized
INFO - 2024-09-06 01:34:19 --> Router Class Initialized
INFO - 2024-09-06 01:34:19 --> Output Class Initialized
INFO - 2024-09-06 01:34:19 --> Security Class Initialized
DEBUG - 2024-09-06 01:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:34:19 --> Input Class Initialized
INFO - 2024-09-06 01:34:19 --> Language Class Initialized
INFO - 2024-09-06 01:34:19 --> Loader Class Initialized
INFO - 2024-09-06 01:34:19 --> Helper loaded: url_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: file_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: security_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:34:19 --> Database Driver Class Initialized
INFO - 2024-09-06 01:34:19 --> Email Class Initialized
DEBUG - 2024-09-06 01:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:34:19 --> Helper loaded: form_helper
INFO - 2024-09-06 01:34:19 --> Form Validation Class Initialized
INFO - 2024-09-06 01:34:19 --> Controller Class Initialized
DEBUG - 2024-09-06 01:34:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:34:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 01:34:19 --> Config Class Initialized
INFO - 2024-09-06 01:34:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:34:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:34:19 --> Utf8 Class Initialized
INFO - 2024-09-06 01:34:19 --> URI Class Initialized
INFO - 2024-09-06 01:34:19 --> Router Class Initialized
INFO - 2024-09-06 01:34:19 --> Output Class Initialized
INFO - 2024-09-06 01:34:19 --> Security Class Initialized
DEBUG - 2024-09-06 01:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:34:19 --> Input Class Initialized
INFO - 2024-09-06 01:34:19 --> Language Class Initialized
INFO - 2024-09-06 01:34:19 --> Loader Class Initialized
INFO - 2024-09-06 01:34:19 --> Helper loaded: url_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: file_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: security_helper
INFO - 2024-09-06 01:34:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:34:19 --> Database Driver Class Initialized
INFO - 2024-09-06 01:34:20 --> Email Class Initialized
DEBUG - 2024-09-06 01:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:34:20 --> Helper loaded: form_helper
INFO - 2024-09-06 01:34:20 --> Form Validation Class Initialized
INFO - 2024-09-06 01:34:20 --> Controller Class Initialized
INFO - 2024-09-06 01:34:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 01:34:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:34:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 01:34:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 01:34:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 01:34:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 01:34:20 --> Final output sent to browser
DEBUG - 2024-09-06 01:34:20 --> Total execution time: 0.5486
INFO - 2024-09-06 01:43:33 --> Config Class Initialized
INFO - 2024-09-06 01:43:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 01:43:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 01:43:33 --> Utf8 Class Initialized
INFO - 2024-09-06 01:43:33 --> URI Class Initialized
DEBUG - 2024-09-06 01:43:33 --> No URI present. Default controller set.
INFO - 2024-09-06 01:43:33 --> Router Class Initialized
INFO - 2024-09-06 01:43:33 --> Output Class Initialized
INFO - 2024-09-06 01:43:33 --> Security Class Initialized
DEBUG - 2024-09-06 01:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 01:43:33 --> Input Class Initialized
INFO - 2024-09-06 01:43:33 --> Language Class Initialized
INFO - 2024-09-06 01:43:33 --> Loader Class Initialized
INFO - 2024-09-06 01:43:33 --> Helper loaded: url_helper
INFO - 2024-09-06 01:43:33 --> Helper loaded: file_helper
INFO - 2024-09-06 01:43:33 --> Helper loaded: security_helper
INFO - 2024-09-06 01:43:33 --> Helper loaded: wpu_helper
INFO - 2024-09-06 01:43:33 --> Database Driver Class Initialized
INFO - 2024-09-06 01:43:33 --> Email Class Initialized
DEBUG - 2024-09-06 01:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 01:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 01:43:33 --> Helper loaded: form_helper
INFO - 2024-09-06 01:43:33 --> Form Validation Class Initialized
INFO - 2024-09-06 01:43:33 --> Controller Class Initialized
DEBUG - 2024-09-06 01:43:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 01:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 01:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 01:43:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 01:43:33 --> Final output sent to browser
DEBUG - 2024-09-06 01:43:33 --> Total execution time: 0.2240
INFO - 2024-09-06 02:13:32 --> Config Class Initialized
INFO - 2024-09-06 02:13:32 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:13:32 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:13:32 --> Utf8 Class Initialized
INFO - 2024-09-06 02:13:32 --> URI Class Initialized
DEBUG - 2024-09-06 02:13:32 --> No URI present. Default controller set.
INFO - 2024-09-06 02:13:32 --> Router Class Initialized
INFO - 2024-09-06 02:13:32 --> Output Class Initialized
INFO - 2024-09-06 02:13:32 --> Security Class Initialized
DEBUG - 2024-09-06 02:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:13:32 --> Input Class Initialized
INFO - 2024-09-06 02:13:32 --> Language Class Initialized
INFO - 2024-09-06 02:13:32 --> Loader Class Initialized
INFO - 2024-09-06 02:13:32 --> Helper loaded: url_helper
INFO - 2024-09-06 02:13:32 --> Helper loaded: file_helper
INFO - 2024-09-06 02:13:32 --> Helper loaded: security_helper
INFO - 2024-09-06 02:13:32 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:13:32 --> Database Driver Class Initialized
INFO - 2024-09-06 02:13:32 --> Email Class Initialized
DEBUG - 2024-09-06 02:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:13:32 --> Helper loaded: form_helper
INFO - 2024-09-06 02:13:32 --> Form Validation Class Initialized
INFO - 2024-09-06 02:13:32 --> Controller Class Initialized
DEBUG - 2024-09-06 02:13:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:13:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 02:13:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 02:13:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 02:13:32 --> Final output sent to browser
DEBUG - 2024-09-06 02:13:32 --> Total execution time: 0.2140
INFO - 2024-09-06 02:13:49 --> Config Class Initialized
INFO - 2024-09-06 02:13:49 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:13:49 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:13:49 --> Utf8 Class Initialized
INFO - 2024-09-06 02:13:49 --> URI Class Initialized
DEBUG - 2024-09-06 02:13:49 --> No URI present. Default controller set.
INFO - 2024-09-06 02:13:49 --> Router Class Initialized
INFO - 2024-09-06 02:13:49 --> Output Class Initialized
INFO - 2024-09-06 02:13:49 --> Security Class Initialized
DEBUG - 2024-09-06 02:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:13:49 --> Input Class Initialized
INFO - 2024-09-06 02:13:49 --> Language Class Initialized
INFO - 2024-09-06 02:13:49 --> Loader Class Initialized
INFO - 2024-09-06 02:13:49 --> Helper loaded: url_helper
INFO - 2024-09-06 02:13:49 --> Helper loaded: file_helper
INFO - 2024-09-06 02:13:49 --> Helper loaded: security_helper
INFO - 2024-09-06 02:13:49 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:13:49 --> Database Driver Class Initialized
INFO - 2024-09-06 02:13:50 --> Email Class Initialized
DEBUG - 2024-09-06 02:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:13:50 --> Helper loaded: form_helper
INFO - 2024-09-06 02:13:50 --> Form Validation Class Initialized
INFO - 2024-09-06 02:13:50 --> Controller Class Initialized
DEBUG - 2024-09-06 02:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:13:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 02:13:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 02:13:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 02:13:50 --> Final output sent to browser
DEBUG - 2024-09-06 02:13:50 --> Total execution time: 0.2289
INFO - 2024-09-06 02:17:59 --> Config Class Initialized
INFO - 2024-09-06 02:17:59 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:17:59 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:17:59 --> Utf8 Class Initialized
INFO - 2024-09-06 02:17:59 --> URI Class Initialized
INFO - 2024-09-06 02:17:59 --> Router Class Initialized
INFO - 2024-09-06 02:17:59 --> Output Class Initialized
INFO - 2024-09-06 02:17:59 --> Security Class Initialized
DEBUG - 2024-09-06 02:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:17:59 --> Input Class Initialized
INFO - 2024-09-06 02:17:59 --> Language Class Initialized
INFO - 2024-09-06 02:17:59 --> Loader Class Initialized
INFO - 2024-09-06 02:17:59 --> Helper loaded: url_helper
INFO - 2024-09-06 02:17:59 --> Helper loaded: file_helper
INFO - 2024-09-06 02:17:59 --> Helper loaded: security_helper
INFO - 2024-09-06 02:17:59 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:17:59 --> Database Driver Class Initialized
INFO - 2024-09-06 02:17:59 --> Email Class Initialized
DEBUG - 2024-09-06 02:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:17:59 --> Helper loaded: form_helper
INFO - 2024-09-06 02:17:59 --> Form Validation Class Initialized
INFO - 2024-09-06 02:17:59 --> Controller Class Initialized
INFO - 2024-09-06 02:17:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:17:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:18:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:18:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:18:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:18:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:18:00 --> Final output sent to browser
DEBUG - 2024-09-06 02:18:00 --> Total execution time: 0.6376
INFO - 2024-09-06 02:18:28 --> Config Class Initialized
INFO - 2024-09-06 02:18:28 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:18:28 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:18:28 --> Utf8 Class Initialized
INFO - 2024-09-06 02:18:28 --> URI Class Initialized
INFO - 2024-09-06 02:18:28 --> Router Class Initialized
INFO - 2024-09-06 02:18:28 --> Output Class Initialized
INFO - 2024-09-06 02:18:28 --> Security Class Initialized
DEBUG - 2024-09-06 02:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:18:28 --> Input Class Initialized
INFO - 2024-09-06 02:18:28 --> Language Class Initialized
INFO - 2024-09-06 02:18:28 --> Loader Class Initialized
INFO - 2024-09-06 02:18:28 --> Helper loaded: url_helper
INFO - 2024-09-06 02:18:28 --> Helper loaded: file_helper
INFO - 2024-09-06 02:18:28 --> Helper loaded: security_helper
INFO - 2024-09-06 02:18:28 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:18:28 --> Database Driver Class Initialized
INFO - 2024-09-06 02:18:28 --> Email Class Initialized
DEBUG - 2024-09-06 02:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:18:28 --> Helper loaded: form_helper
INFO - 2024-09-06 02:18:28 --> Form Validation Class Initialized
INFO - 2024-09-06 02:18:28 --> Controller Class Initialized
INFO - 2024-09-06 02:18:28 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:18:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:18:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:18:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:18:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:18:29 --> Final output sent to browser
DEBUG - 2024-09-06 02:18:29 --> Total execution time: 0.6832
INFO - 2024-09-06 02:18:43 --> Config Class Initialized
INFO - 2024-09-06 02:18:43 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:18:43 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:18:43 --> Utf8 Class Initialized
INFO - 2024-09-06 02:18:43 --> URI Class Initialized
INFO - 2024-09-06 02:18:43 --> Router Class Initialized
INFO - 2024-09-06 02:18:43 --> Output Class Initialized
INFO - 2024-09-06 02:18:43 --> Security Class Initialized
DEBUG - 2024-09-06 02:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:18:43 --> Input Class Initialized
INFO - 2024-09-06 02:18:43 --> Language Class Initialized
INFO - 2024-09-06 02:18:43 --> Loader Class Initialized
INFO - 2024-09-06 02:18:43 --> Helper loaded: url_helper
INFO - 2024-09-06 02:18:43 --> Helper loaded: file_helper
INFO - 2024-09-06 02:18:43 --> Helper loaded: security_helper
INFO - 2024-09-06 02:18:43 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:18:43 --> Database Driver Class Initialized
INFO - 2024-09-06 02:18:44 --> Email Class Initialized
DEBUG - 2024-09-06 02:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:18:44 --> Helper loaded: form_helper
INFO - 2024-09-06 02:18:44 --> Form Validation Class Initialized
INFO - 2024-09-06 02:18:44 --> Controller Class Initialized
INFO - 2024-09-06 02:18:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:18:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:18:44 --> Final output sent to browser
DEBUG - 2024-09-06 02:18:44 --> Total execution time: 0.6061
INFO - 2024-09-06 02:20:40 --> Config Class Initialized
INFO - 2024-09-06 02:20:40 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:20:40 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:20:40 --> Utf8 Class Initialized
INFO - 2024-09-06 02:20:40 --> URI Class Initialized
INFO - 2024-09-06 02:20:40 --> Router Class Initialized
INFO - 2024-09-06 02:20:40 --> Output Class Initialized
INFO - 2024-09-06 02:20:40 --> Security Class Initialized
DEBUG - 2024-09-06 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:20:40 --> Input Class Initialized
INFO - 2024-09-06 02:20:40 --> Language Class Initialized
INFO - 2024-09-06 02:20:40 --> Loader Class Initialized
INFO - 2024-09-06 02:20:40 --> Helper loaded: url_helper
INFO - 2024-09-06 02:20:40 --> Helper loaded: file_helper
INFO - 2024-09-06 02:20:40 --> Helper loaded: security_helper
INFO - 2024-09-06 02:20:40 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:20:40 --> Database Driver Class Initialized
INFO - 2024-09-06 02:20:40 --> Email Class Initialized
DEBUG - 2024-09-06 02:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:20:40 --> Helper loaded: form_helper
INFO - 2024-09-06 02:20:40 --> Form Validation Class Initialized
INFO - 2024-09-06 02:20:40 --> Controller Class Initialized
INFO - 2024-09-06 02:20:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:20:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:20:40 --> Final output sent to browser
DEBUG - 2024-09-06 02:20:40 --> Total execution time: 0.5466
INFO - 2024-09-06 02:21:43 --> Config Class Initialized
INFO - 2024-09-06 02:21:43 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:21:43 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:21:43 --> Utf8 Class Initialized
INFO - 2024-09-06 02:21:43 --> URI Class Initialized
INFO - 2024-09-06 02:21:43 --> Router Class Initialized
INFO - 2024-09-06 02:21:43 --> Output Class Initialized
INFO - 2024-09-06 02:21:43 --> Security Class Initialized
DEBUG - 2024-09-06 02:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:21:43 --> Input Class Initialized
INFO - 2024-09-06 02:21:43 --> Language Class Initialized
INFO - 2024-09-06 02:21:43 --> Loader Class Initialized
INFO - 2024-09-06 02:21:43 --> Helper loaded: url_helper
INFO - 2024-09-06 02:21:43 --> Helper loaded: file_helper
INFO - 2024-09-06 02:21:43 --> Helper loaded: security_helper
INFO - 2024-09-06 02:21:43 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:21:43 --> Database Driver Class Initialized
INFO - 2024-09-06 02:21:43 --> Email Class Initialized
DEBUG - 2024-09-06 02:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:21:43 --> Helper loaded: form_helper
INFO - 2024-09-06 02:21:43 --> Form Validation Class Initialized
INFO - 2024-09-06 02:21:43 --> Controller Class Initialized
INFO - 2024-09-06 02:21:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:21:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:21:44 --> Final output sent to browser
DEBUG - 2024-09-06 02:21:44 --> Total execution time: 0.5927
INFO - 2024-09-06 02:22:13 --> Config Class Initialized
INFO - 2024-09-06 02:22:13 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:22:13 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:22:13 --> Utf8 Class Initialized
INFO - 2024-09-06 02:22:13 --> URI Class Initialized
INFO - 2024-09-06 02:22:13 --> Router Class Initialized
INFO - 2024-09-06 02:22:13 --> Output Class Initialized
INFO - 2024-09-06 02:22:13 --> Security Class Initialized
DEBUG - 2024-09-06 02:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:22:13 --> Input Class Initialized
INFO - 2024-09-06 02:22:13 --> Language Class Initialized
INFO - 2024-09-06 02:22:13 --> Loader Class Initialized
INFO - 2024-09-06 02:22:13 --> Helper loaded: url_helper
INFO - 2024-09-06 02:22:13 --> Helper loaded: file_helper
INFO - 2024-09-06 02:22:13 --> Helper loaded: security_helper
INFO - 2024-09-06 02:22:13 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:22:13 --> Database Driver Class Initialized
INFO - 2024-09-06 02:22:14 --> Email Class Initialized
DEBUG - 2024-09-06 02:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:22:14 --> Helper loaded: form_helper
INFO - 2024-09-06 02:22:14 --> Form Validation Class Initialized
INFO - 2024-09-06 02:22:14 --> Controller Class Initialized
INFO - 2024-09-06 02:22:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:22:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:22:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:22:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:22:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:22:14 --> Final output sent to browser
DEBUG - 2024-09-06 02:22:14 --> Total execution time: 0.6105
INFO - 2024-09-06 02:22:31 --> Config Class Initialized
INFO - 2024-09-06 02:22:31 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:22:31 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:22:31 --> Utf8 Class Initialized
INFO - 2024-09-06 02:22:31 --> URI Class Initialized
INFO - 2024-09-06 02:22:31 --> Router Class Initialized
INFO - 2024-09-06 02:22:31 --> Output Class Initialized
INFO - 2024-09-06 02:22:31 --> Security Class Initialized
DEBUG - 2024-09-06 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:22:31 --> Input Class Initialized
INFO - 2024-09-06 02:22:31 --> Language Class Initialized
INFO - 2024-09-06 02:22:31 --> Loader Class Initialized
INFO - 2024-09-06 02:22:31 --> Helper loaded: url_helper
INFO - 2024-09-06 02:22:31 --> Helper loaded: file_helper
INFO - 2024-09-06 02:22:31 --> Helper loaded: security_helper
INFO - 2024-09-06 02:22:31 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:22:31 --> Database Driver Class Initialized
INFO - 2024-09-06 02:22:32 --> Email Class Initialized
DEBUG - 2024-09-06 02:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:22:32 --> Helper loaded: form_helper
INFO - 2024-09-06 02:22:32 --> Form Validation Class Initialized
INFO - 2024-09-06 02:22:32 --> Controller Class Initialized
INFO - 2024-09-06 02:22:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:22:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:22:32 --> Final output sent to browser
DEBUG - 2024-09-06 02:22:32 --> Total execution time: 0.5715
INFO - 2024-09-06 02:22:53 --> Config Class Initialized
INFO - 2024-09-06 02:22:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:22:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:22:53 --> Utf8 Class Initialized
INFO - 2024-09-06 02:22:53 --> URI Class Initialized
INFO - 2024-09-06 02:22:53 --> Router Class Initialized
INFO - 2024-09-06 02:22:53 --> Output Class Initialized
INFO - 2024-09-06 02:22:53 --> Security Class Initialized
DEBUG - 2024-09-06 02:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:22:53 --> Input Class Initialized
INFO - 2024-09-06 02:22:53 --> Language Class Initialized
INFO - 2024-09-06 02:22:53 --> Loader Class Initialized
INFO - 2024-09-06 02:22:53 --> Helper loaded: url_helper
INFO - 2024-09-06 02:22:53 --> Helper loaded: file_helper
INFO - 2024-09-06 02:22:53 --> Helper loaded: security_helper
INFO - 2024-09-06 02:22:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:22:53 --> Database Driver Class Initialized
INFO - 2024-09-06 02:22:53 --> Email Class Initialized
DEBUG - 2024-09-06 02:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:22:53 --> Helper loaded: form_helper
INFO - 2024-09-06 02:22:53 --> Form Validation Class Initialized
INFO - 2024-09-06 02:22:53 --> Controller Class Initialized
INFO - 2024-09-06 02:22:53 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:22:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:22:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:22:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:22:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:22:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:22:54 --> Final output sent to browser
DEBUG - 2024-09-06 02:22:54 --> Total execution time: 0.6051
INFO - 2024-09-06 02:23:11 --> Config Class Initialized
INFO - 2024-09-06 02:23:11 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:23:11 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:23:11 --> Utf8 Class Initialized
INFO - 2024-09-06 02:23:11 --> URI Class Initialized
INFO - 2024-09-06 02:23:11 --> Router Class Initialized
INFO - 2024-09-06 02:23:11 --> Output Class Initialized
INFO - 2024-09-06 02:23:11 --> Security Class Initialized
DEBUG - 2024-09-06 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:23:11 --> Input Class Initialized
INFO - 2024-09-06 02:23:11 --> Language Class Initialized
INFO - 2024-09-06 02:23:11 --> Loader Class Initialized
INFO - 2024-09-06 02:23:11 --> Helper loaded: url_helper
INFO - 2024-09-06 02:23:11 --> Helper loaded: file_helper
INFO - 2024-09-06 02:23:11 --> Helper loaded: security_helper
INFO - 2024-09-06 02:23:11 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:23:11 --> Database Driver Class Initialized
INFO - 2024-09-06 02:23:11 --> Email Class Initialized
DEBUG - 2024-09-06 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:23:11 --> Helper loaded: form_helper
INFO - 2024-09-06 02:23:11 --> Form Validation Class Initialized
INFO - 2024-09-06 02:23:11 --> Controller Class Initialized
INFO - 2024-09-06 02:23:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:23:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:23:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:23:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:23:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:23:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:23:12 --> Final output sent to browser
DEBUG - 2024-09-06 02:23:12 --> Total execution time: 0.6384
INFO - 2024-09-06 02:23:19 --> Config Class Initialized
INFO - 2024-09-06 02:23:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:23:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:23:19 --> Utf8 Class Initialized
INFO - 2024-09-06 02:23:19 --> URI Class Initialized
INFO - 2024-09-06 02:23:19 --> Router Class Initialized
INFO - 2024-09-06 02:23:19 --> Output Class Initialized
INFO - 2024-09-06 02:23:19 --> Security Class Initialized
DEBUG - 2024-09-06 02:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:23:19 --> Input Class Initialized
INFO - 2024-09-06 02:23:19 --> Language Class Initialized
INFO - 2024-09-06 02:23:19 --> Loader Class Initialized
INFO - 2024-09-06 02:23:19 --> Helper loaded: url_helper
INFO - 2024-09-06 02:23:19 --> Helper loaded: file_helper
INFO - 2024-09-06 02:23:19 --> Helper loaded: security_helper
INFO - 2024-09-06 02:23:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:23:19 --> Database Driver Class Initialized
INFO - 2024-09-06 02:23:20 --> Email Class Initialized
DEBUG - 2024-09-06 02:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:23:20 --> Helper loaded: form_helper
INFO - 2024-09-06 02:23:20 --> Form Validation Class Initialized
INFO - 2024-09-06 02:23:20 --> Controller Class Initialized
INFO - 2024-09-06 02:23:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:23:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:23:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:23:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:23:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:23:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:23:20 --> Final output sent to browser
DEBUG - 2024-09-06 02:23:20 --> Total execution time: 0.5751
INFO - 2024-09-06 02:23:52 --> Config Class Initialized
INFO - 2024-09-06 02:23:52 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:23:52 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:23:52 --> Utf8 Class Initialized
INFO - 2024-09-06 02:23:52 --> URI Class Initialized
INFO - 2024-09-06 02:23:52 --> Router Class Initialized
INFO - 2024-09-06 02:23:52 --> Output Class Initialized
INFO - 2024-09-06 02:23:52 --> Security Class Initialized
DEBUG - 2024-09-06 02:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:23:52 --> Input Class Initialized
INFO - 2024-09-06 02:23:52 --> Language Class Initialized
INFO - 2024-09-06 02:23:52 --> Loader Class Initialized
INFO - 2024-09-06 02:23:52 --> Helper loaded: url_helper
INFO - 2024-09-06 02:23:52 --> Helper loaded: file_helper
INFO - 2024-09-06 02:23:52 --> Helper loaded: security_helper
INFO - 2024-09-06 02:23:52 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:23:52 --> Database Driver Class Initialized
INFO - 2024-09-06 02:23:52 --> Email Class Initialized
DEBUG - 2024-09-06 02:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:23:52 --> Helper loaded: form_helper
INFO - 2024-09-06 02:23:52 --> Form Validation Class Initialized
INFO - 2024-09-06 02:23:52 --> Controller Class Initialized
INFO - 2024-09-06 02:23:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:23:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:23:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:23:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:23:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:23:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:23:53 --> Final output sent to browser
DEBUG - 2024-09-06 02:23:53 --> Total execution time: 0.5615
INFO - 2024-09-06 02:25:16 --> Config Class Initialized
INFO - 2024-09-06 02:25:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:25:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:25:16 --> Utf8 Class Initialized
INFO - 2024-09-06 02:25:16 --> URI Class Initialized
INFO - 2024-09-06 02:25:16 --> Router Class Initialized
INFO - 2024-09-06 02:25:16 --> Output Class Initialized
INFO - 2024-09-06 02:25:16 --> Security Class Initialized
DEBUG - 2024-09-06 02:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:25:16 --> Input Class Initialized
INFO - 2024-09-06 02:25:16 --> Language Class Initialized
INFO - 2024-09-06 02:25:16 --> Loader Class Initialized
INFO - 2024-09-06 02:25:16 --> Helper loaded: url_helper
INFO - 2024-09-06 02:25:16 --> Helper loaded: file_helper
INFO - 2024-09-06 02:25:16 --> Helper loaded: security_helper
INFO - 2024-09-06 02:25:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:25:16 --> Database Driver Class Initialized
INFO - 2024-09-06 02:25:16 --> Email Class Initialized
DEBUG - 2024-09-06 02:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:25:16 --> Helper loaded: form_helper
INFO - 2024-09-06 02:25:16 --> Form Validation Class Initialized
INFO - 2024-09-06 02:25:16 --> Controller Class Initialized
INFO - 2024-09-06 02:25:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:25:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:25:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:25:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:25:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:25:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:25:17 --> Final output sent to browser
DEBUG - 2024-09-06 02:25:17 --> Total execution time: 0.5912
INFO - 2024-09-06 02:25:33 --> Config Class Initialized
INFO - 2024-09-06 02:25:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:25:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:25:33 --> Utf8 Class Initialized
INFO - 2024-09-06 02:25:33 --> URI Class Initialized
INFO - 2024-09-06 02:25:33 --> Router Class Initialized
INFO - 2024-09-06 02:25:33 --> Output Class Initialized
INFO - 2024-09-06 02:25:33 --> Security Class Initialized
DEBUG - 2024-09-06 02:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:25:33 --> Input Class Initialized
INFO - 2024-09-06 02:25:33 --> Language Class Initialized
INFO - 2024-09-06 02:25:33 --> Loader Class Initialized
INFO - 2024-09-06 02:25:33 --> Helper loaded: url_helper
INFO - 2024-09-06 02:25:33 --> Helper loaded: file_helper
INFO - 2024-09-06 02:25:33 --> Helper loaded: security_helper
INFO - 2024-09-06 02:25:33 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:25:33 --> Database Driver Class Initialized
INFO - 2024-09-06 02:25:33 --> Email Class Initialized
DEBUG - 2024-09-06 02:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:25:33 --> Helper loaded: form_helper
INFO - 2024-09-06 02:25:33 --> Form Validation Class Initialized
INFO - 2024-09-06 02:25:33 --> Controller Class Initialized
INFO - 2024-09-06 02:25:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:25:33 --> Final output sent to browser
DEBUG - 2024-09-06 02:25:33 --> Total execution time: 0.5557
INFO - 2024-09-06 02:25:45 --> Config Class Initialized
INFO - 2024-09-06 02:25:45 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:25:45 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:25:45 --> Utf8 Class Initialized
INFO - 2024-09-06 02:25:45 --> URI Class Initialized
INFO - 2024-09-06 02:25:45 --> Router Class Initialized
INFO - 2024-09-06 02:25:45 --> Output Class Initialized
INFO - 2024-09-06 02:25:45 --> Security Class Initialized
DEBUG - 2024-09-06 02:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:25:45 --> Input Class Initialized
INFO - 2024-09-06 02:25:45 --> Language Class Initialized
INFO - 2024-09-06 02:25:45 --> Loader Class Initialized
INFO - 2024-09-06 02:25:45 --> Helper loaded: url_helper
INFO - 2024-09-06 02:25:45 --> Helper loaded: file_helper
INFO - 2024-09-06 02:25:45 --> Helper loaded: security_helper
INFO - 2024-09-06 02:25:45 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:25:45 --> Database Driver Class Initialized
INFO - 2024-09-06 02:25:46 --> Email Class Initialized
DEBUG - 2024-09-06 02:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:25:46 --> Helper loaded: form_helper
INFO - 2024-09-06 02:25:46 --> Form Validation Class Initialized
INFO - 2024-09-06 02:25:46 --> Controller Class Initialized
INFO - 2024-09-06 02:25:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:25:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:25:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:25:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:25:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:25:46 --> Final output sent to browser
DEBUG - 2024-09-06 02:25:46 --> Total execution time: 0.5802
INFO - 2024-09-06 02:26:00 --> Config Class Initialized
INFO - 2024-09-06 02:26:00 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:26:00 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:26:00 --> Utf8 Class Initialized
INFO - 2024-09-06 02:26:00 --> URI Class Initialized
INFO - 2024-09-06 02:26:00 --> Router Class Initialized
INFO - 2024-09-06 02:26:00 --> Output Class Initialized
INFO - 2024-09-06 02:26:00 --> Security Class Initialized
DEBUG - 2024-09-06 02:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:26:00 --> Input Class Initialized
INFO - 2024-09-06 02:26:00 --> Language Class Initialized
INFO - 2024-09-06 02:26:00 --> Loader Class Initialized
INFO - 2024-09-06 02:26:00 --> Helper loaded: url_helper
INFO - 2024-09-06 02:26:00 --> Helper loaded: file_helper
INFO - 2024-09-06 02:26:00 --> Helper loaded: security_helper
INFO - 2024-09-06 02:26:00 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:26:00 --> Database Driver Class Initialized
INFO - 2024-09-06 02:26:00 --> Email Class Initialized
DEBUG - 2024-09-06 02:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:26:00 --> Helper loaded: form_helper
INFO - 2024-09-06 02:26:00 --> Form Validation Class Initialized
INFO - 2024-09-06 02:26:00 --> Controller Class Initialized
INFO - 2024-09-06 02:26:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:26:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:26:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:26:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:26:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:26:00 --> Final output sent to browser
DEBUG - 2024-09-06 02:26:00 --> Total execution time: 0.5306
INFO - 2024-09-06 02:26:03 --> Config Class Initialized
INFO - 2024-09-06 02:26:03 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:26:03 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:26:03 --> Utf8 Class Initialized
INFO - 2024-09-06 02:26:03 --> URI Class Initialized
INFO - 2024-09-06 02:26:03 --> Router Class Initialized
INFO - 2024-09-06 02:26:03 --> Output Class Initialized
INFO - 2024-09-06 02:26:03 --> Security Class Initialized
DEBUG - 2024-09-06 02:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:26:03 --> Input Class Initialized
INFO - 2024-09-06 02:26:03 --> Language Class Initialized
INFO - 2024-09-06 02:26:03 --> Loader Class Initialized
INFO - 2024-09-06 02:26:03 --> Helper loaded: url_helper
INFO - 2024-09-06 02:26:03 --> Helper loaded: file_helper
INFO - 2024-09-06 02:26:03 --> Helper loaded: security_helper
INFO - 2024-09-06 02:26:03 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:26:03 --> Database Driver Class Initialized
INFO - 2024-09-06 02:26:03 --> Email Class Initialized
DEBUG - 2024-09-06 02:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:26:03 --> Helper loaded: form_helper
INFO - 2024-09-06 02:26:03 --> Form Validation Class Initialized
INFO - 2024-09-06 02:26:03 --> Controller Class Initialized
INFO - 2024-09-06 02:26:03 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:26:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:26:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:26:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:26:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:26:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:26:03 --> Final output sent to browser
DEBUG - 2024-09-06 02:26:03 --> Total execution time: 0.5723
INFO - 2024-09-06 02:26:21 --> Config Class Initialized
INFO - 2024-09-06 02:26:21 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:26:21 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:26:21 --> Utf8 Class Initialized
INFO - 2024-09-06 02:26:21 --> URI Class Initialized
INFO - 2024-09-06 02:26:21 --> Router Class Initialized
INFO - 2024-09-06 02:26:21 --> Output Class Initialized
INFO - 2024-09-06 02:26:21 --> Security Class Initialized
DEBUG - 2024-09-06 02:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:26:21 --> Input Class Initialized
INFO - 2024-09-06 02:26:21 --> Language Class Initialized
INFO - 2024-09-06 02:26:21 --> Loader Class Initialized
INFO - 2024-09-06 02:26:21 --> Helper loaded: url_helper
INFO - 2024-09-06 02:26:21 --> Helper loaded: file_helper
INFO - 2024-09-06 02:26:21 --> Helper loaded: security_helper
INFO - 2024-09-06 02:26:21 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:26:21 --> Database Driver Class Initialized
INFO - 2024-09-06 02:26:21 --> Email Class Initialized
DEBUG - 2024-09-06 02:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:26:21 --> Helper loaded: form_helper
INFO - 2024-09-06 02:26:21 --> Form Validation Class Initialized
INFO - 2024-09-06 02:26:21 --> Controller Class Initialized
INFO - 2024-09-06 02:26:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:26:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:26:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:26:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:26:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:26:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:26:22 --> Final output sent to browser
DEBUG - 2024-09-06 02:26:22 --> Total execution time: 0.6166
INFO - 2024-09-06 02:26:35 --> Config Class Initialized
INFO - 2024-09-06 02:26:35 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:26:35 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:26:35 --> Utf8 Class Initialized
INFO - 2024-09-06 02:26:35 --> URI Class Initialized
INFO - 2024-09-06 02:26:35 --> Router Class Initialized
INFO - 2024-09-06 02:26:35 --> Output Class Initialized
INFO - 2024-09-06 02:26:35 --> Security Class Initialized
DEBUG - 2024-09-06 02:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:26:35 --> Input Class Initialized
INFO - 2024-09-06 02:26:35 --> Language Class Initialized
INFO - 2024-09-06 02:26:35 --> Loader Class Initialized
INFO - 2024-09-06 02:26:35 --> Helper loaded: url_helper
INFO - 2024-09-06 02:26:35 --> Helper loaded: file_helper
INFO - 2024-09-06 02:26:35 --> Helper loaded: security_helper
INFO - 2024-09-06 02:26:35 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:26:35 --> Database Driver Class Initialized
INFO - 2024-09-06 02:26:35 --> Email Class Initialized
DEBUG - 2024-09-06 02:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:26:35 --> Helper loaded: form_helper
INFO - 2024-09-06 02:26:35 --> Form Validation Class Initialized
INFO - 2024-09-06 02:26:35 --> Controller Class Initialized
INFO - 2024-09-06 02:26:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:26:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:26:36 --> Final output sent to browser
DEBUG - 2024-09-06 02:26:36 --> Total execution time: 0.6328
INFO - 2024-09-06 02:26:45 --> Config Class Initialized
INFO - 2024-09-06 02:26:45 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:26:45 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:26:45 --> Utf8 Class Initialized
INFO - 2024-09-06 02:26:45 --> URI Class Initialized
INFO - 2024-09-06 02:26:45 --> Router Class Initialized
INFO - 2024-09-06 02:26:45 --> Output Class Initialized
INFO - 2024-09-06 02:26:45 --> Security Class Initialized
DEBUG - 2024-09-06 02:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:26:45 --> Input Class Initialized
INFO - 2024-09-06 02:26:45 --> Language Class Initialized
INFO - 2024-09-06 02:26:45 --> Loader Class Initialized
INFO - 2024-09-06 02:26:45 --> Helper loaded: url_helper
INFO - 2024-09-06 02:26:45 --> Helper loaded: file_helper
INFO - 2024-09-06 02:26:45 --> Helper loaded: security_helper
INFO - 2024-09-06 02:26:45 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:26:45 --> Database Driver Class Initialized
INFO - 2024-09-06 02:26:45 --> Email Class Initialized
DEBUG - 2024-09-06 02:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:26:45 --> Helper loaded: form_helper
INFO - 2024-09-06 02:26:45 --> Form Validation Class Initialized
INFO - 2024-09-06 02:26:45 --> Controller Class Initialized
INFO - 2024-09-06 02:26:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:26:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:26:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:26:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:26:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:26:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:26:45 --> Final output sent to browser
DEBUG - 2024-09-06 02:26:45 --> Total execution time: 0.5429
INFO - 2024-09-06 02:27:42 --> Config Class Initialized
INFO - 2024-09-06 02:27:42 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:27:42 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:27:42 --> Utf8 Class Initialized
INFO - 2024-09-06 02:27:42 --> URI Class Initialized
DEBUG - 2024-09-06 02:27:42 --> No URI present. Default controller set.
INFO - 2024-09-06 02:27:42 --> Router Class Initialized
INFO - 2024-09-06 02:27:42 --> Output Class Initialized
INFO - 2024-09-06 02:27:42 --> Security Class Initialized
DEBUG - 2024-09-06 02:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:27:42 --> Input Class Initialized
INFO - 2024-09-06 02:27:42 --> Language Class Initialized
INFO - 2024-09-06 02:27:42 --> Loader Class Initialized
INFO - 2024-09-06 02:27:42 --> Helper loaded: url_helper
INFO - 2024-09-06 02:27:42 --> Helper loaded: file_helper
INFO - 2024-09-06 02:27:42 --> Helper loaded: security_helper
INFO - 2024-09-06 02:27:42 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:27:42 --> Database Driver Class Initialized
INFO - 2024-09-06 02:27:42 --> Email Class Initialized
DEBUG - 2024-09-06 02:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:27:42 --> Helper loaded: form_helper
INFO - 2024-09-06 02:27:42 --> Form Validation Class Initialized
INFO - 2024-09-06 02:27:42 --> Controller Class Initialized
DEBUG - 2024-09-06 02:27:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:27:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 02:27:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 02:27:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 02:27:42 --> Final output sent to browser
DEBUG - 2024-09-06 02:27:42 --> Total execution time: 0.7200
INFO - 2024-09-06 02:27:50 --> Config Class Initialized
INFO - 2024-09-06 02:27:50 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:27:50 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:27:50 --> Utf8 Class Initialized
INFO - 2024-09-06 02:27:50 --> URI Class Initialized
INFO - 2024-09-06 02:27:50 --> Router Class Initialized
INFO - 2024-09-06 02:27:50 --> Output Class Initialized
INFO - 2024-09-06 02:27:50 --> Security Class Initialized
DEBUG - 2024-09-06 02:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:27:50 --> Input Class Initialized
INFO - 2024-09-06 02:27:50 --> Language Class Initialized
INFO - 2024-09-06 02:27:50 --> Loader Class Initialized
INFO - 2024-09-06 02:27:50 --> Helper loaded: url_helper
INFO - 2024-09-06 02:27:50 --> Helper loaded: file_helper
INFO - 2024-09-06 02:27:50 --> Helper loaded: security_helper
INFO - 2024-09-06 02:27:50 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:27:51 --> Database Driver Class Initialized
INFO - 2024-09-06 02:27:51 --> Email Class Initialized
DEBUG - 2024-09-06 02:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:27:51 --> Helper loaded: form_helper
INFO - 2024-09-06 02:27:51 --> Form Validation Class Initialized
INFO - 2024-09-06 02:27:51 --> Controller Class Initialized
DEBUG - 2024-09-06 02:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:27:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-06 02:27:51 --> Config Class Initialized
INFO - 2024-09-06 02:27:51 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:27:51 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:27:51 --> Utf8 Class Initialized
INFO - 2024-09-06 02:27:51 --> URI Class Initialized
INFO - 2024-09-06 02:27:51 --> Router Class Initialized
INFO - 2024-09-06 02:27:51 --> Output Class Initialized
INFO - 2024-09-06 02:27:51 --> Security Class Initialized
DEBUG - 2024-09-06 02:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:27:51 --> Input Class Initialized
INFO - 2024-09-06 02:27:51 --> Language Class Initialized
INFO - 2024-09-06 02:27:51 --> Loader Class Initialized
INFO - 2024-09-06 02:27:51 --> Helper loaded: url_helper
INFO - 2024-09-06 02:27:51 --> Helper loaded: file_helper
INFO - 2024-09-06 02:27:51 --> Helper loaded: security_helper
INFO - 2024-09-06 02:27:51 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:27:51 --> Database Driver Class Initialized
INFO - 2024-09-06 02:27:51 --> Email Class Initialized
DEBUG - 2024-09-06 02:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:27:51 --> Helper loaded: form_helper
INFO - 2024-09-06 02:27:51 --> Form Validation Class Initialized
INFO - 2024-09-06 02:27:51 --> Controller Class Initialized
INFO - 2024-09-06 02:27:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:27:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:27:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:27:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:27:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:27:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:27:51 --> Final output sent to browser
DEBUG - 2024-09-06 02:27:51 --> Total execution time: 0.5330
INFO - 2024-09-06 02:28:06 --> Config Class Initialized
INFO - 2024-09-06 02:28:06 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:28:06 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:28:06 --> Utf8 Class Initialized
INFO - 2024-09-06 02:28:06 --> URI Class Initialized
INFO - 2024-09-06 02:28:06 --> Router Class Initialized
INFO - 2024-09-06 02:28:06 --> Output Class Initialized
INFO - 2024-09-06 02:28:06 --> Security Class Initialized
DEBUG - 2024-09-06 02:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:28:06 --> Input Class Initialized
INFO - 2024-09-06 02:28:06 --> Language Class Initialized
INFO - 2024-09-06 02:28:06 --> Loader Class Initialized
INFO - 2024-09-06 02:28:06 --> Helper loaded: url_helper
INFO - 2024-09-06 02:28:06 --> Helper loaded: file_helper
INFO - 2024-09-06 02:28:06 --> Helper loaded: security_helper
INFO - 2024-09-06 02:28:06 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:28:06 --> Database Driver Class Initialized
INFO - 2024-09-06 02:28:07 --> Email Class Initialized
DEBUG - 2024-09-06 02:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:28:07 --> Helper loaded: form_helper
INFO - 2024-09-06 02:28:07 --> Form Validation Class Initialized
INFO - 2024-09-06 02:28:07 --> Controller Class Initialized
INFO - 2024-09-06 02:28:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:28:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:28:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:28:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:28:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:28:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:28:07 --> Final output sent to browser
DEBUG - 2024-09-06 02:28:07 --> Total execution time: 0.5871
INFO - 2024-09-06 02:28:13 --> Config Class Initialized
INFO - 2024-09-06 02:28:13 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:28:13 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:28:13 --> Utf8 Class Initialized
INFO - 2024-09-06 02:28:13 --> URI Class Initialized
INFO - 2024-09-06 02:28:13 --> Router Class Initialized
INFO - 2024-09-06 02:28:13 --> Output Class Initialized
INFO - 2024-09-06 02:28:13 --> Security Class Initialized
DEBUG - 2024-09-06 02:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:28:13 --> Input Class Initialized
INFO - 2024-09-06 02:28:13 --> Language Class Initialized
INFO - 2024-09-06 02:28:13 --> Loader Class Initialized
INFO - 2024-09-06 02:28:13 --> Helper loaded: url_helper
INFO - 2024-09-06 02:28:13 --> Helper loaded: file_helper
INFO - 2024-09-06 02:28:13 --> Helper loaded: security_helper
INFO - 2024-09-06 02:28:13 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:28:13 --> Database Driver Class Initialized
INFO - 2024-09-06 02:28:13 --> Email Class Initialized
DEBUG - 2024-09-06 02:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:28:13 --> Helper loaded: form_helper
INFO - 2024-09-06 02:28:13 --> Form Validation Class Initialized
INFO - 2024-09-06 02:28:13 --> Controller Class Initialized
INFO - 2024-09-06 02:28:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:28:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:28:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:28:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:28:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:28:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:28:14 --> Final output sent to browser
DEBUG - 2024-09-06 02:28:14 --> Total execution time: 0.6437
INFO - 2024-09-06 02:29:32 --> Config Class Initialized
INFO - 2024-09-06 02:29:32 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:29:32 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:29:32 --> Utf8 Class Initialized
INFO - 2024-09-06 02:29:32 --> URI Class Initialized
INFO - 2024-09-06 02:29:32 --> Router Class Initialized
INFO - 2024-09-06 02:29:32 --> Output Class Initialized
INFO - 2024-09-06 02:29:32 --> Security Class Initialized
DEBUG - 2024-09-06 02:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:29:32 --> Input Class Initialized
INFO - 2024-09-06 02:29:32 --> Language Class Initialized
INFO - 2024-09-06 02:29:32 --> Loader Class Initialized
INFO - 2024-09-06 02:29:32 --> Helper loaded: url_helper
INFO - 2024-09-06 02:29:32 --> Helper loaded: file_helper
INFO - 2024-09-06 02:29:32 --> Helper loaded: security_helper
INFO - 2024-09-06 02:29:32 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:29:32 --> Database Driver Class Initialized
INFO - 2024-09-06 02:29:33 --> Email Class Initialized
DEBUG - 2024-09-06 02:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:29:33 --> Helper loaded: form_helper
INFO - 2024-09-06 02:29:33 --> Form Validation Class Initialized
INFO - 2024-09-06 02:29:33 --> Controller Class Initialized
INFO - 2024-09-06 02:29:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:29:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:29:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:29:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:29:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:29:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:29:33 --> Final output sent to browser
DEBUG - 2024-09-06 02:29:33 --> Total execution time: 0.6691
INFO - 2024-09-06 02:29:36 --> Config Class Initialized
INFO - 2024-09-06 02:29:36 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:29:36 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:29:36 --> Utf8 Class Initialized
INFO - 2024-09-06 02:29:36 --> URI Class Initialized
INFO - 2024-09-06 02:29:36 --> Router Class Initialized
INFO - 2024-09-06 02:29:36 --> Output Class Initialized
INFO - 2024-09-06 02:29:36 --> Security Class Initialized
DEBUG - 2024-09-06 02:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:29:36 --> Input Class Initialized
INFO - 2024-09-06 02:29:36 --> Language Class Initialized
INFO - 2024-09-06 02:29:36 --> Loader Class Initialized
INFO - 2024-09-06 02:29:36 --> Helper loaded: url_helper
INFO - 2024-09-06 02:29:36 --> Helper loaded: file_helper
INFO - 2024-09-06 02:29:36 --> Helper loaded: security_helper
INFO - 2024-09-06 02:29:36 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:29:36 --> Database Driver Class Initialized
INFO - 2024-09-06 02:29:36 --> Email Class Initialized
DEBUG - 2024-09-06 02:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:29:36 --> Helper loaded: form_helper
INFO - 2024-09-06 02:29:36 --> Form Validation Class Initialized
INFO - 2024-09-06 02:29:36 --> Controller Class Initialized
INFO - 2024-09-06 02:29:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:29:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:29:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:29:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:29:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:29:37 --> Final output sent to browser
DEBUG - 2024-09-06 02:29:37 --> Total execution time: 0.6433
INFO - 2024-09-06 02:32:24 --> Config Class Initialized
INFO - 2024-09-06 02:32:24 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:32:24 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:32:24 --> Utf8 Class Initialized
INFO - 2024-09-06 02:32:24 --> URI Class Initialized
INFO - 2024-09-06 02:32:24 --> Router Class Initialized
INFO - 2024-09-06 02:32:24 --> Output Class Initialized
INFO - 2024-09-06 02:32:24 --> Security Class Initialized
DEBUG - 2024-09-06 02:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:32:24 --> Input Class Initialized
INFO - 2024-09-06 02:32:24 --> Language Class Initialized
INFO - 2024-09-06 02:32:24 --> Loader Class Initialized
INFO - 2024-09-06 02:32:24 --> Helper loaded: url_helper
INFO - 2024-09-06 02:32:24 --> Helper loaded: file_helper
INFO - 2024-09-06 02:32:24 --> Helper loaded: security_helper
INFO - 2024-09-06 02:32:24 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:32:24 --> Database Driver Class Initialized
INFO - 2024-09-06 02:32:25 --> Email Class Initialized
DEBUG - 2024-09-06 02:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:32:25 --> Helper loaded: form_helper
INFO - 2024-09-06 02:32:25 --> Form Validation Class Initialized
INFO - 2024-09-06 02:32:25 --> Controller Class Initialized
INFO - 2024-09-06 02:32:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:32:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:32:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:32:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:32:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:32:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:32:25 --> Final output sent to browser
DEBUG - 2024-09-06 02:32:25 --> Total execution time: 0.6203
INFO - 2024-09-06 02:33:01 --> Config Class Initialized
INFO - 2024-09-06 02:33:01 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:33:01 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:33:01 --> Utf8 Class Initialized
INFO - 2024-09-06 02:33:01 --> URI Class Initialized
INFO - 2024-09-06 02:33:01 --> Router Class Initialized
INFO - 2024-09-06 02:33:01 --> Output Class Initialized
INFO - 2024-09-06 02:33:01 --> Security Class Initialized
DEBUG - 2024-09-06 02:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:33:01 --> Input Class Initialized
INFO - 2024-09-06 02:33:01 --> Language Class Initialized
INFO - 2024-09-06 02:33:01 --> Loader Class Initialized
INFO - 2024-09-06 02:33:01 --> Helper loaded: url_helper
INFO - 2024-09-06 02:33:01 --> Helper loaded: file_helper
INFO - 2024-09-06 02:33:01 --> Helper loaded: security_helper
INFO - 2024-09-06 02:33:01 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:33:01 --> Database Driver Class Initialized
INFO - 2024-09-06 02:33:01 --> Email Class Initialized
DEBUG - 2024-09-06 02:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:33:01 --> Helper loaded: form_helper
INFO - 2024-09-06 02:33:01 --> Form Validation Class Initialized
INFO - 2024-09-06 02:33:01 --> Controller Class Initialized
INFO - 2024-09-06 02:33:01 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:33:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:33:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:33:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:33:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:33:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:33:02 --> Final output sent to browser
DEBUG - 2024-09-06 02:33:02 --> Total execution time: 0.6741
INFO - 2024-09-06 02:34:25 --> Config Class Initialized
INFO - 2024-09-06 02:34:25 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:34:25 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:34:25 --> Utf8 Class Initialized
INFO - 2024-09-06 02:34:25 --> URI Class Initialized
INFO - 2024-09-06 02:34:25 --> Router Class Initialized
INFO - 2024-09-06 02:34:25 --> Output Class Initialized
INFO - 2024-09-06 02:34:25 --> Security Class Initialized
DEBUG - 2024-09-06 02:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:34:25 --> Input Class Initialized
INFO - 2024-09-06 02:34:25 --> Language Class Initialized
INFO - 2024-09-06 02:34:25 --> Loader Class Initialized
INFO - 2024-09-06 02:34:25 --> Helper loaded: url_helper
INFO - 2024-09-06 02:34:25 --> Helper loaded: file_helper
INFO - 2024-09-06 02:34:25 --> Helper loaded: security_helper
INFO - 2024-09-06 02:34:25 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:34:25 --> Database Driver Class Initialized
INFO - 2024-09-06 02:34:25 --> Email Class Initialized
DEBUG - 2024-09-06 02:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:34:25 --> Helper loaded: form_helper
INFO - 2024-09-06 02:34:25 --> Form Validation Class Initialized
INFO - 2024-09-06 02:34:25 --> Controller Class Initialized
INFO - 2024-09-06 02:34:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:34:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:34:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:34:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:34:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:34:26 --> Final output sent to browser
DEBUG - 2024-09-06 02:34:26 --> Total execution time: 0.6927
INFO - 2024-09-06 02:36:29 --> Config Class Initialized
INFO - 2024-09-06 02:36:29 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:29 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:29 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:29 --> URI Class Initialized
INFO - 2024-09-06 02:36:29 --> Router Class Initialized
INFO - 2024-09-06 02:36:29 --> Output Class Initialized
INFO - 2024-09-06 02:36:29 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:29 --> Input Class Initialized
INFO - 2024-09-06 02:36:29 --> Language Class Initialized
INFO - 2024-09-06 02:36:29 --> Loader Class Initialized
INFO - 2024-09-06 02:36:29 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:29 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:29 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:29 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:29 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:29 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:29 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:29 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:29 --> Controller Class Initialized
INFO - 2024-09-06 02:36:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:36:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:29 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:29 --> Total execution time: 0.5967
INFO - 2024-09-06 02:36:42 --> Config Class Initialized
INFO - 2024-09-06 02:36:42 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:42 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:42 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:42 --> URI Class Initialized
INFO - 2024-09-06 02:36:42 --> Router Class Initialized
INFO - 2024-09-06 02:36:42 --> Output Class Initialized
INFO - 2024-09-06 02:36:42 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:42 --> Input Class Initialized
INFO - 2024-09-06 02:36:42 --> Language Class Initialized
INFO - 2024-09-06 02:36:42 --> Loader Class Initialized
INFO - 2024-09-06 02:36:42 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:42 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:42 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:42 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:42 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:42 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:42 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:42 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:42 --> Controller Class Initialized
INFO - 2024-09-06 02:36:42 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:36:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:43 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:43 --> Total execution time: 0.6679
INFO - 2024-09-06 02:36:50 --> Config Class Initialized
INFO - 2024-09-06 02:36:50 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:50 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:50 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:50 --> URI Class Initialized
INFO - 2024-09-06 02:36:50 --> Router Class Initialized
INFO - 2024-09-06 02:36:50 --> Output Class Initialized
INFO - 2024-09-06 02:36:50 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:50 --> Input Class Initialized
INFO - 2024-09-06 02:36:50 --> Language Class Initialized
INFO - 2024-09-06 02:36:50 --> Loader Class Initialized
INFO - 2024-09-06 02:36:50 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:50 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:50 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:50 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:50 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:50 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:50 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:50 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:50 --> Controller Class Initialized
INFO - 2024-09-06 02:36:50 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:36:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:51 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:51 --> Total execution time: 0.6901
INFO - 2024-09-06 02:36:55 --> Config Class Initialized
INFO - 2024-09-06 02:36:55 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:55 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:55 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:55 --> URI Class Initialized
INFO - 2024-09-06 02:36:55 --> Router Class Initialized
INFO - 2024-09-06 02:36:55 --> Output Class Initialized
INFO - 2024-09-06 02:36:55 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:55 --> Input Class Initialized
INFO - 2024-09-06 02:36:55 --> Language Class Initialized
INFO - 2024-09-06 02:36:55 --> Loader Class Initialized
INFO - 2024-09-06 02:36:55 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:55 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:55 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:55 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:55 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:55 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:55 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:55 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:55 --> Controller Class Initialized
INFO - 2024-09-06 02:36:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:56 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:56 --> Total execution time: 0.7279
INFO - 2024-09-06 02:36:56 --> Config Class Initialized
INFO - 2024-09-06 02:36:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:56 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:56 --> URI Class Initialized
INFO - 2024-09-06 02:36:56 --> Router Class Initialized
INFO - 2024-09-06 02:36:56 --> Output Class Initialized
INFO - 2024-09-06 02:36:56 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:56 --> Input Class Initialized
INFO - 2024-09-06 02:36:56 --> Language Class Initialized
INFO - 2024-09-06 02:36:56 --> Loader Class Initialized
INFO - 2024-09-06 02:36:56 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:56 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:56 --> Config Class Initialized
INFO - 2024-09-06 02:36:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:56 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:56 --> URI Class Initialized
INFO - 2024-09-06 02:36:56 --> Router Class Initialized
INFO - 2024-09-06 02:36:56 --> Output Class Initialized
INFO - 2024-09-06 02:36:56 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:56 --> Input Class Initialized
INFO - 2024-09-06 02:36:56 --> Language Class Initialized
INFO - 2024-09-06 02:36:56 --> Loader Class Initialized
INFO - 2024-09-06 02:36:56 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:56 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:56 --> Config Class Initialized
INFO - 2024-09-06 02:36:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:56 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:56 --> URI Class Initialized
INFO - 2024-09-06 02:36:56 --> Router Class Initialized
INFO - 2024-09-06 02:36:56 --> Output Class Initialized
INFO - 2024-09-06 02:36:56 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:56 --> Input Class Initialized
INFO - 2024-09-06 02:36:56 --> Language Class Initialized
INFO - 2024-09-06 02:36:56 --> Loader Class Initialized
INFO - 2024-09-06 02:36:56 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:56 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:56 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:56 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:56 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:56 --> Controller Class Initialized
INFO - 2024-09-06 02:36:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:56 --> Config Class Initialized
INFO - 2024-09-06 02:36:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:56 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:56 --> URI Class Initialized
INFO - 2024-09-06 02:36:56 --> Router Class Initialized
INFO - 2024-09-06 02:36:56 --> Output Class Initialized
INFO - 2024-09-06 02:36:56 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:56 --> Input Class Initialized
INFO - 2024-09-06 02:36:56 --> Language Class Initialized
INFO - 2024-09-06 02:36:56 --> Loader Class Initialized
INFO - 2024-09-06 02:36:56 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:56 --> Database Driver Class Initialized
INFO - 2024-09-06 02:36:57 --> Email Class Initialized
DEBUG - 2024-09-06 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:57 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:57 --> Total execution time: 0.7639
INFO - 2024-09-06 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:36:57 --> Helper loaded: form_helper
INFO - 2024-09-06 02:36:57 --> Form Validation Class Initialized
INFO - 2024-09-06 02:36:57 --> Controller Class Initialized
INFO - 2024-09-06 02:36:57 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:36:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:36:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:36:57 --> Final output sent to browser
DEBUG - 2024-09-06 02:36:57 --> Total execution time: 0.8686
INFO - 2024-09-06 02:36:59 --> Config Class Initialized
INFO - 2024-09-06 02:36:59 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:36:59 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:36:59 --> Utf8 Class Initialized
INFO - 2024-09-06 02:36:59 --> URI Class Initialized
INFO - 2024-09-06 02:36:59 --> Router Class Initialized
INFO - 2024-09-06 02:36:59 --> Output Class Initialized
INFO - 2024-09-06 02:36:59 --> Security Class Initialized
DEBUG - 2024-09-06 02:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:36:59 --> Input Class Initialized
INFO - 2024-09-06 02:36:59 --> Language Class Initialized
INFO - 2024-09-06 02:36:59 --> Loader Class Initialized
INFO - 2024-09-06 02:36:59 --> Helper loaded: url_helper
INFO - 2024-09-06 02:36:59 --> Helper loaded: file_helper
INFO - 2024-09-06 02:36:59 --> Helper loaded: security_helper
INFO - 2024-09-06 02:36:59 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:36:59 --> Database Driver Class Initialized
INFO - 2024-09-06 02:37:00 --> Email Class Initialized
DEBUG - 2024-09-06 02:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:37:00 --> Helper loaded: form_helper
INFO - 2024-09-06 02:37:00 --> Form Validation Class Initialized
INFO - 2024-09-06 02:37:00 --> Controller Class Initialized
INFO - 2024-09-06 02:37:00 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:37:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:37:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:37:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:37:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:37:00 --> Final output sent to browser
DEBUG - 2024-09-06 02:37:00 --> Total execution time: 0.5913
INFO - 2024-09-06 02:37:24 --> Config Class Initialized
INFO - 2024-09-06 02:37:24 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:37:24 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:37:24 --> Utf8 Class Initialized
INFO - 2024-09-06 02:37:24 --> URI Class Initialized
INFO - 2024-09-06 02:37:24 --> Router Class Initialized
INFO - 2024-09-06 02:37:24 --> Output Class Initialized
INFO - 2024-09-06 02:37:24 --> Security Class Initialized
DEBUG - 2024-09-06 02:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:37:24 --> Input Class Initialized
INFO - 2024-09-06 02:37:24 --> Language Class Initialized
INFO - 2024-09-06 02:37:24 --> Loader Class Initialized
INFO - 2024-09-06 02:37:24 --> Helper loaded: url_helper
INFO - 2024-09-06 02:37:24 --> Helper loaded: file_helper
INFO - 2024-09-06 02:37:24 --> Helper loaded: security_helper
INFO - 2024-09-06 02:37:24 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:37:24 --> Database Driver Class Initialized
INFO - 2024-09-06 02:37:24 --> Email Class Initialized
DEBUG - 2024-09-06 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:37:24 --> Helper loaded: form_helper
INFO - 2024-09-06 02:37:24 --> Form Validation Class Initialized
INFO - 2024-09-06 02:37:24 --> Controller Class Initialized
INFO - 2024-09-06 02:37:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:37:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:37:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:37:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:37:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:37:25 --> Final output sent to browser
DEBUG - 2024-09-06 02:37:25 --> Total execution time: 0.6351
INFO - 2024-09-06 02:39:30 --> Config Class Initialized
INFO - 2024-09-06 02:39:30 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:39:30 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:39:30 --> Utf8 Class Initialized
INFO - 2024-09-06 02:39:30 --> URI Class Initialized
INFO - 2024-09-06 02:39:30 --> Router Class Initialized
INFO - 2024-09-06 02:39:30 --> Output Class Initialized
INFO - 2024-09-06 02:39:30 --> Security Class Initialized
DEBUG - 2024-09-06 02:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:39:30 --> Input Class Initialized
INFO - 2024-09-06 02:39:30 --> Language Class Initialized
INFO - 2024-09-06 02:39:30 --> Loader Class Initialized
INFO - 2024-09-06 02:39:30 --> Helper loaded: url_helper
INFO - 2024-09-06 02:39:30 --> Helper loaded: file_helper
INFO - 2024-09-06 02:39:30 --> Helper loaded: security_helper
INFO - 2024-09-06 02:39:30 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:39:30 --> Database Driver Class Initialized
INFO - 2024-09-06 02:39:31 --> Email Class Initialized
DEBUG - 2024-09-06 02:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:39:31 --> Helper loaded: form_helper
INFO - 2024-09-06 02:39:31 --> Form Validation Class Initialized
INFO - 2024-09-06 02:39:31 --> Controller Class Initialized
INFO - 2024-09-06 02:39:31 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:39:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:39:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:39:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:39:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:39:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:39:31 --> Final output sent to browser
DEBUG - 2024-09-06 02:39:31 --> Total execution time: 0.6034
INFO - 2024-09-06 02:40:17 --> Config Class Initialized
INFO - 2024-09-06 02:40:17 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:40:17 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:40:17 --> Utf8 Class Initialized
INFO - 2024-09-06 02:40:17 --> URI Class Initialized
INFO - 2024-09-06 02:40:17 --> Router Class Initialized
INFO - 2024-09-06 02:40:17 --> Output Class Initialized
INFO - 2024-09-06 02:40:17 --> Security Class Initialized
DEBUG - 2024-09-06 02:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:40:17 --> Input Class Initialized
INFO - 2024-09-06 02:40:17 --> Language Class Initialized
INFO - 2024-09-06 02:40:17 --> Loader Class Initialized
INFO - 2024-09-06 02:40:17 --> Helper loaded: url_helper
INFO - 2024-09-06 02:40:17 --> Helper loaded: file_helper
INFO - 2024-09-06 02:40:17 --> Helper loaded: security_helper
INFO - 2024-09-06 02:40:17 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:40:17 --> Database Driver Class Initialized
INFO - 2024-09-06 02:40:17 --> Email Class Initialized
DEBUG - 2024-09-06 02:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:40:17 --> Helper loaded: form_helper
INFO - 2024-09-06 02:40:17 --> Form Validation Class Initialized
INFO - 2024-09-06 02:40:17 --> Controller Class Initialized
INFO - 2024-09-06 02:40:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:40:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:40:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:40:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:40:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:40:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:40:18 --> Final output sent to browser
DEBUG - 2024-09-06 02:40:18 --> Total execution time: 0.6111
INFO - 2024-09-06 02:40:54 --> Config Class Initialized
INFO - 2024-09-06 02:40:54 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:40:54 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:40:54 --> Utf8 Class Initialized
INFO - 2024-09-06 02:40:54 --> URI Class Initialized
INFO - 2024-09-06 02:40:54 --> Router Class Initialized
INFO - 2024-09-06 02:40:54 --> Output Class Initialized
INFO - 2024-09-06 02:40:54 --> Security Class Initialized
DEBUG - 2024-09-06 02:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:40:54 --> Input Class Initialized
INFO - 2024-09-06 02:40:54 --> Language Class Initialized
INFO - 2024-09-06 02:40:54 --> Loader Class Initialized
INFO - 2024-09-06 02:40:54 --> Helper loaded: url_helper
INFO - 2024-09-06 02:40:54 --> Helper loaded: file_helper
INFO - 2024-09-06 02:40:54 --> Helper loaded: security_helper
INFO - 2024-09-06 02:40:54 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:40:54 --> Database Driver Class Initialized
INFO - 2024-09-06 02:40:54 --> Email Class Initialized
DEBUG - 2024-09-06 02:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:40:54 --> Helper loaded: form_helper
INFO - 2024-09-06 02:40:54 --> Form Validation Class Initialized
INFO - 2024-09-06 02:40:54 --> Controller Class Initialized
INFO - 2024-09-06 02:40:54 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:40:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:40:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:40:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:40:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:40:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:40:55 --> Final output sent to browser
DEBUG - 2024-09-06 02:40:55 --> Total execution time: 0.6058
INFO - 2024-09-06 02:44:53 --> Config Class Initialized
INFO - 2024-09-06 02:44:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:44:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:44:53 --> Utf8 Class Initialized
INFO - 2024-09-06 02:44:53 --> URI Class Initialized
DEBUG - 2024-09-06 02:44:53 --> No URI present. Default controller set.
INFO - 2024-09-06 02:44:53 --> Router Class Initialized
INFO - 2024-09-06 02:44:53 --> Output Class Initialized
INFO - 2024-09-06 02:44:53 --> Security Class Initialized
DEBUG - 2024-09-06 02:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:44:53 --> Input Class Initialized
INFO - 2024-09-06 02:44:53 --> Language Class Initialized
INFO - 2024-09-06 02:44:53 --> Loader Class Initialized
INFO - 2024-09-06 02:44:53 --> Helper loaded: url_helper
INFO - 2024-09-06 02:44:53 --> Helper loaded: file_helper
INFO - 2024-09-06 02:44:53 --> Helper loaded: security_helper
INFO - 2024-09-06 02:44:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:44:53 --> Database Driver Class Initialized
INFO - 2024-09-06 02:44:53 --> Email Class Initialized
DEBUG - 2024-09-06 02:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:44:53 --> Helper loaded: form_helper
INFO - 2024-09-06 02:44:53 --> Form Validation Class Initialized
INFO - 2024-09-06 02:44:53 --> Controller Class Initialized
DEBUG - 2024-09-06 02:44:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:44:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 02:44:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 02:44:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 02:44:53 --> Final output sent to browser
DEBUG - 2024-09-06 02:44:53 --> Total execution time: 0.2223
INFO - 2024-09-06 02:45:32 --> Config Class Initialized
INFO - 2024-09-06 02:45:32 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:45:32 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:45:32 --> Utf8 Class Initialized
INFO - 2024-09-06 02:45:32 --> URI Class Initialized
INFO - 2024-09-06 02:45:32 --> Router Class Initialized
INFO - 2024-09-06 02:45:32 --> Output Class Initialized
INFO - 2024-09-06 02:45:32 --> Security Class Initialized
DEBUG - 2024-09-06 02:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:45:32 --> Input Class Initialized
INFO - 2024-09-06 02:45:32 --> Language Class Initialized
INFO - 2024-09-06 02:45:32 --> Loader Class Initialized
INFO - 2024-09-06 02:45:32 --> Helper loaded: url_helper
INFO - 2024-09-06 02:45:32 --> Helper loaded: file_helper
INFO - 2024-09-06 02:45:32 --> Helper loaded: security_helper
INFO - 2024-09-06 02:45:32 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:45:32 --> Database Driver Class Initialized
INFO - 2024-09-06 02:45:32 --> Email Class Initialized
DEBUG - 2024-09-06 02:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:45:32 --> Helper loaded: form_helper
INFO - 2024-09-06 02:45:32 --> Form Validation Class Initialized
INFO - 2024-09-06 02:45:32 --> Controller Class Initialized
INFO - 2024-09-06 02:45:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:45:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:45:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:45:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:45:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:45:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:45:32 --> Final output sent to browser
DEBUG - 2024-09-06 02:45:32 --> Total execution time: 0.6036
INFO - 2024-09-06 02:46:35 --> Config Class Initialized
INFO - 2024-09-06 02:46:35 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:46:35 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:46:35 --> Utf8 Class Initialized
INFO - 2024-09-06 02:46:35 --> URI Class Initialized
INFO - 2024-09-06 02:46:35 --> Router Class Initialized
INFO - 2024-09-06 02:46:35 --> Output Class Initialized
INFO - 2024-09-06 02:46:35 --> Security Class Initialized
DEBUG - 2024-09-06 02:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:46:35 --> Input Class Initialized
INFO - 2024-09-06 02:46:35 --> Language Class Initialized
INFO - 2024-09-06 02:46:35 --> Loader Class Initialized
INFO - 2024-09-06 02:46:35 --> Helper loaded: url_helper
INFO - 2024-09-06 02:46:35 --> Helper loaded: file_helper
INFO - 2024-09-06 02:46:35 --> Helper loaded: security_helper
INFO - 2024-09-06 02:46:35 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:46:35 --> Database Driver Class Initialized
INFO - 2024-09-06 02:46:36 --> Email Class Initialized
DEBUG - 2024-09-06 02:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:46:36 --> Helper loaded: form_helper
INFO - 2024-09-06 02:46:36 --> Form Validation Class Initialized
INFO - 2024-09-06 02:46:36 --> Controller Class Initialized
INFO - 2024-09-06 02:46:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:46:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:46:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:46:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:46:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:46:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:46:36 --> Final output sent to browser
DEBUG - 2024-09-06 02:46:36 --> Total execution time: 0.6089
INFO - 2024-09-06 02:46:49 --> Config Class Initialized
INFO - 2024-09-06 02:46:49 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:46:49 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:46:49 --> Utf8 Class Initialized
INFO - 2024-09-06 02:46:49 --> URI Class Initialized
INFO - 2024-09-06 02:46:49 --> Router Class Initialized
INFO - 2024-09-06 02:46:49 --> Output Class Initialized
INFO - 2024-09-06 02:46:49 --> Security Class Initialized
DEBUG - 2024-09-06 02:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:46:49 --> Input Class Initialized
INFO - 2024-09-06 02:46:49 --> Language Class Initialized
INFO - 2024-09-06 02:46:49 --> Loader Class Initialized
INFO - 2024-09-06 02:46:49 --> Helper loaded: url_helper
INFO - 2024-09-06 02:46:49 --> Helper loaded: file_helper
INFO - 2024-09-06 02:46:49 --> Helper loaded: security_helper
INFO - 2024-09-06 02:46:49 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:46:49 --> Database Driver Class Initialized
INFO - 2024-09-06 02:46:49 --> Email Class Initialized
DEBUG - 2024-09-06 02:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:46:49 --> Helper loaded: form_helper
INFO - 2024-09-06 02:46:49 --> Form Validation Class Initialized
INFO - 2024-09-06 02:46:49 --> Controller Class Initialized
INFO - 2024-09-06 02:46:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:46:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:46:50 --> Final output sent to browser
DEBUG - 2024-09-06 02:46:50 --> Total execution time: 0.6574
INFO - 2024-09-06 02:48:23 --> Config Class Initialized
INFO - 2024-09-06 02:48:23 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:48:23 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:48:23 --> Utf8 Class Initialized
INFO - 2024-09-06 02:48:23 --> URI Class Initialized
INFO - 2024-09-06 02:48:23 --> Router Class Initialized
INFO - 2024-09-06 02:48:23 --> Output Class Initialized
INFO - 2024-09-06 02:48:23 --> Security Class Initialized
DEBUG - 2024-09-06 02:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:48:23 --> Input Class Initialized
INFO - 2024-09-06 02:48:23 --> Language Class Initialized
INFO - 2024-09-06 02:48:23 --> Loader Class Initialized
INFO - 2024-09-06 02:48:23 --> Helper loaded: url_helper
INFO - 2024-09-06 02:48:23 --> Helper loaded: file_helper
INFO - 2024-09-06 02:48:23 --> Helper loaded: security_helper
INFO - 2024-09-06 02:48:23 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:48:23 --> Database Driver Class Initialized
INFO - 2024-09-06 02:48:23 --> Email Class Initialized
DEBUG - 2024-09-06 02:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:48:23 --> Helper loaded: form_helper
INFO - 2024-09-06 02:48:23 --> Form Validation Class Initialized
INFO - 2024-09-06 02:48:23 --> Controller Class Initialized
INFO - 2024-09-06 02:48:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:48:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:48:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:48:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:48:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:48:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:48:24 --> Final output sent to browser
DEBUG - 2024-09-06 02:48:24 --> Total execution time: 0.9237
INFO - 2024-09-06 02:48:51 --> Config Class Initialized
INFO - 2024-09-06 02:48:51 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:48:51 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:48:51 --> Utf8 Class Initialized
INFO - 2024-09-06 02:48:51 --> URI Class Initialized
INFO - 2024-09-06 02:48:51 --> Router Class Initialized
INFO - 2024-09-06 02:48:51 --> Output Class Initialized
INFO - 2024-09-06 02:48:51 --> Security Class Initialized
DEBUG - 2024-09-06 02:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:48:51 --> Input Class Initialized
INFO - 2024-09-06 02:48:51 --> Language Class Initialized
INFO - 2024-09-06 02:48:51 --> Loader Class Initialized
INFO - 2024-09-06 02:48:51 --> Helper loaded: url_helper
INFO - 2024-09-06 02:48:51 --> Helper loaded: file_helper
INFO - 2024-09-06 02:48:51 --> Helper loaded: security_helper
INFO - 2024-09-06 02:48:51 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:48:51 --> Database Driver Class Initialized
INFO - 2024-09-06 02:48:51 --> Email Class Initialized
DEBUG - 2024-09-06 02:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:48:51 --> Helper loaded: form_helper
INFO - 2024-09-06 02:48:51 --> Form Validation Class Initialized
INFO - 2024-09-06 02:48:51 --> Controller Class Initialized
INFO - 2024-09-06 02:48:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:48:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:48:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:48:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:48:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:48:51 --> Final output sent to browser
DEBUG - 2024-09-06 02:48:51 --> Total execution time: 0.5303
INFO - 2024-09-06 02:49:04 --> Config Class Initialized
INFO - 2024-09-06 02:49:04 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:49:04 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:49:04 --> Utf8 Class Initialized
INFO - 2024-09-06 02:49:04 --> URI Class Initialized
INFO - 2024-09-06 02:49:04 --> Router Class Initialized
INFO - 2024-09-06 02:49:04 --> Output Class Initialized
INFO - 2024-09-06 02:49:04 --> Security Class Initialized
DEBUG - 2024-09-06 02:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:49:04 --> Input Class Initialized
INFO - 2024-09-06 02:49:04 --> Language Class Initialized
INFO - 2024-09-06 02:49:04 --> Loader Class Initialized
INFO - 2024-09-06 02:49:04 --> Helper loaded: url_helper
INFO - 2024-09-06 02:49:04 --> Helper loaded: file_helper
INFO - 2024-09-06 02:49:04 --> Helper loaded: security_helper
INFO - 2024-09-06 02:49:04 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:49:04 --> Database Driver Class Initialized
INFO - 2024-09-06 02:49:05 --> Email Class Initialized
DEBUG - 2024-09-06 02:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:49:05 --> Helper loaded: form_helper
INFO - 2024-09-06 02:49:05 --> Form Validation Class Initialized
INFO - 2024-09-06 02:49:05 --> Controller Class Initialized
INFO - 2024-09-06 02:49:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:49:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:49:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:49:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:49:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:49:05 --> Final output sent to browser
DEBUG - 2024-09-06 02:49:05 --> Total execution time: 0.9399
INFO - 2024-09-06 02:49:16 --> Config Class Initialized
INFO - 2024-09-06 02:49:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:49:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:49:16 --> Utf8 Class Initialized
INFO - 2024-09-06 02:49:16 --> URI Class Initialized
INFO - 2024-09-06 02:49:16 --> Router Class Initialized
INFO - 2024-09-06 02:49:16 --> Output Class Initialized
INFO - 2024-09-06 02:49:16 --> Security Class Initialized
DEBUG - 2024-09-06 02:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:49:16 --> Input Class Initialized
INFO - 2024-09-06 02:49:16 --> Language Class Initialized
INFO - 2024-09-06 02:49:16 --> Loader Class Initialized
INFO - 2024-09-06 02:49:16 --> Helper loaded: url_helper
INFO - 2024-09-06 02:49:16 --> Helper loaded: file_helper
INFO - 2024-09-06 02:49:16 --> Helper loaded: security_helper
INFO - 2024-09-06 02:49:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:49:16 --> Database Driver Class Initialized
INFO - 2024-09-06 02:49:17 --> Email Class Initialized
DEBUG - 2024-09-06 02:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:49:17 --> Helper loaded: form_helper
INFO - 2024-09-06 02:49:17 --> Form Validation Class Initialized
INFO - 2024-09-06 02:49:17 --> Controller Class Initialized
INFO - 2024-09-06 02:49:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:49:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:49:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:49:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:49:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:49:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:49:17 --> Final output sent to browser
DEBUG - 2024-09-06 02:49:17 --> Total execution time: 0.6122
INFO - 2024-09-06 02:50:08 --> Config Class Initialized
INFO - 2024-09-06 02:50:08 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:50:08 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:50:08 --> Utf8 Class Initialized
INFO - 2024-09-06 02:50:08 --> URI Class Initialized
INFO - 2024-09-06 02:50:08 --> Router Class Initialized
INFO - 2024-09-06 02:50:08 --> Output Class Initialized
INFO - 2024-09-06 02:50:08 --> Security Class Initialized
DEBUG - 2024-09-06 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:50:08 --> Input Class Initialized
INFO - 2024-09-06 02:50:08 --> Language Class Initialized
INFO - 2024-09-06 02:50:08 --> Loader Class Initialized
INFO - 2024-09-06 02:50:08 --> Helper loaded: url_helper
INFO - 2024-09-06 02:50:08 --> Helper loaded: file_helper
INFO - 2024-09-06 02:50:08 --> Helper loaded: security_helper
INFO - 2024-09-06 02:50:08 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:50:08 --> Database Driver Class Initialized
INFO - 2024-09-06 02:50:08 --> Email Class Initialized
DEBUG - 2024-09-06 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:50:08 --> Helper loaded: form_helper
INFO - 2024-09-06 02:50:08 --> Form Validation Class Initialized
INFO - 2024-09-06 02:50:08 --> Controller Class Initialized
INFO - 2024-09-06 02:50:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:50:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:50:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:50:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:50:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:50:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:50:08 --> Final output sent to browser
DEBUG - 2024-09-06 02:50:08 --> Total execution time: 0.5635
INFO - 2024-09-06 02:50:49 --> Config Class Initialized
INFO - 2024-09-06 02:50:49 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:50:49 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:50:49 --> Utf8 Class Initialized
INFO - 2024-09-06 02:50:49 --> URI Class Initialized
INFO - 2024-09-06 02:50:49 --> Router Class Initialized
INFO - 2024-09-06 02:50:49 --> Output Class Initialized
INFO - 2024-09-06 02:50:49 --> Security Class Initialized
DEBUG - 2024-09-06 02:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:50:49 --> Input Class Initialized
INFO - 2024-09-06 02:50:49 --> Language Class Initialized
INFO - 2024-09-06 02:50:49 --> Loader Class Initialized
INFO - 2024-09-06 02:50:49 --> Helper loaded: url_helper
INFO - 2024-09-06 02:50:49 --> Helper loaded: file_helper
INFO - 2024-09-06 02:50:49 --> Helper loaded: security_helper
INFO - 2024-09-06 02:50:49 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:50:49 --> Database Driver Class Initialized
INFO - 2024-09-06 02:50:49 --> Email Class Initialized
DEBUG - 2024-09-06 02:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:50:49 --> Helper loaded: form_helper
INFO - 2024-09-06 02:50:49 --> Form Validation Class Initialized
INFO - 2024-09-06 02:50:49 --> Controller Class Initialized
INFO - 2024-09-06 02:50:49 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:50:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:50:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:50:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:50:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-06 02:50:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:50:49 --> Final output sent to browser
DEBUG - 2024-09-06 02:50:49 --> Total execution time: 0.6129
INFO - 2024-09-06 02:50:55 --> Config Class Initialized
INFO - 2024-09-06 02:50:55 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:50:55 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:50:55 --> Utf8 Class Initialized
INFO - 2024-09-06 02:50:55 --> URI Class Initialized
INFO - 2024-09-06 02:50:55 --> Router Class Initialized
INFO - 2024-09-06 02:50:55 --> Output Class Initialized
INFO - 2024-09-06 02:50:55 --> Security Class Initialized
DEBUG - 2024-09-06 02:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:50:55 --> Input Class Initialized
INFO - 2024-09-06 02:50:55 --> Language Class Initialized
INFO - 2024-09-06 02:50:55 --> Loader Class Initialized
INFO - 2024-09-06 02:50:55 --> Helper loaded: url_helper
INFO - 2024-09-06 02:50:55 --> Helper loaded: file_helper
INFO - 2024-09-06 02:50:55 --> Helper loaded: security_helper
INFO - 2024-09-06 02:50:55 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:50:55 --> Database Driver Class Initialized
INFO - 2024-09-06 02:50:55 --> Email Class Initialized
DEBUG - 2024-09-06 02:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:50:55 --> Helper loaded: form_helper
INFO - 2024-09-06 02:50:55 --> Form Validation Class Initialized
INFO - 2024-09-06 02:50:55 --> Controller Class Initialized
INFO - 2024-09-06 02:50:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:50:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:50:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:50:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:50:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:50:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:50:56 --> Final output sent to browser
DEBUG - 2024-09-06 02:50:56 --> Total execution time: 0.6870
INFO - 2024-09-06 02:51:15 --> Config Class Initialized
INFO - 2024-09-06 02:51:15 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:51:15 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:51:15 --> Utf8 Class Initialized
INFO - 2024-09-06 02:51:15 --> URI Class Initialized
INFO - 2024-09-06 02:51:15 --> Router Class Initialized
INFO - 2024-09-06 02:51:15 --> Output Class Initialized
INFO - 2024-09-06 02:51:15 --> Security Class Initialized
DEBUG - 2024-09-06 02:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:51:15 --> Input Class Initialized
INFO - 2024-09-06 02:51:15 --> Language Class Initialized
INFO - 2024-09-06 02:51:15 --> Loader Class Initialized
INFO - 2024-09-06 02:51:15 --> Helper loaded: url_helper
INFO - 2024-09-06 02:51:15 --> Helper loaded: file_helper
INFO - 2024-09-06 02:51:15 --> Helper loaded: security_helper
INFO - 2024-09-06 02:51:15 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:51:15 --> Database Driver Class Initialized
INFO - 2024-09-06 02:51:15 --> Email Class Initialized
DEBUG - 2024-09-06 02:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:51:15 --> Helper loaded: form_helper
INFO - 2024-09-06 02:51:15 --> Form Validation Class Initialized
INFO - 2024-09-06 02:51:15 --> Controller Class Initialized
INFO - 2024-09-06 02:51:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-06 02:51:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2' at line 1 - Invalid query: SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2024-09-07'
                AND `tanggal_periksa` <= '2024-09-21'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            
INFO - 2024-09-06 02:51:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-06 02:51:22 --> Config Class Initialized
INFO - 2024-09-06 02:51:22 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:51:22 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:51:22 --> Utf8 Class Initialized
INFO - 2024-09-06 02:51:22 --> URI Class Initialized
INFO - 2024-09-06 02:51:22 --> Router Class Initialized
INFO - 2024-09-06 02:51:22 --> Output Class Initialized
INFO - 2024-09-06 02:51:22 --> Security Class Initialized
DEBUG - 2024-09-06 02:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:51:22 --> Input Class Initialized
INFO - 2024-09-06 02:51:22 --> Language Class Initialized
INFO - 2024-09-06 02:51:22 --> Loader Class Initialized
INFO - 2024-09-06 02:51:22 --> Helper loaded: url_helper
INFO - 2024-09-06 02:51:22 --> Helper loaded: file_helper
INFO - 2024-09-06 02:51:22 --> Helper loaded: security_helper
INFO - 2024-09-06 02:51:22 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:51:22 --> Database Driver Class Initialized
INFO - 2024-09-06 02:51:23 --> Email Class Initialized
DEBUG - 2024-09-06 02:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:51:23 --> Helper loaded: form_helper
INFO - 2024-09-06 02:51:23 --> Form Validation Class Initialized
INFO - 2024-09-06 02:51:23 --> Controller Class Initialized
INFO - 2024-09-06 02:51:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:51:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:51:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:51:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:51:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:51:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:51:23 --> Final output sent to browser
DEBUG - 2024-09-06 02:51:23 --> Total execution time: 0.9299
INFO - 2024-09-06 02:51:37 --> Config Class Initialized
INFO - 2024-09-06 02:51:37 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:51:37 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:51:37 --> Utf8 Class Initialized
INFO - 2024-09-06 02:51:37 --> URI Class Initialized
INFO - 2024-09-06 02:51:37 --> Router Class Initialized
INFO - 2024-09-06 02:51:37 --> Output Class Initialized
INFO - 2024-09-06 02:51:37 --> Security Class Initialized
DEBUG - 2024-09-06 02:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:51:37 --> Input Class Initialized
INFO - 2024-09-06 02:51:37 --> Language Class Initialized
INFO - 2024-09-06 02:51:37 --> Loader Class Initialized
INFO - 2024-09-06 02:51:37 --> Helper loaded: url_helper
INFO - 2024-09-06 02:51:37 --> Helper loaded: file_helper
INFO - 2024-09-06 02:51:37 --> Helper loaded: security_helper
INFO - 2024-09-06 02:51:37 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:51:37 --> Database Driver Class Initialized
INFO - 2024-09-06 02:51:38 --> Email Class Initialized
DEBUG - 2024-09-06 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:51:38 --> Helper loaded: form_helper
INFO - 2024-09-06 02:51:38 --> Form Validation Class Initialized
INFO - 2024-09-06 02:51:38 --> Controller Class Initialized
INFO - 2024-09-06 02:51:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:51:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-06 02:51:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2' at line 1 - Invalid query: SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2024-09-01'
                AND `tanggal_periksa` <= '2024-09-08'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            
INFO - 2024-09-06 02:51:38 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-06 02:51:53 --> Config Class Initialized
INFO - 2024-09-06 02:51:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:51:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:51:53 --> Utf8 Class Initialized
INFO - 2024-09-06 02:51:53 --> URI Class Initialized
INFO - 2024-09-06 02:51:53 --> Router Class Initialized
INFO - 2024-09-06 02:51:53 --> Output Class Initialized
INFO - 2024-09-06 02:51:53 --> Security Class Initialized
DEBUG - 2024-09-06 02:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:51:53 --> Input Class Initialized
INFO - 2024-09-06 02:51:53 --> Language Class Initialized
INFO - 2024-09-06 02:51:53 --> Loader Class Initialized
INFO - 2024-09-06 02:51:53 --> Helper loaded: url_helper
INFO - 2024-09-06 02:51:53 --> Helper loaded: file_helper
INFO - 2024-09-06 02:51:53 --> Helper loaded: security_helper
INFO - 2024-09-06 02:51:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:51:53 --> Database Driver Class Initialized
INFO - 2024-09-06 02:51:53 --> Email Class Initialized
DEBUG - 2024-09-06 02:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:51:53 --> Helper loaded: form_helper
INFO - 2024-09-06 02:51:53 --> Form Validation Class Initialized
INFO - 2024-09-06 02:51:53 --> Controller Class Initialized
INFO - 2024-09-06 02:51:53 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:51:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:51:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:51:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:51:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:51:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:51:54 --> Final output sent to browser
DEBUG - 2024-09-06 02:51:54 --> Total execution time: 0.6568
INFO - 2024-09-06 02:51:58 --> Config Class Initialized
INFO - 2024-09-06 02:51:58 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:51:58 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:51:58 --> Utf8 Class Initialized
INFO - 2024-09-06 02:51:58 --> URI Class Initialized
INFO - 2024-09-06 02:51:58 --> Router Class Initialized
INFO - 2024-09-06 02:51:58 --> Output Class Initialized
INFO - 2024-09-06 02:51:58 --> Security Class Initialized
DEBUG - 2024-09-06 02:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:51:58 --> Input Class Initialized
INFO - 2024-09-06 02:51:58 --> Language Class Initialized
INFO - 2024-09-06 02:51:58 --> Loader Class Initialized
INFO - 2024-09-06 02:51:58 --> Helper loaded: url_helper
INFO - 2024-09-06 02:51:58 --> Helper loaded: file_helper
INFO - 2024-09-06 02:51:58 --> Helper loaded: security_helper
INFO - 2024-09-06 02:51:58 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:51:58 --> Database Driver Class Initialized
INFO - 2024-09-06 02:51:58 --> Email Class Initialized
DEBUG - 2024-09-06 02:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:51:58 --> Helper loaded: form_helper
INFO - 2024-09-06 02:51:58 --> Form Validation Class Initialized
INFO - 2024-09-06 02:51:58 --> Controller Class Initialized
INFO - 2024-09-06 02:51:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:51:58 --> Final output sent to browser
DEBUG - 2024-09-06 02:51:58 --> Total execution time: 0.5825
INFO - 2024-09-06 02:52:04 --> Config Class Initialized
INFO - 2024-09-06 02:52:04 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:52:04 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:52:04 --> Utf8 Class Initialized
INFO - 2024-09-06 02:52:04 --> URI Class Initialized
INFO - 2024-09-06 02:52:04 --> Router Class Initialized
INFO - 2024-09-06 02:52:04 --> Output Class Initialized
INFO - 2024-09-06 02:52:04 --> Security Class Initialized
DEBUG - 2024-09-06 02:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:52:04 --> Input Class Initialized
INFO - 2024-09-06 02:52:04 --> Language Class Initialized
INFO - 2024-09-06 02:52:04 --> Loader Class Initialized
INFO - 2024-09-06 02:52:04 --> Helper loaded: url_helper
INFO - 2024-09-06 02:52:04 --> Helper loaded: file_helper
INFO - 2024-09-06 02:52:04 --> Helper loaded: security_helper
INFO - 2024-09-06 02:52:04 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:52:04 --> Database Driver Class Initialized
INFO - 2024-09-06 02:52:04 --> Email Class Initialized
DEBUG - 2024-09-06 02:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:52:04 --> Helper loaded: form_helper
INFO - 2024-09-06 02:52:04 --> Form Validation Class Initialized
INFO - 2024-09-06 02:52:04 --> Controller Class Initialized
INFO - 2024-09-06 02:52:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:52:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-06 02:52:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2' at line 1 - Invalid query: SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2024-09-01'
                AND `tanggal_periksa` <= '2024-09-06'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            
INFO - 2024-09-06 02:52:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-06 02:52:13 --> Config Class Initialized
INFO - 2024-09-06 02:52:13 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:52:13 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:52:13 --> Utf8 Class Initialized
INFO - 2024-09-06 02:52:13 --> URI Class Initialized
INFO - 2024-09-06 02:52:13 --> Router Class Initialized
INFO - 2024-09-06 02:52:13 --> Output Class Initialized
INFO - 2024-09-06 02:52:13 --> Security Class Initialized
DEBUG - 2024-09-06 02:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:52:13 --> Input Class Initialized
INFO - 2024-09-06 02:52:13 --> Language Class Initialized
INFO - 2024-09-06 02:52:13 --> Loader Class Initialized
INFO - 2024-09-06 02:52:13 --> Helper loaded: url_helper
INFO - 2024-09-06 02:52:13 --> Helper loaded: file_helper
INFO - 2024-09-06 02:52:13 --> Helper loaded: security_helper
INFO - 2024-09-06 02:52:13 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:52:13 --> Database Driver Class Initialized
INFO - 2024-09-06 02:52:13 --> Email Class Initialized
DEBUG - 2024-09-06 02:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:52:13 --> Helper loaded: form_helper
INFO - 2024-09-06 02:52:13 --> Form Validation Class Initialized
INFO - 2024-09-06 02:52:13 --> Controller Class Initialized
INFO - 2024-09-06 02:52:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:52:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-06 02:52:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2' at line 1 - Invalid query: SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2024-09-01'
                AND `tanggal_periksa` <= '2024-09-06'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            
INFO - 2024-09-06 02:52:13 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-06 02:53:18 --> Config Class Initialized
INFO - 2024-09-06 02:53:18 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:53:18 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:53:18 --> Utf8 Class Initialized
INFO - 2024-09-06 02:53:18 --> URI Class Initialized
INFO - 2024-09-06 02:53:18 --> Router Class Initialized
INFO - 2024-09-06 02:53:18 --> Output Class Initialized
INFO - 2024-09-06 02:53:18 --> Security Class Initialized
DEBUG - 2024-09-06 02:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:53:18 --> Input Class Initialized
INFO - 2024-09-06 02:53:18 --> Language Class Initialized
INFO - 2024-09-06 02:53:18 --> Loader Class Initialized
INFO - 2024-09-06 02:53:18 --> Helper loaded: url_helper
INFO - 2024-09-06 02:53:18 --> Helper loaded: file_helper
INFO - 2024-09-06 02:53:18 --> Helper loaded: security_helper
INFO - 2024-09-06 02:53:18 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:53:18 --> Database Driver Class Initialized
INFO - 2024-09-06 02:53:18 --> Email Class Initialized
DEBUG - 2024-09-06 02:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:53:18 --> Helper loaded: form_helper
INFO - 2024-09-06 02:53:18 --> Form Validation Class Initialized
INFO - 2024-09-06 02:53:18 --> Controller Class Initialized
INFO - 2024-09-06 02:53:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:53:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:53:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:53:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:53:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:53:19 --> Final output sent to browser
DEBUG - 2024-09-06 02:53:19 --> Total execution time: 0.6549
INFO - 2024-09-06 02:53:31 --> Config Class Initialized
INFO - 2024-09-06 02:53:31 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:53:31 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:53:31 --> Utf8 Class Initialized
INFO - 2024-09-06 02:53:31 --> URI Class Initialized
INFO - 2024-09-06 02:53:31 --> Router Class Initialized
INFO - 2024-09-06 02:53:31 --> Output Class Initialized
INFO - 2024-09-06 02:53:31 --> Security Class Initialized
DEBUG - 2024-09-06 02:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:53:31 --> Input Class Initialized
INFO - 2024-09-06 02:53:31 --> Language Class Initialized
INFO - 2024-09-06 02:53:31 --> Loader Class Initialized
INFO - 2024-09-06 02:53:31 --> Helper loaded: url_helper
INFO - 2024-09-06 02:53:31 --> Helper loaded: file_helper
INFO - 2024-09-06 02:53:31 --> Helper loaded: security_helper
INFO - 2024-09-06 02:53:31 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:53:31 --> Database Driver Class Initialized
INFO - 2024-09-06 02:53:31 --> Email Class Initialized
DEBUG - 2024-09-06 02:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:53:31 --> Helper loaded: form_helper
INFO - 2024-09-06 02:53:31 --> Form Validation Class Initialized
INFO - 2024-09-06 02:53:31 --> Controller Class Initialized
INFO - 2024-09-06 02:53:31 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:53:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-06 02:53:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2' at line 1 - Invalid query: SELECT COUNT (*) FROM `mlite_antrian_referensi`
                WHERE `tanggal_periksa` >= '2024-09-01'
                AND `tanggal_periksa` <= '2024-09-06'
                AND keterangan NOT IN ('Terdapat duplikasi Kode Booking', '208: Terdapat duplikasi Kode Booking')
            
INFO - 2024-09-06 02:53:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-06 02:54:56 --> Config Class Initialized
INFO - 2024-09-06 02:54:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:54:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:54:56 --> Utf8 Class Initialized
INFO - 2024-09-06 02:54:56 --> URI Class Initialized
INFO - 2024-09-06 02:54:56 --> Router Class Initialized
INFO - 2024-09-06 02:54:56 --> Output Class Initialized
INFO - 2024-09-06 02:54:56 --> Security Class Initialized
DEBUG - 2024-09-06 02:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:54:56 --> Input Class Initialized
INFO - 2024-09-06 02:54:56 --> Language Class Initialized
INFO - 2024-09-06 02:54:56 --> Loader Class Initialized
INFO - 2024-09-06 02:54:56 --> Helper loaded: url_helper
INFO - 2024-09-06 02:54:56 --> Helper loaded: file_helper
INFO - 2024-09-06 02:54:56 --> Helper loaded: security_helper
INFO - 2024-09-06 02:54:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:54:56 --> Database Driver Class Initialized
INFO - 2024-09-06 02:54:56 --> Email Class Initialized
DEBUG - 2024-09-06 02:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:54:56 --> Helper loaded: form_helper
INFO - 2024-09-06 02:54:56 --> Form Validation Class Initialized
INFO - 2024-09-06 02:54:56 --> Controller Class Initialized
INFO - 2024-09-06 02:54:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:54:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:54:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:54:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:54:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:54:57 --> Final output sent to browser
DEBUG - 2024-09-06 02:54:57 --> Total execution time: 0.7292
INFO - 2024-09-06 02:55:05 --> Config Class Initialized
INFO - 2024-09-06 02:55:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:55:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:55:05 --> Utf8 Class Initialized
INFO - 2024-09-06 02:55:05 --> URI Class Initialized
INFO - 2024-09-06 02:55:05 --> Router Class Initialized
INFO - 2024-09-06 02:55:05 --> Output Class Initialized
INFO - 2024-09-06 02:55:05 --> Security Class Initialized
DEBUG - 2024-09-06 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:55:05 --> Input Class Initialized
INFO - 2024-09-06 02:55:05 --> Language Class Initialized
INFO - 2024-09-06 02:55:05 --> Loader Class Initialized
INFO - 2024-09-06 02:55:05 --> Helper loaded: url_helper
INFO - 2024-09-06 02:55:05 --> Helper loaded: file_helper
INFO - 2024-09-06 02:55:05 --> Helper loaded: security_helper
INFO - 2024-09-06 02:55:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:55:05 --> Database Driver Class Initialized
INFO - 2024-09-06 02:55:05 --> Email Class Initialized
DEBUG - 2024-09-06 02:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:55:05 --> Helper loaded: form_helper
INFO - 2024-09-06 02:55:05 --> Form Validation Class Initialized
INFO - 2024-09-06 02:55:05 --> Controller Class Initialized
INFO - 2024-09-06 02:55:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:55:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:55:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:55:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:55:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:55:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:55:06 --> Final output sent to browser
DEBUG - 2024-09-06 02:55:06 --> Total execution time: 1.3235
INFO - 2024-09-06 02:55:47 --> Config Class Initialized
INFO - 2024-09-06 02:55:47 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:55:47 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:55:47 --> Utf8 Class Initialized
INFO - 2024-09-06 02:55:47 --> URI Class Initialized
INFO - 2024-09-06 02:55:47 --> Router Class Initialized
INFO - 2024-09-06 02:55:47 --> Output Class Initialized
INFO - 2024-09-06 02:55:47 --> Security Class Initialized
DEBUG - 2024-09-06 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:55:47 --> Input Class Initialized
INFO - 2024-09-06 02:55:47 --> Language Class Initialized
INFO - 2024-09-06 02:55:47 --> Loader Class Initialized
INFO - 2024-09-06 02:55:47 --> Helper loaded: url_helper
INFO - 2024-09-06 02:55:47 --> Helper loaded: file_helper
INFO - 2024-09-06 02:55:47 --> Helper loaded: security_helper
INFO - 2024-09-06 02:55:47 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:55:47 --> Database Driver Class Initialized
INFO - 2024-09-06 02:55:48 --> Email Class Initialized
DEBUG - 2024-09-06 02:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:55:48 --> Helper loaded: form_helper
INFO - 2024-09-06 02:55:48 --> Form Validation Class Initialized
INFO - 2024-09-06 02:55:48 --> Controller Class Initialized
INFO - 2024-09-06 02:55:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:55:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:55:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:55:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:55:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:55:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:55:49 --> Final output sent to browser
DEBUG - 2024-09-06 02:55:49 --> Total execution time: 1.2676
INFO - 2024-09-06 02:55:58 --> Config Class Initialized
INFO - 2024-09-06 02:55:58 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:55:58 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:55:58 --> Utf8 Class Initialized
INFO - 2024-09-06 02:55:58 --> URI Class Initialized
INFO - 2024-09-06 02:55:58 --> Router Class Initialized
INFO - 2024-09-06 02:55:58 --> Output Class Initialized
INFO - 2024-09-06 02:55:58 --> Security Class Initialized
DEBUG - 2024-09-06 02:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:55:58 --> Input Class Initialized
INFO - 2024-09-06 02:55:58 --> Language Class Initialized
INFO - 2024-09-06 02:55:58 --> Loader Class Initialized
INFO - 2024-09-06 02:55:58 --> Helper loaded: url_helper
INFO - 2024-09-06 02:55:58 --> Helper loaded: file_helper
INFO - 2024-09-06 02:55:58 --> Helper loaded: security_helper
INFO - 2024-09-06 02:55:58 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:55:58 --> Database Driver Class Initialized
INFO - 2024-09-06 02:55:58 --> Email Class Initialized
DEBUG - 2024-09-06 02:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:55:58 --> Helper loaded: form_helper
INFO - 2024-09-06 02:55:58 --> Form Validation Class Initialized
INFO - 2024-09-06 02:55:58 --> Controller Class Initialized
INFO - 2024-09-06 02:55:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:55:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:55:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-06 02:55:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-06 02:55:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-06 02:55:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-06 02:55:59 --> Final output sent to browser
DEBUG - 2024-09-06 02:55:59 --> Total execution time: 0.6446
INFO - 2024-09-06 02:56:04 --> Config Class Initialized
INFO - 2024-09-06 02:56:04 --> Hooks Class Initialized
DEBUG - 2024-09-06 02:56:04 --> UTF-8 Support Enabled
INFO - 2024-09-06 02:56:04 --> Utf8 Class Initialized
INFO - 2024-09-06 02:56:04 --> URI Class Initialized
INFO - 2024-09-06 02:56:04 --> Router Class Initialized
INFO - 2024-09-06 02:56:04 --> Output Class Initialized
INFO - 2024-09-06 02:56:04 --> Security Class Initialized
DEBUG - 2024-09-06 02:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 02:56:04 --> Input Class Initialized
INFO - 2024-09-06 02:56:04 --> Language Class Initialized
INFO - 2024-09-06 02:56:04 --> Loader Class Initialized
INFO - 2024-09-06 02:56:04 --> Helper loaded: url_helper
INFO - 2024-09-06 02:56:04 --> Helper loaded: file_helper
INFO - 2024-09-06 02:56:04 --> Helper loaded: security_helper
INFO - 2024-09-06 02:56:04 --> Helper loaded: wpu_helper
INFO - 2024-09-06 02:56:04 --> Database Driver Class Initialized
INFO - 2024-09-06 02:56:05 --> Email Class Initialized
DEBUG - 2024-09-06 02:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 02:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 02:56:05 --> Helper loaded: form_helper
INFO - 2024-09-06 02:56:05 --> Form Validation Class Initialized
INFO - 2024-09-06 02:56:05 --> Controller Class Initialized
INFO - 2024-09-06 02:56:05 --> Model "Antrol_model" initialized
DEBUG - 2024-09-06 02:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 02:56:05 --> Final output sent to browser
DEBUG - 2024-09-06 02:56:05 --> Total execution time: 0.9876
INFO - 2024-09-06 03:12:53 --> Config Class Initialized
INFO - 2024-09-06 03:12:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 03:12:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 03:12:53 --> Utf8 Class Initialized
INFO - 2024-09-06 03:12:53 --> URI Class Initialized
DEBUG - 2024-09-06 03:12:53 --> No URI present. Default controller set.
INFO - 2024-09-06 03:12:53 --> Router Class Initialized
INFO - 2024-09-06 03:12:53 --> Output Class Initialized
INFO - 2024-09-06 03:12:53 --> Security Class Initialized
DEBUG - 2024-09-06 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 03:12:53 --> Input Class Initialized
INFO - 2024-09-06 03:12:53 --> Language Class Initialized
INFO - 2024-09-06 03:12:53 --> Loader Class Initialized
INFO - 2024-09-06 03:12:53 --> Helper loaded: url_helper
INFO - 2024-09-06 03:12:53 --> Helper loaded: file_helper
INFO - 2024-09-06 03:12:53 --> Helper loaded: security_helper
INFO - 2024-09-06 03:12:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 03:12:53 --> Database Driver Class Initialized
INFO - 2024-09-06 03:12:53 --> Email Class Initialized
DEBUG - 2024-09-06 03:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 03:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 03:12:53 --> Helper loaded: form_helper
INFO - 2024-09-06 03:12:53 --> Form Validation Class Initialized
INFO - 2024-09-06 03:12:53 --> Controller Class Initialized
DEBUG - 2024-09-06 03:12:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 03:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 03:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 03:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 03:12:53 --> Final output sent to browser
DEBUG - 2024-09-06 03:12:53 --> Total execution time: 0.2533
INFO - 2024-09-06 03:43:30 --> Config Class Initialized
INFO - 2024-09-06 03:43:30 --> Hooks Class Initialized
DEBUG - 2024-09-06 03:43:30 --> UTF-8 Support Enabled
INFO - 2024-09-06 03:43:30 --> Utf8 Class Initialized
INFO - 2024-09-06 03:43:30 --> URI Class Initialized
DEBUG - 2024-09-06 03:43:30 --> No URI present. Default controller set.
INFO - 2024-09-06 03:43:30 --> Router Class Initialized
INFO - 2024-09-06 03:43:30 --> Output Class Initialized
INFO - 2024-09-06 03:43:30 --> Security Class Initialized
DEBUG - 2024-09-06 03:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 03:43:30 --> Input Class Initialized
INFO - 2024-09-06 03:43:30 --> Language Class Initialized
INFO - 2024-09-06 03:43:30 --> Loader Class Initialized
INFO - 2024-09-06 03:43:30 --> Helper loaded: url_helper
INFO - 2024-09-06 03:43:30 --> Helper loaded: file_helper
INFO - 2024-09-06 03:43:30 --> Helper loaded: security_helper
INFO - 2024-09-06 03:43:30 --> Helper loaded: wpu_helper
INFO - 2024-09-06 03:43:30 --> Database Driver Class Initialized
INFO - 2024-09-06 03:43:31 --> Email Class Initialized
DEBUG - 2024-09-06 03:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 03:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 03:43:31 --> Helper loaded: form_helper
INFO - 2024-09-06 03:43:31 --> Form Validation Class Initialized
INFO - 2024-09-06 03:43:31 --> Controller Class Initialized
DEBUG - 2024-09-06 03:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 03:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 03:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 03:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 03:43:31 --> Final output sent to browser
DEBUG - 2024-09-06 03:43:31 --> Total execution time: 0.2333
INFO - 2024-09-06 04:14:58 --> Config Class Initialized
INFO - 2024-09-06 04:14:58 --> Hooks Class Initialized
DEBUG - 2024-09-06 04:14:58 --> UTF-8 Support Enabled
INFO - 2024-09-06 04:14:58 --> Utf8 Class Initialized
INFO - 2024-09-06 04:14:58 --> URI Class Initialized
DEBUG - 2024-09-06 04:14:58 --> No URI present. Default controller set.
INFO - 2024-09-06 04:14:58 --> Router Class Initialized
INFO - 2024-09-06 04:14:58 --> Output Class Initialized
INFO - 2024-09-06 04:14:58 --> Security Class Initialized
DEBUG - 2024-09-06 04:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 04:14:58 --> Input Class Initialized
INFO - 2024-09-06 04:14:58 --> Language Class Initialized
INFO - 2024-09-06 04:14:58 --> Loader Class Initialized
INFO - 2024-09-06 04:14:58 --> Helper loaded: url_helper
INFO - 2024-09-06 04:14:58 --> Helper loaded: file_helper
INFO - 2024-09-06 04:14:58 --> Helper loaded: security_helper
INFO - 2024-09-06 04:14:58 --> Helper loaded: wpu_helper
INFO - 2024-09-06 04:14:58 --> Database Driver Class Initialized
INFO - 2024-09-06 04:14:58 --> Email Class Initialized
DEBUG - 2024-09-06 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 04:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 04:14:58 --> Helper loaded: form_helper
INFO - 2024-09-06 04:14:58 --> Form Validation Class Initialized
INFO - 2024-09-06 04:14:58 --> Controller Class Initialized
DEBUG - 2024-09-06 04:14:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 04:14:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 04:14:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 04:14:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 04:14:58 --> Final output sent to browser
DEBUG - 2024-09-06 04:14:58 --> Total execution time: 0.2291
INFO - 2024-09-06 04:44:12 --> Config Class Initialized
INFO - 2024-09-06 04:44:12 --> Hooks Class Initialized
DEBUG - 2024-09-06 04:44:12 --> UTF-8 Support Enabled
INFO - 2024-09-06 04:44:12 --> Utf8 Class Initialized
INFO - 2024-09-06 04:44:12 --> URI Class Initialized
DEBUG - 2024-09-06 04:44:12 --> No URI present. Default controller set.
INFO - 2024-09-06 04:44:12 --> Router Class Initialized
INFO - 2024-09-06 04:44:12 --> Output Class Initialized
INFO - 2024-09-06 04:44:12 --> Security Class Initialized
DEBUG - 2024-09-06 04:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 04:44:12 --> Input Class Initialized
INFO - 2024-09-06 04:44:12 --> Language Class Initialized
INFO - 2024-09-06 04:44:12 --> Loader Class Initialized
INFO - 2024-09-06 04:44:12 --> Helper loaded: url_helper
INFO - 2024-09-06 04:44:12 --> Helper loaded: file_helper
INFO - 2024-09-06 04:44:12 --> Helper loaded: security_helper
INFO - 2024-09-06 04:44:12 --> Helper loaded: wpu_helper
INFO - 2024-09-06 04:44:12 --> Database Driver Class Initialized
INFO - 2024-09-06 04:44:13 --> Email Class Initialized
DEBUG - 2024-09-06 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 04:44:13 --> Helper loaded: form_helper
INFO - 2024-09-06 04:44:13 --> Form Validation Class Initialized
INFO - 2024-09-06 04:44:13 --> Controller Class Initialized
DEBUG - 2024-09-06 04:44:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 04:44:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 04:44:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 04:44:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 04:44:13 --> Final output sent to browser
DEBUG - 2024-09-06 04:44:13 --> Total execution time: 0.2405
INFO - 2024-09-06 05:14:21 --> Config Class Initialized
INFO - 2024-09-06 05:14:21 --> Hooks Class Initialized
DEBUG - 2024-09-06 05:14:21 --> UTF-8 Support Enabled
INFO - 2024-09-06 05:14:21 --> Utf8 Class Initialized
INFO - 2024-09-06 05:14:21 --> URI Class Initialized
DEBUG - 2024-09-06 05:14:21 --> No URI present. Default controller set.
INFO - 2024-09-06 05:14:21 --> Router Class Initialized
INFO - 2024-09-06 05:14:21 --> Output Class Initialized
INFO - 2024-09-06 05:14:21 --> Security Class Initialized
DEBUG - 2024-09-06 05:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 05:14:21 --> Input Class Initialized
INFO - 2024-09-06 05:14:21 --> Language Class Initialized
INFO - 2024-09-06 05:14:21 --> Loader Class Initialized
INFO - 2024-09-06 05:14:21 --> Helper loaded: url_helper
INFO - 2024-09-06 05:14:21 --> Helper loaded: file_helper
INFO - 2024-09-06 05:14:21 --> Helper loaded: security_helper
INFO - 2024-09-06 05:14:21 --> Helper loaded: wpu_helper
INFO - 2024-09-06 05:14:21 --> Database Driver Class Initialized
INFO - 2024-09-06 05:14:22 --> Email Class Initialized
DEBUG - 2024-09-06 05:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 05:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 05:14:22 --> Helper loaded: form_helper
INFO - 2024-09-06 05:14:22 --> Form Validation Class Initialized
INFO - 2024-09-06 05:14:22 --> Controller Class Initialized
DEBUG - 2024-09-06 05:14:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 05:14:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 05:14:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 05:14:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 05:14:22 --> Final output sent to browser
DEBUG - 2024-09-06 05:14:22 --> Total execution time: 0.4823
INFO - 2024-09-06 05:17:33 --> Config Class Initialized
INFO - 2024-09-06 05:17:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 05:17:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 05:17:33 --> Utf8 Class Initialized
INFO - 2024-09-06 05:17:33 --> URI Class Initialized
DEBUG - 2024-09-06 05:17:33 --> No URI present. Default controller set.
INFO - 2024-09-06 05:17:33 --> Router Class Initialized
INFO - 2024-09-06 05:17:33 --> Output Class Initialized
INFO - 2024-09-06 05:17:33 --> Security Class Initialized
DEBUG - 2024-09-06 05:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 05:17:33 --> Input Class Initialized
INFO - 2024-09-06 05:17:33 --> Language Class Initialized
INFO - 2024-09-06 05:17:33 --> Loader Class Initialized
INFO - 2024-09-06 05:17:33 --> Helper loaded: url_helper
INFO - 2024-09-06 05:17:33 --> Helper loaded: file_helper
INFO - 2024-09-06 05:17:33 --> Helper loaded: security_helper
INFO - 2024-09-06 05:17:33 --> Helper loaded: wpu_helper
INFO - 2024-09-06 05:17:33 --> Database Driver Class Initialized
INFO - 2024-09-06 05:17:33 --> Email Class Initialized
DEBUG - 2024-09-06 05:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 05:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 05:17:34 --> Helper loaded: form_helper
INFO - 2024-09-06 05:17:34 --> Form Validation Class Initialized
INFO - 2024-09-06 05:17:34 --> Controller Class Initialized
DEBUG - 2024-09-06 05:17:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 05:17:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 05:17:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 05:17:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 05:17:34 --> Final output sent to browser
DEBUG - 2024-09-06 05:17:34 --> Total execution time: 0.2381
INFO - 2024-09-06 05:44:19 --> Config Class Initialized
INFO - 2024-09-06 05:44:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 05:44:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 05:44:19 --> Utf8 Class Initialized
INFO - 2024-09-06 05:44:19 --> URI Class Initialized
DEBUG - 2024-09-06 05:44:19 --> No URI present. Default controller set.
INFO - 2024-09-06 05:44:19 --> Router Class Initialized
INFO - 2024-09-06 05:44:19 --> Output Class Initialized
INFO - 2024-09-06 05:44:19 --> Security Class Initialized
DEBUG - 2024-09-06 05:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 05:44:19 --> Input Class Initialized
INFO - 2024-09-06 05:44:19 --> Language Class Initialized
INFO - 2024-09-06 05:44:19 --> Loader Class Initialized
INFO - 2024-09-06 05:44:19 --> Helper loaded: url_helper
INFO - 2024-09-06 05:44:19 --> Helper loaded: file_helper
INFO - 2024-09-06 05:44:19 --> Helper loaded: security_helper
INFO - 2024-09-06 05:44:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 05:44:19 --> Database Driver Class Initialized
INFO - 2024-09-06 05:44:20 --> Email Class Initialized
DEBUG - 2024-09-06 05:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 05:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 05:44:20 --> Helper loaded: form_helper
INFO - 2024-09-06 05:44:20 --> Form Validation Class Initialized
INFO - 2024-09-06 05:44:20 --> Controller Class Initialized
DEBUG - 2024-09-06 05:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 05:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 05:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 05:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 05:44:20 --> Final output sent to browser
DEBUG - 2024-09-06 05:44:20 --> Total execution time: 0.2228
INFO - 2024-09-06 06:12:39 --> Config Class Initialized
INFO - 2024-09-06 06:12:39 --> Hooks Class Initialized
DEBUG - 2024-09-06 06:12:39 --> UTF-8 Support Enabled
INFO - 2024-09-06 06:12:39 --> Utf8 Class Initialized
INFO - 2024-09-06 06:12:39 --> URI Class Initialized
DEBUG - 2024-09-06 06:12:39 --> No URI present. Default controller set.
INFO - 2024-09-06 06:12:39 --> Router Class Initialized
INFO - 2024-09-06 06:12:39 --> Output Class Initialized
INFO - 2024-09-06 06:12:39 --> Security Class Initialized
DEBUG - 2024-09-06 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 06:12:39 --> Input Class Initialized
INFO - 2024-09-06 06:12:39 --> Language Class Initialized
INFO - 2024-09-06 06:12:39 --> Loader Class Initialized
INFO - 2024-09-06 06:12:39 --> Helper loaded: url_helper
INFO - 2024-09-06 06:12:39 --> Helper loaded: file_helper
INFO - 2024-09-06 06:12:39 --> Helper loaded: security_helper
INFO - 2024-09-06 06:12:39 --> Helper loaded: wpu_helper
INFO - 2024-09-06 06:12:39 --> Database Driver Class Initialized
INFO - 2024-09-06 06:12:39 --> Email Class Initialized
DEBUG - 2024-09-06 06:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 06:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 06:12:39 --> Helper loaded: form_helper
INFO - 2024-09-06 06:12:39 --> Form Validation Class Initialized
INFO - 2024-09-06 06:12:39 --> Controller Class Initialized
DEBUG - 2024-09-06 06:12:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 06:12:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 06:12:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 06:12:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 06:12:39 --> Final output sent to browser
DEBUG - 2024-09-06 06:12:39 --> Total execution time: 0.2166
INFO - 2024-09-06 06:45:12 --> Config Class Initialized
INFO - 2024-09-06 06:45:12 --> Hooks Class Initialized
DEBUG - 2024-09-06 06:45:12 --> UTF-8 Support Enabled
INFO - 2024-09-06 06:45:12 --> Utf8 Class Initialized
INFO - 2024-09-06 06:45:12 --> URI Class Initialized
DEBUG - 2024-09-06 06:45:12 --> No URI present. Default controller set.
INFO - 2024-09-06 06:45:12 --> Router Class Initialized
INFO - 2024-09-06 06:45:12 --> Output Class Initialized
INFO - 2024-09-06 06:45:12 --> Security Class Initialized
DEBUG - 2024-09-06 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 06:45:12 --> Input Class Initialized
INFO - 2024-09-06 06:45:12 --> Language Class Initialized
INFO - 2024-09-06 06:45:12 --> Loader Class Initialized
INFO - 2024-09-06 06:45:12 --> Helper loaded: url_helper
INFO - 2024-09-06 06:45:12 --> Helper loaded: file_helper
INFO - 2024-09-06 06:45:12 --> Helper loaded: security_helper
INFO - 2024-09-06 06:45:12 --> Helper loaded: wpu_helper
INFO - 2024-09-06 06:45:12 --> Database Driver Class Initialized
INFO - 2024-09-06 06:45:13 --> Email Class Initialized
DEBUG - 2024-09-06 06:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 06:45:13 --> Helper loaded: form_helper
INFO - 2024-09-06 06:45:13 --> Form Validation Class Initialized
INFO - 2024-09-06 06:45:13 --> Controller Class Initialized
DEBUG - 2024-09-06 06:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 06:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 06:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 06:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 06:45:13 --> Final output sent to browser
DEBUG - 2024-09-06 06:45:13 --> Total execution time: 0.2274
INFO - 2024-09-06 07:12:59 --> Config Class Initialized
INFO - 2024-09-06 07:12:59 --> Hooks Class Initialized
DEBUG - 2024-09-06 07:12:59 --> UTF-8 Support Enabled
INFO - 2024-09-06 07:12:59 --> Utf8 Class Initialized
INFO - 2024-09-06 07:12:59 --> URI Class Initialized
DEBUG - 2024-09-06 07:12:59 --> No URI present. Default controller set.
INFO - 2024-09-06 07:12:59 --> Router Class Initialized
INFO - 2024-09-06 07:12:59 --> Output Class Initialized
INFO - 2024-09-06 07:12:59 --> Security Class Initialized
DEBUG - 2024-09-06 07:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 07:12:59 --> Input Class Initialized
INFO - 2024-09-06 07:12:59 --> Language Class Initialized
INFO - 2024-09-06 07:12:59 --> Loader Class Initialized
INFO - 2024-09-06 07:12:59 --> Helper loaded: url_helper
INFO - 2024-09-06 07:12:59 --> Helper loaded: file_helper
INFO - 2024-09-06 07:12:59 --> Helper loaded: security_helper
INFO - 2024-09-06 07:12:59 --> Helper loaded: wpu_helper
INFO - 2024-09-06 07:12:59 --> Database Driver Class Initialized
INFO - 2024-09-06 07:13:00 --> Email Class Initialized
DEBUG - 2024-09-06 07:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 07:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 07:13:00 --> Helper loaded: form_helper
INFO - 2024-09-06 07:13:00 --> Form Validation Class Initialized
INFO - 2024-09-06 07:13:00 --> Controller Class Initialized
DEBUG - 2024-09-06 07:13:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 07:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 07:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 07:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 07:13:00 --> Final output sent to browser
DEBUG - 2024-09-06 07:13:00 --> Total execution time: 0.2232
INFO - 2024-09-06 07:38:19 --> Config Class Initialized
INFO - 2024-09-06 07:38:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 07:38:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 07:38:19 --> Utf8 Class Initialized
INFO - 2024-09-06 07:38:19 --> URI Class Initialized
DEBUG - 2024-09-06 07:38:19 --> No URI present. Default controller set.
INFO - 2024-09-06 07:38:19 --> Router Class Initialized
INFO - 2024-09-06 07:38:19 --> Output Class Initialized
INFO - 2024-09-06 07:38:19 --> Security Class Initialized
DEBUG - 2024-09-06 07:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 07:38:19 --> Input Class Initialized
INFO - 2024-09-06 07:38:19 --> Language Class Initialized
INFO - 2024-09-06 07:38:19 --> Loader Class Initialized
INFO - 2024-09-06 07:38:19 --> Helper loaded: url_helper
INFO - 2024-09-06 07:38:19 --> Helper loaded: file_helper
INFO - 2024-09-06 07:38:19 --> Helper loaded: security_helper
INFO - 2024-09-06 07:38:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 07:38:19 --> Database Driver Class Initialized
INFO - 2024-09-06 07:38:19 --> Email Class Initialized
DEBUG - 2024-09-06 07:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 07:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 07:38:19 --> Helper loaded: form_helper
INFO - 2024-09-06 07:38:19 --> Form Validation Class Initialized
INFO - 2024-09-06 07:38:19 --> Controller Class Initialized
DEBUG - 2024-09-06 07:38:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 07:38:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 07:38:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 07:38:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 07:38:19 --> Final output sent to browser
DEBUG - 2024-09-06 07:38:19 --> Total execution time: 0.2223
INFO - 2024-09-06 07:38:20 --> Config Class Initialized
INFO - 2024-09-06 07:38:20 --> Hooks Class Initialized
DEBUG - 2024-09-06 07:38:20 --> UTF-8 Support Enabled
INFO - 2024-09-06 07:38:20 --> Utf8 Class Initialized
INFO - 2024-09-06 07:38:20 --> URI Class Initialized
DEBUG - 2024-09-06 07:38:20 --> No URI present. Default controller set.
INFO - 2024-09-06 07:38:20 --> Router Class Initialized
INFO - 2024-09-06 07:38:20 --> Output Class Initialized
INFO - 2024-09-06 07:38:20 --> Security Class Initialized
DEBUG - 2024-09-06 07:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 07:38:20 --> Input Class Initialized
INFO - 2024-09-06 07:38:20 --> Language Class Initialized
INFO - 2024-09-06 07:38:20 --> Loader Class Initialized
INFO - 2024-09-06 07:38:20 --> Helper loaded: url_helper
INFO - 2024-09-06 07:38:20 --> Helper loaded: file_helper
INFO - 2024-09-06 07:38:20 --> Helper loaded: security_helper
INFO - 2024-09-06 07:38:20 --> Helper loaded: wpu_helper
INFO - 2024-09-06 07:38:20 --> Database Driver Class Initialized
INFO - 2024-09-06 07:38:21 --> Email Class Initialized
DEBUG - 2024-09-06 07:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 07:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 07:38:21 --> Helper loaded: form_helper
INFO - 2024-09-06 07:38:21 --> Form Validation Class Initialized
INFO - 2024-09-06 07:38:21 --> Controller Class Initialized
DEBUG - 2024-09-06 07:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 07:38:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 07:38:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 07:38:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 07:38:21 --> Final output sent to browser
DEBUG - 2024-09-06 07:38:21 --> Total execution time: 0.2371
INFO - 2024-09-06 07:43:50 --> Config Class Initialized
INFO - 2024-09-06 07:43:50 --> Hooks Class Initialized
DEBUG - 2024-09-06 07:43:50 --> UTF-8 Support Enabled
INFO - 2024-09-06 07:43:50 --> Utf8 Class Initialized
INFO - 2024-09-06 07:43:50 --> URI Class Initialized
DEBUG - 2024-09-06 07:43:50 --> No URI present. Default controller set.
INFO - 2024-09-06 07:43:50 --> Router Class Initialized
INFO - 2024-09-06 07:43:50 --> Output Class Initialized
INFO - 2024-09-06 07:43:50 --> Security Class Initialized
DEBUG - 2024-09-06 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 07:43:50 --> Input Class Initialized
INFO - 2024-09-06 07:43:50 --> Language Class Initialized
INFO - 2024-09-06 07:43:50 --> Loader Class Initialized
INFO - 2024-09-06 07:43:50 --> Helper loaded: url_helper
INFO - 2024-09-06 07:43:50 --> Helper loaded: file_helper
INFO - 2024-09-06 07:43:50 --> Helper loaded: security_helper
INFO - 2024-09-06 07:43:50 --> Helper loaded: wpu_helper
INFO - 2024-09-06 07:43:50 --> Database Driver Class Initialized
INFO - 2024-09-06 07:43:50 --> Email Class Initialized
DEBUG - 2024-09-06 07:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 07:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 07:43:50 --> Helper loaded: form_helper
INFO - 2024-09-06 07:43:50 --> Form Validation Class Initialized
INFO - 2024-09-06 07:43:50 --> Controller Class Initialized
DEBUG - 2024-09-06 07:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 07:43:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 07:43:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 07:43:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 07:43:50 --> Final output sent to browser
DEBUG - 2024-09-06 07:43:50 --> Total execution time: 0.2401
INFO - 2024-09-06 08:12:23 --> Config Class Initialized
INFO - 2024-09-06 08:12:23 --> Hooks Class Initialized
DEBUG - 2024-09-06 08:12:23 --> UTF-8 Support Enabled
INFO - 2024-09-06 08:12:23 --> Utf8 Class Initialized
INFO - 2024-09-06 08:12:23 --> URI Class Initialized
DEBUG - 2024-09-06 08:12:23 --> No URI present. Default controller set.
INFO - 2024-09-06 08:12:23 --> Router Class Initialized
INFO - 2024-09-06 08:12:23 --> Output Class Initialized
INFO - 2024-09-06 08:12:23 --> Security Class Initialized
DEBUG - 2024-09-06 08:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 08:12:23 --> Input Class Initialized
INFO - 2024-09-06 08:12:23 --> Language Class Initialized
INFO - 2024-09-06 08:12:23 --> Loader Class Initialized
INFO - 2024-09-06 08:12:23 --> Helper loaded: url_helper
INFO - 2024-09-06 08:12:23 --> Helper loaded: file_helper
INFO - 2024-09-06 08:12:23 --> Helper loaded: security_helper
INFO - 2024-09-06 08:12:23 --> Helper loaded: wpu_helper
INFO - 2024-09-06 08:12:23 --> Database Driver Class Initialized
INFO - 2024-09-06 08:12:23 --> Email Class Initialized
DEBUG - 2024-09-06 08:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 08:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 08:12:23 --> Helper loaded: form_helper
INFO - 2024-09-06 08:12:23 --> Form Validation Class Initialized
INFO - 2024-09-06 08:12:23 --> Controller Class Initialized
DEBUG - 2024-09-06 08:12:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 08:12:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 08:12:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 08:12:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 08:12:23 --> Final output sent to browser
DEBUG - 2024-09-06 08:12:23 --> Total execution time: 0.2426
INFO - 2024-09-06 08:15:27 --> Config Class Initialized
INFO - 2024-09-06 08:15:27 --> Hooks Class Initialized
DEBUG - 2024-09-06 08:15:27 --> UTF-8 Support Enabled
INFO - 2024-09-06 08:15:27 --> Utf8 Class Initialized
INFO - 2024-09-06 08:15:27 --> URI Class Initialized
DEBUG - 2024-09-06 08:15:27 --> No URI present. Default controller set.
INFO - 2024-09-06 08:15:27 --> Router Class Initialized
INFO - 2024-09-06 08:15:27 --> Output Class Initialized
INFO - 2024-09-06 08:15:27 --> Security Class Initialized
DEBUG - 2024-09-06 08:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 08:15:27 --> Input Class Initialized
INFO - 2024-09-06 08:15:27 --> Language Class Initialized
INFO - 2024-09-06 08:15:27 --> Loader Class Initialized
INFO - 2024-09-06 08:15:27 --> Helper loaded: url_helper
INFO - 2024-09-06 08:15:27 --> Helper loaded: file_helper
INFO - 2024-09-06 08:15:27 --> Helper loaded: security_helper
INFO - 2024-09-06 08:15:27 --> Helper loaded: wpu_helper
INFO - 2024-09-06 08:15:27 --> Database Driver Class Initialized
INFO - 2024-09-06 08:15:27 --> Email Class Initialized
DEBUG - 2024-09-06 08:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 08:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 08:15:27 --> Helper loaded: form_helper
INFO - 2024-09-06 08:15:27 --> Form Validation Class Initialized
INFO - 2024-09-06 08:15:27 --> Controller Class Initialized
DEBUG - 2024-09-06 08:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 08:15:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 08:15:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 08:15:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 08:15:28 --> Final output sent to browser
DEBUG - 2024-09-06 08:15:28 --> Total execution time: 0.2209
INFO - 2024-09-06 08:42:08 --> Config Class Initialized
INFO - 2024-09-06 08:42:08 --> Hooks Class Initialized
DEBUG - 2024-09-06 08:42:08 --> UTF-8 Support Enabled
INFO - 2024-09-06 08:42:08 --> Utf8 Class Initialized
INFO - 2024-09-06 08:42:08 --> URI Class Initialized
DEBUG - 2024-09-06 08:42:08 --> No URI present. Default controller set.
INFO - 2024-09-06 08:42:08 --> Router Class Initialized
INFO - 2024-09-06 08:42:08 --> Output Class Initialized
INFO - 2024-09-06 08:42:08 --> Security Class Initialized
DEBUG - 2024-09-06 08:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 08:42:08 --> Input Class Initialized
INFO - 2024-09-06 08:42:08 --> Language Class Initialized
INFO - 2024-09-06 08:42:08 --> Loader Class Initialized
INFO - 2024-09-06 08:42:08 --> Helper loaded: url_helper
INFO - 2024-09-06 08:42:08 --> Helper loaded: file_helper
INFO - 2024-09-06 08:42:08 --> Helper loaded: security_helper
INFO - 2024-09-06 08:42:08 --> Helper loaded: wpu_helper
INFO - 2024-09-06 08:42:08 --> Database Driver Class Initialized
INFO - 2024-09-06 08:42:08 --> Email Class Initialized
DEBUG - 2024-09-06 08:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 08:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 08:42:08 --> Helper loaded: form_helper
INFO - 2024-09-06 08:42:08 --> Form Validation Class Initialized
INFO - 2024-09-06 08:42:08 --> Controller Class Initialized
DEBUG - 2024-09-06 08:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 08:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 08:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 08:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 08:42:08 --> Final output sent to browser
DEBUG - 2024-09-06 08:42:08 --> Total execution time: 0.2320
INFO - 2024-09-06 08:42:10 --> Config Class Initialized
INFO - 2024-09-06 08:42:10 --> Hooks Class Initialized
DEBUG - 2024-09-06 08:42:10 --> UTF-8 Support Enabled
INFO - 2024-09-06 08:42:10 --> Utf8 Class Initialized
INFO - 2024-09-06 08:42:10 --> URI Class Initialized
DEBUG - 2024-09-06 08:42:10 --> No URI present. Default controller set.
INFO - 2024-09-06 08:42:10 --> Router Class Initialized
INFO - 2024-09-06 08:42:10 --> Output Class Initialized
INFO - 2024-09-06 08:42:10 --> Security Class Initialized
DEBUG - 2024-09-06 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 08:42:10 --> Input Class Initialized
INFO - 2024-09-06 08:42:10 --> Language Class Initialized
INFO - 2024-09-06 08:42:10 --> Loader Class Initialized
INFO - 2024-09-06 08:42:10 --> Helper loaded: url_helper
INFO - 2024-09-06 08:42:10 --> Helper loaded: file_helper
INFO - 2024-09-06 08:42:10 --> Helper loaded: security_helper
INFO - 2024-09-06 08:42:10 --> Helper loaded: wpu_helper
INFO - 2024-09-06 08:42:10 --> Database Driver Class Initialized
INFO - 2024-09-06 08:42:10 --> Email Class Initialized
DEBUG - 2024-09-06 08:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 08:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 08:42:10 --> Helper loaded: form_helper
INFO - 2024-09-06 08:42:10 --> Form Validation Class Initialized
INFO - 2024-09-06 08:42:10 --> Controller Class Initialized
DEBUG - 2024-09-06 08:42:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 08:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 08:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 08:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 08:42:10 --> Final output sent to browser
DEBUG - 2024-09-06 08:42:10 --> Total execution time: 0.2252
INFO - 2024-09-06 08:45:42 --> Config Class Initialized
INFO - 2024-09-06 08:45:42 --> Hooks Class Initialized
DEBUG - 2024-09-06 08:45:42 --> UTF-8 Support Enabled
INFO - 2024-09-06 08:45:42 --> Utf8 Class Initialized
INFO - 2024-09-06 08:45:42 --> URI Class Initialized
DEBUG - 2024-09-06 08:45:42 --> No URI present. Default controller set.
INFO - 2024-09-06 08:45:42 --> Router Class Initialized
INFO - 2024-09-06 08:45:42 --> Output Class Initialized
INFO - 2024-09-06 08:45:42 --> Security Class Initialized
DEBUG - 2024-09-06 08:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 08:45:42 --> Input Class Initialized
INFO - 2024-09-06 08:45:42 --> Language Class Initialized
INFO - 2024-09-06 08:45:42 --> Loader Class Initialized
INFO - 2024-09-06 08:45:42 --> Helper loaded: url_helper
INFO - 2024-09-06 08:45:42 --> Helper loaded: file_helper
INFO - 2024-09-06 08:45:42 --> Helper loaded: security_helper
INFO - 2024-09-06 08:45:42 --> Helper loaded: wpu_helper
INFO - 2024-09-06 08:45:42 --> Database Driver Class Initialized
INFO - 2024-09-06 08:45:42 --> Email Class Initialized
DEBUG - 2024-09-06 08:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 08:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 08:45:42 --> Helper loaded: form_helper
INFO - 2024-09-06 08:45:42 --> Form Validation Class Initialized
INFO - 2024-09-06 08:45:42 --> Controller Class Initialized
DEBUG - 2024-09-06 08:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 08:45:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 08:45:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 08:45:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 08:45:42 --> Final output sent to browser
DEBUG - 2024-09-06 08:45:42 --> Total execution time: 0.4667
INFO - 2024-09-06 09:00:46 --> Config Class Initialized
INFO - 2024-09-06 09:00:46 --> Hooks Class Initialized
DEBUG - 2024-09-06 09:00:46 --> UTF-8 Support Enabled
INFO - 2024-09-06 09:00:46 --> Utf8 Class Initialized
INFO - 2024-09-06 09:00:46 --> URI Class Initialized
DEBUG - 2024-09-06 09:00:46 --> No URI present. Default controller set.
INFO - 2024-09-06 09:00:46 --> Router Class Initialized
INFO - 2024-09-06 09:00:46 --> Output Class Initialized
INFO - 2024-09-06 09:00:46 --> Security Class Initialized
DEBUG - 2024-09-06 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 09:00:46 --> Input Class Initialized
INFO - 2024-09-06 09:00:46 --> Language Class Initialized
INFO - 2024-09-06 09:00:46 --> Loader Class Initialized
INFO - 2024-09-06 09:00:46 --> Helper loaded: url_helper
INFO - 2024-09-06 09:00:46 --> Helper loaded: file_helper
INFO - 2024-09-06 09:00:46 --> Helper loaded: security_helper
INFO - 2024-09-06 09:00:46 --> Helper loaded: wpu_helper
INFO - 2024-09-06 09:00:46 --> Database Driver Class Initialized
INFO - 2024-09-06 09:00:46 --> Email Class Initialized
DEBUG - 2024-09-06 09:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 09:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 09:00:46 --> Helper loaded: form_helper
INFO - 2024-09-06 09:00:46 --> Form Validation Class Initialized
INFO - 2024-09-06 09:00:46 --> Controller Class Initialized
DEBUG - 2024-09-06 09:00:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 09:00:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 09:00:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 09:00:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 09:00:46 --> Final output sent to browser
DEBUG - 2024-09-06 09:00:46 --> Total execution time: 0.2115
INFO - 2024-09-06 09:13:16 --> Config Class Initialized
INFO - 2024-09-06 09:13:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 09:13:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 09:13:16 --> Utf8 Class Initialized
INFO - 2024-09-06 09:13:16 --> URI Class Initialized
DEBUG - 2024-09-06 09:13:16 --> No URI present. Default controller set.
INFO - 2024-09-06 09:13:16 --> Router Class Initialized
INFO - 2024-09-06 09:13:16 --> Output Class Initialized
INFO - 2024-09-06 09:13:16 --> Security Class Initialized
DEBUG - 2024-09-06 09:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 09:13:16 --> Input Class Initialized
INFO - 2024-09-06 09:13:16 --> Language Class Initialized
INFO - 2024-09-06 09:13:16 --> Loader Class Initialized
INFO - 2024-09-06 09:13:16 --> Helper loaded: url_helper
INFO - 2024-09-06 09:13:16 --> Helper loaded: file_helper
INFO - 2024-09-06 09:13:16 --> Helper loaded: security_helper
INFO - 2024-09-06 09:13:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 09:13:16 --> Database Driver Class Initialized
INFO - 2024-09-06 09:13:17 --> Email Class Initialized
DEBUG - 2024-09-06 09:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 09:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 09:13:17 --> Helper loaded: form_helper
INFO - 2024-09-06 09:13:17 --> Form Validation Class Initialized
INFO - 2024-09-06 09:13:17 --> Controller Class Initialized
DEBUG - 2024-09-06 09:13:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 09:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 09:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 09:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 09:13:17 --> Final output sent to browser
DEBUG - 2024-09-06 09:13:17 --> Total execution time: 0.2297
INFO - 2024-09-06 09:42:12 --> Config Class Initialized
INFO - 2024-09-06 09:42:12 --> Hooks Class Initialized
DEBUG - 2024-09-06 09:42:12 --> UTF-8 Support Enabled
INFO - 2024-09-06 09:42:12 --> Utf8 Class Initialized
INFO - 2024-09-06 09:42:12 --> URI Class Initialized
DEBUG - 2024-09-06 09:42:12 --> No URI present. Default controller set.
INFO - 2024-09-06 09:42:12 --> Router Class Initialized
INFO - 2024-09-06 09:42:12 --> Output Class Initialized
INFO - 2024-09-06 09:42:12 --> Security Class Initialized
DEBUG - 2024-09-06 09:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 09:42:12 --> Input Class Initialized
INFO - 2024-09-06 09:42:12 --> Language Class Initialized
INFO - 2024-09-06 09:42:12 --> Loader Class Initialized
INFO - 2024-09-06 09:42:12 --> Helper loaded: url_helper
INFO - 2024-09-06 09:42:12 --> Helper loaded: file_helper
INFO - 2024-09-06 09:42:12 --> Helper loaded: security_helper
INFO - 2024-09-06 09:42:12 --> Helper loaded: wpu_helper
INFO - 2024-09-06 09:42:12 --> Database Driver Class Initialized
INFO - 2024-09-06 09:42:13 --> Email Class Initialized
DEBUG - 2024-09-06 09:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 09:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 09:42:13 --> Helper loaded: form_helper
INFO - 2024-09-06 09:42:13 --> Form Validation Class Initialized
INFO - 2024-09-06 09:42:13 --> Controller Class Initialized
DEBUG - 2024-09-06 09:42:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 09:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 09:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 09:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 09:42:13 --> Final output sent to browser
DEBUG - 2024-09-06 09:42:13 --> Total execution time: 0.2923
INFO - 2024-09-06 10:12:08 --> Config Class Initialized
INFO - 2024-09-06 10:12:08 --> Hooks Class Initialized
DEBUG - 2024-09-06 10:12:08 --> UTF-8 Support Enabled
INFO - 2024-09-06 10:12:08 --> Utf8 Class Initialized
INFO - 2024-09-06 10:12:08 --> URI Class Initialized
DEBUG - 2024-09-06 10:12:08 --> No URI present. Default controller set.
INFO - 2024-09-06 10:12:08 --> Router Class Initialized
INFO - 2024-09-06 10:12:08 --> Output Class Initialized
INFO - 2024-09-06 10:12:08 --> Security Class Initialized
DEBUG - 2024-09-06 10:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 10:12:08 --> Input Class Initialized
INFO - 2024-09-06 10:12:08 --> Language Class Initialized
INFO - 2024-09-06 10:12:08 --> Loader Class Initialized
INFO - 2024-09-06 10:12:08 --> Helper loaded: url_helper
INFO - 2024-09-06 10:12:08 --> Helper loaded: file_helper
INFO - 2024-09-06 10:12:08 --> Helper loaded: security_helper
INFO - 2024-09-06 10:12:08 --> Helper loaded: wpu_helper
INFO - 2024-09-06 10:12:08 --> Database Driver Class Initialized
INFO - 2024-09-06 10:12:08 --> Email Class Initialized
DEBUG - 2024-09-06 10:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 10:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 10:12:08 --> Helper loaded: form_helper
INFO - 2024-09-06 10:12:08 --> Form Validation Class Initialized
INFO - 2024-09-06 10:12:08 --> Controller Class Initialized
DEBUG - 2024-09-06 10:12:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 10:12:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 10:12:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 10:12:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 10:12:08 --> Final output sent to browser
DEBUG - 2024-09-06 10:12:08 --> Total execution time: 0.2634
INFO - 2024-09-06 10:20:25 --> Config Class Initialized
INFO - 2024-09-06 10:20:25 --> Hooks Class Initialized
DEBUG - 2024-09-06 10:20:25 --> UTF-8 Support Enabled
INFO - 2024-09-06 10:20:25 --> Utf8 Class Initialized
INFO - 2024-09-06 10:20:25 --> URI Class Initialized
DEBUG - 2024-09-06 10:20:25 --> No URI present. Default controller set.
INFO - 2024-09-06 10:20:25 --> Router Class Initialized
INFO - 2024-09-06 10:20:25 --> Output Class Initialized
INFO - 2024-09-06 10:20:25 --> Security Class Initialized
DEBUG - 2024-09-06 10:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 10:20:25 --> Input Class Initialized
INFO - 2024-09-06 10:20:25 --> Language Class Initialized
INFO - 2024-09-06 10:20:25 --> Loader Class Initialized
INFO - 2024-09-06 10:20:25 --> Helper loaded: url_helper
INFO - 2024-09-06 10:20:25 --> Helper loaded: file_helper
INFO - 2024-09-06 10:20:25 --> Helper loaded: security_helper
INFO - 2024-09-06 10:20:25 --> Helper loaded: wpu_helper
INFO - 2024-09-06 10:20:25 --> Database Driver Class Initialized
INFO - 2024-09-06 10:20:25 --> Email Class Initialized
DEBUG - 2024-09-06 10:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 10:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 10:20:25 --> Helper loaded: form_helper
INFO - 2024-09-06 10:20:25 --> Form Validation Class Initialized
INFO - 2024-09-06 10:20:25 --> Controller Class Initialized
DEBUG - 2024-09-06 10:20:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 10:20:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 10:20:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 10:20:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 10:20:25 --> Final output sent to browser
DEBUG - 2024-09-06 10:20:25 --> Total execution time: 0.2723
INFO - 2024-09-06 10:42:15 --> Config Class Initialized
INFO - 2024-09-06 10:42:15 --> Hooks Class Initialized
DEBUG - 2024-09-06 10:42:15 --> UTF-8 Support Enabled
INFO - 2024-09-06 10:42:15 --> Utf8 Class Initialized
INFO - 2024-09-06 10:42:15 --> URI Class Initialized
DEBUG - 2024-09-06 10:42:15 --> No URI present. Default controller set.
INFO - 2024-09-06 10:42:15 --> Router Class Initialized
INFO - 2024-09-06 10:42:15 --> Output Class Initialized
INFO - 2024-09-06 10:42:15 --> Security Class Initialized
DEBUG - 2024-09-06 10:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 10:42:15 --> Input Class Initialized
INFO - 2024-09-06 10:42:15 --> Language Class Initialized
INFO - 2024-09-06 10:42:15 --> Loader Class Initialized
INFO - 2024-09-06 10:42:15 --> Helper loaded: url_helper
INFO - 2024-09-06 10:42:15 --> Helper loaded: file_helper
INFO - 2024-09-06 10:42:15 --> Helper loaded: security_helper
INFO - 2024-09-06 10:42:15 --> Helper loaded: wpu_helper
INFO - 2024-09-06 10:42:15 --> Database Driver Class Initialized
INFO - 2024-09-06 10:42:15 --> Email Class Initialized
DEBUG - 2024-09-06 10:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 10:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 10:42:15 --> Helper loaded: form_helper
INFO - 2024-09-06 10:42:15 --> Form Validation Class Initialized
INFO - 2024-09-06 10:42:15 --> Controller Class Initialized
DEBUG - 2024-09-06 10:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 10:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 10:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 10:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 10:42:15 --> Final output sent to browser
DEBUG - 2024-09-06 10:42:15 --> Total execution time: 0.2693
INFO - 2024-09-06 11:12:13 --> Config Class Initialized
INFO - 2024-09-06 11:12:13 --> Hooks Class Initialized
DEBUG - 2024-09-06 11:12:13 --> UTF-8 Support Enabled
INFO - 2024-09-06 11:12:13 --> Utf8 Class Initialized
INFO - 2024-09-06 11:12:13 --> URI Class Initialized
DEBUG - 2024-09-06 11:12:13 --> No URI present. Default controller set.
INFO - 2024-09-06 11:12:13 --> Router Class Initialized
INFO - 2024-09-06 11:12:13 --> Output Class Initialized
INFO - 2024-09-06 11:12:13 --> Security Class Initialized
DEBUG - 2024-09-06 11:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 11:12:13 --> Input Class Initialized
INFO - 2024-09-06 11:12:13 --> Language Class Initialized
INFO - 2024-09-06 11:12:13 --> Loader Class Initialized
INFO - 2024-09-06 11:12:13 --> Helper loaded: url_helper
INFO - 2024-09-06 11:12:13 --> Helper loaded: file_helper
INFO - 2024-09-06 11:12:13 --> Helper loaded: security_helper
INFO - 2024-09-06 11:12:13 --> Helper loaded: wpu_helper
INFO - 2024-09-06 11:12:13 --> Database Driver Class Initialized
INFO - 2024-09-06 11:12:14 --> Email Class Initialized
DEBUG - 2024-09-06 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 11:12:14 --> Helper loaded: form_helper
INFO - 2024-09-06 11:12:14 --> Form Validation Class Initialized
INFO - 2024-09-06 11:12:14 --> Controller Class Initialized
DEBUG - 2024-09-06 11:12:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 11:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 11:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 11:12:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 11:12:14 --> Final output sent to browser
DEBUG - 2024-09-06 11:12:14 --> Total execution time: 0.2131
INFO - 2024-09-06 11:15:53 --> Config Class Initialized
INFO - 2024-09-06 11:15:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 11:15:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 11:15:53 --> Utf8 Class Initialized
INFO - 2024-09-06 11:15:53 --> URI Class Initialized
DEBUG - 2024-09-06 11:15:53 --> No URI present. Default controller set.
INFO - 2024-09-06 11:15:53 --> Router Class Initialized
INFO - 2024-09-06 11:15:53 --> Output Class Initialized
INFO - 2024-09-06 11:15:53 --> Security Class Initialized
DEBUG - 2024-09-06 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 11:15:53 --> Input Class Initialized
INFO - 2024-09-06 11:15:53 --> Language Class Initialized
INFO - 2024-09-06 11:15:53 --> Loader Class Initialized
INFO - 2024-09-06 11:15:53 --> Helper loaded: url_helper
INFO - 2024-09-06 11:15:53 --> Helper loaded: file_helper
INFO - 2024-09-06 11:15:53 --> Helper loaded: security_helper
INFO - 2024-09-06 11:15:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 11:15:53 --> Database Driver Class Initialized
INFO - 2024-09-06 11:15:54 --> Email Class Initialized
DEBUG - 2024-09-06 11:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 11:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 11:15:54 --> Helper loaded: form_helper
INFO - 2024-09-06 11:15:54 --> Form Validation Class Initialized
INFO - 2024-09-06 11:15:54 --> Controller Class Initialized
DEBUG - 2024-09-06 11:15:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 11:15:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 11:15:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 11:15:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 11:15:54 --> Final output sent to browser
DEBUG - 2024-09-06 11:15:54 --> Total execution time: 0.2369
INFO - 2024-09-06 11:41:49 --> Config Class Initialized
INFO - 2024-09-06 11:41:49 --> Hooks Class Initialized
DEBUG - 2024-09-06 11:41:49 --> UTF-8 Support Enabled
INFO - 2024-09-06 11:41:49 --> Utf8 Class Initialized
INFO - 2024-09-06 11:41:49 --> URI Class Initialized
DEBUG - 2024-09-06 11:41:49 --> No URI present. Default controller set.
INFO - 2024-09-06 11:41:49 --> Router Class Initialized
INFO - 2024-09-06 11:41:49 --> Output Class Initialized
INFO - 2024-09-06 11:41:49 --> Security Class Initialized
DEBUG - 2024-09-06 11:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 11:41:49 --> Input Class Initialized
INFO - 2024-09-06 11:41:49 --> Language Class Initialized
INFO - 2024-09-06 11:41:49 --> Loader Class Initialized
INFO - 2024-09-06 11:41:49 --> Helper loaded: url_helper
INFO - 2024-09-06 11:41:49 --> Helper loaded: file_helper
INFO - 2024-09-06 11:41:49 --> Helper loaded: security_helper
INFO - 2024-09-06 11:41:49 --> Helper loaded: wpu_helper
INFO - 2024-09-06 11:41:49 --> Database Driver Class Initialized
INFO - 2024-09-06 11:41:49 --> Email Class Initialized
DEBUG - 2024-09-06 11:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 11:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 11:41:49 --> Helper loaded: form_helper
INFO - 2024-09-06 11:41:49 --> Form Validation Class Initialized
INFO - 2024-09-06 11:41:49 --> Controller Class Initialized
DEBUG - 2024-09-06 11:41:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 11:41:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 11:41:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 11:41:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 11:41:49 --> Final output sent to browser
DEBUG - 2024-09-06 11:41:49 --> Total execution time: 0.2165
INFO - 2024-09-06 12:15:05 --> Config Class Initialized
INFO - 2024-09-06 12:15:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 12:15:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 12:15:05 --> Utf8 Class Initialized
INFO - 2024-09-06 12:15:05 --> URI Class Initialized
DEBUG - 2024-09-06 12:15:05 --> No URI present. Default controller set.
INFO - 2024-09-06 12:15:05 --> Router Class Initialized
INFO - 2024-09-06 12:15:05 --> Output Class Initialized
INFO - 2024-09-06 12:15:05 --> Security Class Initialized
DEBUG - 2024-09-06 12:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 12:15:05 --> Input Class Initialized
INFO - 2024-09-06 12:15:05 --> Language Class Initialized
INFO - 2024-09-06 12:15:05 --> Loader Class Initialized
INFO - 2024-09-06 12:15:05 --> Helper loaded: url_helper
INFO - 2024-09-06 12:15:05 --> Helper loaded: file_helper
INFO - 2024-09-06 12:15:05 --> Helper loaded: security_helper
INFO - 2024-09-06 12:15:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 12:15:05 --> Database Driver Class Initialized
INFO - 2024-09-06 12:15:05 --> Email Class Initialized
DEBUG - 2024-09-06 12:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 12:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 12:15:05 --> Helper loaded: form_helper
INFO - 2024-09-06 12:15:05 --> Form Validation Class Initialized
INFO - 2024-09-06 12:15:05 --> Controller Class Initialized
DEBUG - 2024-09-06 12:15:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 12:15:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 12:15:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 12:15:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 12:15:05 --> Final output sent to browser
DEBUG - 2024-09-06 12:15:05 --> Total execution time: 0.3819
INFO - 2024-09-06 12:42:05 --> Config Class Initialized
INFO - 2024-09-06 12:42:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 12:42:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 12:42:05 --> Utf8 Class Initialized
INFO - 2024-09-06 12:42:05 --> URI Class Initialized
DEBUG - 2024-09-06 12:42:05 --> No URI present. Default controller set.
INFO - 2024-09-06 12:42:05 --> Router Class Initialized
INFO - 2024-09-06 12:42:05 --> Output Class Initialized
INFO - 2024-09-06 12:42:05 --> Security Class Initialized
DEBUG - 2024-09-06 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 12:42:05 --> Input Class Initialized
INFO - 2024-09-06 12:42:05 --> Language Class Initialized
INFO - 2024-09-06 12:42:05 --> Loader Class Initialized
INFO - 2024-09-06 12:42:05 --> Helper loaded: url_helper
INFO - 2024-09-06 12:42:05 --> Helper loaded: file_helper
INFO - 2024-09-06 12:42:05 --> Helper loaded: security_helper
INFO - 2024-09-06 12:42:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 12:42:05 --> Database Driver Class Initialized
INFO - 2024-09-06 12:42:05 --> Email Class Initialized
DEBUG - 2024-09-06 12:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 12:42:05 --> Helper loaded: form_helper
INFO - 2024-09-06 12:42:05 --> Form Validation Class Initialized
INFO - 2024-09-06 12:42:05 --> Controller Class Initialized
DEBUG - 2024-09-06 12:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 12:42:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 12:42:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 12:42:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 12:42:05 --> Final output sent to browser
DEBUG - 2024-09-06 12:42:05 --> Total execution time: 0.2246
INFO - 2024-09-06 13:12:05 --> Config Class Initialized
INFO - 2024-09-06 13:12:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 13:12:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 13:12:05 --> Utf8 Class Initialized
INFO - 2024-09-06 13:12:05 --> URI Class Initialized
DEBUG - 2024-09-06 13:12:05 --> No URI present. Default controller set.
INFO - 2024-09-06 13:12:05 --> Router Class Initialized
INFO - 2024-09-06 13:12:05 --> Output Class Initialized
INFO - 2024-09-06 13:12:05 --> Security Class Initialized
DEBUG - 2024-09-06 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 13:12:05 --> Input Class Initialized
INFO - 2024-09-06 13:12:05 --> Language Class Initialized
INFO - 2024-09-06 13:12:05 --> Loader Class Initialized
INFO - 2024-09-06 13:12:05 --> Helper loaded: url_helper
INFO - 2024-09-06 13:12:05 --> Helper loaded: file_helper
INFO - 2024-09-06 13:12:05 --> Helper loaded: security_helper
INFO - 2024-09-06 13:12:05 --> Helper loaded: wpu_helper
INFO - 2024-09-06 13:12:05 --> Database Driver Class Initialized
INFO - 2024-09-06 13:12:05 --> Email Class Initialized
DEBUG - 2024-09-06 13:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 13:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 13:12:05 --> Helper loaded: form_helper
INFO - 2024-09-06 13:12:05 --> Form Validation Class Initialized
INFO - 2024-09-06 13:12:05 --> Controller Class Initialized
DEBUG - 2024-09-06 13:12:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 13:12:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 13:12:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 13:12:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 13:12:05 --> Final output sent to browser
DEBUG - 2024-09-06 13:12:05 --> Total execution time: 0.2254
INFO - 2024-09-06 13:42:30 --> Config Class Initialized
INFO - 2024-09-06 13:42:30 --> Hooks Class Initialized
DEBUG - 2024-09-06 13:42:30 --> UTF-8 Support Enabled
INFO - 2024-09-06 13:42:30 --> Utf8 Class Initialized
INFO - 2024-09-06 13:42:30 --> URI Class Initialized
DEBUG - 2024-09-06 13:42:30 --> No URI present. Default controller set.
INFO - 2024-09-06 13:42:30 --> Router Class Initialized
INFO - 2024-09-06 13:42:30 --> Output Class Initialized
INFO - 2024-09-06 13:42:30 --> Security Class Initialized
DEBUG - 2024-09-06 13:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 13:42:30 --> Input Class Initialized
INFO - 2024-09-06 13:42:30 --> Language Class Initialized
INFO - 2024-09-06 13:42:30 --> Loader Class Initialized
INFO - 2024-09-06 13:42:30 --> Helper loaded: url_helper
INFO - 2024-09-06 13:42:30 --> Helper loaded: file_helper
INFO - 2024-09-06 13:42:30 --> Helper loaded: security_helper
INFO - 2024-09-06 13:42:30 --> Helper loaded: wpu_helper
INFO - 2024-09-06 13:42:30 --> Database Driver Class Initialized
INFO - 2024-09-06 13:42:30 --> Email Class Initialized
DEBUG - 2024-09-06 13:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 13:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 13:42:30 --> Helper loaded: form_helper
INFO - 2024-09-06 13:42:30 --> Form Validation Class Initialized
INFO - 2024-09-06 13:42:30 --> Controller Class Initialized
DEBUG - 2024-09-06 13:42:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 13:42:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 13:42:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 13:42:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 13:42:30 --> Final output sent to browser
DEBUG - 2024-09-06 13:42:30 --> Total execution time: 0.2220
INFO - 2024-09-06 14:11:33 --> Config Class Initialized
INFO - 2024-09-06 14:11:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 14:11:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 14:11:33 --> Utf8 Class Initialized
INFO - 2024-09-06 14:11:33 --> URI Class Initialized
DEBUG - 2024-09-06 14:11:33 --> No URI present. Default controller set.
INFO - 2024-09-06 14:11:33 --> Router Class Initialized
INFO - 2024-09-06 14:11:33 --> Output Class Initialized
INFO - 2024-09-06 14:11:33 --> Security Class Initialized
DEBUG - 2024-09-06 14:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 14:11:33 --> Input Class Initialized
INFO - 2024-09-06 14:11:33 --> Language Class Initialized
INFO - 2024-09-06 14:11:33 --> Loader Class Initialized
INFO - 2024-09-06 14:11:33 --> Helper loaded: url_helper
INFO - 2024-09-06 14:11:33 --> Helper loaded: file_helper
INFO - 2024-09-06 14:11:33 --> Helper loaded: security_helper
INFO - 2024-09-06 14:11:33 --> Helper loaded: wpu_helper
INFO - 2024-09-06 14:11:33 --> Database Driver Class Initialized
INFO - 2024-09-06 14:11:34 --> Email Class Initialized
DEBUG - 2024-09-06 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 14:11:34 --> Helper loaded: form_helper
INFO - 2024-09-06 14:11:34 --> Form Validation Class Initialized
INFO - 2024-09-06 14:11:34 --> Controller Class Initialized
DEBUG - 2024-09-06 14:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 14:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 14:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 14:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 14:11:34 --> Final output sent to browser
DEBUG - 2024-09-06 14:11:34 --> Total execution time: 0.2317
INFO - 2024-09-06 14:16:32 --> Config Class Initialized
INFO - 2024-09-06 14:16:32 --> Hooks Class Initialized
DEBUG - 2024-09-06 14:16:32 --> UTF-8 Support Enabled
INFO - 2024-09-06 14:16:32 --> Utf8 Class Initialized
INFO - 2024-09-06 14:16:32 --> URI Class Initialized
DEBUG - 2024-09-06 14:16:32 --> No URI present. Default controller set.
INFO - 2024-09-06 14:16:32 --> Router Class Initialized
INFO - 2024-09-06 14:16:32 --> Output Class Initialized
INFO - 2024-09-06 14:16:32 --> Security Class Initialized
DEBUG - 2024-09-06 14:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 14:16:32 --> Input Class Initialized
INFO - 2024-09-06 14:16:32 --> Language Class Initialized
INFO - 2024-09-06 14:16:32 --> Loader Class Initialized
INFO - 2024-09-06 14:16:32 --> Helper loaded: url_helper
INFO - 2024-09-06 14:16:32 --> Helper loaded: file_helper
INFO - 2024-09-06 14:16:32 --> Helper loaded: security_helper
INFO - 2024-09-06 14:16:32 --> Helper loaded: wpu_helper
INFO - 2024-09-06 14:16:32 --> Database Driver Class Initialized
INFO - 2024-09-06 14:16:32 --> Email Class Initialized
DEBUG - 2024-09-06 14:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 14:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 14:16:32 --> Helper loaded: form_helper
INFO - 2024-09-06 14:16:32 --> Form Validation Class Initialized
INFO - 2024-09-06 14:16:32 --> Controller Class Initialized
DEBUG - 2024-09-06 14:16:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 14:16:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 14:16:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 14:16:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 14:16:32 --> Final output sent to browser
DEBUG - 2024-09-06 14:16:32 --> Total execution time: 0.2284
INFO - 2024-09-06 14:42:24 --> Config Class Initialized
INFO - 2024-09-06 14:42:24 --> Hooks Class Initialized
DEBUG - 2024-09-06 14:42:24 --> UTF-8 Support Enabled
INFO - 2024-09-06 14:42:24 --> Utf8 Class Initialized
INFO - 2024-09-06 14:42:24 --> URI Class Initialized
DEBUG - 2024-09-06 14:42:24 --> No URI present. Default controller set.
INFO - 2024-09-06 14:42:24 --> Router Class Initialized
INFO - 2024-09-06 14:42:24 --> Output Class Initialized
INFO - 2024-09-06 14:42:24 --> Security Class Initialized
DEBUG - 2024-09-06 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 14:42:24 --> Input Class Initialized
INFO - 2024-09-06 14:42:24 --> Language Class Initialized
INFO - 2024-09-06 14:42:24 --> Loader Class Initialized
INFO - 2024-09-06 14:42:24 --> Helper loaded: url_helper
INFO - 2024-09-06 14:42:24 --> Helper loaded: file_helper
INFO - 2024-09-06 14:42:24 --> Helper loaded: security_helper
INFO - 2024-09-06 14:42:24 --> Helper loaded: wpu_helper
INFO - 2024-09-06 14:42:24 --> Database Driver Class Initialized
INFO - 2024-09-06 14:42:25 --> Email Class Initialized
DEBUG - 2024-09-06 14:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 14:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 14:42:25 --> Helper loaded: form_helper
INFO - 2024-09-06 14:42:25 --> Form Validation Class Initialized
INFO - 2024-09-06 14:42:25 --> Controller Class Initialized
DEBUG - 2024-09-06 14:42:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 14:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 14:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 14:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 14:42:25 --> Final output sent to browser
DEBUG - 2024-09-06 14:42:25 --> Total execution time: 0.2236
INFO - 2024-09-06 15:00:27 --> Config Class Initialized
INFO - 2024-09-06 15:00:27 --> Hooks Class Initialized
DEBUG - 2024-09-06 15:00:27 --> UTF-8 Support Enabled
INFO - 2024-09-06 15:00:27 --> Utf8 Class Initialized
INFO - 2024-09-06 15:00:27 --> URI Class Initialized
DEBUG - 2024-09-06 15:00:27 --> No URI present. Default controller set.
INFO - 2024-09-06 15:00:27 --> Router Class Initialized
INFO - 2024-09-06 15:00:27 --> Output Class Initialized
INFO - 2024-09-06 15:00:27 --> Security Class Initialized
DEBUG - 2024-09-06 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 15:00:27 --> Input Class Initialized
INFO - 2024-09-06 15:00:27 --> Language Class Initialized
INFO - 2024-09-06 15:00:27 --> Loader Class Initialized
INFO - 2024-09-06 15:00:27 --> Helper loaded: url_helper
INFO - 2024-09-06 15:00:27 --> Helper loaded: file_helper
INFO - 2024-09-06 15:00:27 --> Helper loaded: security_helper
INFO - 2024-09-06 15:00:27 --> Helper loaded: wpu_helper
INFO - 2024-09-06 15:00:27 --> Database Driver Class Initialized
INFO - 2024-09-06 15:00:27 --> Email Class Initialized
DEBUG - 2024-09-06 15:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 15:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 15:00:27 --> Helper loaded: form_helper
INFO - 2024-09-06 15:00:27 --> Form Validation Class Initialized
INFO - 2024-09-06 15:00:27 --> Controller Class Initialized
DEBUG - 2024-09-06 15:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 15:00:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 15:00:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 15:00:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 15:00:27 --> Final output sent to browser
DEBUG - 2024-09-06 15:00:27 --> Total execution time: 0.2163
INFO - 2024-09-06 15:00:28 --> Config Class Initialized
INFO - 2024-09-06 15:00:28 --> Hooks Class Initialized
DEBUG - 2024-09-06 15:00:28 --> UTF-8 Support Enabled
INFO - 2024-09-06 15:00:28 --> Utf8 Class Initialized
INFO - 2024-09-06 15:00:28 --> URI Class Initialized
DEBUG - 2024-09-06 15:00:28 --> No URI present. Default controller set.
INFO - 2024-09-06 15:00:28 --> Router Class Initialized
INFO - 2024-09-06 15:00:28 --> Output Class Initialized
INFO - 2024-09-06 15:00:28 --> Security Class Initialized
DEBUG - 2024-09-06 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 15:00:28 --> Input Class Initialized
INFO - 2024-09-06 15:00:28 --> Language Class Initialized
INFO - 2024-09-06 15:00:28 --> Loader Class Initialized
INFO - 2024-09-06 15:00:28 --> Helper loaded: url_helper
INFO - 2024-09-06 15:00:28 --> Helper loaded: file_helper
INFO - 2024-09-06 15:00:28 --> Helper loaded: security_helper
INFO - 2024-09-06 15:00:28 --> Helper loaded: wpu_helper
INFO - 2024-09-06 15:00:28 --> Database Driver Class Initialized
INFO - 2024-09-06 15:00:29 --> Email Class Initialized
DEBUG - 2024-09-06 15:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 15:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 15:00:29 --> Helper loaded: form_helper
INFO - 2024-09-06 15:00:29 --> Form Validation Class Initialized
INFO - 2024-09-06 15:00:29 --> Controller Class Initialized
DEBUG - 2024-09-06 15:00:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 15:00:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 15:00:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 15:00:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 15:00:29 --> Final output sent to browser
DEBUG - 2024-09-06 15:00:29 --> Total execution time: 0.2126
INFO - 2024-09-06 15:12:01 --> Config Class Initialized
INFO - 2024-09-06 15:12:01 --> Hooks Class Initialized
DEBUG - 2024-09-06 15:12:01 --> UTF-8 Support Enabled
INFO - 2024-09-06 15:12:01 --> Utf8 Class Initialized
INFO - 2024-09-06 15:12:01 --> URI Class Initialized
DEBUG - 2024-09-06 15:12:01 --> No URI present. Default controller set.
INFO - 2024-09-06 15:12:01 --> Router Class Initialized
INFO - 2024-09-06 15:12:01 --> Output Class Initialized
INFO - 2024-09-06 15:12:01 --> Security Class Initialized
DEBUG - 2024-09-06 15:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 15:12:01 --> Input Class Initialized
INFO - 2024-09-06 15:12:01 --> Language Class Initialized
INFO - 2024-09-06 15:12:01 --> Loader Class Initialized
INFO - 2024-09-06 15:12:01 --> Helper loaded: url_helper
INFO - 2024-09-06 15:12:01 --> Helper loaded: file_helper
INFO - 2024-09-06 15:12:01 --> Helper loaded: security_helper
INFO - 2024-09-06 15:12:01 --> Helper loaded: wpu_helper
INFO - 2024-09-06 15:12:01 --> Database Driver Class Initialized
INFO - 2024-09-06 15:12:01 --> Email Class Initialized
DEBUG - 2024-09-06 15:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 15:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 15:12:01 --> Helper loaded: form_helper
INFO - 2024-09-06 15:12:01 --> Form Validation Class Initialized
INFO - 2024-09-06 15:12:01 --> Controller Class Initialized
DEBUG - 2024-09-06 15:12:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 15:12:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 15:12:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 15:12:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 15:12:01 --> Final output sent to browser
DEBUG - 2024-09-06 15:12:01 --> Total execution time: 0.2194
INFO - 2024-09-06 15:42:33 --> Config Class Initialized
INFO - 2024-09-06 15:42:33 --> Hooks Class Initialized
DEBUG - 2024-09-06 15:42:33 --> UTF-8 Support Enabled
INFO - 2024-09-06 15:42:33 --> Utf8 Class Initialized
INFO - 2024-09-06 15:42:33 --> URI Class Initialized
DEBUG - 2024-09-06 15:42:33 --> No URI present. Default controller set.
INFO - 2024-09-06 15:42:33 --> Router Class Initialized
INFO - 2024-09-06 15:42:33 --> Output Class Initialized
INFO - 2024-09-06 15:42:33 --> Security Class Initialized
DEBUG - 2024-09-06 15:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 15:42:33 --> Input Class Initialized
INFO - 2024-09-06 15:42:33 --> Language Class Initialized
INFO - 2024-09-06 15:42:33 --> Loader Class Initialized
INFO - 2024-09-06 15:42:33 --> Helper loaded: url_helper
INFO - 2024-09-06 15:42:33 --> Helper loaded: file_helper
INFO - 2024-09-06 15:42:33 --> Helper loaded: security_helper
INFO - 2024-09-06 15:42:33 --> Helper loaded: wpu_helper
INFO - 2024-09-06 15:42:33 --> Database Driver Class Initialized
INFO - 2024-09-06 15:42:33 --> Email Class Initialized
DEBUG - 2024-09-06 15:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 15:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 15:42:33 --> Helper loaded: form_helper
INFO - 2024-09-06 15:42:33 --> Form Validation Class Initialized
INFO - 2024-09-06 15:42:33 --> Controller Class Initialized
DEBUG - 2024-09-06 15:42:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 15:42:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 15:42:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 15:42:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 15:42:33 --> Final output sent to browser
DEBUG - 2024-09-06 15:42:33 --> Total execution time: 0.2216
INFO - 2024-09-06 16:12:08 --> Config Class Initialized
INFO - 2024-09-06 16:12:08 --> Hooks Class Initialized
DEBUG - 2024-09-06 16:12:08 --> UTF-8 Support Enabled
INFO - 2024-09-06 16:12:08 --> Utf8 Class Initialized
INFO - 2024-09-06 16:12:08 --> URI Class Initialized
DEBUG - 2024-09-06 16:12:08 --> No URI present. Default controller set.
INFO - 2024-09-06 16:12:08 --> Router Class Initialized
INFO - 2024-09-06 16:12:08 --> Output Class Initialized
INFO - 2024-09-06 16:12:08 --> Security Class Initialized
DEBUG - 2024-09-06 16:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 16:12:08 --> Input Class Initialized
INFO - 2024-09-06 16:12:08 --> Language Class Initialized
INFO - 2024-09-06 16:12:08 --> Loader Class Initialized
INFO - 2024-09-06 16:12:08 --> Helper loaded: url_helper
INFO - 2024-09-06 16:12:08 --> Helper loaded: file_helper
INFO - 2024-09-06 16:12:08 --> Helper loaded: security_helper
INFO - 2024-09-06 16:12:08 --> Helper loaded: wpu_helper
INFO - 2024-09-06 16:12:08 --> Database Driver Class Initialized
INFO - 2024-09-06 16:12:09 --> Email Class Initialized
DEBUG - 2024-09-06 16:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 16:12:09 --> Helper loaded: form_helper
INFO - 2024-09-06 16:12:09 --> Form Validation Class Initialized
INFO - 2024-09-06 16:12:09 --> Controller Class Initialized
DEBUG - 2024-09-06 16:12:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 16:12:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 16:12:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 16:12:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 16:12:09 --> Final output sent to browser
DEBUG - 2024-09-06 16:12:09 --> Total execution time: 0.2162
INFO - 2024-09-06 16:42:20 --> Config Class Initialized
INFO - 2024-09-06 16:42:20 --> Hooks Class Initialized
DEBUG - 2024-09-06 16:42:20 --> UTF-8 Support Enabled
INFO - 2024-09-06 16:42:20 --> Utf8 Class Initialized
INFO - 2024-09-06 16:42:20 --> URI Class Initialized
DEBUG - 2024-09-06 16:42:20 --> No URI present. Default controller set.
INFO - 2024-09-06 16:42:20 --> Router Class Initialized
INFO - 2024-09-06 16:42:20 --> Output Class Initialized
INFO - 2024-09-06 16:42:20 --> Security Class Initialized
DEBUG - 2024-09-06 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 16:42:20 --> Input Class Initialized
INFO - 2024-09-06 16:42:20 --> Language Class Initialized
INFO - 2024-09-06 16:42:20 --> Loader Class Initialized
INFO - 2024-09-06 16:42:20 --> Helper loaded: url_helper
INFO - 2024-09-06 16:42:20 --> Helper loaded: file_helper
INFO - 2024-09-06 16:42:20 --> Helper loaded: security_helper
INFO - 2024-09-06 16:42:20 --> Helper loaded: wpu_helper
INFO - 2024-09-06 16:42:20 --> Database Driver Class Initialized
INFO - 2024-09-06 16:42:20 --> Email Class Initialized
DEBUG - 2024-09-06 16:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 16:42:20 --> Helper loaded: form_helper
INFO - 2024-09-06 16:42:20 --> Form Validation Class Initialized
INFO - 2024-09-06 16:42:20 --> Controller Class Initialized
DEBUG - 2024-09-06 16:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 16:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 16:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 16:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 16:42:20 --> Final output sent to browser
DEBUG - 2024-09-06 16:42:20 --> Total execution time: 0.2143
INFO - 2024-09-06 17:12:56 --> Config Class Initialized
INFO - 2024-09-06 17:12:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 17:12:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 17:12:56 --> Utf8 Class Initialized
INFO - 2024-09-06 17:12:56 --> URI Class Initialized
DEBUG - 2024-09-06 17:12:56 --> No URI present. Default controller set.
INFO - 2024-09-06 17:12:56 --> Router Class Initialized
INFO - 2024-09-06 17:12:56 --> Output Class Initialized
INFO - 2024-09-06 17:12:56 --> Security Class Initialized
DEBUG - 2024-09-06 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 17:12:56 --> Input Class Initialized
INFO - 2024-09-06 17:12:56 --> Language Class Initialized
INFO - 2024-09-06 17:12:56 --> Loader Class Initialized
INFO - 2024-09-06 17:12:56 --> Helper loaded: url_helper
INFO - 2024-09-06 17:12:56 --> Helper loaded: file_helper
INFO - 2024-09-06 17:12:56 --> Helper loaded: security_helper
INFO - 2024-09-06 17:12:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 17:12:56 --> Database Driver Class Initialized
INFO - 2024-09-06 17:12:57 --> Email Class Initialized
DEBUG - 2024-09-06 17:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 17:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 17:12:57 --> Helper loaded: form_helper
INFO - 2024-09-06 17:12:57 --> Form Validation Class Initialized
INFO - 2024-09-06 17:12:57 --> Controller Class Initialized
DEBUG - 2024-09-06 17:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 17:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 17:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 17:12:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 17:12:57 --> Final output sent to browser
DEBUG - 2024-09-06 17:12:57 --> Total execution time: 0.2153
INFO - 2024-09-06 17:15:12 --> Config Class Initialized
INFO - 2024-09-06 17:15:12 --> Hooks Class Initialized
DEBUG - 2024-09-06 17:15:12 --> UTF-8 Support Enabled
INFO - 2024-09-06 17:15:12 --> Utf8 Class Initialized
INFO - 2024-09-06 17:15:12 --> URI Class Initialized
DEBUG - 2024-09-06 17:15:12 --> No URI present. Default controller set.
INFO - 2024-09-06 17:15:12 --> Router Class Initialized
INFO - 2024-09-06 17:15:12 --> Output Class Initialized
INFO - 2024-09-06 17:15:12 --> Security Class Initialized
DEBUG - 2024-09-06 17:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 17:15:12 --> Input Class Initialized
INFO - 2024-09-06 17:15:12 --> Language Class Initialized
INFO - 2024-09-06 17:15:12 --> Loader Class Initialized
INFO - 2024-09-06 17:15:12 --> Helper loaded: url_helper
INFO - 2024-09-06 17:15:12 --> Helper loaded: file_helper
INFO - 2024-09-06 17:15:12 --> Helper loaded: security_helper
INFO - 2024-09-06 17:15:12 --> Helper loaded: wpu_helper
INFO - 2024-09-06 17:15:12 --> Database Driver Class Initialized
INFO - 2024-09-06 17:15:12 --> Email Class Initialized
DEBUG - 2024-09-06 17:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 17:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 17:15:12 --> Helper loaded: form_helper
INFO - 2024-09-06 17:15:12 --> Form Validation Class Initialized
INFO - 2024-09-06 17:15:12 --> Controller Class Initialized
DEBUG - 2024-09-06 17:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 17:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 17:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 17:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 17:15:12 --> Final output sent to browser
DEBUG - 2024-09-06 17:15:12 --> Total execution time: 0.2336
INFO - 2024-09-06 17:42:25 --> Config Class Initialized
INFO - 2024-09-06 17:42:25 --> Hooks Class Initialized
DEBUG - 2024-09-06 17:42:25 --> UTF-8 Support Enabled
INFO - 2024-09-06 17:42:25 --> Utf8 Class Initialized
INFO - 2024-09-06 17:42:25 --> URI Class Initialized
DEBUG - 2024-09-06 17:42:25 --> No URI present. Default controller set.
INFO - 2024-09-06 17:42:25 --> Router Class Initialized
INFO - 2024-09-06 17:42:25 --> Output Class Initialized
INFO - 2024-09-06 17:42:25 --> Security Class Initialized
DEBUG - 2024-09-06 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 17:42:25 --> Input Class Initialized
INFO - 2024-09-06 17:42:25 --> Language Class Initialized
INFO - 2024-09-06 17:42:25 --> Loader Class Initialized
INFO - 2024-09-06 17:42:25 --> Helper loaded: url_helper
INFO - 2024-09-06 17:42:25 --> Helper loaded: file_helper
INFO - 2024-09-06 17:42:25 --> Helper loaded: security_helper
INFO - 2024-09-06 17:42:25 --> Helper loaded: wpu_helper
INFO - 2024-09-06 17:42:25 --> Database Driver Class Initialized
INFO - 2024-09-06 17:42:25 --> Email Class Initialized
DEBUG - 2024-09-06 17:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 17:42:25 --> Helper loaded: form_helper
INFO - 2024-09-06 17:42:25 --> Form Validation Class Initialized
INFO - 2024-09-06 17:42:25 --> Controller Class Initialized
DEBUG - 2024-09-06 17:42:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 17:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 17:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 17:42:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 17:42:25 --> Final output sent to browser
DEBUG - 2024-09-06 17:42:25 --> Total execution time: 0.2162
INFO - 2024-09-06 18:13:01 --> Config Class Initialized
INFO - 2024-09-06 18:13:01 --> Hooks Class Initialized
DEBUG - 2024-09-06 18:13:01 --> UTF-8 Support Enabled
INFO - 2024-09-06 18:13:01 --> Utf8 Class Initialized
INFO - 2024-09-06 18:13:01 --> URI Class Initialized
DEBUG - 2024-09-06 18:13:01 --> No URI present. Default controller set.
INFO - 2024-09-06 18:13:01 --> Router Class Initialized
INFO - 2024-09-06 18:13:01 --> Output Class Initialized
INFO - 2024-09-06 18:13:01 --> Security Class Initialized
DEBUG - 2024-09-06 18:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 18:13:01 --> Input Class Initialized
INFO - 2024-09-06 18:13:01 --> Language Class Initialized
INFO - 2024-09-06 18:13:01 --> Loader Class Initialized
INFO - 2024-09-06 18:13:01 --> Helper loaded: url_helper
INFO - 2024-09-06 18:13:01 --> Helper loaded: file_helper
INFO - 2024-09-06 18:13:01 --> Helper loaded: security_helper
INFO - 2024-09-06 18:13:01 --> Helper loaded: wpu_helper
INFO - 2024-09-06 18:13:01 --> Database Driver Class Initialized
INFO - 2024-09-06 18:13:01 --> Email Class Initialized
DEBUG - 2024-09-06 18:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 18:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 18:13:01 --> Helper loaded: form_helper
INFO - 2024-09-06 18:13:01 --> Form Validation Class Initialized
INFO - 2024-09-06 18:13:01 --> Controller Class Initialized
DEBUG - 2024-09-06 18:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 18:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 18:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 18:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 18:13:01 --> Final output sent to browser
DEBUG - 2024-09-06 18:13:01 --> Total execution time: 0.2294
INFO - 2024-09-06 18:19:47 --> Config Class Initialized
INFO - 2024-09-06 18:19:47 --> Hooks Class Initialized
DEBUG - 2024-09-06 18:19:47 --> UTF-8 Support Enabled
INFO - 2024-09-06 18:19:47 --> Utf8 Class Initialized
INFO - 2024-09-06 18:19:47 --> URI Class Initialized
DEBUG - 2024-09-06 18:19:47 --> No URI present. Default controller set.
INFO - 2024-09-06 18:19:47 --> Router Class Initialized
INFO - 2024-09-06 18:19:47 --> Output Class Initialized
INFO - 2024-09-06 18:19:47 --> Security Class Initialized
DEBUG - 2024-09-06 18:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 18:19:47 --> Input Class Initialized
INFO - 2024-09-06 18:19:47 --> Language Class Initialized
INFO - 2024-09-06 18:19:47 --> Loader Class Initialized
INFO - 2024-09-06 18:19:47 --> Helper loaded: url_helper
INFO - 2024-09-06 18:19:47 --> Helper loaded: file_helper
INFO - 2024-09-06 18:19:47 --> Helper loaded: security_helper
INFO - 2024-09-06 18:19:47 --> Helper loaded: wpu_helper
INFO - 2024-09-06 18:19:47 --> Database Driver Class Initialized
INFO - 2024-09-06 18:19:47 --> Email Class Initialized
DEBUG - 2024-09-06 18:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 18:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 18:19:47 --> Helper loaded: form_helper
INFO - 2024-09-06 18:19:47 --> Form Validation Class Initialized
INFO - 2024-09-06 18:19:47 --> Controller Class Initialized
DEBUG - 2024-09-06 18:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 18:19:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 18:19:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 18:19:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 18:19:47 --> Final output sent to browser
DEBUG - 2024-09-06 18:19:47 --> Total execution time: 0.2206
INFO - 2024-09-06 18:19:58 --> Config Class Initialized
INFO - 2024-09-06 18:19:58 --> Hooks Class Initialized
DEBUG - 2024-09-06 18:19:58 --> UTF-8 Support Enabled
INFO - 2024-09-06 18:19:58 --> Utf8 Class Initialized
INFO - 2024-09-06 18:19:58 --> URI Class Initialized
DEBUG - 2024-09-06 18:19:58 --> No URI present. Default controller set.
INFO - 2024-09-06 18:19:58 --> Router Class Initialized
INFO - 2024-09-06 18:19:58 --> Output Class Initialized
INFO - 2024-09-06 18:19:58 --> Security Class Initialized
DEBUG - 2024-09-06 18:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 18:19:58 --> Input Class Initialized
INFO - 2024-09-06 18:19:58 --> Language Class Initialized
INFO - 2024-09-06 18:19:58 --> Loader Class Initialized
INFO - 2024-09-06 18:19:58 --> Helper loaded: url_helper
INFO - 2024-09-06 18:19:58 --> Helper loaded: file_helper
INFO - 2024-09-06 18:19:58 --> Helper loaded: security_helper
INFO - 2024-09-06 18:19:58 --> Helper loaded: wpu_helper
INFO - 2024-09-06 18:19:58 --> Database Driver Class Initialized
INFO - 2024-09-06 18:19:58 --> Email Class Initialized
DEBUG - 2024-09-06 18:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 18:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 18:19:58 --> Helper loaded: form_helper
INFO - 2024-09-06 18:19:58 --> Form Validation Class Initialized
INFO - 2024-09-06 18:19:58 --> Controller Class Initialized
DEBUG - 2024-09-06 18:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 18:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 18:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 18:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 18:19:58 --> Final output sent to browser
DEBUG - 2024-09-06 18:19:58 --> Total execution time: 0.2169
INFO - 2024-09-06 18:43:01 --> Config Class Initialized
INFO - 2024-09-06 18:43:01 --> Hooks Class Initialized
DEBUG - 2024-09-06 18:43:01 --> UTF-8 Support Enabled
INFO - 2024-09-06 18:43:01 --> Utf8 Class Initialized
INFO - 2024-09-06 18:43:01 --> URI Class Initialized
DEBUG - 2024-09-06 18:43:01 --> No URI present. Default controller set.
INFO - 2024-09-06 18:43:01 --> Router Class Initialized
INFO - 2024-09-06 18:43:01 --> Output Class Initialized
INFO - 2024-09-06 18:43:01 --> Security Class Initialized
DEBUG - 2024-09-06 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 18:43:01 --> Input Class Initialized
INFO - 2024-09-06 18:43:01 --> Language Class Initialized
INFO - 2024-09-06 18:43:01 --> Loader Class Initialized
INFO - 2024-09-06 18:43:01 --> Helper loaded: url_helper
INFO - 2024-09-06 18:43:01 --> Helper loaded: file_helper
INFO - 2024-09-06 18:43:01 --> Helper loaded: security_helper
INFO - 2024-09-06 18:43:01 --> Helper loaded: wpu_helper
INFO - 2024-09-06 18:43:01 --> Database Driver Class Initialized
INFO - 2024-09-06 18:43:02 --> Email Class Initialized
DEBUG - 2024-09-06 18:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 18:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 18:43:02 --> Helper loaded: form_helper
INFO - 2024-09-06 18:43:02 --> Form Validation Class Initialized
INFO - 2024-09-06 18:43:02 --> Controller Class Initialized
DEBUG - 2024-09-06 18:43:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 18:43:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 18:43:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 18:43:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 18:43:02 --> Final output sent to browser
DEBUG - 2024-09-06 18:43:02 --> Total execution time: 0.2487
INFO - 2024-09-06 19:12:51 --> Config Class Initialized
INFO - 2024-09-06 19:12:51 --> Hooks Class Initialized
DEBUG - 2024-09-06 19:12:51 --> UTF-8 Support Enabled
INFO - 2024-09-06 19:12:51 --> Utf8 Class Initialized
INFO - 2024-09-06 19:12:51 --> URI Class Initialized
DEBUG - 2024-09-06 19:12:51 --> No URI present. Default controller set.
INFO - 2024-09-06 19:12:51 --> Router Class Initialized
INFO - 2024-09-06 19:12:51 --> Output Class Initialized
INFO - 2024-09-06 19:12:51 --> Security Class Initialized
DEBUG - 2024-09-06 19:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 19:12:51 --> Input Class Initialized
INFO - 2024-09-06 19:12:51 --> Language Class Initialized
INFO - 2024-09-06 19:12:51 --> Loader Class Initialized
INFO - 2024-09-06 19:12:51 --> Helper loaded: url_helper
INFO - 2024-09-06 19:12:51 --> Helper loaded: file_helper
INFO - 2024-09-06 19:12:51 --> Helper loaded: security_helper
INFO - 2024-09-06 19:12:51 --> Helper loaded: wpu_helper
INFO - 2024-09-06 19:12:51 --> Database Driver Class Initialized
INFO - 2024-09-06 19:12:51 --> Email Class Initialized
DEBUG - 2024-09-06 19:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 19:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 19:12:51 --> Helper loaded: form_helper
INFO - 2024-09-06 19:12:51 --> Form Validation Class Initialized
INFO - 2024-09-06 19:12:51 --> Controller Class Initialized
DEBUG - 2024-09-06 19:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 19:12:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 19:12:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 19:12:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 19:12:51 --> Final output sent to browser
DEBUG - 2024-09-06 19:12:51 --> Total execution time: 0.2216
INFO - 2024-09-06 19:43:09 --> Config Class Initialized
INFO - 2024-09-06 19:43:09 --> Hooks Class Initialized
DEBUG - 2024-09-06 19:43:09 --> UTF-8 Support Enabled
INFO - 2024-09-06 19:43:09 --> Utf8 Class Initialized
INFO - 2024-09-06 19:43:09 --> URI Class Initialized
DEBUG - 2024-09-06 19:43:09 --> No URI present. Default controller set.
INFO - 2024-09-06 19:43:09 --> Router Class Initialized
INFO - 2024-09-06 19:43:09 --> Output Class Initialized
INFO - 2024-09-06 19:43:09 --> Security Class Initialized
DEBUG - 2024-09-06 19:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 19:43:09 --> Input Class Initialized
INFO - 2024-09-06 19:43:09 --> Language Class Initialized
INFO - 2024-09-06 19:43:09 --> Loader Class Initialized
INFO - 2024-09-06 19:43:09 --> Helper loaded: url_helper
INFO - 2024-09-06 19:43:09 --> Helper loaded: file_helper
INFO - 2024-09-06 19:43:09 --> Helper loaded: security_helper
INFO - 2024-09-06 19:43:09 --> Helper loaded: wpu_helper
INFO - 2024-09-06 19:43:09 --> Database Driver Class Initialized
INFO - 2024-09-06 19:43:10 --> Email Class Initialized
DEBUG - 2024-09-06 19:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 19:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 19:43:10 --> Helper loaded: form_helper
INFO - 2024-09-06 19:43:10 --> Form Validation Class Initialized
INFO - 2024-09-06 19:43:10 --> Controller Class Initialized
DEBUG - 2024-09-06 19:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 19:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 19:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 19:43:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 19:43:10 --> Final output sent to browser
DEBUG - 2024-09-06 19:43:10 --> Total execution time: 0.2179
INFO - 2024-09-06 20:11:46 --> Config Class Initialized
INFO - 2024-09-06 20:11:46 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:11:46 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:11:46 --> Utf8 Class Initialized
INFO - 2024-09-06 20:11:46 --> URI Class Initialized
DEBUG - 2024-09-06 20:11:46 --> No URI present. Default controller set.
INFO - 2024-09-06 20:11:46 --> Router Class Initialized
INFO - 2024-09-06 20:11:46 --> Output Class Initialized
INFO - 2024-09-06 20:11:46 --> Security Class Initialized
DEBUG - 2024-09-06 20:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:11:46 --> Input Class Initialized
INFO - 2024-09-06 20:11:46 --> Language Class Initialized
INFO - 2024-09-06 20:11:46 --> Loader Class Initialized
INFO - 2024-09-06 20:11:46 --> Helper loaded: url_helper
INFO - 2024-09-06 20:11:46 --> Helper loaded: file_helper
INFO - 2024-09-06 20:11:46 --> Helper loaded: security_helper
INFO - 2024-09-06 20:11:46 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:11:46 --> Database Driver Class Initialized
INFO - 2024-09-06 20:11:46 --> Email Class Initialized
DEBUG - 2024-09-06 20:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:11:46 --> Helper loaded: form_helper
INFO - 2024-09-06 20:11:46 --> Form Validation Class Initialized
INFO - 2024-09-06 20:11:46 --> Controller Class Initialized
DEBUG - 2024-09-06 20:11:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:11:46 --> Final output sent to browser
DEBUG - 2024-09-06 20:11:46 --> Total execution time: 0.2208
INFO - 2024-09-06 20:17:19 --> Config Class Initialized
INFO - 2024-09-06 20:17:19 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:17:19 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:17:19 --> Utf8 Class Initialized
INFO - 2024-09-06 20:17:19 --> URI Class Initialized
DEBUG - 2024-09-06 20:17:19 --> No URI present. Default controller set.
INFO - 2024-09-06 20:17:19 --> Router Class Initialized
INFO - 2024-09-06 20:17:19 --> Output Class Initialized
INFO - 2024-09-06 20:17:19 --> Security Class Initialized
DEBUG - 2024-09-06 20:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:17:19 --> Input Class Initialized
INFO - 2024-09-06 20:17:19 --> Language Class Initialized
INFO - 2024-09-06 20:17:19 --> Loader Class Initialized
INFO - 2024-09-06 20:17:19 --> Helper loaded: url_helper
INFO - 2024-09-06 20:17:19 --> Helper loaded: file_helper
INFO - 2024-09-06 20:17:19 --> Helper loaded: security_helper
INFO - 2024-09-06 20:17:19 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:17:19 --> Database Driver Class Initialized
INFO - 2024-09-06 20:17:19 --> Email Class Initialized
DEBUG - 2024-09-06 20:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:17:19 --> Helper loaded: form_helper
INFO - 2024-09-06 20:17:19 --> Form Validation Class Initialized
INFO - 2024-09-06 20:17:19 --> Controller Class Initialized
DEBUG - 2024-09-06 20:17:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:17:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:17:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:17:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:17:19 --> Final output sent to browser
DEBUG - 2024-09-06 20:17:19 --> Total execution time: 0.2178
INFO - 2024-09-06 20:31:10 --> Config Class Initialized
INFO - 2024-09-06 20:31:10 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:31:10 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:31:10 --> Utf8 Class Initialized
INFO - 2024-09-06 20:31:10 --> URI Class Initialized
DEBUG - 2024-09-06 20:31:10 --> No URI present. Default controller set.
INFO - 2024-09-06 20:31:10 --> Router Class Initialized
INFO - 2024-09-06 20:31:10 --> Output Class Initialized
INFO - 2024-09-06 20:31:10 --> Security Class Initialized
DEBUG - 2024-09-06 20:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:31:10 --> Input Class Initialized
INFO - 2024-09-06 20:31:10 --> Language Class Initialized
INFO - 2024-09-06 20:31:10 --> Loader Class Initialized
INFO - 2024-09-06 20:31:10 --> Helper loaded: url_helper
INFO - 2024-09-06 20:31:10 --> Helper loaded: file_helper
INFO - 2024-09-06 20:31:10 --> Helper loaded: security_helper
INFO - 2024-09-06 20:31:10 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:31:10 --> Database Driver Class Initialized
INFO - 2024-09-06 20:31:10 --> Email Class Initialized
DEBUG - 2024-09-06 20:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:31:10 --> Helper loaded: form_helper
INFO - 2024-09-06 20:31:10 --> Form Validation Class Initialized
INFO - 2024-09-06 20:31:10 --> Controller Class Initialized
DEBUG - 2024-09-06 20:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:31:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:31:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:31:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:31:10 --> Final output sent to browser
DEBUG - 2024-09-06 20:31:10 --> Total execution time: 0.2112
INFO - 2024-09-06 20:31:11 --> Config Class Initialized
INFO - 2024-09-06 20:31:11 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:31:11 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:31:11 --> Utf8 Class Initialized
INFO - 2024-09-06 20:31:11 --> URI Class Initialized
DEBUG - 2024-09-06 20:31:11 --> No URI present. Default controller set.
INFO - 2024-09-06 20:31:11 --> Router Class Initialized
INFO - 2024-09-06 20:31:11 --> Output Class Initialized
INFO - 2024-09-06 20:31:11 --> Security Class Initialized
DEBUG - 2024-09-06 20:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:31:11 --> Input Class Initialized
INFO - 2024-09-06 20:31:11 --> Language Class Initialized
INFO - 2024-09-06 20:31:11 --> Loader Class Initialized
INFO - 2024-09-06 20:31:11 --> Helper loaded: url_helper
INFO - 2024-09-06 20:31:11 --> Helper loaded: file_helper
INFO - 2024-09-06 20:31:11 --> Helper loaded: security_helper
INFO - 2024-09-06 20:31:11 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:31:11 --> Database Driver Class Initialized
INFO - 2024-09-06 20:31:11 --> Email Class Initialized
DEBUG - 2024-09-06 20:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:31:11 --> Helper loaded: form_helper
INFO - 2024-09-06 20:31:11 --> Form Validation Class Initialized
INFO - 2024-09-06 20:31:11 --> Controller Class Initialized
DEBUG - 2024-09-06 20:31:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:31:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:31:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:31:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:31:11 --> Final output sent to browser
DEBUG - 2024-09-06 20:31:11 --> Total execution time: 0.2092
INFO - 2024-09-06 20:38:58 --> Config Class Initialized
INFO - 2024-09-06 20:38:58 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:38:58 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:38:58 --> Utf8 Class Initialized
INFO - 2024-09-06 20:38:58 --> URI Class Initialized
DEBUG - 2024-09-06 20:38:58 --> No URI present. Default controller set.
INFO - 2024-09-06 20:38:58 --> Router Class Initialized
INFO - 2024-09-06 20:38:58 --> Output Class Initialized
INFO - 2024-09-06 20:38:58 --> Security Class Initialized
DEBUG - 2024-09-06 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:38:58 --> Input Class Initialized
INFO - 2024-09-06 20:38:58 --> Language Class Initialized
INFO - 2024-09-06 20:38:58 --> Loader Class Initialized
INFO - 2024-09-06 20:38:58 --> Helper loaded: url_helper
INFO - 2024-09-06 20:38:58 --> Helper loaded: file_helper
INFO - 2024-09-06 20:38:58 --> Helper loaded: security_helper
INFO - 2024-09-06 20:38:58 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:38:58 --> Database Driver Class Initialized
INFO - 2024-09-06 20:38:59 --> Email Class Initialized
DEBUG - 2024-09-06 20:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:38:59 --> Helper loaded: form_helper
INFO - 2024-09-06 20:38:59 --> Form Validation Class Initialized
INFO - 2024-09-06 20:38:59 --> Controller Class Initialized
DEBUG - 2024-09-06 20:38:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:38:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:38:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:38:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:38:59 --> Final output sent to browser
DEBUG - 2024-09-06 20:38:59 --> Total execution time: 0.2283
INFO - 2024-09-06 20:39:00 --> Config Class Initialized
INFO - 2024-09-06 20:39:00 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:39:00 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:39:00 --> Utf8 Class Initialized
INFO - 2024-09-06 20:39:00 --> URI Class Initialized
DEBUG - 2024-09-06 20:39:00 --> No URI present. Default controller set.
INFO - 2024-09-06 20:39:00 --> Router Class Initialized
INFO - 2024-09-06 20:39:00 --> Output Class Initialized
INFO - 2024-09-06 20:39:00 --> Security Class Initialized
DEBUG - 2024-09-06 20:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:39:00 --> Input Class Initialized
INFO - 2024-09-06 20:39:00 --> Language Class Initialized
INFO - 2024-09-06 20:39:00 --> Loader Class Initialized
INFO - 2024-09-06 20:39:00 --> Helper loaded: url_helper
INFO - 2024-09-06 20:39:00 --> Helper loaded: file_helper
INFO - 2024-09-06 20:39:00 --> Helper loaded: security_helper
INFO - 2024-09-06 20:39:00 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:39:00 --> Database Driver Class Initialized
INFO - 2024-09-06 20:39:00 --> Email Class Initialized
DEBUG - 2024-09-06 20:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:39:00 --> Helper loaded: form_helper
INFO - 2024-09-06 20:39:00 --> Form Validation Class Initialized
INFO - 2024-09-06 20:39:00 --> Controller Class Initialized
DEBUG - 2024-09-06 20:39:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:39:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:39:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:39:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:39:00 --> Final output sent to browser
DEBUG - 2024-09-06 20:39:00 --> Total execution time: 0.2202
INFO - 2024-09-06 20:43:16 --> Config Class Initialized
INFO - 2024-09-06 20:43:16 --> Hooks Class Initialized
DEBUG - 2024-09-06 20:43:16 --> UTF-8 Support Enabled
INFO - 2024-09-06 20:43:16 --> Utf8 Class Initialized
INFO - 2024-09-06 20:43:16 --> URI Class Initialized
DEBUG - 2024-09-06 20:43:16 --> No URI present. Default controller set.
INFO - 2024-09-06 20:43:16 --> Router Class Initialized
INFO - 2024-09-06 20:43:16 --> Output Class Initialized
INFO - 2024-09-06 20:43:16 --> Security Class Initialized
DEBUG - 2024-09-06 20:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 20:43:16 --> Input Class Initialized
INFO - 2024-09-06 20:43:16 --> Language Class Initialized
INFO - 2024-09-06 20:43:16 --> Loader Class Initialized
INFO - 2024-09-06 20:43:16 --> Helper loaded: url_helper
INFO - 2024-09-06 20:43:16 --> Helper loaded: file_helper
INFO - 2024-09-06 20:43:16 --> Helper loaded: security_helper
INFO - 2024-09-06 20:43:16 --> Helper loaded: wpu_helper
INFO - 2024-09-06 20:43:16 --> Database Driver Class Initialized
INFO - 2024-09-06 20:43:17 --> Email Class Initialized
DEBUG - 2024-09-06 20:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 20:43:17 --> Helper loaded: form_helper
INFO - 2024-09-06 20:43:17 --> Form Validation Class Initialized
INFO - 2024-09-06 20:43:17 --> Controller Class Initialized
DEBUG - 2024-09-06 20:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 20:43:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 20:43:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 20:43:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 20:43:17 --> Final output sent to browser
DEBUG - 2024-09-06 20:43:17 --> Total execution time: 0.2249
INFO - 2024-09-06 21:13:56 --> Config Class Initialized
INFO - 2024-09-06 21:13:56 --> Hooks Class Initialized
DEBUG - 2024-09-06 21:13:56 --> UTF-8 Support Enabled
INFO - 2024-09-06 21:13:56 --> Utf8 Class Initialized
INFO - 2024-09-06 21:13:56 --> URI Class Initialized
DEBUG - 2024-09-06 21:13:56 --> No URI present. Default controller set.
INFO - 2024-09-06 21:13:56 --> Router Class Initialized
INFO - 2024-09-06 21:13:56 --> Output Class Initialized
INFO - 2024-09-06 21:13:56 --> Security Class Initialized
DEBUG - 2024-09-06 21:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 21:13:56 --> Input Class Initialized
INFO - 2024-09-06 21:13:56 --> Language Class Initialized
INFO - 2024-09-06 21:13:56 --> Loader Class Initialized
INFO - 2024-09-06 21:13:56 --> Helper loaded: url_helper
INFO - 2024-09-06 21:13:56 --> Helper loaded: file_helper
INFO - 2024-09-06 21:13:56 --> Helper loaded: security_helper
INFO - 2024-09-06 21:13:56 --> Helper loaded: wpu_helper
INFO - 2024-09-06 21:13:56 --> Database Driver Class Initialized
INFO - 2024-09-06 21:13:57 --> Email Class Initialized
DEBUG - 2024-09-06 21:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 21:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 21:13:57 --> Helper loaded: form_helper
INFO - 2024-09-06 21:13:57 --> Form Validation Class Initialized
INFO - 2024-09-06 21:13:57 --> Controller Class Initialized
DEBUG - 2024-09-06 21:13:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 21:13:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 21:13:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 21:13:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 21:13:57 --> Final output sent to browser
DEBUG - 2024-09-06 21:13:57 --> Total execution time: 0.5686
INFO - 2024-09-06 21:41:53 --> Config Class Initialized
INFO - 2024-09-06 21:41:53 --> Hooks Class Initialized
DEBUG - 2024-09-06 21:41:53 --> UTF-8 Support Enabled
INFO - 2024-09-06 21:41:53 --> Utf8 Class Initialized
INFO - 2024-09-06 21:41:53 --> URI Class Initialized
DEBUG - 2024-09-06 21:41:53 --> No URI present. Default controller set.
INFO - 2024-09-06 21:41:53 --> Router Class Initialized
INFO - 2024-09-06 21:41:53 --> Output Class Initialized
INFO - 2024-09-06 21:41:53 --> Security Class Initialized
DEBUG - 2024-09-06 21:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 21:41:53 --> Input Class Initialized
INFO - 2024-09-06 21:41:53 --> Language Class Initialized
INFO - 2024-09-06 21:41:53 --> Loader Class Initialized
INFO - 2024-09-06 21:41:53 --> Helper loaded: url_helper
INFO - 2024-09-06 21:41:53 --> Helper loaded: file_helper
INFO - 2024-09-06 21:41:53 --> Helper loaded: security_helper
INFO - 2024-09-06 21:41:53 --> Helper loaded: wpu_helper
INFO - 2024-09-06 21:41:53 --> Database Driver Class Initialized
INFO - 2024-09-06 21:41:53 --> Email Class Initialized
DEBUG - 2024-09-06 21:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 21:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 21:41:53 --> Helper loaded: form_helper
INFO - 2024-09-06 21:41:53 --> Form Validation Class Initialized
INFO - 2024-09-06 21:41:53 --> Controller Class Initialized
DEBUG - 2024-09-06 21:41:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 21:41:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 21:41:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 21:41:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 21:41:53 --> Final output sent to browser
DEBUG - 2024-09-06 21:41:53 --> Total execution time: 0.2141
INFO - 2024-09-06 22:12:45 --> Config Class Initialized
INFO - 2024-09-06 22:12:45 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:12:45 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:12:45 --> Utf8 Class Initialized
INFO - 2024-09-06 22:12:45 --> URI Class Initialized
DEBUG - 2024-09-06 22:12:46 --> No URI present. Default controller set.
INFO - 2024-09-06 22:12:46 --> Router Class Initialized
INFO - 2024-09-06 22:12:46 --> Output Class Initialized
INFO - 2024-09-06 22:12:46 --> Security Class Initialized
DEBUG - 2024-09-06 22:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:12:46 --> Input Class Initialized
INFO - 2024-09-06 22:12:46 --> Language Class Initialized
INFO - 2024-09-06 22:12:46 --> Loader Class Initialized
INFO - 2024-09-06 22:12:46 --> Helper loaded: url_helper
INFO - 2024-09-06 22:12:46 --> Helper loaded: file_helper
INFO - 2024-09-06 22:12:46 --> Helper loaded: security_helper
INFO - 2024-09-06 22:12:46 --> Helper loaded: wpu_helper
INFO - 2024-09-06 22:12:46 --> Database Driver Class Initialized
INFO - 2024-09-06 22:12:46 --> Email Class Initialized
DEBUG - 2024-09-06 22:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 22:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 22:12:46 --> Helper loaded: form_helper
INFO - 2024-09-06 22:12:46 --> Form Validation Class Initialized
INFO - 2024-09-06 22:12:46 --> Controller Class Initialized
DEBUG - 2024-09-06 22:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 22:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 22:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 22:12:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 22:12:46 --> Final output sent to browser
DEBUG - 2024-09-06 22:12:46 --> Total execution time: 0.2337
INFO - 2024-09-06 22:42:39 --> Config Class Initialized
INFO - 2024-09-06 22:42:39 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:42:39 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:42:39 --> Utf8 Class Initialized
INFO - 2024-09-06 22:42:39 --> URI Class Initialized
DEBUG - 2024-09-06 22:42:39 --> No URI present. Default controller set.
INFO - 2024-09-06 22:42:39 --> Router Class Initialized
INFO - 2024-09-06 22:42:39 --> Output Class Initialized
INFO - 2024-09-06 22:42:39 --> Security Class Initialized
DEBUG - 2024-09-06 22:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:42:39 --> Input Class Initialized
INFO - 2024-09-06 22:42:39 --> Language Class Initialized
INFO - 2024-09-06 22:42:39 --> Loader Class Initialized
INFO - 2024-09-06 22:42:39 --> Helper loaded: url_helper
INFO - 2024-09-06 22:42:39 --> Helper loaded: file_helper
INFO - 2024-09-06 22:42:39 --> Helper loaded: security_helper
INFO - 2024-09-06 22:42:39 --> Helper loaded: wpu_helper
INFO - 2024-09-06 22:42:39 --> Database Driver Class Initialized
INFO - 2024-09-06 22:42:39 --> Email Class Initialized
DEBUG - 2024-09-06 22:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 22:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 22:42:39 --> Helper loaded: form_helper
INFO - 2024-09-06 22:42:39 --> Form Validation Class Initialized
INFO - 2024-09-06 22:42:39 --> Controller Class Initialized
DEBUG - 2024-09-06 22:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 22:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 22:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 22:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 22:42:39 --> Final output sent to browser
DEBUG - 2024-09-06 22:42:39 --> Total execution time: 0.2183
INFO - 2024-09-06 22:56:02 --> Config Class Initialized
INFO - 2024-09-06 22:56:02 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:02 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:02 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:02 --> URI Class Initialized
INFO - 2024-09-06 22:56:02 --> Router Class Initialized
INFO - 2024-09-06 22:56:02 --> Output Class Initialized
INFO - 2024-09-06 22:56:02 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:02 --> Input Class Initialized
INFO - 2024-09-06 22:56:02 --> Language Class Initialized
ERROR - 2024-09-06 22:56:02 --> 404 Page Not Found: Envexemple/index
INFO - 2024-09-06 22:56:02 --> Config Class Initialized
INFO - 2024-09-06 22:56:02 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:02 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:02 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:02 --> URI Class Initialized
INFO - 2024-09-06 22:56:02 --> Router Class Initialized
INFO - 2024-09-06 22:56:02 --> Output Class Initialized
INFO - 2024-09-06 22:56:02 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:02 --> Input Class Initialized
INFO - 2024-09-06 22:56:02 --> Language Class Initialized
ERROR - 2024-09-06 22:56:02 --> 404 Page Not Found: Env_exemple/index
INFO - 2024-09-06 22:56:03 --> Config Class Initialized
INFO - 2024-09-06 22:56:03 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:03 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:03 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:03 --> URI Class Initialized
INFO - 2024-09-06 22:56:03 --> Router Class Initialized
INFO - 2024-09-06 22:56:03 --> Output Class Initialized
INFO - 2024-09-06 22:56:03 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:03 --> Input Class Initialized
INFO - 2024-09-06 22:56:03 --> Language Class Initialized
ERROR - 2024-09-06 22:56:03 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-09-06 22:56:03 --> Config Class Initialized
INFO - 2024-09-06 22:56:03 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:03 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:03 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:03 --> URI Class Initialized
INFO - 2024-09-06 22:56:03 --> Router Class Initialized
INFO - 2024-09-06 22:56:03 --> Output Class Initialized
INFO - 2024-09-06 22:56:03 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:03 --> Input Class Initialized
INFO - 2024-09-06 22:56:03 --> Language Class Initialized
ERROR - 2024-09-06 22:56:03 --> 404 Page Not Found: Aws/credentials
INFO - 2024-09-06 22:56:04 --> Config Class Initialized
INFO - 2024-09-06 22:56:04 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:04 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:04 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:04 --> URI Class Initialized
INFO - 2024-09-06 22:56:04 --> Router Class Initialized
INFO - 2024-09-06 22:56:04 --> Output Class Initialized
INFO - 2024-09-06 22:56:04 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:04 --> Input Class Initialized
INFO - 2024-09-06 22:56:04 --> Language Class Initialized
ERROR - 2024-09-06 22:56:04 --> 404 Page Not Found: Phpinfophp/index
INFO - 2024-09-06 22:56:04 --> Config Class Initialized
INFO - 2024-09-06 22:56:04 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:04 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:04 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:04 --> URI Class Initialized
INFO - 2024-09-06 22:56:04 --> Router Class Initialized
INFO - 2024-09-06 22:56:04 --> Output Class Initialized
INFO - 2024-09-06 22:56:04 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:04 --> Input Class Initialized
INFO - 2024-09-06 22:56:04 --> Language Class Initialized
ERROR - 2024-09-06 22:56:04 --> 404 Page Not Found: Phpinfo/index
INFO - 2024-09-06 22:56:05 --> Config Class Initialized
INFO - 2024-09-06 22:56:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:05 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:05 --> URI Class Initialized
INFO - 2024-09-06 22:56:05 --> Router Class Initialized
INFO - 2024-09-06 22:56:05 --> Output Class Initialized
INFO - 2024-09-06 22:56:05 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:05 --> Input Class Initialized
INFO - 2024-09-06 22:56:05 --> Language Class Initialized
ERROR - 2024-09-06 22:56:05 --> 404 Page Not Found: Info/index
INFO - 2024-09-06 22:56:05 --> Config Class Initialized
INFO - 2024-09-06 22:56:05 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:05 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:05 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:05 --> URI Class Initialized
INFO - 2024-09-06 22:56:05 --> Router Class Initialized
INFO - 2024-09-06 22:56:05 --> Output Class Initialized
INFO - 2024-09-06 22:56:05 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:05 --> Input Class Initialized
INFO - 2024-09-06 22:56:05 --> Language Class Initialized
ERROR - 2024-09-06 22:56:05 --> 404 Page Not Found: Php_info/index
INFO - 2024-09-06 22:56:06 --> Config Class Initialized
INFO - 2024-09-06 22:56:06 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:06 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:06 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:06 --> URI Class Initialized
INFO - 2024-09-06 22:56:06 --> Router Class Initialized
INFO - 2024-09-06 22:56:06 --> Output Class Initialized
INFO - 2024-09-06 22:56:06 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:06 --> Input Class Initialized
INFO - 2024-09-06 22:56:06 --> Language Class Initialized
ERROR - 2024-09-06 22:56:06 --> 404 Page Not Found: Php_infophp/index
INFO - 2024-09-06 22:56:06 --> Config Class Initialized
INFO - 2024-09-06 22:56:06 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:06 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:06 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:06 --> URI Class Initialized
INFO - 2024-09-06 22:56:06 --> Router Class Initialized
INFO - 2024-09-06 22:56:06 --> Output Class Initialized
INFO - 2024-09-06 22:56:06 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:06 --> Input Class Initialized
INFO - 2024-09-06 22:56:06 --> Language Class Initialized
ERROR - 2024-09-06 22:56:06 --> 404 Page Not Found: Infophp/index
INFO - 2024-09-06 22:56:07 --> Config Class Initialized
INFO - 2024-09-06 22:56:07 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:07 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:07 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:07 --> URI Class Initialized
INFO - 2024-09-06 22:56:07 --> Router Class Initialized
INFO - 2024-09-06 22:56:07 --> Output Class Initialized
INFO - 2024-09-06 22:56:07 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:07 --> Input Class Initialized
INFO - 2024-09-06 22:56:07 --> Language Class Initialized
ERROR - 2024-09-06 22:56:07 --> 404 Page Not Found: _profiler/phpinfo.php
INFO - 2024-09-06 22:56:07 --> Config Class Initialized
INFO - 2024-09-06 22:56:07 --> Hooks Class Initialized
DEBUG - 2024-09-06 22:56:07 --> UTF-8 Support Enabled
INFO - 2024-09-06 22:56:07 --> Utf8 Class Initialized
INFO - 2024-09-06 22:56:07 --> URI Class Initialized
INFO - 2024-09-06 22:56:07 --> Router Class Initialized
INFO - 2024-09-06 22:56:07 --> Output Class Initialized
INFO - 2024-09-06 22:56:07 --> Security Class Initialized
DEBUG - 2024-09-06 22:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 22:56:07 --> Input Class Initialized
INFO - 2024-09-06 22:56:07 --> Language Class Initialized
ERROR - 2024-09-06 22:56:07 --> 404 Page Not Found: _profiler/phpinfo
INFO - 2024-09-06 23:13:00 --> Config Class Initialized
INFO - 2024-09-06 23:13:00 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:13:00 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:13:00 --> Utf8 Class Initialized
INFO - 2024-09-06 23:13:00 --> URI Class Initialized
DEBUG - 2024-09-06 23:13:00 --> No URI present. Default controller set.
INFO - 2024-09-06 23:13:00 --> Router Class Initialized
INFO - 2024-09-06 23:13:00 --> Output Class Initialized
INFO - 2024-09-06 23:13:00 --> Security Class Initialized
DEBUG - 2024-09-06 23:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:13:00 --> Input Class Initialized
INFO - 2024-09-06 23:13:00 --> Language Class Initialized
INFO - 2024-09-06 23:13:00 --> Loader Class Initialized
INFO - 2024-09-06 23:13:00 --> Helper loaded: url_helper
INFO - 2024-09-06 23:13:00 --> Helper loaded: file_helper
INFO - 2024-09-06 23:13:00 --> Helper loaded: security_helper
INFO - 2024-09-06 23:13:00 --> Helper loaded: wpu_helper
INFO - 2024-09-06 23:13:00 --> Database Driver Class Initialized
INFO - 2024-09-06 23:13:00 --> Email Class Initialized
DEBUG - 2024-09-06 23:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:13:00 --> Helper loaded: form_helper
INFO - 2024-09-06 23:13:00 --> Form Validation Class Initialized
INFO - 2024-09-06 23:13:00 --> Controller Class Initialized
DEBUG - 2024-09-06 23:13:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 23:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 23:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 23:13:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 23:13:00 --> Final output sent to browser
DEBUG - 2024-09-06 23:13:00 --> Total execution time: 0.2161
INFO - 2024-09-06 23:18:10 --> Config Class Initialized
INFO - 2024-09-06 23:18:10 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:18:10 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:18:10 --> Utf8 Class Initialized
INFO - 2024-09-06 23:18:10 --> URI Class Initialized
DEBUG - 2024-09-06 23:18:10 --> No URI present. Default controller set.
INFO - 2024-09-06 23:18:10 --> Router Class Initialized
INFO - 2024-09-06 23:18:10 --> Output Class Initialized
INFO - 2024-09-06 23:18:10 --> Security Class Initialized
DEBUG - 2024-09-06 23:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:18:10 --> Input Class Initialized
INFO - 2024-09-06 23:18:10 --> Language Class Initialized
INFO - 2024-09-06 23:18:10 --> Loader Class Initialized
INFO - 2024-09-06 23:18:10 --> Helper loaded: url_helper
INFO - 2024-09-06 23:18:10 --> Helper loaded: file_helper
INFO - 2024-09-06 23:18:10 --> Helper loaded: security_helper
INFO - 2024-09-06 23:18:10 --> Helper loaded: wpu_helper
INFO - 2024-09-06 23:18:10 --> Database Driver Class Initialized
INFO - 2024-09-06 23:18:10 --> Email Class Initialized
DEBUG - 2024-09-06 23:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:18:10 --> Helper loaded: form_helper
INFO - 2024-09-06 23:18:10 --> Form Validation Class Initialized
INFO - 2024-09-06 23:18:10 --> Controller Class Initialized
DEBUG - 2024-09-06 23:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 23:18:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 23:18:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 23:18:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 23:18:10 --> Final output sent to browser
DEBUG - 2024-09-06 23:18:10 --> Total execution time: 0.2240
INFO - 2024-09-06 23:18:47 --> Config Class Initialized
INFO - 2024-09-06 23:18:47 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:18:47 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:18:47 --> Utf8 Class Initialized
INFO - 2024-09-06 23:18:47 --> URI Class Initialized
DEBUG - 2024-09-06 23:18:47 --> No URI present. Default controller set.
INFO - 2024-09-06 23:18:47 --> Router Class Initialized
INFO - 2024-09-06 23:18:47 --> Output Class Initialized
INFO - 2024-09-06 23:18:47 --> Security Class Initialized
DEBUG - 2024-09-06 23:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:18:47 --> Input Class Initialized
INFO - 2024-09-06 23:18:47 --> Language Class Initialized
INFO - 2024-09-06 23:18:47 --> Loader Class Initialized
INFO - 2024-09-06 23:18:47 --> Helper loaded: url_helper
INFO - 2024-09-06 23:18:47 --> Helper loaded: file_helper
INFO - 2024-09-06 23:18:47 --> Helper loaded: security_helper
INFO - 2024-09-06 23:18:47 --> Helper loaded: wpu_helper
INFO - 2024-09-06 23:18:47 --> Database Driver Class Initialized
INFO - 2024-09-06 23:18:48 --> Email Class Initialized
DEBUG - 2024-09-06 23:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:18:48 --> Helper loaded: form_helper
INFO - 2024-09-06 23:18:48 --> Form Validation Class Initialized
INFO - 2024-09-06 23:18:48 --> Controller Class Initialized
DEBUG - 2024-09-06 23:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 23:18:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 23:18:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 23:18:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 23:18:48 --> Final output sent to browser
DEBUG - 2024-09-06 23:18:48 --> Total execution time: 0.2097
INFO - 2024-09-06 23:21:29 --> Config Class Initialized
INFO - 2024-09-06 23:21:29 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:21:29 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:21:29 --> Utf8 Class Initialized
INFO - 2024-09-06 23:21:29 --> URI Class Initialized
DEBUG - 2024-09-06 23:21:29 --> No URI present. Default controller set.
INFO - 2024-09-06 23:21:29 --> Router Class Initialized
INFO - 2024-09-06 23:21:29 --> Output Class Initialized
INFO - 2024-09-06 23:21:29 --> Security Class Initialized
DEBUG - 2024-09-06 23:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:21:29 --> Input Class Initialized
INFO - 2024-09-06 23:21:29 --> Language Class Initialized
INFO - 2024-09-06 23:21:29 --> Loader Class Initialized
INFO - 2024-09-06 23:21:29 --> Helper loaded: url_helper
INFO - 2024-09-06 23:21:29 --> Helper loaded: file_helper
INFO - 2024-09-06 23:21:29 --> Helper loaded: security_helper
INFO - 2024-09-06 23:21:29 --> Helper loaded: wpu_helper
INFO - 2024-09-06 23:21:29 --> Database Driver Class Initialized
INFO - 2024-09-06 23:21:29 --> Email Class Initialized
DEBUG - 2024-09-06 23:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:21:29 --> Helper loaded: form_helper
INFO - 2024-09-06 23:21:29 --> Form Validation Class Initialized
INFO - 2024-09-06 23:21:29 --> Controller Class Initialized
DEBUG - 2024-09-06 23:21:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 23:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 23:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 23:21:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 23:21:29 --> Final output sent to browser
DEBUG - 2024-09-06 23:21:29 --> Total execution time: 0.2095
INFO - 2024-09-06 23:43:26 --> Config Class Initialized
INFO - 2024-09-06 23:43:26 --> Hooks Class Initialized
DEBUG - 2024-09-06 23:43:26 --> UTF-8 Support Enabled
INFO - 2024-09-06 23:43:26 --> Utf8 Class Initialized
INFO - 2024-09-06 23:43:26 --> URI Class Initialized
DEBUG - 2024-09-06 23:43:26 --> No URI present. Default controller set.
INFO - 2024-09-06 23:43:26 --> Router Class Initialized
INFO - 2024-09-06 23:43:26 --> Output Class Initialized
INFO - 2024-09-06 23:43:26 --> Security Class Initialized
DEBUG - 2024-09-06 23:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-06 23:43:26 --> Input Class Initialized
INFO - 2024-09-06 23:43:26 --> Language Class Initialized
INFO - 2024-09-06 23:43:26 --> Loader Class Initialized
INFO - 2024-09-06 23:43:26 --> Helper loaded: url_helper
INFO - 2024-09-06 23:43:26 --> Helper loaded: file_helper
INFO - 2024-09-06 23:43:26 --> Helper loaded: security_helper
INFO - 2024-09-06 23:43:26 --> Helper loaded: wpu_helper
INFO - 2024-09-06 23:43:26 --> Database Driver Class Initialized
INFO - 2024-09-06 23:43:26 --> Email Class Initialized
DEBUG - 2024-09-06 23:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-06 23:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-06 23:43:26 --> Helper loaded: form_helper
INFO - 2024-09-06 23:43:26 --> Form Validation Class Initialized
INFO - 2024-09-06 23:43:26 --> Controller Class Initialized
DEBUG - 2024-09-06 23:43:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-06 23:43:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-06 23:43:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-06 23:43:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-06 23:43:26 --> Final output sent to browser
DEBUG - 2024-09-06 23:43:26 --> Total execution time: 0.2283
