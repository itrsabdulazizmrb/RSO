<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-19 08:07:17 --> Config Class Initialized
INFO - 2024-11-19 08:07:17 --> Hooks Class Initialized
DEBUG - 2024-11-19 08:07:17 --> UTF-8 Support Enabled
INFO - 2024-11-19 08:07:17 --> Utf8 Class Initialized
INFO - 2024-11-19 08:07:17 --> URI Class Initialized
DEBUG - 2024-11-19 08:07:17 --> No URI present. Default controller set.
INFO - 2024-11-19 08:07:17 --> Router Class Initialized
INFO - 2024-11-19 08:07:17 --> Output Class Initialized
INFO - 2024-11-19 08:07:17 --> Security Class Initialized
DEBUG - 2024-11-19 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 08:07:17 --> Input Class Initialized
INFO - 2024-11-19 08:07:17 --> Language Class Initialized
INFO - 2024-11-19 08:07:17 --> Loader Class Initialized
INFO - 2024-11-19 08:07:17 --> Helper loaded: url_helper
INFO - 2024-11-19 08:07:17 --> Helper loaded: file_helper
INFO - 2024-11-19 08:07:17 --> Helper loaded: security_helper
INFO - 2024-11-19 08:07:17 --> Helper loaded: wpu_helper
INFO - 2024-11-19 08:07:17 --> Database Driver Class Initialized
INFO - 2024-11-19 08:07:17 --> Email Class Initialized
DEBUG - 2024-11-19 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-19 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 08:07:17 --> Helper loaded: form_helper
INFO - 2024-11-19 08:07:17 --> Form Validation Class Initialized
INFO - 2024-11-19 08:07:17 --> Controller Class Initialized
DEBUG - 2024-11-19 08:07:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-19 08:07:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-19 08:07:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-19 08:07:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-19 08:07:17 --> Final output sent to browser
DEBUG - 2024-11-19 08:07:17 --> Total execution time: 0.4149
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Caches/configs
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Htdocs/config.php.disabled
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Application/Common
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Resources/config.json
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Site/default
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envprod/index
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: App/etc
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envdevelopmentlocal/index
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Config/production.config.php
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Db/config.json.bak
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Database/config.php.orig
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Env_sample/index
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Webroot/config.php.old
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envbackup/index
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envwww/index
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: App/etc
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Textpattern/config.php.bkp
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envold/index
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: App/config
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Awsenv/index
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envproduction/index
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Includes/config.php.bak
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Old/config.php
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Common/config
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envexample/index
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Envproductionlocal/index
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: App/settings
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: App/config
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Installation/configuration.php.backup
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Tmp/config.php.bak
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Config/settings.inc.php.backup
INFO - 2024-11-19 12:44:13 --> Config Class Initialized
INFO - 2024-11-19 12:44:13 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:13 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:13 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:13 --> URI Class Initialized
INFO - 2024-11-19 12:44:13 --> Router Class Initialized
INFO - 2024-11-19 12:44:13 --> Output Class Initialized
INFO - 2024-11-19 12:44:13 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:13 --> Input Class Initialized
INFO - 2024-11-19 12:44:13 --> Language Class Initialized
ERROR - 2024-11-19 12:44:13 --> 404 Page Not Found: Backup/database.php.bak
INFO - 2024-11-19 12:44:14 --> Config Class Initialized
INFO - 2024-11-19 12:44:14 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:14 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:14 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:14 --> URI Class Initialized
INFO - 2024-11-19 12:44:14 --> Router Class Initialized
INFO - 2024-11-19 12:44:14 --> Output Class Initialized
INFO - 2024-11-19 12:44:14 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:14 --> Input Class Initialized
INFO - 2024-11-19 12:44:14 --> Language Class Initialized
ERROR - 2024-11-19 12:44:14 --> 404 Page Not Found: App/etc
INFO - 2024-11-19 12:44:14 --> Config Class Initialized
INFO - 2024-11-19 12:44:14 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:44:14 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:44:14 --> Utf8 Class Initialized
INFO - 2024-11-19 12:44:14 --> URI Class Initialized
INFO - 2024-11-19 12:44:14 --> Router Class Initialized
INFO - 2024-11-19 12:44:14 --> Output Class Initialized
INFO - 2024-11-19 12:44:14 --> Security Class Initialized
DEBUG - 2024-11-19 12:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:44:14 --> Input Class Initialized
INFO - 2024-11-19 12:44:14 --> Language Class Initialized
ERROR - 2024-11-19 12:44:14 --> 404 Page Not Found: Env_1/index
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Backup/database.php.bak
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Env_1/index
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Configphp~/index
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envexample/index
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Sendgridenv/index
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envdev/index
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Env_sample/index
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Backup/settings.php.bak
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envbackup/index
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envold/index
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envsave/index
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envbak/index
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Config/production.config.php
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Backup/db.php.bak
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Configphpbak/index
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Caches/configs
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Database/config.php.orig
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envlive/index
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envproduction/index
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envstage/index
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envprod/index
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envwww/index
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Common/config
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envdevlocal/index
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envdevelopmentlocal/index
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: App/etc
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: App/etc
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envproductionlocal/index
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Config Class Initialized
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Hooks Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: App/config
DEBUG - 2024-11-19 12:46:53 --> UTF-8 Support Enabled
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Utf8 Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> URI Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Router Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
INFO - 2024-11-19 12:46:53 --> Output Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Security Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envlocal/index
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
DEBUG - 2024-11-19 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 12:46:53 --> Input Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
INFO - 2024-11-19 12:46:53 --> Language Class Initialized
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: App/config
ERROR - 2024-11-19 12:46:53 --> 404 Page Not Found: Envprodlocal/index
INFO - 2024-11-19 13:29:02 --> Config Class Initialized
INFO - 2024-11-19 13:29:02 --> Hooks Class Initialized
DEBUG - 2024-11-19 13:29:02 --> UTF-8 Support Enabled
INFO - 2024-11-19 13:29:02 --> Utf8 Class Initialized
INFO - 2024-11-19 13:29:02 --> URI Class Initialized
DEBUG - 2024-11-19 13:29:02 --> No URI present. Default controller set.
INFO - 2024-11-19 13:29:02 --> Router Class Initialized
INFO - 2024-11-19 13:29:02 --> Output Class Initialized
INFO - 2024-11-19 13:29:02 --> Security Class Initialized
DEBUG - 2024-11-19 13:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 13:29:02 --> Input Class Initialized
INFO - 2024-11-19 13:29:02 --> Language Class Initialized
INFO - 2024-11-19 13:29:02 --> Loader Class Initialized
INFO - 2024-11-19 13:29:02 --> Helper loaded: url_helper
INFO - 2024-11-19 13:29:02 --> Helper loaded: file_helper
INFO - 2024-11-19 13:29:02 --> Helper loaded: security_helper
INFO - 2024-11-19 13:29:02 --> Helper loaded: wpu_helper
INFO - 2024-11-19 13:29:02 --> Database Driver Class Initialized
INFO - 2024-11-19 13:29:02 --> Email Class Initialized
DEBUG - 2024-11-19 13:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-19 13:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 13:29:02 --> Helper loaded: form_helper
INFO - 2024-11-19 13:29:02 --> Form Validation Class Initialized
INFO - 2024-11-19 13:29:02 --> Controller Class Initialized
DEBUG - 2024-11-19 13:29:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-19 13:29:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-19 13:29:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-19 13:29:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-19 13:29:02 --> Final output sent to browser
DEBUG - 2024-11-19 13:29:02 --> Total execution time: 0.4374
INFO - 2024-11-19 21:56:46 --> Config Class Initialized
INFO - 2024-11-19 21:56:46 --> Hooks Class Initialized
DEBUG - 2024-11-19 21:56:46 --> UTF-8 Support Enabled
INFO - 2024-11-19 21:56:46 --> Utf8 Class Initialized
INFO - 2024-11-19 21:56:46 --> URI Class Initialized
DEBUG - 2024-11-19 21:56:46 --> No URI present. Default controller set.
INFO - 2024-11-19 21:56:46 --> Router Class Initialized
INFO - 2024-11-19 21:56:46 --> Output Class Initialized
INFO - 2024-11-19 21:56:46 --> Security Class Initialized
DEBUG - 2024-11-19 21:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 21:56:46 --> Input Class Initialized
INFO - 2024-11-19 21:56:46 --> Language Class Initialized
INFO - 2024-11-19 21:56:46 --> Loader Class Initialized
INFO - 2024-11-19 21:56:46 --> Helper loaded: url_helper
INFO - 2024-11-19 21:56:46 --> Helper loaded: file_helper
INFO - 2024-11-19 21:56:46 --> Helper loaded: security_helper
INFO - 2024-11-19 21:56:46 --> Helper loaded: wpu_helper
INFO - 2024-11-19 21:56:46 --> Database Driver Class Initialized
INFO - 2024-11-19 21:56:47 --> Email Class Initialized
DEBUG - 2024-11-19 21:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-19 21:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 21:56:47 --> Helper loaded: form_helper
INFO - 2024-11-19 21:56:47 --> Form Validation Class Initialized
INFO - 2024-11-19 21:56:47 --> Controller Class Initialized
DEBUG - 2024-11-19 21:56:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-19 21:56:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-19 21:56:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-19 21:56:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-19 21:56:47 --> Final output sent to browser
DEBUG - 2024-11-19 21:56:47 --> Total execution time: 0.4262
INFO - 2024-11-19 21:56:49 --> Config Class Initialized
INFO - 2024-11-19 21:56:49 --> Hooks Class Initialized
DEBUG - 2024-11-19 21:56:49 --> UTF-8 Support Enabled
INFO - 2024-11-19 21:56:49 --> Utf8 Class Initialized
INFO - 2024-11-19 21:56:49 --> URI Class Initialized
INFO - 2024-11-19 21:56:49 --> Router Class Initialized
INFO - 2024-11-19 21:56:49 --> Output Class Initialized
INFO - 2024-11-19 21:56:49 --> Security Class Initialized
DEBUG - 2024-11-19 21:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 21:56:49 --> Input Class Initialized
INFO - 2024-11-19 21:56:49 --> Language Class Initialized
INFO - 2024-11-19 21:56:49 --> Loader Class Initialized
INFO - 2024-11-19 21:56:49 --> Helper loaded: url_helper
INFO - 2024-11-19 21:56:49 --> Helper loaded: file_helper
INFO - 2024-11-19 21:56:49 --> Helper loaded: security_helper
INFO - 2024-11-19 21:56:49 --> Helper loaded: wpu_helper
INFO - 2024-11-19 21:56:49 --> Database Driver Class Initialized
INFO - 2024-11-19 21:56:49 --> Email Class Initialized
DEBUG - 2024-11-19 21:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-19 21:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 21:56:49 --> Helper loaded: form_helper
INFO - 2024-11-19 21:56:49 --> Form Validation Class Initialized
INFO - 2024-11-19 21:56:49 --> Controller Class Initialized
DEBUG - 2024-11-19 21:56:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-19 21:56:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-19 21:56:50 --> Config Class Initialized
INFO - 2024-11-19 21:56:50 --> Hooks Class Initialized
DEBUG - 2024-11-19 21:56:50 --> UTF-8 Support Enabled
INFO - 2024-11-19 21:56:50 --> Utf8 Class Initialized
INFO - 2024-11-19 21:56:50 --> URI Class Initialized
INFO - 2024-11-19 21:56:50 --> Router Class Initialized
INFO - 2024-11-19 21:56:50 --> Output Class Initialized
INFO - 2024-11-19 21:56:50 --> Security Class Initialized
DEBUG - 2024-11-19 21:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 21:56:50 --> Input Class Initialized
INFO - 2024-11-19 21:56:50 --> Language Class Initialized
INFO - 2024-11-19 21:56:50 --> Loader Class Initialized
INFO - 2024-11-19 21:56:50 --> Helper loaded: url_helper
INFO - 2024-11-19 21:56:50 --> Helper loaded: file_helper
INFO - 2024-11-19 21:56:50 --> Helper loaded: security_helper
INFO - 2024-11-19 21:56:50 --> Helper loaded: wpu_helper
INFO - 2024-11-19 21:56:50 --> Database Driver Class Initialized
INFO - 2024-11-19 21:56:50 --> Email Class Initialized
DEBUG - 2024-11-19 21:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-19 21:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 21:56:50 --> Helper loaded: form_helper
INFO - 2024-11-19 21:56:50 --> Form Validation Class Initialized
INFO - 2024-11-19 21:56:50 --> Controller Class Initialized
INFO - 2024-11-19 21:56:50 --> Model "Antrol_model" initialized
DEBUG - 2024-11-19 21:56:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-19 21:56:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-19 21:56:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-19 21:56:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-19 21:56:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-19 21:56:51 --> Final output sent to browser
DEBUG - 2024-11-19 21:56:51 --> Total execution time: 1.0921
