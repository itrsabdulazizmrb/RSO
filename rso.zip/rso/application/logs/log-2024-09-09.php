<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-09 00:12:53 --> Config Class Initialized
INFO - 2024-09-09 00:12:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 00:12:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 00:12:53 --> Utf8 Class Initialized
INFO - 2024-09-09 00:12:53 --> URI Class Initialized
DEBUG - 2024-09-09 00:12:53 --> No URI present. Default controller set.
INFO - 2024-09-09 00:12:53 --> Router Class Initialized
INFO - 2024-09-09 00:12:53 --> Output Class Initialized
INFO - 2024-09-09 00:12:53 --> Security Class Initialized
DEBUG - 2024-09-09 00:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 00:12:53 --> Input Class Initialized
INFO - 2024-09-09 00:12:53 --> Language Class Initialized
INFO - 2024-09-09 00:12:53 --> Loader Class Initialized
INFO - 2024-09-09 00:12:53 --> Helper loaded: url_helper
INFO - 2024-09-09 00:12:53 --> Helper loaded: file_helper
INFO - 2024-09-09 00:12:53 --> Helper loaded: security_helper
INFO - 2024-09-09 00:12:53 --> Helper loaded: wpu_helper
INFO - 2024-09-09 00:12:53 --> Database Driver Class Initialized
INFO - 2024-09-09 00:12:54 --> Email Class Initialized
DEBUG - 2024-09-09 00:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 00:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 00:12:54 --> Helper loaded: form_helper
INFO - 2024-09-09 00:12:54 --> Form Validation Class Initialized
INFO - 2024-09-09 00:12:54 --> Controller Class Initialized
DEBUG - 2024-09-09 00:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 00:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 00:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 00:12:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 00:12:54 --> Final output sent to browser
DEBUG - 2024-09-09 00:12:54 --> Total execution time: 0.2290
INFO - 2024-09-09 00:43:34 --> Config Class Initialized
INFO - 2024-09-09 00:43:34 --> Hooks Class Initialized
DEBUG - 2024-09-09 00:43:34 --> UTF-8 Support Enabled
INFO - 2024-09-09 00:43:34 --> Utf8 Class Initialized
INFO - 2024-09-09 00:43:34 --> URI Class Initialized
DEBUG - 2024-09-09 00:43:34 --> No URI present. Default controller set.
INFO - 2024-09-09 00:43:34 --> Router Class Initialized
INFO - 2024-09-09 00:43:34 --> Output Class Initialized
INFO - 2024-09-09 00:43:34 --> Security Class Initialized
DEBUG - 2024-09-09 00:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 00:43:34 --> Input Class Initialized
INFO - 2024-09-09 00:43:34 --> Language Class Initialized
INFO - 2024-09-09 00:43:34 --> Loader Class Initialized
INFO - 2024-09-09 00:43:34 --> Helper loaded: url_helper
INFO - 2024-09-09 00:43:34 --> Helper loaded: file_helper
INFO - 2024-09-09 00:43:34 --> Helper loaded: security_helper
INFO - 2024-09-09 00:43:34 --> Helper loaded: wpu_helper
INFO - 2024-09-09 00:43:34 --> Database Driver Class Initialized
INFO - 2024-09-09 00:43:35 --> Email Class Initialized
DEBUG - 2024-09-09 00:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 00:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 00:43:35 --> Helper loaded: form_helper
INFO - 2024-09-09 00:43:35 --> Form Validation Class Initialized
INFO - 2024-09-09 00:43:35 --> Controller Class Initialized
DEBUG - 2024-09-09 00:43:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 00:43:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 00:43:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 00:43:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 00:43:35 --> Final output sent to browser
DEBUG - 2024-09-09 00:43:35 --> Total execution time: 0.2175
INFO - 2024-09-09 01:17:39 --> Config Class Initialized
INFO - 2024-09-09 01:17:39 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:17:39 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:17:39 --> Utf8 Class Initialized
INFO - 2024-09-09 01:17:39 --> URI Class Initialized
DEBUG - 2024-09-09 01:17:39 --> No URI present. Default controller set.
INFO - 2024-09-09 01:17:39 --> Router Class Initialized
INFO - 2024-09-09 01:17:39 --> Output Class Initialized
INFO - 2024-09-09 01:17:39 --> Security Class Initialized
DEBUG - 2024-09-09 01:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:17:39 --> Input Class Initialized
INFO - 2024-09-09 01:17:39 --> Language Class Initialized
INFO - 2024-09-09 01:17:39 --> Loader Class Initialized
INFO - 2024-09-09 01:17:39 --> Helper loaded: url_helper
INFO - 2024-09-09 01:17:39 --> Helper loaded: file_helper
INFO - 2024-09-09 01:17:39 --> Helper loaded: security_helper
INFO - 2024-09-09 01:17:39 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:17:39 --> Database Driver Class Initialized
INFO - 2024-09-09 01:17:39 --> Email Class Initialized
DEBUG - 2024-09-09 01:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:17:39 --> Helper loaded: form_helper
INFO - 2024-09-09 01:17:39 --> Form Validation Class Initialized
INFO - 2024-09-09 01:17:39 --> Controller Class Initialized
DEBUG - 2024-09-09 01:17:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:17:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 01:17:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 01:17:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 01:17:39 --> Final output sent to browser
DEBUG - 2024-09-09 01:17:39 --> Total execution time: 0.2329
INFO - 2024-09-09 01:43:36 --> Config Class Initialized
INFO - 2024-09-09 01:43:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:43:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:43:36 --> Utf8 Class Initialized
INFO - 2024-09-09 01:43:36 --> URI Class Initialized
DEBUG - 2024-09-09 01:43:36 --> No URI present. Default controller set.
INFO - 2024-09-09 01:43:36 --> Router Class Initialized
INFO - 2024-09-09 01:43:36 --> Output Class Initialized
INFO - 2024-09-09 01:43:36 --> Security Class Initialized
DEBUG - 2024-09-09 01:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:43:36 --> Input Class Initialized
INFO - 2024-09-09 01:43:36 --> Language Class Initialized
INFO - 2024-09-09 01:43:36 --> Loader Class Initialized
INFO - 2024-09-09 01:43:36 --> Helper loaded: url_helper
INFO - 2024-09-09 01:43:36 --> Helper loaded: file_helper
INFO - 2024-09-09 01:43:36 --> Helper loaded: security_helper
INFO - 2024-09-09 01:43:36 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:43:36 --> Database Driver Class Initialized
INFO - 2024-09-09 01:43:36 --> Email Class Initialized
DEBUG - 2024-09-09 01:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:43:36 --> Helper loaded: form_helper
INFO - 2024-09-09 01:43:36 --> Form Validation Class Initialized
INFO - 2024-09-09 01:43:36 --> Controller Class Initialized
DEBUG - 2024-09-09 01:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:43:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 01:43:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 01:43:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 01:43:36 --> Final output sent to browser
DEBUG - 2024-09-09 01:43:36 --> Total execution time: 0.2359
INFO - 2024-09-09 01:58:51 --> Config Class Initialized
INFO - 2024-09-09 01:58:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:58:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:58:51 --> Utf8 Class Initialized
INFO - 2024-09-09 01:58:51 --> URI Class Initialized
DEBUG - 2024-09-09 01:58:51 --> No URI present. Default controller set.
INFO - 2024-09-09 01:58:51 --> Router Class Initialized
INFO - 2024-09-09 01:58:51 --> Output Class Initialized
INFO - 2024-09-09 01:58:51 --> Security Class Initialized
DEBUG - 2024-09-09 01:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:58:51 --> Input Class Initialized
INFO - 2024-09-09 01:58:51 --> Language Class Initialized
INFO - 2024-09-09 01:58:51 --> Loader Class Initialized
INFO - 2024-09-09 01:58:51 --> Helper loaded: url_helper
INFO - 2024-09-09 01:58:51 --> Helper loaded: file_helper
INFO - 2024-09-09 01:58:51 --> Helper loaded: security_helper
INFO - 2024-09-09 01:58:51 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:58:51 --> Database Driver Class Initialized
INFO - 2024-09-09 01:58:51 --> Email Class Initialized
DEBUG - 2024-09-09 01:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:58:51 --> Helper loaded: form_helper
INFO - 2024-09-09 01:58:51 --> Form Validation Class Initialized
INFO - 2024-09-09 01:58:51 --> Controller Class Initialized
DEBUG - 2024-09-09 01:58:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:58:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 01:58:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 01:58:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 01:58:51 --> Final output sent to browser
DEBUG - 2024-09-09 01:58:51 --> Total execution time: 0.2255
INFO - 2024-09-09 01:58:58 --> Config Class Initialized
INFO - 2024-09-09 01:58:58 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:58:58 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:58:58 --> Utf8 Class Initialized
INFO - 2024-09-09 01:58:58 --> URI Class Initialized
INFO - 2024-09-09 01:58:58 --> Router Class Initialized
INFO - 2024-09-09 01:58:58 --> Output Class Initialized
INFO - 2024-09-09 01:58:58 --> Security Class Initialized
DEBUG - 2024-09-09 01:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:58:58 --> Input Class Initialized
INFO - 2024-09-09 01:58:58 --> Language Class Initialized
INFO - 2024-09-09 01:58:58 --> Loader Class Initialized
INFO - 2024-09-09 01:58:58 --> Helper loaded: url_helper
INFO - 2024-09-09 01:58:58 --> Helper loaded: file_helper
INFO - 2024-09-09 01:58:58 --> Helper loaded: security_helper
INFO - 2024-09-09 01:58:58 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:58:58 --> Database Driver Class Initialized
INFO - 2024-09-09 01:58:58 --> Email Class Initialized
DEBUG - 2024-09-09 01:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:58:58 --> Helper loaded: form_helper
INFO - 2024-09-09 01:58:58 --> Form Validation Class Initialized
INFO - 2024-09-09 01:58:58 --> Controller Class Initialized
DEBUG - 2024-09-09 01:58:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:58:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 01:58:59 --> Config Class Initialized
INFO - 2024-09-09 01:58:59 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:58:59 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:58:59 --> Utf8 Class Initialized
INFO - 2024-09-09 01:58:59 --> URI Class Initialized
INFO - 2024-09-09 01:58:59 --> Router Class Initialized
INFO - 2024-09-09 01:58:59 --> Output Class Initialized
INFO - 2024-09-09 01:58:59 --> Security Class Initialized
DEBUG - 2024-09-09 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:58:59 --> Input Class Initialized
INFO - 2024-09-09 01:58:59 --> Language Class Initialized
INFO - 2024-09-09 01:58:59 --> Loader Class Initialized
INFO - 2024-09-09 01:58:59 --> Helper loaded: url_helper
INFO - 2024-09-09 01:58:59 --> Helper loaded: file_helper
INFO - 2024-09-09 01:58:59 --> Helper loaded: security_helper
INFO - 2024-09-09 01:58:59 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:58:59 --> Database Driver Class Initialized
INFO - 2024-09-09 01:58:59 --> Email Class Initialized
DEBUG - 2024-09-09 01:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:58:59 --> Helper loaded: form_helper
INFO - 2024-09-09 01:58:59 --> Form Validation Class Initialized
INFO - 2024-09-09 01:58:59 --> Controller Class Initialized
INFO - 2024-09-09 01:58:59 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 01:58:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:58:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 01:58:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 01:58:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-09 01:58:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 01:58:59 --> Final output sent to browser
DEBUG - 2024-09-09 01:58:59 --> Total execution time: 0.5764
INFO - 2024-09-09 01:59:03 --> Config Class Initialized
INFO - 2024-09-09 01:59:03 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:59:03 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:59:03 --> Utf8 Class Initialized
INFO - 2024-09-09 01:59:03 --> URI Class Initialized
INFO - 2024-09-09 01:59:03 --> Router Class Initialized
INFO - 2024-09-09 01:59:03 --> Output Class Initialized
INFO - 2024-09-09 01:59:03 --> Security Class Initialized
DEBUG - 2024-09-09 01:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:59:03 --> Input Class Initialized
INFO - 2024-09-09 01:59:03 --> Language Class Initialized
INFO - 2024-09-09 01:59:03 --> Loader Class Initialized
INFO - 2024-09-09 01:59:03 --> Helper loaded: url_helper
INFO - 2024-09-09 01:59:03 --> Helper loaded: file_helper
INFO - 2024-09-09 01:59:03 --> Helper loaded: security_helper
INFO - 2024-09-09 01:59:03 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:59:03 --> Database Driver Class Initialized
INFO - 2024-09-09 01:59:03 --> Email Class Initialized
DEBUG - 2024-09-09 01:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:59:03 --> Helper loaded: form_helper
INFO - 2024-09-09 01:59:03 --> Form Validation Class Initialized
INFO - 2024-09-09 01:59:03 --> Controller Class Initialized
INFO - 2024-09-09 01:59:03 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 01:59:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:59:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 01:59:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 01:59:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-09 01:59:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 01:59:04 --> Final output sent to browser
DEBUG - 2024-09-09 01:59:04 --> Total execution time: 0.7621
INFO - 2024-09-09 01:59:07 --> Config Class Initialized
INFO - 2024-09-09 01:59:07 --> Hooks Class Initialized
DEBUG - 2024-09-09 01:59:07 --> UTF-8 Support Enabled
INFO - 2024-09-09 01:59:07 --> Utf8 Class Initialized
INFO - 2024-09-09 01:59:07 --> URI Class Initialized
INFO - 2024-09-09 01:59:07 --> Router Class Initialized
INFO - 2024-09-09 01:59:07 --> Output Class Initialized
INFO - 2024-09-09 01:59:07 --> Security Class Initialized
DEBUG - 2024-09-09 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 01:59:07 --> Input Class Initialized
INFO - 2024-09-09 01:59:07 --> Language Class Initialized
INFO - 2024-09-09 01:59:07 --> Loader Class Initialized
INFO - 2024-09-09 01:59:07 --> Helper loaded: url_helper
INFO - 2024-09-09 01:59:07 --> Helper loaded: file_helper
INFO - 2024-09-09 01:59:07 --> Helper loaded: security_helper
INFO - 2024-09-09 01:59:07 --> Helper loaded: wpu_helper
INFO - 2024-09-09 01:59:07 --> Database Driver Class Initialized
INFO - 2024-09-09 01:59:07 --> Email Class Initialized
DEBUG - 2024-09-09 01:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 01:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 01:59:07 --> Helper loaded: form_helper
INFO - 2024-09-09 01:59:07 --> Form Validation Class Initialized
INFO - 2024-09-09 01:59:07 --> Controller Class Initialized
INFO - 2024-09-09 01:59:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 01:59:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 01:59:08 --> Final output sent to browser
DEBUG - 2024-09-09 01:59:08 --> Total execution time: 1.2401
INFO - 2024-09-09 02:22:31 --> Config Class Initialized
INFO - 2024-09-09 02:22:31 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:22:31 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:22:31 --> Utf8 Class Initialized
INFO - 2024-09-09 02:22:31 --> URI Class Initialized
DEBUG - 2024-09-09 02:22:31 --> No URI present. Default controller set.
INFO - 2024-09-09 02:22:31 --> Router Class Initialized
INFO - 2024-09-09 02:22:31 --> Output Class Initialized
INFO - 2024-09-09 02:22:31 --> Security Class Initialized
DEBUG - 2024-09-09 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:22:31 --> Input Class Initialized
INFO - 2024-09-09 02:22:31 --> Language Class Initialized
INFO - 2024-09-09 02:22:31 --> Loader Class Initialized
INFO - 2024-09-09 02:22:31 --> Helper loaded: url_helper
INFO - 2024-09-09 02:22:31 --> Helper loaded: file_helper
INFO - 2024-09-09 02:22:31 --> Helper loaded: security_helper
INFO - 2024-09-09 02:22:31 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:22:31 --> Database Driver Class Initialized
INFO - 2024-09-09 02:22:31 --> Email Class Initialized
DEBUG - 2024-09-09 02:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:22:31 --> Helper loaded: form_helper
INFO - 2024-09-09 02:22:31 --> Form Validation Class Initialized
INFO - 2024-09-09 02:22:31 --> Controller Class Initialized
DEBUG - 2024-09-09 02:22:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:22:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:22:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:22:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:22:31 --> Final output sent to browser
DEBUG - 2024-09-09 02:22:31 --> Total execution time: 0.2653
INFO - 2024-09-09 02:32:44 --> Config Class Initialized
INFO - 2024-09-09 02:32:44 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:32:44 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:32:44 --> Utf8 Class Initialized
INFO - 2024-09-09 02:32:44 --> URI Class Initialized
DEBUG - 2024-09-09 02:32:44 --> No URI present. Default controller set.
INFO - 2024-09-09 02:32:44 --> Router Class Initialized
INFO - 2024-09-09 02:32:44 --> Output Class Initialized
INFO - 2024-09-09 02:32:44 --> Security Class Initialized
DEBUG - 2024-09-09 02:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:32:44 --> Input Class Initialized
INFO - 2024-09-09 02:32:44 --> Language Class Initialized
INFO - 2024-09-09 02:32:44 --> Loader Class Initialized
INFO - 2024-09-09 02:32:44 --> Helper loaded: url_helper
INFO - 2024-09-09 02:32:44 --> Helper loaded: file_helper
INFO - 2024-09-09 02:32:44 --> Helper loaded: security_helper
INFO - 2024-09-09 02:32:44 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:32:44 --> Database Driver Class Initialized
INFO - 2024-09-09 02:32:44 --> Email Class Initialized
DEBUG - 2024-09-09 02:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:32:44 --> Helper loaded: form_helper
INFO - 2024-09-09 02:32:44 --> Form Validation Class Initialized
INFO - 2024-09-09 02:32:44 --> Controller Class Initialized
DEBUG - 2024-09-09 02:32:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:32:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:32:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:32:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:32:44 --> Final output sent to browser
DEBUG - 2024-09-09 02:32:44 --> Total execution time: 0.2696
INFO - 2024-09-09 02:42:00 --> Config Class Initialized
INFO - 2024-09-09 02:42:00 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:00 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:00 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:00 --> URI Class Initialized
INFO - 2024-09-09 02:42:00 --> Router Class Initialized
INFO - 2024-09-09 02:42:00 --> Output Class Initialized
INFO - 2024-09-09 02:42:00 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:00 --> Input Class Initialized
INFO - 2024-09-09 02:42:00 --> Language Class Initialized
INFO - 2024-09-09 02:42:00 --> Loader Class Initialized
INFO - 2024-09-09 02:42:00 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:00 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:00 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:00 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:00 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:01 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:01 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:01 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:01 --> Controller Class Initialized
INFO - 2024-09-09 02:42:01 --> Config Class Initialized
INFO - 2024-09-09 02:42:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:01 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:01 --> URI Class Initialized
INFO - 2024-09-09 02:42:01 --> Router Class Initialized
INFO - 2024-09-09 02:42:01 --> Output Class Initialized
INFO - 2024-09-09 02:42:01 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:01 --> Input Class Initialized
INFO - 2024-09-09 02:42:01 --> Language Class Initialized
INFO - 2024-09-09 02:42:01 --> Loader Class Initialized
INFO - 2024-09-09 02:42:01 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:01 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:01 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:01 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:01 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:01 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:01 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:01 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:01 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:42:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:42:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:42:01 --> Final output sent to browser
DEBUG - 2024-09-09 02:42:01 --> Total execution time: 0.2677
INFO - 2024-09-09 02:42:05 --> Config Class Initialized
INFO - 2024-09-09 02:42:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:05 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:05 --> URI Class Initialized
INFO - 2024-09-09 02:42:05 --> Router Class Initialized
INFO - 2024-09-09 02:42:05 --> Output Class Initialized
INFO - 2024-09-09 02:42:05 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:05 --> Input Class Initialized
INFO - 2024-09-09 02:42:05 --> Language Class Initialized
INFO - 2024-09-09 02:42:05 --> Loader Class Initialized
INFO - 2024-09-09 02:42:05 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:05 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:05 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:05 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:05 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:05 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 02:42:05 --> Config Class Initialized
INFO - 2024-09-09 02:42:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:05 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:05 --> URI Class Initialized
INFO - 2024-09-09 02:42:05 --> Router Class Initialized
INFO - 2024-09-09 02:42:05 --> Output Class Initialized
INFO - 2024-09-09 02:42:05 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:05 --> Input Class Initialized
INFO - 2024-09-09 02:42:05 --> Language Class Initialized
INFO - 2024-09-09 02:42:05 --> Loader Class Initialized
INFO - 2024-09-09 02:42:05 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:05 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:05 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:06 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:06 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:06 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:06 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:42:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:42:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:42:06 --> Final output sent to browser
DEBUG - 2024-09-09 02:42:06 --> Total execution time: 0.2706
INFO - 2024-09-09 02:42:08 --> Config Class Initialized
INFO - 2024-09-09 02:42:08 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:08 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:08 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:08 --> URI Class Initialized
INFO - 2024-09-09 02:42:08 --> Router Class Initialized
INFO - 2024-09-09 02:42:08 --> Output Class Initialized
INFO - 2024-09-09 02:42:08 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:08 --> Input Class Initialized
INFO - 2024-09-09 02:42:08 --> Language Class Initialized
INFO - 2024-09-09 02:42:08 --> Loader Class Initialized
INFO - 2024-09-09 02:42:08 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:08 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:08 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:08 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:08 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:08 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:08 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:08 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:08 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 02:42:09 --> Config Class Initialized
INFO - 2024-09-09 02:42:09 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:09 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:09 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:09 --> URI Class Initialized
INFO - 2024-09-09 02:42:09 --> Router Class Initialized
INFO - 2024-09-09 02:42:09 --> Output Class Initialized
INFO - 2024-09-09 02:42:09 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:09 --> Input Class Initialized
INFO - 2024-09-09 02:42:09 --> Language Class Initialized
INFO - 2024-09-09 02:42:09 --> Loader Class Initialized
INFO - 2024-09-09 02:42:09 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:09 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:09 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:09 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:09 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:09 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:09 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:09 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:09 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:42:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:42:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:42:09 --> Final output sent to browser
DEBUG - 2024-09-09 02:42:09 --> Total execution time: 0.2764
INFO - 2024-09-09 02:42:11 --> Config Class Initialized
INFO - 2024-09-09 02:42:11 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:11 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:11 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:11 --> URI Class Initialized
INFO - 2024-09-09 02:42:11 --> Router Class Initialized
INFO - 2024-09-09 02:42:11 --> Output Class Initialized
INFO - 2024-09-09 02:42:11 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:11 --> Input Class Initialized
INFO - 2024-09-09 02:42:11 --> Language Class Initialized
INFO - 2024-09-09 02:42:11 --> Loader Class Initialized
INFO - 2024-09-09 02:42:11 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:11 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:11 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:11 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:11 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:12 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:12 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:12 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:12 --> Controller Class Initialized
DEBUG - 2024-09-09 02:42:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 02:42:13 --> Config Class Initialized
INFO - 2024-09-09 02:42:13 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:42:13 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:42:13 --> Utf8 Class Initialized
INFO - 2024-09-09 02:42:13 --> URI Class Initialized
INFO - 2024-09-09 02:42:13 --> Router Class Initialized
INFO - 2024-09-09 02:42:13 --> Output Class Initialized
INFO - 2024-09-09 02:42:13 --> Security Class Initialized
DEBUG - 2024-09-09 02:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:42:13 --> Input Class Initialized
INFO - 2024-09-09 02:42:13 --> Language Class Initialized
INFO - 2024-09-09 02:42:13 --> Loader Class Initialized
INFO - 2024-09-09 02:42:13 --> Helper loaded: url_helper
INFO - 2024-09-09 02:42:13 --> Helper loaded: file_helper
INFO - 2024-09-09 02:42:13 --> Helper loaded: security_helper
INFO - 2024-09-09 02:42:13 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:42:13 --> Database Driver Class Initialized
INFO - 2024-09-09 02:42:13 --> Email Class Initialized
DEBUG - 2024-09-09 02:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:42:13 --> Helper loaded: form_helper
INFO - 2024-09-09 02:42:13 --> Form Validation Class Initialized
INFO - 2024-09-09 02:42:13 --> Controller Class Initialized
INFO - 2024-09-09 02:42:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 02:42:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 02:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 02:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-09 02:42:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 02:42:13 --> Final output sent to browser
DEBUG - 2024-09-09 02:42:13 --> Total execution time: 0.7137
INFO - 2024-09-09 02:45:53 --> Config Class Initialized
INFO - 2024-09-09 02:45:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:45:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:45:53 --> Utf8 Class Initialized
INFO - 2024-09-09 02:45:53 --> URI Class Initialized
DEBUG - 2024-09-09 02:45:53 --> No URI present. Default controller set.
INFO - 2024-09-09 02:45:53 --> Router Class Initialized
INFO - 2024-09-09 02:45:53 --> Output Class Initialized
INFO - 2024-09-09 02:45:53 --> Security Class Initialized
DEBUG - 2024-09-09 02:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:45:53 --> Input Class Initialized
INFO - 2024-09-09 02:45:53 --> Language Class Initialized
INFO - 2024-09-09 02:45:53 --> Loader Class Initialized
INFO - 2024-09-09 02:45:53 --> Helper loaded: url_helper
INFO - 2024-09-09 02:45:53 --> Helper loaded: file_helper
INFO - 2024-09-09 02:45:53 --> Helper loaded: security_helper
INFO - 2024-09-09 02:45:53 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:45:53 --> Database Driver Class Initialized
INFO - 2024-09-09 02:45:54 --> Email Class Initialized
DEBUG - 2024-09-09 02:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:45:54 --> Helper loaded: form_helper
INFO - 2024-09-09 02:45:54 --> Form Validation Class Initialized
INFO - 2024-09-09 02:45:54 --> Controller Class Initialized
DEBUG - 2024-09-09 02:45:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:45:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 02:45:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 02:45:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 02:45:54 --> Final output sent to browser
DEBUG - 2024-09-09 02:45:54 --> Total execution time: 0.2833
INFO - 2024-09-09 02:46:34 --> Config Class Initialized
INFO - 2024-09-09 02:46:34 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:46:34 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:46:34 --> Utf8 Class Initialized
INFO - 2024-09-09 02:46:34 --> URI Class Initialized
INFO - 2024-09-09 02:46:34 --> Router Class Initialized
INFO - 2024-09-09 02:46:34 --> Output Class Initialized
INFO - 2024-09-09 02:46:34 --> Security Class Initialized
DEBUG - 2024-09-09 02:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:46:34 --> Input Class Initialized
INFO - 2024-09-09 02:46:34 --> Language Class Initialized
INFO - 2024-09-09 02:46:34 --> Loader Class Initialized
INFO - 2024-09-09 02:46:34 --> Helper loaded: url_helper
INFO - 2024-09-09 02:46:34 --> Helper loaded: file_helper
INFO - 2024-09-09 02:46:34 --> Helper loaded: security_helper
INFO - 2024-09-09 02:46:34 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:46:34 --> Database Driver Class Initialized
INFO - 2024-09-09 02:46:34 --> Email Class Initialized
DEBUG - 2024-09-09 02:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:46:34 --> Helper loaded: form_helper
INFO - 2024-09-09 02:46:34 --> Form Validation Class Initialized
INFO - 2024-09-09 02:46:34 --> Controller Class Initialized
INFO - 2024-09-09 02:46:34 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 02:46:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:46:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 02:46:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 02:46:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-09 02:46:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 02:46:35 --> Final output sent to browser
DEBUG - 2024-09-09 02:46:35 --> Total execution time: 0.8320
INFO - 2024-09-09 02:46:37 --> Config Class Initialized
INFO - 2024-09-09 02:46:37 --> Hooks Class Initialized
DEBUG - 2024-09-09 02:46:37 --> UTF-8 Support Enabled
INFO - 2024-09-09 02:46:37 --> Utf8 Class Initialized
INFO - 2024-09-09 02:46:37 --> URI Class Initialized
INFO - 2024-09-09 02:46:37 --> Router Class Initialized
INFO - 2024-09-09 02:46:37 --> Output Class Initialized
INFO - 2024-09-09 02:46:37 --> Security Class Initialized
DEBUG - 2024-09-09 02:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 02:46:37 --> Input Class Initialized
INFO - 2024-09-09 02:46:37 --> Language Class Initialized
INFO - 2024-09-09 02:46:37 --> Loader Class Initialized
INFO - 2024-09-09 02:46:37 --> Helper loaded: url_helper
INFO - 2024-09-09 02:46:37 --> Helper loaded: file_helper
INFO - 2024-09-09 02:46:37 --> Helper loaded: security_helper
INFO - 2024-09-09 02:46:37 --> Helper loaded: wpu_helper
INFO - 2024-09-09 02:46:37 --> Database Driver Class Initialized
INFO - 2024-09-09 02:46:38 --> Email Class Initialized
DEBUG - 2024-09-09 02:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 02:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 02:46:38 --> Helper loaded: form_helper
INFO - 2024-09-09 02:46:38 --> Form Validation Class Initialized
INFO - 2024-09-09 02:46:38 --> Controller Class Initialized
INFO - 2024-09-09 02:46:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 02:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 02:46:39 --> Final output sent to browser
DEBUG - 2024-09-09 02:46:39 --> Total execution time: 1.5752
INFO - 2024-09-09 03:15:12 --> Config Class Initialized
INFO - 2024-09-09 03:15:12 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:15:12 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:15:12 --> Utf8 Class Initialized
INFO - 2024-09-09 03:15:12 --> URI Class Initialized
DEBUG - 2024-09-09 03:15:12 --> No URI present. Default controller set.
INFO - 2024-09-09 03:15:12 --> Router Class Initialized
INFO - 2024-09-09 03:15:12 --> Output Class Initialized
INFO - 2024-09-09 03:15:12 --> Security Class Initialized
DEBUG - 2024-09-09 03:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:15:12 --> Input Class Initialized
INFO - 2024-09-09 03:15:12 --> Language Class Initialized
INFO - 2024-09-09 03:15:12 --> Loader Class Initialized
INFO - 2024-09-09 03:15:12 --> Helper loaded: url_helper
INFO - 2024-09-09 03:15:12 --> Helper loaded: file_helper
INFO - 2024-09-09 03:15:12 --> Helper loaded: security_helper
INFO - 2024-09-09 03:15:12 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:15:12 --> Database Driver Class Initialized
INFO - 2024-09-09 03:15:12 --> Email Class Initialized
DEBUG - 2024-09-09 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:15:12 --> Helper loaded: form_helper
INFO - 2024-09-09 03:15:12 --> Form Validation Class Initialized
INFO - 2024-09-09 03:15:12 --> Controller Class Initialized
DEBUG - 2024-09-09 03:15:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:15:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:15:12 --> Final output sent to browser
DEBUG - 2024-09-09 03:15:12 --> Total execution time: 0.2450
INFO - 2024-09-09 03:15:28 --> Config Class Initialized
INFO - 2024-09-09 03:15:28 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:15:28 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:15:28 --> Utf8 Class Initialized
INFO - 2024-09-09 03:15:28 --> URI Class Initialized
INFO - 2024-09-09 03:15:28 --> Router Class Initialized
INFO - 2024-09-09 03:15:28 --> Output Class Initialized
INFO - 2024-09-09 03:15:28 --> Security Class Initialized
DEBUG - 2024-09-09 03:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:15:28 --> Input Class Initialized
INFO - 2024-09-09 03:15:28 --> Language Class Initialized
ERROR - 2024-09-09 03:15:28 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-09-09 03:21:22 --> Config Class Initialized
INFO - 2024-09-09 03:21:22 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:21:22 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:21:22 --> Utf8 Class Initialized
INFO - 2024-09-09 03:21:22 --> URI Class Initialized
DEBUG - 2024-09-09 03:21:22 --> No URI present. Default controller set.
INFO - 2024-09-09 03:21:22 --> Router Class Initialized
INFO - 2024-09-09 03:21:22 --> Output Class Initialized
INFO - 2024-09-09 03:21:22 --> Security Class Initialized
DEBUG - 2024-09-09 03:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:21:22 --> Input Class Initialized
INFO - 2024-09-09 03:21:22 --> Language Class Initialized
INFO - 2024-09-09 03:21:22 --> Loader Class Initialized
INFO - 2024-09-09 03:21:22 --> Helper loaded: url_helper
INFO - 2024-09-09 03:21:22 --> Helper loaded: file_helper
INFO - 2024-09-09 03:21:22 --> Helper loaded: security_helper
INFO - 2024-09-09 03:21:22 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:21:22 --> Database Driver Class Initialized
INFO - 2024-09-09 03:21:22 --> Email Class Initialized
DEBUG - 2024-09-09 03:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:21:22 --> Helper loaded: form_helper
INFO - 2024-09-09 03:21:22 --> Form Validation Class Initialized
INFO - 2024-09-09 03:21:22 --> Controller Class Initialized
DEBUG - 2024-09-09 03:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:21:22 --> Final output sent to browser
DEBUG - 2024-09-09 03:21:22 --> Total execution time: 0.2402
INFO - 2024-09-09 03:44:05 --> Config Class Initialized
INFO - 2024-09-09 03:44:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:05 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:05 --> URI Class Initialized
DEBUG - 2024-09-09 03:44:05 --> No URI present. Default controller set.
INFO - 2024-09-09 03:44:05 --> Router Class Initialized
INFO - 2024-09-09 03:44:05 --> Output Class Initialized
INFO - 2024-09-09 03:44:05 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:05 --> Input Class Initialized
INFO - 2024-09-09 03:44:05 --> Language Class Initialized
INFO - 2024-09-09 03:44:05 --> Loader Class Initialized
INFO - 2024-09-09 03:44:05 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:05 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:05 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:05 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:05 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:05 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:05 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:05 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:05 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:44:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:44:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:44:05 --> Final output sent to browser
DEBUG - 2024-09-09 03:44:05 --> Total execution time: 0.2483
INFO - 2024-09-09 03:44:14 --> Config Class Initialized
INFO - 2024-09-09 03:44:14 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:14 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:14 --> URI Class Initialized
INFO - 2024-09-09 03:44:14 --> Router Class Initialized
INFO - 2024-09-09 03:44:14 --> Output Class Initialized
INFO - 2024-09-09 03:44:14 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:14 --> Input Class Initialized
INFO - 2024-09-09 03:44:14 --> Language Class Initialized
INFO - 2024-09-09 03:44:14 --> Loader Class Initialized
INFO - 2024-09-09 03:44:14 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:14 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:14 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:14 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:14 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:14 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:14 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:14 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:14 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 03:44:15 --> Config Class Initialized
INFO - 2024-09-09 03:44:15 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:15 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:15 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:15 --> URI Class Initialized
INFO - 2024-09-09 03:44:15 --> Router Class Initialized
INFO - 2024-09-09 03:44:15 --> Output Class Initialized
INFO - 2024-09-09 03:44:15 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:15 --> Input Class Initialized
INFO - 2024-09-09 03:44:15 --> Language Class Initialized
INFO - 2024-09-09 03:44:15 --> Loader Class Initialized
INFO - 2024-09-09 03:44:15 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:15 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:15 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:15 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:15 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:15 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:15 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:15 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:15 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:44:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:44:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:44:15 --> Final output sent to browser
DEBUG - 2024-09-09 03:44:15 --> Total execution time: 0.2401
INFO - 2024-09-09 03:44:21 --> Config Class Initialized
INFO - 2024-09-09 03:44:21 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:21 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:21 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:21 --> URI Class Initialized
INFO - 2024-09-09 03:44:21 --> Router Class Initialized
INFO - 2024-09-09 03:44:21 --> Output Class Initialized
INFO - 2024-09-09 03:44:21 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:21 --> Input Class Initialized
INFO - 2024-09-09 03:44:21 --> Language Class Initialized
INFO - 2024-09-09 03:44:21 --> Loader Class Initialized
INFO - 2024-09-09 03:44:21 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:21 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:21 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:21 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:21 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:22 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:22 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:22 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:22 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 03:44:22 --> Config Class Initialized
INFO - 2024-09-09 03:44:22 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:22 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:22 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:22 --> URI Class Initialized
INFO - 2024-09-09 03:44:22 --> Router Class Initialized
INFO - 2024-09-09 03:44:22 --> Output Class Initialized
INFO - 2024-09-09 03:44:22 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:22 --> Input Class Initialized
INFO - 2024-09-09 03:44:22 --> Language Class Initialized
INFO - 2024-09-09 03:44:23 --> Loader Class Initialized
INFO - 2024-09-09 03:44:23 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:23 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:23 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:23 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:23 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:23 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:23 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:23 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:23 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:44:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:44:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:44:23 --> Final output sent to browser
DEBUG - 2024-09-09 03:44:23 --> Total execution time: 0.2262
INFO - 2024-09-09 03:44:34 --> Config Class Initialized
INFO - 2024-09-09 03:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:34 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:34 --> URI Class Initialized
INFO - 2024-09-09 03:44:34 --> Router Class Initialized
INFO - 2024-09-09 03:44:34 --> Output Class Initialized
INFO - 2024-09-09 03:44:34 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:34 --> Input Class Initialized
INFO - 2024-09-09 03:44:34 --> Language Class Initialized
INFO - 2024-09-09 03:44:34 --> Loader Class Initialized
INFO - 2024-09-09 03:44:34 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:34 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:34 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:34 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:34 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:34 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:34 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:34 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:34 --> Controller Class Initialized
DEBUG - 2024-09-09 03:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-09 03:44:36 --> Config Class Initialized
INFO - 2024-09-09 03:44:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:36 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:36 --> URI Class Initialized
INFO - 2024-09-09 03:44:36 --> Router Class Initialized
INFO - 2024-09-09 03:44:36 --> Output Class Initialized
INFO - 2024-09-09 03:44:36 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:36 --> Input Class Initialized
INFO - 2024-09-09 03:44:36 --> Language Class Initialized
INFO - 2024-09-09 03:44:36 --> Loader Class Initialized
INFO - 2024-09-09 03:44:36 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:36 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:36 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:36 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:36 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:36 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:36 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:36 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:36 --> Controller Class Initialized
INFO - 2024-09-09 03:44:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 03:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 03:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 03:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-09 03:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 03:44:36 --> Final output sent to browser
DEBUG - 2024-09-09 03:44:36 --> Total execution time: 0.6271
INFO - 2024-09-09 03:44:48 --> Config Class Initialized
INFO - 2024-09-09 03:44:48 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:44:48 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:44:48 --> Utf8 Class Initialized
INFO - 2024-09-09 03:44:48 --> URI Class Initialized
INFO - 2024-09-09 03:44:48 --> Router Class Initialized
INFO - 2024-09-09 03:44:48 --> Output Class Initialized
INFO - 2024-09-09 03:44:48 --> Security Class Initialized
DEBUG - 2024-09-09 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:44:48 --> Input Class Initialized
INFO - 2024-09-09 03:44:48 --> Language Class Initialized
INFO - 2024-09-09 03:44:48 --> Loader Class Initialized
INFO - 2024-09-09 03:44:48 --> Helper loaded: url_helper
INFO - 2024-09-09 03:44:48 --> Helper loaded: file_helper
INFO - 2024-09-09 03:44:48 --> Helper loaded: security_helper
INFO - 2024-09-09 03:44:48 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:44:48 --> Database Driver Class Initialized
INFO - 2024-09-09 03:44:48 --> Email Class Initialized
DEBUG - 2024-09-09 03:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:44:48 --> Helper loaded: form_helper
INFO - 2024-09-09 03:44:48 --> Form Validation Class Initialized
INFO - 2024-09-09 03:44:48 --> Controller Class Initialized
INFO - 2024-09-09 03:44:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-09 03:44:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:44:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-09 03:44:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-09 03:44:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-09 03:44:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-09 03:44:49 --> Final output sent to browser
DEBUG - 2024-09-09 03:44:49 --> Total execution time: 0.7562
INFO - 2024-09-09 03:51:15 --> Config Class Initialized
INFO - 2024-09-09 03:51:15 --> Hooks Class Initialized
DEBUG - 2024-09-09 03:51:15 --> UTF-8 Support Enabled
INFO - 2024-09-09 03:51:15 --> Utf8 Class Initialized
INFO - 2024-09-09 03:51:15 --> URI Class Initialized
DEBUG - 2024-09-09 03:51:15 --> No URI present. Default controller set.
INFO - 2024-09-09 03:51:15 --> Router Class Initialized
INFO - 2024-09-09 03:51:15 --> Output Class Initialized
INFO - 2024-09-09 03:51:15 --> Security Class Initialized
DEBUG - 2024-09-09 03:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 03:51:15 --> Input Class Initialized
INFO - 2024-09-09 03:51:15 --> Language Class Initialized
INFO - 2024-09-09 03:51:15 --> Loader Class Initialized
INFO - 2024-09-09 03:51:15 --> Helper loaded: url_helper
INFO - 2024-09-09 03:51:15 --> Helper loaded: file_helper
INFO - 2024-09-09 03:51:15 --> Helper loaded: security_helper
INFO - 2024-09-09 03:51:15 --> Helper loaded: wpu_helper
INFO - 2024-09-09 03:51:15 --> Database Driver Class Initialized
INFO - 2024-09-09 03:51:16 --> Email Class Initialized
DEBUG - 2024-09-09 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 03:51:16 --> Helper loaded: form_helper
INFO - 2024-09-09 03:51:16 --> Form Validation Class Initialized
INFO - 2024-09-09 03:51:16 --> Controller Class Initialized
DEBUG - 2024-09-09 03:51:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 03:51:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 03:51:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 03:51:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 03:51:16 --> Final output sent to browser
DEBUG - 2024-09-09 03:51:16 --> Total execution time: 0.2315
INFO - 2024-09-09 04:15:28 --> Config Class Initialized
INFO - 2024-09-09 04:15:28 --> Hooks Class Initialized
DEBUG - 2024-09-09 04:15:28 --> UTF-8 Support Enabled
INFO - 2024-09-09 04:15:28 --> Utf8 Class Initialized
INFO - 2024-09-09 04:15:28 --> URI Class Initialized
DEBUG - 2024-09-09 04:15:28 --> No URI present. Default controller set.
INFO - 2024-09-09 04:15:28 --> Router Class Initialized
INFO - 2024-09-09 04:15:28 --> Output Class Initialized
INFO - 2024-09-09 04:15:28 --> Security Class Initialized
DEBUG - 2024-09-09 04:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 04:15:28 --> Input Class Initialized
INFO - 2024-09-09 04:15:28 --> Language Class Initialized
INFO - 2024-09-09 04:15:28 --> Loader Class Initialized
INFO - 2024-09-09 04:15:28 --> Helper loaded: url_helper
INFO - 2024-09-09 04:15:28 --> Helper loaded: file_helper
INFO - 2024-09-09 04:15:28 --> Helper loaded: security_helper
INFO - 2024-09-09 04:15:28 --> Helper loaded: wpu_helper
INFO - 2024-09-09 04:15:28 --> Database Driver Class Initialized
INFO - 2024-09-09 04:15:28 --> Email Class Initialized
DEBUG - 2024-09-09 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 04:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 04:15:28 --> Helper loaded: form_helper
INFO - 2024-09-09 04:15:28 --> Form Validation Class Initialized
INFO - 2024-09-09 04:15:28 --> Controller Class Initialized
DEBUG - 2024-09-09 04:15:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 04:15:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 04:15:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 04:15:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 04:15:28 --> Final output sent to browser
DEBUG - 2024-09-09 04:15:28 --> Total execution time: 0.2681
INFO - 2024-09-09 04:50:25 --> Config Class Initialized
INFO - 2024-09-09 04:50:25 --> Hooks Class Initialized
DEBUG - 2024-09-09 04:50:25 --> UTF-8 Support Enabled
INFO - 2024-09-09 04:50:25 --> Utf8 Class Initialized
INFO - 2024-09-09 04:50:25 --> URI Class Initialized
DEBUG - 2024-09-09 04:50:25 --> No URI present. Default controller set.
INFO - 2024-09-09 04:50:25 --> Router Class Initialized
INFO - 2024-09-09 04:50:25 --> Output Class Initialized
INFO - 2024-09-09 04:50:25 --> Security Class Initialized
DEBUG - 2024-09-09 04:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 04:50:25 --> Input Class Initialized
INFO - 2024-09-09 04:50:25 --> Language Class Initialized
INFO - 2024-09-09 04:50:25 --> Loader Class Initialized
INFO - 2024-09-09 04:50:25 --> Helper loaded: url_helper
INFO - 2024-09-09 04:50:25 --> Helper loaded: file_helper
INFO - 2024-09-09 04:50:25 --> Helper loaded: security_helper
INFO - 2024-09-09 04:50:25 --> Helper loaded: wpu_helper
INFO - 2024-09-09 04:50:25 --> Database Driver Class Initialized
INFO - 2024-09-09 04:50:25 --> Email Class Initialized
DEBUG - 2024-09-09 04:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 04:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 04:50:25 --> Helper loaded: form_helper
INFO - 2024-09-09 04:50:25 --> Form Validation Class Initialized
INFO - 2024-09-09 04:50:25 --> Controller Class Initialized
DEBUG - 2024-09-09 04:50:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 04:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 04:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 04:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 04:50:25 --> Final output sent to browser
DEBUG - 2024-09-09 04:50:25 --> Total execution time: 0.2476
INFO - 2024-09-09 05:17:18 --> Config Class Initialized
INFO - 2024-09-09 05:17:18 --> Hooks Class Initialized
DEBUG - 2024-09-09 05:17:18 --> UTF-8 Support Enabled
INFO - 2024-09-09 05:17:18 --> Utf8 Class Initialized
INFO - 2024-09-09 05:17:18 --> URI Class Initialized
DEBUG - 2024-09-09 05:17:18 --> No URI present. Default controller set.
INFO - 2024-09-09 05:17:18 --> Router Class Initialized
INFO - 2024-09-09 05:17:18 --> Output Class Initialized
INFO - 2024-09-09 05:17:18 --> Security Class Initialized
DEBUG - 2024-09-09 05:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 05:17:18 --> Input Class Initialized
INFO - 2024-09-09 05:17:18 --> Language Class Initialized
INFO - 2024-09-09 05:17:18 --> Loader Class Initialized
INFO - 2024-09-09 05:17:18 --> Helper loaded: url_helper
INFO - 2024-09-09 05:17:18 --> Helper loaded: file_helper
INFO - 2024-09-09 05:17:18 --> Helper loaded: security_helper
INFO - 2024-09-09 05:17:18 --> Helper loaded: wpu_helper
INFO - 2024-09-09 05:17:18 --> Database Driver Class Initialized
INFO - 2024-09-09 05:17:18 --> Email Class Initialized
DEBUG - 2024-09-09 05:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 05:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 05:17:18 --> Helper loaded: form_helper
INFO - 2024-09-09 05:17:18 --> Form Validation Class Initialized
INFO - 2024-09-09 05:17:18 --> Controller Class Initialized
DEBUG - 2024-09-09 05:17:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 05:17:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 05:17:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 05:17:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 05:17:18 --> Final output sent to browser
DEBUG - 2024-09-09 05:17:18 --> Total execution time: 0.2258
INFO - 2024-09-09 05:27:01 --> Config Class Initialized
INFO - 2024-09-09 05:27:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 05:27:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 05:27:01 --> Utf8 Class Initialized
INFO - 2024-09-09 05:27:01 --> URI Class Initialized
DEBUG - 2024-09-09 05:27:01 --> No URI present. Default controller set.
INFO - 2024-09-09 05:27:01 --> Router Class Initialized
INFO - 2024-09-09 05:27:01 --> Output Class Initialized
INFO - 2024-09-09 05:27:01 --> Security Class Initialized
DEBUG - 2024-09-09 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 05:27:01 --> Input Class Initialized
INFO - 2024-09-09 05:27:01 --> Language Class Initialized
INFO - 2024-09-09 05:27:01 --> Loader Class Initialized
INFO - 2024-09-09 05:27:01 --> Helper loaded: url_helper
INFO - 2024-09-09 05:27:01 --> Helper loaded: file_helper
INFO - 2024-09-09 05:27:01 --> Helper loaded: security_helper
INFO - 2024-09-09 05:27:01 --> Helper loaded: wpu_helper
INFO - 2024-09-09 05:27:01 --> Database Driver Class Initialized
INFO - 2024-09-09 05:27:01 --> Email Class Initialized
DEBUG - 2024-09-09 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 05:27:01 --> Helper loaded: form_helper
INFO - 2024-09-09 05:27:01 --> Form Validation Class Initialized
INFO - 2024-09-09 05:27:01 --> Controller Class Initialized
DEBUG - 2024-09-09 05:27:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 05:27:01 --> Final output sent to browser
DEBUG - 2024-09-09 05:27:01 --> Total execution time: 0.2176
INFO - 2024-09-09 05:47:17 --> Config Class Initialized
INFO - 2024-09-09 05:47:17 --> Hooks Class Initialized
DEBUG - 2024-09-09 05:47:17 --> UTF-8 Support Enabled
INFO - 2024-09-09 05:47:17 --> Utf8 Class Initialized
INFO - 2024-09-09 05:47:17 --> URI Class Initialized
DEBUG - 2024-09-09 05:47:17 --> No URI present. Default controller set.
INFO - 2024-09-09 05:47:17 --> Router Class Initialized
INFO - 2024-09-09 05:47:17 --> Output Class Initialized
INFO - 2024-09-09 05:47:17 --> Security Class Initialized
DEBUG - 2024-09-09 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 05:47:17 --> Input Class Initialized
INFO - 2024-09-09 05:47:17 --> Language Class Initialized
INFO - 2024-09-09 05:47:17 --> Loader Class Initialized
INFO - 2024-09-09 05:47:17 --> Helper loaded: url_helper
INFO - 2024-09-09 05:47:17 --> Helper loaded: file_helper
INFO - 2024-09-09 05:47:17 --> Helper loaded: security_helper
INFO - 2024-09-09 05:47:17 --> Helper loaded: wpu_helper
INFO - 2024-09-09 05:47:17 --> Database Driver Class Initialized
INFO - 2024-09-09 05:47:17 --> Email Class Initialized
DEBUG - 2024-09-09 05:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 05:47:17 --> Helper loaded: form_helper
INFO - 2024-09-09 05:47:17 --> Form Validation Class Initialized
INFO - 2024-09-09 05:47:17 --> Controller Class Initialized
DEBUG - 2024-09-09 05:47:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 05:47:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 05:47:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 05:47:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 05:47:17 --> Final output sent to browser
DEBUG - 2024-09-09 05:47:17 --> Total execution time: 0.2320
INFO - 2024-09-09 06:15:42 --> Config Class Initialized
INFO - 2024-09-09 06:15:42 --> Hooks Class Initialized
DEBUG - 2024-09-09 06:15:42 --> UTF-8 Support Enabled
INFO - 2024-09-09 06:15:42 --> Utf8 Class Initialized
INFO - 2024-09-09 06:15:42 --> URI Class Initialized
DEBUG - 2024-09-09 06:15:42 --> No URI present. Default controller set.
INFO - 2024-09-09 06:15:42 --> Router Class Initialized
INFO - 2024-09-09 06:15:42 --> Output Class Initialized
INFO - 2024-09-09 06:15:42 --> Security Class Initialized
DEBUG - 2024-09-09 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 06:15:42 --> Input Class Initialized
INFO - 2024-09-09 06:15:42 --> Language Class Initialized
INFO - 2024-09-09 06:15:42 --> Loader Class Initialized
INFO - 2024-09-09 06:15:42 --> Helper loaded: url_helper
INFO - 2024-09-09 06:15:42 --> Helper loaded: file_helper
INFO - 2024-09-09 06:15:42 --> Helper loaded: security_helper
INFO - 2024-09-09 06:15:42 --> Helper loaded: wpu_helper
INFO - 2024-09-09 06:15:42 --> Database Driver Class Initialized
INFO - 2024-09-09 06:15:42 --> Email Class Initialized
DEBUG - 2024-09-09 06:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 06:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 06:15:42 --> Helper loaded: form_helper
INFO - 2024-09-09 06:15:42 --> Form Validation Class Initialized
INFO - 2024-09-09 06:15:42 --> Controller Class Initialized
DEBUG - 2024-09-09 06:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 06:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 06:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 06:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 06:15:42 --> Final output sent to browser
DEBUG - 2024-09-09 06:15:42 --> Total execution time: 0.2209
INFO - 2024-09-09 06:44:34 --> Config Class Initialized
INFO - 2024-09-09 06:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-09 06:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-09 06:44:34 --> Utf8 Class Initialized
INFO - 2024-09-09 06:44:34 --> URI Class Initialized
DEBUG - 2024-09-09 06:44:34 --> No URI present. Default controller set.
INFO - 2024-09-09 06:44:34 --> Router Class Initialized
INFO - 2024-09-09 06:44:34 --> Output Class Initialized
INFO - 2024-09-09 06:44:34 --> Security Class Initialized
DEBUG - 2024-09-09 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 06:44:34 --> Input Class Initialized
INFO - 2024-09-09 06:44:34 --> Language Class Initialized
INFO - 2024-09-09 06:44:34 --> Loader Class Initialized
INFO - 2024-09-09 06:44:34 --> Helper loaded: url_helper
INFO - 2024-09-09 06:44:34 --> Helper loaded: file_helper
INFO - 2024-09-09 06:44:34 --> Helper loaded: security_helper
INFO - 2024-09-09 06:44:34 --> Helper loaded: wpu_helper
INFO - 2024-09-09 06:44:34 --> Database Driver Class Initialized
INFO - 2024-09-09 06:44:34 --> Email Class Initialized
DEBUG - 2024-09-09 06:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 06:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 06:44:34 --> Helper loaded: form_helper
INFO - 2024-09-09 06:44:34 --> Form Validation Class Initialized
INFO - 2024-09-09 06:44:34 --> Controller Class Initialized
DEBUG - 2024-09-09 06:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 06:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 06:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 06:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 06:44:34 --> Final output sent to browser
DEBUG - 2024-09-09 06:44:34 --> Total execution time: 0.2323
INFO - 2024-09-09 07:15:29 --> Config Class Initialized
INFO - 2024-09-09 07:15:29 --> Hooks Class Initialized
DEBUG - 2024-09-09 07:15:29 --> UTF-8 Support Enabled
INFO - 2024-09-09 07:15:29 --> Utf8 Class Initialized
INFO - 2024-09-09 07:15:29 --> URI Class Initialized
DEBUG - 2024-09-09 07:15:29 --> No URI present. Default controller set.
INFO - 2024-09-09 07:15:29 --> Router Class Initialized
INFO - 2024-09-09 07:15:29 --> Output Class Initialized
INFO - 2024-09-09 07:15:29 --> Security Class Initialized
DEBUG - 2024-09-09 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 07:15:29 --> Input Class Initialized
INFO - 2024-09-09 07:15:29 --> Language Class Initialized
INFO - 2024-09-09 07:15:29 --> Loader Class Initialized
INFO - 2024-09-09 07:15:29 --> Helper loaded: url_helper
INFO - 2024-09-09 07:15:29 --> Helper loaded: file_helper
INFO - 2024-09-09 07:15:29 --> Helper loaded: security_helper
INFO - 2024-09-09 07:15:29 --> Helper loaded: wpu_helper
INFO - 2024-09-09 07:15:29 --> Database Driver Class Initialized
INFO - 2024-09-09 07:15:29 --> Email Class Initialized
DEBUG - 2024-09-09 07:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 07:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 07:15:29 --> Helper loaded: form_helper
INFO - 2024-09-09 07:15:29 --> Form Validation Class Initialized
INFO - 2024-09-09 07:15:29 --> Controller Class Initialized
DEBUG - 2024-09-09 07:15:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 07:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 07:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 07:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 07:15:29 --> Final output sent to browser
DEBUG - 2024-09-09 07:15:29 --> Total execution time: 0.2612
INFO - 2024-09-09 07:45:59 --> Config Class Initialized
INFO - 2024-09-09 07:45:59 --> Hooks Class Initialized
DEBUG - 2024-09-09 07:45:59 --> UTF-8 Support Enabled
INFO - 2024-09-09 07:45:59 --> Utf8 Class Initialized
INFO - 2024-09-09 07:45:59 --> URI Class Initialized
DEBUG - 2024-09-09 07:45:59 --> No URI present. Default controller set.
INFO - 2024-09-09 07:45:59 --> Router Class Initialized
INFO - 2024-09-09 07:45:59 --> Output Class Initialized
INFO - 2024-09-09 07:45:59 --> Security Class Initialized
DEBUG - 2024-09-09 07:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 07:45:59 --> Input Class Initialized
INFO - 2024-09-09 07:45:59 --> Language Class Initialized
INFO - 2024-09-09 07:45:59 --> Loader Class Initialized
INFO - 2024-09-09 07:45:59 --> Helper loaded: url_helper
INFO - 2024-09-09 07:45:59 --> Helper loaded: file_helper
INFO - 2024-09-09 07:45:59 --> Helper loaded: security_helper
INFO - 2024-09-09 07:45:59 --> Helper loaded: wpu_helper
INFO - 2024-09-09 07:45:59 --> Database Driver Class Initialized
INFO - 2024-09-09 07:45:59 --> Email Class Initialized
DEBUG - 2024-09-09 07:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 07:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 07:45:59 --> Helper loaded: form_helper
INFO - 2024-09-09 07:45:59 --> Form Validation Class Initialized
INFO - 2024-09-09 07:45:59 --> Controller Class Initialized
DEBUG - 2024-09-09 07:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 07:45:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 07:45:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 07:45:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 07:45:59 --> Final output sent to browser
DEBUG - 2024-09-09 07:45:59 --> Total execution time: 0.2235
INFO - 2024-09-09 07:54:35 --> Config Class Initialized
INFO - 2024-09-09 07:54:35 --> Hooks Class Initialized
DEBUG - 2024-09-09 07:54:35 --> UTF-8 Support Enabled
INFO - 2024-09-09 07:54:35 --> Utf8 Class Initialized
INFO - 2024-09-09 07:54:35 --> URI Class Initialized
DEBUG - 2024-09-09 07:54:35 --> No URI present. Default controller set.
INFO - 2024-09-09 07:54:35 --> Router Class Initialized
INFO - 2024-09-09 07:54:35 --> Output Class Initialized
INFO - 2024-09-09 07:54:35 --> Security Class Initialized
DEBUG - 2024-09-09 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 07:54:35 --> Input Class Initialized
INFO - 2024-09-09 07:54:35 --> Language Class Initialized
INFO - 2024-09-09 07:54:35 --> Loader Class Initialized
INFO - 2024-09-09 07:54:35 --> Helper loaded: url_helper
INFO - 2024-09-09 07:54:35 --> Helper loaded: file_helper
INFO - 2024-09-09 07:54:35 --> Helper loaded: security_helper
INFO - 2024-09-09 07:54:35 --> Helper loaded: wpu_helper
INFO - 2024-09-09 07:54:35 --> Database Driver Class Initialized
INFO - 2024-09-09 07:54:35 --> Email Class Initialized
DEBUG - 2024-09-09 07:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 07:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 07:54:35 --> Helper loaded: form_helper
INFO - 2024-09-09 07:54:35 --> Form Validation Class Initialized
INFO - 2024-09-09 07:54:35 --> Controller Class Initialized
DEBUG - 2024-09-09 07:54:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 07:54:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 07:54:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 07:54:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 07:54:35 --> Final output sent to browser
DEBUG - 2024-09-09 07:54:35 --> Total execution time: 0.5242
INFO - 2024-09-09 07:54:51 --> Config Class Initialized
INFO - 2024-09-09 07:54:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 07:54:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 07:54:51 --> Utf8 Class Initialized
INFO - 2024-09-09 07:54:51 --> URI Class Initialized
INFO - 2024-09-09 07:54:51 --> Router Class Initialized
INFO - 2024-09-09 07:54:51 --> Output Class Initialized
INFO - 2024-09-09 07:54:51 --> Security Class Initialized
DEBUG - 2024-09-09 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 07:54:51 --> Input Class Initialized
INFO - 2024-09-09 07:54:51 --> Language Class Initialized
ERROR - 2024-09-09 07:54:51 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-09-09 08:14:21 --> Config Class Initialized
INFO - 2024-09-09 08:14:21 --> Hooks Class Initialized
DEBUG - 2024-09-09 08:14:21 --> UTF-8 Support Enabled
INFO - 2024-09-09 08:14:21 --> Utf8 Class Initialized
INFO - 2024-09-09 08:14:21 --> URI Class Initialized
DEBUG - 2024-09-09 08:14:21 --> No URI present. Default controller set.
INFO - 2024-09-09 08:14:21 --> Router Class Initialized
INFO - 2024-09-09 08:14:21 --> Output Class Initialized
INFO - 2024-09-09 08:14:21 --> Security Class Initialized
DEBUG - 2024-09-09 08:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 08:14:21 --> Input Class Initialized
INFO - 2024-09-09 08:14:21 --> Language Class Initialized
INFO - 2024-09-09 08:14:21 --> Loader Class Initialized
INFO - 2024-09-09 08:14:21 --> Helper loaded: url_helper
INFO - 2024-09-09 08:14:21 --> Helper loaded: file_helper
INFO - 2024-09-09 08:14:21 --> Helper loaded: security_helper
INFO - 2024-09-09 08:14:21 --> Helper loaded: wpu_helper
INFO - 2024-09-09 08:14:21 --> Database Driver Class Initialized
INFO - 2024-09-09 08:14:21 --> Email Class Initialized
DEBUG - 2024-09-09 08:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 08:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 08:14:21 --> Helper loaded: form_helper
INFO - 2024-09-09 08:14:21 --> Form Validation Class Initialized
INFO - 2024-09-09 08:14:21 --> Controller Class Initialized
DEBUG - 2024-09-09 08:14:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 08:14:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 08:14:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 08:14:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 08:14:21 --> Final output sent to browser
DEBUG - 2024-09-09 08:14:21 --> Total execution time: 0.2381
INFO - 2024-09-09 08:27:26 --> Config Class Initialized
INFO - 2024-09-09 08:27:26 --> Hooks Class Initialized
DEBUG - 2024-09-09 08:27:26 --> UTF-8 Support Enabled
INFO - 2024-09-09 08:27:26 --> Utf8 Class Initialized
INFO - 2024-09-09 08:27:26 --> URI Class Initialized
DEBUG - 2024-09-09 08:27:26 --> No URI present. Default controller set.
INFO - 2024-09-09 08:27:26 --> Router Class Initialized
INFO - 2024-09-09 08:27:26 --> Output Class Initialized
INFO - 2024-09-09 08:27:26 --> Security Class Initialized
DEBUG - 2024-09-09 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 08:27:26 --> Input Class Initialized
INFO - 2024-09-09 08:27:26 --> Language Class Initialized
INFO - 2024-09-09 08:27:26 --> Loader Class Initialized
INFO - 2024-09-09 08:27:26 --> Helper loaded: url_helper
INFO - 2024-09-09 08:27:26 --> Helper loaded: file_helper
INFO - 2024-09-09 08:27:26 --> Helper loaded: security_helper
INFO - 2024-09-09 08:27:26 --> Helper loaded: wpu_helper
INFO - 2024-09-09 08:27:26 --> Database Driver Class Initialized
INFO - 2024-09-09 08:27:26 --> Email Class Initialized
DEBUG - 2024-09-09 08:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 08:27:26 --> Helper loaded: form_helper
INFO - 2024-09-09 08:27:26 --> Form Validation Class Initialized
INFO - 2024-09-09 08:27:26 --> Controller Class Initialized
DEBUG - 2024-09-09 08:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 08:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 08:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 08:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 08:27:26 --> Final output sent to browser
DEBUG - 2024-09-09 08:27:26 --> Total execution time: 0.2234
INFO - 2024-09-09 08:44:51 --> Config Class Initialized
INFO - 2024-09-09 08:44:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 08:44:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 08:44:51 --> Utf8 Class Initialized
INFO - 2024-09-09 08:44:51 --> URI Class Initialized
DEBUG - 2024-09-09 08:44:51 --> No URI present. Default controller set.
INFO - 2024-09-09 08:44:51 --> Router Class Initialized
INFO - 2024-09-09 08:44:51 --> Output Class Initialized
INFO - 2024-09-09 08:44:51 --> Security Class Initialized
DEBUG - 2024-09-09 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 08:44:51 --> Input Class Initialized
INFO - 2024-09-09 08:44:51 --> Language Class Initialized
INFO - 2024-09-09 08:44:51 --> Loader Class Initialized
INFO - 2024-09-09 08:44:51 --> Helper loaded: url_helper
INFO - 2024-09-09 08:44:51 --> Helper loaded: file_helper
INFO - 2024-09-09 08:44:51 --> Helper loaded: security_helper
INFO - 2024-09-09 08:44:51 --> Helper loaded: wpu_helper
INFO - 2024-09-09 08:44:51 --> Database Driver Class Initialized
INFO - 2024-09-09 08:44:51 --> Email Class Initialized
DEBUG - 2024-09-09 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 08:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 08:44:51 --> Helper loaded: form_helper
INFO - 2024-09-09 08:44:51 --> Form Validation Class Initialized
INFO - 2024-09-09 08:44:51 --> Controller Class Initialized
DEBUG - 2024-09-09 08:44:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 08:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 08:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 08:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 08:44:51 --> Final output sent to browser
DEBUG - 2024-09-09 08:44:51 --> Total execution time: 0.2455
INFO - 2024-09-09 09:15:49 --> Config Class Initialized
INFO - 2024-09-09 09:15:49 --> Hooks Class Initialized
DEBUG - 2024-09-09 09:15:49 --> UTF-8 Support Enabled
INFO - 2024-09-09 09:15:49 --> Utf8 Class Initialized
INFO - 2024-09-09 09:15:49 --> URI Class Initialized
DEBUG - 2024-09-09 09:15:49 --> No URI present. Default controller set.
INFO - 2024-09-09 09:15:49 --> Router Class Initialized
INFO - 2024-09-09 09:15:49 --> Output Class Initialized
INFO - 2024-09-09 09:15:49 --> Security Class Initialized
DEBUG - 2024-09-09 09:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 09:15:49 --> Input Class Initialized
INFO - 2024-09-09 09:15:49 --> Language Class Initialized
INFO - 2024-09-09 09:15:49 --> Loader Class Initialized
INFO - 2024-09-09 09:15:49 --> Helper loaded: url_helper
INFO - 2024-09-09 09:15:49 --> Helper loaded: file_helper
INFO - 2024-09-09 09:15:49 --> Helper loaded: security_helper
INFO - 2024-09-09 09:15:49 --> Helper loaded: wpu_helper
INFO - 2024-09-09 09:15:49 --> Database Driver Class Initialized
INFO - 2024-09-09 09:15:49 --> Email Class Initialized
DEBUG - 2024-09-09 09:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 09:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 09:15:49 --> Helper loaded: form_helper
INFO - 2024-09-09 09:15:49 --> Form Validation Class Initialized
INFO - 2024-09-09 09:15:49 --> Controller Class Initialized
DEBUG - 2024-09-09 09:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 09:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 09:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 09:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 09:15:49 --> Final output sent to browser
DEBUG - 2024-09-09 09:15:49 --> Total execution time: 0.2269
INFO - 2024-09-09 09:44:20 --> Config Class Initialized
INFO - 2024-09-09 09:44:20 --> Hooks Class Initialized
DEBUG - 2024-09-09 09:44:20 --> UTF-8 Support Enabled
INFO - 2024-09-09 09:44:20 --> Utf8 Class Initialized
INFO - 2024-09-09 09:44:20 --> URI Class Initialized
DEBUG - 2024-09-09 09:44:20 --> No URI present. Default controller set.
INFO - 2024-09-09 09:44:20 --> Router Class Initialized
INFO - 2024-09-09 09:44:20 --> Output Class Initialized
INFO - 2024-09-09 09:44:20 --> Security Class Initialized
DEBUG - 2024-09-09 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 09:44:20 --> Input Class Initialized
INFO - 2024-09-09 09:44:20 --> Language Class Initialized
INFO - 2024-09-09 09:44:20 --> Loader Class Initialized
INFO - 2024-09-09 09:44:20 --> Helper loaded: url_helper
INFO - 2024-09-09 09:44:20 --> Helper loaded: file_helper
INFO - 2024-09-09 09:44:20 --> Helper loaded: security_helper
INFO - 2024-09-09 09:44:20 --> Helper loaded: wpu_helper
INFO - 2024-09-09 09:44:20 --> Database Driver Class Initialized
INFO - 2024-09-09 09:44:20 --> Email Class Initialized
DEBUG - 2024-09-09 09:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 09:44:20 --> Helper loaded: form_helper
INFO - 2024-09-09 09:44:20 --> Form Validation Class Initialized
INFO - 2024-09-09 09:44:20 --> Controller Class Initialized
DEBUG - 2024-09-09 09:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 09:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 09:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 09:44:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 09:44:20 --> Final output sent to browser
DEBUG - 2024-09-09 09:44:20 --> Total execution time: 0.4562
INFO - 2024-09-09 09:56:49 --> Config Class Initialized
INFO - 2024-09-09 09:56:49 --> Hooks Class Initialized
DEBUG - 2024-09-09 09:56:49 --> UTF-8 Support Enabled
INFO - 2024-09-09 09:56:49 --> Utf8 Class Initialized
INFO - 2024-09-09 09:56:49 --> URI Class Initialized
DEBUG - 2024-09-09 09:56:49 --> No URI present. Default controller set.
INFO - 2024-09-09 09:56:49 --> Router Class Initialized
INFO - 2024-09-09 09:56:49 --> Output Class Initialized
INFO - 2024-09-09 09:56:49 --> Security Class Initialized
DEBUG - 2024-09-09 09:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 09:56:49 --> Input Class Initialized
INFO - 2024-09-09 09:56:49 --> Language Class Initialized
INFO - 2024-09-09 09:56:49 --> Loader Class Initialized
INFO - 2024-09-09 09:56:49 --> Helper loaded: url_helper
INFO - 2024-09-09 09:56:49 --> Helper loaded: file_helper
INFO - 2024-09-09 09:56:49 --> Helper loaded: security_helper
INFO - 2024-09-09 09:56:49 --> Helper loaded: wpu_helper
INFO - 2024-09-09 09:56:49 --> Database Driver Class Initialized
INFO - 2024-09-09 09:56:49 --> Email Class Initialized
DEBUG - 2024-09-09 09:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 09:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 09:56:49 --> Helper loaded: form_helper
INFO - 2024-09-09 09:56:49 --> Form Validation Class Initialized
INFO - 2024-09-09 09:56:49 --> Controller Class Initialized
DEBUG - 2024-09-09 09:56:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 09:56:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 09:56:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 09:56:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 09:56:49 --> Final output sent to browser
DEBUG - 2024-09-09 09:56:49 --> Total execution time: 0.2190
INFO - 2024-09-09 09:57:15 --> Config Class Initialized
INFO - 2024-09-09 09:57:15 --> Hooks Class Initialized
DEBUG - 2024-09-09 09:57:15 --> UTF-8 Support Enabled
INFO - 2024-09-09 09:57:15 --> Utf8 Class Initialized
INFO - 2024-09-09 09:57:15 --> URI Class Initialized
INFO - 2024-09-09 09:57:15 --> Router Class Initialized
INFO - 2024-09-09 09:57:15 --> Output Class Initialized
INFO - 2024-09-09 09:57:15 --> Security Class Initialized
DEBUG - 2024-09-09 09:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 09:57:15 --> Input Class Initialized
INFO - 2024-09-09 09:57:15 --> Language Class Initialized
ERROR - 2024-09-09 09:57:15 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-09-09 10:14:50 --> Config Class Initialized
INFO - 2024-09-09 10:14:50 --> Hooks Class Initialized
DEBUG - 2024-09-09 10:14:50 --> UTF-8 Support Enabled
INFO - 2024-09-09 10:14:50 --> Utf8 Class Initialized
INFO - 2024-09-09 10:14:50 --> URI Class Initialized
DEBUG - 2024-09-09 10:14:50 --> No URI present. Default controller set.
INFO - 2024-09-09 10:14:50 --> Router Class Initialized
INFO - 2024-09-09 10:14:50 --> Output Class Initialized
INFO - 2024-09-09 10:14:50 --> Security Class Initialized
DEBUG - 2024-09-09 10:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 10:14:50 --> Input Class Initialized
INFO - 2024-09-09 10:14:50 --> Language Class Initialized
INFO - 2024-09-09 10:14:50 --> Loader Class Initialized
INFO - 2024-09-09 10:14:50 --> Helper loaded: url_helper
INFO - 2024-09-09 10:14:50 --> Helper loaded: file_helper
INFO - 2024-09-09 10:14:50 --> Helper loaded: security_helper
INFO - 2024-09-09 10:14:50 --> Helper loaded: wpu_helper
INFO - 2024-09-09 10:14:50 --> Database Driver Class Initialized
INFO - 2024-09-09 10:14:50 --> Email Class Initialized
DEBUG - 2024-09-09 10:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 10:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 10:14:50 --> Helper loaded: form_helper
INFO - 2024-09-09 10:14:50 --> Form Validation Class Initialized
INFO - 2024-09-09 10:14:50 --> Controller Class Initialized
DEBUG - 2024-09-09 10:14:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 10:14:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 10:14:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 10:14:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 10:14:50 --> Final output sent to browser
DEBUG - 2024-09-09 10:14:50 --> Total execution time: 0.2196
INFO - 2024-09-09 10:44:29 --> Config Class Initialized
INFO - 2024-09-09 10:44:29 --> Hooks Class Initialized
DEBUG - 2024-09-09 10:44:29 --> UTF-8 Support Enabled
INFO - 2024-09-09 10:44:29 --> Utf8 Class Initialized
INFO - 2024-09-09 10:44:29 --> URI Class Initialized
DEBUG - 2024-09-09 10:44:29 --> No URI present. Default controller set.
INFO - 2024-09-09 10:44:29 --> Router Class Initialized
INFO - 2024-09-09 10:44:29 --> Output Class Initialized
INFO - 2024-09-09 10:44:29 --> Security Class Initialized
DEBUG - 2024-09-09 10:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 10:44:29 --> Input Class Initialized
INFO - 2024-09-09 10:44:29 --> Language Class Initialized
INFO - 2024-09-09 10:44:29 --> Loader Class Initialized
INFO - 2024-09-09 10:44:29 --> Helper loaded: url_helper
INFO - 2024-09-09 10:44:29 --> Helper loaded: file_helper
INFO - 2024-09-09 10:44:29 --> Helper loaded: security_helper
INFO - 2024-09-09 10:44:29 --> Helper loaded: wpu_helper
INFO - 2024-09-09 10:44:29 --> Database Driver Class Initialized
INFO - 2024-09-09 10:44:29 --> Email Class Initialized
DEBUG - 2024-09-09 10:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 10:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 10:44:29 --> Helper loaded: form_helper
INFO - 2024-09-09 10:44:29 --> Form Validation Class Initialized
INFO - 2024-09-09 10:44:29 --> Controller Class Initialized
DEBUG - 2024-09-09 10:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 10:44:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 10:44:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 10:44:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 10:44:29 --> Final output sent to browser
DEBUG - 2024-09-09 10:44:29 --> Total execution time: 0.2286
INFO - 2024-09-09 11:06:51 --> Config Class Initialized
INFO - 2024-09-09 11:06:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:06:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:06:51 --> Utf8 Class Initialized
INFO - 2024-09-09 11:06:51 --> URI Class Initialized
DEBUG - 2024-09-09 11:06:51 --> No URI present. Default controller set.
INFO - 2024-09-09 11:06:51 --> Router Class Initialized
INFO - 2024-09-09 11:06:51 --> Output Class Initialized
INFO - 2024-09-09 11:06:51 --> Security Class Initialized
DEBUG - 2024-09-09 11:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:06:51 --> Input Class Initialized
INFO - 2024-09-09 11:06:51 --> Language Class Initialized
INFO - 2024-09-09 11:06:51 --> Loader Class Initialized
INFO - 2024-09-09 11:06:51 --> Helper loaded: url_helper
INFO - 2024-09-09 11:06:51 --> Helper loaded: file_helper
INFO - 2024-09-09 11:06:51 --> Helper loaded: security_helper
INFO - 2024-09-09 11:06:51 --> Helper loaded: wpu_helper
INFO - 2024-09-09 11:06:51 --> Database Driver Class Initialized
INFO - 2024-09-09 11:06:51 --> Email Class Initialized
DEBUG - 2024-09-09 11:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 11:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 11:06:51 --> Helper loaded: form_helper
INFO - 2024-09-09 11:06:51 --> Form Validation Class Initialized
INFO - 2024-09-09 11:06:51 --> Controller Class Initialized
DEBUG - 2024-09-09 11:06:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 11:06:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 11:06:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 11:06:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 11:06:51 --> Final output sent to browser
DEBUG - 2024-09-09 11:06:51 --> Total execution time: 0.2206
INFO - 2024-09-09 11:07:05 --> Config Class Initialized
INFO - 2024-09-09 11:07:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:07:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:07:05 --> Utf8 Class Initialized
INFO - 2024-09-09 11:07:05 --> URI Class Initialized
INFO - 2024-09-09 11:07:05 --> Router Class Initialized
INFO - 2024-09-09 11:07:05 --> Output Class Initialized
INFO - 2024-09-09 11:07:05 --> Security Class Initialized
DEBUG - 2024-09-09 11:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:07:05 --> Input Class Initialized
INFO - 2024-09-09 11:07:05 --> Language Class Initialized
ERROR - 2024-09-09 11:07:05 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-09-09 11:14:19 --> Config Class Initialized
INFO - 2024-09-09 11:14:19 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:14:19 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:14:19 --> Utf8 Class Initialized
INFO - 2024-09-09 11:14:19 --> URI Class Initialized
DEBUG - 2024-09-09 11:14:19 --> No URI present. Default controller set.
INFO - 2024-09-09 11:14:19 --> Router Class Initialized
INFO - 2024-09-09 11:14:19 --> Output Class Initialized
INFO - 2024-09-09 11:14:19 --> Security Class Initialized
DEBUG - 2024-09-09 11:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:14:19 --> Input Class Initialized
INFO - 2024-09-09 11:14:19 --> Language Class Initialized
INFO - 2024-09-09 11:14:19 --> Loader Class Initialized
INFO - 2024-09-09 11:14:19 --> Helper loaded: url_helper
INFO - 2024-09-09 11:14:19 --> Helper loaded: file_helper
INFO - 2024-09-09 11:14:19 --> Helper loaded: security_helper
INFO - 2024-09-09 11:14:19 --> Helper loaded: wpu_helper
INFO - 2024-09-09 11:14:19 --> Database Driver Class Initialized
INFO - 2024-09-09 11:14:20 --> Email Class Initialized
DEBUG - 2024-09-09 11:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 11:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 11:14:20 --> Helper loaded: form_helper
INFO - 2024-09-09 11:14:20 --> Form Validation Class Initialized
INFO - 2024-09-09 11:14:20 --> Controller Class Initialized
DEBUG - 2024-09-09 11:14:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 11:14:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 11:14:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 11:14:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 11:14:20 --> Final output sent to browser
DEBUG - 2024-09-09 11:14:20 --> Total execution time: 0.2404
INFO - 2024-09-09 11:25:33 --> Config Class Initialized
INFO - 2024-09-09 11:25:33 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:25:33 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:25:33 --> Utf8 Class Initialized
INFO - 2024-09-09 11:25:33 --> URI Class Initialized
DEBUG - 2024-09-09 11:25:33 --> No URI present. Default controller set.
INFO - 2024-09-09 11:25:33 --> Router Class Initialized
INFO - 2024-09-09 11:25:33 --> Output Class Initialized
INFO - 2024-09-09 11:25:33 --> Security Class Initialized
DEBUG - 2024-09-09 11:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:25:33 --> Input Class Initialized
INFO - 2024-09-09 11:25:33 --> Language Class Initialized
INFO - 2024-09-09 11:25:33 --> Loader Class Initialized
INFO - 2024-09-09 11:25:33 --> Helper loaded: url_helper
INFO - 2024-09-09 11:25:33 --> Helper loaded: file_helper
INFO - 2024-09-09 11:25:33 --> Helper loaded: security_helper
INFO - 2024-09-09 11:25:33 --> Helper loaded: wpu_helper
INFO - 2024-09-09 11:25:33 --> Database Driver Class Initialized
INFO - 2024-09-09 11:25:34 --> Email Class Initialized
DEBUG - 2024-09-09 11:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 11:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 11:25:34 --> Helper loaded: form_helper
INFO - 2024-09-09 11:25:34 --> Form Validation Class Initialized
INFO - 2024-09-09 11:25:34 --> Controller Class Initialized
DEBUG - 2024-09-09 11:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 11:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 11:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 11:25:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 11:25:34 --> Final output sent to browser
DEBUG - 2024-09-09 11:25:34 --> Total execution time: 0.4568
INFO - 2024-09-09 11:33:58 --> Config Class Initialized
INFO - 2024-09-09 11:33:58 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:33:58 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:33:58 --> Utf8 Class Initialized
INFO - 2024-09-09 11:33:58 --> URI Class Initialized
DEBUG - 2024-09-09 11:33:58 --> No URI present. Default controller set.
INFO - 2024-09-09 11:33:58 --> Router Class Initialized
INFO - 2024-09-09 11:33:58 --> Output Class Initialized
INFO - 2024-09-09 11:33:58 --> Security Class Initialized
DEBUG - 2024-09-09 11:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:33:58 --> Input Class Initialized
INFO - 2024-09-09 11:33:58 --> Language Class Initialized
INFO - 2024-09-09 11:33:58 --> Loader Class Initialized
INFO - 2024-09-09 11:33:58 --> Helper loaded: url_helper
INFO - 2024-09-09 11:33:58 --> Helper loaded: file_helper
INFO - 2024-09-09 11:33:58 --> Helper loaded: security_helper
INFO - 2024-09-09 11:33:58 --> Helper loaded: wpu_helper
INFO - 2024-09-09 11:33:58 --> Database Driver Class Initialized
INFO - 2024-09-09 11:33:58 --> Email Class Initialized
DEBUG - 2024-09-09 11:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 11:33:58 --> Helper loaded: form_helper
INFO - 2024-09-09 11:33:58 --> Form Validation Class Initialized
INFO - 2024-09-09 11:33:58 --> Controller Class Initialized
DEBUG - 2024-09-09 11:33:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 11:33:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 11:33:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 11:33:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 11:33:58 --> Final output sent to browser
DEBUG - 2024-09-09 11:33:58 --> Total execution time: 0.2274
INFO - 2024-09-09 11:34:16 --> Config Class Initialized
INFO - 2024-09-09 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:16 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:16 --> URI Class Initialized
INFO - 2024-09-09 11:34:16 --> Router Class Initialized
INFO - 2024-09-09 11:34:16 --> Output Class Initialized
INFO - 2024-09-09 11:34:16 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:16 --> Input Class Initialized
INFO - 2024-09-09 11:34:16 --> Language Class Initialized
ERROR - 2024-09-09 11:34:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:16 --> Config Class Initialized
INFO - 2024-09-09 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:16 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:16 --> URI Class Initialized
INFO - 2024-09-09 11:34:16 --> Router Class Initialized
INFO - 2024-09-09 11:34:16 --> Output Class Initialized
INFO - 2024-09-09 11:34:16 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:16 --> Input Class Initialized
INFO - 2024-09-09 11:34:16 --> Language Class Initialized
ERROR - 2024-09-09 11:34:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:16 --> Config Class Initialized
INFO - 2024-09-09 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:16 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:16 --> URI Class Initialized
INFO - 2024-09-09 11:34:16 --> Router Class Initialized
INFO - 2024-09-09 11:34:16 --> Output Class Initialized
INFO - 2024-09-09 11:34:16 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:16 --> Input Class Initialized
INFO - 2024-09-09 11:34:16 --> Language Class Initialized
ERROR - 2024-09-09 11:34:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-09-09 11:34:16 --> Config Class Initialized
INFO - 2024-09-09 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:16 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:16 --> URI Class Initialized
INFO - 2024-09-09 11:34:16 --> Router Class Initialized
INFO - 2024-09-09 11:34:16 --> Output Class Initialized
INFO - 2024-09-09 11:34:16 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:16 --> Input Class Initialized
INFO - 2024-09-09 11:34:16 --> Language Class Initialized
ERROR - 2024-09-09 11:34:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:16 --> Config Class Initialized
INFO - 2024-09-09 11:34:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:16 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:16 --> URI Class Initialized
INFO - 2024-09-09 11:34:16 --> Router Class Initialized
INFO - 2024-09-09 11:34:16 --> Output Class Initialized
INFO - 2024-09-09 11:34:16 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:16 --> Input Class Initialized
INFO - 2024-09-09 11:34:16 --> Language Class Initialized
ERROR - 2024-09-09 11:34:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:36 --> Config Class Initialized
INFO - 2024-09-09 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:36 --> Config Class Initialized
INFO - 2024-09-09 11:34:36 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:36 --> Hooks Class Initialized
INFO - 2024-09-09 11:34:36 --> URI Class Initialized
DEBUG - 2024-09-09 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:36 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:36 --> Router Class Initialized
INFO - 2024-09-09 11:34:36 --> URI Class Initialized
INFO - 2024-09-09 11:34:36 --> Output Class Initialized
INFO - 2024-09-09 11:34:36 --> Router Class Initialized
INFO - 2024-09-09 11:34:36 --> Security Class Initialized
INFO - 2024-09-09 11:34:36 --> Output Class Initialized
DEBUG - 2024-09-09 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:36 --> Input Class Initialized
INFO - 2024-09-09 11:34:36 --> Security Class Initialized
INFO - 2024-09-09 11:34:36 --> Language Class Initialized
ERROR - 2024-09-09 11:34:36 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-09-09 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:36 --> Input Class Initialized
INFO - 2024-09-09 11:34:36 --> Language Class Initialized
ERROR - 2024-09-09 11:34:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:36 --> Config Class Initialized
INFO - 2024-09-09 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:36 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:36 --> URI Class Initialized
INFO - 2024-09-09 11:34:36 --> Router Class Initialized
INFO - 2024-09-09 11:34:36 --> Output Class Initialized
INFO - 2024-09-09 11:34:36 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:36 --> Input Class Initialized
INFO - 2024-09-09 11:34:36 --> Language Class Initialized
ERROR - 2024-09-09 11:34:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:36 --> Config Class Initialized
INFO - 2024-09-09 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:36 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:36 --> URI Class Initialized
INFO - 2024-09-09 11:34:36 --> Router Class Initialized
INFO - 2024-09-09 11:34:36 --> Output Class Initialized
INFO - 2024-09-09 11:34:36 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:36 --> Input Class Initialized
INFO - 2024-09-09 11:34:36 --> Language Class Initialized
ERROR - 2024-09-09 11:34:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:36 --> Config Class Initialized
INFO - 2024-09-09 11:34:36 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:36 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:36 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:36 --> URI Class Initialized
INFO - 2024-09-09 11:34:36 --> Router Class Initialized
INFO - 2024-09-09 11:34:36 --> Output Class Initialized
INFO - 2024-09-09 11:34:36 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:36 --> Input Class Initialized
INFO - 2024-09-09 11:34:36 --> Language Class Initialized
ERROR - 2024-09-09 11:34:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:54 --> Config Class Initialized
INFO - 2024-09-09 11:34:54 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:54 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:54 --> URI Class Initialized
INFO - 2024-09-09 11:34:54 --> Router Class Initialized
INFO - 2024-09-09 11:34:54 --> Output Class Initialized
INFO - 2024-09-09 11:34:54 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:54 --> Input Class Initialized
INFO - 2024-09-09 11:34:54 --> Language Class Initialized
ERROR - 2024-09-09 11:34:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:54 --> Config Class Initialized
INFO - 2024-09-09 11:34:54 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:54 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:54 --> URI Class Initialized
INFO - 2024-09-09 11:34:54 --> Router Class Initialized
INFO - 2024-09-09 11:34:54 --> Config Class Initialized
INFO - 2024-09-09 11:34:54 --> Hooks Class Initialized
INFO - 2024-09-09 11:34:54 --> Output Class Initialized
DEBUG - 2024-09-09 11:34:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:54 --> Config Class Initialized
INFO - 2024-09-09 11:34:54 --> Security Class Initialized
INFO - 2024-09-09 11:34:54 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:54 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:54 --> Input Class Initialized
INFO - 2024-09-09 11:34:54 --> Language Class Initialized
INFO - 2024-09-09 11:34:54 --> URI Class Initialized
DEBUG - 2024-09-09 11:34:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:54 --> Utf8 Class Initialized
ERROR - 2024-09-09 11:34:54 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-09-09 11:34:54 --> Router Class Initialized
INFO - 2024-09-09 11:34:54 --> URI Class Initialized
INFO - 2024-09-09 11:34:54 --> Router Class Initialized
INFO - 2024-09-09 11:34:54 --> Output Class Initialized
INFO - 2024-09-09 11:34:54 --> Output Class Initialized
INFO - 2024-09-09 11:34:54 --> Security Class Initialized
INFO - 2024-09-09 11:34:54 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:54 --> Input Class Initialized
INFO - 2024-09-09 11:34:54 --> Language Class Initialized
DEBUG - 2024-09-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:54 --> Input Class Initialized
ERROR - 2024-09-09 11:34:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:54 --> Language Class Initialized
ERROR - 2024-09-09 11:34:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:34:54 --> Config Class Initialized
INFO - 2024-09-09 11:34:54 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:34:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:34:54 --> Utf8 Class Initialized
INFO - 2024-09-09 11:34:54 --> URI Class Initialized
INFO - 2024-09-09 11:34:54 --> Router Class Initialized
INFO - 2024-09-09 11:34:54 --> Output Class Initialized
INFO - 2024-09-09 11:34:54 --> Security Class Initialized
DEBUG - 2024-09-09 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:34:54 --> Input Class Initialized
INFO - 2024-09-09 11:34:54 --> Language Class Initialized
ERROR - 2024-09-09 11:34:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:14 --> Config Class Initialized
INFO - 2024-09-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:14 --> URI Class Initialized
INFO - 2024-09-09 11:35:14 --> Router Class Initialized
INFO - 2024-09-09 11:35:14 --> Output Class Initialized
INFO - 2024-09-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:14 --> Input Class Initialized
INFO - 2024-09-09 11:35:14 --> Language Class Initialized
ERROR - 2024-09-09 11:35:14 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-09-09 11:35:14 --> Config Class Initialized
INFO - 2024-09-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:14 --> URI Class Initialized
INFO - 2024-09-09 11:35:14 --> Router Class Initialized
INFO - 2024-09-09 11:35:14 --> Output Class Initialized
INFO - 2024-09-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:14 --> Input Class Initialized
INFO - 2024-09-09 11:35:14 --> Language Class Initialized
ERROR - 2024-09-09 11:35:14 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:14 --> Config Class Initialized
INFO - 2024-09-09 11:35:14 --> Hooks Class Initialized
INFO - 2024-09-09 11:35:14 --> Config Class Initialized
DEBUG - 2024-09-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:14 --> Hooks Class Initialized
INFO - 2024-09-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:14 --> URI Class Initialized
DEBUG - 2024-09-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:14 --> Router Class Initialized
INFO - 2024-09-09 11:35:14 --> URI Class Initialized
INFO - 2024-09-09 11:35:14 --> Output Class Initialized
INFO - 2024-09-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:14 --> Input Class Initialized
INFO - 2024-09-09 11:35:14 --> Language Class Initialized
ERROR - 2024-09-09 11:35:14 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:14 --> Router Class Initialized
INFO - 2024-09-09 11:35:14 --> Output Class Initialized
INFO - 2024-09-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:14 --> Input Class Initialized
INFO - 2024-09-09 11:35:14 --> Language Class Initialized
ERROR - 2024-09-09 11:35:14 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:14 --> Config Class Initialized
INFO - 2024-09-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:14 --> URI Class Initialized
INFO - 2024-09-09 11:35:14 --> Router Class Initialized
INFO - 2024-09-09 11:35:14 --> Output Class Initialized
INFO - 2024-09-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:14 --> Input Class Initialized
INFO - 2024-09-09 11:35:14 --> Language Class Initialized
ERROR - 2024-09-09 11:35:14 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:41 --> Config Class Initialized
INFO - 2024-09-09 11:35:41 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:41 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:41 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:41 --> URI Class Initialized
INFO - 2024-09-09 11:35:41 --> Config Class Initialized
INFO - 2024-09-09 11:35:41 --> Hooks Class Initialized
INFO - 2024-09-09 11:35:41 --> Router Class Initialized
DEBUG - 2024-09-09 11:35:41 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:41 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:41 --> Output Class Initialized
INFO - 2024-09-09 11:35:41 --> URI Class Initialized
INFO - 2024-09-09 11:35:41 --> Security Class Initialized
INFO - 2024-09-09 11:35:41 --> Router Class Initialized
DEBUG - 2024-09-09 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:41 --> Input Class Initialized
INFO - 2024-09-09 11:35:41 --> Output Class Initialized
INFO - 2024-09-09 11:35:41 --> Language Class Initialized
ERROR - 2024-09-09 11:35:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:41 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:41 --> Input Class Initialized
INFO - 2024-09-09 11:35:41 --> Language Class Initialized
ERROR - 2024-09-09 11:35:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:41 --> Config Class Initialized
INFO - 2024-09-09 11:35:41 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:41 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:41 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:41 --> URI Class Initialized
INFO - 2024-09-09 11:35:41 --> Router Class Initialized
INFO - 2024-09-09 11:35:41 --> Output Class Initialized
INFO - 2024-09-09 11:35:41 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:41 --> Input Class Initialized
INFO - 2024-09-09 11:35:41 --> Language Class Initialized
ERROR - 2024-09-09 11:35:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:35:41 --> Config Class Initialized
INFO - 2024-09-09 11:35:41 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:41 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:41 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:41 --> URI Class Initialized
INFO - 2024-09-09 11:35:41 --> Router Class Initialized
INFO - 2024-09-09 11:35:41 --> Output Class Initialized
INFO - 2024-09-09 11:35:41 --> Security Class Initialized
INFO - 2024-09-09 11:35:41 --> Config Class Initialized
INFO - 2024-09-09 11:35:41 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:41 --> Input Class Initialized
INFO - 2024-09-09 11:35:41 --> Language Class Initialized
ERROR - 2024-09-09 11:35:41 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-09-09 11:35:41 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:35:41 --> Utf8 Class Initialized
INFO - 2024-09-09 11:35:41 --> URI Class Initialized
INFO - 2024-09-09 11:35:41 --> Router Class Initialized
INFO - 2024-09-09 11:35:41 --> Output Class Initialized
INFO - 2024-09-09 11:35:41 --> Security Class Initialized
DEBUG - 2024-09-09 11:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:35:41 --> Input Class Initialized
INFO - 2024-09-09 11:35:41 --> Language Class Initialized
ERROR - 2024-09-09 11:35:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:36:01 --> Config Class Initialized
INFO - 2024-09-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-09 11:36:01 --> URI Class Initialized
INFO - 2024-09-09 11:36:01 --> Router Class Initialized
INFO - 2024-09-09 11:36:01 --> Config Class Initialized
INFO - 2024-09-09 11:36:01 --> Hooks Class Initialized
INFO - 2024-09-09 11:36:01 --> Output Class Initialized
DEBUG - 2024-09-09 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-09 11:36:01 --> URI Class Initialized
INFO - 2024-09-09 11:36:01 --> Security Class Initialized
INFO - 2024-09-09 11:36:01 --> Router Class Initialized
DEBUG - 2024-09-09 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:36:01 --> Input Class Initialized
INFO - 2024-09-09 11:36:01 --> Language Class Initialized
ERROR - 2024-09-09 11:36:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:36:01 --> Output Class Initialized
INFO - 2024-09-09 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-09 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:36:01 --> Input Class Initialized
INFO - 2024-09-09 11:36:01 --> Language Class Initialized
ERROR - 2024-09-09 11:36:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:36:01 --> Config Class Initialized
INFO - 2024-09-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-09 11:36:01 --> URI Class Initialized
INFO - 2024-09-09 11:36:01 --> Router Class Initialized
INFO - 2024-09-09 11:36:01 --> Output Class Initialized
INFO - 2024-09-09 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-09 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:36:01 --> Input Class Initialized
INFO - 2024-09-09 11:36:01 --> Language Class Initialized
ERROR - 2024-09-09 11:36:01 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-09-09 11:36:01 --> Config Class Initialized
INFO - 2024-09-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-09 11:36:01 --> URI Class Initialized
INFO - 2024-09-09 11:36:01 --> Router Class Initialized
INFO - 2024-09-09 11:36:01 --> Output Class Initialized
INFO - 2024-09-09 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-09 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:36:01 --> Input Class Initialized
INFO - 2024-09-09 11:36:01 --> Language Class Initialized
ERROR - 2024-09-09 11:36:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:36:01 --> Config Class Initialized
INFO - 2024-09-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-09 11:36:01 --> URI Class Initialized
INFO - 2024-09-09 11:36:01 --> Router Class Initialized
INFO - 2024-09-09 11:36:01 --> Output Class Initialized
INFO - 2024-09-09 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-09 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:36:01 --> Input Class Initialized
INFO - 2024-09-09 11:36:01 --> Language Class Initialized
ERROR - 2024-09-09 11:36:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-09-09 11:45:23 --> Config Class Initialized
INFO - 2024-09-09 11:45:23 --> Hooks Class Initialized
DEBUG - 2024-09-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-09-09 11:45:23 --> Utf8 Class Initialized
INFO - 2024-09-09 11:45:23 --> URI Class Initialized
DEBUG - 2024-09-09 11:45:23 --> No URI present. Default controller set.
INFO - 2024-09-09 11:45:23 --> Router Class Initialized
INFO - 2024-09-09 11:45:23 --> Output Class Initialized
INFO - 2024-09-09 11:45:23 --> Security Class Initialized
DEBUG - 2024-09-09 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 11:45:23 --> Input Class Initialized
INFO - 2024-09-09 11:45:23 --> Language Class Initialized
INFO - 2024-09-09 11:45:23 --> Loader Class Initialized
INFO - 2024-09-09 11:45:23 --> Helper loaded: url_helper
INFO - 2024-09-09 11:45:23 --> Helper loaded: file_helper
INFO - 2024-09-09 11:45:23 --> Helper loaded: security_helper
INFO - 2024-09-09 11:45:23 --> Helper loaded: wpu_helper
INFO - 2024-09-09 11:45:23 --> Database Driver Class Initialized
INFO - 2024-09-09 11:45:23 --> Email Class Initialized
DEBUG - 2024-09-09 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 11:45:23 --> Helper loaded: form_helper
INFO - 2024-09-09 11:45:23 --> Form Validation Class Initialized
INFO - 2024-09-09 11:45:23 --> Controller Class Initialized
DEBUG - 2024-09-09 11:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 11:45:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 11:45:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 11:45:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 11:45:23 --> Final output sent to browser
DEBUG - 2024-09-09 11:45:23 --> Total execution time: 0.2237
INFO - 2024-09-09 12:15:53 --> Config Class Initialized
INFO - 2024-09-09 12:15:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 12:15:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 12:15:53 --> Utf8 Class Initialized
INFO - 2024-09-09 12:15:53 --> URI Class Initialized
DEBUG - 2024-09-09 12:15:53 --> No URI present. Default controller set.
INFO - 2024-09-09 12:15:53 --> Router Class Initialized
INFO - 2024-09-09 12:15:53 --> Output Class Initialized
INFO - 2024-09-09 12:15:53 --> Security Class Initialized
DEBUG - 2024-09-09 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 12:15:53 --> Input Class Initialized
INFO - 2024-09-09 12:15:53 --> Language Class Initialized
INFO - 2024-09-09 12:15:53 --> Loader Class Initialized
INFO - 2024-09-09 12:15:53 --> Helper loaded: url_helper
INFO - 2024-09-09 12:15:53 --> Helper loaded: file_helper
INFO - 2024-09-09 12:15:53 --> Helper loaded: security_helper
INFO - 2024-09-09 12:15:53 --> Helper loaded: wpu_helper
INFO - 2024-09-09 12:15:53 --> Database Driver Class Initialized
INFO - 2024-09-09 12:15:53 --> Email Class Initialized
DEBUG - 2024-09-09 12:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 12:15:53 --> Helper loaded: form_helper
INFO - 2024-09-09 12:15:53 --> Form Validation Class Initialized
INFO - 2024-09-09 12:15:53 --> Controller Class Initialized
DEBUG - 2024-09-09 12:15:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 12:15:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 12:15:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 12:15:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 12:15:53 --> Final output sent to browser
DEBUG - 2024-09-09 12:15:53 --> Total execution time: 0.2495
INFO - 2024-09-09 12:44:23 --> Config Class Initialized
INFO - 2024-09-09 12:44:23 --> Hooks Class Initialized
DEBUG - 2024-09-09 12:44:23 --> UTF-8 Support Enabled
INFO - 2024-09-09 12:44:23 --> Utf8 Class Initialized
INFO - 2024-09-09 12:44:23 --> URI Class Initialized
DEBUG - 2024-09-09 12:44:23 --> No URI present. Default controller set.
INFO - 2024-09-09 12:44:23 --> Router Class Initialized
INFO - 2024-09-09 12:44:23 --> Output Class Initialized
INFO - 2024-09-09 12:44:23 --> Security Class Initialized
DEBUG - 2024-09-09 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 12:44:23 --> Input Class Initialized
INFO - 2024-09-09 12:44:23 --> Language Class Initialized
INFO - 2024-09-09 12:44:23 --> Loader Class Initialized
INFO - 2024-09-09 12:44:23 --> Helper loaded: url_helper
INFO - 2024-09-09 12:44:23 --> Helper loaded: file_helper
INFO - 2024-09-09 12:44:23 --> Helper loaded: security_helper
INFO - 2024-09-09 12:44:23 --> Helper loaded: wpu_helper
INFO - 2024-09-09 12:44:23 --> Database Driver Class Initialized
INFO - 2024-09-09 12:44:24 --> Email Class Initialized
DEBUG - 2024-09-09 12:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 12:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 12:44:24 --> Helper loaded: form_helper
INFO - 2024-09-09 12:44:24 --> Form Validation Class Initialized
INFO - 2024-09-09 12:44:24 --> Controller Class Initialized
DEBUG - 2024-09-09 12:44:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 12:44:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 12:44:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 12:44:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 12:44:24 --> Final output sent to browser
DEBUG - 2024-09-09 12:44:24 --> Total execution time: 1.6742
INFO - 2024-09-09 13:15:16 --> Config Class Initialized
INFO - 2024-09-09 13:15:16 --> Hooks Class Initialized
DEBUG - 2024-09-09 13:15:16 --> UTF-8 Support Enabled
INFO - 2024-09-09 13:15:16 --> Utf8 Class Initialized
INFO - 2024-09-09 13:15:16 --> URI Class Initialized
DEBUG - 2024-09-09 13:15:16 --> No URI present. Default controller set.
INFO - 2024-09-09 13:15:16 --> Router Class Initialized
INFO - 2024-09-09 13:15:16 --> Output Class Initialized
INFO - 2024-09-09 13:15:16 --> Security Class Initialized
DEBUG - 2024-09-09 13:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 13:15:16 --> Input Class Initialized
INFO - 2024-09-09 13:15:16 --> Language Class Initialized
INFO - 2024-09-09 13:15:16 --> Loader Class Initialized
INFO - 2024-09-09 13:15:16 --> Helper loaded: url_helper
INFO - 2024-09-09 13:15:16 --> Helper loaded: file_helper
INFO - 2024-09-09 13:15:16 --> Helper loaded: security_helper
INFO - 2024-09-09 13:15:16 --> Helper loaded: wpu_helper
INFO - 2024-09-09 13:15:16 --> Database Driver Class Initialized
INFO - 2024-09-09 13:15:17 --> Email Class Initialized
DEBUG - 2024-09-09 13:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 13:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 13:15:17 --> Helper loaded: form_helper
INFO - 2024-09-09 13:15:17 --> Form Validation Class Initialized
INFO - 2024-09-09 13:15:17 --> Controller Class Initialized
DEBUG - 2024-09-09 13:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 13:15:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 13:15:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 13:15:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 13:15:17 --> Final output sent to browser
DEBUG - 2024-09-09 13:15:17 --> Total execution time: 0.4655
INFO - 2024-09-09 13:44:34 --> Config Class Initialized
INFO - 2024-09-09 13:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-09 13:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-09 13:44:34 --> Utf8 Class Initialized
INFO - 2024-09-09 13:44:34 --> URI Class Initialized
DEBUG - 2024-09-09 13:44:34 --> No URI present. Default controller set.
INFO - 2024-09-09 13:44:34 --> Router Class Initialized
INFO - 2024-09-09 13:44:34 --> Output Class Initialized
INFO - 2024-09-09 13:44:34 --> Security Class Initialized
DEBUG - 2024-09-09 13:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 13:44:34 --> Input Class Initialized
INFO - 2024-09-09 13:44:34 --> Language Class Initialized
INFO - 2024-09-09 13:44:34 --> Loader Class Initialized
INFO - 2024-09-09 13:44:34 --> Helper loaded: url_helper
INFO - 2024-09-09 13:44:34 --> Helper loaded: file_helper
INFO - 2024-09-09 13:44:34 --> Helper loaded: security_helper
INFO - 2024-09-09 13:44:34 --> Helper loaded: wpu_helper
INFO - 2024-09-09 13:44:34 --> Database Driver Class Initialized
INFO - 2024-09-09 13:44:36 --> Email Class Initialized
DEBUG - 2024-09-09 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 13:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 13:44:36 --> Helper loaded: form_helper
INFO - 2024-09-09 13:44:36 --> Form Validation Class Initialized
INFO - 2024-09-09 13:44:36 --> Controller Class Initialized
DEBUG - 2024-09-09 13:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 13:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 13:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 13:44:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 13:44:36 --> Final output sent to browser
DEBUG - 2024-09-09 13:44:36 --> Total execution time: 2.1241
INFO - 2024-09-09 14:19:45 --> Config Class Initialized
INFO - 2024-09-09 14:19:45 --> Hooks Class Initialized
DEBUG - 2024-09-09 14:19:45 --> UTF-8 Support Enabled
INFO - 2024-09-09 14:19:45 --> Utf8 Class Initialized
INFO - 2024-09-09 14:19:45 --> URI Class Initialized
DEBUG - 2024-09-09 14:19:45 --> No URI present. Default controller set.
INFO - 2024-09-09 14:19:45 --> Router Class Initialized
INFO - 2024-09-09 14:19:45 --> Output Class Initialized
INFO - 2024-09-09 14:19:45 --> Security Class Initialized
DEBUG - 2024-09-09 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 14:19:45 --> Input Class Initialized
INFO - 2024-09-09 14:19:45 --> Language Class Initialized
INFO - 2024-09-09 14:19:45 --> Loader Class Initialized
INFO - 2024-09-09 14:19:45 --> Helper loaded: url_helper
INFO - 2024-09-09 14:19:45 --> Helper loaded: file_helper
INFO - 2024-09-09 14:19:45 --> Helper loaded: security_helper
INFO - 2024-09-09 14:19:45 --> Helper loaded: wpu_helper
INFO - 2024-09-09 14:19:45 --> Database Driver Class Initialized
INFO - 2024-09-09 14:19:45 --> Email Class Initialized
DEBUG - 2024-09-09 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 14:19:45 --> Helper loaded: form_helper
INFO - 2024-09-09 14:19:45 --> Form Validation Class Initialized
INFO - 2024-09-09 14:19:45 --> Controller Class Initialized
DEBUG - 2024-09-09 14:19:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 14:19:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 14:19:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 14:19:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 14:19:45 --> Final output sent to browser
DEBUG - 2024-09-09 14:19:45 --> Total execution time: 0.2372
INFO - 2024-09-09 14:27:25 --> Config Class Initialized
INFO - 2024-09-09 14:27:25 --> Hooks Class Initialized
DEBUG - 2024-09-09 14:27:25 --> UTF-8 Support Enabled
INFO - 2024-09-09 14:27:25 --> Utf8 Class Initialized
INFO - 2024-09-09 14:27:25 --> URI Class Initialized
DEBUG - 2024-09-09 14:27:25 --> No URI present. Default controller set.
INFO - 2024-09-09 14:27:25 --> Router Class Initialized
INFO - 2024-09-09 14:27:25 --> Output Class Initialized
INFO - 2024-09-09 14:27:25 --> Security Class Initialized
DEBUG - 2024-09-09 14:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 14:27:25 --> Input Class Initialized
INFO - 2024-09-09 14:27:25 --> Language Class Initialized
INFO - 2024-09-09 14:27:25 --> Loader Class Initialized
INFO - 2024-09-09 14:27:25 --> Helper loaded: url_helper
INFO - 2024-09-09 14:27:25 --> Helper loaded: file_helper
INFO - 2024-09-09 14:27:25 --> Helper loaded: security_helper
INFO - 2024-09-09 14:27:25 --> Helper loaded: wpu_helper
INFO - 2024-09-09 14:27:25 --> Database Driver Class Initialized
INFO - 2024-09-09 14:27:26 --> Email Class Initialized
DEBUG - 2024-09-09 14:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 14:27:26 --> Helper loaded: form_helper
INFO - 2024-09-09 14:27:26 --> Form Validation Class Initialized
INFO - 2024-09-09 14:27:26 --> Controller Class Initialized
DEBUG - 2024-09-09 14:27:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 14:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 14:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 14:27:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 14:27:26 --> Final output sent to browser
DEBUG - 2024-09-09 14:27:26 --> Total execution time: 0.2354
INFO - 2024-09-09 14:45:12 --> Config Class Initialized
INFO - 2024-09-09 14:45:12 --> Hooks Class Initialized
DEBUG - 2024-09-09 14:45:12 --> UTF-8 Support Enabled
INFO - 2024-09-09 14:45:12 --> Utf8 Class Initialized
INFO - 2024-09-09 14:45:12 --> URI Class Initialized
DEBUG - 2024-09-09 14:45:12 --> No URI present. Default controller set.
INFO - 2024-09-09 14:45:12 --> Router Class Initialized
INFO - 2024-09-09 14:45:12 --> Output Class Initialized
INFO - 2024-09-09 14:45:12 --> Security Class Initialized
DEBUG - 2024-09-09 14:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 14:45:12 --> Input Class Initialized
INFO - 2024-09-09 14:45:12 --> Language Class Initialized
INFO - 2024-09-09 14:45:12 --> Loader Class Initialized
INFO - 2024-09-09 14:45:12 --> Helper loaded: url_helper
INFO - 2024-09-09 14:45:12 --> Helper loaded: file_helper
INFO - 2024-09-09 14:45:12 --> Helper loaded: security_helper
INFO - 2024-09-09 14:45:12 --> Helper loaded: wpu_helper
INFO - 2024-09-09 14:45:12 --> Database Driver Class Initialized
INFO - 2024-09-09 14:45:13 --> Email Class Initialized
DEBUG - 2024-09-09 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 14:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 14:45:13 --> Helper loaded: form_helper
INFO - 2024-09-09 14:45:13 --> Form Validation Class Initialized
INFO - 2024-09-09 14:45:13 --> Controller Class Initialized
DEBUG - 2024-09-09 14:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 14:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 14:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 14:45:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 14:45:13 --> Final output sent to browser
DEBUG - 2024-09-09 14:45:13 --> Total execution time: 1.2247
INFO - 2024-09-09 15:21:53 --> Config Class Initialized
INFO - 2024-09-09 15:21:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 15:21:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 15:21:53 --> Utf8 Class Initialized
INFO - 2024-09-09 15:21:53 --> URI Class Initialized
DEBUG - 2024-09-09 15:21:53 --> No URI present. Default controller set.
INFO - 2024-09-09 15:21:53 --> Router Class Initialized
INFO - 2024-09-09 15:21:53 --> Output Class Initialized
INFO - 2024-09-09 15:21:53 --> Security Class Initialized
DEBUG - 2024-09-09 15:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 15:21:53 --> Input Class Initialized
INFO - 2024-09-09 15:21:53 --> Language Class Initialized
INFO - 2024-09-09 15:21:53 --> Loader Class Initialized
INFO - 2024-09-09 15:21:53 --> Helper loaded: url_helper
INFO - 2024-09-09 15:21:53 --> Helper loaded: file_helper
INFO - 2024-09-09 15:21:53 --> Helper loaded: security_helper
INFO - 2024-09-09 15:21:53 --> Helper loaded: wpu_helper
INFO - 2024-09-09 15:21:53 --> Database Driver Class Initialized
INFO - 2024-09-09 15:21:53 --> Email Class Initialized
DEBUG - 2024-09-09 15:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 15:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 15:21:53 --> Helper loaded: form_helper
INFO - 2024-09-09 15:21:53 --> Form Validation Class Initialized
INFO - 2024-09-09 15:21:53 --> Controller Class Initialized
DEBUG - 2024-09-09 15:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 15:21:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 15:21:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 15:21:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 15:21:53 --> Final output sent to browser
DEBUG - 2024-09-09 15:21:53 --> Total execution time: 0.2450
INFO - 2024-09-09 15:53:54 --> Config Class Initialized
INFO - 2024-09-09 15:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-09 15:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-09 15:53:54 --> Utf8 Class Initialized
INFO - 2024-09-09 15:53:54 --> URI Class Initialized
DEBUG - 2024-09-09 15:53:54 --> No URI present. Default controller set.
INFO - 2024-09-09 15:53:54 --> Router Class Initialized
INFO - 2024-09-09 15:53:54 --> Output Class Initialized
INFO - 2024-09-09 15:53:54 --> Security Class Initialized
DEBUG - 2024-09-09 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 15:53:54 --> Input Class Initialized
INFO - 2024-09-09 15:53:54 --> Language Class Initialized
INFO - 2024-09-09 15:53:54 --> Loader Class Initialized
INFO - 2024-09-09 15:53:54 --> Helper loaded: url_helper
INFO - 2024-09-09 15:53:54 --> Helper loaded: file_helper
INFO - 2024-09-09 15:53:54 --> Helper loaded: security_helper
INFO - 2024-09-09 15:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-09 15:53:54 --> Database Driver Class Initialized
INFO - 2024-09-09 15:53:54 --> Email Class Initialized
DEBUG - 2024-09-09 15:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 15:53:54 --> Helper loaded: form_helper
INFO - 2024-09-09 15:53:54 --> Form Validation Class Initialized
INFO - 2024-09-09 15:53:54 --> Controller Class Initialized
DEBUG - 2024-09-09 15:53:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 15:53:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 15:53:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 15:53:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 15:53:54 --> Final output sent to browser
DEBUG - 2024-09-09 15:53:54 --> Total execution time: 0.2693
INFO - 2024-09-09 16:16:20 --> Config Class Initialized
INFO - 2024-09-09 16:16:20 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:16:20 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:16:20 --> Utf8 Class Initialized
INFO - 2024-09-09 16:16:20 --> URI Class Initialized
DEBUG - 2024-09-09 16:16:20 --> No URI present. Default controller set.
INFO - 2024-09-09 16:16:20 --> Router Class Initialized
INFO - 2024-09-09 16:16:20 --> Output Class Initialized
INFO - 2024-09-09 16:16:20 --> Security Class Initialized
DEBUG - 2024-09-09 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:16:20 --> Input Class Initialized
INFO - 2024-09-09 16:16:20 --> Language Class Initialized
INFO - 2024-09-09 16:16:20 --> Loader Class Initialized
INFO - 2024-09-09 16:16:20 --> Helper loaded: url_helper
INFO - 2024-09-09 16:16:20 --> Helper loaded: file_helper
INFO - 2024-09-09 16:16:20 --> Helper loaded: security_helper
INFO - 2024-09-09 16:16:20 --> Helper loaded: wpu_helper
INFO - 2024-09-09 16:16:20 --> Database Driver Class Initialized
INFO - 2024-09-09 16:16:20 --> Email Class Initialized
DEBUG - 2024-09-09 16:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 16:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:16:20 --> Helper loaded: form_helper
INFO - 2024-09-09 16:16:20 --> Form Validation Class Initialized
INFO - 2024-09-09 16:16:20 --> Controller Class Initialized
DEBUG - 2024-09-09 16:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 16:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 16:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 16:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 16:16:20 --> Final output sent to browser
DEBUG - 2024-09-09 16:16:20 --> Total execution time: 0.2238
INFO - 2024-09-09 16:47:33 --> Config Class Initialized
INFO - 2024-09-09 16:47:33 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:47:33 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:47:33 --> Utf8 Class Initialized
INFO - 2024-09-09 16:47:33 --> URI Class Initialized
DEBUG - 2024-09-09 16:47:33 --> No URI present. Default controller set.
INFO - 2024-09-09 16:47:33 --> Router Class Initialized
INFO - 2024-09-09 16:47:33 --> Output Class Initialized
INFO - 2024-09-09 16:47:33 --> Security Class Initialized
DEBUG - 2024-09-09 16:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:47:33 --> Input Class Initialized
INFO - 2024-09-09 16:47:33 --> Language Class Initialized
INFO - 2024-09-09 16:47:33 --> Loader Class Initialized
INFO - 2024-09-09 16:47:33 --> Helper loaded: url_helper
INFO - 2024-09-09 16:47:33 --> Helper loaded: file_helper
INFO - 2024-09-09 16:47:33 --> Helper loaded: security_helper
INFO - 2024-09-09 16:47:33 --> Helper loaded: wpu_helper
INFO - 2024-09-09 16:47:33 --> Database Driver Class Initialized
INFO - 2024-09-09 16:47:34 --> Email Class Initialized
DEBUG - 2024-09-09 16:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 16:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:47:34 --> Helper loaded: form_helper
INFO - 2024-09-09 16:47:34 --> Form Validation Class Initialized
INFO - 2024-09-09 16:47:34 --> Controller Class Initialized
DEBUG - 2024-09-09 16:47:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 16:47:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 16:47:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 16:47:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 16:47:34 --> Final output sent to browser
DEBUG - 2024-09-09 16:47:34 --> Total execution time: 0.2188
INFO - 2024-09-09 17:23:58 --> Config Class Initialized
INFO - 2024-09-09 17:23:58 --> Hooks Class Initialized
DEBUG - 2024-09-09 17:23:58 --> UTF-8 Support Enabled
INFO - 2024-09-09 17:23:58 --> Utf8 Class Initialized
INFO - 2024-09-09 17:23:58 --> URI Class Initialized
DEBUG - 2024-09-09 17:23:58 --> No URI present. Default controller set.
INFO - 2024-09-09 17:23:58 --> Router Class Initialized
INFO - 2024-09-09 17:23:58 --> Output Class Initialized
INFO - 2024-09-09 17:23:58 --> Security Class Initialized
DEBUG - 2024-09-09 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 17:23:58 --> Input Class Initialized
INFO - 2024-09-09 17:23:58 --> Language Class Initialized
INFO - 2024-09-09 17:23:58 --> Loader Class Initialized
INFO - 2024-09-09 17:23:58 --> Helper loaded: url_helper
INFO - 2024-09-09 17:23:58 --> Helper loaded: file_helper
INFO - 2024-09-09 17:23:58 --> Helper loaded: security_helper
INFO - 2024-09-09 17:23:58 --> Helper loaded: wpu_helper
INFO - 2024-09-09 17:23:58 --> Database Driver Class Initialized
INFO - 2024-09-09 17:23:58 --> Email Class Initialized
DEBUG - 2024-09-09 17:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 17:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 17:23:58 --> Helper loaded: form_helper
INFO - 2024-09-09 17:23:58 --> Form Validation Class Initialized
INFO - 2024-09-09 17:23:58 --> Controller Class Initialized
DEBUG - 2024-09-09 17:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 17:23:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 17:23:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 17:23:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 17:23:58 --> Final output sent to browser
DEBUG - 2024-09-09 17:23:58 --> Total execution time: 0.2569
INFO - 2024-09-09 17:27:33 --> Config Class Initialized
INFO - 2024-09-09 17:27:33 --> Hooks Class Initialized
DEBUG - 2024-09-09 17:27:33 --> UTF-8 Support Enabled
INFO - 2024-09-09 17:27:33 --> Utf8 Class Initialized
INFO - 2024-09-09 17:27:33 --> URI Class Initialized
DEBUG - 2024-09-09 17:27:33 --> No URI present. Default controller set.
INFO - 2024-09-09 17:27:33 --> Router Class Initialized
INFO - 2024-09-09 17:27:33 --> Output Class Initialized
INFO - 2024-09-09 17:27:33 --> Security Class Initialized
DEBUG - 2024-09-09 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 17:27:33 --> Input Class Initialized
INFO - 2024-09-09 17:27:33 --> Language Class Initialized
INFO - 2024-09-09 17:27:33 --> Loader Class Initialized
INFO - 2024-09-09 17:27:33 --> Helper loaded: url_helper
INFO - 2024-09-09 17:27:33 --> Helper loaded: file_helper
INFO - 2024-09-09 17:27:33 --> Helper loaded: security_helper
INFO - 2024-09-09 17:27:33 --> Helper loaded: wpu_helper
INFO - 2024-09-09 17:27:33 --> Database Driver Class Initialized
INFO - 2024-09-09 17:27:33 --> Email Class Initialized
DEBUG - 2024-09-09 17:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 17:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 17:27:33 --> Helper loaded: form_helper
INFO - 2024-09-09 17:27:33 --> Form Validation Class Initialized
INFO - 2024-09-09 17:27:33 --> Controller Class Initialized
DEBUG - 2024-09-09 17:27:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 17:27:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 17:27:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 17:27:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 17:27:33 --> Final output sent to browser
DEBUG - 2024-09-09 17:27:33 --> Total execution time: 0.2313
INFO - 2024-09-09 17:47:42 --> Config Class Initialized
INFO - 2024-09-09 17:47:42 --> Hooks Class Initialized
DEBUG - 2024-09-09 17:47:42 --> UTF-8 Support Enabled
INFO - 2024-09-09 17:47:42 --> Utf8 Class Initialized
INFO - 2024-09-09 17:47:42 --> URI Class Initialized
DEBUG - 2024-09-09 17:47:42 --> No URI present. Default controller set.
INFO - 2024-09-09 17:47:42 --> Router Class Initialized
INFO - 2024-09-09 17:47:42 --> Output Class Initialized
INFO - 2024-09-09 17:47:42 --> Security Class Initialized
DEBUG - 2024-09-09 17:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 17:47:42 --> Input Class Initialized
INFO - 2024-09-09 17:47:42 --> Language Class Initialized
INFO - 2024-09-09 17:47:42 --> Loader Class Initialized
INFO - 2024-09-09 17:47:42 --> Helper loaded: url_helper
INFO - 2024-09-09 17:47:42 --> Helper loaded: file_helper
INFO - 2024-09-09 17:47:42 --> Helper loaded: security_helper
INFO - 2024-09-09 17:47:42 --> Helper loaded: wpu_helper
INFO - 2024-09-09 17:47:42 --> Database Driver Class Initialized
INFO - 2024-09-09 17:47:42 --> Email Class Initialized
DEBUG - 2024-09-09 17:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 17:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 17:47:42 --> Helper loaded: form_helper
INFO - 2024-09-09 17:47:42 --> Form Validation Class Initialized
INFO - 2024-09-09 17:47:42 --> Controller Class Initialized
DEBUG - 2024-09-09 17:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 17:47:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 17:47:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 17:47:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 17:47:42 --> Final output sent to browser
DEBUG - 2024-09-09 17:47:42 --> Total execution time: 0.2281
INFO - 2024-09-09 18:16:57 --> Config Class Initialized
INFO - 2024-09-09 18:16:57 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:16:57 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:16:57 --> Utf8 Class Initialized
INFO - 2024-09-09 18:16:57 --> URI Class Initialized
DEBUG - 2024-09-09 18:16:57 --> No URI present. Default controller set.
INFO - 2024-09-09 18:16:57 --> Router Class Initialized
INFO - 2024-09-09 18:16:57 --> Output Class Initialized
INFO - 2024-09-09 18:16:57 --> Security Class Initialized
DEBUG - 2024-09-09 18:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:16:57 --> Input Class Initialized
INFO - 2024-09-09 18:16:57 --> Language Class Initialized
INFO - 2024-09-09 18:16:57 --> Loader Class Initialized
INFO - 2024-09-09 18:16:57 --> Helper loaded: url_helper
INFO - 2024-09-09 18:16:57 --> Helper loaded: file_helper
INFO - 2024-09-09 18:16:57 --> Helper loaded: security_helper
INFO - 2024-09-09 18:16:57 --> Helper loaded: wpu_helper
INFO - 2024-09-09 18:16:57 --> Database Driver Class Initialized
INFO - 2024-09-09 18:16:57 --> Email Class Initialized
DEBUG - 2024-09-09 18:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 18:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:16:57 --> Helper loaded: form_helper
INFO - 2024-09-09 18:16:57 --> Form Validation Class Initialized
INFO - 2024-09-09 18:16:57 --> Controller Class Initialized
DEBUG - 2024-09-09 18:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 18:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 18:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 18:16:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 18:16:57 --> Final output sent to browser
DEBUG - 2024-09-09 18:16:57 --> Total execution time: 0.2397
INFO - 2024-09-09 18:32:32 --> Config Class Initialized
INFO - 2024-09-09 18:32:32 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:32:32 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:32:32 --> Utf8 Class Initialized
INFO - 2024-09-09 18:32:32 --> URI Class Initialized
DEBUG - 2024-09-09 18:32:32 --> No URI present. Default controller set.
INFO - 2024-09-09 18:32:32 --> Router Class Initialized
INFO - 2024-09-09 18:32:32 --> Output Class Initialized
INFO - 2024-09-09 18:32:32 --> Security Class Initialized
DEBUG - 2024-09-09 18:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:32:32 --> Input Class Initialized
INFO - 2024-09-09 18:32:32 --> Language Class Initialized
INFO - 2024-09-09 18:32:32 --> Loader Class Initialized
INFO - 2024-09-09 18:32:32 --> Helper loaded: url_helper
INFO - 2024-09-09 18:32:32 --> Helper loaded: file_helper
INFO - 2024-09-09 18:32:32 --> Helper loaded: security_helper
INFO - 2024-09-09 18:32:32 --> Helper loaded: wpu_helper
INFO - 2024-09-09 18:32:32 --> Database Driver Class Initialized
INFO - 2024-09-09 18:32:33 --> Email Class Initialized
DEBUG - 2024-09-09 18:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 18:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:32:33 --> Helper loaded: form_helper
INFO - 2024-09-09 18:32:33 --> Form Validation Class Initialized
INFO - 2024-09-09 18:32:33 --> Controller Class Initialized
DEBUG - 2024-09-09 18:32:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 18:32:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 18:32:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 18:32:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 18:32:33 --> Final output sent to browser
DEBUG - 2024-09-09 18:32:33 --> Total execution time: 0.2211
INFO - 2024-09-09 18:33:02 --> Config Class Initialized
INFO - 2024-09-09 18:33:02 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:33:02 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:33:02 --> Utf8 Class Initialized
INFO - 2024-09-09 18:33:02 --> URI Class Initialized
DEBUG - 2024-09-09 18:33:02 --> No URI present. Default controller set.
INFO - 2024-09-09 18:33:02 --> Router Class Initialized
INFO - 2024-09-09 18:33:02 --> Output Class Initialized
INFO - 2024-09-09 18:33:02 --> Security Class Initialized
DEBUG - 2024-09-09 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:33:02 --> Input Class Initialized
INFO - 2024-09-09 18:33:02 --> Language Class Initialized
INFO - 2024-09-09 18:33:02 --> Loader Class Initialized
INFO - 2024-09-09 18:33:02 --> Helper loaded: url_helper
INFO - 2024-09-09 18:33:02 --> Helper loaded: file_helper
INFO - 2024-09-09 18:33:02 --> Helper loaded: security_helper
INFO - 2024-09-09 18:33:02 --> Helper loaded: wpu_helper
INFO - 2024-09-09 18:33:02 --> Database Driver Class Initialized
INFO - 2024-09-09 18:33:03 --> Email Class Initialized
DEBUG - 2024-09-09 18:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 18:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:33:03 --> Helper loaded: form_helper
INFO - 2024-09-09 18:33:03 --> Form Validation Class Initialized
INFO - 2024-09-09 18:33:03 --> Controller Class Initialized
DEBUG - 2024-09-09 18:33:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 18:33:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 18:33:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 18:33:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 18:33:03 --> Final output sent to browser
DEBUG - 2024-09-09 18:33:03 --> Total execution time: 0.2296
INFO - 2024-09-09 18:46:26 --> Config Class Initialized
INFO - 2024-09-09 18:46:26 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:46:26 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:46:26 --> Utf8 Class Initialized
INFO - 2024-09-09 18:46:26 --> URI Class Initialized
DEBUG - 2024-09-09 18:46:26 --> No URI present. Default controller set.
INFO - 2024-09-09 18:46:26 --> Router Class Initialized
INFO - 2024-09-09 18:46:26 --> Output Class Initialized
INFO - 2024-09-09 18:46:26 --> Security Class Initialized
DEBUG - 2024-09-09 18:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:46:26 --> Input Class Initialized
INFO - 2024-09-09 18:46:26 --> Language Class Initialized
INFO - 2024-09-09 18:46:26 --> Loader Class Initialized
INFO - 2024-09-09 18:46:26 --> Helper loaded: url_helper
INFO - 2024-09-09 18:46:26 --> Helper loaded: file_helper
INFO - 2024-09-09 18:46:26 --> Helper loaded: security_helper
INFO - 2024-09-09 18:46:26 --> Helper loaded: wpu_helper
INFO - 2024-09-09 18:46:26 --> Database Driver Class Initialized
INFO - 2024-09-09 18:46:27 --> Email Class Initialized
DEBUG - 2024-09-09 18:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 18:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:46:27 --> Helper loaded: form_helper
INFO - 2024-09-09 18:46:27 --> Form Validation Class Initialized
INFO - 2024-09-09 18:46:27 --> Controller Class Initialized
DEBUG - 2024-09-09 18:46:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 18:46:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 18:46:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 18:46:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 18:46:27 --> Final output sent to browser
DEBUG - 2024-09-09 18:46:27 --> Total execution time: 0.2340
INFO - 2024-09-09 19:17:46 --> Config Class Initialized
INFO - 2024-09-09 19:17:46 --> Hooks Class Initialized
DEBUG - 2024-09-09 19:17:46 --> UTF-8 Support Enabled
INFO - 2024-09-09 19:17:46 --> Utf8 Class Initialized
INFO - 2024-09-09 19:17:46 --> URI Class Initialized
DEBUG - 2024-09-09 19:17:46 --> No URI present. Default controller set.
INFO - 2024-09-09 19:17:46 --> Router Class Initialized
INFO - 2024-09-09 19:17:46 --> Output Class Initialized
INFO - 2024-09-09 19:17:46 --> Security Class Initialized
DEBUG - 2024-09-09 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 19:17:46 --> Input Class Initialized
INFO - 2024-09-09 19:17:46 --> Language Class Initialized
INFO - 2024-09-09 19:17:46 --> Loader Class Initialized
INFO - 2024-09-09 19:17:46 --> Helper loaded: url_helper
INFO - 2024-09-09 19:17:46 --> Helper loaded: file_helper
INFO - 2024-09-09 19:17:46 --> Helper loaded: security_helper
INFO - 2024-09-09 19:17:46 --> Helper loaded: wpu_helper
INFO - 2024-09-09 19:17:46 --> Database Driver Class Initialized
INFO - 2024-09-09 19:17:47 --> Email Class Initialized
DEBUG - 2024-09-09 19:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 19:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 19:17:47 --> Helper loaded: form_helper
INFO - 2024-09-09 19:17:47 --> Form Validation Class Initialized
INFO - 2024-09-09 19:17:47 --> Controller Class Initialized
DEBUG - 2024-09-09 19:17:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 19:17:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 19:17:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 19:17:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 19:17:47 --> Final output sent to browser
DEBUG - 2024-09-09 19:17:47 --> Total execution time: 0.2112
INFO - 2024-09-09 19:46:06 --> Config Class Initialized
INFO - 2024-09-09 19:46:06 --> Hooks Class Initialized
DEBUG - 2024-09-09 19:46:06 --> UTF-8 Support Enabled
INFO - 2024-09-09 19:46:06 --> Utf8 Class Initialized
INFO - 2024-09-09 19:46:06 --> URI Class Initialized
DEBUG - 2024-09-09 19:46:06 --> No URI present. Default controller set.
INFO - 2024-09-09 19:46:06 --> Router Class Initialized
INFO - 2024-09-09 19:46:06 --> Output Class Initialized
INFO - 2024-09-09 19:46:06 --> Security Class Initialized
DEBUG - 2024-09-09 19:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 19:46:06 --> Input Class Initialized
INFO - 2024-09-09 19:46:06 --> Language Class Initialized
INFO - 2024-09-09 19:46:06 --> Loader Class Initialized
INFO - 2024-09-09 19:46:06 --> Helper loaded: url_helper
INFO - 2024-09-09 19:46:06 --> Helper loaded: file_helper
INFO - 2024-09-09 19:46:06 --> Helper loaded: security_helper
INFO - 2024-09-09 19:46:06 --> Helper loaded: wpu_helper
INFO - 2024-09-09 19:46:06 --> Database Driver Class Initialized
INFO - 2024-09-09 19:46:07 --> Email Class Initialized
DEBUG - 2024-09-09 19:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 19:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 19:46:07 --> Helper loaded: form_helper
INFO - 2024-09-09 19:46:07 --> Form Validation Class Initialized
INFO - 2024-09-09 19:46:07 --> Controller Class Initialized
DEBUG - 2024-09-09 19:46:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 19:46:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 19:46:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 19:46:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 19:46:07 --> Final output sent to browser
DEBUG - 2024-09-09 19:46:07 --> Total execution time: 0.2391
INFO - 2024-09-09 20:19:09 --> Config Class Initialized
INFO - 2024-09-09 20:19:09 --> Hooks Class Initialized
DEBUG - 2024-09-09 20:19:09 --> UTF-8 Support Enabled
INFO - 2024-09-09 20:19:09 --> Utf8 Class Initialized
INFO - 2024-09-09 20:19:09 --> URI Class Initialized
DEBUG - 2024-09-09 20:19:09 --> No URI present. Default controller set.
INFO - 2024-09-09 20:19:09 --> Router Class Initialized
INFO - 2024-09-09 20:19:09 --> Output Class Initialized
INFO - 2024-09-09 20:19:09 --> Security Class Initialized
DEBUG - 2024-09-09 20:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 20:19:09 --> Input Class Initialized
INFO - 2024-09-09 20:19:09 --> Language Class Initialized
INFO - 2024-09-09 20:19:09 --> Loader Class Initialized
INFO - 2024-09-09 20:19:09 --> Helper loaded: url_helper
INFO - 2024-09-09 20:19:09 --> Helper loaded: file_helper
INFO - 2024-09-09 20:19:09 --> Helper loaded: security_helper
INFO - 2024-09-09 20:19:09 --> Helper loaded: wpu_helper
INFO - 2024-09-09 20:19:09 --> Database Driver Class Initialized
INFO - 2024-09-09 20:19:09 --> Email Class Initialized
DEBUG - 2024-09-09 20:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 20:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 20:19:09 --> Helper loaded: form_helper
INFO - 2024-09-09 20:19:09 --> Form Validation Class Initialized
INFO - 2024-09-09 20:19:09 --> Controller Class Initialized
DEBUG - 2024-09-09 20:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 20:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 20:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 20:19:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 20:19:09 --> Final output sent to browser
DEBUG - 2024-09-09 20:19:09 --> Total execution time: 0.2202
INFO - 2024-09-09 20:25:22 --> Config Class Initialized
INFO - 2024-09-09 20:25:22 --> Hooks Class Initialized
DEBUG - 2024-09-09 20:25:22 --> UTF-8 Support Enabled
INFO - 2024-09-09 20:25:22 --> Utf8 Class Initialized
INFO - 2024-09-09 20:25:22 --> URI Class Initialized
DEBUG - 2024-09-09 20:25:22 --> No URI present. Default controller set.
INFO - 2024-09-09 20:25:22 --> Router Class Initialized
INFO - 2024-09-09 20:25:22 --> Output Class Initialized
INFO - 2024-09-09 20:25:22 --> Security Class Initialized
DEBUG - 2024-09-09 20:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 20:25:22 --> Input Class Initialized
INFO - 2024-09-09 20:25:22 --> Language Class Initialized
INFO - 2024-09-09 20:25:22 --> Loader Class Initialized
INFO - 2024-09-09 20:25:22 --> Helper loaded: url_helper
INFO - 2024-09-09 20:25:22 --> Helper loaded: file_helper
INFO - 2024-09-09 20:25:22 --> Helper loaded: security_helper
INFO - 2024-09-09 20:25:22 --> Helper loaded: wpu_helper
INFO - 2024-09-09 20:25:22 --> Database Driver Class Initialized
INFO - 2024-09-09 20:25:23 --> Email Class Initialized
DEBUG - 2024-09-09 20:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 20:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 20:25:23 --> Helper loaded: form_helper
INFO - 2024-09-09 20:25:23 --> Form Validation Class Initialized
INFO - 2024-09-09 20:25:23 --> Controller Class Initialized
DEBUG - 2024-09-09 20:25:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 20:25:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 20:25:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 20:25:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 20:25:23 --> Final output sent to browser
DEBUG - 2024-09-09 20:25:23 --> Total execution time: 0.2316
INFO - 2024-09-09 20:46:05 --> Config Class Initialized
INFO - 2024-09-09 20:46:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 20:46:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 20:46:05 --> Utf8 Class Initialized
INFO - 2024-09-09 20:46:05 --> URI Class Initialized
DEBUG - 2024-09-09 20:46:05 --> No URI present. Default controller set.
INFO - 2024-09-09 20:46:05 --> Router Class Initialized
INFO - 2024-09-09 20:46:05 --> Output Class Initialized
INFO - 2024-09-09 20:46:05 --> Security Class Initialized
DEBUG - 2024-09-09 20:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 20:46:05 --> Input Class Initialized
INFO - 2024-09-09 20:46:05 --> Language Class Initialized
INFO - 2024-09-09 20:46:05 --> Loader Class Initialized
INFO - 2024-09-09 20:46:05 --> Helper loaded: url_helper
INFO - 2024-09-09 20:46:05 --> Helper loaded: file_helper
INFO - 2024-09-09 20:46:05 --> Helper loaded: security_helper
INFO - 2024-09-09 20:46:05 --> Helper loaded: wpu_helper
INFO - 2024-09-09 20:46:05 --> Database Driver Class Initialized
INFO - 2024-09-09 20:46:06 --> Email Class Initialized
DEBUG - 2024-09-09 20:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 20:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 20:46:06 --> Helper loaded: form_helper
INFO - 2024-09-09 20:46:06 --> Form Validation Class Initialized
INFO - 2024-09-09 20:46:06 --> Controller Class Initialized
DEBUG - 2024-09-09 20:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 20:46:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 20:46:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 20:46:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 20:46:06 --> Final output sent to browser
DEBUG - 2024-09-09 20:46:06 --> Total execution time: 0.2282
INFO - 2024-09-09 20:54:46 --> Config Class Initialized
INFO - 2024-09-09 20:54:46 --> Hooks Class Initialized
DEBUG - 2024-09-09 20:54:46 --> UTF-8 Support Enabled
INFO - 2024-09-09 20:54:46 --> Utf8 Class Initialized
INFO - 2024-09-09 20:54:46 --> URI Class Initialized
DEBUG - 2024-09-09 20:54:46 --> No URI present. Default controller set.
INFO - 2024-09-09 20:54:46 --> Router Class Initialized
INFO - 2024-09-09 20:54:46 --> Output Class Initialized
INFO - 2024-09-09 20:54:47 --> Security Class Initialized
DEBUG - 2024-09-09 20:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 20:54:47 --> Input Class Initialized
INFO - 2024-09-09 20:54:47 --> Language Class Initialized
INFO - 2024-09-09 20:54:47 --> Loader Class Initialized
INFO - 2024-09-09 20:54:47 --> Helper loaded: url_helper
INFO - 2024-09-09 20:54:47 --> Helper loaded: file_helper
INFO - 2024-09-09 20:54:47 --> Helper loaded: security_helper
INFO - 2024-09-09 20:54:47 --> Helper loaded: wpu_helper
INFO - 2024-09-09 20:54:47 --> Database Driver Class Initialized
INFO - 2024-09-09 20:54:47 --> Email Class Initialized
DEBUG - 2024-09-09 20:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 20:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 20:54:47 --> Helper loaded: form_helper
INFO - 2024-09-09 20:54:47 --> Form Validation Class Initialized
INFO - 2024-09-09 20:54:47 --> Controller Class Initialized
DEBUG - 2024-09-09 20:54:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 20:54:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 20:54:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 20:54:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 20:54:47 --> Final output sent to browser
DEBUG - 2024-09-09 20:54:47 --> Total execution time: 0.2221
INFO - 2024-09-09 21:19:05 --> Config Class Initialized
INFO - 2024-09-09 21:19:05 --> Hooks Class Initialized
DEBUG - 2024-09-09 21:19:05 --> UTF-8 Support Enabled
INFO - 2024-09-09 21:19:05 --> Utf8 Class Initialized
INFO - 2024-09-09 21:19:05 --> URI Class Initialized
DEBUG - 2024-09-09 21:19:05 --> No URI present. Default controller set.
INFO - 2024-09-09 21:19:05 --> Router Class Initialized
INFO - 2024-09-09 21:19:05 --> Output Class Initialized
INFO - 2024-09-09 21:19:05 --> Security Class Initialized
DEBUG - 2024-09-09 21:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 21:19:05 --> Input Class Initialized
INFO - 2024-09-09 21:19:05 --> Language Class Initialized
INFO - 2024-09-09 21:19:05 --> Loader Class Initialized
INFO - 2024-09-09 21:19:05 --> Helper loaded: url_helper
INFO - 2024-09-09 21:19:05 --> Helper loaded: file_helper
INFO - 2024-09-09 21:19:05 --> Helper loaded: security_helper
INFO - 2024-09-09 21:19:05 --> Helper loaded: wpu_helper
INFO - 2024-09-09 21:19:05 --> Database Driver Class Initialized
INFO - 2024-09-09 21:19:06 --> Email Class Initialized
DEBUG - 2024-09-09 21:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 21:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 21:19:06 --> Helper loaded: form_helper
INFO - 2024-09-09 21:19:06 --> Form Validation Class Initialized
INFO - 2024-09-09 21:19:06 --> Controller Class Initialized
DEBUG - 2024-09-09 21:19:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 21:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 21:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 21:19:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 21:19:06 --> Final output sent to browser
DEBUG - 2024-09-09 21:19:06 --> Total execution time: 0.5711
INFO - 2024-09-09 21:45:07 --> Config Class Initialized
INFO - 2024-09-09 21:45:07 --> Hooks Class Initialized
DEBUG - 2024-09-09 21:45:07 --> UTF-8 Support Enabled
INFO - 2024-09-09 21:45:07 --> Utf8 Class Initialized
INFO - 2024-09-09 21:45:07 --> URI Class Initialized
DEBUG - 2024-09-09 21:45:07 --> No URI present. Default controller set.
INFO - 2024-09-09 21:45:07 --> Router Class Initialized
INFO - 2024-09-09 21:45:07 --> Output Class Initialized
INFO - 2024-09-09 21:45:07 --> Security Class Initialized
DEBUG - 2024-09-09 21:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 21:45:07 --> Input Class Initialized
INFO - 2024-09-09 21:45:07 --> Language Class Initialized
INFO - 2024-09-09 21:45:07 --> Loader Class Initialized
INFO - 2024-09-09 21:45:07 --> Helper loaded: url_helper
INFO - 2024-09-09 21:45:07 --> Helper loaded: file_helper
INFO - 2024-09-09 21:45:07 --> Helper loaded: security_helper
INFO - 2024-09-09 21:45:07 --> Helper loaded: wpu_helper
INFO - 2024-09-09 21:45:07 --> Database Driver Class Initialized
INFO - 2024-09-09 21:45:08 --> Email Class Initialized
DEBUG - 2024-09-09 21:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 21:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 21:45:08 --> Helper loaded: form_helper
INFO - 2024-09-09 21:45:08 --> Form Validation Class Initialized
INFO - 2024-09-09 21:45:08 --> Controller Class Initialized
DEBUG - 2024-09-09 21:45:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 21:45:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 21:45:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 21:45:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 21:45:08 --> Final output sent to browser
DEBUG - 2024-09-09 21:45:08 --> Total execution time: 0.4588
INFO - 2024-09-09 22:15:20 --> Config Class Initialized
INFO - 2024-09-09 22:15:20 --> Hooks Class Initialized
DEBUG - 2024-09-09 22:15:20 --> UTF-8 Support Enabled
INFO - 2024-09-09 22:15:20 --> Utf8 Class Initialized
INFO - 2024-09-09 22:15:20 --> URI Class Initialized
DEBUG - 2024-09-09 22:15:20 --> No URI present. Default controller set.
INFO - 2024-09-09 22:15:20 --> Router Class Initialized
INFO - 2024-09-09 22:15:20 --> Output Class Initialized
INFO - 2024-09-09 22:15:20 --> Security Class Initialized
DEBUG - 2024-09-09 22:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 22:15:20 --> Input Class Initialized
INFO - 2024-09-09 22:15:20 --> Language Class Initialized
INFO - 2024-09-09 22:15:20 --> Loader Class Initialized
INFO - 2024-09-09 22:15:20 --> Helper loaded: url_helper
INFO - 2024-09-09 22:15:20 --> Helper loaded: file_helper
INFO - 2024-09-09 22:15:20 --> Helper loaded: security_helper
INFO - 2024-09-09 22:15:20 --> Helper loaded: wpu_helper
INFO - 2024-09-09 22:15:20 --> Database Driver Class Initialized
INFO - 2024-09-09 22:15:21 --> Email Class Initialized
DEBUG - 2024-09-09 22:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 22:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 22:15:21 --> Helper loaded: form_helper
INFO - 2024-09-09 22:15:21 --> Form Validation Class Initialized
INFO - 2024-09-09 22:15:21 --> Controller Class Initialized
DEBUG - 2024-09-09 22:15:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 22:15:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 22:15:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 22:15:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 22:15:21 --> Final output sent to browser
DEBUG - 2024-09-09 22:15:21 --> Total execution time: 0.2480
INFO - 2024-09-09 22:46:09 --> Config Class Initialized
INFO - 2024-09-09 22:46:09 --> Hooks Class Initialized
DEBUG - 2024-09-09 22:46:09 --> UTF-8 Support Enabled
INFO - 2024-09-09 22:46:09 --> Utf8 Class Initialized
INFO - 2024-09-09 22:46:09 --> URI Class Initialized
DEBUG - 2024-09-09 22:46:09 --> No URI present. Default controller set.
INFO - 2024-09-09 22:46:09 --> Router Class Initialized
INFO - 2024-09-09 22:46:09 --> Output Class Initialized
INFO - 2024-09-09 22:46:09 --> Security Class Initialized
DEBUG - 2024-09-09 22:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 22:46:09 --> Input Class Initialized
INFO - 2024-09-09 22:46:09 --> Language Class Initialized
INFO - 2024-09-09 22:46:09 --> Loader Class Initialized
INFO - 2024-09-09 22:46:09 --> Helper loaded: url_helper
INFO - 2024-09-09 22:46:09 --> Helper loaded: file_helper
INFO - 2024-09-09 22:46:09 --> Helper loaded: security_helper
INFO - 2024-09-09 22:46:09 --> Helper loaded: wpu_helper
INFO - 2024-09-09 22:46:09 --> Database Driver Class Initialized
INFO - 2024-09-09 22:46:09 --> Email Class Initialized
DEBUG - 2024-09-09 22:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 22:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 22:46:09 --> Helper loaded: form_helper
INFO - 2024-09-09 22:46:09 --> Form Validation Class Initialized
INFO - 2024-09-09 22:46:09 --> Controller Class Initialized
DEBUG - 2024-09-09 22:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 22:46:09 --> Final output sent to browser
DEBUG - 2024-09-09 22:46:09 --> Total execution time: 0.2247
INFO - 2024-09-09 23:17:31 --> Config Class Initialized
INFO - 2024-09-09 23:17:31 --> Hooks Class Initialized
DEBUG - 2024-09-09 23:17:31 --> UTF-8 Support Enabled
INFO - 2024-09-09 23:17:31 --> Utf8 Class Initialized
INFO - 2024-09-09 23:17:31 --> URI Class Initialized
DEBUG - 2024-09-09 23:17:31 --> No URI present. Default controller set.
INFO - 2024-09-09 23:17:31 --> Router Class Initialized
INFO - 2024-09-09 23:17:31 --> Output Class Initialized
INFO - 2024-09-09 23:17:31 --> Security Class Initialized
DEBUG - 2024-09-09 23:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 23:17:31 --> Input Class Initialized
INFO - 2024-09-09 23:17:31 --> Language Class Initialized
INFO - 2024-09-09 23:17:31 --> Loader Class Initialized
INFO - 2024-09-09 23:17:31 --> Helper loaded: url_helper
INFO - 2024-09-09 23:17:31 --> Helper loaded: file_helper
INFO - 2024-09-09 23:17:31 --> Helper loaded: security_helper
INFO - 2024-09-09 23:17:31 --> Helper loaded: wpu_helper
INFO - 2024-09-09 23:17:31 --> Database Driver Class Initialized
INFO - 2024-09-09 23:17:31 --> Email Class Initialized
DEBUG - 2024-09-09 23:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 23:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 23:17:31 --> Helper loaded: form_helper
INFO - 2024-09-09 23:17:31 --> Form Validation Class Initialized
INFO - 2024-09-09 23:17:31 --> Controller Class Initialized
DEBUG - 2024-09-09 23:17:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 23:17:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 23:17:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 23:17:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 23:17:31 --> Final output sent to browser
DEBUG - 2024-09-09 23:17:31 --> Total execution time: 0.2374
INFO - 2024-09-09 23:28:02 --> Config Class Initialized
INFO - 2024-09-09 23:28:02 --> Hooks Class Initialized
DEBUG - 2024-09-09 23:28:02 --> UTF-8 Support Enabled
INFO - 2024-09-09 23:28:02 --> Utf8 Class Initialized
INFO - 2024-09-09 23:28:02 --> URI Class Initialized
DEBUG - 2024-09-09 23:28:02 --> No URI present. Default controller set.
INFO - 2024-09-09 23:28:02 --> Router Class Initialized
INFO - 2024-09-09 23:28:02 --> Output Class Initialized
INFO - 2024-09-09 23:28:02 --> Security Class Initialized
DEBUG - 2024-09-09 23:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 23:28:02 --> Input Class Initialized
INFO - 2024-09-09 23:28:02 --> Language Class Initialized
INFO - 2024-09-09 23:28:02 --> Loader Class Initialized
INFO - 2024-09-09 23:28:02 --> Helper loaded: url_helper
INFO - 2024-09-09 23:28:02 --> Helper loaded: file_helper
INFO - 2024-09-09 23:28:02 --> Helper loaded: security_helper
INFO - 2024-09-09 23:28:02 --> Helper loaded: wpu_helper
INFO - 2024-09-09 23:28:02 --> Database Driver Class Initialized
INFO - 2024-09-09 23:28:02 --> Email Class Initialized
DEBUG - 2024-09-09 23:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 23:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 23:28:02 --> Helper loaded: form_helper
INFO - 2024-09-09 23:28:02 --> Form Validation Class Initialized
INFO - 2024-09-09 23:28:02 --> Controller Class Initialized
DEBUG - 2024-09-09 23:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 23:28:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 23:28:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 23:28:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 23:28:02 --> Final output sent to browser
DEBUG - 2024-09-09 23:28:02 --> Total execution time: 0.2568
INFO - 2024-09-09 23:47:40 --> Config Class Initialized
INFO - 2024-09-09 23:47:40 --> Hooks Class Initialized
DEBUG - 2024-09-09 23:47:40 --> UTF-8 Support Enabled
INFO - 2024-09-09 23:47:40 --> Utf8 Class Initialized
INFO - 2024-09-09 23:47:40 --> URI Class Initialized
DEBUG - 2024-09-09 23:47:40 --> No URI present. Default controller set.
INFO - 2024-09-09 23:47:40 --> Router Class Initialized
INFO - 2024-09-09 23:47:40 --> Output Class Initialized
INFO - 2024-09-09 23:47:40 --> Security Class Initialized
DEBUG - 2024-09-09 23:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 23:47:40 --> Input Class Initialized
INFO - 2024-09-09 23:47:40 --> Language Class Initialized
INFO - 2024-09-09 23:47:40 --> Loader Class Initialized
INFO - 2024-09-09 23:47:40 --> Helper loaded: url_helper
INFO - 2024-09-09 23:47:40 --> Helper loaded: file_helper
INFO - 2024-09-09 23:47:40 --> Helper loaded: security_helper
INFO - 2024-09-09 23:47:40 --> Helper loaded: wpu_helper
INFO - 2024-09-09 23:47:40 --> Database Driver Class Initialized
INFO - 2024-09-09 23:47:41 --> Email Class Initialized
DEBUG - 2024-09-09 23:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-09 23:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 23:47:41 --> Helper loaded: form_helper
INFO - 2024-09-09 23:47:41 --> Form Validation Class Initialized
INFO - 2024-09-09 23:47:41 --> Controller Class Initialized
DEBUG - 2024-09-09 23:47:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-09 23:47:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-09 23:47:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-09 23:47:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-09 23:47:41 --> Final output sent to browser
DEBUG - 2024-09-09 23:47:41 --> Total execution time: 0.2204
