<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-04 14:40:49 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:43:43 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:49:36 --> Severity: error --> Exception: Too few arguments to function Admin::editpesanan(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 485
ERROR - 2024-02-04 14:52:05 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:54:33 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:54:45 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:55:02 --> Severity: error --> Exception: Call to undefined method Pesanan_model::update() C:\xampp\htdocs\simba\application\controllers\Admin.php 496
ERROR - 2024-02-04 14:55:20 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:56:58 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:58:08 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:58:15 --> 404 Page Not Found: 
ERROR - 2024-02-04 14:58:42 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:00:21 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:03:57 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:04:50 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:05:27 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:05:29 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:05:33 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:12:54 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:13:22 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:14:01 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:14:37 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:17:14 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 15:17:41 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-04 15:17:56 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 33
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-04 15:24:57 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 33
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-04 15:25:06 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 68
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 78
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 89
ERROR - 2024-02-04 15:25:24 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 102
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 15:25:27 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 15:25:27 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:25:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\simba\system\core\Exceptions.php:271) C:\xampp\htdocs\simba\system\core\Common.php 570
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 15:25:39 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:25:47 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:25:47 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 15:25:47 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:26:14 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:26:15 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:26:19 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:26:19 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:26:22 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:26:34 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 189
ERROR - 2024-02-04 15:26:34 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 15:27:06 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 15:28:04 --> 404 Page Not Found: 
ERROR - 2024-02-04 15:28:06 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:13:28 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:13:40 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:14:14 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:23:56 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:24:45 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:24:59 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:07 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:12 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:15 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:21 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:25 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:28 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:31 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:35 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:40 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:44 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:49 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:25:53 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:26:02 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:26:12 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:26:13 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:29:44 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:29:58 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\pengurus\e_pesanan.php 35
ERROR - 2024-02-04 17:30:05 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:30:05 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:30:05 --> 404 Page Not Found: 
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 17:30:09 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\pengurus\e_pesanan.php 35
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:30:10 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\pengurus\e_pesanan.php 35
ERROR - 2024-02-04 17:30:20 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:30:20 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 17:30:24 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\pengurus\e_pesanan.php 35
ERROR - 2024-02-04 17:30:29 --> Severity: Notice --> Undefined variable: id_permintaan C:\xampp\htdocs\simba\application\controllers\Pengurus.php 307
ERROR - 2024-02-04 17:30:29 --> Severity: Notice --> Undefined variable: JBarang C:\xampp\htdocs\simba\application\views\pengurus\t_pesanan.php 34
ERROR - 2024-02-04 17:30:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\simba\application\views\pengurus\t_pesanan.php 34
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Permintaan_model.php 111
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: surat_permintaan C:\xampp\htdocs\simba\application\models\Permintaan_model.php 112
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Permintaan_model.php 113
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Permintaan_model.php 114
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Permintaan_model.php 115
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Permintaan_model.php 116
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: rincian_permintaan C:\xampp\htdocs\simba\application\models\Permintaan_model.php 117
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Permintaan_model.php 122
ERROR - 2024-02-04 17:30:53 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Permintaan_model.php 124
ERROR - 2024-02-04 23:30:19 --> Severity: Notice --> Undefined variable: total_faktur C:\xampp\htdocs\simba\application\controllers\Admin.php 31
ERROR - 2024-02-04 23:30:19 --> Severity: Notice --> Undefined index: nama_user C:\xampp\htdocs\simba\application\views\admin\dashboard.php 13
ERROR - 2024-02-04 23:30:29 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
ERROR - 2024-02-04 23:30:32 --> 404 Page Not Found: 
ERROR - 2024-02-04 23:30:34 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:32:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:32:05 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:32:05 --> Total execution time: 0.0494
DEBUG - 2024-02-04 23:32:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:11 --> Total execution time: 0.0520
DEBUG - 2024-02-04 23:32:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:32:12 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:32:12 --> Total execution time: 0.0754
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0487
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0576
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0642
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0662
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0774
DEBUG - 2024-02-04 23:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:14 --> Total execution time: 0.0883
DEBUG - 2024-02-04 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:32:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:32:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
DEBUG - 2024-02-04 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:16 --> Total execution time: 0.0577
DEBUG - 2024-02-04 23:32:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:32:19 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:32:19 --> Total execution time: 0.0655
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0431
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0501
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0573
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0650
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0732
DEBUG - 2024-02-04 23:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:21 --> Total execution time: 0.0823
DEBUG - 2024-02-04 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:32:32 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:32:32 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
ERROR - 2024-02-04 23:32:32 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
DEBUG - 2024-02-04 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:32:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:32:32 --> Total execution time: 0.0392
DEBUG - 2024-02-04 23:38:00 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:00 --> Total execution time: 0.0420
DEBUG - 2024-02-04 23:38:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:38:02 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:38:02 --> Total execution time: 0.0691
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0438
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0527
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0603
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0685
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0761
DEBUG - 2024-02-04 23:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:04 --> Total execution time: 0.0875
DEBUG - 2024-02-04 23:38:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 23:38:51 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:38:51 --> Total execution time: 0.0654
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0454
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0525
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0600
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0674
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0764
DEBUG - 2024-02-04 23:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:38:55 --> Total execution time: 0.0859
DEBUG - 2024-02-04 23:38:56 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:38:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:38:56 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:38:56 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
ERROR - 2024-02-04 23:38:56 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:41:17 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:41:17 --> Total execution time: 0.0744
DEBUG - 2024-02-04 23:41:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:41:18 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:41:18 --> Total execution time: 0.0783
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0450
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0591
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0631
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0741
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0834
DEBUG - 2024-02-04 23:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:41:19 --> Total execution time: 0.0937
DEBUG - 2024-02-04 23:41:20 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:41:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:41:20 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:41:20 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:42:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-04 23:42:13 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
DEBUG - 2024-02-04 23:42:13 --> Total execution time: 0.0683
DEBUG - 2024-02-04 23:42:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-04 23:42:14 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
DEBUG - 2024-02-04 23:42:14 --> Total execution time: 0.0753
DEBUG - 2024-02-04 23:42:23 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:42:23 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:42:23 --> Total execution time: 0.0683
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0442
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0511
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0602
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0680
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0762
DEBUG - 2024-02-04 23:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:42:46 --> Total execution time: 0.0845
DEBUG - 2024-02-04 23:42:48 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:42:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:42:48 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:42:48 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:44:09 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:09 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:09 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:44:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:11 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:11 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:44:11 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:11 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:11 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:44:11 --> Total execution time: 0.0523
DEBUG - 2024-02-04 23:44:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:12 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:12 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:44:12 --> Total execution time: 0.0509
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0465
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0585
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0650
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0749
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0841
DEBUG - 2024-02-04 23:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:14 --> Total execution time: 0.0937
DEBUG - 2024-02-04 23:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
DEBUG - 2024-02-04 23:44:16 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:16 --> Total execution time: 0.0456
DEBUG - 2024-02-04 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:21 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:21 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:44:21 --> Total execution time: 0.0593
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0473
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0562
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0618
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0710
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0795
DEBUG - 2024-02-04 23:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:44:24 --> Total execution time: 0.0897
DEBUG - 2024-02-04 23:44:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:44:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:44:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
ERROR - 2024-02-04 23:44:28 --> 404 Page Not Found: 
DEBUG - 2024-02-04 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:28 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:47:28 --> Total execution time: 0.0613
DEBUG - 2024-02-04 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:28 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:47:28 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:47:28 --> Total execution time: 0.0705
DEBUG - 2024-02-04 23:47:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:31 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:47:31 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:47:31 --> Total execution time: 0.0588
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0461
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0579
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0682
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0723
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0820
DEBUG - 2024-02-04 23:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:34 --> Total execution time: 0.0906
DEBUG - 2024-02-04 23:47:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:39 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:39 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:39 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:39 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:47:39 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:47:39 --> Total execution time: 0.0785
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0435
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0496
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0572
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0693
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0746
DEBUG - 2024-02-04 23:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:44 --> Total execution time: 0.0835
DEBUG - 2024-02-04 23:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:50 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:50 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:50 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:50 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
DEBUG - 2024-02-04 23:47:50 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:50 --> Total execution time: 0.0624
DEBUG - 2024-02-04 23:47:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:47:55 --> You did not select a file to upload.
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:47:55 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
DEBUG - 2024-02-04 23:47:55 --> Total execution time: 0.0617
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0444
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0519
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0611
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0692
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0769
DEBUG - 2024-02-04 23:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:47:58 --> Total execution time: 0.0852
DEBUG - 2024-02-04 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:48:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:48:12 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:48:12 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
DEBUG - 2024-02-04 23:48:12 --> You did not select a file to upload.
ERROR - 2024-02-04 23:48:12 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
DEBUG - 2024-02-04 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:48:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-04 23:48:12 --> Total execution time: 0.0639
INFO - 2024-02-04 23:49:02 --> Config Class Initialized
INFO - 2024-02-04 23:49:02 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:02 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:02 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:02 --> URI Class Initialized
INFO - 2024-02-04 23:49:02 --> Router Class Initialized
INFO - 2024-02-04 23:49:02 --> Output Class Initialized
INFO - 2024-02-04 23:49:02 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:02 --> Input Class Initialized
INFO - 2024-02-04 23:49:02 --> Language Class Initialized
INFO - 2024-02-04 23:49:02 --> Loader Class Initialized
INFO - 2024-02-04 23:49:02 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:02 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:02 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:02 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:02 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:02 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:02 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:02 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:02 --> Controller Class Initialized
INFO - 2024-02-04 23:49:02 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:49:02 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:49:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:02 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:02 --> Total execution time: 0.0739
INFO - 2024-02-04 23:49:04 --> Config Class Initialized
INFO - 2024-02-04 23:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:04 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:04 --> URI Class Initialized
INFO - 2024-02-04 23:49:04 --> Router Class Initialized
INFO - 2024-02-04 23:49:04 --> Output Class Initialized
INFO - 2024-02-04 23:49:04 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:04 --> Input Class Initialized
INFO - 2024-02-04 23:49:04 --> Language Class Initialized
INFO - 2024-02-04 23:49:04 --> Loader Class Initialized
INFO - 2024-02-04 23:49:04 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:04 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:04 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:04 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:04 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:04 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:04 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:04 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:04 --> Controller Class Initialized
INFO - 2024-02-04 23:49:04 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
INFO - 2024-02-04 23:49:04 --> Helper loaded: inflector_helper
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 188
INFO - 2024-02-04 23:49:04 --> Upload Class Initialized
INFO - 2024-02-04 23:49:04 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-02-04 23:49:04 --> You did not select a file to upload.
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-04 23:49:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:49:04 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:49:04 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:49:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:04 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:04 --> Total execution time: 0.0971
INFO - 2024-02-04 23:49:27 --> Config Class Initialized
INFO - 2024-02-04 23:49:27 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:27 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:27 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:27 --> URI Class Initialized
INFO - 2024-02-04 23:49:27 --> Router Class Initialized
INFO - 2024-02-04 23:49:27 --> Output Class Initialized
INFO - 2024-02-04 23:49:27 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:27 --> Input Class Initialized
INFO - 2024-02-04 23:49:27 --> Language Class Initialized
INFO - 2024-02-04 23:49:27 --> Loader Class Initialized
INFO - 2024-02-04 23:49:27 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:27 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:27 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:27 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:27 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:27 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:27 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:27 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:27 --> Controller Class Initialized
INFO - 2024-02-04 23:49:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 149
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 150
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 151
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 152
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 153
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 154
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 155
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 156
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 157
INFO - 2024-02-04 23:49:28 --> Helper loaded: inflector_helper
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-04 23:49:28 --> Upload Class Initialized
INFO - 2024-02-04 23:49:28 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-02-04 23:49:28 --> You did not select a file to upload.
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 162
INFO - 2024-02-04 23:49:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:49:28 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:49:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:49:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:28 --> Total execution time: 0.0865
INFO - 2024-02-04 23:49:32 --> Config Class Initialized
INFO - 2024-02-04 23:49:32 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:32 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:32 --> URI Class Initialized
INFO - 2024-02-04 23:49:32 --> Router Class Initialized
INFO - 2024-02-04 23:49:32 --> Output Class Initialized
INFO - 2024-02-04 23:49:32 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:32 --> Input Class Initialized
INFO - 2024-02-04 23:49:32 --> Language Class Initialized
INFO - 2024-02-04 23:49:32 --> Loader Class Initialized
INFO - 2024-02-04 23:49:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:32 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:32 --> Controller Class Initialized
INFO - 2024-02-04 23:49:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:49:32 --> Severity: error --> Exception: Call to undefined method Pesanan_model::update() C:\xampp\htdocs\simba\application\controllers\Admin.php 495
INFO - 2024-02-04 23:49:37 --> Config Class Initialized
INFO - 2024-02-04 23:49:37 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:37 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:37 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:37 --> URI Class Initialized
INFO - 2024-02-04 23:49:37 --> Router Class Initialized
INFO - 2024-02-04 23:49:37 --> Output Class Initialized
INFO - 2024-02-04 23:49:37 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:37 --> Input Class Initialized
INFO - 2024-02-04 23:49:37 --> Language Class Initialized
INFO - 2024-02-04 23:49:37 --> Loader Class Initialized
INFO - 2024-02-04 23:49:37 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:37 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:37 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:37 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:37 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:37 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:37 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:37 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:37 --> Controller Class Initialized
INFO - 2024-02-04 23:49:37 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:49:37 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:49:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:49:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:37 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:37 --> Total execution time: 0.0777
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
INFO - 2024-02-04 23:49:40 --> Config Class Initialized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> Hooks Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
INFO - 2024-02-04 23:49:40 --> URI Class Initialized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Router Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
INFO - 2024-02-04 23:49:40 --> Output Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
INFO - 2024-02-04 23:49:40 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
DEBUG - 2024-02-04 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:40 --> Input Class Initialized
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Language Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Loader Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:40 --> Database Driver Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
INFO - 2024-02-04 23:49:40 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.0566
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.0655
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.0762
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.0890
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.1018
INFO - 2024-02-04 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:40 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:40 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:40 --> Controller Class Initialized
INFO - 2024-02-04 23:49:40 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:40 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:40 --> Total execution time: 0.1152
INFO - 2024-02-04 23:49:41 --> Config Class Initialized
INFO - 2024-02-04 23:49:41 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:41 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:41 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:41 --> URI Class Initialized
INFO - 2024-02-04 23:49:41 --> Router Class Initialized
INFO - 2024-02-04 23:49:41 --> Output Class Initialized
INFO - 2024-02-04 23:49:41 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:41 --> Input Class Initialized
INFO - 2024-02-04 23:49:41 --> Language Class Initialized
INFO - 2024-02-04 23:49:41 --> Loader Class Initialized
INFO - 2024-02-04 23:49:41 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:41 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:41 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:41 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:41 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:41 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:41 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:41 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:41 --> Controller Class Initialized
INFO - 2024-02-04 23:49:41 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:49:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:49:41 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:49:41 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:49:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:41 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:41 --> Total execution time: 0.0593
INFO - 2024-02-04 23:49:54 --> Config Class Initialized
INFO - 2024-02-04 23:49:54 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:54 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:54 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:54 --> URI Class Initialized
INFO - 2024-02-04 23:49:54 --> Router Class Initialized
INFO - 2024-02-04 23:49:54 --> Output Class Initialized
INFO - 2024-02-04 23:49:54 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:54 --> Input Class Initialized
INFO - 2024-02-04 23:49:54 --> Language Class Initialized
INFO - 2024-02-04 23:49:54 --> Loader Class Initialized
INFO - 2024-02-04 23:49:54 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:54 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:54 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:54 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:54 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:54 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:54 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:54 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:54 --> Controller Class Initialized
INFO - 2024-02-04 23:49:54 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:49:54 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
INFO - 2024-02-04 23:49:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:49:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:49:54 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:49:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:49:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:54 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:54 --> Total execution time: 0.0667
INFO - 2024-02-04 23:49:59 --> Config Class Initialized
INFO - 2024-02-04 23:49:59 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:49:59 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:49:59 --> Utf8 Class Initialized
INFO - 2024-02-04 23:49:59 --> URI Class Initialized
INFO - 2024-02-04 23:49:59 --> Router Class Initialized
INFO - 2024-02-04 23:49:59 --> Output Class Initialized
INFO - 2024-02-04 23:49:59 --> Security Class Initialized
DEBUG - 2024-02-04 23:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:49:59 --> Input Class Initialized
INFO - 2024-02-04 23:49:59 --> Language Class Initialized
INFO - 2024-02-04 23:49:59 --> Loader Class Initialized
INFO - 2024-02-04 23:49:59 --> Helper loaded: url_helper
INFO - 2024-02-04 23:49:59 --> Helper loaded: file_helper
INFO - 2024-02-04 23:49:59 --> Helper loaded: security_helper
INFO - 2024-02-04 23:49:59 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:49:59 --> Database Driver Class Initialized
INFO - 2024-02-04 23:49:59 --> Email Class Initialized
DEBUG - 2024-02-04 23:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:49:59 --> Helper loaded: form_helper
INFO - 2024-02-04 23:49:59 --> Form Validation Class Initialized
INFO - 2024-02-04 23:49:59 --> Controller Class Initialized
INFO - 2024-02-04 23:49:59 --> Model "User_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:49:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:49:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:49:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:49:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:49:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:49:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:49:59 --> Final output sent to browser
DEBUG - 2024-02-04 23:49:59 --> Total execution time: 0.0709
INFO - 2024-02-04 23:50:00 --> Config Class Initialized
INFO - 2024-02-04 23:50:00 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:00 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:00 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:00 --> URI Class Initialized
INFO - 2024-02-04 23:50:00 --> Router Class Initialized
INFO - 2024-02-04 23:50:00 --> Output Class Initialized
INFO - 2024-02-04 23:50:00 --> Security Class Initialized
DEBUG - 2024-02-04 23:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:00 --> Input Class Initialized
INFO - 2024-02-04 23:50:00 --> Language Class Initialized
INFO - 2024-02-04 23:50:00 --> Loader Class Initialized
INFO - 2024-02-04 23:50:00 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:00 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:00 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:00 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:00 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:00 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:00 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:00 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:00 --> Controller Class Initialized
INFO - 2024-02-04 23:50:00 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:50:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:50:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:50:00 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:50:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:50:00 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:00 --> Total execution time: 0.0650
INFO - 2024-02-04 23:50:01 --> Config Class Initialized
INFO - 2024-02-04 23:50:01 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:01 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:01 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:01 --> URI Class Initialized
INFO - 2024-02-04 23:50:01 --> Router Class Initialized
INFO - 2024-02-04 23:50:01 --> Output Class Initialized
INFO - 2024-02-04 23:50:01 --> Security Class Initialized
DEBUG - 2024-02-04 23:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:01 --> Input Class Initialized
INFO - 2024-02-04 23:50:01 --> Language Class Initialized
INFO - 2024-02-04 23:50:01 --> Loader Class Initialized
INFO - 2024-02-04 23:50:01 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:01 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:01 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:01 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:01 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:01 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:01 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:01 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:01 --> Controller Class Initialized
INFO - 2024-02-04 23:50:01 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:50:01 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
INFO - 2024-02-04 23:50:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:50:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:50:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:50:01 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:50:01 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:50:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:50:01 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:01 --> Total execution time: 0.0654
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Config Class Initialized
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
INFO - 2024-02-04 23:50:03 --> Hooks Class Initialized
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:50:03 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:03 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
INFO - 2024-02-04 23:50:03 --> URI Class Initialized
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> Router Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
INFO - 2024-02-04 23:50:03 --> Output Class Initialized
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Security Class Initialized
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:03 --> Input Class Initialized
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
INFO - 2024-02-04 23:50:03 --> Language Class Initialized
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Loader Class Initialized
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:03 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:03 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:03 --> Database Driver Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
INFO - 2024-02-04 23:50:03 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.0569
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.0651
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.0770
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.0890
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.1030
INFO - 2024-02-04 23:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:03 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:03 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:03 --> Controller Class Initialized
INFO - 2024-02-04 23:50:03 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:03 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:03 --> Total execution time: 0.1178
INFO - 2024-02-04 23:50:08 --> Config Class Initialized
INFO - 2024-02-04 23:50:08 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:08 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:08 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:08 --> URI Class Initialized
INFO - 2024-02-04 23:50:08 --> Router Class Initialized
INFO - 2024-02-04 23:50:08 --> Output Class Initialized
INFO - 2024-02-04 23:50:08 --> Security Class Initialized
DEBUG - 2024-02-04 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:08 --> Input Class Initialized
INFO - 2024-02-04 23:50:08 --> Language Class Initialized
INFO - 2024-02-04 23:50:08 --> Loader Class Initialized
INFO - 2024-02-04 23:50:08 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:08 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:08 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:08 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:08 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:08 --> Controller Class Initialized
INFO - 2024-02-04 23:50:08 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:50:08 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
INFO - 2024-02-04 23:50:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:50:08 --> Config Class Initialized
INFO - 2024-02-04 23:50:08 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:08 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:08 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:08 --> URI Class Initialized
INFO - 2024-02-04 23:50:08 --> Router Class Initialized
INFO - 2024-02-04 23:50:08 --> Output Class Initialized
INFO - 2024-02-04 23:50:08 --> Security Class Initialized
DEBUG - 2024-02-04 23:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:08 --> Input Class Initialized
INFO - 2024-02-04 23:50:08 --> Language Class Initialized
INFO - 2024-02-04 23:50:08 --> Loader Class Initialized
INFO - 2024-02-04 23:50:08 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:08 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:08 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:08 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:08 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:08 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:08 --> Controller Class Initialized
INFO - 2024-02-04 23:50:08 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:50:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:50:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:50:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:50:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:50:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:50:08 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:08 --> Total execution time: 0.0715
INFO - 2024-02-04 23:50:11 --> Config Class Initialized
INFO - 2024-02-04 23:50:11 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:50:11 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:50:11 --> Utf8 Class Initialized
INFO - 2024-02-04 23:50:11 --> URI Class Initialized
INFO - 2024-02-04 23:50:11 --> Router Class Initialized
INFO - 2024-02-04 23:50:11 --> Output Class Initialized
INFO - 2024-02-04 23:50:11 --> Security Class Initialized
DEBUG - 2024-02-04 23:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:50:11 --> Input Class Initialized
INFO - 2024-02-04 23:50:11 --> Language Class Initialized
INFO - 2024-02-04 23:50:11 --> Loader Class Initialized
INFO - 2024-02-04 23:50:11 --> Helper loaded: url_helper
INFO - 2024-02-04 23:50:11 --> Helper loaded: file_helper
INFO - 2024-02-04 23:50:11 --> Helper loaded: security_helper
INFO - 2024-02-04 23:50:11 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:50:11 --> Database Driver Class Initialized
INFO - 2024-02-04 23:50:11 --> Email Class Initialized
DEBUG - 2024-02-04 23:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:50:11 --> Helper loaded: form_helper
INFO - 2024-02-04 23:50:11 --> Form Validation Class Initialized
INFO - 2024-02-04 23:50:11 --> Controller Class Initialized
INFO - 2024-02-04 23:50:11 --> Model "User_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:50:11 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:50:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:50:11 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
INFO - 2024-02-04 23:50:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:50:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:50:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:50:11 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:50:11 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:50:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:50:11 --> Final output sent to browser
DEBUG - 2024-02-04 23:50:11 --> Total execution time: 0.0561
INFO - 2024-02-04 23:51:06 --> Config Class Initialized
INFO - 2024-02-04 23:51:06 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:51:06 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:06 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:06 --> URI Class Initialized
INFO - 2024-02-04 23:51:06 --> Router Class Initialized
INFO - 2024-02-04 23:51:06 --> Output Class Initialized
INFO - 2024-02-04 23:51:06 --> Security Class Initialized
DEBUG - 2024-02-04 23:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:06 --> Input Class Initialized
INFO - 2024-02-04 23:51:06 --> Language Class Initialized
INFO - 2024-02-04 23:51:06 --> Loader Class Initialized
INFO - 2024-02-04 23:51:06 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:06 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:06 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:06 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:06 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:06 --> Email Class Initialized
DEBUG - 2024-02-04 23:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:06 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:06 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:06 --> Controller Class Initialized
INFO - 2024-02-04 23:51:06 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:51:06 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 182
INFO - 2024-02-04 23:51:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:51:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:51:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:51:06 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:51:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:51:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:51:06 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:06 --> Total execution time: 0.0621
INFO - 2024-02-04 23:51:52 --> Config Class Initialized
INFO - 2024-02-04 23:51:52 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:51:52 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:52 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:52 --> URI Class Initialized
INFO - 2024-02-04 23:51:52 --> Router Class Initialized
INFO - 2024-02-04 23:51:52 --> Output Class Initialized
INFO - 2024-02-04 23:51:52 --> Security Class Initialized
DEBUG - 2024-02-04 23:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:52 --> Input Class Initialized
INFO - 2024-02-04 23:51:52 --> Language Class Initialized
INFO - 2024-02-04 23:51:52 --> Loader Class Initialized
INFO - 2024-02-04 23:51:52 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:52 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:52 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:52 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:52 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:52 --> Email Class Initialized
DEBUG - 2024-02-04 23:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:52 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:52 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:52 --> Controller Class Initialized
INFO - 2024-02-04 23:51:52 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:51:52 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-04 23:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:51:52 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:51:52 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:52 --> Total execution time: 0.0592
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Config Class Initialized
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
INFO - 2024-02-04 23:51:55 --> Hooks Class Initialized
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:51:55 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
INFO - 2024-02-04 23:51:55 --> URI Class Initialized
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Router Class Initialized
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
INFO - 2024-02-04 23:51:55 --> Output Class Initialized
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Security Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Input Class Initialized
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Language Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Loader Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Email Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.0589
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.0653
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.0818
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.0902
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.1043
INFO - 2024-02-04 23:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:51:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:51:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:51:55 --> Controller Class Initialized
INFO - 2024-02-04 23:51:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:51:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:51:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:51:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:51:55 --> Total execution time: 0.1191
INFO - 2024-02-04 23:52:06 --> Config Class Initialized
INFO - 2024-02-04 23:52:06 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:52:06 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:52:06 --> Utf8 Class Initialized
INFO - 2024-02-04 23:52:06 --> URI Class Initialized
INFO - 2024-02-04 23:52:06 --> Router Class Initialized
INFO - 2024-02-04 23:52:06 --> Output Class Initialized
INFO - 2024-02-04 23:52:06 --> Security Class Initialized
DEBUG - 2024-02-04 23:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:52:06 --> Input Class Initialized
INFO - 2024-02-04 23:52:06 --> Language Class Initialized
INFO - 2024-02-04 23:52:06 --> Loader Class Initialized
INFO - 2024-02-04 23:52:06 --> Helper loaded: url_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: file_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: security_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:52:06 --> Database Driver Class Initialized
INFO - 2024-02-04 23:52:06 --> Email Class Initialized
DEBUG - 2024-02-04 23:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:52:06 --> Helper loaded: form_helper
INFO - 2024-02-04 23:52:06 --> Form Validation Class Initialized
INFO - 2024-02-04 23:52:06 --> Controller Class Initialized
INFO - 2024-02-04 23:52:06 --> Model "User_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:52:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:52:06 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-04 23:52:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:52:06 --> Config Class Initialized
INFO - 2024-02-04 23:52:06 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:52:06 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:52:06 --> Utf8 Class Initialized
INFO - 2024-02-04 23:52:06 --> URI Class Initialized
INFO - 2024-02-04 23:52:06 --> Router Class Initialized
INFO - 2024-02-04 23:52:06 --> Output Class Initialized
INFO - 2024-02-04 23:52:06 --> Security Class Initialized
DEBUG - 2024-02-04 23:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:52:06 --> Input Class Initialized
INFO - 2024-02-04 23:52:06 --> Language Class Initialized
INFO - 2024-02-04 23:52:06 --> Loader Class Initialized
INFO - 2024-02-04 23:52:06 --> Helper loaded: url_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: file_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: security_helper
INFO - 2024-02-04 23:52:06 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:52:06 --> Database Driver Class Initialized
INFO - 2024-02-04 23:52:06 --> Email Class Initialized
DEBUG - 2024-02-04 23:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:52:06 --> Helper loaded: form_helper
INFO - 2024-02-04 23:52:06 --> Form Validation Class Initialized
INFO - 2024-02-04 23:52:06 --> Controller Class Initialized
INFO - 2024-02-04 23:52:06 --> Model "User_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:52:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:52:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:52:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:52:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:52:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:52:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:52:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:52:06 --> Final output sent to browser
DEBUG - 2024-02-04 23:52:06 --> Total execution time: 0.0731
INFO - 2024-02-04 23:53:25 --> Config Class Initialized
INFO - 2024-02-04 23:53:25 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:25 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:25 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:25 --> URI Class Initialized
INFO - 2024-02-04 23:53:25 --> Router Class Initialized
INFO - 2024-02-04 23:53:25 --> Output Class Initialized
INFO - 2024-02-04 23:53:25 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:25 --> Input Class Initialized
INFO - 2024-02-04 23:53:25 --> Language Class Initialized
INFO - 2024-02-04 23:53:25 --> Loader Class Initialized
INFO - 2024-02-04 23:53:25 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:25 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:25 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:25 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:25 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:25 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:25 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:25 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:25 --> Controller Class Initialized
INFO - 2024-02-04 23:53:25 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:53:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:53:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:53:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:53:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:53:25 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:25 --> Total execution time: 0.0693
INFO - 2024-02-04 23:53:26 --> Config Class Initialized
INFO - 2024-02-04 23:53:26 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:26 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:26 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:26 --> URI Class Initialized
INFO - 2024-02-04 23:53:26 --> Router Class Initialized
INFO - 2024-02-04 23:53:26 --> Output Class Initialized
INFO - 2024-02-04 23:53:26 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:26 --> Input Class Initialized
INFO - 2024-02-04 23:53:26 --> Language Class Initialized
INFO - 2024-02-04 23:53:26 --> Loader Class Initialized
INFO - 2024-02-04 23:53:26 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:26 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:26 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:26 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:26 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:26 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:26 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:26 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:26 --> Controller Class Initialized
INFO - 2024-02-04 23:53:26 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:53:26 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-04 23:53:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:53:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:53:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:53:26 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:53:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:53:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:53:26 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:26 --> Total execution time: 0.0558
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:28 --> Config Class Initialized
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
INFO - 2024-02-04 23:53:28 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
INFO - 2024-02-04 23:53:28 --> URI Class Initialized
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
INFO - 2024-02-04 23:53:28 --> Router Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:28 --> Output Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Security Class Initialized
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:28 --> Input Class Initialized
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Language Class Initialized
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Loader Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:28 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.0540
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.0651
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.0766
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.0875
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.0996
INFO - 2024-02-04 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:28 --> Controller Class Initialized
INFO - 2024-02-04 23:53:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:28 --> Total execution time: 0.1152
INFO - 2024-02-04 23:53:30 --> Config Class Initialized
INFO - 2024-02-04 23:53:30 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:30 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:30 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:30 --> URI Class Initialized
INFO - 2024-02-04 23:53:30 --> Router Class Initialized
INFO - 2024-02-04 23:53:30 --> Output Class Initialized
INFO - 2024-02-04 23:53:30 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:30 --> Input Class Initialized
INFO - 2024-02-04 23:53:30 --> Language Class Initialized
INFO - 2024-02-04 23:53:30 --> Loader Class Initialized
INFO - 2024-02-04 23:53:30 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:30 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:30 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:30 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:30 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:30 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:30 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:30 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:30 --> Controller Class Initialized
INFO - 2024-02-04 23:53:30 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:53:30 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-04 23:53:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:53:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:53:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:53:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:53:30 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:53:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:53:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:53:30 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:30 --> Total execution time: 0.0647
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
INFO - 2024-02-04 23:53:32 --> Config Class Initialized
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:53:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:32 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> URI Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
INFO - 2024-02-04 23:53:32 --> Router Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
INFO - 2024-02-04 23:53:32 --> Output Class Initialized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
INFO - 2024-02-04 23:53:32 --> Security Class Initialized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Input Class Initialized
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Language Class Initialized
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
INFO - 2024-02-04 23:53:32 --> Loader Class Initialized
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.0552
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.0739
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.0840
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.0955
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.1069
INFO - 2024-02-04 23:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:32 --> Controller Class Initialized
INFO - 2024-02-04 23:53:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:32 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:32 --> Total execution time: 0.1223
INFO - 2024-02-04 23:53:36 --> Config Class Initialized
INFO - 2024-02-04 23:53:36 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:36 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:36 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:36 --> URI Class Initialized
INFO - 2024-02-04 23:53:36 --> Router Class Initialized
INFO - 2024-02-04 23:53:36 --> Output Class Initialized
INFO - 2024-02-04 23:53:36 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:36 --> Input Class Initialized
INFO - 2024-02-04 23:53:36 --> Language Class Initialized
INFO - 2024-02-04 23:53:36 --> Loader Class Initialized
INFO - 2024-02-04 23:53:36 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:36 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:36 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:36 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:36 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:36 --> Controller Class Initialized
INFO - 2024-02-04 23:53:36 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:53:36 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-04 23:53:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-04 23:53:36 --> Config Class Initialized
INFO - 2024-02-04 23:53:36 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:53:36 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:53:36 --> Utf8 Class Initialized
INFO - 2024-02-04 23:53:36 --> URI Class Initialized
INFO - 2024-02-04 23:53:36 --> Router Class Initialized
INFO - 2024-02-04 23:53:36 --> Output Class Initialized
INFO - 2024-02-04 23:53:36 --> Security Class Initialized
DEBUG - 2024-02-04 23:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:53:36 --> Input Class Initialized
INFO - 2024-02-04 23:53:36 --> Language Class Initialized
INFO - 2024-02-04 23:53:36 --> Loader Class Initialized
INFO - 2024-02-04 23:53:36 --> Helper loaded: url_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: file_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: security_helper
INFO - 2024-02-04 23:53:36 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:53:36 --> Database Driver Class Initialized
INFO - 2024-02-04 23:53:36 --> Email Class Initialized
DEBUG - 2024-02-04 23:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:53:36 --> Helper loaded: form_helper
INFO - 2024-02-04 23:53:36 --> Form Validation Class Initialized
INFO - 2024-02-04 23:53:36 --> Controller Class Initialized
INFO - 2024-02-04 23:53:36 --> Model "User_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:53:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:53:36 --> Final output sent to browser
DEBUG - 2024-02-04 23:53:36 --> Total execution time: 0.0714
INFO - 2024-02-04 23:54:28 --> Config Class Initialized
INFO - 2024-02-04 23:54:28 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:54:28 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:54:28 --> Utf8 Class Initialized
INFO - 2024-02-04 23:54:28 --> URI Class Initialized
INFO - 2024-02-04 23:54:28 --> Router Class Initialized
INFO - 2024-02-04 23:54:28 --> Output Class Initialized
INFO - 2024-02-04 23:54:28 --> Security Class Initialized
DEBUG - 2024-02-04 23:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:54:28 --> Input Class Initialized
INFO - 2024-02-04 23:54:28 --> Language Class Initialized
INFO - 2024-02-04 23:54:28 --> Loader Class Initialized
INFO - 2024-02-04 23:54:28 --> Helper loaded: url_helper
INFO - 2024-02-04 23:54:28 --> Helper loaded: file_helper
INFO - 2024-02-04 23:54:28 --> Helper loaded: security_helper
INFO - 2024-02-04 23:54:28 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:54:28 --> Database Driver Class Initialized
INFO - 2024-02-04 23:54:28 --> Email Class Initialized
DEBUG - 2024-02-04 23:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:54:28 --> Helper loaded: form_helper
INFO - 2024-02-04 23:54:28 --> Form Validation Class Initialized
INFO - 2024-02-04 23:54:28 --> Controller Class Initialized
INFO - 2024-02-04 23:54:28 --> Model "User_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:54:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:54:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:54:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:54:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:54:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:54:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:54:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:54:28 --> Final output sent to browser
DEBUG - 2024-02-04 23:54:28 --> Total execution time: 0.0891
INFO - 2024-02-04 23:54:29 --> Config Class Initialized
INFO - 2024-02-04 23:54:29 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:54:29 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:54:29 --> Utf8 Class Initialized
INFO - 2024-02-04 23:54:29 --> URI Class Initialized
INFO - 2024-02-04 23:54:29 --> Router Class Initialized
INFO - 2024-02-04 23:54:29 --> Output Class Initialized
INFO - 2024-02-04 23:54:29 --> Security Class Initialized
DEBUG - 2024-02-04 23:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:54:29 --> Input Class Initialized
INFO - 2024-02-04 23:54:29 --> Language Class Initialized
INFO - 2024-02-04 23:54:29 --> Loader Class Initialized
INFO - 2024-02-04 23:54:29 --> Helper loaded: url_helper
INFO - 2024-02-04 23:54:29 --> Helper loaded: file_helper
INFO - 2024-02-04 23:54:29 --> Helper loaded: security_helper
INFO - 2024-02-04 23:54:29 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:54:29 --> Database Driver Class Initialized
INFO - 2024-02-04 23:54:29 --> Email Class Initialized
DEBUG - 2024-02-04 23:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:54:29 --> Helper loaded: form_helper
INFO - 2024-02-04 23:54:29 --> Form Validation Class Initialized
INFO - 2024-02-04 23:54:29 --> Controller Class Initialized
INFO - 2024-02-04 23:54:29 --> Model "User_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:54:29 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:54:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:54:29 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\simba\application\controllers\Admin.php 493
INFO - 2024-02-04 23:55:57 --> Config Class Initialized
INFO - 2024-02-04 23:55:57 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:55:57 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:55:57 --> Utf8 Class Initialized
INFO - 2024-02-04 23:55:57 --> URI Class Initialized
INFO - 2024-02-04 23:55:57 --> Router Class Initialized
INFO - 2024-02-04 23:55:57 --> Output Class Initialized
INFO - 2024-02-04 23:55:57 --> Security Class Initialized
DEBUG - 2024-02-04 23:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:55:57 --> Input Class Initialized
INFO - 2024-02-04 23:55:57 --> Language Class Initialized
INFO - 2024-02-04 23:55:57 --> Loader Class Initialized
INFO - 2024-02-04 23:55:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:55:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:55:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:55:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:55:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:55:57 --> Email Class Initialized
DEBUG - 2024-02-04 23:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:55:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:55:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:55:57 --> Controller Class Initialized
INFO - 2024-02-04 23:55:57 --> Model "User_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:55:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:55:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:55:57 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\simba\application\controllers\Admin.php 493
INFO - 2024-02-04 23:55:58 --> Config Class Initialized
INFO - 2024-02-04 23:55:58 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:55:58 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:55:58 --> Utf8 Class Initialized
INFO - 2024-02-04 23:55:58 --> URI Class Initialized
INFO - 2024-02-04 23:55:58 --> Router Class Initialized
INFO - 2024-02-04 23:55:58 --> Output Class Initialized
INFO - 2024-02-04 23:55:58 --> Security Class Initialized
DEBUG - 2024-02-04 23:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:55:58 --> Input Class Initialized
INFO - 2024-02-04 23:55:58 --> Language Class Initialized
INFO - 2024-02-04 23:55:58 --> Loader Class Initialized
INFO - 2024-02-04 23:55:58 --> Helper loaded: url_helper
INFO - 2024-02-04 23:55:58 --> Helper loaded: file_helper
INFO - 2024-02-04 23:55:58 --> Helper loaded: security_helper
INFO - 2024-02-04 23:55:58 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:55:58 --> Database Driver Class Initialized
INFO - 2024-02-04 23:55:58 --> Email Class Initialized
DEBUG - 2024-02-04 23:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:55:58 --> Helper loaded: form_helper
INFO - 2024-02-04 23:55:58 --> Form Validation Class Initialized
INFO - 2024-02-04 23:55:58 --> Controller Class Initialized
INFO - 2024-02-04 23:55:58 --> Model "User_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:55:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:55:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:55:58 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\simba\application\controllers\Admin.php 493
INFO - 2024-02-04 23:55:59 --> Config Class Initialized
INFO - 2024-02-04 23:55:59 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:55:59 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:55:59 --> Utf8 Class Initialized
INFO - 2024-02-04 23:55:59 --> URI Class Initialized
INFO - 2024-02-04 23:55:59 --> Router Class Initialized
INFO - 2024-02-04 23:55:59 --> Output Class Initialized
INFO - 2024-02-04 23:55:59 --> Security Class Initialized
DEBUG - 2024-02-04 23:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:55:59 --> Input Class Initialized
INFO - 2024-02-04 23:55:59 --> Language Class Initialized
INFO - 2024-02-04 23:55:59 --> Loader Class Initialized
INFO - 2024-02-04 23:55:59 --> Helper loaded: url_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: file_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: security_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:55:59 --> Database Driver Class Initialized
INFO - 2024-02-04 23:55:59 --> Email Class Initialized
DEBUG - 2024-02-04 23:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:55:59 --> Helper loaded: form_helper
INFO - 2024-02-04 23:55:59 --> Form Validation Class Initialized
INFO - 2024-02-04 23:55:59 --> Controller Class Initialized
INFO - 2024-02-04 23:55:59 --> Model "User_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:55:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:55:59 --> Final output sent to browser
DEBUG - 2024-02-04 23:55:59 --> Total execution time: 0.0568
INFO - 2024-02-04 23:55:59 --> Config Class Initialized
INFO - 2024-02-04 23:55:59 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:55:59 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:55:59 --> Utf8 Class Initialized
INFO - 2024-02-04 23:55:59 --> URI Class Initialized
INFO - 2024-02-04 23:55:59 --> Router Class Initialized
INFO - 2024-02-04 23:55:59 --> Output Class Initialized
INFO - 2024-02-04 23:55:59 --> Security Class Initialized
DEBUG - 2024-02-04 23:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:55:59 --> Input Class Initialized
INFO - 2024-02-04 23:55:59 --> Language Class Initialized
INFO - 2024-02-04 23:55:59 --> Loader Class Initialized
INFO - 2024-02-04 23:55:59 --> Helper loaded: url_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: file_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: security_helper
INFO - 2024-02-04 23:55:59 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:55:59 --> Database Driver Class Initialized
INFO - 2024-02-04 23:55:59 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:00 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:00 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:00 --> Controller Class Initialized
INFO - 2024-02-04 23:56:00 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:56:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:56:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:56:00 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:56:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:56:00 --> Final output sent to browser
DEBUG - 2024-02-04 23:56:00 --> Total execution time: 0.0758
INFO - 2024-02-04 23:56:07 --> Config Class Initialized
INFO - 2024-02-04 23:56:07 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:07 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:07 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:07 --> URI Class Initialized
INFO - 2024-02-04 23:56:07 --> Router Class Initialized
INFO - 2024-02-04 23:56:07 --> Output Class Initialized
INFO - 2024-02-04 23:56:07 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:07 --> Input Class Initialized
INFO - 2024-02-04 23:56:07 --> Language Class Initialized
INFO - 2024-02-04 23:56:07 --> Loader Class Initialized
INFO - 2024-02-04 23:56:07 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:07 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:07 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:07 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:07 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:07 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:07 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:07 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:07 --> Controller Class Initialized
INFO - 2024-02-04 23:56:07 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:56:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:56:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:56:07 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:56:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:56:07 --> Final output sent to browser
DEBUG - 2024-02-04 23:56:07 --> Total execution time: 0.0624
INFO - 2024-02-04 23:56:08 --> Config Class Initialized
INFO - 2024-02-04 23:56:08 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:08 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:08 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:08 --> URI Class Initialized
INFO - 2024-02-04 23:56:08 --> Router Class Initialized
INFO - 2024-02-04 23:56:08 --> Output Class Initialized
INFO - 2024-02-04 23:56:08 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:08 --> Input Class Initialized
INFO - 2024-02-04 23:56:08 --> Language Class Initialized
INFO - 2024-02-04 23:56:08 --> Loader Class Initialized
INFO - 2024-02-04 23:56:08 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:08 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:08 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:08 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:08 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:08 --> Controller Class Initialized
INFO - 2024-02-04 23:56:08 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:56:08 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\simba\application\controllers\Admin.php 493
ERROR - 2024-02-04 23:56:08 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 185
INFO - 2024-02-04 23:56:08 --> Config Class Initialized
INFO - 2024-02-04 23:56:08 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:08 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:08 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:08 --> URI Class Initialized
INFO - 2024-02-04 23:56:08 --> Router Class Initialized
INFO - 2024-02-04 23:56:08 --> Output Class Initialized
INFO - 2024-02-04 23:56:08 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:08 --> Input Class Initialized
INFO - 2024-02-04 23:56:08 --> Language Class Initialized
INFO - 2024-02-04 23:56:08 --> Loader Class Initialized
INFO - 2024-02-04 23:56:08 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:08 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:08 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:08 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:08 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:08 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:08 --> Controller Class Initialized
INFO - 2024-02-04 23:56:08 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:56:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:56:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:56:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:56:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:56:08 --> Final output sent to browser
DEBUG - 2024-02-04 23:56:08 --> Total execution time: 0.0479
INFO - 2024-02-04 23:56:10 --> Config Class Initialized
INFO - 2024-02-04 23:56:10 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:10 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:10 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:10 --> URI Class Initialized
INFO - 2024-02-04 23:56:10 --> Router Class Initialized
INFO - 2024-02-04 23:56:10 --> Output Class Initialized
INFO - 2024-02-04 23:56:10 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:10 --> Input Class Initialized
INFO - 2024-02-04 23:56:10 --> Language Class Initialized
INFO - 2024-02-04 23:56:10 --> Loader Class Initialized
INFO - 2024-02-04 23:56:10 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:10 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:10 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:10 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:10 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:10 --> Controller Class Initialized
INFO - 2024-02-04 23:56:10 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:56:10 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\simba\application\controllers\Admin.php 493
ERROR - 2024-02-04 23:56:10 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 185
INFO - 2024-02-04 23:56:10 --> Config Class Initialized
INFO - 2024-02-04 23:56:10 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:10 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:10 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:10 --> URI Class Initialized
INFO - 2024-02-04 23:56:10 --> Router Class Initialized
INFO - 2024-02-04 23:56:10 --> Output Class Initialized
INFO - 2024-02-04 23:56:10 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:10 --> Input Class Initialized
INFO - 2024-02-04 23:56:10 --> Language Class Initialized
INFO - 2024-02-04 23:56:10 --> Loader Class Initialized
INFO - 2024-02-04 23:56:10 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:10 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:10 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:10 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:10 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:10 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:10 --> Controller Class Initialized
INFO - 2024-02-04 23:56:10 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:56:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:56:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:56:10 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:56:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:56:10 --> Final output sent to browser
DEBUG - 2024-02-04 23:56:10 --> Total execution time: 0.0705
INFO - 2024-02-04 23:56:25 --> Config Class Initialized
INFO - 2024-02-04 23:56:25 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:25 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:25 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:25 --> URI Class Initialized
INFO - 2024-02-04 23:56:25 --> Router Class Initialized
INFO - 2024-02-04 23:56:25 --> Output Class Initialized
INFO - 2024-02-04 23:56:25 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:25 --> Input Class Initialized
INFO - 2024-02-04 23:56:25 --> Language Class Initialized
INFO - 2024-02-04 23:56:25 --> Loader Class Initialized
INFO - 2024-02-04 23:56:25 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:25 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:25 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:25 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:25 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:25 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:25 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:25 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:25 --> Controller Class Initialized
INFO - 2024-02-04 23:56:25 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:56:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:56:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:56:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:56:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:56:25 --> Final output sent to browser
DEBUG - 2024-02-04 23:56:25 --> Total execution time: 0.0897
INFO - 2024-02-04 23:56:26 --> Config Class Initialized
INFO - 2024-02-04 23:56:26 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:26 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:26 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:26 --> URI Class Initialized
INFO - 2024-02-04 23:56:26 --> Router Class Initialized
INFO - 2024-02-04 23:56:26 --> Output Class Initialized
INFO - 2024-02-04 23:56:26 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:26 --> Input Class Initialized
INFO - 2024-02-04 23:56:26 --> Language Class Initialized
INFO - 2024-02-04 23:56:26 --> Loader Class Initialized
INFO - 2024-02-04 23:56:26 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:26 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:26 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:26 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:26 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:26 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:26 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:26 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:26 --> Controller Class Initialized
INFO - 2024-02-04 23:56:26 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:56:34 --> Config Class Initialized
INFO - 2024-02-04 23:56:34 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:56:34 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:56:34 --> Utf8 Class Initialized
INFO - 2024-02-04 23:56:34 --> URI Class Initialized
INFO - 2024-02-04 23:56:34 --> Router Class Initialized
INFO - 2024-02-04 23:56:34 --> Output Class Initialized
INFO - 2024-02-04 23:56:34 --> Security Class Initialized
DEBUG - 2024-02-04 23:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:56:34 --> Input Class Initialized
INFO - 2024-02-04 23:56:34 --> Language Class Initialized
INFO - 2024-02-04 23:56:34 --> Loader Class Initialized
INFO - 2024-02-04 23:56:34 --> Helper loaded: url_helper
INFO - 2024-02-04 23:56:34 --> Helper loaded: file_helper
INFO - 2024-02-04 23:56:34 --> Helper loaded: security_helper
INFO - 2024-02-04 23:56:34 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:56:34 --> Database Driver Class Initialized
INFO - 2024-02-04 23:56:34 --> Email Class Initialized
DEBUG - 2024-02-04 23:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:56:34 --> Helper loaded: form_helper
INFO - 2024-02-04 23:56:34 --> Form Validation Class Initialized
INFO - 2024-02-04 23:56:34 --> Controller Class Initialized
INFO - 2024-02-04 23:56:34 --> Model "User_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:56:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:56:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:55 --> Config Class Initialized
INFO - 2024-02-04 23:57:55 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:57:55 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:57:55 --> Utf8 Class Initialized
INFO - 2024-02-04 23:57:55 --> URI Class Initialized
INFO - 2024-02-04 23:57:55 --> Router Class Initialized
INFO - 2024-02-04 23:57:55 --> Output Class Initialized
INFO - 2024-02-04 23:57:55 --> Security Class Initialized
DEBUG - 2024-02-04 23:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:55 --> Input Class Initialized
INFO - 2024-02-04 23:57:55 --> Language Class Initialized
INFO - 2024-02-04 23:57:55 --> Loader Class Initialized
INFO - 2024-02-04 23:57:55 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:55 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:55 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:55 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:55 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:55 --> Email Class Initialized
DEBUG - 2024-02-04 23:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:55 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:55 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:55 --> Controller Class Initialized
INFO - 2024-02-04 23:57:55 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
INFO - 2024-02-04 23:57:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:57:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:57:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-04 23:57:55 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-04 23:57:55 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-04 23:57:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:57:55 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:55 --> Total execution time: 0.0773
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:57 --> Controller Class Initialized
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
INFO - 2024-02-04 23:57:57 --> Config Class Initialized
INFO - 2024-02-04 23:57:57 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
DEBUG - 2024-02-04 23:57:57 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> Utf8 Class Initialized
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> URI Class Initialized
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:57 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:57 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:57 --> Total execution time: 0.0610
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Router Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Controller Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:57 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:57 --> Total execution time: 0.0758
INFO - 2024-02-04 23:57:57 --> Output Class Initialized
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
INFO - 2024-02-04 23:57:57 --> Security Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
INFO - 2024-02-04 23:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:57:57 --> Input Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:57 --> Language Class Initialized
INFO - 2024-02-04 23:57:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:57 --> Controller Class Initialized
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Loader Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: url_helper
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: file_helper
INFO - 2024-02-04 23:57:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: security_helper
INFO - 2024-02-04 23:57:57 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:57 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:57:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:57 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:57 --> Total execution time: 0.0565
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Database Driver Class Initialized
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
DEBUG - 2024-02-04 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
INFO - 2024-02-04 23:57:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-04 23:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:57:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:57 --> Controller Class Initialized
INFO - 2024-02-04 23:57:57 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:57 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:57 --> Total execution time: 0.0783
INFO - 2024-02-04 23:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:57 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:57 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:57 --> Controller Class Initialized
INFO - 2024-02-04 23:57:57 --> Email Class Initialized
INFO - 2024-02-04 23:57:58 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Faktur_model" initialized
DEBUG - 2024-02-04 23:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:57:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:58 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:58 --> Total execution time: 0.1259
INFO - 2024-02-04 23:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:57:58 --> Helper loaded: form_helper
INFO - 2024-02-04 23:57:58 --> Form Validation Class Initialized
INFO - 2024-02-04 23:57:58 --> Controller Class Initialized
INFO - 2024-02-04 23:57:58 --> Model "User_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:57:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:57:58 --> Final output sent to browser
DEBUG - 2024-02-04 23:57:58 --> Total execution time: 0.1399
INFO - 2024-02-04 23:58:02 --> Config Class Initialized
INFO - 2024-02-04 23:58:02 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:58:02 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:58:02 --> Utf8 Class Initialized
INFO - 2024-02-04 23:58:02 --> URI Class Initialized
INFO - 2024-02-04 23:58:02 --> Router Class Initialized
INFO - 2024-02-04 23:58:02 --> Output Class Initialized
INFO - 2024-02-04 23:58:02 --> Security Class Initialized
DEBUG - 2024-02-04 23:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:58:02 --> Input Class Initialized
INFO - 2024-02-04 23:58:02 --> Language Class Initialized
INFO - 2024-02-04 23:58:02 --> Loader Class Initialized
INFO - 2024-02-04 23:58:02 --> Helper loaded: url_helper
INFO - 2024-02-04 23:58:02 --> Helper loaded: file_helper
INFO - 2024-02-04 23:58:02 --> Helper loaded: security_helper
INFO - 2024-02-04 23:58:02 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:58:02 --> Database Driver Class Initialized
INFO - 2024-02-04 23:58:02 --> Email Class Initialized
DEBUG - 2024-02-04 23:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:58:02 --> Helper loaded: form_helper
INFO - 2024-02-04 23:58:02 --> Form Validation Class Initialized
INFO - 2024-02-04 23:58:02 --> Controller Class Initialized
INFO - 2024-02-04 23:58:02 --> Model "User_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:58:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:58:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:58:02 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:58:02 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
INFO - 2024-02-04 23:58:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-04 23:58:02 --> 404 Page Not Found: 
INFO - 2024-02-04 23:59:32 --> Config Class Initialized
INFO - 2024-02-04 23:59:32 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:59:32 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:59:32 --> Utf8 Class Initialized
INFO - 2024-02-04 23:59:32 --> URI Class Initialized
INFO - 2024-02-04 23:59:32 --> Router Class Initialized
INFO - 2024-02-04 23:59:32 --> Output Class Initialized
INFO - 2024-02-04 23:59:32 --> Security Class Initialized
DEBUG - 2024-02-04 23:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:59:32 --> Input Class Initialized
INFO - 2024-02-04 23:59:32 --> Language Class Initialized
INFO - 2024-02-04 23:59:32 --> Loader Class Initialized
INFO - 2024-02-04 23:59:32 --> Helper loaded: url_helper
INFO - 2024-02-04 23:59:32 --> Helper loaded: file_helper
INFO - 2024-02-04 23:59:32 --> Helper loaded: security_helper
INFO - 2024-02-04 23:59:32 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:59:32 --> Database Driver Class Initialized
INFO - 2024-02-04 23:59:32 --> Email Class Initialized
DEBUG - 2024-02-04 23:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:59:32 --> Helper loaded: form_helper
INFO - 2024-02-04 23:59:32 --> Form Validation Class Initialized
INFO - 2024-02-04 23:59:32 --> Controller Class Initialized
INFO - 2024-02-04 23:59:32 --> Model "User_model" initialized
INFO - 2024-02-04 23:59:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:59:33 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:59:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:59:33 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:59:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:59:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:59:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:59:33 --> Severity: Notice --> Undefined index: surat_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:59:33 --> Severity: Notice --> Undefined index: rincian_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:59:33 --> Query error: Unknown column 'surat_permintaan' in 'field list' - Invalid query: UPDATE `tbl_pesanan` SET `id_pesanan` = NULL, `id_permintaan` = '18', `id_supplier` = '2', `id_jenis_faktur` = '2', `surat_pesanan` = NULL, `uraian` = NULL, `tanggal_surat` = NULL, `nip` = '13132', `unit` = 'Admin', `file_pesanan` = NULL, `surat_permintaan` = NULL, `rincian_permintaan` = NULL, `tanggal_permintaan` = '2024-02-04', `file_permintaan` = 'time_schedule_pembongkaran_poli.pdf'
WHERE `id_permintaan` = '18'
INFO - 2024-02-04 23:59:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-02-04 23:59:42 --> Config Class Initialized
INFO - 2024-02-04 23:59:42 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:59:42 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:59:42 --> Utf8 Class Initialized
INFO - 2024-02-04 23:59:42 --> URI Class Initialized
INFO - 2024-02-04 23:59:42 --> Router Class Initialized
INFO - 2024-02-04 23:59:42 --> Output Class Initialized
INFO - 2024-02-04 23:59:42 --> Security Class Initialized
DEBUG - 2024-02-04 23:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:59:42 --> Input Class Initialized
INFO - 2024-02-04 23:59:42 --> Language Class Initialized
INFO - 2024-02-04 23:59:42 --> Loader Class Initialized
INFO - 2024-02-04 23:59:42 --> Helper loaded: url_helper
INFO - 2024-02-04 23:59:42 --> Helper loaded: file_helper
INFO - 2024-02-04 23:59:42 --> Helper loaded: security_helper
INFO - 2024-02-04 23:59:42 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:59:42 --> Database Driver Class Initialized
INFO - 2024-02-04 23:59:42 --> Email Class Initialized
DEBUG - 2024-02-04 23:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:59:42 --> Helper loaded: form_helper
INFO - 2024-02-04 23:59:42 --> Form Validation Class Initialized
INFO - 2024-02-04 23:59:42 --> Controller Class Initialized
INFO - 2024-02-04 23:59:42 --> Model "User_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:59:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:59:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: surat_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: rincian_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:59:42 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:59:42 --> Query error: Unknown column 'surat_permintaan' in 'field list' - Invalid query: UPDATE `tbl_pesanan` SET `id_pesanan` = NULL, `id_permintaan` = NULL, `id_supplier` = NULL, `id_jenis_faktur` = NULL, `surat_pesanan` = NULL, `uraian` = NULL, `tanggal_surat` = NULL, `nip` = NULL, `unit` = NULL, `file_pesanan` = NULL, `surat_permintaan` = NULL, `rincian_permintaan` = NULL, `tanggal_permintaan` = '2024-02-04', `file_permintaan` = NULL
WHERE `id_permintaan` IS NULL
INFO - 2024-02-04 23:59:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-02-04 23:59:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\simba\system\core\Exceptions.php:271) C:\xampp\htdocs\simba\system\core\Common.php 570
INFO - 2024-02-04 23:59:43 --> Config Class Initialized
INFO - 2024-02-04 23:59:43 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:59:43 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:59:43 --> Utf8 Class Initialized
INFO - 2024-02-04 23:59:43 --> URI Class Initialized
INFO - 2024-02-04 23:59:43 --> Router Class Initialized
INFO - 2024-02-04 23:59:43 --> Output Class Initialized
INFO - 2024-02-04 23:59:43 --> Security Class Initialized
DEBUG - 2024-02-04 23:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:59:43 --> Input Class Initialized
INFO - 2024-02-04 23:59:43 --> Language Class Initialized
INFO - 2024-02-04 23:59:43 --> Loader Class Initialized
INFO - 2024-02-04 23:59:43 --> Helper loaded: url_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: file_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: security_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:59:43 --> Database Driver Class Initialized
INFO - 2024-02-04 23:59:43 --> Email Class Initialized
DEBUG - 2024-02-04 23:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:59:43 --> Helper loaded: form_helper
INFO - 2024-02-04 23:59:43 --> Form Validation Class Initialized
INFO - 2024-02-04 23:59:43 --> Controller Class Initialized
INFO - 2024-02-04 23:59:43 --> Model "User_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:59:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:59:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:59:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:59:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:59:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:59:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:59:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:59:43 --> Final output sent to browser
DEBUG - 2024-02-04 23:59:43 --> Total execution time: 0.0675
INFO - 2024-02-04 23:59:43 --> Config Class Initialized
INFO - 2024-02-04 23:59:43 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:59:43 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:59:43 --> Utf8 Class Initialized
INFO - 2024-02-04 23:59:43 --> URI Class Initialized
INFO - 2024-02-04 23:59:43 --> Router Class Initialized
INFO - 2024-02-04 23:59:43 --> Output Class Initialized
INFO - 2024-02-04 23:59:43 --> Security Class Initialized
DEBUG - 2024-02-04 23:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:59:43 --> Input Class Initialized
INFO - 2024-02-04 23:59:43 --> Language Class Initialized
INFO - 2024-02-04 23:59:43 --> Loader Class Initialized
INFO - 2024-02-04 23:59:43 --> Helper loaded: url_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: file_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: security_helper
INFO - 2024-02-04 23:59:43 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:59:43 --> Database Driver Class Initialized
INFO - 2024-02-04 23:59:44 --> Email Class Initialized
DEBUG - 2024-02-04 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:59:44 --> Helper loaded: form_helper
INFO - 2024-02-04 23:59:44 --> Form Validation Class Initialized
INFO - 2024-02-04 23:59:44 --> Controller Class Initialized
INFO - 2024-02-04 23:59:44 --> Model "User_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-04 23:59:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-04 23:59:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-04 23:59:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-04 23:59:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-04 23:59:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-04 23:59:44 --> Final output sent to browser
DEBUG - 2024-02-04 23:59:44 --> Total execution time: 0.0704
INFO - 2024-02-04 23:59:44 --> Config Class Initialized
INFO - 2024-02-04 23:59:44 --> Hooks Class Initialized
DEBUG - 2024-02-04 23:59:44 --> UTF-8 Support Enabled
INFO - 2024-02-04 23:59:44 --> Utf8 Class Initialized
INFO - 2024-02-04 23:59:44 --> URI Class Initialized
INFO - 2024-02-04 23:59:44 --> Router Class Initialized
INFO - 2024-02-04 23:59:44 --> Output Class Initialized
INFO - 2024-02-04 23:59:44 --> Security Class Initialized
DEBUG - 2024-02-04 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-04 23:59:44 --> Input Class Initialized
INFO - 2024-02-04 23:59:44 --> Language Class Initialized
INFO - 2024-02-04 23:59:44 --> Loader Class Initialized
INFO - 2024-02-04 23:59:44 --> Helper loaded: url_helper
INFO - 2024-02-04 23:59:44 --> Helper loaded: file_helper
INFO - 2024-02-04 23:59:44 --> Helper loaded: security_helper
INFO - 2024-02-04 23:59:44 --> Helper loaded: wpu_helper
INFO - 2024-02-04 23:59:44 --> Database Driver Class Initialized
INFO - 2024-02-04 23:59:44 --> Email Class Initialized
DEBUG - 2024-02-04 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-04 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-04 23:59:44 --> Helper loaded: form_helper
INFO - 2024-02-04 23:59:44 --> Form Validation Class Initialized
INFO - 2024-02-04 23:59:44 --> Controller Class Initialized
INFO - 2024-02-04 23:59:44 --> Model "User_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Faktur_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Supplier_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-04 23:59:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-04 23:59:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: surat_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: rincian_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-04 23:59:44 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
ERROR - 2024-02-04 23:59:44 --> Query error: Unknown column 'surat_permintaan' in 'field list' - Invalid query: UPDATE `tbl_pesanan` SET `id_pesanan` = NULL, `id_permintaan` = NULL, `id_supplier` = NULL, `id_jenis_faktur` = NULL, `surat_pesanan` = NULL, `uraian` = NULL, `tanggal_surat` = NULL, `nip` = NULL, `unit` = NULL, `file_pesanan` = NULL, `surat_permintaan` = NULL, `rincian_permintaan` = NULL, `tanggal_permintaan` = '2024-02-04', `file_permintaan` = NULL
WHERE `id_permintaan` IS NULL
INFO - 2024-02-04 23:59:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-02-04 23:59:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\simba\system\core\Exceptions.php:271) C:\xampp\htdocs\simba\system\core\Common.php 570
