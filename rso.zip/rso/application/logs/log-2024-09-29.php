<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-29 00:49:52 --> Config Class Initialized
INFO - 2024-09-29 00:49:52 --> Hooks Class Initialized
DEBUG - 2024-09-29 00:49:52 --> UTF-8 Support Enabled
INFO - 2024-09-29 00:49:52 --> Utf8 Class Initialized
INFO - 2024-09-29 00:49:52 --> URI Class Initialized
DEBUG - 2024-09-29 00:49:52 --> No URI present. Default controller set.
INFO - 2024-09-29 00:49:52 --> Router Class Initialized
INFO - 2024-09-29 00:49:52 --> Output Class Initialized
INFO - 2024-09-29 00:49:52 --> Security Class Initialized
DEBUG - 2024-09-29 00:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 00:49:52 --> Input Class Initialized
INFO - 2024-09-29 00:49:52 --> Language Class Initialized
INFO - 2024-09-29 00:49:52 --> Loader Class Initialized
INFO - 2024-09-29 00:49:52 --> Helper loaded: url_helper
INFO - 2024-09-29 00:49:52 --> Helper loaded: file_helper
INFO - 2024-09-29 00:49:52 --> Helper loaded: security_helper
INFO - 2024-09-29 00:49:52 --> Helper loaded: wpu_helper
INFO - 2024-09-29 00:49:52 --> Database Driver Class Initialized
INFO - 2024-09-29 14:13:29 --> Config Class Initialized
INFO - 2024-09-29 14:13:29 --> Hooks Class Initialized
DEBUG - 2024-09-29 14:13:29 --> UTF-8 Support Enabled
INFO - 2024-09-29 14:13:29 --> Utf8 Class Initialized
INFO - 2024-09-29 14:13:29 --> URI Class Initialized
DEBUG - 2024-09-29 14:13:29 --> No URI present. Default controller set.
INFO - 2024-09-29 14:13:29 --> Router Class Initialized
INFO - 2024-09-29 14:13:29 --> Output Class Initialized
INFO - 2024-09-29 14:13:29 --> Security Class Initialized
DEBUG - 2024-09-29 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 14:13:29 --> Input Class Initialized
INFO - 2024-09-29 14:13:29 --> Language Class Initialized
INFO - 2024-09-29 14:13:29 --> Loader Class Initialized
INFO - 2024-09-29 14:13:29 --> Helper loaded: url_helper
INFO - 2024-09-29 14:13:29 --> Helper loaded: file_helper
INFO - 2024-09-29 14:13:29 --> Helper loaded: security_helper
INFO - 2024-09-29 14:13:29 --> Helper loaded: wpu_helper
INFO - 2024-09-29 14:13:29 --> Database Driver Class Initialized
INFO - 2024-09-29 14:15:52 --> Config Class Initialized
INFO - 2024-09-29 14:15:52 --> Hooks Class Initialized
DEBUG - 2024-09-29 14:15:52 --> UTF-8 Support Enabled
INFO - 2024-09-29 14:15:52 --> Utf8 Class Initialized
INFO - 2024-09-29 14:15:52 --> URI Class Initialized
DEBUG - 2024-09-29 14:15:52 --> No URI present. Default controller set.
INFO - 2024-09-29 14:15:52 --> Router Class Initialized
INFO - 2024-09-29 14:15:52 --> Output Class Initialized
INFO - 2024-09-29 14:15:52 --> Security Class Initialized
DEBUG - 2024-09-29 14:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 14:15:52 --> Input Class Initialized
INFO - 2024-09-29 14:15:52 --> Language Class Initialized
INFO - 2024-09-29 14:15:52 --> Loader Class Initialized
INFO - 2024-09-29 14:15:52 --> Helper loaded: url_helper
INFO - 2024-09-29 14:15:52 --> Helper loaded: file_helper
INFO - 2024-09-29 14:15:52 --> Helper loaded: security_helper
INFO - 2024-09-29 14:15:52 --> Helper loaded: wpu_helper
INFO - 2024-09-29 14:15:52 --> Database Driver Class Initialized
INFO - 2024-09-29 14:16:15 --> Config Class Initialized
INFO - 2024-09-29 14:16:15 --> Hooks Class Initialized
DEBUG - 2024-09-29 14:16:15 --> UTF-8 Support Enabled
INFO - 2024-09-29 14:16:15 --> Utf8 Class Initialized
INFO - 2024-09-29 14:16:15 --> URI Class Initialized
DEBUG - 2024-09-29 14:16:15 --> No URI present. Default controller set.
INFO - 2024-09-29 14:16:15 --> Router Class Initialized
INFO - 2024-09-29 14:16:15 --> Output Class Initialized
INFO - 2024-09-29 14:16:15 --> Security Class Initialized
DEBUG - 2024-09-29 14:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-29 14:16:15 --> Input Class Initialized
INFO - 2024-09-29 14:16:15 --> Language Class Initialized
INFO - 2024-09-29 14:16:15 --> Loader Class Initialized
INFO - 2024-09-29 14:16:15 --> Helper loaded: url_helper
INFO - 2024-09-29 14:16:15 --> Helper loaded: file_helper
INFO - 2024-09-29 14:16:15 --> Helper loaded: security_helper
INFO - 2024-09-29 14:16:15 --> Helper loaded: wpu_helper
INFO - 2024-09-29 14:16:15 --> Database Driver Class Initialized
