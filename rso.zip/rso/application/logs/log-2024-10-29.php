<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-29 08:36:54 --> Config Class Initialized
INFO - 2024-10-29 08:36:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:54 --> URI Class Initialized
DEBUG - 2024-10-29 08:36:54 --> No URI present. Default controller set.
INFO - 2024-10-29 08:36:54 --> Router Class Initialized
INFO - 2024-10-29 08:36:54 --> Output Class Initialized
INFO - 2024-10-29 08:36:54 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:54 --> Input Class Initialized
INFO - 2024-10-29 08:36:54 --> Language Class Initialized
INFO - 2024-10-29 08:36:54 --> Loader Class Initialized
INFO - 2024-10-29 08:36:54 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:54 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:54 --> Helper loaded: security_helper
INFO - 2024-10-29 08:36:54 --> Helper loaded: wpu_helper
INFO - 2024-10-29 08:36:54 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:54 --> Email Class Initialized
DEBUG - 2024-10-29 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 08:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:54 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:54 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:54 --> Controller Class Initialized
DEBUG - 2024-10-29 08:36:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 08:36:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 08:36:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 08:36:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 08:36:54 --> Final output sent to browser
DEBUG - 2024-10-29 08:36:54 --> Total execution time: 0.2475
INFO - 2024-10-29 15:36:40 --> Config Class Initialized
INFO - 2024-10-29 15:36:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 15:36:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 15:36:40 --> Utf8 Class Initialized
INFO - 2024-10-29 15:36:40 --> URI Class Initialized
DEBUG - 2024-10-29 15:36:40 --> No URI present. Default controller set.
INFO - 2024-10-29 15:36:40 --> Router Class Initialized
INFO - 2024-10-29 15:36:40 --> Output Class Initialized
INFO - 2024-10-29 15:36:40 --> Security Class Initialized
DEBUG - 2024-10-29 15:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 15:36:40 --> Input Class Initialized
INFO - 2024-10-29 15:36:40 --> Language Class Initialized
INFO - 2024-10-29 15:36:40 --> Loader Class Initialized
INFO - 2024-10-29 15:36:40 --> Helper loaded: url_helper
INFO - 2024-10-29 15:36:40 --> Helper loaded: file_helper
INFO - 2024-10-29 15:36:40 --> Helper loaded: security_helper
INFO - 2024-10-29 15:36:40 --> Helper loaded: wpu_helper
INFO - 2024-10-29 15:36:40 --> Database Driver Class Initialized
INFO - 2024-10-29 15:36:41 --> Email Class Initialized
DEBUG - 2024-10-29 15:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 15:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 15:36:41 --> Helper loaded: form_helper
INFO - 2024-10-29 15:36:41 --> Form Validation Class Initialized
INFO - 2024-10-29 15:36:41 --> Controller Class Initialized
DEBUG - 2024-10-29 15:36:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 15:36:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 15:36:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 15:36:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 15:36:41 --> Final output sent to browser
DEBUG - 2024-10-29 15:36:41 --> Total execution time: 0.2497
INFO - 2024-10-29 18:25:00 --> Config Class Initialized
INFO - 2024-10-29 18:25:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 18:25:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 18:25:00 --> Utf8 Class Initialized
INFO - 2024-10-29 18:25:00 --> URI Class Initialized
DEBUG - 2024-10-29 18:25:00 --> No URI present. Default controller set.
INFO - 2024-10-29 18:25:00 --> Router Class Initialized
INFO - 2024-10-29 18:25:00 --> Output Class Initialized
INFO - 2024-10-29 18:25:00 --> Security Class Initialized
DEBUG - 2024-10-29 18:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 18:25:00 --> Input Class Initialized
INFO - 2024-10-29 18:25:00 --> Language Class Initialized
INFO - 2024-10-29 18:25:00 --> Loader Class Initialized
INFO - 2024-10-29 18:25:00 --> Helper loaded: url_helper
INFO - 2024-10-29 18:25:00 --> Helper loaded: file_helper
INFO - 2024-10-29 18:25:00 --> Helper loaded: security_helper
INFO - 2024-10-29 18:25:00 --> Helper loaded: wpu_helper
INFO - 2024-10-29 18:25:00 --> Database Driver Class Initialized
INFO - 2024-10-29 18:25:00 --> Email Class Initialized
DEBUG - 2024-10-29 18:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 18:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 18:25:00 --> Helper loaded: form_helper
INFO - 2024-10-29 18:25:00 --> Form Validation Class Initialized
INFO - 2024-10-29 18:25:00 --> Controller Class Initialized
DEBUG - 2024-10-29 18:25:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 18:25:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 18:25:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 18:25:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 18:25:00 --> Final output sent to browser
DEBUG - 2024-10-29 18:25:00 --> Total execution time: 0.2444
INFO - 2024-10-29 18:25:32 --> Config Class Initialized
INFO - 2024-10-29 18:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 18:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 18:25:32 --> Utf8 Class Initialized
INFO - 2024-10-29 18:25:32 --> URI Class Initialized
INFO - 2024-10-29 18:25:32 --> Router Class Initialized
INFO - 2024-10-29 18:25:32 --> Output Class Initialized
INFO - 2024-10-29 18:25:32 --> Security Class Initialized
DEBUG - 2024-10-29 18:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 18:25:32 --> Input Class Initialized
INFO - 2024-10-29 18:25:32 --> Language Class Initialized
ERROR - 2024-10-29 18:25:32 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-29 18:25:35 --> Config Class Initialized
INFO - 2024-10-29 18:25:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 18:25:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 18:25:35 --> Utf8 Class Initialized
INFO - 2024-10-29 18:25:35 --> URI Class Initialized
INFO - 2024-10-29 18:25:35 --> Router Class Initialized
INFO - 2024-10-29 18:25:35 --> Output Class Initialized
INFO - 2024-10-29 18:25:35 --> Security Class Initialized
DEBUG - 2024-10-29 18:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 18:25:35 --> Input Class Initialized
INFO - 2024-10-29 18:25:35 --> Language Class Initialized
ERROR - 2024-10-29 18:25:35 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-29 18:25:37 --> Config Class Initialized
INFO - 2024-10-29 18:25:37 --> Hooks Class Initialized
DEBUG - 2024-10-29 18:25:37 --> UTF-8 Support Enabled
INFO - 2024-10-29 18:25:37 --> Utf8 Class Initialized
INFO - 2024-10-29 18:25:37 --> URI Class Initialized
INFO - 2024-10-29 18:25:37 --> Router Class Initialized
INFO - 2024-10-29 18:25:37 --> Output Class Initialized
INFO - 2024-10-29 18:25:37 --> Security Class Initialized
DEBUG - 2024-10-29 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 18:25:37 --> Input Class Initialized
INFO - 2024-10-29 18:25:37 --> Language Class Initialized
ERROR - 2024-10-29 18:25:37 --> 404 Page Not Found: Configjson/index
INFO - 2024-10-29 21:14:33 --> Config Class Initialized
INFO - 2024-10-29 21:14:33 --> Hooks Class Initialized
DEBUG - 2024-10-29 21:14:33 --> UTF-8 Support Enabled
INFO - 2024-10-29 21:14:33 --> Utf8 Class Initialized
INFO - 2024-10-29 21:14:33 --> URI Class Initialized
DEBUG - 2024-10-29 21:14:33 --> No URI present. Default controller set.
INFO - 2024-10-29 21:14:33 --> Router Class Initialized
INFO - 2024-10-29 21:14:33 --> Output Class Initialized
INFO - 2024-10-29 21:14:33 --> Security Class Initialized
DEBUG - 2024-10-29 21:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 21:14:33 --> Input Class Initialized
INFO - 2024-10-29 21:14:33 --> Language Class Initialized
INFO - 2024-10-29 21:14:33 --> Loader Class Initialized
INFO - 2024-10-29 21:14:33 --> Helper loaded: url_helper
INFO - 2024-10-29 21:14:33 --> Helper loaded: file_helper
INFO - 2024-10-29 21:14:33 --> Helper loaded: security_helper
INFO - 2024-10-29 21:14:33 --> Helper loaded: wpu_helper
INFO - 2024-10-29 21:14:33 --> Database Driver Class Initialized
INFO - 2024-10-29 21:14:33 --> Email Class Initialized
DEBUG - 2024-10-29 21:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 21:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 21:14:33 --> Helper loaded: form_helper
INFO - 2024-10-29 21:14:33 --> Form Validation Class Initialized
INFO - 2024-10-29 21:14:33 --> Controller Class Initialized
DEBUG - 2024-10-29 21:14:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 21:14:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 21:14:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 21:14:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 21:14:33 --> Final output sent to browser
DEBUG - 2024-10-29 21:14:33 --> Total execution time: 0.2536
INFO - 2024-10-29 21:53:02 --> Config Class Initialized
INFO - 2024-10-29 21:53:02 --> Hooks Class Initialized
DEBUG - 2024-10-29 21:53:02 --> UTF-8 Support Enabled
INFO - 2024-10-29 21:53:02 --> Utf8 Class Initialized
INFO - 2024-10-29 21:53:02 --> URI Class Initialized
DEBUG - 2024-10-29 21:53:02 --> No URI present. Default controller set.
INFO - 2024-10-29 21:53:02 --> Router Class Initialized
INFO - 2024-10-29 21:53:02 --> Output Class Initialized
INFO - 2024-10-29 21:53:02 --> Security Class Initialized
DEBUG - 2024-10-29 21:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 21:53:02 --> Input Class Initialized
INFO - 2024-10-29 21:53:02 --> Language Class Initialized
INFO - 2024-10-29 21:53:02 --> Loader Class Initialized
INFO - 2024-10-29 21:53:02 --> Helper loaded: url_helper
INFO - 2024-10-29 21:53:02 --> Helper loaded: file_helper
INFO - 2024-10-29 21:53:02 --> Helper loaded: security_helper
INFO - 2024-10-29 21:53:02 --> Helper loaded: wpu_helper
INFO - 2024-10-29 21:53:02 --> Database Driver Class Initialized
INFO - 2024-10-29 21:53:02 --> Email Class Initialized
DEBUG - 2024-10-29 21:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 21:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 21:53:02 --> Helper loaded: form_helper
INFO - 2024-10-29 21:53:02 --> Form Validation Class Initialized
INFO - 2024-10-29 21:53:02 --> Controller Class Initialized
DEBUG - 2024-10-29 21:53:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 21:53:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 21:53:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 21:53:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 21:53:02 --> Final output sent to browser
DEBUG - 2024-10-29 21:53:02 --> Total execution time: 0.2631
INFO - 2024-10-29 21:53:06 --> Config Class Initialized
INFO - 2024-10-29 21:53:06 --> Hooks Class Initialized
DEBUG - 2024-10-29 21:53:06 --> UTF-8 Support Enabled
INFO - 2024-10-29 21:53:06 --> Utf8 Class Initialized
INFO - 2024-10-29 21:53:06 --> URI Class Initialized
DEBUG - 2024-10-29 21:53:06 --> No URI present. Default controller set.
INFO - 2024-10-29 21:53:06 --> Router Class Initialized
INFO - 2024-10-29 21:53:06 --> Output Class Initialized
INFO - 2024-10-29 21:53:06 --> Security Class Initialized
DEBUG - 2024-10-29 21:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 21:53:06 --> Input Class Initialized
INFO - 2024-10-29 21:53:06 --> Language Class Initialized
INFO - 2024-10-29 21:53:06 --> Loader Class Initialized
INFO - 2024-10-29 21:53:06 --> Helper loaded: url_helper
INFO - 2024-10-29 21:53:06 --> Helper loaded: file_helper
INFO - 2024-10-29 21:53:06 --> Helper loaded: security_helper
INFO - 2024-10-29 21:53:06 --> Helper loaded: wpu_helper
INFO - 2024-10-29 21:53:06 --> Database Driver Class Initialized
INFO - 2024-10-29 21:53:06 --> Email Class Initialized
DEBUG - 2024-10-29 21:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 21:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 21:53:06 --> Helper loaded: form_helper
INFO - 2024-10-29 21:53:06 --> Form Validation Class Initialized
INFO - 2024-10-29 21:53:06 --> Controller Class Initialized
DEBUG - 2024-10-29 21:53:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 21:53:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-29 21:53:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-29 21:53:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-29 21:53:06 --> Final output sent to browser
DEBUG - 2024-10-29 21:53:06 --> Total execution time: 0.2485
INFO - 2024-10-29 21:53:07 --> Config Class Initialized
INFO - 2024-10-29 21:53:07 --> Hooks Class Initialized
DEBUG - 2024-10-29 21:53:07 --> UTF-8 Support Enabled
INFO - 2024-10-29 21:53:07 --> Utf8 Class Initialized
INFO - 2024-10-29 21:53:07 --> URI Class Initialized
INFO - 2024-10-29 21:53:07 --> Router Class Initialized
INFO - 2024-10-29 21:53:07 --> Output Class Initialized
INFO - 2024-10-29 21:53:07 --> Security Class Initialized
DEBUG - 2024-10-29 21:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 21:53:07 --> Input Class Initialized
INFO - 2024-10-29 21:53:07 --> Language Class Initialized
INFO - 2024-10-29 21:53:07 --> Loader Class Initialized
INFO - 2024-10-29 21:53:07 --> Helper loaded: url_helper
INFO - 2024-10-29 21:53:07 --> Helper loaded: file_helper
INFO - 2024-10-29 21:53:07 --> Helper loaded: security_helper
INFO - 2024-10-29 21:53:07 --> Helper loaded: wpu_helper
INFO - 2024-10-29 21:53:07 --> Database Driver Class Initialized
INFO - 2024-10-29 21:53:07 --> Email Class Initialized
DEBUG - 2024-10-29 21:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 21:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 21:53:07 --> Helper loaded: form_helper
INFO - 2024-10-29 21:53:07 --> Form Validation Class Initialized
INFO - 2024-10-29 21:53:07 --> Controller Class Initialized
DEBUG - 2024-10-29 21:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 21:53:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-29 21:53:08 --> Config Class Initialized
INFO - 2024-10-29 21:53:08 --> Hooks Class Initialized
DEBUG - 2024-10-29 21:53:08 --> UTF-8 Support Enabled
INFO - 2024-10-29 21:53:08 --> Utf8 Class Initialized
INFO - 2024-10-29 21:53:08 --> URI Class Initialized
INFO - 2024-10-29 21:53:08 --> Router Class Initialized
INFO - 2024-10-29 21:53:08 --> Output Class Initialized
INFO - 2024-10-29 21:53:08 --> Security Class Initialized
DEBUG - 2024-10-29 21:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 21:53:08 --> Input Class Initialized
INFO - 2024-10-29 21:53:08 --> Language Class Initialized
INFO - 2024-10-29 21:53:08 --> Loader Class Initialized
INFO - 2024-10-29 21:53:08 --> Helper loaded: url_helper
INFO - 2024-10-29 21:53:08 --> Helper loaded: file_helper
INFO - 2024-10-29 21:53:08 --> Helper loaded: security_helper
INFO - 2024-10-29 21:53:08 --> Helper loaded: wpu_helper
INFO - 2024-10-29 21:53:08 --> Database Driver Class Initialized
INFO - 2024-10-29 21:53:08 --> Email Class Initialized
DEBUG - 2024-10-29 21:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-29 21:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 21:53:08 --> Helper loaded: form_helper
INFO - 2024-10-29 21:53:08 --> Form Validation Class Initialized
INFO - 2024-10-29 21:53:08 --> Controller Class Initialized
INFO - 2024-10-29 21:53:08 --> Model "Antrol_model" initialized
DEBUG - 2024-10-29 21:53:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-29 21:53:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-29 21:53:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-29 21:53:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-29 21:53:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-29 21:53:08 --> Final output sent to browser
DEBUG - 2024-10-29 21:53:08 --> Total execution time: 0.7325
