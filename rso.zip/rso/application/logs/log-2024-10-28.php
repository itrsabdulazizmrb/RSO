<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-28 05:49:46 --> Config Class Initialized
INFO - 2024-10-28 05:49:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:49:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:49:46 --> Utf8 Class Initialized
INFO - 2024-10-28 05:49:46 --> URI Class Initialized
INFO - 2024-10-28 05:49:46 --> Router Class Initialized
INFO - 2024-10-28 05:49:46 --> Output Class Initialized
INFO - 2024-10-28 05:49:46 --> Security Class Initialized
DEBUG - 2024-10-28 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:49:46 --> Input Class Initialized
INFO - 2024-10-28 05:49:46 --> Language Class Initialized
INFO - 2024-10-28 05:49:46 --> Loader Class Initialized
INFO - 2024-10-28 05:49:46 --> Helper loaded: url_helper
INFO - 2024-10-28 05:49:46 --> Helper loaded: file_helper
INFO - 2024-10-28 05:49:46 --> Helper loaded: security_helper
INFO - 2024-10-28 05:49:46 --> Helper loaded: wpu_helper
INFO - 2024-10-28 05:49:46 --> Database Driver Class Initialized
INFO - 2024-10-28 05:49:46 --> Email Class Initialized
DEBUG - 2024-10-28 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:49:46 --> Helper loaded: form_helper
INFO - 2024-10-28 05:49:46 --> Form Validation Class Initialized
INFO - 2024-10-28 05:49:46 --> Controller Class Initialized
INFO - 2024-10-28 05:49:47 --> Config Class Initialized
INFO - 2024-10-28 05:49:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:49:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:49:47 --> Utf8 Class Initialized
INFO - 2024-10-28 05:49:47 --> URI Class Initialized
INFO - 2024-10-28 05:49:47 --> Router Class Initialized
INFO - 2024-10-28 05:49:47 --> Output Class Initialized
INFO - 2024-10-28 05:49:47 --> Security Class Initialized
DEBUG - 2024-10-28 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:49:47 --> Input Class Initialized
INFO - 2024-10-28 05:49:47 --> Language Class Initialized
INFO - 2024-10-28 05:49:47 --> Loader Class Initialized
INFO - 2024-10-28 05:49:47 --> Helper loaded: url_helper
INFO - 2024-10-28 05:49:47 --> Helper loaded: file_helper
INFO - 2024-10-28 05:49:47 --> Helper loaded: security_helper
INFO - 2024-10-28 05:49:47 --> Helper loaded: wpu_helper
INFO - 2024-10-28 05:49:48 --> Database Driver Class Initialized
INFO - 2024-10-28 05:49:48 --> Email Class Initialized
DEBUG - 2024-10-28 05:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:49:48 --> Helper loaded: form_helper
INFO - 2024-10-28 05:49:48 --> Form Validation Class Initialized
INFO - 2024-10-28 05:49:48 --> Controller Class Initialized
DEBUG - 2024-10-28 05:49:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 05:49:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-28 05:49:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-28 05:49:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-28 05:49:48 --> Final output sent to browser
DEBUG - 2024-10-28 05:49:48 --> Total execution time: 0.2656
INFO - 2024-10-28 05:50:04 --> Config Class Initialized
INFO - 2024-10-28 05:50:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:50:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:50:04 --> Utf8 Class Initialized
INFO - 2024-10-28 05:50:04 --> URI Class Initialized
INFO - 2024-10-28 05:50:04 --> Router Class Initialized
INFO - 2024-10-28 05:50:04 --> Output Class Initialized
INFO - 2024-10-28 05:50:04 --> Security Class Initialized
DEBUG - 2024-10-28 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:50:04 --> Input Class Initialized
INFO - 2024-10-28 05:50:04 --> Language Class Initialized
INFO - 2024-10-28 05:50:04 --> Loader Class Initialized
INFO - 2024-10-28 05:50:04 --> Helper loaded: url_helper
INFO - 2024-10-28 05:50:04 --> Helper loaded: file_helper
INFO - 2024-10-28 05:50:04 --> Helper loaded: security_helper
INFO - 2024-10-28 05:50:04 --> Helper loaded: wpu_helper
INFO - 2024-10-28 05:50:04 --> Database Driver Class Initialized
INFO - 2024-10-28 05:50:04 --> Email Class Initialized
DEBUG - 2024-10-28 05:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:50:04 --> Helper loaded: form_helper
INFO - 2024-10-28 05:50:04 --> Form Validation Class Initialized
INFO - 2024-10-28 05:50:04 --> Controller Class Initialized
DEBUG - 2024-10-28 05:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 05:50:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-28 05:50:06 --> Config Class Initialized
INFO - 2024-10-28 05:50:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:50:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:50:06 --> Utf8 Class Initialized
INFO - 2024-10-28 05:50:06 --> URI Class Initialized
INFO - 2024-10-28 05:50:06 --> Router Class Initialized
INFO - 2024-10-28 05:50:06 --> Output Class Initialized
INFO - 2024-10-28 05:50:06 --> Security Class Initialized
DEBUG - 2024-10-28 05:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:50:06 --> Input Class Initialized
INFO - 2024-10-28 05:50:06 --> Language Class Initialized
INFO - 2024-10-28 05:50:06 --> Loader Class Initialized
INFO - 2024-10-28 05:50:06 --> Helper loaded: url_helper
INFO - 2024-10-28 05:50:06 --> Helper loaded: file_helper
INFO - 2024-10-28 05:50:06 --> Helper loaded: security_helper
INFO - 2024-10-28 05:50:06 --> Helper loaded: wpu_helper
INFO - 2024-10-28 05:50:06 --> Database Driver Class Initialized
INFO - 2024-10-28 05:50:06 --> Email Class Initialized
DEBUG - 2024-10-28 05:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:50:06 --> Helper loaded: form_helper
INFO - 2024-10-28 05:50:06 --> Form Validation Class Initialized
INFO - 2024-10-28 05:50:06 --> Controller Class Initialized
INFO - 2024-10-28 05:50:06 --> Model "Antrol_model" initialized
DEBUG - 2024-10-28 05:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 05:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-28 05:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-28 05:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-28 05:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-28 05:50:07 --> Final output sent to browser
DEBUG - 2024-10-28 05:50:07 --> Total execution time: 0.7445
INFO - 2024-10-28 08:36:31 --> Config Class Initialized
INFO - 2024-10-28 08:36:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:36:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:36:31 --> Utf8 Class Initialized
INFO - 2024-10-28 08:36:31 --> URI Class Initialized
DEBUG - 2024-10-28 08:36:31 --> No URI present. Default controller set.
INFO - 2024-10-28 08:36:31 --> Router Class Initialized
INFO - 2024-10-28 08:36:31 --> Output Class Initialized
INFO - 2024-10-28 08:36:31 --> Security Class Initialized
DEBUG - 2024-10-28 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:36:31 --> Input Class Initialized
INFO - 2024-10-28 08:36:31 --> Language Class Initialized
INFO - 2024-10-28 08:36:31 --> Loader Class Initialized
INFO - 2024-10-28 08:36:31 --> Helper loaded: url_helper
INFO - 2024-10-28 08:36:31 --> Helper loaded: file_helper
INFO - 2024-10-28 08:36:31 --> Helper loaded: security_helper
INFO - 2024-10-28 08:36:31 --> Helper loaded: wpu_helper
INFO - 2024-10-28 08:36:31 --> Database Driver Class Initialized
INFO - 2024-10-28 08:36:31 --> Email Class Initialized
DEBUG - 2024-10-28 08:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 08:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:36:31 --> Helper loaded: form_helper
INFO - 2024-10-28 08:36:31 --> Form Validation Class Initialized
INFO - 2024-10-28 08:36:31 --> Controller Class Initialized
DEBUG - 2024-10-28 08:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 08:36:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-28 08:36:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-28 08:36:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-28 08:36:31 --> Final output sent to browser
DEBUG - 2024-10-28 08:36:31 --> Total execution time: 0.2645
INFO - 2024-10-28 15:00:11 --> Config Class Initialized
INFO - 2024-10-28 15:00:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 15:00:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 15:00:11 --> Utf8 Class Initialized
INFO - 2024-10-28 15:00:11 --> URI Class Initialized
DEBUG - 2024-10-28 15:00:11 --> No URI present. Default controller set.
INFO - 2024-10-28 15:00:11 --> Router Class Initialized
INFO - 2024-10-28 15:00:11 --> Output Class Initialized
INFO - 2024-10-28 15:00:11 --> Security Class Initialized
DEBUG - 2024-10-28 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 15:00:11 --> Input Class Initialized
INFO - 2024-10-28 15:00:11 --> Language Class Initialized
INFO - 2024-10-28 15:00:11 --> Loader Class Initialized
INFO - 2024-10-28 15:00:11 --> Helper loaded: url_helper
INFO - 2024-10-28 15:00:11 --> Helper loaded: file_helper
INFO - 2024-10-28 15:00:11 --> Helper loaded: security_helper
INFO - 2024-10-28 15:00:11 --> Helper loaded: wpu_helper
INFO - 2024-10-28 15:00:11 --> Database Driver Class Initialized
INFO - 2024-10-28 15:00:12 --> Email Class Initialized
DEBUG - 2024-10-28 15:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 15:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 15:00:12 --> Helper loaded: form_helper
INFO - 2024-10-28 15:00:12 --> Form Validation Class Initialized
INFO - 2024-10-28 15:00:12 --> Controller Class Initialized
DEBUG - 2024-10-28 15:00:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 15:00:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-28 15:00:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-28 15:00:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-28 15:00:12 --> Final output sent to browser
DEBUG - 2024-10-28 15:00:12 --> Total execution time: 0.2558
INFO - 2024-10-28 19:50:06 --> Config Class Initialized
INFO - 2024-10-28 19:50:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 19:50:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 19:50:06 --> Utf8 Class Initialized
INFO - 2024-10-28 19:50:06 --> URI Class Initialized
DEBUG - 2024-10-28 19:50:06 --> No URI present. Default controller set.
INFO - 2024-10-28 19:50:06 --> Router Class Initialized
INFO - 2024-10-28 19:50:06 --> Output Class Initialized
INFO - 2024-10-28 19:50:06 --> Security Class Initialized
DEBUG - 2024-10-28 19:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 19:50:06 --> Input Class Initialized
INFO - 2024-10-28 19:50:06 --> Language Class Initialized
INFO - 2024-10-28 19:50:06 --> Loader Class Initialized
INFO - 2024-10-28 19:50:06 --> Helper loaded: url_helper
INFO - 2024-10-28 19:50:06 --> Helper loaded: file_helper
INFO - 2024-10-28 19:50:06 --> Helper loaded: security_helper
INFO - 2024-10-28 19:50:06 --> Helper loaded: wpu_helper
INFO - 2024-10-28 19:50:06 --> Database Driver Class Initialized
INFO - 2024-10-28 19:50:07 --> Email Class Initialized
DEBUG - 2024-10-28 19:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 19:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 19:50:07 --> Helper loaded: form_helper
INFO - 2024-10-28 19:50:07 --> Form Validation Class Initialized
INFO - 2024-10-28 19:50:07 --> Controller Class Initialized
DEBUG - 2024-10-28 19:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 19:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-28 19:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-28 19:50:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-28 19:50:07 --> Final output sent to browser
DEBUG - 2024-10-28 19:50:07 --> Total execution time: 0.2542
INFO - 2024-10-28 19:50:35 --> Config Class Initialized
INFO - 2024-10-28 19:50:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 19:50:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 19:50:35 --> Utf8 Class Initialized
INFO - 2024-10-28 19:50:35 --> URI Class Initialized
DEBUG - 2024-10-28 19:50:35 --> No URI present. Default controller set.
INFO - 2024-10-28 19:50:35 --> Router Class Initialized
INFO - 2024-10-28 19:50:35 --> Output Class Initialized
INFO - 2024-10-28 19:50:35 --> Security Class Initialized
DEBUG - 2024-10-28 19:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 19:50:35 --> Input Class Initialized
INFO - 2024-10-28 19:50:35 --> Language Class Initialized
INFO - 2024-10-28 19:50:35 --> Loader Class Initialized
INFO - 2024-10-28 19:50:35 --> Helper loaded: url_helper
INFO - 2024-10-28 19:50:35 --> Helper loaded: file_helper
INFO - 2024-10-28 19:50:35 --> Helper loaded: security_helper
INFO - 2024-10-28 19:50:35 --> Helper loaded: wpu_helper
INFO - 2024-10-28 19:50:35 --> Database Driver Class Initialized
INFO - 2024-10-28 19:50:35 --> Email Class Initialized
DEBUG - 2024-10-28 19:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-28 19:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 19:50:35 --> Helper loaded: form_helper
INFO - 2024-10-28 19:50:35 --> Form Validation Class Initialized
INFO - 2024-10-28 19:50:35 --> Controller Class Initialized
DEBUG - 2024-10-28 19:50:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-28 19:50:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-28 19:50:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-28 19:50:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-28 19:50:35 --> Final output sent to browser
DEBUG - 2024-10-28 19:50:35 --> Total execution time: 0.2461
