<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-04 00:46:57 --> Config Class Initialized
INFO - 2024-11-04 00:46:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 00:46:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 00:46:57 --> Utf8 Class Initialized
INFO - 2024-11-04 00:46:57 --> URI Class Initialized
DEBUG - 2024-11-04 00:46:57 --> No URI present. Default controller set.
INFO - 2024-11-04 00:46:57 --> Router Class Initialized
INFO - 2024-11-04 00:46:57 --> Output Class Initialized
INFO - 2024-11-04 00:46:57 --> Security Class Initialized
DEBUG - 2024-11-04 00:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 00:46:57 --> Input Class Initialized
INFO - 2024-11-04 00:46:57 --> Language Class Initialized
INFO - 2024-11-04 00:46:57 --> Loader Class Initialized
INFO - 2024-11-04 00:46:57 --> Helper loaded: url_helper
INFO - 2024-11-04 00:46:57 --> Helper loaded: file_helper
INFO - 2024-11-04 00:46:57 --> Helper loaded: security_helper
INFO - 2024-11-04 00:46:57 --> Helper loaded: wpu_helper
INFO - 2024-11-04 00:46:57 --> Database Driver Class Initialized
ERROR - 2024-11-04 00:47:04 --> Unable to connect to the database
INFO - 2024-11-04 00:47:04 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-04 00:52:17 --> Config Class Initialized
INFO - 2024-11-04 00:52:17 --> Hooks Class Initialized
DEBUG - 2024-11-04 00:52:17 --> UTF-8 Support Enabled
INFO - 2024-11-04 00:52:17 --> Utf8 Class Initialized
INFO - 2024-11-04 00:52:17 --> URI Class Initialized
DEBUG - 2024-11-04 00:52:17 --> No URI present. Default controller set.
INFO - 2024-11-04 00:52:17 --> Router Class Initialized
INFO - 2024-11-04 00:52:17 --> Output Class Initialized
INFO - 2024-11-04 00:52:17 --> Security Class Initialized
DEBUG - 2024-11-04 00:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 00:52:17 --> Input Class Initialized
INFO - 2024-11-04 00:52:17 --> Language Class Initialized
INFO - 2024-11-04 00:52:17 --> Loader Class Initialized
INFO - 2024-11-04 00:52:17 --> Helper loaded: url_helper
INFO - 2024-11-04 00:52:17 --> Helper loaded: file_helper
INFO - 2024-11-04 00:52:17 --> Helper loaded: security_helper
INFO - 2024-11-04 00:52:17 --> Helper loaded: wpu_helper
INFO - 2024-11-04 00:52:17 --> Database Driver Class Initialized
ERROR - 2024-11-04 00:52:24 --> Unable to connect to the database
INFO - 2024-11-04 00:52:24 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-04 00:55:04 --> Config Class Initialized
INFO - 2024-11-04 00:55:04 --> Hooks Class Initialized
DEBUG - 2024-11-04 00:55:04 --> UTF-8 Support Enabled
INFO - 2024-11-04 00:55:04 --> Utf8 Class Initialized
INFO - 2024-11-04 00:55:04 --> URI Class Initialized
DEBUG - 2024-11-04 00:55:04 --> No URI present. Default controller set.
INFO - 2024-11-04 00:55:04 --> Router Class Initialized
INFO - 2024-11-04 00:55:04 --> Output Class Initialized
INFO - 2024-11-04 00:55:04 --> Security Class Initialized
DEBUG - 2024-11-04 00:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 00:55:04 --> Input Class Initialized
INFO - 2024-11-04 00:55:04 --> Language Class Initialized
INFO - 2024-11-04 00:55:04 --> Loader Class Initialized
INFO - 2024-11-04 00:55:04 --> Helper loaded: url_helper
INFO - 2024-11-04 00:55:04 --> Helper loaded: file_helper
INFO - 2024-11-04 00:55:04 --> Helper loaded: security_helper
INFO - 2024-11-04 00:55:04 --> Helper loaded: wpu_helper
INFO - 2024-11-04 00:55:04 --> Database Driver Class Initialized
ERROR - 2024-11-04 00:55:11 --> Unable to connect to the database
INFO - 2024-11-04 00:55:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-04 01:00:29 --> Config Class Initialized
INFO - 2024-11-04 01:00:29 --> Hooks Class Initialized
DEBUG - 2024-11-04 01:00:29 --> UTF-8 Support Enabled
INFO - 2024-11-04 01:00:29 --> Utf8 Class Initialized
INFO - 2024-11-04 01:00:29 --> URI Class Initialized
DEBUG - 2024-11-04 01:00:29 --> No URI present. Default controller set.
INFO - 2024-11-04 01:00:29 --> Router Class Initialized
INFO - 2024-11-04 01:00:29 --> Output Class Initialized
INFO - 2024-11-04 01:00:29 --> Security Class Initialized
DEBUG - 2024-11-04 01:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 01:00:29 --> Input Class Initialized
INFO - 2024-11-04 01:00:29 --> Language Class Initialized
INFO - 2024-11-04 01:00:29 --> Loader Class Initialized
INFO - 2024-11-04 01:00:29 --> Helper loaded: url_helper
INFO - 2024-11-04 01:00:29 --> Helper loaded: file_helper
INFO - 2024-11-04 01:00:29 --> Helper loaded: security_helper
INFO - 2024-11-04 01:00:29 --> Helper loaded: wpu_helper
INFO - 2024-11-04 01:00:29 --> Database Driver Class Initialized
INFO - 2024-11-04 08:27:41 --> Config Class Initialized
INFO - 2024-11-04 08:27:41 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:27:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:27:41 --> Utf8 Class Initialized
INFO - 2024-11-04 08:27:41 --> URI Class Initialized
DEBUG - 2024-11-04 08:27:41 --> No URI present. Default controller set.
INFO - 2024-11-04 08:27:41 --> Router Class Initialized
INFO - 2024-11-04 08:27:41 --> Output Class Initialized
INFO - 2024-11-04 08:27:41 --> Security Class Initialized
DEBUG - 2024-11-04 08:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:27:41 --> Input Class Initialized
INFO - 2024-11-04 08:27:41 --> Language Class Initialized
INFO - 2024-11-04 08:27:41 --> Loader Class Initialized
INFO - 2024-11-04 08:27:41 --> Helper loaded: url_helper
INFO - 2024-11-04 08:27:41 --> Helper loaded: file_helper
INFO - 2024-11-04 08:27:41 --> Helper loaded: security_helper
INFO - 2024-11-04 08:27:41 --> Helper loaded: wpu_helper
INFO - 2024-11-04 08:27:41 --> Database Driver Class Initialized
ERROR - 2024-11-04 08:27:48 --> Unable to connect to the database
INFO - 2024-11-04 08:27:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-04 18:39:10 --> Config Class Initialized
INFO - 2024-11-04 18:39:10 --> Hooks Class Initialized
DEBUG - 2024-11-04 18:39:10 --> UTF-8 Support Enabled
INFO - 2024-11-04 18:39:10 --> Utf8 Class Initialized
INFO - 2024-11-04 18:39:10 --> URI Class Initialized
DEBUG - 2024-11-04 18:39:10 --> No URI present. Default controller set.
INFO - 2024-11-04 18:39:10 --> Router Class Initialized
INFO - 2024-11-04 18:39:10 --> Output Class Initialized
INFO - 2024-11-04 18:39:10 --> Security Class Initialized
DEBUG - 2024-11-04 18:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 18:39:10 --> Input Class Initialized
INFO - 2024-11-04 18:39:10 --> Language Class Initialized
INFO - 2024-11-04 18:39:10 --> Loader Class Initialized
INFO - 2024-11-04 18:39:10 --> Helper loaded: url_helper
INFO - 2024-11-04 18:39:10 --> Helper loaded: file_helper
INFO - 2024-11-04 18:39:10 --> Helper loaded: security_helper
INFO - 2024-11-04 18:39:10 --> Helper loaded: wpu_helper
INFO - 2024-11-04 18:39:10 --> Database Driver Class Initialized
ERROR - 2024-11-04 18:39:17 --> Unable to connect to the database
INFO - 2024-11-04 18:39:17 --> Language file loaded: language/english/db_lang.php
