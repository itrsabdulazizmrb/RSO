<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-27 00:00:27 --> Config Class Initialized
INFO - 2024-02-27 00:00:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:27 --> URI Class Initialized
INFO - 2024-02-27 00:00:27 --> Router Class Initialized
INFO - 2024-02-27 00:00:27 --> Output Class Initialized
INFO - 2024-02-27 00:00:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:27 --> Input Class Initialized
INFO - 2024-02-27 00:00:27 --> Language Class Initialized
INFO - 2024-02-27 00:00:27 --> Loader Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:27 --> Email Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:27 --> Controller Class Initialized
INFO - 2024-02-27 00:00:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:00:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:00:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:00:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:00:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:00:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:27 --> Total execution time: 0.0570
INFO - 2024-02-27 00:00:27 --> Config Class Initialized
INFO - 2024-02-27 00:00:27 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:27 --> Config Class Initialized
DEBUG - 2024-02-27 00:00:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:27 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:27 --> URI Class Initialized
DEBUG - 2024-02-27 00:00:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:27 --> Router Class Initialized
INFO - 2024-02-27 00:00:27 --> Config Class Initialized
INFO - 2024-02-27 00:00:27 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:27 --> URI Class Initialized
INFO - 2024-02-27 00:00:27 --> Output Class Initialized
INFO - 2024-02-27 00:00:27 --> Router Class Initialized
INFO - 2024-02-27 00:00:27 --> Config Class Initialized
INFO - 2024-02-27 00:00:27 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:27 --> Output Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:27 --> URI Class Initialized
INFO - 2024-02-27 00:00:27 --> Input Class Initialized
INFO - 2024-02-27 00:00:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:27 --> Language Class Initialized
INFO - 2024-02-27 00:00:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:27 --> Router Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:27 --> URI Class Initialized
INFO - 2024-02-27 00:00:27 --> Input Class Initialized
INFO - 2024-02-27 00:00:27 --> Output Class Initialized
INFO - 2024-02-27 00:00:27 --> Language Class Initialized
INFO - 2024-02-27 00:00:27 --> Router Class Initialized
INFO - 2024-02-27 00:00:27 --> Loader Class Initialized
INFO - 2024-02-27 00:00:27 --> Security Class Initialized
INFO - 2024-02-27 00:00:27 --> Output Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:27 --> Loader Class Initialized
INFO - 2024-02-27 00:00:27 --> Input Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:27 --> Language Class Initialized
INFO - 2024-02-27 00:00:27 --> Security Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:27 --> Input Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:27 --> Language Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:27 --> Loader Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:27 --> Loader Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:27 --> Email Class Initialized
INFO - 2024-02-27 00:00:27 --> Email Class Initialized
INFO - 2024-02-27 00:00:27 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:27 --> Email Class Initialized
INFO - 2024-02-27 00:00:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:27 --> Controller Class Initialized
DEBUG - 2024-02-27 00:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:27 --> Email Class Initialized
INFO - 2024-02-27 00:00:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:27 --> Total execution time: 0.0582
INFO - 2024-02-27 00:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:27 --> Controller Class Initialized
INFO - 2024-02-27 00:00:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:27 --> Total execution time: 0.0693
INFO - 2024-02-27 00:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:27 --> Controller Class Initialized
INFO - 2024-02-27 00:00:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:27 --> Total execution time: 0.0780
INFO - 2024-02-27 00:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:27 --> Controller Class Initialized
INFO - 2024-02-27 00:00:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:27 --> Total execution time: 0.0903
INFO - 2024-02-27 00:00:30 --> Config Class Initialized
INFO - 2024-02-27 00:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:30 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:30 --> URI Class Initialized
INFO - 2024-02-27 00:00:30 --> Router Class Initialized
INFO - 2024-02-27 00:00:30 --> Output Class Initialized
INFO - 2024-02-27 00:00:30 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:30 --> Input Class Initialized
INFO - 2024-02-27 00:00:30 --> Language Class Initialized
INFO - 2024-02-27 00:00:30 --> Loader Class Initialized
INFO - 2024-02-27 00:00:30 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:30 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:30 --> Email Class Initialized
DEBUG - 2024-02-27 00:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:30 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:30 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:30 --> Controller Class Initialized
INFO - 2024-02-27 00:00:30 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:00:30 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:30 --> Total execution time: 0.0620
INFO - 2024-02-27 00:00:30 --> Config Class Initialized
INFO - 2024-02-27 00:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:30 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:30 --> URI Class Initialized
INFO - 2024-02-27 00:00:30 --> Router Class Initialized
INFO - 2024-02-27 00:00:30 --> Output Class Initialized
INFO - 2024-02-27 00:00:30 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:30 --> Input Class Initialized
INFO - 2024-02-27 00:00:30 --> Language Class Initialized
INFO - 2024-02-27 00:00:30 --> Loader Class Initialized
INFO - 2024-02-27 00:00:30 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:30 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:30 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:30 --> Email Class Initialized
DEBUG - 2024-02-27 00:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:30 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:30 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:30 --> Controller Class Initialized
INFO - 2024-02-27 00:00:30 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:00:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:00:30 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:30 --> Total execution time: 0.0817
INFO - 2024-02-27 00:00:33 --> Config Class Initialized
INFO - 2024-02-27 00:00:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:33 --> URI Class Initialized
INFO - 2024-02-27 00:00:33 --> Router Class Initialized
INFO - 2024-02-27 00:00:33 --> Output Class Initialized
INFO - 2024-02-27 00:00:33 --> Security Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:33 --> Input Class Initialized
INFO - 2024-02-27 00:00:33 --> Language Class Initialized
INFO - 2024-02-27 00:00:33 --> Loader Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:33 --> Controller Class Initialized
INFO - 2024-02-27 00:00:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:00:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:00:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:00:33 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:00:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:00:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:33 --> Total execution time: 0.0596
INFO - 2024-02-27 00:00:33 --> Config Class Initialized
INFO - 2024-02-27 00:00:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:33 --> URI Class Initialized
INFO - 2024-02-27 00:00:33 --> Router Class Initialized
INFO - 2024-02-27 00:00:33 --> Output Class Initialized
INFO - 2024-02-27 00:00:33 --> Security Class Initialized
INFO - 2024-02-27 00:00:33 --> Config Class Initialized
INFO - 2024-02-27 00:00:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:33 --> Input Class Initialized
INFO - 2024-02-27 00:00:33 --> Language Class Initialized
DEBUG - 2024-02-27 00:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:33 --> URI Class Initialized
INFO - 2024-02-27 00:00:33 --> Loader Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:33 --> Router Class Initialized
INFO - 2024-02-27 00:00:33 --> Config Class Initialized
INFO - 2024-02-27 00:00:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:33 --> Output Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:33 --> Config Class Initialized
DEBUG - 2024-02-27 00:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:00:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:33 --> Security Class Initialized
INFO - 2024-02-27 00:00:33 --> URI Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:00:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:00:33 --> Input Class Initialized
INFO - 2024-02-27 00:00:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:00:33 --> Language Class Initialized
INFO - 2024-02-27 00:00:33 --> Router Class Initialized
INFO - 2024-02-27 00:00:33 --> URI Class Initialized
INFO - 2024-02-27 00:00:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:33 --> Router Class Initialized
INFO - 2024-02-27 00:00:33 --> Output Class Initialized
INFO - 2024-02-27 00:00:33 --> Output Class Initialized
INFO - 2024-02-27 00:00:33 --> Loader Class Initialized
INFO - 2024-02-27 00:00:33 --> Security Class Initialized
INFO - 2024-02-27 00:00:33 --> Security Class Initialized
INFO - 2024-02-27 00:00:33 --> Email Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:33 --> Input Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:00:33 --> Input Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:33 --> Language Class Initialized
INFO - 2024-02-27 00:00:33 --> Language Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:33 --> Loader Class Initialized
INFO - 2024-02-27 00:00:33 --> Loader Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:00:33 --> Controller Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:00:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:00:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:33 --> Email Class Initialized
INFO - 2024-02-27 00:00:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:00:33 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:00:33 --> Total execution time: 0.0590
INFO - 2024-02-27 00:00:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:33 --> Email Class Initialized
INFO - 2024-02-27 00:00:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:33 --> Controller Class Initialized
INFO - 2024-02-27 00:00:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:00:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:33 --> Total execution time: 0.0641
INFO - 2024-02-27 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:33 --> Controller Class Initialized
INFO - 2024-02-27 00:00:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:33 --> Total execution time: 0.0665
INFO - 2024-02-27 00:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:00:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:00:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:00:33 --> Controller Class Initialized
INFO - 2024-02-27 00:00:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:00:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:00:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:00:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:00:33 --> Total execution time: 0.0843
INFO - 2024-02-27 00:01:05 --> Config Class Initialized
INFO - 2024-02-27 00:01:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:05 --> URI Class Initialized
INFO - 2024-02-27 00:01:05 --> Router Class Initialized
INFO - 2024-02-27 00:01:05 --> Output Class Initialized
INFO - 2024-02-27 00:01:05 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:05 --> Input Class Initialized
INFO - 2024-02-27 00:01:05 --> Language Class Initialized
INFO - 2024-02-27 00:01:05 --> Loader Class Initialized
INFO - 2024-02-27 00:01:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:05 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:05 --> Controller Class Initialized
INFO - 2024-02-27 00:01:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:01:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:05 --> Total execution time: 0.0640
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:06 --> Email Class Initialized
INFO - 2024-02-27 00:01:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:06 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:06 --> Email Class Initialized
INFO - 2024-02-27 00:01:06 --> Email Class Initialized
INFO - 2024-02-27 00:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:06 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:06 --> Controller Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:06 --> Total execution time: 0.0687
INFO - 2024-02-27 00:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:06 --> Controller Class Initialized
INFO - 2024-02-27 00:01:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:06 --> Total execution time: 0.0783
INFO - 2024-02-27 00:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:06 --> Controller Class Initialized
INFO - 2024-02-27 00:01:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:06 --> Total execution time: 0.0841
INFO - 2024-02-27 00:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:06 --> Controller Class Initialized
INFO - 2024-02-27 00:01:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:06 --> Total execution time: 0.1016
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:06 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:06 --> Controller Class Initialized
INFO - 2024-02-27 00:01:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:01:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:06 --> Total execution time: 0.0847
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> URI Class Initialized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
DEBUG - 2024-02-27 00:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:06 --> Input Class Initialized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Language Class Initialized
INFO - 2024-02-27 00:01:06 --> Router Class Initialized
INFO - 2024-02-27 00:01:06 --> Config Class Initialized
INFO - 2024-02-27 00:01:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:06 --> Output Class Initialized
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Loader Class Initialized
INFO - 2024-02-27 00:01:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:07 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:07 --> Input Class Initialized
INFO - 2024-02-27 00:01:07 --> URI Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:07 --> Language Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:07 --> Router Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:07 --> Output Class Initialized
INFO - 2024-02-27 00:01:07 --> Loader Class Initialized
INFO - 2024-02-27 00:01:07 --> Security Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:07 --> Input Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:07 --> Language Class Initialized
INFO - 2024-02-27 00:01:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:07 --> Loader Class Initialized
INFO - 2024-02-27 00:01:07 --> Email Class Initialized
INFO - 2024-02-27 00:01:07 --> Email Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:07 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:07 --> Email Class Initialized
INFO - 2024-02-27 00:01:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:07 --> Controller Class Initialized
DEBUG - 2024-02-27 00:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:07 --> Email Class Initialized
INFO - 2024-02-27 00:01:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:07 --> Total execution time: 0.0552
INFO - 2024-02-27 00:01:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:07 --> Controller Class Initialized
INFO - 2024-02-27 00:01:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:07 --> Total execution time: 0.0751
INFO - 2024-02-27 00:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:07 --> Controller Class Initialized
INFO - 2024-02-27 00:01:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:07 --> Total execution time: 0.0804
INFO - 2024-02-27 00:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:07 --> Controller Class Initialized
INFO - 2024-02-27 00:01:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:07 --> Total execution time: 0.0815
INFO - 2024-02-27 00:01:09 --> Config Class Initialized
INFO - 2024-02-27 00:01:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:09 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:09 --> URI Class Initialized
INFO - 2024-02-27 00:01:09 --> Router Class Initialized
INFO - 2024-02-27 00:01:09 --> Output Class Initialized
INFO - 2024-02-27 00:01:09 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:09 --> Input Class Initialized
INFO - 2024-02-27 00:01:09 --> Language Class Initialized
INFO - 2024-02-27 00:01:09 --> Loader Class Initialized
INFO - 2024-02-27 00:01:09 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:09 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:09 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:09 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:09 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:09 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:09 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:09 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:09 --> Controller Class Initialized
INFO - 2024-02-27 00:01:09 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:01:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:09 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:09 --> Total execution time: 0.0627
INFO - 2024-02-27 00:01:10 --> Config Class Initialized
INFO - 2024-02-27 00:01:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:10 --> URI Class Initialized
INFO - 2024-02-27 00:01:10 --> Router Class Initialized
INFO - 2024-02-27 00:01:10 --> Output Class Initialized
INFO - 2024-02-27 00:01:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:10 --> Input Class Initialized
INFO - 2024-02-27 00:01:10 --> Language Class Initialized
INFO - 2024-02-27 00:01:10 --> Loader Class Initialized
INFO - 2024-02-27 00:01:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:10 --> Controller Class Initialized
INFO - 2024-02-27 00:01:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:10 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:01:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:10 --> Total execution time: 0.0679
INFO - 2024-02-27 00:01:12 --> Config Class Initialized
INFO - 2024-02-27 00:01:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:12 --> URI Class Initialized
INFO - 2024-02-27 00:01:12 --> Router Class Initialized
INFO - 2024-02-27 00:01:12 --> Output Class Initialized
INFO - 2024-02-27 00:01:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:12 --> Input Class Initialized
INFO - 2024-02-27 00:01:12 --> Language Class Initialized
INFO - 2024-02-27 00:01:12 --> Loader Class Initialized
INFO - 2024-02-27 00:01:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:12 --> Controller Class Initialized
INFO - 2024-02-27 00:01:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:12 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:01:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:12 --> Total execution time: 0.0705
INFO - 2024-02-27 00:01:12 --> Config Class Initialized
INFO - 2024-02-27 00:01:12 --> Config Class Initialized
INFO - 2024-02-27 00:01:12 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:12 --> Config Class Initialized
INFO - 2024-02-27 00:01:12 --> Config Class Initialized
INFO - 2024-02-27 00:01:12 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:12 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:01:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:12 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:01:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:12 --> URI Class Initialized
INFO - 2024-02-27 00:01:12 --> URI Class Initialized
INFO - 2024-02-27 00:01:12 --> URI Class Initialized
INFO - 2024-02-27 00:01:12 --> URI Class Initialized
INFO - 2024-02-27 00:01:12 --> Router Class Initialized
INFO - 2024-02-27 00:01:12 --> Router Class Initialized
INFO - 2024-02-27 00:01:12 --> Router Class Initialized
INFO - 2024-02-27 00:01:12 --> Router Class Initialized
INFO - 2024-02-27 00:01:12 --> Output Class Initialized
INFO - 2024-02-27 00:01:12 --> Output Class Initialized
INFO - 2024-02-27 00:01:12 --> Output Class Initialized
INFO - 2024-02-27 00:01:12 --> Output Class Initialized
INFO - 2024-02-27 00:01:12 --> Security Class Initialized
INFO - 2024-02-27 00:01:12 --> Security Class Initialized
INFO - 2024-02-27 00:01:12 --> Security Class Initialized
INFO - 2024-02-27 00:01:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:12 --> Input Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:12 --> Language Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:12 --> Input Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:12 --> Input Class Initialized
INFO - 2024-02-27 00:01:12 --> Input Class Initialized
INFO - 2024-02-27 00:01:12 --> Language Class Initialized
INFO - 2024-02-27 00:01:12 --> Language Class Initialized
INFO - 2024-02-27 00:01:12 --> Language Class Initialized
INFO - 2024-02-27 00:01:12 --> Loader Class Initialized
INFO - 2024-02-27 00:01:12 --> Loader Class Initialized
INFO - 2024-02-27 00:01:12 --> Loader Class Initialized
INFO - 2024-02-27 00:01:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:12 --> Loader Class Initialized
INFO - 2024-02-27 00:01:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:12 --> Email Class Initialized
INFO - 2024-02-27 00:01:12 --> Email Class Initialized
INFO - 2024-02-27 00:01:12 --> Email Class Initialized
INFO - 2024-02-27 00:01:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:12 --> Controller Class Initialized
INFO - 2024-02-27 00:01:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:12 --> Total execution time: 0.0580
INFO - 2024-02-27 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:12 --> Controller Class Initialized
INFO - 2024-02-27 00:01:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:12 --> Total execution time: 0.0707
INFO - 2024-02-27 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:12 --> Controller Class Initialized
INFO - 2024-02-27 00:01:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:12 --> Total execution time: 0.0838
INFO - 2024-02-27 00:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:12 --> Controller Class Initialized
INFO - 2024-02-27 00:01:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:12 --> Total execution time: 0.0984
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.0605
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.0669
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.0767
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.1067
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.1022
INFO - 2024-02-27 00:01:51 --> Config Class Initialized
INFO - 2024-02-27 00:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:51 --> URI Class Initialized
INFO - 2024-02-27 00:01:51 --> Router Class Initialized
INFO - 2024-02-27 00:01:51 --> Output Class Initialized
INFO - 2024-02-27 00:01:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:51 --> Input Class Initialized
INFO - 2024-02-27 00:01:51 --> Language Class Initialized
INFO - 2024-02-27 00:01:51 --> Loader Class Initialized
INFO - 2024-02-27 00:01:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:51 --> Controller Class Initialized
INFO - 2024-02-27 00:01:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:01:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:01:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:51 --> Total execution time: 0.0835
INFO - 2024-02-27 00:01:52 --> Config Class Initialized
INFO - 2024-02-27 00:01:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:52 --> Config Class Initialized
INFO - 2024-02-27 00:01:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:52 --> URI Class Initialized
INFO - 2024-02-27 00:01:52 --> Router Class Initialized
INFO - 2024-02-27 00:01:52 --> Output Class Initialized
DEBUG - 2024-02-27 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:52 --> Security Class Initialized
INFO - 2024-02-27 00:01:52 --> URI Class Initialized
DEBUG - 2024-02-27 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:52 --> Input Class Initialized
INFO - 2024-02-27 00:01:52 --> Config Class Initialized
INFO - 2024-02-27 00:01:52 --> Router Class Initialized
INFO - 2024-02-27 00:01:52 --> Language Class Initialized
INFO - 2024-02-27 00:01:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:52 --> Config Class Initialized
INFO - 2024-02-27 00:01:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:01:52 --> Output Class Initialized
DEBUG - 2024-02-27 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:01:52 --> Loader Class Initialized
INFO - 2024-02-27 00:01:52 --> Security Class Initialized
INFO - 2024-02-27 00:01:52 --> URI Class Initialized
DEBUG - 2024-02-27 00:01:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:01:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:52 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:52 --> Input Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:52 --> Router Class Initialized
INFO - 2024-02-27 00:01:52 --> URI Class Initialized
INFO - 2024-02-27 00:01:52 --> Language Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:52 --> Router Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:52 --> Output Class Initialized
INFO - 2024-02-27 00:01:52 --> Output Class Initialized
INFO - 2024-02-27 00:01:52 --> Security Class Initialized
INFO - 2024-02-27 00:01:52 --> Loader Class Initialized
INFO - 2024-02-27 00:01:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:52 --> Input Class Initialized
DEBUG - 2024-02-27 00:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:01:52 --> Input Class Initialized
INFO - 2024-02-27 00:01:52 --> Language Class Initialized
INFO - 2024-02-27 00:01:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:52 --> Language Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:52 --> Loader Class Initialized
INFO - 2024-02-27 00:01:52 --> Email Class Initialized
INFO - 2024-02-27 00:01:52 --> Loader Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:01:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:52 --> Controller Class Initialized
INFO - 2024-02-27 00:01:52 --> Email Class Initialized
INFO - 2024-02-27 00:01:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:01:52 --> Email Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:52 --> Email Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:52 --> Total execution time: 0.0614
INFO - 2024-02-27 00:01:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:01:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:52 --> Controller Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:52 --> Total execution time: 0.0686
INFO - 2024-02-27 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:52 --> Controller Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:52 --> Total execution time: 0.0689
INFO - 2024-02-27 00:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:01:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:01:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:01:52 --> Controller Class Initialized
INFO - 2024-02-27 00:01:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:01:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:01:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:01:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:01:52 --> Total execution time: 0.0853
INFO - 2024-02-27 00:03:05 --> Config Class Initialized
INFO - 2024-02-27 00:03:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:05 --> URI Class Initialized
INFO - 2024-02-27 00:03:05 --> Router Class Initialized
INFO - 2024-02-27 00:03:05 --> Output Class Initialized
INFO - 2024-02-27 00:03:05 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:05 --> Input Class Initialized
INFO - 2024-02-27 00:03:05 --> Language Class Initialized
INFO - 2024-02-27 00:03:05 --> Loader Class Initialized
INFO - 2024-02-27 00:03:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:05 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:05 --> Controller Class Initialized
INFO - 2024-02-27 00:03:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:03:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:05 --> Total execution time: 0.0770
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:06 --> Total execution time: 0.0601
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:06 --> Total execution time: 0.0666
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:06 --> Total execution time: 0.0982
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:06 --> Total execution time: 0.0849
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:03:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:06 --> Total execution time: 0.0541
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Config Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> URI Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Router Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Output Class Initialized
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Security Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Input Class Initialized
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Language Class Initialized
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
DEBUG - 2024-02-27 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:06 --> Loader Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:06 --> Controller Class Initialized
INFO - 2024-02-27 00:03:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:06 --> Email Class Initialized
INFO - 2024-02-27 00:03:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:06 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:07 --> Email Class Initialized
INFO - 2024-02-27 00:03:07 --> Email Class Initialized
INFO - 2024-02-27 00:03:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:07 --> Total execution time: 0.0601
INFO - 2024-02-27 00:03:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:07 --> Controller Class Initialized
INFO - 2024-02-27 00:03:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:07 --> Total execution time: 0.0635
INFO - 2024-02-27 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:07 --> Controller Class Initialized
INFO - 2024-02-27 00:03:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:07 --> Total execution time: 0.0646
INFO - 2024-02-27 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:07 --> Controller Class Initialized
INFO - 2024-02-27 00:03:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:07 --> Total execution time: 0.0770
INFO - 2024-02-27 00:03:07 --> Config Class Initialized
INFO - 2024-02-27 00:03:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:07 --> URI Class Initialized
INFO - 2024-02-27 00:03:07 --> Router Class Initialized
INFO - 2024-02-27 00:03:07 --> Output Class Initialized
INFO - 2024-02-27 00:03:07 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:07 --> Input Class Initialized
INFO - 2024-02-27 00:03:07 --> Language Class Initialized
INFO - 2024-02-27 00:03:07 --> Loader Class Initialized
INFO - 2024-02-27 00:03:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:07 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:07 --> Controller Class Initialized
INFO - 2024-02-27 00:03:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:07 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:03:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:07 --> Total execution time: 0.0667
INFO - 2024-02-27 00:03:10 --> Config Class Initialized
INFO - 2024-02-27 00:03:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:10 --> URI Class Initialized
INFO - 2024-02-27 00:03:10 --> Router Class Initialized
INFO - 2024-02-27 00:03:10 --> Output Class Initialized
INFO - 2024-02-27 00:03:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:10 --> Input Class Initialized
INFO - 2024-02-27 00:03:10 --> Language Class Initialized
INFO - 2024-02-27 00:03:10 --> Loader Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:10 --> Controller Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:10 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:03:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:10 --> Total execution time: 0.0514
INFO - 2024-02-27 00:03:10 --> Config Class Initialized
INFO - 2024-02-27 00:03:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:10 --> URI Class Initialized
INFO - 2024-02-27 00:03:10 --> Router Class Initialized
INFO - 2024-02-27 00:03:10 --> Output Class Initialized
INFO - 2024-02-27 00:03:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:10 --> Input Class Initialized
INFO - 2024-02-27 00:03:10 --> Language Class Initialized
INFO - 2024-02-27 00:03:10 --> Loader Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:10 --> Controller Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:10 --> Total execution time: 0.0645
INFO - 2024-02-27 00:03:10 --> Config Class Initialized
INFO - 2024-02-27 00:03:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:10 --> URI Class Initialized
INFO - 2024-02-27 00:03:10 --> Router Class Initialized
INFO - 2024-02-27 00:03:10 --> Output Class Initialized
INFO - 2024-02-27 00:03:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:10 --> Input Class Initialized
INFO - 2024-02-27 00:03:10 --> Language Class Initialized
INFO - 2024-02-27 00:03:10 --> Loader Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:10 --> Email Class Initialized
INFO - 2024-02-27 00:03:10 --> Config Class Initialized
INFO - 2024-02-27 00:03:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:10 --> URI Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:10 --> Router Class Initialized
INFO - 2024-02-27 00:03:10 --> Controller Class Initialized
INFO - 2024-02-27 00:03:10 --> Output Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:10 --> Security Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "Faktur_model" initialized
DEBUG - 2024-02-27 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:10 --> Input Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:10 --> Language Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:10 --> Total execution time: 0.0646
INFO - 2024-02-27 00:03:10 --> Loader Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:10 --> Config Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:10 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:03:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:10 --> URI Class Initialized
INFO - 2024-02-27 00:03:10 --> Router Class Initialized
INFO - 2024-02-27 00:03:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:10 --> Output Class Initialized
INFO - 2024-02-27 00:03:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:10 --> Input Class Initialized
INFO - 2024-02-27 00:03:10 --> Email Class Initialized
INFO - 2024-02-27 00:03:10 --> Language Class Initialized
DEBUG - 2024-02-27 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:10 --> Loader Class Initialized
INFO - 2024-02-27 00:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:10 --> Controller Class Initialized
INFO - 2024-02-27 00:03:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:10 --> Email Class Initialized
INFO - 2024-02-27 00:03:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:10 --> Total execution time: 0.0687
DEBUG - 2024-02-27 00:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:10 --> Controller Class Initialized
INFO - 2024-02-27 00:03:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:11 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:11 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:11 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:11 --> Total execution time: 0.0618
INFO - 2024-02-27 00:03:42 --> Config Class Initialized
INFO - 2024-02-27 00:03:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:42 --> URI Class Initialized
INFO - 2024-02-27 00:03:42 --> Router Class Initialized
INFO - 2024-02-27 00:03:42 --> Output Class Initialized
INFO - 2024-02-27 00:03:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:42 --> Input Class Initialized
INFO - 2024-02-27 00:03:42 --> Language Class Initialized
INFO - 2024-02-27 00:03:42 --> Loader Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:42 --> Controller Class Initialized
INFO - 2024-02-27 00:03:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:42 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:03:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:42 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:42 --> Total execution time: 0.0699
INFO - 2024-02-27 00:03:42 --> Config Class Initialized
INFO - 2024-02-27 00:03:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:42 --> Config Class Initialized
INFO - 2024-02-27 00:03:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:42 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:42 --> URI Class Initialized
INFO - 2024-02-27 00:03:42 --> Router Class Initialized
DEBUG - 2024-02-27 00:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:42 --> Config Class Initialized
INFO - 2024-02-27 00:03:42 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:42 --> Output Class Initialized
INFO - 2024-02-27 00:03:42 --> URI Class Initialized
INFO - 2024-02-27 00:03:42 --> Security Class Initialized
INFO - 2024-02-27 00:03:42 --> Router Class Initialized
DEBUG - 2024-02-27 00:03:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:42 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:42 --> Input Class Initialized
INFO - 2024-02-27 00:03:42 --> URI Class Initialized
INFO - 2024-02-27 00:03:42 --> Language Class Initialized
INFO - 2024-02-27 00:03:42 --> Output Class Initialized
INFO - 2024-02-27 00:03:42 --> Router Class Initialized
INFO - 2024-02-27 00:03:42 --> Security Class Initialized
INFO - 2024-02-27 00:03:42 --> Output Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:42 --> Loader Class Initialized
INFO - 2024-02-27 00:03:42 --> Input Class Initialized
INFO - 2024-02-27 00:03:42 --> Security Class Initialized
INFO - 2024-02-27 00:03:42 --> Language Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:42 --> Input Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:42 --> Language Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:42 --> Loader Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:42 --> Loader Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:42 --> Email Class Initialized
INFO - 2024-02-27 00:03:42 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:42 --> Email Class Initialized
INFO - 2024-02-27 00:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:42 --> Controller Class Initialized
DEBUG - 2024-02-27 00:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:42 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:42 --> Total execution time: 0.0601
INFO - 2024-02-27 00:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0732
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0821
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0607
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:03:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:03:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:03:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:03:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0553
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:43 --> Config Class Initialized
INFO - 2024-02-27 00:03:43 --> Hooks Class Initialized
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:03:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> URI Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
INFO - 2024-02-27 00:03:43 --> Router Class Initialized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> Output Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
INFO - 2024-02-27 00:03:43 --> Security Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
DEBUG - 2024-02-27 00:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Input Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Language Class Initialized
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Loader Class Initialized
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
INFO - 2024-02-27 00:03:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Email Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0557
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0625
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0648
INFO - 2024-02-27 00:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:03:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:03:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:03:43 --> Controller Class Initialized
INFO - 2024-02-27 00:03:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:03:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:03:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:03:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:03:43 --> Total execution time: 0.0788
INFO - 2024-02-27 00:04:20 --> Config Class Initialized
INFO - 2024-02-27 00:04:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:20 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:20 --> URI Class Initialized
INFO - 2024-02-27 00:04:20 --> Router Class Initialized
INFO - 2024-02-27 00:04:20 --> Output Class Initialized
INFO - 2024-02-27 00:04:20 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:20 --> Input Class Initialized
INFO - 2024-02-27 00:04:20 --> Language Class Initialized
INFO - 2024-02-27 00:04:20 --> Loader Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:20 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:20 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:20 --> Controller Class Initialized
INFO - 2024-02-27 00:04:20 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:04:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:04:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:04:20 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:04:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:04:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:20 --> Total execution time: 0.0610
INFO - 2024-02-27 00:04:20 --> Config Class Initialized
INFO - 2024-02-27 00:04:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:20 --> Config Class Initialized
INFO - 2024-02-27 00:04:20 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:20 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:20 --> Config Class Initialized
INFO - 2024-02-27 00:04:20 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:20 --> URI Class Initialized
INFO - 2024-02-27 00:04:20 --> Router Class Initialized
DEBUG - 2024-02-27 00:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:20 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:20 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:20 --> Output Class Initialized
INFO - 2024-02-27 00:04:20 --> URI Class Initialized
INFO - 2024-02-27 00:04:20 --> Config Class Initialized
INFO - 2024-02-27 00:04:20 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:20 --> URI Class Initialized
INFO - 2024-02-27 00:04:20 --> Security Class Initialized
INFO - 2024-02-27 00:04:20 --> Router Class Initialized
INFO - 2024-02-27 00:04:20 --> Router Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:20 --> Input Class Initialized
DEBUG - 2024-02-27 00:04:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:20 --> Output Class Initialized
INFO - 2024-02-27 00:04:20 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:20 --> Language Class Initialized
INFO - 2024-02-27 00:04:20 --> Output Class Initialized
INFO - 2024-02-27 00:04:20 --> URI Class Initialized
INFO - 2024-02-27 00:04:20 --> Security Class Initialized
INFO - 2024-02-27 00:04:20 --> Security Class Initialized
INFO - 2024-02-27 00:04:20 --> Router Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:20 --> Input Class Initialized
INFO - 2024-02-27 00:04:20 --> Loader Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:20 --> Language Class Initialized
INFO - 2024-02-27 00:04:20 --> Input Class Initialized
INFO - 2024-02-27 00:04:20 --> Output Class Initialized
INFO - 2024-02-27 00:04:20 --> Language Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:20 --> Security Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:20 --> Loader Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:20 --> Input Class Initialized
INFO - 2024-02-27 00:04:20 --> Loader Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:20 --> Language Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:20 --> Loader Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:20 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:20 --> Email Class Initialized
INFO - 2024-02-27 00:04:20 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:20 --> Email Class Initialized
INFO - 2024-02-27 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:20 --> Email Class Initialized
INFO - 2024-02-27 00:04:20 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:20 --> Controller Class Initialized
DEBUG - 2024-02-27 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:20 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:20 --> Total execution time: 0.0563
INFO - 2024-02-27 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:20 --> Controller Class Initialized
INFO - 2024-02-27 00:04:20 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:20 --> Total execution time: 0.0634
INFO - 2024-02-27 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:20 --> Email Class Initialized
INFO - 2024-02-27 00:04:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:20 --> Controller Class Initialized
INFO - 2024-02-27 00:04:20 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:20 --> Total execution time: 0.0758
INFO - 2024-02-27 00:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:20 --> Controller Class Initialized
INFO - 2024-02-27 00:04:20 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:20 --> Total execution time: 0.0847
INFO - 2024-02-27 00:04:21 --> Config Class Initialized
INFO - 2024-02-27 00:04:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:21 --> URI Class Initialized
INFO - 2024-02-27 00:04:21 --> Router Class Initialized
INFO - 2024-02-27 00:04:21 --> Output Class Initialized
INFO - 2024-02-27 00:04:21 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:21 --> Input Class Initialized
INFO - 2024-02-27 00:04:21 --> Language Class Initialized
INFO - 2024-02-27 00:04:21 --> Loader Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:21 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:21 --> Controller Class Initialized
INFO - 2024-02-27 00:04:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:04:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:21 --> Total execution time: 0.0692
INFO - 2024-02-27 00:04:21 --> Config Class Initialized
INFO - 2024-02-27 00:04:21 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:21 --> Config Class Initialized
INFO - 2024-02-27 00:04:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:21 --> URI Class Initialized
INFO - 2024-02-27 00:04:21 --> Config Class Initialized
DEBUG - 2024-02-27 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:21 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:21 --> Router Class Initialized
INFO - 2024-02-27 00:04:21 --> URI Class Initialized
DEBUG - 2024-02-27 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:21 --> Output Class Initialized
INFO - 2024-02-27 00:04:21 --> Router Class Initialized
INFO - 2024-02-27 00:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:21 --> Security Class Initialized
INFO - 2024-02-27 00:04:21 --> Output Class Initialized
INFO - 2024-02-27 00:04:21 --> URI Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:21 --> Input Class Initialized
INFO - 2024-02-27 00:04:21 --> Config Class Initialized
INFO - 2024-02-27 00:04:21 --> Security Class Initialized
INFO - 2024-02-27 00:04:21 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:21 --> Router Class Initialized
INFO - 2024-02-27 00:04:21 --> Language Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:21 --> Input Class Initialized
INFO - 2024-02-27 00:04:21 --> Output Class Initialized
INFO - 2024-02-27 00:04:21 --> Language Class Initialized
DEBUG - 2024-02-27 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:21 --> Security Class Initialized
INFO - 2024-02-27 00:04:21 --> Loader Class Initialized
INFO - 2024-02-27 00:04:21 --> URI Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:21 --> Input Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:21 --> Loader Class Initialized
INFO - 2024-02-27 00:04:21 --> Router Class Initialized
INFO - 2024-02-27 00:04:21 --> Language Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:21 --> Output Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:21 --> Security Class Initialized
INFO - 2024-02-27 00:04:21 --> Loader Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:21 --> Input Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:21 --> Language Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:21 --> Loader Class Initialized
INFO - 2024-02-27 00:04:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:21 --> Email Class Initialized
INFO - 2024-02-27 00:04:21 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:21 --> Email Class Initialized
INFO - 2024-02-27 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:21 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:21 --> Controller Class Initialized
INFO - 2024-02-27 00:04:21 --> Email Class Initialized
INFO - 2024-02-27 00:04:21 --> Email Class Initialized
INFO - 2024-02-27 00:04:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:21 --> Model "Faktur_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:21 --> Total execution time: 0.0547
INFO - 2024-02-27 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:21 --> Controller Class Initialized
INFO - 2024-02-27 00:04:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:21 --> Total execution time: 0.0656
INFO - 2024-02-27 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:21 --> Controller Class Initialized
INFO - 2024-02-27 00:04:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:21 --> Total execution time: 0.0853
INFO - 2024-02-27 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:21 --> Controller Class Initialized
INFO - 2024-02-27 00:04:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:21 --> Total execution time: 0.0841
INFO - 2024-02-27 00:04:31 --> Config Class Initialized
INFO - 2024-02-27 00:04:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:31 --> URI Class Initialized
INFO - 2024-02-27 00:04:31 --> Router Class Initialized
INFO - 2024-02-27 00:04:31 --> Output Class Initialized
INFO - 2024-02-27 00:04:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:31 --> Input Class Initialized
INFO - 2024-02-27 00:04:31 --> Language Class Initialized
INFO - 2024-02-27 00:04:31 --> Loader Class Initialized
INFO - 2024-02-27 00:04:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:31 --> Controller Class Initialized
INFO - 2024-02-27 00:04:31 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:04:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:04:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:04:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:04:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:04:31 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:31 --> Total execution time: 0.0829
INFO - 2024-02-27 00:04:32 --> Config Class Initialized
INFO - 2024-02-27 00:04:32 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:32 --> Config Class Initialized
INFO - 2024-02-27 00:04:32 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:32 --> Config Class Initialized
INFO - 2024-02-27 00:04:32 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:32 --> Config Class Initialized
DEBUG - 2024-02-27 00:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:32 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:32 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:04:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:32 --> URI Class Initialized
INFO - 2024-02-27 00:04:32 --> URI Class Initialized
INFO - 2024-02-27 00:04:32 --> URI Class Initialized
DEBUG - 2024-02-27 00:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:32 --> Router Class Initialized
INFO - 2024-02-27 00:04:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:32 --> URI Class Initialized
INFO - 2024-02-27 00:04:32 --> Router Class Initialized
INFO - 2024-02-27 00:04:32 --> Router Class Initialized
INFO - 2024-02-27 00:04:32 --> Router Class Initialized
INFO - 2024-02-27 00:04:32 --> Output Class Initialized
INFO - 2024-02-27 00:04:32 --> Output Class Initialized
INFO - 2024-02-27 00:04:32 --> Output Class Initialized
INFO - 2024-02-27 00:04:32 --> Security Class Initialized
INFO - 2024-02-27 00:04:32 --> Output Class Initialized
INFO - 2024-02-27 00:04:32 --> Security Class Initialized
INFO - 2024-02-27 00:04:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:32 --> Security Class Initialized
INFO - 2024-02-27 00:04:32 --> Input Class Initialized
INFO - 2024-02-27 00:04:32 --> Input Class Initialized
INFO - 2024-02-27 00:04:32 --> Input Class Initialized
INFO - 2024-02-27 00:04:32 --> Language Class Initialized
INFO - 2024-02-27 00:04:32 --> Language Class Initialized
INFO - 2024-02-27 00:04:32 --> Language Class Initialized
DEBUG - 2024-02-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:32 --> Input Class Initialized
INFO - 2024-02-27 00:04:32 --> Language Class Initialized
INFO - 2024-02-27 00:04:32 --> Loader Class Initialized
INFO - 2024-02-27 00:04:32 --> Loader Class Initialized
INFO - 2024-02-27 00:04:32 --> Loader Class Initialized
INFO - 2024-02-27 00:04:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:32 --> Loader Class Initialized
INFO - 2024-02-27 00:04:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:32 --> Email Class Initialized
INFO - 2024-02-27 00:04:32 --> Email Class Initialized
INFO - 2024-02-27 00:04:32 --> Email Class Initialized
INFO - 2024-02-27 00:04:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:32 --> Controller Class Initialized
INFO - 2024-02-27 00:04:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:32 --> Total execution time: 0.0623
INFO - 2024-02-27 00:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:32 --> Controller Class Initialized
INFO - 2024-02-27 00:04:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:32 --> Total execution time: 0.0808
INFO - 2024-02-27 00:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:32 --> Controller Class Initialized
INFO - 2024-02-27 00:04:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:32 --> Total execution time: 0.0939
INFO - 2024-02-27 00:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:32 --> Controller Class Initialized
INFO - 2024-02-27 00:04:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:32 --> Total execution time: 0.1042
INFO - 2024-02-27 00:04:32 --> Config Class Initialized
INFO - 2024-02-27 00:04:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:32 --> URI Class Initialized
INFO - 2024-02-27 00:04:32 --> Router Class Initialized
INFO - 2024-02-27 00:04:32 --> Output Class Initialized
INFO - 2024-02-27 00:04:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:32 --> Input Class Initialized
INFO - 2024-02-27 00:04:32 --> Language Class Initialized
INFO - 2024-02-27 00:04:32 --> Loader Class Initialized
INFO - 2024-02-27 00:04:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:32 --> Controller Class Initialized
INFO - 2024-02-27 00:04:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:04:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:04:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:32 --> Total execution time: 0.0713
INFO - 2024-02-27 00:04:33 --> Config Class Initialized
INFO - 2024-02-27 00:04:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:04:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:33 --> URI Class Initialized
INFO - 2024-02-27 00:04:33 --> Router Class Initialized
INFO - 2024-02-27 00:04:33 --> Config Class Initialized
INFO - 2024-02-27 00:04:33 --> Config Class Initialized
INFO - 2024-02-27 00:04:33 --> Config Class Initialized
INFO - 2024-02-27 00:04:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:04:33 --> Output Class Initialized
INFO - 2024-02-27 00:04:33 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:04:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:04:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:04:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:04:33 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:33 --> Input Class Initialized
INFO - 2024-02-27 00:04:33 --> URI Class Initialized
INFO - 2024-02-27 00:04:33 --> URI Class Initialized
INFO - 2024-02-27 00:04:33 --> URI Class Initialized
INFO - 2024-02-27 00:04:33 --> Language Class Initialized
INFO - 2024-02-27 00:04:33 --> Router Class Initialized
INFO - 2024-02-27 00:04:33 --> Router Class Initialized
INFO - 2024-02-27 00:04:33 --> Router Class Initialized
INFO - 2024-02-27 00:04:33 --> Output Class Initialized
INFO - 2024-02-27 00:04:33 --> Loader Class Initialized
INFO - 2024-02-27 00:04:33 --> Output Class Initialized
INFO - 2024-02-27 00:04:33 --> Output Class Initialized
INFO - 2024-02-27 00:04:33 --> Security Class Initialized
INFO - 2024-02-27 00:04:33 --> Security Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:33 --> Security Class Initialized
DEBUG - 2024-02-27 00:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:33 --> Input Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:04:33 --> Language Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:33 --> Input Class Initialized
INFO - 2024-02-27 00:04:33 --> Input Class Initialized
INFO - 2024-02-27 00:04:33 --> Language Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:33 --> Language Class Initialized
INFO - 2024-02-27 00:04:33 --> Loader Class Initialized
INFO - 2024-02-27 00:04:33 --> Loader Class Initialized
INFO - 2024-02-27 00:04:33 --> Loader Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:04:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:04:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:04:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:33 --> Controller Class Initialized
INFO - 2024-02-27 00:04:33 --> Email Class Initialized
INFO - 2024-02-27 00:04:33 --> Email Class Initialized
INFO - 2024-02-27 00:04:33 --> Email Class Initialized
INFO - 2024-02-27 00:04:33 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:33 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:04:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:33 --> Total execution time: 0.0641
INFO - 2024-02-27 00:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:33 --> Controller Class Initialized
INFO - 2024-02-27 00:04:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:33 --> Total execution time: 0.0694
INFO - 2024-02-27 00:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:33 --> Controller Class Initialized
INFO - 2024-02-27 00:04:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:33 --> Total execution time: 0.0863
INFO - 2024-02-27 00:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:04:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:04:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:04:33 --> Controller Class Initialized
INFO - 2024-02-27 00:04:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:04:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:04:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:04:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:04:33 --> Total execution time: 0.1052
INFO - 2024-02-27 00:05:03 --> Config Class Initialized
INFO - 2024-02-27 00:05:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:03 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:03 --> URI Class Initialized
INFO - 2024-02-27 00:05:03 --> Router Class Initialized
INFO - 2024-02-27 00:05:03 --> Output Class Initialized
INFO - 2024-02-27 00:05:03 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:03 --> Input Class Initialized
INFO - 2024-02-27 00:05:03 --> Language Class Initialized
INFO - 2024-02-27 00:05:03 --> Loader Class Initialized
INFO - 2024-02-27 00:05:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:03 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:03 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:03 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:03 --> Controller Class Initialized
INFO - 2024-02-27 00:05:03 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:03 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:03 --> Total execution time: 0.0705
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0598
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0677
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0779
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0946
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:04 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0509
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Config Class Initialized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:05:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> URI Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Router Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Output Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
DEBUG - 2024-02-27 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:04 --> Input Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Language Class Initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Loader Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:04 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Email Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0587
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0688
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0672
INFO - 2024-02-27 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:04 --> Controller Class Initialized
INFO - 2024-02-27 00:05:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:04 --> Total execution time: 0.0798
INFO - 2024-02-27 00:05:05 --> Config Class Initialized
INFO - 2024-02-27 00:05:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:05 --> URI Class Initialized
INFO - 2024-02-27 00:05:05 --> Router Class Initialized
INFO - 2024-02-27 00:05:05 --> Output Class Initialized
INFO - 2024-02-27 00:05:05 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:05 --> Input Class Initialized
INFO - 2024-02-27 00:05:05 --> Language Class Initialized
INFO - 2024-02-27 00:05:05 --> Loader Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:05 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:05 --> Controller Class Initialized
INFO - 2024-02-27 00:05:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:05 --> Total execution time: 0.0735
INFO - 2024-02-27 00:05:05 --> Config Class Initialized
INFO - 2024-02-27 00:05:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:05 --> Config Class Initialized
INFO - 2024-02-27 00:05:05 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:05 --> URI Class Initialized
INFO - 2024-02-27 00:05:05 --> Router Class Initialized
DEBUG - 2024-02-27 00:05:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:05 --> Output Class Initialized
INFO - 2024-02-27 00:05:05 --> Security Class Initialized
INFO - 2024-02-27 00:05:05 --> URI Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:05 --> Input Class Initialized
INFO - 2024-02-27 00:05:05 --> Router Class Initialized
INFO - 2024-02-27 00:05:05 --> Language Class Initialized
INFO - 2024-02-27 00:05:05 --> Config Class Initialized
INFO - 2024-02-27 00:05:05 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:05 --> Config Class Initialized
INFO - 2024-02-27 00:05:05 --> Output Class Initialized
INFO - 2024-02-27 00:05:05 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:05 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:05 --> Loader Class Initialized
DEBUG - 2024-02-27 00:05:05 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:05 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:05 --> URI Class Initialized
INFO - 2024-02-27 00:05:05 --> Input Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:05 --> URI Class Initialized
INFO - 2024-02-27 00:05:05 --> Language Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:05 --> Router Class Initialized
INFO - 2024-02-27 00:05:05 --> Router Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:05 --> Output Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:05 --> Output Class Initialized
INFO - 2024-02-27 00:05:05 --> Loader Class Initialized
INFO - 2024-02-27 00:05:05 --> Security Class Initialized
INFO - 2024-02-27 00:05:05 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:05 --> Input Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:05 --> Input Class Initialized
INFO - 2024-02-27 00:05:05 --> Language Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:05 --> Language Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:05 --> Loader Class Initialized
INFO - 2024-02-27 00:05:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:05 --> Loader Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:05 --> Email Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:05 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:05 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:05 --> Controller Class Initialized
INFO - 2024-02-27 00:05:05 --> Email Class Initialized
INFO - 2024-02-27 00:05:05 --> Email Class Initialized
INFO - 2024-02-27 00:05:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:05 --> Model "Faktur_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:05 --> Total execution time: 0.0576
INFO - 2024-02-27 00:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:05 --> Controller Class Initialized
INFO - 2024-02-27 00:05:05 --> Email Class Initialized
INFO - 2024-02-27 00:05:05 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:05 --> Total execution time: 0.0550
INFO - 2024-02-27 00:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:05 --> Controller Class Initialized
INFO - 2024-02-27 00:05:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:05 --> Total execution time: 0.0701
INFO - 2024-02-27 00:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:05 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:05 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:05 --> Controller Class Initialized
INFO - 2024-02-27 00:05:05 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:05 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:05 --> Total execution time: 0.1009
INFO - 2024-02-27 00:05:08 --> Config Class Initialized
INFO - 2024-02-27 00:05:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:08 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:08 --> URI Class Initialized
INFO - 2024-02-27 00:05:08 --> Router Class Initialized
INFO - 2024-02-27 00:05:08 --> Output Class Initialized
INFO - 2024-02-27 00:05:08 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:08 --> Input Class Initialized
INFO - 2024-02-27 00:05:08 --> Language Class Initialized
INFO - 2024-02-27 00:05:08 --> Loader Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:08 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:08 --> Controller Class Initialized
INFO - 2024-02-27 00:05:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:08 --> Total execution time: 0.0715
INFO - 2024-02-27 00:05:08 --> Config Class Initialized
INFO - 2024-02-27 00:05:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:08 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:08 --> Config Class Initialized
INFO - 2024-02-27 00:05:08 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:08 --> URI Class Initialized
INFO - 2024-02-27 00:05:08 --> Router Class Initialized
INFO - 2024-02-27 00:05:08 --> Config Class Initialized
DEBUG - 2024-02-27 00:05:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:08 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:08 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:08 --> Output Class Initialized
INFO - 2024-02-27 00:05:08 --> URI Class Initialized
INFO - 2024-02-27 00:05:08 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:08 --> Router Class Initialized
INFO - 2024-02-27 00:05:08 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:08 --> URI Class Initialized
INFO - 2024-02-27 00:05:08 --> Input Class Initialized
INFO - 2024-02-27 00:05:08 --> Output Class Initialized
INFO - 2024-02-27 00:05:08 --> Config Class Initialized
INFO - 2024-02-27 00:05:08 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:08 --> Language Class Initialized
INFO - 2024-02-27 00:05:08 --> Router Class Initialized
INFO - 2024-02-27 00:05:08 --> Security Class Initialized
INFO - 2024-02-27 00:05:08 --> Output Class Initialized
DEBUG - 2024-02-27 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:08 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:08 --> Input Class Initialized
INFO - 2024-02-27 00:05:08 --> Security Class Initialized
INFO - 2024-02-27 00:05:08 --> URI Class Initialized
INFO - 2024-02-27 00:05:08 --> Loader Class Initialized
INFO - 2024-02-27 00:05:08 --> Language Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:08 --> Input Class Initialized
INFO - 2024-02-27 00:05:08 --> Router Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:08 --> Language Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:08 --> Output Class Initialized
INFO - 2024-02-27 00:05:08 --> Loader Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:08 --> Security Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:08 --> Loader Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:08 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:08 --> Input Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:08 --> Language Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:08 --> Loader Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:08 --> Email Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:08 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:08 --> Email Class Initialized
INFO - 2024-02-27 00:05:08 --> Email Class Initialized
INFO - 2024-02-27 00:05:08 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:08 --> Controller Class Initialized
DEBUG - 2024-02-27 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:08 --> Email Class Initialized
INFO - 2024-02-27 00:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:08 --> Total execution time: 0.0562
INFO - 2024-02-27 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:08 --> Controller Class Initialized
INFO - 2024-02-27 00:05:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:08 --> Total execution time: 0.0633
INFO - 2024-02-27 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:08 --> Controller Class Initialized
INFO - 2024-02-27 00:05:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:08 --> Total execution time: 0.0723
INFO - 2024-02-27 00:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:08 --> Controller Class Initialized
INFO - 2024-02-27 00:05:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:08 --> Total execution time: 0.0777
INFO - 2024-02-27 00:05:36 --> Config Class Initialized
INFO - 2024-02-27 00:05:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:36 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:36 --> URI Class Initialized
INFO - 2024-02-27 00:05:36 --> Router Class Initialized
INFO - 2024-02-27 00:05:36 --> Output Class Initialized
INFO - 2024-02-27 00:05:36 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:36 --> Input Class Initialized
INFO - 2024-02-27 00:05:36 --> Language Class Initialized
INFO - 2024-02-27 00:05:36 --> Loader Class Initialized
INFO - 2024-02-27 00:05:36 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:36 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:36 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:36 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:36 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:36 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:36 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:36 --> Controller Class Initialized
INFO - 2024-02-27 00:05:36 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:36 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:36 --> Total execution time: 0.0739
INFO - 2024-02-27 00:05:37 --> Config Class Initialized
INFO - 2024-02-27 00:05:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:37 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:37 --> URI Class Initialized
INFO - 2024-02-27 00:05:37 --> Config Class Initialized
INFO - 2024-02-27 00:05:37 --> Router Class Initialized
INFO - 2024-02-27 00:05:37 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:37 --> Output Class Initialized
INFO - 2024-02-27 00:05:37 --> Config Class Initialized
INFO - 2024-02-27 00:05:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:37 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:37 --> URI Class Initialized
INFO - 2024-02-27 00:05:37 --> Security Class Initialized
INFO - 2024-02-27 00:05:37 --> Router Class Initialized
INFO - 2024-02-27 00:05:37 --> Output Class Initialized
INFO - 2024-02-27 00:05:37 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:37 --> Input Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:37 --> Language Class Initialized
INFO - 2024-02-27 00:05:37 --> Input Class Initialized
INFO - 2024-02-27 00:05:37 --> Language Class Initialized
DEBUG - 2024-02-27 00:05:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:37 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:37 --> Loader Class Initialized
INFO - 2024-02-27 00:05:37 --> Loader Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:37 --> URI Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:37 --> Router Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:37 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:37 --> Output Class Initialized
INFO - 2024-02-27 00:05:37 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:37 --> Email Class Initialized
INFO - 2024-02-27 00:05:37 --> Email Class Initialized
INFO - 2024-02-27 00:05:37 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:37 --> Input Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:37 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:37 --> Controller Class Initialized
INFO - 2024-02-27 00:05:37 --> Language Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:37 --> Config Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:37 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:37 --> Loader Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:05:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 00:05:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:37 --> Final output sent to browser
INFO - 2024-02-27 00:05:37 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Total execution time: 0.1109
INFO - 2024-02-27 00:05:37 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:37 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:37 --> URI Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:37 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:37 --> Controller Class Initialized
INFO - 2024-02-27 00:05:37 --> Router Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:37 --> Output Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Security Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:37 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:37 --> Input Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:05:37 --> Language Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:37 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:37 --> Total execution time: 0.1385
INFO - 2024-02-27 00:05:37 --> Email Class Initialized
INFO - 2024-02-27 00:05:37 --> Loader Class Initialized
INFO - 2024-02-27 00:05:37 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:37 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:37 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:37 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:37 --> Controller Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:37 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:37 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:37 --> Total execution time: 0.1650
INFO - 2024-02-27 00:05:37 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:37 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:37 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:37 --> Controller Class Initialized
INFO - 2024-02-27 00:05:37 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:37 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:37 --> Total execution time: 0.1328
INFO - 2024-02-27 00:05:51 --> Config Class Initialized
INFO - 2024-02-27 00:05:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:51 --> URI Class Initialized
INFO - 2024-02-27 00:05:51 --> Router Class Initialized
INFO - 2024-02-27 00:05:51 --> Output Class Initialized
INFO - 2024-02-27 00:05:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:51 --> Input Class Initialized
INFO - 2024-02-27 00:05:51 --> Language Class Initialized
INFO - 2024-02-27 00:05:51 --> Loader Class Initialized
INFO - 2024-02-27 00:05:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:51 --> Controller Class Initialized
INFO - 2024-02-27 00:05:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:52 --> Total execution time: 0.0761
INFO - 2024-02-27 00:05:52 --> Config Class Initialized
INFO - 2024-02-27 00:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:52 --> Config Class Initialized
INFO - 2024-02-27 00:05:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:52 --> URI Class Initialized
INFO - 2024-02-27 00:05:52 --> Config Class Initialized
INFO - 2024-02-27 00:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:52 --> URI Class Initialized
INFO - 2024-02-27 00:05:52 --> Router Class Initialized
INFO - 2024-02-27 00:05:52 --> Router Class Initialized
INFO - 2024-02-27 00:05:52 --> Output Class Initialized
INFO - 2024-02-27 00:05:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:52 --> Output Class Initialized
INFO - 2024-02-27 00:05:52 --> Input Class Initialized
INFO - 2024-02-27 00:05:52 --> Language Class Initialized
INFO - 2024-02-27 00:05:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:52 --> Input Class Initialized
INFO - 2024-02-27 00:05:52 --> Loader Class Initialized
INFO - 2024-02-27 00:05:52 --> Language Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:52 --> Loader Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:52 --> URI Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:52 --> Config Class Initialized
INFO - 2024-02-27 00:05:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:52 --> Router Class Initialized
INFO - 2024-02-27 00:05:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:05:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:05:52 --> Output Class Initialized
INFO - 2024-02-27 00:05:52 --> URI Class Initialized
INFO - 2024-02-27 00:05:52 --> Email Class Initialized
INFO - 2024-02-27 00:05:52 --> Router Class Initialized
INFO - 2024-02-27 00:05:52 --> Security Class Initialized
INFO - 2024-02-27 00:05:52 --> Output Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:52 --> Controller Class Initialized
INFO - 2024-02-27 00:05:52 --> Input Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:05:52 --> Language Class Initialized
INFO - 2024-02-27 00:05:52 --> Input Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:52 --> Language Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Loader Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:52 --> Total execution time: 0.0873
INFO - 2024-02-27 00:05:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:05:52 --> Email Class Initialized
INFO - 2024-02-27 00:05:52 --> Loader Class Initialized
INFO - 2024-02-27 00:05:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:05:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:05:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:05:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:52 --> Controller Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:52 --> Total execution time: 0.1762
INFO - 2024-02-27 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:52 --> Controller Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:52 --> Total execution time: 0.1386
INFO - 2024-02-27 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:05:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:05:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:05:52 --> Controller Class Initialized
INFO - 2024-02-27 00:05:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:05:52 --> Total execution time: 0.2215
INFO - 2024-02-27 00:06:44 --> Config Class Initialized
INFO - 2024-02-27 00:06:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:44 --> URI Class Initialized
INFO - 2024-02-27 00:06:44 --> Router Class Initialized
INFO - 2024-02-27 00:06:44 --> Output Class Initialized
INFO - 2024-02-27 00:06:44 --> Security Class Initialized
DEBUG - 2024-02-27 00:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:44 --> Input Class Initialized
INFO - 2024-02-27 00:06:44 --> Language Class Initialized
INFO - 2024-02-27 00:06:44 --> Loader Class Initialized
INFO - 2024-02-27 00:06:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:44 --> Email Class Initialized
DEBUG - 2024-02-27 00:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:44 --> Controller Class Initialized
INFO - 2024-02-27 00:06:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:06:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:06:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:06:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:06:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:06:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:44 --> Total execution time: 0.0631
INFO - 2024-02-27 00:06:45 --> Config Class Initialized
INFO - 2024-02-27 00:06:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:45 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:45 --> Config Class Initialized
INFO - 2024-02-27 00:06:45 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:45 --> Config Class Initialized
DEBUG - 2024-02-27 00:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:45 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:45 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:45 --> URI Class Initialized
INFO - 2024-02-27 00:06:45 --> URI Class Initialized
INFO - 2024-02-27 00:06:45 --> Router Class Initialized
INFO - 2024-02-27 00:06:45 --> Router Class Initialized
INFO - 2024-02-27 00:06:45 --> Output Class Initialized
DEBUG - 2024-02-27 00:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:45 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:45 --> Security Class Initialized
INFO - 2024-02-27 00:06:45 --> Output Class Initialized
INFO - 2024-02-27 00:06:45 --> URI Class Initialized
INFO - 2024-02-27 00:06:45 --> Security Class Initialized
DEBUG - 2024-02-27 00:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:45 --> Input Class Initialized
INFO - 2024-02-27 00:06:45 --> Router Class Initialized
DEBUG - 2024-02-27 00:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:45 --> Input Class Initialized
INFO - 2024-02-27 00:06:45 --> Language Class Initialized
INFO - 2024-02-27 00:06:45 --> Language Class Initialized
INFO - 2024-02-27 00:06:45 --> Output Class Initialized
INFO - 2024-02-27 00:06:45 --> Loader Class Initialized
INFO - 2024-02-27 00:06:45 --> Loader Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:45 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:45 --> Security Class Initialized
INFO - 2024-02-27 00:06:45 --> Config Class Initialized
INFO - 2024-02-27 00:06:45 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:45 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:45 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:45 --> Input Class Initialized
DEBUG - 2024-02-27 00:06:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:45 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:45 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:45 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:45 --> Language Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:45 --> URI Class Initialized
INFO - 2024-02-27 00:06:45 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:45 --> Loader Class Initialized
INFO - 2024-02-27 00:06:45 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:45 --> Router Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:45 --> Output Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:45 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:45 --> Security Class Initialized
INFO - 2024-02-27 00:06:45 --> Email Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:45 --> Email Class Initialized
INFO - 2024-02-27 00:06:45 --> Input Class Initialized
DEBUG - 2024-02-27 00:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:45 --> Language Class Initialized
INFO - 2024-02-27 00:06:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:45 --> Loader Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:45 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:45 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:45 --> Controller Class Initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:45 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:45 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:45 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:45 --> Email Class Initialized
INFO - 2024-02-27 00:06:45 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:45 --> Final output sent to browser
INFO - 2024-02-27 00:06:45 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:06:45 --> Total execution time: 0.1162
DEBUG - 2024-02-27 00:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:45 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:45 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:45 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:45 --> Controller Class Initialized
INFO - 2024-02-27 00:06:45 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:45 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Email Class Initialized
INFO - 2024-02-27 00:06:45 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:45 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:45 --> Total execution time: 0.1391
DEBUG - 2024-02-27 00:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:45 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:45 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:45 --> Controller Class Initialized
INFO - 2024-02-27 00:06:45 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:45 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:45 --> Total execution time: 0.1640
INFO - 2024-02-27 00:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:45 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:45 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:45 --> Controller Class Initialized
INFO - 2024-02-27 00:06:45 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:45 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:45 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:45 --> Total execution time: 0.1483
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:46 --> Controller Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:06:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:06:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:06:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:06:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:46 --> Total execution time: 0.0738
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:46 --> Email Class Initialized
INFO - 2024-02-27 00:06:46 --> Email Class Initialized
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:46 --> Controller Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:46 --> Total execution time: 0.0914
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
INFO - 2024-02-27 00:06:46 --> Email Class Initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:46 --> Controller Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:46 --> Total execution time: 0.1235
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:46 --> Controller Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:46 --> Total execution time: 0.1614
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:46 --> Controller Class Initialized
INFO - 2024-02-27 00:06:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:46 --> Total execution time: 0.2195
INFO - 2024-02-27 00:06:46 --> Config Class Initialized
INFO - 2024-02-27 00:06:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:46 --> URI Class Initialized
INFO - 2024-02-27 00:06:46 --> Router Class Initialized
INFO - 2024-02-27 00:06:46 --> Output Class Initialized
INFO - 2024-02-27 00:06:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:46 --> Input Class Initialized
INFO - 2024-02-27 00:06:46 --> Language Class Initialized
INFO - 2024-02-27 00:06:46 --> Loader Class Initialized
INFO - 2024-02-27 00:06:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:47 --> Controller Class Initialized
INFO - 2024-02-27 00:06:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:06:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:06:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:06:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:06:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:06:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:47 --> Total execution time: 0.0806
INFO - 2024-02-27 00:06:47 --> Config Class Initialized
INFO - 2024-02-27 00:06:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:47 --> Config Class Initialized
INFO - 2024-02-27 00:06:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:06:47 --> Config Class Initialized
INFO - 2024-02-27 00:06:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:47 --> URI Class Initialized
INFO - 2024-02-27 00:06:47 --> Router Class Initialized
INFO - 2024-02-27 00:06:47 --> Config Class Initialized
INFO - 2024-02-27 00:06:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:06:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:47 --> Output Class Initialized
DEBUG - 2024-02-27 00:06:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:47 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:06:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:06:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:47 --> Security Class Initialized
INFO - 2024-02-27 00:06:47 --> URI Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:47 --> Input Class Initialized
INFO - 2024-02-27 00:06:47 --> URI Class Initialized
INFO - 2024-02-27 00:06:47 --> Language Class Initialized
INFO - 2024-02-27 00:06:47 --> Router Class Initialized
INFO - 2024-02-27 00:06:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:06:47 --> Router Class Initialized
INFO - 2024-02-27 00:06:47 --> Output Class Initialized
INFO - 2024-02-27 00:06:47 --> Loader Class Initialized
INFO - 2024-02-27 00:06:47 --> Output Class Initialized
INFO - 2024-02-27 00:06:47 --> Security Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:47 --> Security Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:47 --> Input Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:47 --> Language Class Initialized
INFO - 2024-02-27 00:06:47 --> Input Class Initialized
INFO - 2024-02-27 00:06:47 --> Language Class Initialized
INFO - 2024-02-27 00:06:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:47 --> Loader Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:47 --> Loader Class Initialized
INFO - 2024-02-27 00:06:47 --> Email Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:47 --> Controller Class Initialized
INFO - 2024-02-27 00:06:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:47 --> Total execution time: 0.1224
INFO - 2024-02-27 00:06:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:47 --> URI Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:47 --> Router Class Initialized
INFO - 2024-02-27 00:06:47 --> Output Class Initialized
INFO - 2024-02-27 00:06:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:06:47 --> Email Class Initialized
INFO - 2024-02-27 00:06:47 --> Input Class Initialized
INFO - 2024-02-27 00:06:47 --> Language Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:47 --> Loader Class Initialized
INFO - 2024-02-27 00:06:47 --> Email Class Initialized
INFO - 2024-02-27 00:06:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:47 --> Controller Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:06:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:06:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:06:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:47 --> Final output sent to browser
INFO - 2024-02-27 00:06:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:06:47 --> Total execution time: 0.1748
INFO - 2024-02-27 00:06:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:06:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:47 --> Controller Class Initialized
INFO - 2024-02-27 00:06:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:47 --> Total execution time: 0.1971
INFO - 2024-02-27 00:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:06:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:06:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:06:47 --> Controller Class Initialized
INFO - 2024-02-27 00:06:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:06:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:06:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:06:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:06:47 --> Total execution time: 0.2188
INFO - 2024-02-27 00:07:32 --> Config Class Initialized
INFO - 2024-02-27 00:07:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:07:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:07:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:07:32 --> URI Class Initialized
INFO - 2024-02-27 00:07:32 --> Router Class Initialized
INFO - 2024-02-27 00:07:32 --> Output Class Initialized
INFO - 2024-02-27 00:07:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:07:32 --> Input Class Initialized
INFO - 2024-02-27 00:07:32 --> Language Class Initialized
INFO - 2024-02-27 00:07:32 --> Loader Class Initialized
INFO - 2024-02-27 00:07:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:07:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:07:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:07:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:07:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:07:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:07:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:07:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:07:32 --> Controller Class Initialized
INFO - 2024-02-27 00:07:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:07:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:07:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:07:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:07:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:07:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:07:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:07:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:07:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:07:32 --> Total execution time: 0.0527
INFO - 2024-02-27 00:07:33 --> Config Class Initialized
INFO - 2024-02-27 00:07:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:07:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:07:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:07:33 --> URI Class Initialized
INFO - 2024-02-27 00:07:33 --> Router Class Initialized
INFO - 2024-02-27 00:07:33 --> Output Class Initialized
INFO - 2024-02-27 00:07:33 --> Security Class Initialized
INFO - 2024-02-27 00:07:33 --> Config Class Initialized
INFO - 2024-02-27 00:07:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:07:33 --> Input Class Initialized
DEBUG - 2024-02-27 00:07:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:07:33 --> Language Class Initialized
INFO - 2024-02-27 00:07:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:07:33 --> Config Class Initialized
INFO - 2024-02-27 00:07:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:07:33 --> Loader Class Initialized
INFO - 2024-02-27 00:07:33 --> URI Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:07:33 --> Config Class Initialized
INFO - 2024-02-27 00:07:33 --> Hooks Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:07:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:07:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:07:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:07:33 --> Router Class Initialized
INFO - 2024-02-27 00:07:33 --> URI Class Initialized
INFO - 2024-02-27 00:07:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:07:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:07:33 --> Output Class Initialized
INFO - 2024-02-27 00:07:33 --> Security Class Initialized
INFO - 2024-02-27 00:07:33 --> URI Class Initialized
INFO - 2024-02-27 00:07:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:07:33 --> Router Class Initialized
INFO - 2024-02-27 00:07:33 --> Router Class Initialized
DEBUG - 2024-02-27 00:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:07:33 --> Output Class Initialized
INFO - 2024-02-27 00:07:33 --> Output Class Initialized
INFO - 2024-02-27 00:07:33 --> Input Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:07:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:07:33 --> Controller Class Initialized
INFO - 2024-02-27 00:07:33 --> Language Class Initialized
INFO - 2024-02-27 00:07:33 --> Security Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:07:33 --> Security Class Initialized
DEBUG - 2024-02-27 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:07:33 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:07:33 --> Input Class Initialized
INFO - 2024-02-27 00:07:33 --> Loader Class Initialized
INFO - 2024-02-27 00:07:33 --> Input Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Language Class Initialized
INFO - 2024-02-27 00:07:33 --> Language Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:07:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:07:33 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:07:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:07:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:07:33 --> Total execution time: 0.0817
INFO - 2024-02-27 00:07:33 --> Loader Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:07:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:07:33 --> Loader Class Initialized
INFO - 2024-02-27 00:07:33 --> Email Class Initialized
INFO - 2024-02-27 00:07:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:07:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:07:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:07:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:07:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:07:33 --> Controller Class Initialized
INFO - 2024-02-27 00:07:33 --> Email Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:07:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:07:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:07:33 --> Total execution time: 0.1060
INFO - 2024-02-27 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:07:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:07:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:07:33 --> Controller Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:07:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:07:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:07:33 --> Total execution time: 0.1372
INFO - 2024-02-27 00:07:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:07:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:07:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:07:33 --> Controller Class Initialized
INFO - 2024-02-27 00:07:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:07:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:07:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:07:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:07:33 --> Total execution time: 0.1538
INFO - 2024-02-27 00:08:01 --> Config Class Initialized
INFO - 2024-02-27 00:08:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:01 --> URI Class Initialized
INFO - 2024-02-27 00:08:01 --> Router Class Initialized
INFO - 2024-02-27 00:08:01 --> Output Class Initialized
INFO - 2024-02-27 00:08:01 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:01 --> Input Class Initialized
INFO - 2024-02-27 00:08:01 --> Language Class Initialized
INFO - 2024-02-27 00:08:01 --> Loader Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:01 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:01 --> Controller Class Initialized
INFO - 2024-02-27 00:08:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:01 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:08:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:01 --> Total execution time: 0.0833
INFO - 2024-02-27 00:08:01 --> Config Class Initialized
INFO - 2024-02-27 00:08:01 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:01 --> Config Class Initialized
INFO - 2024-02-27 00:08:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:01 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:01 --> Config Class Initialized
INFO - 2024-02-27 00:08:01 --> Config Class Initialized
INFO - 2024-02-27 00:08:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:01 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:01 --> URI Class Initialized
INFO - 2024-02-27 00:08:01 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:01 --> URI Class Initialized
DEBUG - 2024-02-27 00:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:01 --> Router Class Initialized
INFO - 2024-02-27 00:08:01 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:08:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:01 --> Router Class Initialized
INFO - 2024-02-27 00:08:01 --> Output Class Initialized
INFO - 2024-02-27 00:08:01 --> URI Class Initialized
INFO - 2024-02-27 00:08:01 --> URI Class Initialized
INFO - 2024-02-27 00:08:01 --> Security Class Initialized
INFO - 2024-02-27 00:08:01 --> Output Class Initialized
INFO - 2024-02-27 00:08:01 --> Router Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:01 --> Router Class Initialized
INFO - 2024-02-27 00:08:01 --> Security Class Initialized
INFO - 2024-02-27 00:08:01 --> Input Class Initialized
INFO - 2024-02-27 00:08:01 --> Output Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:01 --> Output Class Initialized
INFO - 2024-02-27 00:08:01 --> Input Class Initialized
INFO - 2024-02-27 00:08:01 --> Language Class Initialized
INFO - 2024-02-27 00:08:01 --> Security Class Initialized
INFO - 2024-02-27 00:08:01 --> Security Class Initialized
INFO - 2024-02-27 00:08:01 --> Language Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:01 --> Input Class Initialized
INFO - 2024-02-27 00:08:01 --> Loader Class Initialized
INFO - 2024-02-27 00:08:01 --> Loader Class Initialized
INFO - 2024-02-27 00:08:01 --> Language Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:01 --> Loader Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:01 --> Input Class Initialized
INFO - 2024-02-27 00:08:01 --> Language Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:01 --> Loader Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:01 --> Email Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:01 --> Controller Class Initialized
INFO - 2024-02-27 00:08:01 --> Email Class Initialized
INFO - 2024-02-27 00:08:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:01 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:01 --> Total execution time: 0.2145
INFO - 2024-02-27 00:08:01 --> Email Class Initialized
INFO - 2024-02-27 00:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:01 --> Controller Class Initialized
DEBUG - 2024-02-27 00:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:01 --> Total execution time: 0.2811
INFO - 2024-02-27 00:08:01 --> Email Class Initialized
INFO - 2024-02-27 00:08:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:01 --> Controller Class Initialized
INFO - 2024-02-27 00:08:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:01 --> Total execution time: 0.2935
INFO - 2024-02-27 00:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:01 --> Controller Class Initialized
INFO - 2024-02-27 00:08:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:01 --> Total execution time: 0.3344
INFO - 2024-02-27 00:08:02 --> Config Class Initialized
INFO - 2024-02-27 00:08:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:02 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:02 --> URI Class Initialized
INFO - 2024-02-27 00:08:02 --> Router Class Initialized
INFO - 2024-02-27 00:08:02 --> Output Class Initialized
INFO - 2024-02-27 00:08:02 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:02 --> Input Class Initialized
INFO - 2024-02-27 00:08:02 --> Language Class Initialized
INFO - 2024-02-27 00:08:02 --> Loader Class Initialized
INFO - 2024-02-27 00:08:02 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:02 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:02 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:02 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:02 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:02 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:02 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:02 --> Controller Class Initialized
INFO - 2024-02-27 00:08:02 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:02 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:08:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:02 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:02 --> Total execution time: 0.0660
INFO - 2024-02-27 00:08:02 --> Config Class Initialized
INFO - 2024-02-27 00:08:02 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:02 --> Config Class Initialized
INFO - 2024-02-27 00:08:02 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:02 --> Config Class Initialized
DEBUG - 2024-02-27 00:08:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:02 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:02 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:08:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:02 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:03 --> URI Class Initialized
INFO - 2024-02-27 00:08:03 --> Config Class Initialized
INFO - 2024-02-27 00:08:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:03 --> URI Class Initialized
DEBUG - 2024-02-27 00:08:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:03 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:03 --> URI Class Initialized
INFO - 2024-02-27 00:08:03 --> Router Class Initialized
INFO - 2024-02-27 00:08:03 --> Router Class Initialized
INFO - 2024-02-27 00:08:03 --> Router Class Initialized
INFO - 2024-02-27 00:08:03 --> Output Class Initialized
INFO - 2024-02-27 00:08:03 --> Output Class Initialized
INFO - 2024-02-27 00:08:03 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:03 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:03 --> Input Class Initialized
INFO - 2024-02-27 00:08:03 --> Language Class Initialized
INFO - 2024-02-27 00:08:03 --> URI Class Initialized
INFO - 2024-02-27 00:08:03 --> Security Class Initialized
INFO - 2024-02-27 00:08:03 --> Loader Class Initialized
INFO - 2024-02-27 00:08:03 --> Router Class Initialized
DEBUG - 2024-02-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:03 --> Input Class Initialized
INFO - 2024-02-27 00:08:03 --> Output Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:03 --> Language Class Initialized
INFO - 2024-02-27 00:08:03 --> Loader Class Initialized
INFO - 2024-02-27 00:08:03 --> Security Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:03 --> Input Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:03 --> Language Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:03 --> Loader Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:03 --> Output Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:03 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:03 --> Input Class Initialized
INFO - 2024-02-27 00:08:03 --> Language Class Initialized
INFO - 2024-02-27 00:08:03 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:03 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:03 --> Loader Class Initialized
INFO - 2024-02-27 00:08:03 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:03 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:03 --> Controller Class Initialized
INFO - 2024-02-27 00:08:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:03 --> Email Class Initialized
INFO - 2024-02-27 00:08:03 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:03 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:03 --> Total execution time: 0.1295
INFO - 2024-02-27 00:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:03 --> Email Class Initialized
INFO - 2024-02-27 00:08:03 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:03 --> Controller Class Initialized
INFO - 2024-02-27 00:08:03 --> Email Class Initialized
INFO - 2024-02-27 00:08:03 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:03 --> Total execution time: 0.1564
INFO - 2024-02-27 00:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:03 --> Controller Class Initialized
INFO - 2024-02-27 00:08:03 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:03 --> Total execution time: 0.1798
INFO - 2024-02-27 00:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:03 --> Controller Class Initialized
INFO - 2024-02-27 00:08:03 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:03 --> Total execution time: 0.1933
INFO - 2024-02-27 00:08:39 --> Config Class Initialized
INFO - 2024-02-27 00:08:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:39 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:39 --> URI Class Initialized
INFO - 2024-02-27 00:08:39 --> Router Class Initialized
INFO - 2024-02-27 00:08:39 --> Output Class Initialized
INFO - 2024-02-27 00:08:39 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:39 --> Input Class Initialized
INFO - 2024-02-27 00:08:39 --> Language Class Initialized
INFO - 2024-02-27 00:08:39 --> Loader Class Initialized
INFO - 2024-02-27 00:08:39 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:39 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:39 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:39 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:39 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:39 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:39 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:39 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:39 --> Controller Class Initialized
INFO - 2024-02-27 00:08:39 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:39 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:08:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:39 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:39 --> Total execution time: 0.0559
INFO - 2024-02-27 00:08:40 --> Config Class Initialized
INFO - 2024-02-27 00:08:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:40 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:40 --> Config Class Initialized
INFO - 2024-02-27 00:08:40 --> URI Class Initialized
INFO - 2024-02-27 00:08:40 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:40 --> Router Class Initialized
INFO - 2024-02-27 00:08:40 --> Output Class Initialized
INFO - 2024-02-27 00:08:40 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:40 --> Input Class Initialized
DEBUG - 2024-02-27 00:08:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:40 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:40 --> Language Class Initialized
INFO - 2024-02-27 00:08:40 --> URI Class Initialized
INFO - 2024-02-27 00:08:40 --> Loader Class Initialized
INFO - 2024-02-27 00:08:40 --> Router Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:40 --> Output Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:40 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:40 --> Security Class Initialized
INFO - 2024-02-27 00:08:40 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:40 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:40 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:40 --> Controller Class Initialized
INFO - 2024-02-27 00:08:40 --> Config Class Initialized
DEBUG - 2024-02-27 00:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:40 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:40 --> Input Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:40 --> Language Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:40 --> Loader Class Initialized
INFO - 2024-02-27 00:08:40 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:40 --> Total execution time: 0.0814
DEBUG - 2024-02-27 00:08:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:40 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:40 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:40 --> Config Class Initialized
INFO - 2024-02-27 00:08:40 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:08:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:40 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:40 --> URI Class Initialized
INFO - 2024-02-27 00:08:40 --> Router Class Initialized
INFO - 2024-02-27 00:08:40 --> Output Class Initialized
INFO - 2024-02-27 00:08:40 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:40 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:40 --> Input Class Initialized
INFO - 2024-02-27 00:08:40 --> Language Class Initialized
INFO - 2024-02-27 00:08:40 --> Loader Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:40 --> Email Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:40 --> URI Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:40 --> Router Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:40 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:40 --> Controller Class Initialized
INFO - 2024-02-27 00:08:40 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:40 --> Output Class Initialized
INFO - 2024-02-27 00:08:40 --> Security Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:40 --> Input Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Language Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:40 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:40 --> Total execution time: 0.1543
INFO - 2024-02-27 00:08:40 --> Loader Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:40 --> Email Class Initialized
INFO - 2024-02-27 00:08:40 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:40 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:40 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:40 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:40 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:40 --> Controller Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:40 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:40 --> Email Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:40 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:40 --> Total execution time: 0.0947
DEBUG - 2024-02-27 00:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:40 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:40 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:40 --> Controller Class Initialized
INFO - 2024-02-27 00:08:40 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:40 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:40 --> Total execution time: 0.1902
INFO - 2024-02-27 00:08:46 --> Config Class Initialized
INFO - 2024-02-27 00:08:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:46 --> URI Class Initialized
INFO - 2024-02-27 00:08:46 --> Router Class Initialized
INFO - 2024-02-27 00:08:46 --> Output Class Initialized
INFO - 2024-02-27 00:08:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:46 --> Input Class Initialized
INFO - 2024-02-27 00:08:46 --> Language Class Initialized
INFO - 2024-02-27 00:08:46 --> Loader Class Initialized
INFO - 2024-02-27 00:08:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:46 --> Controller Class Initialized
INFO - 2024-02-27 00:08:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:08:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:46 --> Total execution time: 0.0785
INFO - 2024-02-27 00:08:47 --> Config Class Initialized
INFO - 2024-02-27 00:08:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:47 --> Config Class Initialized
INFO - 2024-02-27 00:08:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:47 --> Config Class Initialized
INFO - 2024-02-27 00:08:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:08:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:47 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:08:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:47 --> Config Class Initialized
INFO - 2024-02-27 00:08:47 --> URI Class Initialized
INFO - 2024-02-27 00:08:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:47 --> URI Class Initialized
INFO - 2024-02-27 00:08:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:47 --> Router Class Initialized
INFO - 2024-02-27 00:08:47 --> URI Class Initialized
DEBUG - 2024-02-27 00:08:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:47 --> Router Class Initialized
INFO - 2024-02-27 00:08:47 --> Output Class Initialized
INFO - 2024-02-27 00:08:47 --> URI Class Initialized
INFO - 2024-02-27 00:08:47 --> Output Class Initialized
INFO - 2024-02-27 00:08:47 --> Router Class Initialized
INFO - 2024-02-27 00:08:47 --> Security Class Initialized
INFO - 2024-02-27 00:08:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:47 --> Input Class Initialized
INFO - 2024-02-27 00:08:47 --> Output Class Initialized
INFO - 2024-02-27 00:08:47 --> Language Class Initialized
INFO - 2024-02-27 00:08:47 --> Router Class Initialized
DEBUG - 2024-02-27 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:47 --> Security Class Initialized
INFO - 2024-02-27 00:08:47 --> Input Class Initialized
INFO - 2024-02-27 00:08:47 --> Language Class Initialized
DEBUG - 2024-02-27 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:47 --> Output Class Initialized
INFO - 2024-02-27 00:08:47 --> Loader Class Initialized
INFO - 2024-02-27 00:08:47 --> Input Class Initialized
INFO - 2024-02-27 00:08:47 --> Security Class Initialized
INFO - 2024-02-27 00:08:47 --> Loader Class Initialized
INFO - 2024-02-27 00:08:47 --> Language Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:47 --> Input Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:47 --> Language Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:47 --> Loader Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:47 --> Loader Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:47 --> Email Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:47 --> Email Class Initialized
INFO - 2024-02-27 00:08:47 --> Email Class Initialized
INFO - 2024-02-27 00:08:47 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:47 --> Controller Class Initialized
INFO - 2024-02-27 00:08:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:47 --> Email Class Initialized
INFO - 2024-02-27 00:08:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:47 --> Total execution time: 0.1114
INFO - 2024-02-27 00:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:47 --> Controller Class Initialized
INFO - 2024-02-27 00:08:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:47 --> Total execution time: 0.1660
INFO - 2024-02-27 00:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:47 --> Controller Class Initialized
INFO - 2024-02-27 00:08:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:47 --> Total execution time: 0.1951
INFO - 2024-02-27 00:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:47 --> Controller Class Initialized
INFO - 2024-02-27 00:08:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:47 --> Total execution time: 0.2095
INFO - 2024-02-27 00:08:48 --> Config Class Initialized
INFO - 2024-02-27 00:08:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:48 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:48 --> URI Class Initialized
INFO - 2024-02-27 00:08:48 --> Router Class Initialized
INFO - 2024-02-27 00:08:48 --> Output Class Initialized
INFO - 2024-02-27 00:08:48 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:48 --> Input Class Initialized
INFO - 2024-02-27 00:08:48 --> Language Class Initialized
INFO - 2024-02-27 00:08:48 --> Loader Class Initialized
INFO - 2024-02-27 00:08:48 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:48 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:48 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:48 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:48 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:48 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:48 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:48 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:48 --> Controller Class Initialized
INFO - 2024-02-27 00:08:48 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:08:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:48 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:48 --> Total execution time: 0.0768
INFO - 2024-02-27 00:08:52 --> Config Class Initialized
INFO - 2024-02-27 00:08:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:52 --> URI Class Initialized
INFO - 2024-02-27 00:08:52 --> Router Class Initialized
INFO - 2024-02-27 00:08:52 --> Output Class Initialized
INFO - 2024-02-27 00:08:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:52 --> Input Class Initialized
INFO - 2024-02-27 00:08:52 --> Language Class Initialized
INFO - 2024-02-27 00:08:52 --> Loader Class Initialized
INFO - 2024-02-27 00:08:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:52 --> Controller Class Initialized
INFO - 2024-02-27 00:08:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:08:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:08:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:08:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:08:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:08:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:52 --> Total execution time: 0.0523
INFO - 2024-02-27 00:08:53 --> Config Class Initialized
INFO - 2024-02-27 00:08:53 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:08:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:53 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:53 --> URI Class Initialized
INFO - 2024-02-27 00:08:53 --> Router Class Initialized
INFO - 2024-02-27 00:08:53 --> Output Class Initialized
INFO - 2024-02-27 00:08:53 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:53 --> Input Class Initialized
INFO - 2024-02-27 00:08:53 --> Language Class Initialized
INFO - 2024-02-27 00:08:53 --> Config Class Initialized
INFO - 2024-02-27 00:08:53 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:53 --> Config Class Initialized
INFO - 2024-02-27 00:08:53 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:53 --> Loader Class Initialized
DEBUG - 2024-02-27 00:08:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:53 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:53 --> URI Class Initialized
DEBUG - 2024-02-27 00:08:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:53 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:53 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:53 --> Router Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:53 --> URI Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:53 --> Output Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:53 --> Router Class Initialized
INFO - 2024-02-27 00:08:53 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:53 --> Input Class Initialized
INFO - 2024-02-27 00:08:53 --> Output Class Initialized
INFO - 2024-02-27 00:08:53 --> Language Class Initialized
INFO - 2024-02-27 00:08:53 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:53 --> Input Class Initialized
INFO - 2024-02-27 00:08:53 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:53 --> Language Class Initialized
INFO - 2024-02-27 00:08:53 --> Loader Class Initialized
INFO - 2024-02-27 00:08:53 --> Loader Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: url_helper
INFO - 2024-02-27 00:08:53 --> Config Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:53 --> Hooks Class Initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:53 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:53 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:08:53 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:08:53 --> Utf8 Class Initialized
INFO - 2024-02-27 00:08:53 --> URI Class Initialized
INFO - 2024-02-27 00:08:53 --> Email Class Initialized
INFO - 2024-02-27 00:08:53 --> Email Class Initialized
INFO - 2024-02-27 00:08:53 --> Router Class Initialized
INFO - 2024-02-27 00:08:53 --> Email Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:53 --> Output Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:53 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:53 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:53 --> Controller Class Initialized
INFO - 2024-02-27 00:08:53 --> Security Class Initialized
DEBUG - 2024-02-27 00:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:08:53 --> Input Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:53 --> Language Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:53 --> Loader Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:08:53 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:53 --> Helper loaded: file_helper
INFO - 2024-02-27 00:08:53 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:53 --> Total execution time: 0.0804
INFO - 2024-02-27 00:08:53 --> Helper loaded: security_helper
INFO - 2024-02-27 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:53 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:08:53 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:53 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:53 --> Controller Class Initialized
INFO - 2024-02-27 00:08:53 --> Database Driver Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Email Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:08:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:53 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:53 --> Total execution time: 0.1226
INFO - 2024-02-27 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:53 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:53 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:53 --> Controller Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:53 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:53 --> Total execution time: 0.1251
INFO - 2024-02-27 00:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:08:53 --> Helper loaded: form_helper
INFO - 2024-02-27 00:08:53 --> Form Validation Class Initialized
INFO - 2024-02-27 00:08:53 --> Controller Class Initialized
INFO - 2024-02-27 00:08:53 --> Model "User_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:08:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:08:53 --> Final output sent to browser
DEBUG - 2024-02-27 00:08:53 --> Total execution time: 0.1336
INFO - 2024-02-27 00:09:13 --> Config Class Initialized
INFO - 2024-02-27 00:09:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:13 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:13 --> URI Class Initialized
INFO - 2024-02-27 00:09:13 --> Router Class Initialized
INFO - 2024-02-27 00:09:13 --> Output Class Initialized
INFO - 2024-02-27 00:09:13 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:13 --> Input Class Initialized
INFO - 2024-02-27 00:09:13 --> Language Class Initialized
INFO - 2024-02-27 00:09:13 --> Loader Class Initialized
INFO - 2024-02-27 00:09:13 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:13 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:13 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:13 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:13 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:13 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:13 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:13 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:13 --> Controller Class Initialized
INFO - 2024-02-27 00:09:13 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:09:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:09:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:09:13 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:09:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:09:13 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:13 --> Total execution time: 0.0510
INFO - 2024-02-27 00:09:14 --> Config Class Initialized
INFO - 2024-02-27 00:09:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:14 --> Config Class Initialized
INFO - 2024-02-27 00:09:14 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:14 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:14 --> URI Class Initialized
INFO - 2024-02-27 00:09:14 --> URI Class Initialized
INFO - 2024-02-27 00:09:14 --> Router Class Initialized
INFO - 2024-02-27 00:09:14 --> Router Class Initialized
INFO - 2024-02-27 00:09:14 --> Output Class Initialized
INFO - 2024-02-27 00:09:14 --> Security Class Initialized
INFO - 2024-02-27 00:09:14 --> Output Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:14 --> Input Class Initialized
INFO - 2024-02-27 00:09:14 --> Language Class Initialized
INFO - 2024-02-27 00:09:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:14 --> Input Class Initialized
INFO - 2024-02-27 00:09:14 --> Loader Class Initialized
INFO - 2024-02-27 00:09:14 --> Language Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:14 --> Loader Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:14 --> Email Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:14 --> Config Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:14 --> Config Class Initialized
INFO - 2024-02-27 00:09:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:14 --> URI Class Initialized
INFO - 2024-02-27 00:09:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:14 --> Router Class Initialized
INFO - 2024-02-27 00:09:14 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:14 --> Output Class Initialized
INFO - 2024-02-27 00:09:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:14 --> Security Class Initialized
INFO - 2024-02-27 00:09:14 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:14 --> URI Class Initialized
INFO - 2024-02-27 00:09:14 --> Input Class Initialized
INFO - 2024-02-27 00:09:14 --> Router Class Initialized
INFO - 2024-02-27 00:09:14 --> Language Class Initialized
INFO - 2024-02-27 00:09:14 --> Loader Class Initialized
INFO - 2024-02-27 00:09:14 --> Output Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:14 --> Security Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:14 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:14 --> Input Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:14 --> Language Class Initialized
INFO - 2024-02-27 00:09:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:14 --> Email Class Initialized
INFO - 2024-02-27 00:09:14 --> Controller Class Initialized
INFO - 2024-02-27 00:09:14 --> Loader Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:14 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:09:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:14 --> Total execution time: 0.1475
INFO - 2024-02-27 00:09:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:14 --> Controller Class Initialized
INFO - 2024-02-27 00:09:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:09:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:14 --> Total execution time: 0.1749
INFO - 2024-02-27 00:09:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:14 --> Controller Class Initialized
INFO - 2024-02-27 00:09:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:14 --> Total execution time: 0.1598
INFO - 2024-02-27 00:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:14 --> Controller Class Initialized
INFO - 2024-02-27 00:09:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:14 --> Total execution time: 0.2190
INFO - 2024-02-27 00:09:22 --> Config Class Initialized
INFO - 2024-02-27 00:09:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:22 --> URI Class Initialized
INFO - 2024-02-27 00:09:22 --> Router Class Initialized
INFO - 2024-02-27 00:09:22 --> Output Class Initialized
INFO - 2024-02-27 00:09:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:22 --> Input Class Initialized
INFO - 2024-02-27 00:09:22 --> Language Class Initialized
INFO - 2024-02-27 00:09:22 --> Loader Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:22 --> Controller Class Initialized
INFO - 2024-02-27 00:09:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:09:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:09:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:09:22 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:09:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:09:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:22 --> Total execution time: 0.0772
INFO - 2024-02-27 00:09:22 --> Config Class Initialized
INFO - 2024-02-27 00:09:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:22 --> URI Class Initialized
INFO - 2024-02-27 00:09:22 --> Router Class Initialized
INFO - 2024-02-27 00:09:22 --> Output Class Initialized
INFO - 2024-02-27 00:09:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:22 --> Input Class Initialized
INFO - 2024-02-27 00:09:22 --> Language Class Initialized
INFO - 2024-02-27 00:09:22 --> Loader Class Initialized
INFO - 2024-02-27 00:09:22 --> Config Class Initialized
INFO - 2024-02-27 00:09:22 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:09:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:22 --> URI Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:22 --> Router Class Initialized
INFO - 2024-02-27 00:09:22 --> Output Class Initialized
INFO - 2024-02-27 00:09:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:22 --> Input Class Initialized
INFO - 2024-02-27 00:09:22 --> Language Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:22 --> Loader Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:22 --> Config Class Initialized
INFO - 2024-02-27 00:09:22 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:09:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:22 --> Config Class Initialized
INFO - 2024-02-27 00:09:22 --> URI Class Initialized
INFO - 2024-02-27 00:09:22 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:22 --> Router Class Initialized
INFO - 2024-02-27 00:09:22 --> Output Class Initialized
INFO - 2024-02-27 00:09:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:22 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:22 --> Input Class Initialized
INFO - 2024-02-27 00:09:22 --> URI Class Initialized
INFO - 2024-02-27 00:09:22 --> Language Class Initialized
INFO - 2024-02-27 00:09:22 --> Router Class Initialized
INFO - 2024-02-27 00:09:22 --> Loader Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:22 --> Output Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:22 --> Security Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:22 --> Input Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:22 --> Language Class Initialized
INFO - 2024-02-27 00:09:22 --> Loader Class Initialized
INFO - 2024-02-27 00:09:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:22 --> Email Class Initialized
INFO - 2024-02-27 00:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:22 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:22 --> Email Class Initialized
INFO - 2024-02-27 00:09:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:22 --> Controller Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:22 --> Total execution time: 0.0924
INFO - 2024-02-27 00:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:22 --> Email Class Initialized
INFO - 2024-02-27 00:09:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:22 --> Controller Class Initialized
DEBUG - 2024-02-27 00:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:22 --> Total execution time: 0.2026
INFO - 2024-02-27 00:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:22 --> Controller Class Initialized
INFO - 2024-02-27 00:09:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:22 --> Total execution time: 0.1431
INFO - 2024-02-27 00:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:22 --> Controller Class Initialized
INFO - 2024-02-27 00:09:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:22 --> Total execution time: 0.2170
INFO - 2024-02-27 00:09:23 --> Config Class Initialized
INFO - 2024-02-27 00:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:23 --> URI Class Initialized
INFO - 2024-02-27 00:09:23 --> Router Class Initialized
INFO - 2024-02-27 00:09:23 --> Output Class Initialized
INFO - 2024-02-27 00:09:23 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:23 --> Input Class Initialized
INFO - 2024-02-27 00:09:23 --> Language Class Initialized
INFO - 2024-02-27 00:09:23 --> Loader Class Initialized
INFO - 2024-02-27 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:23 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:23 --> Controller Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:09:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:09:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:09:23 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:09:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:09:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:23 --> Total execution time: 0.0856
INFO - 2024-02-27 00:09:23 --> Config Class Initialized
INFO - 2024-02-27 00:09:23 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:23 --> Config Class Initialized
INFO - 2024-02-27 00:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:23 --> Config Class Initialized
INFO - 2024-02-27 00:09:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:23 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:23 --> Config Class Initialized
INFO - 2024-02-27 00:09:23 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:23 --> URI Class Initialized
DEBUG - 2024-02-27 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:23 --> Router Class Initialized
DEBUG - 2024-02-27 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:23 --> URI Class Initialized
INFO - 2024-02-27 00:09:23 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:23 --> URI Class Initialized
INFO - 2024-02-27 00:09:23 --> Output Class Initialized
INFO - 2024-02-27 00:09:23 --> URI Class Initialized
INFO - 2024-02-27 00:09:23 --> Router Class Initialized
INFO - 2024-02-27 00:09:23 --> Router Class Initialized
INFO - 2024-02-27 00:09:23 --> Security Class Initialized
INFO - 2024-02-27 00:09:23 --> Router Class Initialized
INFO - 2024-02-27 00:09:23 --> Output Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:23 --> Output Class Initialized
INFO - 2024-02-27 00:09:23 --> Output Class Initialized
INFO - 2024-02-27 00:09:23 --> Input Class Initialized
INFO - 2024-02-27 00:09:23 --> Security Class Initialized
INFO - 2024-02-27 00:09:23 --> Language Class Initialized
INFO - 2024-02-27 00:09:23 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:23 --> Security Class Initialized
INFO - 2024-02-27 00:09:23 --> Input Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:23 --> Language Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:23 --> Input Class Initialized
INFO - 2024-02-27 00:09:23 --> Input Class Initialized
INFO - 2024-02-27 00:09:23 --> Language Class Initialized
INFO - 2024-02-27 00:09:23 --> Language Class Initialized
INFO - 2024-02-27 00:09:23 --> Loader Class Initialized
INFO - 2024-02-27 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:23 --> Loader Class Initialized
INFO - 2024-02-27 00:09:23 --> Loader Class Initialized
INFO - 2024-02-27 00:09:23 --> Loader Class Initialized
INFO - 2024-02-27 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:23 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:23 --> Email Class Initialized
INFO - 2024-02-27 00:09:23 --> Controller Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:23 --> Email Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "Faktur_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:23 --> Total execution time: 0.0665
INFO - 2024-02-27 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:23 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:23 --> Controller Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:23 --> Total execution time: 0.0903
INFO - 2024-02-27 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:23 --> Controller Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:23 --> Total execution time: 0.1098
INFO - 2024-02-27 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:23 --> Controller Class Initialized
INFO - 2024-02-27 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:24 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:24 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:24 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:24 --> Total execution time: 0.1344
INFO - 2024-02-27 00:09:48 --> Config Class Initialized
INFO - 2024-02-27 00:09:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:48 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:48 --> URI Class Initialized
INFO - 2024-02-27 00:09:48 --> Router Class Initialized
INFO - 2024-02-27 00:09:48 --> Output Class Initialized
INFO - 2024-02-27 00:09:48 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:48 --> Input Class Initialized
INFO - 2024-02-27 00:09:48 --> Language Class Initialized
INFO - 2024-02-27 00:09:48 --> Loader Class Initialized
INFO - 2024-02-27 00:09:48 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:48 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:48 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:48 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:48 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:48 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:48 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:48 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:48 --> Controller Class Initialized
INFO - 2024-02-27 00:09:48 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:09:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:09:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:09:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:09:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:09:48 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:48 --> Total execution time: 0.0745
INFO - 2024-02-27 00:09:49 --> Config Class Initialized
INFO - 2024-02-27 00:09:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:49 --> Config Class Initialized
INFO - 2024-02-27 00:09:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:09:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:49 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:09:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:49 --> URI Class Initialized
INFO - 2024-02-27 00:09:49 --> URI Class Initialized
INFO - 2024-02-27 00:09:49 --> Config Class Initialized
INFO - 2024-02-27 00:09:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:49 --> Router Class Initialized
INFO - 2024-02-27 00:09:49 --> Router Class Initialized
INFO - 2024-02-27 00:09:49 --> Output Class Initialized
INFO - 2024-02-27 00:09:49 --> Output Class Initialized
INFO - 2024-02-27 00:09:49 --> Security Class Initialized
INFO - 2024-02-27 00:09:49 --> Config Class Initialized
DEBUG - 2024-02-27 00:09:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:09:49 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:49 --> URI Class Initialized
INFO - 2024-02-27 00:09:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:09:49 --> Input Class Initialized
INFO - 2024-02-27 00:09:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:09:49 --> Language Class Initialized
INFO - 2024-02-27 00:09:49 --> Router Class Initialized
DEBUG - 2024-02-27 00:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:49 --> URI Class Initialized
INFO - 2024-02-27 00:09:49 --> Input Class Initialized
INFO - 2024-02-27 00:09:49 --> Output Class Initialized
INFO - 2024-02-27 00:09:49 --> Loader Class Initialized
INFO - 2024-02-27 00:09:49 --> Language Class Initialized
INFO - 2024-02-27 00:09:49 --> Security Class Initialized
INFO - 2024-02-27 00:09:49 --> Router Class Initialized
INFO - 2024-02-27 00:09:49 --> Output Class Initialized
INFO - 2024-02-27 00:09:49 --> Loader Class Initialized
INFO - 2024-02-27 00:09:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:49 --> Input Class Initialized
INFO - 2024-02-27 00:09:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:49 --> Language Class Initialized
INFO - 2024-02-27 00:09:49 --> Loader Class Initialized
INFO - 2024-02-27 00:09:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:09:49 --> Input Class Initialized
INFO - 2024-02-27 00:09:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:49 --> Language Class Initialized
INFO - 2024-02-27 00:09:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:49 --> Loader Class Initialized
INFO - 2024-02-27 00:09:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:09:49 --> Email Class Initialized
INFO - 2024-02-27 00:09:49 --> Email Class Initialized
INFO - 2024-02-27 00:09:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:09:49 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:49 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:09:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:49 --> Controller Class Initialized
INFO - 2024-02-27 00:09:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:09:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:49 --> Email Class Initialized
INFO - 2024-02-27 00:09:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:09:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:49 --> Total execution time: 0.1551
INFO - 2024-02-27 00:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:49 --> Controller Class Initialized
INFO - 2024-02-27 00:09:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:49 --> Total execution time: 0.2189
INFO - 2024-02-27 00:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:49 --> Controller Class Initialized
INFO - 2024-02-27 00:09:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:49 --> Total execution time: 0.2480
INFO - 2024-02-27 00:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:09:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:09:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:09:49 --> Controller Class Initialized
INFO - 2024-02-27 00:09:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:09:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:09:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:09:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:09:49 --> Total execution time: 0.2651
INFO - 2024-02-27 00:11:14 --> Config Class Initialized
INFO - 2024-02-27 00:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:14 --> URI Class Initialized
INFO - 2024-02-27 00:11:14 --> Router Class Initialized
INFO - 2024-02-27 00:11:14 --> Output Class Initialized
INFO - 2024-02-27 00:11:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:14 --> Input Class Initialized
INFO - 2024-02-27 00:11:14 --> Language Class Initialized
INFO - 2024-02-27 00:11:14 --> Loader Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:14 --> Controller Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:11:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:11:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:11:14 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:11:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:11:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:14 --> Total execution time: 0.0777
INFO - 2024-02-27 00:11:14 --> Config Class Initialized
INFO - 2024-02-27 00:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:14 --> URI Class Initialized
INFO - 2024-02-27 00:11:14 --> Router Class Initialized
INFO - 2024-02-27 00:11:14 --> Output Class Initialized
INFO - 2024-02-27 00:11:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:14 --> Input Class Initialized
INFO - 2024-02-27 00:11:14 --> Language Class Initialized
INFO - 2024-02-27 00:11:14 --> Loader Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:14 --> Config Class Initialized
INFO - 2024-02-27 00:11:14 --> Config Class Initialized
INFO - 2024-02-27 00:11:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:14 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:14 --> URI Class Initialized
INFO - 2024-02-27 00:11:14 --> Config Class Initialized
INFO - 2024-02-27 00:11:14 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:14 --> Router Class Initialized
INFO - 2024-02-27 00:11:14 --> Output Class Initialized
INFO - 2024-02-27 00:11:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:14 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:14 --> Input Class Initialized
INFO - 2024-02-27 00:11:14 --> Language Class Initialized
DEBUG - 2024-02-27 00:11:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:14 --> URI Class Initialized
INFO - 2024-02-27 00:11:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:14 --> Loader Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:14 --> URI Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:14 --> Router Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:14 --> Output Class Initialized
INFO - 2024-02-27 00:11:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:14 --> Router Class Initialized
INFO - 2024-02-27 00:11:14 --> Security Class Initialized
INFO - 2024-02-27 00:11:14 --> Email Class Initialized
INFO - 2024-02-27 00:11:14 --> Email Class Initialized
INFO - 2024-02-27 00:11:14 --> Output Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:14 --> Security Class Initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:14 --> Input Class Initialized
INFO - 2024-02-27 00:11:14 --> Controller Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:14 --> Input Class Initialized
INFO - 2024-02-27 00:11:14 --> Language Class Initialized
INFO - 2024-02-27 00:11:14 --> Language Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Loader Class Initialized
INFO - 2024-02-27 00:11:14 --> Loader Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:14 --> Total execution time: 0.1414
INFO - 2024-02-27 00:11:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:14 --> Controller Class Initialized
INFO - 2024-02-27 00:11:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:14 --> Email Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-27 00:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:14 --> Total execution time: 0.1850
INFO - 2024-02-27 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:14 --> Controller Class Initialized
INFO - 2024-02-27 00:11:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:15 --> Total execution time: 0.2067
INFO - 2024-02-27 00:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:15 --> Controller Class Initialized
INFO - 2024-02-27 00:11:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:15 --> Total execution time: 0.2185
INFO - 2024-02-27 00:11:16 --> Config Class Initialized
INFO - 2024-02-27 00:11:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:16 --> URI Class Initialized
INFO - 2024-02-27 00:11:16 --> Router Class Initialized
INFO - 2024-02-27 00:11:16 --> Output Class Initialized
INFO - 2024-02-27 00:11:16 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:16 --> Input Class Initialized
INFO - 2024-02-27 00:11:16 --> Language Class Initialized
INFO - 2024-02-27 00:11:16 --> Loader Class Initialized
INFO - 2024-02-27 00:11:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:16 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:16 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:16 --> Controller Class Initialized
INFO - 2024-02-27 00:11:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:11:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:11:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:11:16 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:11:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:11:16 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:16 --> Total execution time: 0.0542
INFO - 2024-02-27 00:11:17 --> Config Class Initialized
INFO - 2024-02-27 00:11:17 --> Config Class Initialized
INFO - 2024-02-27 00:11:17 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:17 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:17 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:17 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:17 --> URI Class Initialized
INFO - 2024-02-27 00:11:17 --> URI Class Initialized
INFO - 2024-02-27 00:11:17 --> Config Class Initialized
INFO - 2024-02-27 00:11:17 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:17 --> Router Class Initialized
INFO - 2024-02-27 00:11:17 --> Router Class Initialized
DEBUG - 2024-02-27 00:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:17 --> Output Class Initialized
INFO - 2024-02-27 00:11:17 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:17 --> Config Class Initialized
INFO - 2024-02-27 00:11:17 --> URI Class Initialized
INFO - 2024-02-27 00:11:17 --> Security Class Initialized
INFO - 2024-02-27 00:11:17 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:17 --> Output Class Initialized
DEBUG - 2024-02-27 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:17 --> Router Class Initialized
INFO - 2024-02-27 00:11:17 --> Input Class Initialized
INFO - 2024-02-27 00:11:17 --> Security Class Initialized
INFO - 2024-02-27 00:11:17 --> Language Class Initialized
INFO - 2024-02-27 00:11:17 --> Output Class Initialized
DEBUG - 2024-02-27 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:17 --> Input Class Initialized
INFO - 2024-02-27 00:11:17 --> Language Class Initialized
INFO - 2024-02-27 00:11:17 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:17 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:17 --> Loader Class Initialized
DEBUG - 2024-02-27 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:17 --> Input Class Initialized
INFO - 2024-02-27 00:11:17 --> URI Class Initialized
INFO - 2024-02-27 00:11:17 --> Language Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:17 --> Loader Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:17 --> Router Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:17 --> Loader Class Initialized
INFO - 2024-02-27 00:11:17 --> Output Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:17 --> Security Class Initialized
INFO - 2024-02-27 00:11:17 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:17 --> Email Class Initialized
INFO - 2024-02-27 00:11:17 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:17 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:17 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:17 --> Controller Class Initialized
INFO - 2024-02-27 00:11:17 --> Email Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:17 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Input Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-27 00:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:17 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:11:17 --> Language Class Initialized
DEBUG - 2024-02-27 00:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:17 --> Email Class Initialized
INFO - 2024-02-27 00:11:17 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:17 --> Total execution time: 0.0696
INFO - 2024-02-27 00:11:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:17 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:17 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:17 --> Controller Class Initialized
INFO - 2024-02-27 00:11:17 --> Loader Class Initialized
INFO - 2024-02-27 00:11:17 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:17 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:17 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:17 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:17 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:17 --> Total execution time: 0.0994
INFO - 2024-02-27 00:11:17 --> Email Class Initialized
INFO - 2024-02-27 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:17 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:17 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:17 --> Controller Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:17 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:17 --> Total execution time: 0.1077
INFO - 2024-02-27 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:17 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:17 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:17 --> Controller Class Initialized
INFO - 2024-02-27 00:11:17 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:17 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:17 --> Total execution time: 0.1316
INFO - 2024-02-27 00:11:18 --> Config Class Initialized
INFO - 2024-02-27 00:11:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:11:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:18 --> URI Class Initialized
INFO - 2024-02-27 00:11:18 --> Router Class Initialized
INFO - 2024-02-27 00:11:18 --> Output Class Initialized
INFO - 2024-02-27 00:11:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:18 --> Input Class Initialized
INFO - 2024-02-27 00:11:18 --> Language Class Initialized
INFO - 2024-02-27 00:11:18 --> Loader Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:18 --> Controller Class Initialized
INFO - 2024-02-27 00:11:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:11:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:11:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:11:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:11:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:11:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:18 --> Total execution time: 0.0579
INFO - 2024-02-27 00:11:18 --> Config Class Initialized
INFO - 2024-02-27 00:11:18 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:18 --> Config Class Initialized
DEBUG - 2024-02-27 00:11:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:18 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:18 --> Config Class Initialized
INFO - 2024-02-27 00:11:18 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:18 --> URI Class Initialized
INFO - 2024-02-27 00:11:18 --> Router Class Initialized
DEBUG - 2024-02-27 00:11:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:18 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:11:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:18 --> URI Class Initialized
INFO - 2024-02-27 00:11:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:18 --> Output Class Initialized
INFO - 2024-02-27 00:11:18 --> URI Class Initialized
INFO - 2024-02-27 00:11:18 --> Router Class Initialized
INFO - 2024-02-27 00:11:18 --> Security Class Initialized
INFO - 2024-02-27 00:11:18 --> Config Class Initialized
INFO - 2024-02-27 00:11:18 --> Hooks Class Initialized
INFO - 2024-02-27 00:11:18 --> Router Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:18 --> Output Class Initialized
INFO - 2024-02-27 00:11:18 --> Input Class Initialized
INFO - 2024-02-27 00:11:18 --> Language Class Initialized
INFO - 2024-02-27 00:11:18 --> Output Class Initialized
INFO - 2024-02-27 00:11:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:11:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:11:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:11:18 --> URI Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:18 --> Security Class Initialized
INFO - 2024-02-27 00:11:18 --> Loader Class Initialized
INFO - 2024-02-27 00:11:18 --> Input Class Initialized
INFO - 2024-02-27 00:11:18 --> Router Class Initialized
INFO - 2024-02-27 00:11:18 --> Language Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:18 --> Input Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:18 --> Output Class Initialized
INFO - 2024-02-27 00:11:18 --> Language Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:18 --> Security Class Initialized
INFO - 2024-02-27 00:11:18 --> Loader Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:11:18 --> Input Class Initialized
INFO - 2024-02-27 00:11:18 --> Loader Class Initialized
INFO - 2024-02-27 00:11:18 --> Language Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:18 --> Loader Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:18 --> Email Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:18 --> Controller Class Initialized
INFO - 2024-02-27 00:11:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Email Class Initialized
INFO - 2024-02-27 00:11:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:18 --> Total execution time: 0.0639
INFO - 2024-02-27 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:18 --> Controller Class Initialized
INFO - 2024-02-27 00:11:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:18 --> Total execution time: 0.0859
INFO - 2024-02-27 00:11:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:18 --> Controller Class Initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:11:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:11:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:11:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:18 --> Total execution time: 0.1220
INFO - 2024-02-27 00:11:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:11:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:11:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:11:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:11:18 --> Controller Class Initialized
INFO - 2024-02-27 00:11:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:11:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:11:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:11:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:11:18 --> Total execution time: 0.1678
INFO - 2024-02-27 00:12:43 --> Config Class Initialized
INFO - 2024-02-27 00:12:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:12:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:12:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:12:43 --> URI Class Initialized
INFO - 2024-02-27 00:12:43 --> Router Class Initialized
INFO - 2024-02-27 00:12:43 --> Output Class Initialized
INFO - 2024-02-27 00:12:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:12:43 --> Input Class Initialized
INFO - 2024-02-27 00:12:43 --> Language Class Initialized
INFO - 2024-02-27 00:12:43 --> Loader Class Initialized
INFO - 2024-02-27 00:12:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:12:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:12:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:12:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:12:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:12:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:12:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:12:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:12:43 --> Controller Class Initialized
INFO - 2024-02-27 00:12:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:12:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:12:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:12:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:12:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:12:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:12:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:12:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:12:43 --> Total execution time: 0.0806
INFO - 2024-02-27 00:12:44 --> Config Class Initialized
INFO - 2024-02-27 00:12:44 --> Config Class Initialized
INFO - 2024-02-27 00:12:44 --> Hooks Class Initialized
INFO - 2024-02-27 00:12:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:12:44 --> URI Class Initialized
INFO - 2024-02-27 00:12:44 --> URI Class Initialized
INFO - 2024-02-27 00:12:44 --> Router Class Initialized
INFO - 2024-02-27 00:12:44 --> Router Class Initialized
INFO - 2024-02-27 00:12:44 --> Output Class Initialized
INFO - 2024-02-27 00:12:44 --> Output Class Initialized
INFO - 2024-02-27 00:12:44 --> Security Class Initialized
INFO - 2024-02-27 00:12:44 --> Security Class Initialized
DEBUG - 2024-02-27 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:12:44 --> Input Class Initialized
INFO - 2024-02-27 00:12:44 --> Language Class Initialized
INFO - 2024-02-27 00:12:44 --> Loader Class Initialized
INFO - 2024-02-27 00:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:12:44 --> Config Class Initialized
INFO - 2024-02-27 00:12:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:12:44 --> Config Class Initialized
INFO - 2024-02-27 00:12:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:12:44 --> Hooks Class Initialized
INFO - 2024-02-27 00:12:44 --> URI Class Initialized
INFO - 2024-02-27 00:12:44 --> Email Class Initialized
DEBUG - 2024-02-27 00:12:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:12:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:12:44 --> Router Class Initialized
INFO - 2024-02-27 00:12:44 --> URI Class Initialized
INFO - 2024-02-27 00:12:44 --> Output Class Initialized
INFO - 2024-02-27 00:12:44 --> Router Class Initialized
DEBUG - 2024-02-27 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:12:44 --> Output Class Initialized
INFO - 2024-02-27 00:12:44 --> Security Class Initialized
INFO - 2024-02-27 00:12:44 --> Input Class Initialized
DEBUG - 2024-02-27 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:12:44 --> Security Class Initialized
INFO - 2024-02-27 00:12:44 --> Language Class Initialized
INFO - 2024-02-27 00:12:44 --> Input Class Initialized
INFO - 2024-02-27 00:12:44 --> Language Class Initialized
DEBUG - 2024-02-27 00:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:12:44 --> Input Class Initialized
INFO - 2024-02-27 00:12:44 --> Language Class Initialized
INFO - 2024-02-27 00:12:44 --> Loader Class Initialized
INFO - 2024-02-27 00:12:44 --> Loader Class Initialized
INFO - 2024-02-27 00:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:12:44 --> Loader Class Initialized
INFO - 2024-02-27 00:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:12:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:12:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:12:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:12:44 --> Controller Class Initialized
INFO - 2024-02-27 00:12:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:12:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:12:44 --> Email Class Initialized
INFO - 2024-02-27 00:12:44 --> Email Class Initialized
INFO - 2024-02-27 00:12:44 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:12:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:12:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:12:44 --> Email Class Initialized
INFO - 2024-02-27 00:12:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:12:44 --> Total execution time: 0.1155
DEBUG - 2024-02-27 00:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:12:44 --> Controller Class Initialized
INFO - 2024-02-27 00:12:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:12:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:12:44 --> Total execution time: 0.1436
INFO - 2024-02-27 00:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:12:44 --> Controller Class Initialized
INFO - 2024-02-27 00:12:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:12:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:12:44 --> Total execution time: 0.1306
INFO - 2024-02-27 00:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:12:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:12:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:12:44 --> Controller Class Initialized
INFO - 2024-02-27 00:12:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:12:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:12:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:12:44 --> Total execution time: 0.1866
INFO - 2024-02-27 00:13:42 --> Config Class Initialized
INFO - 2024-02-27 00:13:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:13:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:42 --> URI Class Initialized
INFO - 2024-02-27 00:13:42 --> Router Class Initialized
INFO - 2024-02-27 00:13:42 --> Output Class Initialized
INFO - 2024-02-27 00:13:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:42 --> Input Class Initialized
INFO - 2024-02-27 00:13:42 --> Language Class Initialized
INFO - 2024-02-27 00:13:42 --> Loader Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:42 --> Controller Class Initialized
INFO - 2024-02-27 00:13:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:13:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:13:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:13:42 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:13:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:13:42 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:42 --> Total execution time: 0.0756
INFO - 2024-02-27 00:13:42 --> Config Class Initialized
INFO - 2024-02-27 00:13:42 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:42 --> Config Class Initialized
INFO - 2024-02-27 00:13:42 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:42 --> Config Class Initialized
INFO - 2024-02-27 00:13:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:13:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:42 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:13:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:42 --> URI Class Initialized
INFO - 2024-02-27 00:13:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:42 --> URI Class Initialized
INFO - 2024-02-27 00:13:42 --> Config Class Initialized
INFO - 2024-02-27 00:13:42 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:42 --> URI Class Initialized
INFO - 2024-02-27 00:13:42 --> Router Class Initialized
INFO - 2024-02-27 00:13:42 --> Router Class Initialized
INFO - 2024-02-27 00:13:42 --> Router Class Initialized
INFO - 2024-02-27 00:13:42 --> Output Class Initialized
DEBUG - 2024-02-27 00:13:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:42 --> Output Class Initialized
INFO - 2024-02-27 00:13:42 --> Security Class Initialized
INFO - 2024-02-27 00:13:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:42 --> Security Class Initialized
INFO - 2024-02-27 00:13:42 --> Output Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:42 --> URI Class Initialized
INFO - 2024-02-27 00:13:42 --> Input Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:42 --> Input Class Initialized
INFO - 2024-02-27 00:13:42 --> Language Class Initialized
INFO - 2024-02-27 00:13:42 --> Router Class Initialized
INFO - 2024-02-27 00:13:42 --> Output Class Initialized
INFO - 2024-02-27 00:13:42 --> Language Class Initialized
INFO - 2024-02-27 00:13:42 --> Security Class Initialized
INFO - 2024-02-27 00:13:42 --> Security Class Initialized
INFO - 2024-02-27 00:13:42 --> Loader Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:42 --> Input Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:42 --> Language Class Initialized
INFO - 2024-02-27 00:13:42 --> Input Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:42 --> Language Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:42 --> Loader Class Initialized
INFO - 2024-02-27 00:13:42 --> Loader Class Initialized
INFO - 2024-02-27 00:13:42 --> Loader Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:42 --> Controller Class Initialized
INFO - 2024-02-27 00:13:42 --> Email Class Initialized
INFO - 2024-02-27 00:13:42 --> Email Class Initialized
INFO - 2024-02-27 00:13:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:42 --> Email Class Initialized
INFO - 2024-02-27 00:13:42 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:42 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-27 00:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:42 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:43 --> Total execution time: 0.0950
INFO - 2024-02-27 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:43 --> Controller Class Initialized
INFO - 2024-02-27 00:13:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:43 --> Total execution time: 0.1145
INFO - 2024-02-27 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:43 --> Controller Class Initialized
INFO - 2024-02-27 00:13:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:43 --> Total execution time: 0.1310
INFO - 2024-02-27 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:43 --> Controller Class Initialized
INFO - 2024-02-27 00:13:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:43 --> Total execution time: 0.1640
INFO - 2024-02-27 00:13:43 --> Config Class Initialized
INFO - 2024-02-27 00:13:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:13:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:43 --> URI Class Initialized
INFO - 2024-02-27 00:13:43 --> Router Class Initialized
INFO - 2024-02-27 00:13:43 --> Output Class Initialized
INFO - 2024-02-27 00:13:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:43 --> Input Class Initialized
INFO - 2024-02-27 00:13:43 --> Language Class Initialized
INFO - 2024-02-27 00:13:43 --> Loader Class Initialized
INFO - 2024-02-27 00:13:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:43 --> Controller Class Initialized
INFO - 2024-02-27 00:13:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:13:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:13:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:13:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:13:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:13:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:43 --> Total execution time: 0.0828
INFO - 2024-02-27 00:13:44 --> Config Class Initialized
INFO - 2024-02-27 00:13:44 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:44 --> Config Class Initialized
INFO - 2024-02-27 00:13:44 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:44 --> Config Class Initialized
INFO - 2024-02-27 00:13:44 --> Config Class Initialized
INFO - 2024-02-27 00:13:44 --> Hooks Class Initialized
INFO - 2024-02-27 00:13:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:13:44 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:13:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:44 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:13:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:44 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:13:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:13:44 --> Utf8 Class Initialized
INFO - 2024-02-27 00:13:44 --> URI Class Initialized
INFO - 2024-02-27 00:13:44 --> URI Class Initialized
INFO - 2024-02-27 00:13:44 --> URI Class Initialized
INFO - 2024-02-27 00:13:44 --> URI Class Initialized
INFO - 2024-02-27 00:13:44 --> Router Class Initialized
INFO - 2024-02-27 00:13:44 --> Router Class Initialized
INFO - 2024-02-27 00:13:44 --> Router Class Initialized
INFO - 2024-02-27 00:13:44 --> Router Class Initialized
INFO - 2024-02-27 00:13:44 --> Output Class Initialized
INFO - 2024-02-27 00:13:44 --> Output Class Initialized
INFO - 2024-02-27 00:13:44 --> Output Class Initialized
INFO - 2024-02-27 00:13:44 --> Security Class Initialized
INFO - 2024-02-27 00:13:44 --> Output Class Initialized
INFO - 2024-02-27 00:13:44 --> Security Class Initialized
INFO - 2024-02-27 00:13:44 --> Security Class Initialized
DEBUG - 2024-02-27 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:44 --> Input Class Initialized
INFO - 2024-02-27 00:13:44 --> Security Class Initialized
DEBUG - 2024-02-27 00:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:44 --> Input Class Initialized
INFO - 2024-02-27 00:13:44 --> Language Class Initialized
INFO - 2024-02-27 00:13:44 --> Input Class Initialized
INFO - 2024-02-27 00:13:44 --> Language Class Initialized
DEBUG - 2024-02-27 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:13:44 --> Language Class Initialized
INFO - 2024-02-27 00:13:44 --> Input Class Initialized
INFO - 2024-02-27 00:13:44 --> Language Class Initialized
INFO - 2024-02-27 00:13:44 --> Loader Class Initialized
INFO - 2024-02-27 00:13:44 --> Loader Class Initialized
INFO - 2024-02-27 00:13:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:44 --> Loader Class Initialized
INFO - 2024-02-27 00:13:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:44 --> Loader Class Initialized
INFO - 2024-02-27 00:13:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: url_helper
INFO - 2024-02-27 00:13:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: file_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: security_helper
INFO - 2024-02-27 00:13:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:13:44 --> Email Class Initialized
INFO - 2024-02-27 00:13:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:44 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:44 --> Email Class Initialized
INFO - 2024-02-27 00:13:44 --> Database Driver Class Initialized
INFO - 2024-02-27 00:13:44 --> Email Class Initialized
INFO - 2024-02-27 00:13:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:44 --> Controller Class Initialized
DEBUG - 2024-02-27 00:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:44 --> Email Class Initialized
INFO - 2024-02-27 00:13:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Faktur_model" initialized
DEBUG - 2024-02-27 00:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:13:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:44 --> Total execution time: 0.0864
INFO - 2024-02-27 00:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:44 --> Controller Class Initialized
INFO - 2024-02-27 00:13:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:44 --> Total execution time: 0.1106
INFO - 2024-02-27 00:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:44 --> Controller Class Initialized
INFO - 2024-02-27 00:13:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:44 --> Total execution time: 0.1381
INFO - 2024-02-27 00:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:13:44 --> Helper loaded: form_helper
INFO - 2024-02-27 00:13:44 --> Form Validation Class Initialized
INFO - 2024-02-27 00:13:44 --> Controller Class Initialized
INFO - 2024-02-27 00:13:44 --> Model "User_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:13:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:13:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:13:44 --> Final output sent to browser
DEBUG - 2024-02-27 00:13:44 --> Total execution time: 0.1566
INFO - 2024-02-27 00:14:46 --> Config Class Initialized
INFO - 2024-02-27 00:14:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:46 --> URI Class Initialized
INFO - 2024-02-27 00:14:46 --> Router Class Initialized
INFO - 2024-02-27 00:14:46 --> Output Class Initialized
INFO - 2024-02-27 00:14:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:46 --> Input Class Initialized
INFO - 2024-02-27 00:14:46 --> Language Class Initialized
INFO - 2024-02-27 00:14:46 --> Loader Class Initialized
INFO - 2024-02-27 00:14:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:46 --> Controller Class Initialized
INFO - 2024-02-27 00:14:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:14:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:14:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:14:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:14:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:14:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:46 --> Total execution time: 0.0905
INFO - 2024-02-27 00:14:47 --> Config Class Initialized
INFO - 2024-02-27 00:14:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:47 --> URI Class Initialized
INFO - 2024-02-27 00:14:47 --> Router Class Initialized
INFO - 2024-02-27 00:14:47 --> Output Class Initialized
INFO - 2024-02-27 00:14:47 --> Security Class Initialized
INFO - 2024-02-27 00:14:47 --> Config Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:47 --> Input Class Initialized
INFO - 2024-02-27 00:14:47 --> Hooks Class Initialized
INFO - 2024-02-27 00:14:47 --> Config Class Initialized
INFO - 2024-02-27 00:14:47 --> Language Class Initialized
INFO - 2024-02-27 00:14:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:47 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:47 --> URI Class Initialized
INFO - 2024-02-27 00:14:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:47 --> Loader Class Initialized
INFO - 2024-02-27 00:14:47 --> Router Class Initialized
INFO - 2024-02-27 00:14:47 --> URI Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:47 --> Output Class Initialized
INFO - 2024-02-27 00:14:47 --> Router Class Initialized
INFO - 2024-02-27 00:14:47 --> Security Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:47 --> Output Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:47 --> Input Class Initialized
INFO - 2024-02-27 00:14:47 --> Security Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:47 --> Language Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:47 --> Input Class Initialized
INFO - 2024-02-27 00:14:47 --> Language Class Initialized
INFO - 2024-02-27 00:14:47 --> Loader Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:47 --> Loader Class Initialized
INFO - 2024-02-27 00:14:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:47 --> Email Class Initialized
INFO - 2024-02-27 00:14:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:47 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:47 --> Email Class Initialized
INFO - 2024-02-27 00:14:47 --> Email Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:47 --> Controller Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:47 --> Config Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:47 --> URI Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Router Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:47 --> Final output sent to browser
INFO - 2024-02-27 00:14:47 --> Output Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Total execution time: 0.1085
INFO - 2024-02-27 00:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:47 --> Security Class Initialized
INFO - 2024-02-27 00:14:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:47 --> Controller Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:47 --> Input Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:47 --> Language Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:14:47 --> Loader Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:47 --> Final output sent to browser
INFO - 2024-02-27 00:14:47 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:14:47 --> Total execution time: 0.1184
INFO - 2024-02-27 00:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:47 --> Controller Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Jenis_model" initialized
INFO - 2024-02-27 00:14:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:47 --> Total execution time: 0.1374
DEBUG - 2024-02-27 00:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:47 --> Controller Class Initialized
INFO - 2024-02-27 00:14:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:47 --> Total execution time: 0.1311
INFO - 2024-02-27 00:14:49 --> Config Class Initialized
INFO - 2024-02-27 00:14:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:49 --> URI Class Initialized
INFO - 2024-02-27 00:14:49 --> Router Class Initialized
INFO - 2024-02-27 00:14:49 --> Output Class Initialized
INFO - 2024-02-27 00:14:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:49 --> Input Class Initialized
INFO - 2024-02-27 00:14:49 --> Language Class Initialized
INFO - 2024-02-27 00:14:49 --> Loader Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:49 --> Controller Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:14:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:14:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:14:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:14:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:14:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:49 --> Total execution time: 0.0629
INFO - 2024-02-27 00:14:49 --> Config Class Initialized
INFO - 2024-02-27 00:14:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:14:49 --> Config Class Initialized
INFO - 2024-02-27 00:14:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:14:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:49 --> Config Class Initialized
INFO - 2024-02-27 00:14:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:14:49 --> URI Class Initialized
INFO - 2024-02-27 00:14:49 --> Router Class Initialized
INFO - 2024-02-27 00:14:49 --> Output Class Initialized
DEBUG - 2024-02-27 00:14:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:14:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:49 --> URI Class Initialized
INFO - 2024-02-27 00:14:49 --> URI Class Initialized
INFO - 2024-02-27 00:14:49 --> Router Class Initialized
INFO - 2024-02-27 00:14:49 --> Security Class Initialized
INFO - 2024-02-27 00:14:49 --> Router Class Initialized
INFO - 2024-02-27 00:14:49 --> Config Class Initialized
INFO - 2024-02-27 00:14:49 --> Hooks Class Initialized
INFO - 2024-02-27 00:14:49 --> Output Class Initialized
INFO - 2024-02-27 00:14:49 --> Output Class Initialized
DEBUG - 2024-02-27 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:14:49 --> Security Class Initialized
INFO - 2024-02-27 00:14:49 --> Input Class Initialized
INFO - 2024-02-27 00:14:49 --> URI Class Initialized
INFO - 2024-02-27 00:14:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:49 --> Input Class Initialized
INFO - 2024-02-27 00:14:49 --> Router Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:49 --> Language Class Initialized
INFO - 2024-02-27 00:14:49 --> Input Class Initialized
INFO - 2024-02-27 00:14:49 --> Language Class Initialized
INFO - 2024-02-27 00:14:49 --> Output Class Initialized
INFO - 2024-02-27 00:14:49 --> Security Class Initialized
INFO - 2024-02-27 00:14:49 --> Loader Class Initialized
INFO - 2024-02-27 00:14:49 --> Loader Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:14:49 --> Language Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:49 --> Input Class Initialized
INFO - 2024-02-27 00:14:49 --> Language Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:49 --> Loader Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:49 --> Loader Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:14:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:14:49 --> Email Class Initialized
INFO - 2024-02-27 00:14:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:49 --> Controller Class Initialized
INFO - 2024-02-27 00:14:49 --> Email Class Initialized
INFO - 2024-02-27 00:14:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:49 --> Email Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:14:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:49 --> Total execution time: 0.1055
INFO - 2024-02-27 00:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:49 --> Controller Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:49 --> Total execution time: 0.1195
INFO - 2024-02-27 00:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:49 --> Controller Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:49 --> Total execution time: 0.1486
INFO - 2024-02-27 00:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:14:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:14:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:14:49 --> Controller Class Initialized
INFO - 2024-02-27 00:14:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:14:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:14:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:14:49 --> Total execution time: 0.1420
INFO - 2024-02-27 00:15:35 --> Config Class Initialized
INFO - 2024-02-27 00:15:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:15:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:35 --> URI Class Initialized
INFO - 2024-02-27 00:15:35 --> Router Class Initialized
INFO - 2024-02-27 00:15:35 --> Output Class Initialized
INFO - 2024-02-27 00:15:35 --> Security Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:35 --> Input Class Initialized
INFO - 2024-02-27 00:15:35 --> Language Class Initialized
INFO - 2024-02-27 00:15:35 --> Loader Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:35 --> Email Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:35 --> Controller Class Initialized
INFO - 2024-02-27 00:15:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:15:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:15:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:15:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:15:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:15:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:35 --> Total execution time: 0.0780
INFO - 2024-02-27 00:15:35 --> Config Class Initialized
INFO - 2024-02-27 00:15:35 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:35 --> Config Class Initialized
INFO - 2024-02-27 00:15:35 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:35 --> Config Class Initialized
INFO - 2024-02-27 00:15:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:15:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:35 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:15:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:35 --> URI Class Initialized
INFO - 2024-02-27 00:15:35 --> URI Class Initialized
INFO - 2024-02-27 00:15:35 --> URI Class Initialized
INFO - 2024-02-27 00:15:35 --> Router Class Initialized
INFO - 2024-02-27 00:15:35 --> Router Class Initialized
INFO - 2024-02-27 00:15:35 --> Router Class Initialized
INFO - 2024-02-27 00:15:35 --> Output Class Initialized
INFO - 2024-02-27 00:15:35 --> Config Class Initialized
INFO - 2024-02-27 00:15:35 --> Output Class Initialized
INFO - 2024-02-27 00:15:35 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:35 --> Security Class Initialized
INFO - 2024-02-27 00:15:35 --> Output Class Initialized
INFO - 2024-02-27 00:15:35 --> Security Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:35 --> Input Class Initialized
DEBUG - 2024-02-27 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:35 --> Security Class Initialized
INFO - 2024-02-27 00:15:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:35 --> Language Class Initialized
INFO - 2024-02-27 00:15:35 --> Input Class Initialized
INFO - 2024-02-27 00:15:35 --> URI Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:35 --> Language Class Initialized
INFO - 2024-02-27 00:15:35 --> Input Class Initialized
INFO - 2024-02-27 00:15:35 --> Router Class Initialized
INFO - 2024-02-27 00:15:35 --> Loader Class Initialized
INFO - 2024-02-27 00:15:35 --> Language Class Initialized
INFO - 2024-02-27 00:15:35 --> Loader Class Initialized
INFO - 2024-02-27 00:15:35 --> Output Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:35 --> Security Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:35 --> Input Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:35 --> Language Class Initialized
INFO - 2024-02-27 00:15:35 --> Loader Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:35 --> Loader Class Initialized
INFO - 2024-02-27 00:15:35 --> Email Class Initialized
INFO - 2024-02-27 00:15:35 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:35 --> Email Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:35 --> Controller Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:35 --> Total execution time: 0.1407
INFO - 2024-02-27 00:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:35 --> Controller Class Initialized
INFO - 2024-02-27 00:15:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:35 --> Total execution time: 0.1671
INFO - 2024-02-27 00:15:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:35 --> Email Class Initialized
DEBUG - 2024-02-27 00:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:35 --> Email Class Initialized
INFO - 2024-02-27 00:15:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:35 --> Controller Class Initialized
INFO - 2024-02-27 00:15:35 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:35 --> Total execution time: 0.2168
INFO - 2024-02-27 00:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:35 --> Controller Class Initialized
INFO - 2024-02-27 00:15:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:35 --> Total execution time: 0.2299
INFO - 2024-02-27 00:15:40 --> Config Class Initialized
INFO - 2024-02-27 00:15:40 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:15:40 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:40 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:40 --> URI Class Initialized
INFO - 2024-02-27 00:15:40 --> Router Class Initialized
INFO - 2024-02-27 00:15:40 --> Output Class Initialized
INFO - 2024-02-27 00:15:40 --> Security Class Initialized
DEBUG - 2024-02-27 00:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:40 --> Input Class Initialized
INFO - 2024-02-27 00:15:40 --> Language Class Initialized
INFO - 2024-02-27 00:15:40 --> Loader Class Initialized
INFO - 2024-02-27 00:15:40 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:40 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:40 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:40 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:40 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:40 --> Email Class Initialized
DEBUG - 2024-02-27 00:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:40 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:40 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:40 --> Controller Class Initialized
INFO - 2024-02-27 00:15:40 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:15:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:15:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:15:40 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:15:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:15:40 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:40 --> Total execution time: 0.0697
INFO - 2024-02-27 00:15:41 --> Config Class Initialized
INFO - 2024-02-27 00:15:41 --> Config Class Initialized
INFO - 2024-02-27 00:15:41 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:41 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:41 --> Config Class Initialized
INFO - 2024-02-27 00:15:41 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:41 --> Config Class Initialized
DEBUG - 2024-02-27 00:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:41 --> Hooks Class Initialized
INFO - 2024-02-27 00:15:41 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:41 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:41 --> URI Class Initialized
DEBUG - 2024-02-27 00:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:41 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:41 --> URI Class Initialized
DEBUG - 2024-02-27 00:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:15:41 --> URI Class Initialized
INFO - 2024-02-27 00:15:41 --> Utf8 Class Initialized
INFO - 2024-02-27 00:15:41 --> Router Class Initialized
INFO - 2024-02-27 00:15:41 --> Router Class Initialized
INFO - 2024-02-27 00:15:41 --> URI Class Initialized
INFO - 2024-02-27 00:15:41 --> Router Class Initialized
INFO - 2024-02-27 00:15:41 --> Output Class Initialized
INFO - 2024-02-27 00:15:41 --> Output Class Initialized
INFO - 2024-02-27 00:15:41 --> Router Class Initialized
INFO - 2024-02-27 00:15:41 --> Output Class Initialized
INFO - 2024-02-27 00:15:41 --> Security Class Initialized
INFO - 2024-02-27 00:15:41 --> Security Class Initialized
INFO - 2024-02-27 00:15:41 --> Output Class Initialized
INFO - 2024-02-27 00:15:41 --> Security Class Initialized
DEBUG - 2024-02-27 00:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:41 --> Input Class Initialized
INFO - 2024-02-27 00:15:41 --> Input Class Initialized
INFO - 2024-02-27 00:15:41 --> Security Class Initialized
DEBUG - 2024-02-27 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:41 --> Language Class Initialized
INFO - 2024-02-27 00:15:41 --> Language Class Initialized
INFO - 2024-02-27 00:15:41 --> Input Class Initialized
INFO - 2024-02-27 00:15:41 --> Language Class Initialized
DEBUG - 2024-02-27 00:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:15:41 --> Input Class Initialized
INFO - 2024-02-27 00:15:41 --> Language Class Initialized
INFO - 2024-02-27 00:15:41 --> Loader Class Initialized
INFO - 2024-02-27 00:15:41 --> Loader Class Initialized
INFO - 2024-02-27 00:15:41 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:41 --> Loader Class Initialized
INFO - 2024-02-27 00:15:41 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:41 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:41 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:41 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:41 --> Loader Class Initialized
INFO - 2024-02-27 00:15:41 --> Helper loaded: url_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: file_helper
INFO - 2024-02-27 00:15:41 --> Email Class Initialized
INFO - 2024-02-27 00:15:41 --> Email Class Initialized
INFO - 2024-02-27 00:15:41 --> Helper loaded: security_helper
INFO - 2024-02-27 00:15:41 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:15:41 --> Email Class Initialized
DEBUG - 2024-02-27 00:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:41 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:41 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:41 --> Controller Class Initialized
INFO - 2024-02-27 00:15:41 --> Database Driver Class Initialized
INFO - 2024-02-27 00:15:41 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:41 --> Email Class Initialized
INFO - 2024-02-27 00:15:41 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:15:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:41 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:41 --> Total execution time: 0.0972
INFO - 2024-02-27 00:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:41 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:41 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:41 --> Controller Class Initialized
INFO - 2024-02-27 00:15:41 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:41 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:41 --> Total execution time: 0.1198
INFO - 2024-02-27 00:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:41 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:41 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:41 --> Controller Class Initialized
INFO - 2024-02-27 00:15:41 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:41 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:41 --> Total execution time: 0.1416
INFO - 2024-02-27 00:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:15:41 --> Helper loaded: form_helper
INFO - 2024-02-27 00:15:41 --> Form Validation Class Initialized
INFO - 2024-02-27 00:15:41 --> Controller Class Initialized
INFO - 2024-02-27 00:15:41 --> Model "User_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:15:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:15:41 --> Final output sent to browser
DEBUG - 2024-02-27 00:15:41 --> Total execution time: 0.1604
INFO - 2024-02-27 00:18:15 --> Config Class Initialized
INFO - 2024-02-27 00:18:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:15 --> URI Class Initialized
INFO - 2024-02-27 00:18:15 --> Router Class Initialized
INFO - 2024-02-27 00:18:15 --> Output Class Initialized
INFO - 2024-02-27 00:18:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:15 --> Input Class Initialized
INFO - 2024-02-27 00:18:15 --> Language Class Initialized
INFO - 2024-02-27 00:18:15 --> Loader Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:15 --> Email Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:15 --> Controller Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:18:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:18:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:18:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_faktur.php
INFO - 2024-02-27 00:18:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:18:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:15 --> Total execution time: 0.0597
INFO - 2024-02-27 00:18:15 --> Config Class Initialized
INFO - 2024-02-27 00:18:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:15 --> URI Class Initialized
INFO - 2024-02-27 00:18:15 --> Router Class Initialized
INFO - 2024-02-27 00:18:15 --> Output Class Initialized
INFO - 2024-02-27 00:18:15 --> Config Class Initialized
INFO - 2024-02-27 00:18:15 --> Security Class Initialized
INFO - 2024-02-27 00:18:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:15 --> Input Class Initialized
INFO - 2024-02-27 00:18:15 --> Language Class Initialized
DEBUG - 2024-02-27 00:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:15 --> URI Class Initialized
INFO - 2024-02-27 00:18:15 --> Loader Class Initialized
INFO - 2024-02-27 00:18:15 --> Config Class Initialized
INFO - 2024-02-27 00:18:15 --> Router Class Initialized
INFO - 2024-02-27 00:18:15 --> Hooks Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:15 --> Output Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: wpu_helper
DEBUG - 2024-02-27 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:15 --> Input Class Initialized
INFO - 2024-02-27 00:18:15 --> URI Class Initialized
INFO - 2024-02-27 00:18:15 --> Language Class Initialized
INFO - 2024-02-27 00:18:15 --> Router Class Initialized
INFO - 2024-02-27 00:18:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:15 --> Loader Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:15 --> Email Class Initialized
INFO - 2024-02-27 00:18:15 --> Output Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:15 --> Security Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:15 --> Controller Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:15 --> Input Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:15 --> Language Class Initialized
INFO - 2024-02-27 00:18:15 --> Config Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:15 --> Hooks Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Supplier_model" initialized
DEBUG - 2024-02-27 00:18:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:15 --> URI Class Initialized
INFO - 2024-02-27 00:18:15 --> Loader Class Initialized
INFO - 2024-02-27 00:18:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:15 --> Total execution time: 0.0741
INFO - 2024-02-27 00:18:15 --> Email Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:15 --> Controller Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Router Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:15 --> Total execution time: 0.0853
INFO - 2024-02-27 00:18:15 --> Output Class Initialized
INFO - 2024-02-27 00:18:15 --> Email Class Initialized
INFO - 2024-02-27 00:18:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:15 --> Input Class Initialized
INFO - 2024-02-27 00:18:15 --> Language Class Initialized
INFO - 2024-02-27 00:18:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:15 --> Controller Class Initialized
INFO - 2024-02-27 00:18:15 --> Loader Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:15 --> Total execution time: 0.1458
INFO - 2024-02-27 00:18:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:15 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:15 --> Email Class Initialized
DEBUG - 2024-02-27 00:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:15 --> Controller Class Initialized
INFO - 2024-02-27 00:18:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:15 --> Total execution time: 0.1740
INFO - 2024-02-27 00:18:18 --> Config Class Initialized
INFO - 2024-02-27 00:18:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:18:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:18 --> URI Class Initialized
INFO - 2024-02-27 00:18:18 --> Router Class Initialized
INFO - 2024-02-27 00:18:18 --> Output Class Initialized
INFO - 2024-02-27 00:18:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:18 --> Input Class Initialized
INFO - 2024-02-27 00:18:18 --> Language Class Initialized
INFO - 2024-02-27 00:18:18 --> Loader Class Initialized
INFO - 2024-02-27 00:18:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:18 --> Controller Class Initialized
INFO - 2024-02-27 00:18:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:18:18 --> Config Class Initialized
INFO - 2024-02-27 00:18:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:18:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:18:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:18:18 --> URI Class Initialized
INFO - 2024-02-27 00:18:18 --> Router Class Initialized
INFO - 2024-02-27 00:18:18 --> Output Class Initialized
INFO - 2024-02-27 00:18:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:18:18 --> Input Class Initialized
INFO - 2024-02-27 00:18:18 --> Language Class Initialized
INFO - 2024-02-27 00:18:18 --> Loader Class Initialized
INFO - 2024-02-27 00:18:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:18:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:18:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:18:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:18:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:18:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:18:18 --> Controller Class Initialized
INFO - 2024-02-27 00:18:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:18:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:18:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:18:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:18:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:18:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:18:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:18:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:18:18 --> Total execution time: 0.0781
INFO - 2024-02-27 00:19:32 --> Config Class Initialized
INFO - 2024-02-27 00:19:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:32 --> URI Class Initialized
INFO - 2024-02-27 00:19:32 --> Router Class Initialized
INFO - 2024-02-27 00:19:32 --> Output Class Initialized
INFO - 2024-02-27 00:19:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:32 --> Input Class Initialized
INFO - 2024-02-27 00:19:32 --> Language Class Initialized
INFO - 2024-02-27 00:19:32 --> Loader Class Initialized
INFO - 2024-02-27 00:19:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:32 --> Controller Class Initialized
INFO - 2024-02-27 00:19:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:19:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:32 --> Total execution time: 0.0614
INFO - 2024-02-27 00:19:34 --> Config Class Initialized
INFO - 2024-02-27 00:19:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:34 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:34 --> URI Class Initialized
INFO - 2024-02-27 00:19:34 --> Router Class Initialized
INFO - 2024-02-27 00:19:34 --> Output Class Initialized
INFO - 2024-02-27 00:19:34 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:34 --> Input Class Initialized
INFO - 2024-02-27 00:19:34 --> Language Class Initialized
INFO - 2024-02-27 00:19:34 --> Loader Class Initialized
INFO - 2024-02-27 00:19:34 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:34 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:34 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:34 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:34 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:34 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:34 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:34 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:34 --> Controller Class Initialized
INFO - 2024-02-27 00:19:34 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:34 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:34 --> Total execution time: 0.0918
INFO - 2024-02-27 00:19:35 --> Config Class Initialized
INFO - 2024-02-27 00:19:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:35 --> URI Class Initialized
INFO - 2024-02-27 00:19:35 --> Router Class Initialized
INFO - 2024-02-27 00:19:35 --> Output Class Initialized
INFO - 2024-02-27 00:19:35 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:35 --> Input Class Initialized
INFO - 2024-02-27 00:19:35 --> Language Class Initialized
INFO - 2024-02-27 00:19:35 --> Loader Class Initialized
INFO - 2024-02-27 00:19:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:35 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:35 --> Controller Class Initialized
INFO - 2024-02-27 00:19:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:35 --> Total execution time: 0.0978
INFO - 2024-02-27 00:19:35 --> Config Class Initialized
INFO - 2024-02-27 00:19:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:35 --> URI Class Initialized
INFO - 2024-02-27 00:19:35 --> Router Class Initialized
INFO - 2024-02-27 00:19:35 --> Output Class Initialized
INFO - 2024-02-27 00:19:35 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:35 --> Input Class Initialized
INFO - 2024-02-27 00:19:35 --> Language Class Initialized
INFO - 2024-02-27 00:19:35 --> Loader Class Initialized
INFO - 2024-02-27 00:19:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:35 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:35 --> Controller Class Initialized
INFO - 2024-02-27 00:19:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-27 00:19:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:35 --> Total execution time: 0.0874
INFO - 2024-02-27 00:19:36 --> Config Class Initialized
INFO - 2024-02-27 00:19:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:36 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:36 --> URI Class Initialized
INFO - 2024-02-27 00:19:36 --> Router Class Initialized
INFO - 2024-02-27 00:19:36 --> Output Class Initialized
INFO - 2024-02-27 00:19:36 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:36 --> Input Class Initialized
INFO - 2024-02-27 00:19:36 --> Language Class Initialized
INFO - 2024-02-27 00:19:36 --> Loader Class Initialized
INFO - 2024-02-27 00:19:36 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:36 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:36 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:36 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:36 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:36 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:36 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:36 --> Controller Class Initialized
INFO - 2024-02-27 00:19:36 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:19:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:36 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:36 --> Total execution time: 0.0711
INFO - 2024-02-27 00:19:38 --> Config Class Initialized
INFO - 2024-02-27 00:19:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:38 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:38 --> URI Class Initialized
INFO - 2024-02-27 00:19:38 --> Router Class Initialized
INFO - 2024-02-27 00:19:38 --> Output Class Initialized
INFO - 2024-02-27 00:19:38 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:38 --> Input Class Initialized
INFO - 2024-02-27 00:19:38 --> Language Class Initialized
INFO - 2024-02-27 00:19:38 --> Loader Class Initialized
INFO - 2024-02-27 00:19:38 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:38 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:38 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:38 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:38 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:38 --> Controller Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:38 --> Config Class Initialized
INFO - 2024-02-27 00:19:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:38 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:38 --> URI Class Initialized
INFO - 2024-02-27 00:19:38 --> Router Class Initialized
INFO - 2024-02-27 00:19:38 --> Output Class Initialized
INFO - 2024-02-27 00:19:38 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:38 --> Input Class Initialized
INFO - 2024-02-27 00:19:38 --> Language Class Initialized
INFO - 2024-02-27 00:19:38 --> Loader Class Initialized
INFO - 2024-02-27 00:19:38 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:38 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:38 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:38 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:38 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:38 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:38 --> Controller Class Initialized
DEBUG - 2024-02-27 00:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:19:38 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:19:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:19:38 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:38 --> Total execution time: 0.0633
INFO - 2024-02-27 00:19:42 --> Config Class Initialized
INFO - 2024-02-27 00:19:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:42 --> URI Class Initialized
INFO - 2024-02-27 00:19:42 --> Router Class Initialized
INFO - 2024-02-27 00:19:42 --> Output Class Initialized
INFO - 2024-02-27 00:19:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:42 --> Input Class Initialized
INFO - 2024-02-27 00:19:42 --> Language Class Initialized
INFO - 2024-02-27 00:19:42 --> Loader Class Initialized
INFO - 2024-02-27 00:19:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:42 --> Controller Class Initialized
DEBUG - 2024-02-27 00:19:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:19:43 --> Config Class Initialized
INFO - 2024-02-27 00:19:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:43 --> URI Class Initialized
INFO - 2024-02-27 00:19:43 --> Router Class Initialized
INFO - 2024-02-27 00:19:43 --> Output Class Initialized
INFO - 2024-02-27 00:19:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:43 --> Input Class Initialized
INFO - 2024-02-27 00:19:43 --> Language Class Initialized
INFO - 2024-02-27 00:19:43 --> Loader Class Initialized
INFO - 2024-02-27 00:19:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:43 --> Controller Class Initialized
DEBUG - 2024-02-27 00:19:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:19:43 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:19:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:19:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:43 --> Total execution time: 0.0382
INFO - 2024-02-27 00:19:46 --> Config Class Initialized
INFO - 2024-02-27 00:19:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:46 --> URI Class Initialized
INFO - 2024-02-27 00:19:46 --> Router Class Initialized
INFO - 2024-02-27 00:19:46 --> Output Class Initialized
INFO - 2024-02-27 00:19:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:46 --> Input Class Initialized
INFO - 2024-02-27 00:19:46 --> Language Class Initialized
INFO - 2024-02-27 00:19:46 --> Loader Class Initialized
INFO - 2024-02-27 00:19:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:46 --> Controller Class Initialized
DEBUG - 2024-02-27 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:19:46 --> Config Class Initialized
INFO - 2024-02-27 00:19:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:46 --> URI Class Initialized
INFO - 2024-02-27 00:19:46 --> Router Class Initialized
INFO - 2024-02-27 00:19:46 --> Output Class Initialized
INFO - 2024-02-27 00:19:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:46 --> Input Class Initialized
INFO - 2024-02-27 00:19:46 --> Language Class Initialized
INFO - 2024-02-27 00:19:46 --> Loader Class Initialized
INFO - 2024-02-27 00:19:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:46 --> Controller Class Initialized
INFO - 2024-02-27 00:19:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:46 --> File loaded: C:\xampp\htdocs\simba\application\views\user/dashboard.php
INFO - 2024-02-27 00:19:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:46 --> Total execution time: 0.0536
INFO - 2024-02-27 00:19:47 --> Config Class Initialized
INFO - 2024-02-27 00:19:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:47 --> URI Class Initialized
INFO - 2024-02-27 00:19:47 --> Router Class Initialized
INFO - 2024-02-27 00:19:47 --> Output Class Initialized
INFO - 2024-02-27 00:19:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:47 --> Input Class Initialized
INFO - 2024-02-27 00:19:47 --> Language Class Initialized
INFO - 2024-02-27 00:19:47 --> Loader Class Initialized
INFO - 2024-02-27 00:19:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:47 --> Controller Class Initialized
INFO - 2024-02-27 00:19:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:48 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:48 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:19:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:48 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:48 --> Total execution time: 0.0646
INFO - 2024-02-27 00:19:51 --> Config Class Initialized
INFO - 2024-02-27 00:19:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:51 --> URI Class Initialized
INFO - 2024-02-27 00:19:51 --> Router Class Initialized
INFO - 2024-02-27 00:19:51 --> Output Class Initialized
INFO - 2024-02-27 00:19:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:51 --> Input Class Initialized
INFO - 2024-02-27 00:19:51 --> Language Class Initialized
INFO - 2024-02-27 00:19:51 --> Loader Class Initialized
INFO - 2024-02-27 00:19:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:51 --> Controller Class Initialized
INFO - 2024-02-27 00:19:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:51 --> File loaded: C:\xampp\htdocs\simba\application\views\user/e_faktur.php
INFO - 2024-02-27 00:19:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:51 --> Total execution time: 0.0508
INFO - 2024-02-27 00:19:52 --> Config Class Initialized
INFO - 2024-02-27 00:19:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:19:52 --> Config Class Initialized
DEBUG - 2024-02-27 00:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:19:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:52 --> Config Class Initialized
INFO - 2024-02-27 00:19:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:19:52 --> URI Class Initialized
INFO - 2024-02-27 00:19:52 --> Config Class Initialized
DEBUG - 2024-02-27 00:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:52 --> Hooks Class Initialized
INFO - 2024-02-27 00:19:52 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:52 --> Router Class Initialized
INFO - 2024-02-27 00:19:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:52 --> URI Class Initialized
DEBUG - 2024-02-27 00:19:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:52 --> URI Class Initialized
INFO - 2024-02-27 00:19:52 --> Output Class Initialized
INFO - 2024-02-27 00:19:52 --> Router Class Initialized
INFO - 2024-02-27 00:19:52 --> URI Class Initialized
INFO - 2024-02-27 00:19:52 --> Security Class Initialized
INFO - 2024-02-27 00:19:52 --> Router Class Initialized
INFO - 2024-02-27 00:19:52 --> Router Class Initialized
INFO - 2024-02-27 00:19:52 --> Output Class Initialized
INFO - 2024-02-27 00:19:52 --> Output Class Initialized
DEBUG - 2024-02-27 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:52 --> Input Class Initialized
INFO - 2024-02-27 00:19:52 --> Security Class Initialized
INFO - 2024-02-27 00:19:52 --> Security Class Initialized
INFO - 2024-02-27 00:19:52 --> Language Class Initialized
INFO - 2024-02-27 00:19:52 --> Output Class Initialized
DEBUG - 2024-02-27 00:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:52 --> Input Class Initialized
INFO - 2024-02-27 00:19:52 --> Security Class Initialized
INFO - 2024-02-27 00:19:52 --> Input Class Initialized
DEBUG - 2024-02-27 00:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:52 --> Loader Class Initialized
INFO - 2024-02-27 00:19:52 --> Language Class Initialized
INFO - 2024-02-27 00:19:52 --> Input Class Initialized
INFO - 2024-02-27 00:19:52 --> Language Class Initialized
INFO - 2024-02-27 00:19:52 --> Language Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:52 --> Loader Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:52 --> Loader Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:52 --> Loader Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:52 --> Email Class Initialized
INFO - 2024-02-27 00:19:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-27 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:52 --> Email Class Initialized
INFO - 2024-02-27 00:19:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:52 --> Helper loaded: form_helper
DEBUG - 2024-02-27 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:52 --> Controller Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Email Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:52 --> Total execution time: 0.1012
INFO - 2024-02-27 00:19:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:52 --> Controller Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:52 --> Total execution time: 0.1176
INFO - 2024-02-27 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:52 --> Controller Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:52 --> Total execution time: 0.1385
INFO - 2024-02-27 00:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:52 --> Controller Class Initialized
INFO - 2024-02-27 00:19:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:52 --> Total execution time: 0.1636
INFO - 2024-02-27 00:19:59 --> Config Class Initialized
INFO - 2024-02-27 00:19:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:59 --> URI Class Initialized
INFO - 2024-02-27 00:19:59 --> Router Class Initialized
INFO - 2024-02-27 00:19:59 --> Output Class Initialized
INFO - 2024-02-27 00:19:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:59 --> Input Class Initialized
INFO - 2024-02-27 00:19:59 --> Language Class Initialized
INFO - 2024-02-27 00:19:59 --> Loader Class Initialized
INFO - 2024-02-27 00:19:59 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:59 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:59 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:59 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:59 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:59 --> Controller Class Initialized
INFO - 2024-02-27 00:19:59 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:19:59 --> Config Class Initialized
INFO - 2024-02-27 00:19:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:19:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:19:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:19:59 --> URI Class Initialized
INFO - 2024-02-27 00:19:59 --> Router Class Initialized
INFO - 2024-02-27 00:19:59 --> Output Class Initialized
INFO - 2024-02-27 00:19:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:19:59 --> Input Class Initialized
INFO - 2024-02-27 00:19:59 --> Language Class Initialized
INFO - 2024-02-27 00:19:59 --> Loader Class Initialized
INFO - 2024-02-27 00:19:59 --> Helper loaded: url_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: file_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: security_helper
INFO - 2024-02-27 00:19:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:19:59 --> Database Driver Class Initialized
INFO - 2024-02-27 00:19:59 --> Email Class Initialized
DEBUG - 2024-02-27 00:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:19:59 --> Helper loaded: form_helper
INFO - 2024-02-27 00:19:59 --> Form Validation Class Initialized
INFO - 2024-02-27 00:19:59 --> Controller Class Initialized
INFO - 2024-02-27 00:19:59 --> Model "User_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:19:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:19:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:19:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:19:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:19:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:19:59 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:19:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:19:59 --> Final output sent to browser
DEBUG - 2024-02-27 00:19:59 --> Total execution time: 0.0672
INFO - 2024-02-27 00:20:02 --> Config Class Initialized
INFO - 2024-02-27 00:20:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:02 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:02 --> URI Class Initialized
INFO - 2024-02-27 00:20:02 --> Router Class Initialized
INFO - 2024-02-27 00:20:02 --> Output Class Initialized
INFO - 2024-02-27 00:20:02 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:02 --> Input Class Initialized
INFO - 2024-02-27 00:20:02 --> Language Class Initialized
INFO - 2024-02-27 00:20:02 --> Loader Class Initialized
INFO - 2024-02-27 00:20:02 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:02 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:02 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:02 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:02 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:02 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:02 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:02 --> Controller Class Initialized
INFO - 2024-02-27 00:20:02 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\user/t_faktur.php
INFO - 2024-02-27 00:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:02 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:02 --> Total execution time: 0.0801
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> Config Class Initialized
INFO - 2024-02-27 00:20:07 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:20:07 --> UTF-8 Support Enabled
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:07 --> URI Class Initialized
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Router Class Initialized
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:07 --> Output Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Security Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:07 --> Input Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Language Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Loader Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Database Driver Class Initialized
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.0611
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Email Class Initialized
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
DEBUG - 2024-02-27 00:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.0745
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.0976
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.0975
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.1088
INFO - 2024-02-27 00:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:07 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:07 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:07 --> Controller Class Initialized
INFO - 2024-02-27 00:20:07 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:07 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:07 --> Total execution time: 0.1240
INFO - 2024-02-27 00:20:12 --> Config Class Initialized
INFO - 2024-02-27 00:20:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:12 --> URI Class Initialized
INFO - 2024-02-27 00:20:12 --> Router Class Initialized
INFO - 2024-02-27 00:20:12 --> Output Class Initialized
INFO - 2024-02-27 00:20:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:12 --> Input Class Initialized
INFO - 2024-02-27 00:20:12 --> Language Class Initialized
INFO - 2024-02-27 00:20:12 --> Loader Class Initialized
INFO - 2024-02-27 00:20:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:12 --> Controller Class Initialized
INFO - 2024-02-27 00:20:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:20:12 --> Helper loaded: inflector_helper
INFO - 2024-02-27 00:20:12 --> Upload Class Initialized
INFO - 2024-02-27 00:20:12 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-02-27 00:20:12 --> You did not select a file to upload.
INFO - 2024-02-27 00:20:12 --> Config Class Initialized
INFO - 2024-02-27 00:20:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:12 --> URI Class Initialized
INFO - 2024-02-27 00:20:12 --> Router Class Initialized
INFO - 2024-02-27 00:20:12 --> Output Class Initialized
INFO - 2024-02-27 00:20:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:12 --> Input Class Initialized
INFO - 2024-02-27 00:20:12 --> Language Class Initialized
INFO - 2024-02-27 00:20:12 --> Loader Class Initialized
INFO - 2024-02-27 00:20:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:12 --> Controller Class Initialized
INFO - 2024-02-27 00:20:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:12 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:20:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:12 --> Total execution time: 0.0527
INFO - 2024-02-27 00:20:15 --> Config Class Initialized
INFO - 2024-02-27 00:20:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:15 --> URI Class Initialized
INFO - 2024-02-27 00:20:15 --> Router Class Initialized
INFO - 2024-02-27 00:20:15 --> Output Class Initialized
INFO - 2024-02-27 00:20:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:15 --> Input Class Initialized
INFO - 2024-02-27 00:20:15 --> Language Class Initialized
INFO - 2024-02-27 00:20:15 --> Loader Class Initialized
INFO - 2024-02-27 00:20:15 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:15 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:15 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:15 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:15 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:15 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:15 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:15 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:15 --> Controller Class Initialized
INFO - 2024-02-27 00:20:15 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:15 --> File loaded: C:\xampp\htdocs\simba\application\views\user/e_faktur.php
INFO - 2024-02-27 00:20:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:15 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:15 --> Total execution time: 0.0759
INFO - 2024-02-27 00:20:16 --> Config Class Initialized
INFO - 2024-02-27 00:20:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:16 --> URI Class Initialized
INFO - 2024-02-27 00:20:16 --> Router Class Initialized
INFO - 2024-02-27 00:20:16 --> Output Class Initialized
INFO - 2024-02-27 00:20:16 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:16 --> Input Class Initialized
INFO - 2024-02-27 00:20:16 --> Language Class Initialized
INFO - 2024-02-27 00:20:16 --> Loader Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:16 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:16 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:16 --> Controller Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:16 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:16 --> Total execution time: 0.0869
INFO - 2024-02-27 00:20:16 --> Config Class Initialized
INFO - 2024-02-27 00:20:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:16 --> URI Class Initialized
INFO - 2024-02-27 00:20:16 --> Router Class Initialized
INFO - 2024-02-27 00:20:16 --> Config Class Initialized
INFO - 2024-02-27 00:20:16 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:16 --> Output Class Initialized
INFO - 2024-02-27 00:20:16 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:16 --> Input Class Initialized
DEBUG - 2024-02-27 00:20:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:16 --> Language Class Initialized
INFO - 2024-02-27 00:20:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:16 --> URI Class Initialized
INFO - 2024-02-27 00:20:16 --> Router Class Initialized
INFO - 2024-02-27 00:20:16 --> Loader Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:16 --> Output Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:16 --> Config Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:16 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:16 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:16 --> URI Class Initialized
INFO - 2024-02-27 00:20:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:16 --> Router Class Initialized
INFO - 2024-02-27 00:20:16 --> Output Class Initialized
INFO - 2024-02-27 00:20:16 --> Security Class Initialized
INFO - 2024-02-27 00:20:16 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:16 --> Input Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:16 --> Language Class Initialized
INFO - 2024-02-27 00:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-27 00:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:16 --> Loader Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:16 --> Controller Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:16 --> Input Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:16 --> Language Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:16 --> Final output sent to browser
INFO - 2024-02-27 00:20:16 --> Loader Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Total execution time: 0.0678
INFO - 2024-02-27 00:20:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:16 --> Email Class Initialized
INFO - 2024-02-27 00:20:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:16 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:16 --> Controller Class Initialized
INFO - 2024-02-27 00:20:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:16 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:16 --> Total execution time: 0.0684
INFO - 2024-02-27 00:20:16 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:16 --> Controller Class Initialized
INFO - 2024-02-27 00:20:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:16 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:16 --> Total execution time: 0.1231
INFO - 2024-02-27 00:20:18 --> Config Class Initialized
INFO - 2024-02-27 00:20:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:18 --> URI Class Initialized
INFO - 2024-02-27 00:20:18 --> Router Class Initialized
INFO - 2024-02-27 00:20:18 --> Output Class Initialized
INFO - 2024-02-27 00:20:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:18 --> Input Class Initialized
INFO - 2024-02-27 00:20:18 --> Language Class Initialized
INFO - 2024-02-27 00:20:18 --> Loader Class Initialized
INFO - 2024-02-27 00:20:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:18 --> Controller Class Initialized
INFO - 2024-02-27 00:20:18 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:18 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:20:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:18 --> Total execution time: 0.0652
INFO - 2024-02-27 00:20:21 --> Config Class Initialized
INFO - 2024-02-27 00:20:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:21 --> URI Class Initialized
INFO - 2024-02-27 00:20:21 --> Router Class Initialized
INFO - 2024-02-27 00:20:21 --> Output Class Initialized
INFO - 2024-02-27 00:20:21 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:21 --> Input Class Initialized
INFO - 2024-02-27 00:20:21 --> Language Class Initialized
INFO - 2024-02-27 00:20:21 --> Loader Class Initialized
INFO - 2024-02-27 00:20:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:21 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:21 --> Controller Class Initialized
INFO - 2024-02-27 00:20:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\user/e_faktur.php
INFO - 2024-02-27 00:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:21 --> Total execution time: 0.0568
INFO - 2024-02-27 00:20:22 --> Config Class Initialized
INFO - 2024-02-27 00:20:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:22 --> URI Class Initialized
INFO - 2024-02-27 00:20:22 --> Router Class Initialized
INFO - 2024-02-27 00:20:22 --> Config Class Initialized
INFO - 2024-02-27 00:20:22 --> Config Class Initialized
INFO - 2024-02-27 00:20:22 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:22 --> URI Class Initialized
INFO - 2024-02-27 00:20:22 --> Output Class Initialized
INFO - 2024-02-27 00:20:22 --> Router Class Initialized
INFO - 2024-02-27 00:20:22 --> Config Class Initialized
INFO - 2024-02-27 00:20:22 --> Output Class Initialized
INFO - 2024-02-27 00:20:22 --> Hooks Class Initialized
INFO - 2024-02-27 00:20:22 --> Security Class Initialized
INFO - 2024-02-27 00:20:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:22 --> Utf8 Class Initialized
DEBUG - 2024-02-27 00:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:22 --> Input Class Initialized
INFO - 2024-02-27 00:20:22 --> URI Class Initialized
DEBUG - 2024-02-27 00:20:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:22 --> Language Class Initialized
DEBUG - 2024-02-27 00:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:22 --> Input Class Initialized
INFO - 2024-02-27 00:20:22 --> Router Class Initialized
INFO - 2024-02-27 00:20:22 --> URI Class Initialized
INFO - 2024-02-27 00:20:22 --> Output Class Initialized
INFO - 2024-02-27 00:20:22 --> Language Class Initialized
INFO - 2024-02-27 00:20:22 --> Loader Class Initialized
INFO - 2024-02-27 00:20:22 --> Security Class Initialized
INFO - 2024-02-27 00:20:22 --> Router Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: file_helper
DEBUG - 2024-02-27 00:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:22 --> Output Class Initialized
INFO - 2024-02-27 00:20:22 --> Loader Class Initialized
INFO - 2024-02-27 00:20:22 --> Input Class Initialized
INFO - 2024-02-27 00:20:22 --> Language Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:22 --> Security Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:22 --> Loader Class Initialized
DEBUG - 2024-02-27 00:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:22 --> Input Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:22 --> Language Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:22 --> Loader Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:22 --> Email Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:22 --> Helper loaded: security_helper
DEBUG - 2024-02-27 00:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:22 --> Email Class Initialized
INFO - 2024-02-27 00:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:22 --> Controller Class Initialized
DEBUG - 2024-02-27 00:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:22 --> Email Class Initialized
INFO - 2024-02-27 00:20:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:22 --> Total execution time: 0.1143
DEBUG - 2024-02-27 00:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:22 --> Controller Class Initialized
INFO - 2024-02-27 00:20:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:22 --> Total execution time: 0.1348
INFO - 2024-02-27 00:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:22 --> Controller Class Initialized
INFO - 2024-02-27 00:20:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:22 --> Total execution time: 0.1408
INFO - 2024-02-27 00:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:22 --> Controller Class Initialized
INFO - 2024-02-27 00:20:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:22 --> Total execution time: 0.1480
INFO - 2024-02-27 00:20:27 --> Config Class Initialized
INFO - 2024-02-27 00:20:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:27 --> URI Class Initialized
INFO - 2024-02-27 00:20:27 --> Router Class Initialized
INFO - 2024-02-27 00:20:27 --> Output Class Initialized
INFO - 2024-02-27 00:20:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:27 --> Input Class Initialized
INFO - 2024-02-27 00:20:27 --> Language Class Initialized
INFO - 2024-02-27 00:20:27 --> Loader Class Initialized
INFO - 2024-02-27 00:20:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:27 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:27 --> Controller Class Initialized
INFO - 2024-02-27 00:20:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:20:27 --> Config Class Initialized
INFO - 2024-02-27 00:20:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:20:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:20:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:20:27 --> URI Class Initialized
INFO - 2024-02-27 00:20:27 --> Router Class Initialized
INFO - 2024-02-27 00:20:27 --> Output Class Initialized
INFO - 2024-02-27 00:20:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:20:27 --> Input Class Initialized
INFO - 2024-02-27 00:20:27 --> Language Class Initialized
INFO - 2024-02-27 00:20:27 --> Loader Class Initialized
INFO - 2024-02-27 00:20:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:20:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:20:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:20:28 --> Email Class Initialized
DEBUG - 2024-02-27 00:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:20:28 --> Helper loaded: form_helper
INFO - 2024-02-27 00:20:28 --> Form Validation Class Initialized
INFO - 2024-02-27 00:20:28 --> Controller Class Initialized
INFO - 2024-02-27 00:20:28 --> Model "User_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:20:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:20:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:20:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:20:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:20:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:20:28 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:20:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:20:28 --> Final output sent to browser
DEBUG - 2024-02-27 00:20:28 --> Total execution time: 0.0738
INFO - 2024-02-27 00:21:04 --> Config Class Initialized
INFO - 2024-02-27 00:21:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:04 --> URI Class Initialized
INFO - 2024-02-27 00:21:04 --> Router Class Initialized
INFO - 2024-02-27 00:21:04 --> Output Class Initialized
INFO - 2024-02-27 00:21:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:04 --> Input Class Initialized
INFO - 2024-02-27 00:21:04 --> Language Class Initialized
INFO - 2024-02-27 00:21:04 --> Loader Class Initialized
INFO - 2024-02-27 00:21:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:04 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:04 --> Controller Class Initialized
INFO - 2024-02-27 00:21:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:04 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:21:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:04 --> Total execution time: 0.0676
INFO - 2024-02-27 00:21:35 --> Config Class Initialized
INFO - 2024-02-27 00:21:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:35 --> URI Class Initialized
INFO - 2024-02-27 00:21:35 --> Router Class Initialized
INFO - 2024-02-27 00:21:36 --> Output Class Initialized
INFO - 2024-02-27 00:21:36 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:36 --> Input Class Initialized
INFO - 2024-02-27 00:21:36 --> Language Class Initialized
INFO - 2024-02-27 00:21:36 --> Loader Class Initialized
INFO - 2024-02-27 00:21:36 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:36 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:36 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:36 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:36 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:36 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:36 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:36 --> Controller Class Initialized
INFO - 2024-02-27 00:21:36 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\user/faktur.php
INFO - 2024-02-27 00:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:36 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:36 --> Total execution time: 0.0635
INFO - 2024-02-27 00:21:38 --> Config Class Initialized
INFO - 2024-02-27 00:21:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:38 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:38 --> URI Class Initialized
INFO - 2024-02-27 00:21:38 --> Router Class Initialized
INFO - 2024-02-27 00:21:38 --> Output Class Initialized
INFO - 2024-02-27 00:21:38 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:38 --> Input Class Initialized
INFO - 2024-02-27 00:21:38 --> Language Class Initialized
INFO - 2024-02-27 00:21:38 --> Loader Class Initialized
INFO - 2024-02-27 00:21:38 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:38 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:38 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:38 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:38 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:38 --> Controller Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:38 --> Config Class Initialized
INFO - 2024-02-27 00:21:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:38 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:38 --> URI Class Initialized
INFO - 2024-02-27 00:21:38 --> Router Class Initialized
INFO - 2024-02-27 00:21:38 --> Output Class Initialized
INFO - 2024-02-27 00:21:38 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:38 --> Input Class Initialized
INFO - 2024-02-27 00:21:38 --> Language Class Initialized
INFO - 2024-02-27 00:21:38 --> Loader Class Initialized
INFO - 2024-02-27 00:21:38 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:38 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:38 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:38 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:38 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:38 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:38 --> Controller Class Initialized
DEBUG - 2024-02-27 00:21:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:21:38 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:21:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:21:38 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:38 --> Total execution time: 0.0942
INFO - 2024-02-27 00:21:42 --> Config Class Initialized
INFO - 2024-02-27 00:21:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:42 --> URI Class Initialized
INFO - 2024-02-27 00:21:42 --> Router Class Initialized
INFO - 2024-02-27 00:21:42 --> Output Class Initialized
INFO - 2024-02-27 00:21:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:42 --> Input Class Initialized
INFO - 2024-02-27 00:21:42 --> Language Class Initialized
INFO - 2024-02-27 00:21:42 --> Loader Class Initialized
INFO - 2024-02-27 00:21:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:42 --> Controller Class Initialized
DEBUG - 2024-02-27 00:21:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:21:42 --> Config Class Initialized
INFO - 2024-02-27 00:21:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:42 --> URI Class Initialized
INFO - 2024-02-27 00:21:42 --> Router Class Initialized
INFO - 2024-02-27 00:21:42 --> Output Class Initialized
INFO - 2024-02-27 00:21:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:42 --> Input Class Initialized
INFO - 2024-02-27 00:21:42 --> Language Class Initialized
INFO - 2024-02-27 00:21:42 --> Loader Class Initialized
INFO - 2024-02-27 00:21:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:42 --> Controller Class Initialized
INFO - 2024-02-27 00:21:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:42 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:21:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:42 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:42 --> Total execution time: 0.0618
INFO - 2024-02-27 00:21:43 --> Config Class Initialized
INFO - 2024-02-27 00:21:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:43 --> URI Class Initialized
INFO - 2024-02-27 00:21:43 --> Router Class Initialized
INFO - 2024-02-27 00:21:43 --> Output Class Initialized
INFO - 2024-02-27 00:21:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:43 --> Input Class Initialized
INFO - 2024-02-27 00:21:43 --> Language Class Initialized
INFO - 2024-02-27 00:21:43 --> Loader Class Initialized
INFO - 2024-02-27 00:21:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:43 --> Controller Class Initialized
INFO - 2024-02-27 00:21:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/user.php
INFO - 2024-02-27 00:21:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:43 --> Total execution time: 0.0919
INFO - 2024-02-27 00:21:45 --> Config Class Initialized
INFO - 2024-02-27 00:21:45 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:45 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:45 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:45 --> URI Class Initialized
INFO - 2024-02-27 00:21:45 --> Router Class Initialized
INFO - 2024-02-27 00:21:45 --> Output Class Initialized
INFO - 2024-02-27 00:21:45 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:45 --> Input Class Initialized
INFO - 2024-02-27 00:21:45 --> Language Class Initialized
INFO - 2024-02-27 00:21:45 --> Loader Class Initialized
INFO - 2024-02-27 00:21:45 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:45 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:45 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:45 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:45 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:45 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:45 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:45 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:45 --> Controller Class Initialized
INFO - 2024-02-27 00:21:45 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:45 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-02-27 00:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:45 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:45 --> Total execution time: 0.0783
INFO - 2024-02-27 00:21:47 --> Config Class Initialized
INFO - 2024-02-27 00:21:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:47 --> URI Class Initialized
INFO - 2024-02-27 00:21:47 --> Router Class Initialized
INFO - 2024-02-27 00:21:47 --> Output Class Initialized
INFO - 2024-02-27 00:21:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:47 --> Input Class Initialized
INFO - 2024-02-27 00:21:47 --> Language Class Initialized
INFO - 2024-02-27 00:21:47 --> Loader Class Initialized
INFO - 2024-02-27 00:21:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:47 --> Controller Class Initialized
INFO - 2024-02-27 00:21:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:21:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:47 --> Total execution time: 0.0969
INFO - 2024-02-27 00:21:49 --> Config Class Initialized
INFO - 2024-02-27 00:21:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:49 --> URI Class Initialized
INFO - 2024-02-27 00:21:49 --> Router Class Initialized
INFO - 2024-02-27 00:21:49 --> Output Class Initialized
INFO - 2024-02-27 00:21:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:49 --> Input Class Initialized
INFO - 2024-02-27 00:21:49 --> Language Class Initialized
INFO - 2024-02-27 00:21:49 --> Loader Class Initialized
INFO - 2024-02-27 00:21:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:49 --> Controller Class Initialized
INFO - 2024-02-27 00:21:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:49 --> Total execution time: 0.0545
INFO - 2024-02-27 00:21:49 --> Config Class Initialized
INFO - 2024-02-27 00:21:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:49 --> URI Class Initialized
INFO - 2024-02-27 00:21:49 --> Router Class Initialized
INFO - 2024-02-27 00:21:49 --> Output Class Initialized
INFO - 2024-02-27 00:21:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:49 --> Input Class Initialized
INFO - 2024-02-27 00:21:49 --> Language Class Initialized
INFO - 2024-02-27 00:21:49 --> Loader Class Initialized
INFO - 2024-02-27 00:21:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:49 --> Controller Class Initialized
INFO - 2024-02-27 00:21:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:21:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:49 --> Total execution time: 0.0508
INFO - 2024-02-27 00:21:51 --> Config Class Initialized
INFO - 2024-02-27 00:21:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:51 --> URI Class Initialized
INFO - 2024-02-27 00:21:51 --> Router Class Initialized
INFO - 2024-02-27 00:21:51 --> Output Class Initialized
INFO - 2024-02-27 00:21:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:51 --> Input Class Initialized
INFO - 2024-02-27 00:21:51 --> Language Class Initialized
INFO - 2024-02-27 00:21:51 --> Loader Class Initialized
INFO - 2024-02-27 00:21:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:51 --> Controller Class Initialized
INFO - 2024-02-27 00:21:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/user.php
INFO - 2024-02-27 00:21:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:51 --> Total execution time: 0.0651
INFO - 2024-02-27 00:21:52 --> Config Class Initialized
INFO - 2024-02-27 00:21:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:52 --> URI Class Initialized
INFO - 2024-02-27 00:21:52 --> Router Class Initialized
INFO - 2024-02-27 00:21:52 --> Output Class Initialized
INFO - 2024-02-27 00:21:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:52 --> Input Class Initialized
INFO - 2024-02-27 00:21:52 --> Language Class Initialized
INFO - 2024-02-27 00:21:52 --> Loader Class Initialized
INFO - 2024-02-27 00:21:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:52 --> Controller Class Initialized
INFO - 2024-02-27 00:21:53 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-02-27 00:21:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:53 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:53 --> Total execution time: 0.0648
INFO - 2024-02-27 00:21:54 --> Config Class Initialized
INFO - 2024-02-27 00:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:21:54 --> Utf8 Class Initialized
INFO - 2024-02-27 00:21:54 --> URI Class Initialized
INFO - 2024-02-27 00:21:54 --> Router Class Initialized
INFO - 2024-02-27 00:21:54 --> Output Class Initialized
INFO - 2024-02-27 00:21:54 --> Security Class Initialized
DEBUG - 2024-02-27 00:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:21:54 --> Input Class Initialized
INFO - 2024-02-27 00:21:54 --> Language Class Initialized
INFO - 2024-02-27 00:21:54 --> Loader Class Initialized
INFO - 2024-02-27 00:21:54 --> Helper loaded: url_helper
INFO - 2024-02-27 00:21:54 --> Helper loaded: file_helper
INFO - 2024-02-27 00:21:54 --> Helper loaded: security_helper
INFO - 2024-02-27 00:21:54 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:21:54 --> Database Driver Class Initialized
INFO - 2024-02-27 00:21:54 --> Email Class Initialized
DEBUG - 2024-02-27 00:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:21:54 --> Helper loaded: form_helper
INFO - 2024-02-27 00:21:54 --> Form Validation Class Initialized
INFO - 2024-02-27 00:21:54 --> Controller Class Initialized
INFO - 2024-02-27 00:21:54 --> Model "User_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:21:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:21:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:21:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:21:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:21:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:21:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:21:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:21:54 --> Final output sent to browser
DEBUG - 2024-02-27 00:21:54 --> Total execution time: 0.0707
INFO - 2024-02-27 00:22:06 --> Config Class Initialized
INFO - 2024-02-27 00:22:06 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:06 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:06 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:06 --> URI Class Initialized
INFO - 2024-02-27 00:22:06 --> Router Class Initialized
INFO - 2024-02-27 00:22:06 --> Output Class Initialized
INFO - 2024-02-27 00:22:06 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:06 --> Input Class Initialized
INFO - 2024-02-27 00:22:06 --> Language Class Initialized
INFO - 2024-02-27 00:22:06 --> Loader Class Initialized
INFO - 2024-02-27 00:22:06 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:06 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:06 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:06 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:06 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:06 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:06 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:06 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:06 --> Controller Class Initialized
INFO - 2024-02-27 00:22:06 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/user.php
INFO - 2024-02-27 00:22:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:06 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:06 --> Total execution time: 0.0658
INFO - 2024-02-27 00:22:07 --> Config Class Initialized
INFO - 2024-02-27 00:22:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:07 --> URI Class Initialized
INFO - 2024-02-27 00:22:07 --> Router Class Initialized
INFO - 2024-02-27 00:22:07 --> Output Class Initialized
INFO - 2024-02-27 00:22:07 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:07 --> Input Class Initialized
INFO - 2024-02-27 00:22:07 --> Language Class Initialized
INFO - 2024-02-27 00:22:08 --> Loader Class Initialized
INFO - 2024-02-27 00:22:08 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:08 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:08 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:08 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:08 --> Controller Class Initialized
INFO - 2024-02-27 00:22:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:08 --> Total execution time: 0.0801
INFO - 2024-02-27 00:22:09 --> Config Class Initialized
INFO - 2024-02-27 00:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:09 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:09 --> URI Class Initialized
INFO - 2024-02-27 00:22:09 --> Router Class Initialized
INFO - 2024-02-27 00:22:09 --> Output Class Initialized
INFO - 2024-02-27 00:22:09 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:09 --> Input Class Initialized
INFO - 2024-02-27 00:22:09 --> Language Class Initialized
INFO - 2024-02-27 00:22:09 --> Loader Class Initialized
INFO - 2024-02-27 00:22:09 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:09 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:09 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:09 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:09 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:09 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:09 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:09 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:09 --> Controller Class Initialized
INFO - 2024-02-27 00:22:09 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/user.php
INFO - 2024-02-27 00:22:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:09 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:09 --> Total execution time: 0.0635
INFO - 2024-02-27 00:22:10 --> Config Class Initialized
INFO - 2024-02-27 00:22:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:10 --> URI Class Initialized
INFO - 2024-02-27 00:22:10 --> Router Class Initialized
INFO - 2024-02-27 00:22:10 --> Output Class Initialized
INFO - 2024-02-27 00:22:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:10 --> Input Class Initialized
INFO - 2024-02-27 00:22:10 --> Language Class Initialized
INFO - 2024-02-27 00:22:10 --> Loader Class Initialized
INFO - 2024-02-27 00:22:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:10 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:10 --> Config Class Initialized
INFO - 2024-02-27 00:22:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:10 --> URI Class Initialized
INFO - 2024-02-27 00:22:10 --> Router Class Initialized
INFO - 2024-02-27 00:22:10 --> Output Class Initialized
INFO - 2024-02-27 00:22:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:10 --> Input Class Initialized
INFO - 2024-02-27 00:22:10 --> Language Class Initialized
INFO - 2024-02-27 00:22:10 --> Loader Class Initialized
INFO - 2024-02-27 00:22:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:10 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:22:10 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:22:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:22:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:10 --> Total execution time: 0.0556
INFO - 2024-02-27 00:22:18 --> Config Class Initialized
INFO - 2024-02-27 00:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:18 --> URI Class Initialized
INFO - 2024-02-27 00:22:18 --> Router Class Initialized
INFO - 2024-02-27 00:22:18 --> Output Class Initialized
INFO - 2024-02-27 00:22:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:18 --> Input Class Initialized
INFO - 2024-02-27 00:22:18 --> Language Class Initialized
INFO - 2024-02-27 00:22:18 --> Loader Class Initialized
INFO - 2024-02-27 00:22:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:18 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:22:18 --> Config Class Initialized
INFO - 2024-02-27 00:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:18 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:18 --> URI Class Initialized
INFO - 2024-02-27 00:22:18 --> Router Class Initialized
INFO - 2024-02-27 00:22:18 --> Output Class Initialized
INFO - 2024-02-27 00:22:18 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:18 --> Input Class Initialized
INFO - 2024-02-27 00:22:18 --> Language Class Initialized
INFO - 2024-02-27 00:22:18 --> Loader Class Initialized
INFO - 2024-02-27 00:22:18 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:18 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:18 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:18 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:18 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:18 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:18 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:22:18 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:22:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:22:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:18 --> Total execution time: 0.0607
INFO - 2024-02-27 00:22:22 --> Config Class Initialized
INFO - 2024-02-27 00:22:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:22 --> URI Class Initialized
INFO - 2024-02-27 00:22:22 --> Router Class Initialized
INFO - 2024-02-27 00:22:22 --> Output Class Initialized
INFO - 2024-02-27 00:22:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:22 --> Input Class Initialized
INFO - 2024-02-27 00:22:22 --> Language Class Initialized
INFO - 2024-02-27 00:22:22 --> Loader Class Initialized
INFO - 2024-02-27 00:22:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:22 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:22:22 --> Config Class Initialized
INFO - 2024-02-27 00:22:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:22 --> URI Class Initialized
INFO - 2024-02-27 00:22:22 --> Router Class Initialized
INFO - 2024-02-27 00:22:22 --> Output Class Initialized
INFO - 2024-02-27 00:22:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:22 --> Input Class Initialized
INFO - 2024-02-27 00:22:22 --> Language Class Initialized
INFO - 2024-02-27 00:22:22 --> Loader Class Initialized
INFO - 2024-02-27 00:22:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:22 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:22:22 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:22:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:22:22 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:22 --> Total execution time: 0.0466
INFO - 2024-02-27 00:22:26 --> Config Class Initialized
INFO - 2024-02-27 00:22:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:26 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:26 --> URI Class Initialized
INFO - 2024-02-27 00:22:26 --> Router Class Initialized
INFO - 2024-02-27 00:22:26 --> Output Class Initialized
INFO - 2024-02-27 00:22:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:27 --> Input Class Initialized
INFO - 2024-02-27 00:22:27 --> Language Class Initialized
INFO - 2024-02-27 00:22:27 --> Loader Class Initialized
INFO - 2024-02-27 00:22:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:27 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:27 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:22:27 --> Config Class Initialized
INFO - 2024-02-27 00:22:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:27 --> URI Class Initialized
INFO - 2024-02-27 00:22:27 --> Router Class Initialized
INFO - 2024-02-27 00:22:27 --> Output Class Initialized
INFO - 2024-02-27 00:22:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:27 --> Input Class Initialized
INFO - 2024-02-27 00:22:27 --> Language Class Initialized
INFO - 2024-02-27 00:22:27 --> Loader Class Initialized
INFO - 2024-02-27 00:22:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:27 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:27 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:22:27 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:22:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:22:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:27 --> Total execution time: 0.0635
INFO - 2024-02-27 00:22:31 --> Config Class Initialized
INFO - 2024-02-27 00:22:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:31 --> URI Class Initialized
INFO - 2024-02-27 00:22:31 --> Router Class Initialized
INFO - 2024-02-27 00:22:31 --> Output Class Initialized
INFO - 2024-02-27 00:22:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:31 --> Input Class Initialized
INFO - 2024-02-27 00:22:31 --> Language Class Initialized
INFO - 2024-02-27 00:22:31 --> Loader Class Initialized
INFO - 2024-02-27 00:22:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:31 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:22:31 --> Config Class Initialized
INFO - 2024-02-27 00:22:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:31 --> URI Class Initialized
INFO - 2024-02-27 00:22:31 --> Router Class Initialized
INFO - 2024-02-27 00:22:31 --> Output Class Initialized
INFO - 2024-02-27 00:22:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:31 --> Input Class Initialized
INFO - 2024-02-27 00:22:31 --> Language Class Initialized
INFO - 2024-02-27 00:22:31 --> Loader Class Initialized
INFO - 2024-02-27 00:22:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:31 --> Controller Class Initialized
INFO - 2024-02-27 00:22:31 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-27 00:22:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:31 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:31 --> Total execution time: 0.1102
INFO - 2024-02-27 00:22:33 --> Config Class Initialized
INFO - 2024-02-27 00:22:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:33 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:33 --> URI Class Initialized
INFO - 2024-02-27 00:22:33 --> Router Class Initialized
INFO - 2024-02-27 00:22:33 --> Output Class Initialized
INFO - 2024-02-27 00:22:33 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:33 --> Input Class Initialized
INFO - 2024-02-27 00:22:33 --> Language Class Initialized
INFO - 2024-02-27 00:22:33 --> Loader Class Initialized
INFO - 2024-02-27 00:22:33 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:33 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:33 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:33 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:33 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:33 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:33 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:33 --> Controller Class Initialized
INFO - 2024-02-27 00:22:33 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:33 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:22:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:33 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:33 --> Total execution time: 0.0610
INFO - 2024-02-27 00:22:42 --> Config Class Initialized
INFO - 2024-02-27 00:22:42 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:42 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:42 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:42 --> URI Class Initialized
INFO - 2024-02-27 00:22:42 --> Router Class Initialized
INFO - 2024-02-27 00:22:42 --> Output Class Initialized
INFO - 2024-02-27 00:22:42 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:42 --> Input Class Initialized
INFO - 2024-02-27 00:22:42 --> Language Class Initialized
INFO - 2024-02-27 00:22:42 --> Loader Class Initialized
INFO - 2024-02-27 00:22:42 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:42 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:42 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:42 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:42 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:42 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:42 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:42 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:42 --> Controller Class Initialized
INFO - 2024-02-27 00:22:42 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:42 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-02-27 00:22:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:42 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:42 --> Total execution time: 0.0716
INFO - 2024-02-27 00:22:43 --> Config Class Initialized
INFO - 2024-02-27 00:22:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:43 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:43 --> URI Class Initialized
INFO - 2024-02-27 00:22:43 --> Router Class Initialized
INFO - 2024-02-27 00:22:43 --> Output Class Initialized
INFO - 2024-02-27 00:22:43 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:43 --> Input Class Initialized
INFO - 2024-02-27 00:22:43 --> Language Class Initialized
INFO - 2024-02-27 00:22:43 --> Loader Class Initialized
INFO - 2024-02-27 00:22:43 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:43 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:43 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:43 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:43 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:43 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:43 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:43 --> Controller Class Initialized
INFO - 2024-02-27 00:22:43 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:22:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:43 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:43 --> Total execution time: 0.0667
INFO - 2024-02-27 00:22:46 --> Config Class Initialized
INFO - 2024-02-27 00:22:46 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:46 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:46 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:46 --> URI Class Initialized
INFO - 2024-02-27 00:22:46 --> Router Class Initialized
INFO - 2024-02-27 00:22:46 --> Output Class Initialized
INFO - 2024-02-27 00:22:46 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:46 --> Input Class Initialized
INFO - 2024-02-27 00:22:46 --> Language Class Initialized
INFO - 2024-02-27 00:22:46 --> Loader Class Initialized
INFO - 2024-02-27 00:22:46 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:46 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:46 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:46 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:46 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:46 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:46 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:46 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:46 --> Controller Class Initialized
INFO - 2024-02-27 00:22:46 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/detailfaktur.php
INFO - 2024-02-27 00:22:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:46 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:46 --> Total execution time: 0.0662
INFO - 2024-02-27 00:22:47 --> Config Class Initialized
INFO - 2024-02-27 00:22:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:47 --> URI Class Initialized
INFO - 2024-02-27 00:22:47 --> Router Class Initialized
INFO - 2024-02-27 00:22:47 --> Output Class Initialized
INFO - 2024-02-27 00:22:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:47 --> Input Class Initialized
INFO - 2024-02-27 00:22:47 --> Language Class Initialized
INFO - 2024-02-27 00:22:47 --> Loader Class Initialized
INFO - 2024-02-27 00:22:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:47 --> Controller Class Initialized
INFO - 2024-02-27 00:22:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:22:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:22:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:22:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:22:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:22:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:22:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:22:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:47 --> Total execution time: 0.0642
INFO - 2024-02-27 00:22:58 --> Config Class Initialized
INFO - 2024-02-27 00:22:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:58 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:58 --> URI Class Initialized
INFO - 2024-02-27 00:22:58 --> Router Class Initialized
INFO - 2024-02-27 00:22:58 --> Output Class Initialized
INFO - 2024-02-27 00:22:58 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:58 --> Input Class Initialized
INFO - 2024-02-27 00:22:58 --> Language Class Initialized
INFO - 2024-02-27 00:22:58 --> Loader Class Initialized
INFO - 2024-02-27 00:22:58 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:58 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:58 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:58 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:58 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:58 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:58 --> Config Class Initialized
INFO - 2024-02-27 00:22:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:22:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:22:58 --> Utf8 Class Initialized
INFO - 2024-02-27 00:22:58 --> URI Class Initialized
INFO - 2024-02-27 00:22:58 --> Router Class Initialized
INFO - 2024-02-27 00:22:58 --> Output Class Initialized
INFO - 2024-02-27 00:22:58 --> Security Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:22:58 --> Input Class Initialized
INFO - 2024-02-27 00:22:58 --> Language Class Initialized
INFO - 2024-02-27 00:22:58 --> Loader Class Initialized
INFO - 2024-02-27 00:22:58 --> Helper loaded: url_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: file_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: security_helper
INFO - 2024-02-27 00:22:58 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:22:58 --> Database Driver Class Initialized
INFO - 2024-02-27 00:22:58 --> Email Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:22:58 --> Helper loaded: form_helper
INFO - 2024-02-27 00:22:58 --> Form Validation Class Initialized
INFO - 2024-02-27 00:22:58 --> Controller Class Initialized
DEBUG - 2024-02-27 00:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:22:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:22:58 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:22:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:22:58 --> Final output sent to browser
DEBUG - 2024-02-27 00:22:58 --> Total execution time: 0.0527
INFO - 2024-02-27 00:23:02 --> Config Class Initialized
INFO - 2024-02-27 00:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:23:02 --> Utf8 Class Initialized
INFO - 2024-02-27 00:23:02 --> URI Class Initialized
INFO - 2024-02-27 00:23:02 --> Router Class Initialized
INFO - 2024-02-27 00:23:02 --> Output Class Initialized
INFO - 2024-02-27 00:23:02 --> Security Class Initialized
DEBUG - 2024-02-27 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:23:02 --> Input Class Initialized
INFO - 2024-02-27 00:23:02 --> Language Class Initialized
INFO - 2024-02-27 00:23:02 --> Loader Class Initialized
INFO - 2024-02-27 00:23:02 --> Helper loaded: url_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: file_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: security_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:23:02 --> Database Driver Class Initialized
INFO - 2024-02-27 00:23:02 --> Email Class Initialized
DEBUG - 2024-02-27 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:23:02 --> Helper loaded: form_helper
INFO - 2024-02-27 00:23:02 --> Form Validation Class Initialized
INFO - 2024-02-27 00:23:02 --> Controller Class Initialized
DEBUG - 2024-02-27 00:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:23:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:23:02 --> Config Class Initialized
INFO - 2024-02-27 00:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:23:02 --> Utf8 Class Initialized
INFO - 2024-02-27 00:23:02 --> URI Class Initialized
INFO - 2024-02-27 00:23:02 --> Router Class Initialized
INFO - 2024-02-27 00:23:02 --> Output Class Initialized
INFO - 2024-02-27 00:23:02 --> Security Class Initialized
DEBUG - 2024-02-27 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:23:02 --> Input Class Initialized
INFO - 2024-02-27 00:23:02 --> Language Class Initialized
INFO - 2024-02-27 00:23:02 --> Loader Class Initialized
INFO - 2024-02-27 00:23:02 --> Helper loaded: url_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: file_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: security_helper
INFO - 2024-02-27 00:23:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:23:02 --> Database Driver Class Initialized
INFO - 2024-02-27 00:23:02 --> Email Class Initialized
DEBUG - 2024-02-27 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:23:02 --> Helper loaded: form_helper
INFO - 2024-02-27 00:23:02 --> Form Validation Class Initialized
INFO - 2024-02-27 00:23:02 --> Controller Class Initialized
INFO - 2024-02-27 00:23:02 --> Model "User_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:23:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\user/dashboard.php
INFO - 2024-02-27 00:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:23:02 --> Final output sent to browser
DEBUG - 2024-02-27 00:23:02 --> Total execution time: 0.0519
INFO - 2024-02-27 00:23:03 --> Config Class Initialized
INFO - 2024-02-27 00:23:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:23:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:23:03 --> Utf8 Class Initialized
INFO - 2024-02-27 00:23:03 --> URI Class Initialized
INFO - 2024-02-27 00:23:03 --> Router Class Initialized
INFO - 2024-02-27 00:23:03 --> Output Class Initialized
INFO - 2024-02-27 00:23:03 --> Security Class Initialized
DEBUG - 2024-02-27 00:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:23:03 --> Input Class Initialized
INFO - 2024-02-27 00:23:03 --> Language Class Initialized
INFO - 2024-02-27 00:23:03 --> Loader Class Initialized
INFO - 2024-02-27 00:23:03 --> Helper loaded: url_helper
INFO - 2024-02-27 00:23:03 --> Helper loaded: file_helper
INFO - 2024-02-27 00:23:03 --> Helper loaded: security_helper
INFO - 2024-02-27 00:23:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:23:03 --> Database Driver Class Initialized
INFO - 2024-02-27 00:23:03 --> Email Class Initialized
DEBUG - 2024-02-27 00:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:23:03 --> Helper loaded: form_helper
INFO - 2024-02-27 00:23:03 --> Form Validation Class Initialized
INFO - 2024-02-27 00:23:03 --> Controller Class Initialized
INFO - 2024-02-27 00:23:03 --> Model "User_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:23:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:23:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:23:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:23:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:23:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:23:03 --> File loaded: C:\xampp\htdocs\simba\application\views\user/dashboard.php
INFO - 2024-02-27 00:23:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:23:03 --> Final output sent to browser
DEBUG - 2024-02-27 00:23:03 --> Total execution time: 0.0654
INFO - 2024-02-27 00:24:23 --> Config Class Initialized
INFO - 2024-02-27 00:24:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:23 --> URI Class Initialized
INFO - 2024-02-27 00:24:23 --> Router Class Initialized
INFO - 2024-02-27 00:24:23 --> Output Class Initialized
INFO - 2024-02-27 00:24:23 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:23 --> Input Class Initialized
INFO - 2024-02-27 00:24:23 --> Language Class Initialized
INFO - 2024-02-27 00:24:23 --> Loader Class Initialized
INFO - 2024-02-27 00:24:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:23 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:23 --> Controller Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:23 --> Config Class Initialized
INFO - 2024-02-27 00:24:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:23 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:23 --> URI Class Initialized
INFO - 2024-02-27 00:24:23 --> Router Class Initialized
INFO - 2024-02-27 00:24:23 --> Output Class Initialized
INFO - 2024-02-27 00:24:23 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:23 --> Input Class Initialized
INFO - 2024-02-27 00:24:23 --> Language Class Initialized
INFO - 2024-02-27 00:24:23 --> Loader Class Initialized
INFO - 2024-02-27 00:24:23 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:23 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:23 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:23 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:23 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:23 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:23 --> Controller Class Initialized
DEBUG - 2024-02-27 00:24:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-27 00:24:23 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-27 00:24:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-27 00:24:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:23 --> Total execution time: 0.0450
INFO - 2024-02-27 00:24:28 --> Config Class Initialized
INFO - 2024-02-27 00:24:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:28 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:28 --> URI Class Initialized
INFO - 2024-02-27 00:24:28 --> Router Class Initialized
INFO - 2024-02-27 00:24:28 --> Output Class Initialized
INFO - 2024-02-27 00:24:28 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:28 --> Input Class Initialized
INFO - 2024-02-27 00:24:28 --> Language Class Initialized
INFO - 2024-02-27 00:24:28 --> Loader Class Initialized
INFO - 2024-02-27 00:24:28 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:28 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:28 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:28 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:28 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:28 --> Controller Class Initialized
DEBUG - 2024-02-27 00:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:24:28 --> Config Class Initialized
INFO - 2024-02-27 00:24:28 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:28 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:28 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:28 --> URI Class Initialized
INFO - 2024-02-27 00:24:28 --> Router Class Initialized
INFO - 2024-02-27 00:24:28 --> Output Class Initialized
INFO - 2024-02-27 00:24:28 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:28 --> Input Class Initialized
INFO - 2024-02-27 00:24:28 --> Language Class Initialized
INFO - 2024-02-27 00:24:28 --> Loader Class Initialized
INFO - 2024-02-27 00:24:28 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:28 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:28 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:28 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:28 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:28 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:28 --> Controller Class Initialized
INFO - 2024-02-27 00:24:28 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:24:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:28 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:28 --> Total execution time: 0.0799
INFO - 2024-02-27 00:24:30 --> Config Class Initialized
INFO - 2024-02-27 00:24:30 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:30 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:30 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:30 --> URI Class Initialized
INFO - 2024-02-27 00:24:30 --> Router Class Initialized
INFO - 2024-02-27 00:24:30 --> Output Class Initialized
INFO - 2024-02-27 00:24:30 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:30 --> Input Class Initialized
INFO - 2024-02-27 00:24:30 --> Language Class Initialized
INFO - 2024-02-27 00:24:30 --> Loader Class Initialized
INFO - 2024-02-27 00:24:30 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:30 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:30 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:30 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:30 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:30 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:30 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:30 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:30 --> Controller Class Initialized
INFO - 2024-02-27 00:24:30 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:24:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:30 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:30 --> Total execution time: 0.0667
INFO - 2024-02-27 00:24:31 --> Config Class Initialized
INFO - 2024-02-27 00:24:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:31 --> URI Class Initialized
INFO - 2024-02-27 00:24:31 --> Router Class Initialized
INFO - 2024-02-27 00:24:31 --> Output Class Initialized
INFO - 2024-02-27 00:24:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:31 --> Input Class Initialized
INFO - 2024-02-27 00:24:31 --> Language Class Initialized
INFO - 2024-02-27 00:24:31 --> Loader Class Initialized
INFO - 2024-02-27 00:24:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:31 --> Controller Class Initialized
INFO - 2024-02-27 00:24:31 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-02-27 00:24:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:31 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:31 --> Total execution time: 0.0619
INFO - 2024-02-27 00:24:37 --> Config Class Initialized
INFO - 2024-02-27 00:24:37 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:37 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:37 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:37 --> URI Class Initialized
INFO - 2024-02-27 00:24:37 --> Router Class Initialized
INFO - 2024-02-27 00:24:37 --> Output Class Initialized
INFO - 2024-02-27 00:24:37 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:37 --> Input Class Initialized
INFO - 2024-02-27 00:24:37 --> Language Class Initialized
INFO - 2024-02-27 00:24:37 --> Loader Class Initialized
INFO - 2024-02-27 00:24:37 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:37 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:37 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:37 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:37 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:37 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:37 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:37 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:37 --> Controller Class Initialized
INFO - 2024-02-27 00:24:37 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-02-27 00:24:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:37 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:37 --> Total execution time: 0.0549
INFO - 2024-02-27 00:24:38 --> Config Class Initialized
INFO - 2024-02-27 00:24:38 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:38 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:38 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:38 --> URI Class Initialized
INFO - 2024-02-27 00:24:38 --> Router Class Initialized
INFO - 2024-02-27 00:24:38 --> Output Class Initialized
INFO - 2024-02-27 00:24:38 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:38 --> Input Class Initialized
INFO - 2024-02-27 00:24:38 --> Language Class Initialized
INFO - 2024-02-27 00:24:38 --> Loader Class Initialized
INFO - 2024-02-27 00:24:38 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:38 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:38 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:38 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:38 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:38 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:38 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:38 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:38 --> Controller Class Initialized
INFO - 2024-02-27 00:24:39 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:39 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:24:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:39 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:39 --> Total execution time: 0.0759
INFO - 2024-02-27 00:24:47 --> Config Class Initialized
INFO - 2024-02-27 00:24:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:47 --> URI Class Initialized
INFO - 2024-02-27 00:24:47 --> Router Class Initialized
INFO - 2024-02-27 00:24:47 --> Output Class Initialized
INFO - 2024-02-27 00:24:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:47 --> Input Class Initialized
INFO - 2024-02-27 00:24:47 --> Language Class Initialized
INFO - 2024-02-27 00:24:47 --> Loader Class Initialized
INFO - 2024-02-27 00:24:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:47 --> Controller Class Initialized
INFO - 2024-02-27 00:24:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-02-27 00:24:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:47 --> Total execution time: 0.0731
INFO - 2024-02-27 00:24:49 --> Config Class Initialized
INFO - 2024-02-27 00:24:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:49 --> URI Class Initialized
INFO - 2024-02-27 00:24:49 --> Router Class Initialized
INFO - 2024-02-27 00:24:49 --> Output Class Initialized
INFO - 2024-02-27 00:24:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:49 --> Input Class Initialized
INFO - 2024-02-27 00:24:49 --> Language Class Initialized
INFO - 2024-02-27 00:24:49 --> Loader Class Initialized
INFO - 2024-02-27 00:24:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:49 --> Controller Class Initialized
INFO - 2024-02-27 00:24:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:24:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:49 --> Total execution time: 0.0658
INFO - 2024-02-27 00:24:51 --> Config Class Initialized
INFO - 2024-02-27 00:24:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:51 --> URI Class Initialized
INFO - 2024-02-27 00:24:51 --> Router Class Initialized
INFO - 2024-02-27 00:24:51 --> Output Class Initialized
INFO - 2024-02-27 00:24:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:51 --> Input Class Initialized
INFO - 2024-02-27 00:24:51 --> Language Class Initialized
INFO - 2024-02-27 00:24:51 --> Loader Class Initialized
INFO - 2024-02-27 00:24:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:51 --> Controller Class Initialized
INFO - 2024-02-27 00:24:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:51 --> Total execution time: 0.0655
INFO - 2024-02-27 00:24:51 --> Config Class Initialized
INFO - 2024-02-27 00:24:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:51 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:51 --> URI Class Initialized
INFO - 2024-02-27 00:24:51 --> Router Class Initialized
INFO - 2024-02-27 00:24:51 --> Output Class Initialized
INFO - 2024-02-27 00:24:51 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:51 --> Input Class Initialized
INFO - 2024-02-27 00:24:51 --> Language Class Initialized
INFO - 2024-02-27 00:24:51 --> Loader Class Initialized
INFO - 2024-02-27 00:24:51 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:51 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:51 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:51 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:51 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:51 --> Controller Class Initialized
INFO - 2024-02-27 00:24:51 --> Model "User_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:24:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:24:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:24:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role-access.php
INFO - 2024-02-27 00:24:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:51 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:51 --> Total execution time: 0.1398
INFO - 2024-02-27 00:24:52 --> Config Class Initialized
INFO - 2024-02-27 00:24:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:52 --> URI Class Initialized
INFO - 2024-02-27 00:24:52 --> Router Class Initialized
INFO - 2024-02-27 00:24:52 --> Output Class Initialized
INFO - 2024-02-27 00:24:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:52 --> Input Class Initialized
INFO - 2024-02-27 00:24:52 --> Language Class Initialized
INFO - 2024-02-27 00:24:52 --> Loader Class Initialized
INFO - 2024-02-27 00:24:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:52 --> Controller Class Initialized
INFO - 2024-02-27 00:24:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:52 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/index.php
INFO - 2024-02-27 00:24:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:52 --> Total execution time: 0.0766
INFO - 2024-02-27 00:24:59 --> Config Class Initialized
INFO - 2024-02-27 00:24:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:59 --> URI Class Initialized
INFO - 2024-02-27 00:24:59 --> Router Class Initialized
INFO - 2024-02-27 00:24:59 --> Output Class Initialized
INFO - 2024-02-27 00:24:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:59 --> Input Class Initialized
INFO - 2024-02-27 00:24:59 --> Language Class Initialized
INFO - 2024-02-27 00:24:59 --> Loader Class Initialized
INFO - 2024-02-27 00:24:59 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:59 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:59 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:59 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:59 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:59 --> Controller Class Initialized
INFO - 2024-02-27 00:24:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:24:59 --> Config Class Initialized
INFO - 2024-02-27 00:24:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:24:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:24:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:24:59 --> URI Class Initialized
INFO - 2024-02-27 00:24:59 --> Router Class Initialized
INFO - 2024-02-27 00:24:59 --> Output Class Initialized
INFO - 2024-02-27 00:24:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:24:59 --> Input Class Initialized
INFO - 2024-02-27 00:24:59 --> Language Class Initialized
INFO - 2024-02-27 00:24:59 --> Loader Class Initialized
INFO - 2024-02-27 00:24:59 --> Helper loaded: url_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: file_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: security_helper
INFO - 2024-02-27 00:24:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:24:59 --> Database Driver Class Initialized
INFO - 2024-02-27 00:24:59 --> Email Class Initialized
DEBUG - 2024-02-27 00:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:24:59 --> Helper loaded: form_helper
INFO - 2024-02-27 00:24:59 --> Form Validation Class Initialized
INFO - 2024-02-27 00:24:59 --> Controller Class Initialized
INFO - 2024-02-27 00:24:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:24:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:24:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:24:59 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/index.php
INFO - 2024-02-27 00:24:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:24:59 --> Final output sent to browser
DEBUG - 2024-02-27 00:24:59 --> Total execution time: 0.0467
INFO - 2024-02-27 00:25:12 --> Config Class Initialized
INFO - 2024-02-27 00:25:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:25:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:25:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:25:12 --> URI Class Initialized
INFO - 2024-02-27 00:25:12 --> Router Class Initialized
INFO - 2024-02-27 00:25:12 --> Output Class Initialized
INFO - 2024-02-27 00:25:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:25:12 --> Input Class Initialized
INFO - 2024-02-27 00:25:12 --> Language Class Initialized
INFO - 2024-02-27 00:25:12 --> Loader Class Initialized
INFO - 2024-02-27 00:25:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:25:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:25:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:25:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:25:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:25:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:25:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:25:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:25:12 --> Controller Class Initialized
INFO - 2024-02-27 00:25:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:25:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:25:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:25:12 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/index.php
INFO - 2024-02-27 00:25:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:25:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:25:12 --> Total execution time: 0.1224
INFO - 2024-02-27 00:25:14 --> Config Class Initialized
INFO - 2024-02-27 00:25:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:25:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:25:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:25:14 --> URI Class Initialized
INFO - 2024-02-27 00:25:14 --> Router Class Initialized
INFO - 2024-02-27 00:25:14 --> Output Class Initialized
INFO - 2024-02-27 00:25:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:25:14 --> Input Class Initialized
INFO - 2024-02-27 00:25:14 --> Language Class Initialized
INFO - 2024-02-27 00:25:14 --> Loader Class Initialized
INFO - 2024-02-27 00:25:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:25:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:25:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:25:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:25:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:25:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:25:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:25:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:25:14 --> Controller Class Initialized
INFO - 2024-02-27 00:25:14 --> Model "Menu_model" initialized
INFO - 2024-02-27 00:25:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:25:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:25:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:25:14 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-02-27 00:25:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:25:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:25:14 --> Total execution time: 0.1047
INFO - 2024-02-27 00:26:29 --> Config Class Initialized
INFO - 2024-02-27 00:26:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:29 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:29 --> URI Class Initialized
INFO - 2024-02-27 00:26:29 --> Router Class Initialized
INFO - 2024-02-27 00:26:29 --> Output Class Initialized
INFO - 2024-02-27 00:26:29 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:29 --> Input Class Initialized
INFO - 2024-02-27 00:26:29 --> Language Class Initialized
INFO - 2024-02-27 00:26:29 --> Loader Class Initialized
INFO - 2024-02-27 00:26:29 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:26:29 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:29 --> Email Class Initialized
DEBUG - 2024-02-27 00:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:29 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:29 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:29 --> Controller Class Initialized
INFO - 2024-02-27 00:26:29 --> Model "Menu_model" initialized
INFO - 2024-02-27 00:26:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:26:29 --> Config Class Initialized
INFO - 2024-02-27 00:26:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:29 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:29 --> URI Class Initialized
INFO - 2024-02-27 00:26:29 --> Router Class Initialized
INFO - 2024-02-27 00:26:29 --> Output Class Initialized
INFO - 2024-02-27 00:26:29 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:29 --> Input Class Initialized
INFO - 2024-02-27 00:26:29 --> Language Class Initialized
INFO - 2024-02-27 00:26:29 --> Loader Class Initialized
INFO - 2024-02-27 00:26:29 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:29 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:26:29 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:29 --> Email Class Initialized
DEBUG - 2024-02-27 00:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:29 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:29 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:29 --> Controller Class Initialized
INFO - 2024-02-27 00:26:29 --> Model "Menu_model" initialized
INFO - 2024-02-27 00:26:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:26:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:26:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:26:29 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-02-27 00:26:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:26:29 --> Final output sent to browser
DEBUG - 2024-02-27 00:26:29 --> Total execution time: 0.0585
INFO - 2024-02-27 00:26:31 --> Config Class Initialized
INFO - 2024-02-27 00:26:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:31 --> URI Class Initialized
INFO - 2024-02-27 00:26:31 --> Router Class Initialized
INFO - 2024-02-27 00:26:31 --> Output Class Initialized
INFO - 2024-02-27 00:26:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:31 --> Input Class Initialized
INFO - 2024-02-27 00:26:31 --> Language Class Initialized
ERROR - 2024-02-27 00:26:31 --> 404 Page Not Found: Direktur/index
INFO - 2024-02-27 00:26:34 --> Config Class Initialized
INFO - 2024-02-27 00:26:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:34 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:34 --> URI Class Initialized
INFO - 2024-02-27 00:26:34 --> Router Class Initialized
INFO - 2024-02-27 00:26:34 --> Output Class Initialized
INFO - 2024-02-27 00:26:34 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:34 --> Input Class Initialized
INFO - 2024-02-27 00:26:34 --> Language Class Initialized
INFO - 2024-02-27 00:26:34 --> Loader Class Initialized
INFO - 2024-02-27 00:26:34 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:34 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:34 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:34 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:26:34 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:34 --> Email Class Initialized
DEBUG - 2024-02-27 00:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:34 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:34 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:34 --> Controller Class Initialized
INFO - 2024-02-27 00:26:34 --> Model "Menu_model" initialized
INFO - 2024-02-27 00:26:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:26:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:26:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:26:34 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-02-27 00:26:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:26:34 --> Final output sent to browser
DEBUG - 2024-02-27 00:26:34 --> Total execution time: 0.0587
INFO - 2024-02-27 00:26:49 --> Config Class Initialized
INFO - 2024-02-27 00:26:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:49 --> URI Class Initialized
INFO - 2024-02-27 00:26:49 --> Router Class Initialized
INFO - 2024-02-27 00:26:49 --> Output Class Initialized
INFO - 2024-02-27 00:26:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:49 --> Input Class Initialized
INFO - 2024-02-27 00:26:49 --> Language Class Initialized
INFO - 2024-02-27 00:26:49 --> Loader Class Initialized
INFO - 2024-02-27 00:26:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:26:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:49 --> Controller Class Initialized
INFO - 2024-02-27 00:26:49 --> Model "Menu_model" initialized
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:26:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:26:49 --> Total execution time: 0.0596
INFO - 2024-02-27 00:26:49 --> Config Class Initialized
INFO - 2024-02-27 00:26:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:26:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:26:49 --> Utf8 Class Initialized
INFO - 2024-02-27 00:26:49 --> URI Class Initialized
INFO - 2024-02-27 00:26:49 --> Router Class Initialized
INFO - 2024-02-27 00:26:49 --> Output Class Initialized
INFO - 2024-02-27 00:26:49 --> Security Class Initialized
DEBUG - 2024-02-27 00:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:26:49 --> Input Class Initialized
INFO - 2024-02-27 00:26:49 --> Language Class Initialized
INFO - 2024-02-27 00:26:49 --> Loader Class Initialized
INFO - 2024-02-27 00:26:49 --> Helper loaded: url_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: file_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: security_helper
INFO - 2024-02-27 00:26:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:26:49 --> Database Driver Class Initialized
INFO - 2024-02-27 00:26:49 --> Email Class Initialized
DEBUG - 2024-02-27 00:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:26:49 --> Helper loaded: form_helper
INFO - 2024-02-27 00:26:49 --> Form Validation Class Initialized
INFO - 2024-02-27 00:26:49 --> Controller Class Initialized
INFO - 2024-02-27 00:26:49 --> Model "User_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:26:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:26:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:26:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:26:49 --> Final output sent to browser
DEBUG - 2024-02-27 00:26:49 --> Total execution time: 0.0810
INFO - 2024-02-27 00:27:12 --> Config Class Initialized
INFO - 2024-02-27 00:27:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:12 --> URI Class Initialized
INFO - 2024-02-27 00:27:12 --> Router Class Initialized
INFO - 2024-02-27 00:27:12 --> Output Class Initialized
INFO - 2024-02-27 00:27:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:12 --> Input Class Initialized
INFO - 2024-02-27 00:27:12 --> Language Class Initialized
INFO - 2024-02-27 00:27:12 --> Loader Class Initialized
INFO - 2024-02-27 00:27:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:27:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:27:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:27:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:27:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:27:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:27:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:27:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:27:12 --> Controller Class Initialized
INFO - 2024-02-27 00:27:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:27:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:27:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:27:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:27:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:27:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:27:12 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:27:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:27:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:27:12 --> Total execution time: 0.0804
INFO - 2024-02-27 00:27:14 --> Config Class Initialized
INFO - 2024-02-27 00:27:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:14 --> URI Class Initialized
INFO - 2024-02-27 00:27:14 --> Router Class Initialized
INFO - 2024-02-27 00:27:14 --> Output Class Initialized
INFO - 2024-02-27 00:27:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:14 --> Input Class Initialized
INFO - 2024-02-27 00:27:14 --> Language Class Initialized
INFO - 2024-02-27 00:27:14 --> Loader Class Initialized
INFO - 2024-02-27 00:27:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:27:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:27:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:27:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:27:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:27:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:27:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:27:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:27:14 --> Controller Class Initialized
INFO - 2024-02-27 00:27:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:27:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:27:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:27:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:27:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:27:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:27:14 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-27 00:27:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:27:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:27:14 --> Total execution time: 0.1205
INFO - 2024-02-27 00:27:15 --> Config Class Initialized
INFO - 2024-02-27 00:27:15 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:15 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:15 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:15 --> URI Class Initialized
INFO - 2024-02-27 00:27:15 --> Router Class Initialized
INFO - 2024-02-27 00:27:15 --> Output Class Initialized
INFO - 2024-02-27 00:27:15 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:15 --> Input Class Initialized
INFO - 2024-02-27 00:27:15 --> Language Class Initialized
ERROR - 2024-02-27 00:27:15 --> 404 Page Not Found: Assets/js
INFO - 2024-02-27 00:27:16 --> Config Class Initialized
INFO - 2024-02-27 00:27:16 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:16 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:16 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:16 --> URI Class Initialized
INFO - 2024-02-27 00:27:16 --> Router Class Initialized
INFO - 2024-02-27 00:27:16 --> Output Class Initialized
INFO - 2024-02-27 00:27:16 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:16 --> Input Class Initialized
INFO - 2024-02-27 00:27:16 --> Language Class Initialized
INFO - 2024-02-27 00:27:16 --> Loader Class Initialized
INFO - 2024-02-27 00:27:16 --> Helper loaded: url_helper
INFO - 2024-02-27 00:27:16 --> Helper loaded: file_helper
INFO - 2024-02-27 00:27:16 --> Helper loaded: security_helper
INFO - 2024-02-27 00:27:16 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:27:16 --> Database Driver Class Initialized
INFO - 2024-02-27 00:27:16 --> Email Class Initialized
DEBUG - 2024-02-27 00:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:27:16 --> Helper loaded: form_helper
INFO - 2024-02-27 00:27:16 --> Form Validation Class Initialized
INFO - 2024-02-27 00:27:16 --> Controller Class Initialized
INFO - 2024-02-27 00:27:16 --> Model "User_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:27:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:27:18 --> Final output sent to browser
DEBUG - 2024-02-27 00:27:18 --> Total execution time: 1.6752
INFO - 2024-02-27 00:27:36 --> Config Class Initialized
INFO - 2024-02-27 00:27:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:36 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:36 --> URI Class Initialized
INFO - 2024-02-27 00:27:36 --> Router Class Initialized
INFO - 2024-02-27 00:27:36 --> Output Class Initialized
INFO - 2024-02-27 00:27:36 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:36 --> Input Class Initialized
INFO - 2024-02-27 00:27:36 --> Language Class Initialized
INFO - 2024-02-27 00:27:36 --> Loader Class Initialized
INFO - 2024-02-27 00:27:36 --> Helper loaded: url_helper
INFO - 2024-02-27 00:27:36 --> Helper loaded: file_helper
INFO - 2024-02-27 00:27:36 --> Helper loaded: security_helper
INFO - 2024-02-27 00:27:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:27:36 --> Database Driver Class Initialized
INFO - 2024-02-27 00:27:36 --> Email Class Initialized
DEBUG - 2024-02-27 00:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:27:36 --> Helper loaded: form_helper
INFO - 2024-02-27 00:27:36 --> Form Validation Class Initialized
INFO - 2024-02-27 00:27:36 --> Controller Class Initialized
INFO - 2024-02-27 00:27:36 --> Model "User_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:27:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:27:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:27:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:27:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:27:36 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:27:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:27:36 --> Final output sent to browser
DEBUG - 2024-02-27 00:27:36 --> Total execution time: 0.0555
INFO - 2024-02-27 00:27:58 --> Config Class Initialized
INFO - 2024-02-27 00:27:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:27:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:27:58 --> Utf8 Class Initialized
INFO - 2024-02-27 00:27:58 --> URI Class Initialized
INFO - 2024-02-27 00:27:58 --> Router Class Initialized
INFO - 2024-02-27 00:27:58 --> Output Class Initialized
INFO - 2024-02-27 00:27:58 --> Security Class Initialized
DEBUG - 2024-02-27 00:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:27:58 --> Input Class Initialized
INFO - 2024-02-27 00:27:58 --> Language Class Initialized
INFO - 2024-02-27 00:27:58 --> Loader Class Initialized
INFO - 2024-02-27 00:27:58 --> Helper loaded: url_helper
INFO - 2024-02-27 00:27:58 --> Helper loaded: file_helper
INFO - 2024-02-27 00:27:58 --> Helper loaded: security_helper
INFO - 2024-02-27 00:27:58 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:27:58 --> Database Driver Class Initialized
INFO - 2024-02-27 00:27:58 --> Email Class Initialized
DEBUG - 2024-02-27 00:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:27:58 --> Helper loaded: form_helper
INFO - 2024-02-27 00:27:58 --> Form Validation Class Initialized
INFO - 2024-02-27 00:27:58 --> Controller Class Initialized
INFO - 2024-02-27 00:27:58 --> Model "User_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:27:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:27:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:27:58 --> Final output sent to browser
DEBUG - 2024-02-27 00:27:58 --> Total execution time: 0.0656
INFO - 2024-02-27 00:28:01 --> Config Class Initialized
INFO - 2024-02-27 00:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:01 --> URI Class Initialized
INFO - 2024-02-27 00:28:01 --> Router Class Initialized
INFO - 2024-02-27 00:28:01 --> Output Class Initialized
INFO - 2024-02-27 00:28:01 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:01 --> Input Class Initialized
INFO - 2024-02-27 00:28:01 --> Language Class Initialized
INFO - 2024-02-27 00:28:01 --> Loader Class Initialized
INFO - 2024-02-27 00:28:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:01 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:01 --> Controller Class Initialized
INFO - 2024-02-27 00:28:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:01 --> Total execution time: 0.0589
INFO - 2024-02-27 00:28:26 --> Config Class Initialized
INFO - 2024-02-27 00:28:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:26 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:26 --> URI Class Initialized
INFO - 2024-02-27 00:28:26 --> Router Class Initialized
INFO - 2024-02-27 00:28:26 --> Output Class Initialized
INFO - 2024-02-27 00:28:26 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:26 --> Input Class Initialized
INFO - 2024-02-27 00:28:26 --> Language Class Initialized
INFO - 2024-02-27 00:28:26 --> Loader Class Initialized
INFO - 2024-02-27 00:28:26 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:26 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:26 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:26 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:26 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:26 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:26 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:26 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:26 --> Controller Class Initialized
INFO - 2024-02-27 00:28:26 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:26 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:28:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:26 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:26 --> Total execution time: 0.0614
INFO - 2024-02-27 00:28:34 --> Config Class Initialized
INFO - 2024-02-27 00:28:34 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:34 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:34 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:34 --> URI Class Initialized
INFO - 2024-02-27 00:28:34 --> Router Class Initialized
INFO - 2024-02-27 00:28:34 --> Output Class Initialized
INFO - 2024-02-27 00:28:34 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:34 --> Input Class Initialized
INFO - 2024-02-27 00:28:34 --> Language Class Initialized
INFO - 2024-02-27 00:28:34 --> Loader Class Initialized
INFO - 2024-02-27 00:28:34 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:34 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:34 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:34 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:34 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:34 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:34 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:34 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:34 --> Controller Class Initialized
INFO - 2024-02-27 00:28:34 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-02-27 00:28:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:34 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:34 --> Total execution time: 0.0715
INFO - 2024-02-27 00:28:35 --> Config Class Initialized
INFO - 2024-02-27 00:28:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:35 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:35 --> URI Class Initialized
INFO - 2024-02-27 00:28:35 --> Router Class Initialized
INFO - 2024-02-27 00:28:35 --> Output Class Initialized
INFO - 2024-02-27 00:28:35 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:35 --> Input Class Initialized
INFO - 2024-02-27 00:28:35 --> Language Class Initialized
INFO - 2024-02-27 00:28:35 --> Loader Class Initialized
INFO - 2024-02-27 00:28:35 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:35 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:35 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:35 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:35 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:35 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:35 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:35 --> Controller Class Initialized
INFO - 2024-02-27 00:28:35 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-02-27 00:28:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:35 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:35 --> Total execution time: 0.0650
INFO - 2024-02-27 00:28:36 --> Config Class Initialized
INFO - 2024-02-27 00:28:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:36 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:36 --> URI Class Initialized
INFO - 2024-02-27 00:28:36 --> Router Class Initialized
INFO - 2024-02-27 00:28:36 --> Output Class Initialized
INFO - 2024-02-27 00:28:36 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:36 --> Input Class Initialized
INFO - 2024-02-27 00:28:36 --> Language Class Initialized
INFO - 2024-02-27 00:28:36 --> Loader Class Initialized
INFO - 2024-02-27 00:28:36 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:36 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:36 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:36 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:36 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:36 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:36 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:36 --> Controller Class Initialized
INFO - 2024-02-27 00:28:36 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:28:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:36 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:36 --> Total execution time: 0.0793
INFO - 2024-02-27 00:28:39 --> Config Class Initialized
INFO - 2024-02-27 00:28:39 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:39 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:39 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:39 --> URI Class Initialized
INFO - 2024-02-27 00:28:39 --> Router Class Initialized
INFO - 2024-02-27 00:28:39 --> Output Class Initialized
INFO - 2024-02-27 00:28:39 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:39 --> Input Class Initialized
INFO - 2024-02-27 00:28:39 --> Language Class Initialized
INFO - 2024-02-27 00:28:39 --> Loader Class Initialized
INFO - 2024-02-27 00:28:39 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:39 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:39 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:39 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:39 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:39 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:39 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:39 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:39 --> Controller Class Initialized
INFO - 2024-02-27 00:28:39 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:39 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/detailfaktur.php
INFO - 2024-02-27 00:28:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:39 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:39 --> Total execution time: 0.0687
INFO - 2024-02-27 00:28:47 --> Config Class Initialized
INFO - 2024-02-27 00:28:47 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:47 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:47 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:47 --> URI Class Initialized
INFO - 2024-02-27 00:28:47 --> Router Class Initialized
INFO - 2024-02-27 00:28:47 --> Output Class Initialized
INFO - 2024-02-27 00:28:47 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:47 --> Input Class Initialized
INFO - 2024-02-27 00:28:47 --> Language Class Initialized
INFO - 2024-02-27 00:28:47 --> Loader Class Initialized
INFO - 2024-02-27 00:28:47 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:47 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:47 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:47 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:47 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:47 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:47 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:47 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:47 --> Controller Class Initialized
INFO - 2024-02-27 00:28:47 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-27 00:28:47 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:47 --> Total execution time: 0.0732
INFO - 2024-02-27 00:28:48 --> Config Class Initialized
INFO - 2024-02-27 00:28:48 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:48 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:48 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:48 --> URI Class Initialized
INFO - 2024-02-27 00:28:48 --> Router Class Initialized
INFO - 2024-02-27 00:28:48 --> Output Class Initialized
INFO - 2024-02-27 00:28:48 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:48 --> Input Class Initialized
INFO - 2024-02-27 00:28:48 --> Language Class Initialized
INFO - 2024-02-27 00:28:48 --> Loader Class Initialized
INFO - 2024-02-27 00:28:48 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:48 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:48 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:48 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:48 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:48 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:48 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:48 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:48 --> Controller Class Initialized
INFO - 2024-02-27 00:28:48 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/detailfaktur.php
INFO - 2024-02-27 00:28:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:48 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:48 --> Total execution time: 0.0640
INFO - 2024-02-27 00:28:57 --> Config Class Initialized
INFO - 2024-02-27 00:28:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:28:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:28:57 --> Utf8 Class Initialized
INFO - 2024-02-27 00:28:57 --> URI Class Initialized
INFO - 2024-02-27 00:28:57 --> Router Class Initialized
INFO - 2024-02-27 00:28:57 --> Output Class Initialized
INFO - 2024-02-27 00:28:57 --> Security Class Initialized
DEBUG - 2024-02-27 00:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:28:57 --> Input Class Initialized
INFO - 2024-02-27 00:28:57 --> Language Class Initialized
INFO - 2024-02-27 00:28:57 --> Loader Class Initialized
INFO - 2024-02-27 00:28:57 --> Helper loaded: url_helper
INFO - 2024-02-27 00:28:57 --> Helper loaded: file_helper
INFO - 2024-02-27 00:28:57 --> Helper loaded: security_helper
INFO - 2024-02-27 00:28:57 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:28:57 --> Database Driver Class Initialized
INFO - 2024-02-27 00:28:57 --> Email Class Initialized
DEBUG - 2024-02-27 00:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:28:57 --> Helper loaded: form_helper
INFO - 2024-02-27 00:28:57 --> Form Validation Class Initialized
INFO - 2024-02-27 00:28:57 --> Controller Class Initialized
INFO - 2024-02-27 00:28:57 --> Model "User_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:28:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:28:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:28:57 --> Final output sent to browser
DEBUG - 2024-02-27 00:28:57 --> Total execution time: 0.0659
INFO - 2024-02-27 00:29:01 --> Config Class Initialized
INFO - 2024-02-27 00:29:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:01 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:01 --> URI Class Initialized
INFO - 2024-02-27 00:29:01 --> Router Class Initialized
INFO - 2024-02-27 00:29:01 --> Output Class Initialized
INFO - 2024-02-27 00:29:01 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:01 --> Input Class Initialized
INFO - 2024-02-27 00:29:01 --> Language Class Initialized
INFO - 2024-02-27 00:29:01 --> Loader Class Initialized
INFO - 2024-02-27 00:29:01 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:01 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:01 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:01 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:01 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:01 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:01 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:01 --> Controller Class Initialized
INFO - 2024-02-27 00:29:01 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:29:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:29:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:29:01 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:29:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:29:01 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:01 --> Total execution time: 0.0725
INFO - 2024-02-27 00:29:04 --> Config Class Initialized
INFO - 2024-02-27 00:29:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:04 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:04 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:04 --> URI Class Initialized
INFO - 2024-02-27 00:29:04 --> Router Class Initialized
INFO - 2024-02-27 00:29:04 --> Output Class Initialized
INFO - 2024-02-27 00:29:04 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:04 --> Input Class Initialized
INFO - 2024-02-27 00:29:04 --> Language Class Initialized
INFO - 2024-02-27 00:29:04 --> Loader Class Initialized
INFO - 2024-02-27 00:29:04 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:04 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:04 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:04 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:04 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:04 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:04 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:04 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:04 --> Controller Class Initialized
INFO - 2024-02-27 00:29:04 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:29:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:29:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:29:04 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:29:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:29:04 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:04 --> Total execution time: 0.0603
INFO - 2024-02-27 00:29:10 --> Config Class Initialized
INFO - 2024-02-27 00:29:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:10 --> URI Class Initialized
INFO - 2024-02-27 00:29:10 --> Router Class Initialized
INFO - 2024-02-27 00:29:10 --> Output Class Initialized
INFO - 2024-02-27 00:29:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:10 --> Input Class Initialized
INFO - 2024-02-27 00:29:10 --> Language Class Initialized
INFO - 2024-02-27 00:29:10 --> Loader Class Initialized
INFO - 2024-02-27 00:29:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:10 --> Controller Class Initialized
INFO - 2024-02-27 00:29:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:10 --> Total execution time: 0.0511
INFO - 2024-02-27 00:29:10 --> Config Class Initialized
INFO - 2024-02-27 00:29:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:10 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:10 --> URI Class Initialized
INFO - 2024-02-27 00:29:10 --> Router Class Initialized
INFO - 2024-02-27 00:29:10 --> Output Class Initialized
INFO - 2024-02-27 00:29:10 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:10 --> Input Class Initialized
INFO - 2024-02-27 00:29:10 --> Language Class Initialized
INFO - 2024-02-27 00:29:10 --> Loader Class Initialized
INFO - 2024-02-27 00:29:10 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:10 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:10 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:10 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:10 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:10 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:10 --> Controller Class Initialized
INFO - 2024-02-27 00:29:10 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:10 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:10 --> Total execution time: 0.0719
INFO - 2024-02-27 00:29:11 --> Config Class Initialized
INFO - 2024-02-27 00:29:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:11 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:11 --> URI Class Initialized
INFO - 2024-02-27 00:29:11 --> Router Class Initialized
INFO - 2024-02-27 00:29:11 --> Output Class Initialized
INFO - 2024-02-27 00:29:11 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:11 --> Input Class Initialized
INFO - 2024-02-27 00:29:11 --> Language Class Initialized
INFO - 2024-02-27 00:29:11 --> Loader Class Initialized
INFO - 2024-02-27 00:29:11 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:11 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:11 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:11 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:11 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:11 --> Controller Class Initialized
INFO - 2024-02-27 00:29:11 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:29:11 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:11 --> Total execution time: 0.0632
INFO - 2024-02-27 00:29:11 --> Config Class Initialized
INFO - 2024-02-27 00:29:11 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:29:11 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:29:11 --> Utf8 Class Initialized
INFO - 2024-02-27 00:29:11 --> URI Class Initialized
INFO - 2024-02-27 00:29:11 --> Router Class Initialized
INFO - 2024-02-27 00:29:11 --> Output Class Initialized
INFO - 2024-02-27 00:29:11 --> Security Class Initialized
DEBUG - 2024-02-27 00:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:29:11 --> Input Class Initialized
INFO - 2024-02-27 00:29:11 --> Language Class Initialized
INFO - 2024-02-27 00:29:11 --> Loader Class Initialized
INFO - 2024-02-27 00:29:11 --> Helper loaded: url_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: file_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: security_helper
INFO - 2024-02-27 00:29:11 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:29:11 --> Database Driver Class Initialized
INFO - 2024-02-27 00:29:11 --> Email Class Initialized
DEBUG - 2024-02-27 00:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:29:11 --> Helper loaded: form_helper
INFO - 2024-02-27 00:29:11 --> Form Validation Class Initialized
INFO - 2024-02-27 00:29:11 --> Controller Class Initialized
INFO - 2024-02-27 00:29:11 --> Model "User_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:29:11 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:29:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\direktur/dashboard.php
INFO - 2024-02-27 00:29:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:29:11 --> Final output sent to browser
DEBUG - 2024-02-27 00:29:11 --> Total execution time: 0.0793
INFO - 2024-02-27 00:31:20 --> Config Class Initialized
INFO - 2024-02-27 00:31:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:31:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:31:20 --> Utf8 Class Initialized
INFO - 2024-02-27 00:31:20 --> URI Class Initialized
INFO - 2024-02-27 00:31:20 --> Router Class Initialized
INFO - 2024-02-27 00:31:20 --> Output Class Initialized
INFO - 2024-02-27 00:31:20 --> Security Class Initialized
DEBUG - 2024-02-27 00:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:31:20 --> Input Class Initialized
INFO - 2024-02-27 00:31:20 --> Language Class Initialized
INFO - 2024-02-27 00:31:20 --> Loader Class Initialized
INFO - 2024-02-27 00:31:20 --> Helper loaded: url_helper
INFO - 2024-02-27 00:31:20 --> Helper loaded: file_helper
INFO - 2024-02-27 00:31:20 --> Helper loaded: security_helper
INFO - 2024-02-27 00:31:20 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:31:20 --> Database Driver Class Initialized
INFO - 2024-02-27 00:31:20 --> Email Class Initialized
DEBUG - 2024-02-27 00:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:31:20 --> Helper loaded: form_helper
INFO - 2024-02-27 00:31:20 --> Form Validation Class Initialized
INFO - 2024-02-27 00:31:20 --> Controller Class Initialized
INFO - 2024-02-27 00:31:20 --> Model "User_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:31:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:31:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:31:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:31:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:31:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:31:20 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:31:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:31:20 --> Final output sent to browser
DEBUG - 2024-02-27 00:31:20 --> Total execution time: 0.0619
INFO - 2024-02-27 00:31:21 --> Config Class Initialized
INFO - 2024-02-27 00:31:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:31:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:31:21 --> Utf8 Class Initialized
INFO - 2024-02-27 00:31:21 --> URI Class Initialized
INFO - 2024-02-27 00:31:21 --> Router Class Initialized
INFO - 2024-02-27 00:31:21 --> Output Class Initialized
INFO - 2024-02-27 00:31:21 --> Security Class Initialized
DEBUG - 2024-02-27 00:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:31:21 --> Input Class Initialized
INFO - 2024-02-27 00:31:21 --> Language Class Initialized
INFO - 2024-02-27 00:31:21 --> Loader Class Initialized
INFO - 2024-02-27 00:31:21 --> Helper loaded: url_helper
INFO - 2024-02-27 00:31:21 --> Helper loaded: file_helper
INFO - 2024-02-27 00:31:21 --> Helper loaded: security_helper
INFO - 2024-02-27 00:31:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:31:21 --> Database Driver Class Initialized
INFO - 2024-02-27 00:31:21 --> Email Class Initialized
DEBUG - 2024-02-27 00:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:31:21 --> Helper loaded: form_helper
INFO - 2024-02-27 00:31:21 --> Form Validation Class Initialized
INFO - 2024-02-27 00:31:21 --> Controller Class Initialized
INFO - 2024-02-27 00:31:21 --> Model "User_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:31:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:31:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:31:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:31:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:31:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:31:21 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-27 00:31:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:31:21 --> Final output sent to browser
DEBUG - 2024-02-27 00:31:21 --> Total execution time: 0.0819
INFO - 2024-02-27 00:31:22 --> Config Class Initialized
INFO - 2024-02-27 00:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:31:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:31:22 --> URI Class Initialized
INFO - 2024-02-27 00:31:22 --> Router Class Initialized
INFO - 2024-02-27 00:31:22 --> Output Class Initialized
INFO - 2024-02-27 00:31:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:31:22 --> Input Class Initialized
INFO - 2024-02-27 00:31:22 --> Language Class Initialized
ERROR - 2024-02-27 00:31:22 --> 404 Page Not Found: Assets/js
INFO - 2024-02-27 00:31:22 --> Config Class Initialized
INFO - 2024-02-27 00:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:31:22 --> Utf8 Class Initialized
INFO - 2024-02-27 00:31:22 --> URI Class Initialized
INFO - 2024-02-27 00:31:22 --> Router Class Initialized
INFO - 2024-02-27 00:31:22 --> Output Class Initialized
INFO - 2024-02-27 00:31:22 --> Security Class Initialized
DEBUG - 2024-02-27 00:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:31:22 --> Input Class Initialized
INFO - 2024-02-27 00:31:22 --> Language Class Initialized
INFO - 2024-02-27 00:31:22 --> Loader Class Initialized
INFO - 2024-02-27 00:31:22 --> Helper loaded: url_helper
INFO - 2024-02-27 00:31:22 --> Helper loaded: file_helper
INFO - 2024-02-27 00:31:22 --> Helper loaded: security_helper
INFO - 2024-02-27 00:31:22 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:31:22 --> Database Driver Class Initialized
INFO - 2024-02-27 00:31:22 --> Email Class Initialized
DEBUG - 2024-02-27 00:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:31:22 --> Helper loaded: form_helper
INFO - 2024-02-27 00:31:22 --> Form Validation Class Initialized
INFO - 2024-02-27 00:31:22 --> Controller Class Initialized
INFO - 2024-02-27 00:31:22 --> Model "User_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:31:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:31:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:31:23 --> Final output sent to browser
DEBUG - 2024-02-27 00:31:23 --> Total execution time: 0.5911
INFO - 2024-02-27 00:31:32 --> Config Class Initialized
INFO - 2024-02-27 00:31:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:31:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:31:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:31:32 --> URI Class Initialized
INFO - 2024-02-27 00:31:32 --> Router Class Initialized
INFO - 2024-02-27 00:31:32 --> Output Class Initialized
INFO - 2024-02-27 00:31:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:31:32 --> Input Class Initialized
INFO - 2024-02-27 00:31:32 --> Language Class Initialized
INFO - 2024-02-27 00:31:32 --> Loader Class Initialized
INFO - 2024-02-27 00:31:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:31:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:31:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:31:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:31:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:31:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:31:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:31:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:31:32 --> Controller Class Initialized
INFO - 2024-02-27 00:31:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:31:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:31:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:31:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:31:32 --> Total execution time: 0.1354
INFO - 2024-02-27 00:34:07 --> Config Class Initialized
INFO - 2024-02-27 00:34:07 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:34:07 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:34:07 --> Utf8 Class Initialized
INFO - 2024-02-27 00:34:07 --> URI Class Initialized
INFO - 2024-02-27 00:34:07 --> Router Class Initialized
INFO - 2024-02-27 00:34:07 --> Output Class Initialized
INFO - 2024-02-27 00:34:07 --> Security Class Initialized
DEBUG - 2024-02-27 00:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:34:07 --> Input Class Initialized
INFO - 2024-02-27 00:34:07 --> Language Class Initialized
INFO - 2024-02-27 00:34:07 --> Loader Class Initialized
INFO - 2024-02-27 00:34:07 --> Helper loaded: url_helper
INFO - 2024-02-27 00:34:07 --> Helper loaded: file_helper
INFO - 2024-02-27 00:34:07 --> Helper loaded: security_helper
INFO - 2024-02-27 00:34:07 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:34:08 --> Database Driver Class Initialized
INFO - 2024-02-27 00:34:08 --> Email Class Initialized
DEBUG - 2024-02-27 00:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:34:08 --> Helper loaded: form_helper
INFO - 2024-02-27 00:34:08 --> Form Validation Class Initialized
INFO - 2024-02-27 00:34:08 --> Controller Class Initialized
INFO - 2024-02-27 00:34:08 --> Model "User_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:34:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:34:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:34:08 --> Final output sent to browser
DEBUG - 2024-02-27 00:34:08 --> Total execution time: 0.1768
INFO - 2024-02-27 00:34:32 --> Config Class Initialized
INFO - 2024-02-27 00:34:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:34:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:34:32 --> Utf8 Class Initialized
INFO - 2024-02-27 00:34:32 --> URI Class Initialized
INFO - 2024-02-27 00:34:32 --> Router Class Initialized
INFO - 2024-02-27 00:34:32 --> Output Class Initialized
INFO - 2024-02-27 00:34:32 --> Security Class Initialized
DEBUG - 2024-02-27 00:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:34:32 --> Input Class Initialized
INFO - 2024-02-27 00:34:32 --> Language Class Initialized
INFO - 2024-02-27 00:34:32 --> Loader Class Initialized
INFO - 2024-02-27 00:34:32 --> Helper loaded: url_helper
INFO - 2024-02-27 00:34:32 --> Helper loaded: file_helper
INFO - 2024-02-27 00:34:32 --> Helper loaded: security_helper
INFO - 2024-02-27 00:34:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:34:32 --> Database Driver Class Initialized
INFO - 2024-02-27 00:34:32 --> Email Class Initialized
DEBUG - 2024-02-27 00:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:34:32 --> Helper loaded: form_helper
INFO - 2024-02-27 00:34:32 --> Form Validation Class Initialized
INFO - 2024-02-27 00:34:32 --> Controller Class Initialized
INFO - 2024-02-27 00:34:32 --> Model "User_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:34:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:34:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:34:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:34:32 --> Total execution time: 0.1542
INFO - 2024-02-27 00:35:31 --> Config Class Initialized
INFO - 2024-02-27 00:35:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:35:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:35:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:35:31 --> URI Class Initialized
INFO - 2024-02-27 00:35:31 --> Router Class Initialized
INFO - 2024-02-27 00:35:31 --> Output Class Initialized
INFO - 2024-02-27 00:35:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:35:31 --> Input Class Initialized
INFO - 2024-02-27 00:35:31 --> Language Class Initialized
INFO - 2024-02-27 00:35:31 --> Loader Class Initialized
INFO - 2024-02-27 00:35:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:35:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:35:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:35:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:35:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:35:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:35:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:35:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:35:31 --> Controller Class Initialized
INFO - 2024-02-27 00:35:31 --> Model "User_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:35:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:35:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:35:31 --> Final output sent to browser
DEBUG - 2024-02-27 00:35:31 --> Total execution time: 0.1555
INFO - 2024-02-27 00:35:52 --> Config Class Initialized
INFO - 2024-02-27 00:35:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:35:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:35:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:35:52 --> URI Class Initialized
INFO - 2024-02-27 00:35:52 --> Router Class Initialized
INFO - 2024-02-27 00:35:52 --> Output Class Initialized
INFO - 2024-02-27 00:35:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:35:52 --> Input Class Initialized
INFO - 2024-02-27 00:35:52 --> Language Class Initialized
INFO - 2024-02-27 00:35:52 --> Loader Class Initialized
INFO - 2024-02-27 00:35:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:35:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:35:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:35:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:35:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:35:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:35:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:35:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:35:52 --> Controller Class Initialized
INFO - 2024-02-27 00:35:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:35:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:35:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:35:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:35:52 --> Total execution time: 0.1573
INFO - 2024-02-27 00:36:56 --> Config Class Initialized
INFO - 2024-02-27 00:36:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:36:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:36:56 --> Utf8 Class Initialized
INFO - 2024-02-27 00:36:56 --> URI Class Initialized
INFO - 2024-02-27 00:36:56 --> Router Class Initialized
INFO - 2024-02-27 00:36:56 --> Output Class Initialized
INFO - 2024-02-27 00:36:56 --> Security Class Initialized
DEBUG - 2024-02-27 00:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:36:56 --> Input Class Initialized
INFO - 2024-02-27 00:36:56 --> Language Class Initialized
INFO - 2024-02-27 00:36:56 --> Loader Class Initialized
INFO - 2024-02-27 00:36:56 --> Helper loaded: url_helper
INFO - 2024-02-27 00:36:56 --> Helper loaded: file_helper
INFO - 2024-02-27 00:36:56 --> Helper loaded: security_helper
INFO - 2024-02-27 00:36:56 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:36:56 --> Database Driver Class Initialized
INFO - 2024-02-27 00:36:56 --> Email Class Initialized
DEBUG - 2024-02-27 00:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:36:56 --> Helper loaded: form_helper
INFO - 2024-02-27 00:36:56 --> Form Validation Class Initialized
INFO - 2024-02-27 00:36:56 --> Controller Class Initialized
INFO - 2024-02-27 00:36:56 --> Model "User_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:36:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:36:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:36:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:36:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:36:56 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:36:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:36:56 --> Final output sent to browser
DEBUG - 2024-02-27 00:36:56 --> Total execution time: 0.0836
INFO - 2024-02-27 00:36:58 --> Config Class Initialized
INFO - 2024-02-27 00:36:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:36:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:36:58 --> Utf8 Class Initialized
INFO - 2024-02-27 00:36:58 --> URI Class Initialized
INFO - 2024-02-27 00:36:58 --> Router Class Initialized
INFO - 2024-02-27 00:36:58 --> Output Class Initialized
INFO - 2024-02-27 00:36:58 --> Security Class Initialized
DEBUG - 2024-02-27 00:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:36:58 --> Input Class Initialized
INFO - 2024-02-27 00:36:58 --> Language Class Initialized
INFO - 2024-02-27 00:36:58 --> Loader Class Initialized
INFO - 2024-02-27 00:36:58 --> Helper loaded: url_helper
INFO - 2024-02-27 00:36:58 --> Helper loaded: file_helper
INFO - 2024-02-27 00:36:58 --> Helper loaded: security_helper
INFO - 2024-02-27 00:36:58 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:36:58 --> Database Driver Class Initialized
INFO - 2024-02-27 00:36:58 --> Email Class Initialized
DEBUG - 2024-02-27 00:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:36:58 --> Helper loaded: form_helper
INFO - 2024-02-27 00:36:58 --> Form Validation Class Initialized
INFO - 2024-02-27 00:36:58 --> Controller Class Initialized
INFO - 2024-02-27 00:36:58 --> Model "User_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:36:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:36:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:36:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:36:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:36:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:36:58 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfakturbelum.php
INFO - 2024-02-27 00:36:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:36:58 --> Final output sent to browser
DEBUG - 2024-02-27 00:36:58 --> Total execution time: 0.1144
INFO - 2024-02-27 00:36:59 --> Config Class Initialized
INFO - 2024-02-27 00:36:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:36:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:36:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:36:59 --> URI Class Initialized
INFO - 2024-02-27 00:36:59 --> Router Class Initialized
INFO - 2024-02-27 00:36:59 --> Output Class Initialized
INFO - 2024-02-27 00:36:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:36:59 --> Input Class Initialized
INFO - 2024-02-27 00:36:59 --> Language Class Initialized
ERROR - 2024-02-27 00:36:59 --> 404 Page Not Found: Assets/js
INFO - 2024-02-27 00:36:59 --> Config Class Initialized
INFO - 2024-02-27 00:36:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:36:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:36:59 --> Utf8 Class Initialized
INFO - 2024-02-27 00:36:59 --> URI Class Initialized
INFO - 2024-02-27 00:36:59 --> Router Class Initialized
INFO - 2024-02-27 00:36:59 --> Output Class Initialized
INFO - 2024-02-27 00:36:59 --> Security Class Initialized
DEBUG - 2024-02-27 00:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:36:59 --> Input Class Initialized
INFO - 2024-02-27 00:36:59 --> Language Class Initialized
INFO - 2024-02-27 00:36:59 --> Loader Class Initialized
INFO - 2024-02-27 00:36:59 --> Helper loaded: url_helper
INFO - 2024-02-27 00:36:59 --> Helper loaded: file_helper
INFO - 2024-02-27 00:36:59 --> Helper loaded: security_helper
INFO - 2024-02-27 00:36:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:36:59 --> Database Driver Class Initialized
INFO - 2024-02-27 00:36:59 --> Email Class Initialized
DEBUG - 2024-02-27 00:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:36:59 --> Helper loaded: form_helper
INFO - 2024-02-27 00:36:59 --> Form Validation Class Initialized
INFO - 2024-02-27 00:36:59 --> Controller Class Initialized
INFO - 2024-02-27 00:36:59 --> Model "User_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:36:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:36:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:36:59 --> Final output sent to browser
DEBUG - 2024-02-27 00:36:59 --> Total execution time: 0.3453
INFO - 2024-02-27 00:51:52 --> Config Class Initialized
INFO - 2024-02-27 00:51:52 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:51:52 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:51:52 --> Utf8 Class Initialized
INFO - 2024-02-27 00:51:52 --> URI Class Initialized
INFO - 2024-02-27 00:51:52 --> Router Class Initialized
INFO - 2024-02-27 00:51:52 --> Output Class Initialized
INFO - 2024-02-27 00:51:52 --> Security Class Initialized
DEBUG - 2024-02-27 00:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:51:52 --> Input Class Initialized
INFO - 2024-02-27 00:51:52 --> Language Class Initialized
INFO - 2024-02-27 00:51:52 --> Loader Class Initialized
INFO - 2024-02-27 00:51:52 --> Helper loaded: url_helper
INFO - 2024-02-27 00:51:52 --> Helper loaded: file_helper
INFO - 2024-02-27 00:51:52 --> Helper loaded: security_helper
INFO - 2024-02-27 00:51:52 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:51:52 --> Database Driver Class Initialized
INFO - 2024-02-27 00:51:52 --> Email Class Initialized
DEBUG - 2024-02-27 00:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:51:52 --> Helper loaded: form_helper
INFO - 2024-02-27 00:51:52 --> Form Validation Class Initialized
INFO - 2024-02-27 00:51:52 --> Controller Class Initialized
INFO - 2024-02-27 00:51:52 --> Model "User_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:51:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:51:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfakturbelum.php
INFO - 2024-02-27 00:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:51:52 --> Final output sent to browser
DEBUG - 2024-02-27 00:51:52 --> Total execution time: 0.0588
INFO - 2024-02-27 00:52:12 --> Config Class Initialized
INFO - 2024-02-27 00:52:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:52:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:52:12 --> Utf8 Class Initialized
INFO - 2024-02-27 00:52:12 --> URI Class Initialized
INFO - 2024-02-27 00:52:12 --> Router Class Initialized
INFO - 2024-02-27 00:52:12 --> Output Class Initialized
INFO - 2024-02-27 00:52:12 --> Security Class Initialized
DEBUG - 2024-02-27 00:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:52:12 --> Input Class Initialized
INFO - 2024-02-27 00:52:12 --> Language Class Initialized
INFO - 2024-02-27 00:52:12 --> Loader Class Initialized
INFO - 2024-02-27 00:52:12 --> Helper loaded: url_helper
INFO - 2024-02-27 00:52:12 --> Helper loaded: file_helper
INFO - 2024-02-27 00:52:12 --> Helper loaded: security_helper
INFO - 2024-02-27 00:52:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:52:12 --> Database Driver Class Initialized
INFO - 2024-02-27 00:52:12 --> Email Class Initialized
DEBUG - 2024-02-27 00:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:52:12 --> Helper loaded: form_helper
INFO - 2024-02-27 00:52:12 --> Form Validation Class Initialized
INFO - 2024-02-27 00:52:12 --> Controller Class Initialized
INFO - 2024-02-27 00:52:12 --> Model "User_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:52:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:52:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:52:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:52:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:52:12 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 00:52:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:52:12 --> Final output sent to browser
DEBUG - 2024-02-27 00:52:12 --> Total execution time: 0.0796
INFO - 2024-02-27 00:52:13 --> Config Class Initialized
INFO - 2024-02-27 00:52:13 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:52:13 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:52:13 --> Utf8 Class Initialized
INFO - 2024-02-27 00:52:13 --> URI Class Initialized
INFO - 2024-02-27 00:52:13 --> Router Class Initialized
INFO - 2024-02-27 00:52:13 --> Output Class Initialized
INFO - 2024-02-27 00:52:13 --> Security Class Initialized
DEBUG - 2024-02-27 00:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:52:13 --> Input Class Initialized
INFO - 2024-02-27 00:52:13 --> Language Class Initialized
INFO - 2024-02-27 00:52:13 --> Loader Class Initialized
INFO - 2024-02-27 00:52:13 --> Helper loaded: url_helper
INFO - 2024-02-27 00:52:13 --> Helper loaded: file_helper
INFO - 2024-02-27 00:52:13 --> Helper loaded: security_helper
INFO - 2024-02-27 00:52:13 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:52:13 --> Database Driver Class Initialized
INFO - 2024-02-27 00:52:13 --> Email Class Initialized
DEBUG - 2024-02-27 00:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:52:13 --> Helper loaded: form_helper
INFO - 2024-02-27 00:52:13 --> Form Validation Class Initialized
INFO - 2024-02-27 00:52:13 --> Controller Class Initialized
INFO - 2024-02-27 00:52:13 --> Model "User_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:52:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:52:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:52:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:52:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:52:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:52:13 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:52:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:52:13 --> Final output sent to browser
DEBUG - 2024-02-27 00:52:13 --> Total execution time: 0.0586
INFO - 2024-02-27 00:52:56 --> Config Class Initialized
INFO - 2024-02-27 00:52:56 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:52:56 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:52:56 --> Utf8 Class Initialized
INFO - 2024-02-27 00:52:56 --> URI Class Initialized
INFO - 2024-02-27 00:52:56 --> Router Class Initialized
INFO - 2024-02-27 00:52:56 --> Output Class Initialized
INFO - 2024-02-27 00:52:56 --> Security Class Initialized
DEBUG - 2024-02-27 00:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:52:56 --> Input Class Initialized
INFO - 2024-02-27 00:52:56 --> Language Class Initialized
INFO - 2024-02-27 00:52:56 --> Loader Class Initialized
INFO - 2024-02-27 00:52:56 --> Helper loaded: url_helper
INFO - 2024-02-27 00:52:56 --> Helper loaded: file_helper
INFO - 2024-02-27 00:52:56 --> Helper loaded: security_helper
INFO - 2024-02-27 00:52:56 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:52:56 --> Database Driver Class Initialized
INFO - 2024-02-27 00:52:56 --> Email Class Initialized
DEBUG - 2024-02-27 00:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:52:56 --> Helper loaded: form_helper
INFO - 2024-02-27 00:52:56 --> Form Validation Class Initialized
INFO - 2024-02-27 00:52:56 --> Controller Class Initialized
INFO - 2024-02-27 00:52:56 --> Model "User_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:52:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:52:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:52:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:52:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:52:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:52:56 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:52:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:52:56 --> Final output sent to browser
DEBUG - 2024-02-27 00:52:56 --> Total execution time: 0.0640
INFO - 2024-02-27 00:54:14 --> Config Class Initialized
INFO - 2024-02-27 00:54:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:54:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:54:14 --> Utf8 Class Initialized
INFO - 2024-02-27 00:54:14 --> URI Class Initialized
INFO - 2024-02-27 00:54:14 --> Router Class Initialized
INFO - 2024-02-27 00:54:14 --> Output Class Initialized
INFO - 2024-02-27 00:54:14 --> Security Class Initialized
DEBUG - 2024-02-27 00:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:54:14 --> Input Class Initialized
INFO - 2024-02-27 00:54:14 --> Language Class Initialized
INFO - 2024-02-27 00:54:14 --> Loader Class Initialized
INFO - 2024-02-27 00:54:14 --> Helper loaded: url_helper
INFO - 2024-02-27 00:54:14 --> Helper loaded: file_helper
INFO - 2024-02-27 00:54:14 --> Helper loaded: security_helper
INFO - 2024-02-27 00:54:14 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:54:14 --> Database Driver Class Initialized
INFO - 2024-02-27 00:54:14 --> Email Class Initialized
DEBUG - 2024-02-27 00:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:54:14 --> Helper loaded: form_helper
INFO - 2024-02-27 00:54:14 --> Form Validation Class Initialized
INFO - 2024-02-27 00:54:14 --> Controller Class Initialized
INFO - 2024-02-27 00:54:14 --> Model "User_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:54:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:54:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:54:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:54:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:54:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:54:14 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:54:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:54:14 --> Final output sent to browser
DEBUG - 2024-02-27 00:54:14 --> Total execution time: 0.0701
INFO - 2024-02-27 00:54:31 --> Config Class Initialized
INFO - 2024-02-27 00:54:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:54:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:54:31 --> Utf8 Class Initialized
INFO - 2024-02-27 00:54:31 --> URI Class Initialized
INFO - 2024-02-27 00:54:31 --> Router Class Initialized
INFO - 2024-02-27 00:54:31 --> Output Class Initialized
INFO - 2024-02-27 00:54:31 --> Security Class Initialized
DEBUG - 2024-02-27 00:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:54:31 --> Input Class Initialized
INFO - 2024-02-27 00:54:31 --> Language Class Initialized
INFO - 2024-02-27 00:54:31 --> Loader Class Initialized
INFO - 2024-02-27 00:54:31 --> Helper loaded: url_helper
INFO - 2024-02-27 00:54:31 --> Helper loaded: file_helper
INFO - 2024-02-27 00:54:31 --> Helper loaded: security_helper
INFO - 2024-02-27 00:54:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:54:31 --> Database Driver Class Initialized
INFO - 2024-02-27 00:54:31 --> Email Class Initialized
DEBUG - 2024-02-27 00:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:54:31 --> Helper loaded: form_helper
INFO - 2024-02-27 00:54:31 --> Form Validation Class Initialized
INFO - 2024-02-27 00:54:31 --> Controller Class Initialized
INFO - 2024-02-27 00:54:31 --> Model "User_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:54:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:54:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:54:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:54:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:54:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:54:32 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 00:54:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:54:32 --> Final output sent to browser
DEBUG - 2024-02-27 00:54:32 --> Total execution time: 0.0634
INFO - 2024-02-27 00:55:26 --> Config Class Initialized
INFO - 2024-02-27 00:55:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:55:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:55:26 --> Utf8 Class Initialized
INFO - 2024-02-27 00:55:26 --> URI Class Initialized
INFO - 2024-02-27 00:55:26 --> Router Class Initialized
INFO - 2024-02-27 00:55:26 --> Output Class Initialized
INFO - 2024-02-27 00:55:26 --> Security Class Initialized
DEBUG - 2024-02-27 00:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:55:26 --> Input Class Initialized
INFO - 2024-02-27 00:55:26 --> Language Class Initialized
INFO - 2024-02-27 00:55:26 --> Loader Class Initialized
INFO - 2024-02-27 00:55:26 --> Helper loaded: url_helper
INFO - 2024-02-27 00:55:26 --> Helper loaded: file_helper
INFO - 2024-02-27 00:55:26 --> Helper loaded: security_helper
INFO - 2024-02-27 00:55:26 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:55:26 --> Database Driver Class Initialized
INFO - 2024-02-27 00:55:26 --> Email Class Initialized
DEBUG - 2024-02-27 00:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:55:26 --> Helper loaded: form_helper
INFO - 2024-02-27 00:55:26 --> Form Validation Class Initialized
INFO - 2024-02-27 00:55:26 --> Controller Class Initialized
INFO - 2024-02-27 00:55:26 --> Model "User_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:55:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:55:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:55:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:55:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:55:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:55:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-27 00:55:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:55:26 --> Final output sent to browser
DEBUG - 2024-02-27 00:55:26 --> Total execution time: 0.0680
INFO - 2024-02-27 00:55:27 --> Config Class Initialized
INFO - 2024-02-27 00:55:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 00:55:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 00:55:27 --> Utf8 Class Initialized
INFO - 2024-02-27 00:55:27 --> URI Class Initialized
INFO - 2024-02-27 00:55:27 --> Router Class Initialized
INFO - 2024-02-27 00:55:27 --> Output Class Initialized
INFO - 2024-02-27 00:55:27 --> Security Class Initialized
DEBUG - 2024-02-27 00:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 00:55:27 --> Input Class Initialized
INFO - 2024-02-27 00:55:27 --> Language Class Initialized
INFO - 2024-02-27 00:55:27 --> Loader Class Initialized
INFO - 2024-02-27 00:55:27 --> Helper loaded: url_helper
INFO - 2024-02-27 00:55:27 --> Helper loaded: file_helper
INFO - 2024-02-27 00:55:27 --> Helper loaded: security_helper
INFO - 2024-02-27 00:55:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 00:55:27 --> Database Driver Class Initialized
INFO - 2024-02-27 00:55:27 --> Email Class Initialized
DEBUG - 2024-02-27 00:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 00:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 00:55:27 --> Helper loaded: form_helper
INFO - 2024-02-27 00:55:27 --> Form Validation Class Initialized
INFO - 2024-02-27 00:55:27 --> Controller Class Initialized
INFO - 2024-02-27 00:55:27 --> Model "User_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 00:55:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 00:55:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 00:55:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 00:55:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 00:55:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 00:55:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-27 00:55:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 00:55:27 --> Final output sent to browser
DEBUG - 2024-02-27 00:55:27 --> Total execution time: 0.0512
INFO - 2024-02-27 01:14:44 --> Config Class Initialized
INFO - 2024-02-27 01:14:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:14:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:14:44 --> Utf8 Class Initialized
INFO - 2024-02-27 01:14:44 --> URI Class Initialized
INFO - 2024-02-27 01:14:44 --> Router Class Initialized
INFO - 2024-02-27 01:14:44 --> Output Class Initialized
INFO - 2024-02-27 01:14:44 --> Security Class Initialized
DEBUG - 2024-02-27 01:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:14:44 --> Input Class Initialized
INFO - 2024-02-27 01:14:44 --> Language Class Initialized
INFO - 2024-02-27 01:14:44 --> Loader Class Initialized
INFO - 2024-02-27 01:14:44 --> Helper loaded: url_helper
INFO - 2024-02-27 01:14:44 --> Helper loaded: file_helper
INFO - 2024-02-27 01:14:44 --> Helper loaded: security_helper
INFO - 2024-02-27 01:14:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:14:44 --> Database Driver Class Initialized
INFO - 2024-02-27 01:14:44 --> Email Class Initialized
DEBUG - 2024-02-27 01:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:14:44 --> Helper loaded: form_helper
INFO - 2024-02-27 01:14:44 --> Form Validation Class Initialized
INFO - 2024-02-27 01:14:44 --> Controller Class Initialized
INFO - 2024-02-27 01:14:44 --> Model "User_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:14:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-27 01:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:14:44 --> Final output sent to browser
DEBUG - 2024-02-27 01:14:44 --> Total execution time: 0.0703
INFO - 2024-02-27 01:18:32 --> Config Class Initialized
INFO - 2024-02-27 01:18:32 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:18:32 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:18:32 --> Utf8 Class Initialized
INFO - 2024-02-27 01:18:32 --> URI Class Initialized
INFO - 2024-02-27 01:18:32 --> Router Class Initialized
INFO - 2024-02-27 01:18:32 --> Output Class Initialized
INFO - 2024-02-27 01:18:32 --> Security Class Initialized
DEBUG - 2024-02-27 01:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:18:32 --> Input Class Initialized
INFO - 2024-02-27 01:18:32 --> Language Class Initialized
INFO - 2024-02-27 01:18:32 --> Loader Class Initialized
INFO - 2024-02-27 01:18:32 --> Helper loaded: url_helper
INFO - 2024-02-27 01:18:32 --> Helper loaded: file_helper
INFO - 2024-02-27 01:18:32 --> Helper loaded: security_helper
INFO - 2024-02-27 01:18:32 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:18:32 --> Database Driver Class Initialized
INFO - 2024-02-27 01:18:32 --> Email Class Initialized
DEBUG - 2024-02-27 01:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:18:32 --> Helper loaded: form_helper
INFO - 2024-02-27 01:18:32 --> Form Validation Class Initialized
INFO - 2024-02-27 01:18:32 --> Controller Class Initialized
INFO - 2024-02-27 01:18:32 --> Model "User_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:18:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:18:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:18:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:18:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:18:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:18:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 01:18:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:18:32 --> Final output sent to browser
DEBUG - 2024-02-27 01:18:32 --> Total execution time: 0.0774
INFO - 2024-02-27 01:18:33 --> Config Class Initialized
INFO - 2024-02-27 01:18:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:18:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:18:33 --> Utf8 Class Initialized
INFO - 2024-02-27 01:18:33 --> URI Class Initialized
INFO - 2024-02-27 01:18:33 --> Router Class Initialized
INFO - 2024-02-27 01:18:33 --> Output Class Initialized
INFO - 2024-02-27 01:18:33 --> Security Class Initialized
DEBUG - 2024-02-27 01:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:18:33 --> Input Class Initialized
INFO - 2024-02-27 01:18:33 --> Language Class Initialized
INFO - 2024-02-27 01:18:33 --> Loader Class Initialized
INFO - 2024-02-27 01:18:33 --> Helper loaded: url_helper
INFO - 2024-02-27 01:18:33 --> Helper loaded: file_helper
INFO - 2024-02-27 01:18:33 --> Helper loaded: security_helper
INFO - 2024-02-27 01:18:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:18:33 --> Database Driver Class Initialized
INFO - 2024-02-27 01:18:33 --> Email Class Initialized
DEBUG - 2024-02-27 01:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:18:33 --> Helper loaded: form_helper
INFO - 2024-02-27 01:18:33 --> Form Validation Class Initialized
INFO - 2024-02-27 01:18:33 --> Controller Class Initialized
INFO - 2024-02-27 01:18:33 --> Model "User_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:18:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:18:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:18:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:18:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:18:33 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 01:18:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:18:33 --> Final output sent to browser
DEBUG - 2024-02-27 01:18:33 --> Total execution time: 0.0806
INFO - 2024-02-27 01:18:35 --> Config Class Initialized
INFO - 2024-02-27 01:18:35 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:18:35 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:18:35 --> Utf8 Class Initialized
INFO - 2024-02-27 01:18:35 --> URI Class Initialized
INFO - 2024-02-27 01:18:35 --> Router Class Initialized
INFO - 2024-02-27 01:18:35 --> Output Class Initialized
INFO - 2024-02-27 01:18:35 --> Security Class Initialized
DEBUG - 2024-02-27 01:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:18:35 --> Input Class Initialized
INFO - 2024-02-27 01:18:35 --> Language Class Initialized
INFO - 2024-02-27 01:18:35 --> Loader Class Initialized
INFO - 2024-02-27 01:18:35 --> Helper loaded: url_helper
INFO - 2024-02-27 01:18:35 --> Helper loaded: file_helper
INFO - 2024-02-27 01:18:35 --> Helper loaded: security_helper
INFO - 2024-02-27 01:18:35 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:18:35 --> Database Driver Class Initialized
INFO - 2024-02-27 01:18:35 --> Email Class Initialized
DEBUG - 2024-02-27 01:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:18:35 --> Helper loaded: form_helper
INFO - 2024-02-27 01:18:35 --> Form Validation Class Initialized
INFO - 2024-02-27 01:18:35 --> Controller Class Initialized
INFO - 2024-02-27 01:18:35 --> Model "User_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:18:35 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:18:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-27 01:18:35 --> Severity: error --> Exception: Call to undefined method Pesanan_model::option_tahun() C:\xampp\htdocs\simba\application\controllers\Report.php 876
INFO - 2024-02-27 01:19:09 --> Config Class Initialized
INFO - 2024-02-27 01:19:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:19:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:19:09 --> Utf8 Class Initialized
INFO - 2024-02-27 01:19:09 --> URI Class Initialized
INFO - 2024-02-27 01:19:09 --> Router Class Initialized
INFO - 2024-02-27 01:19:09 --> Output Class Initialized
INFO - 2024-02-27 01:19:09 --> Security Class Initialized
DEBUG - 2024-02-27 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:19:09 --> Input Class Initialized
INFO - 2024-02-27 01:19:09 --> Language Class Initialized
INFO - 2024-02-27 01:19:09 --> Loader Class Initialized
INFO - 2024-02-27 01:19:09 --> Helper loaded: url_helper
INFO - 2024-02-27 01:19:09 --> Helper loaded: file_helper
INFO - 2024-02-27 01:19:09 --> Helper loaded: security_helper
INFO - 2024-02-27 01:19:09 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:19:09 --> Database Driver Class Initialized
INFO - 2024-02-27 01:19:09 --> Email Class Initialized
DEBUG - 2024-02-27 01:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:19:09 --> Helper loaded: form_helper
INFO - 2024-02-27 01:19:09 --> Form Validation Class Initialized
INFO - 2024-02-27 01:19:09 --> Controller Class Initialized
INFO - 2024-02-27 01:19:09 --> Model "User_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:19:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:19:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-27 01:19:09 --> Query error: Unknown column 'tanggal_surat' in 'field list' - Invalid query: SELECT YEAR(tanggal_surat) AS tahun
FROM `tbl_faktur`
GROUP BY YEAR(tanggal_surat)
ORDER BY YEAR(tanggal_surat)
INFO - 2024-02-27 01:19:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-02-27 01:19:19 --> Config Class Initialized
INFO - 2024-02-27 01:19:19 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:19:19 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:19:19 --> Utf8 Class Initialized
INFO - 2024-02-27 01:19:19 --> URI Class Initialized
INFO - 2024-02-27 01:19:19 --> Router Class Initialized
INFO - 2024-02-27 01:19:19 --> Output Class Initialized
INFO - 2024-02-27 01:19:19 --> Security Class Initialized
DEBUG - 2024-02-27 01:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:19:19 --> Input Class Initialized
INFO - 2024-02-27 01:19:19 --> Language Class Initialized
INFO - 2024-02-27 01:19:19 --> Loader Class Initialized
INFO - 2024-02-27 01:19:19 --> Helper loaded: url_helper
INFO - 2024-02-27 01:19:19 --> Helper loaded: file_helper
INFO - 2024-02-27 01:19:19 --> Helper loaded: security_helper
INFO - 2024-02-27 01:19:19 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:19:19 --> Database Driver Class Initialized
INFO - 2024-02-27 01:19:19 --> Email Class Initialized
DEBUG - 2024-02-27 01:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:19:19 --> Helper loaded: form_helper
INFO - 2024-02-27 01:19:19 --> Form Validation Class Initialized
INFO - 2024-02-27 01:19:19 --> Controller Class Initialized
INFO - 2024-02-27 01:19:19 --> Model "User_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:19:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:19:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:19:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:19:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:19:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-27 01:19:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\report\cetakpesanan.php 112
INFO - 2024-02-27 01:21:02 --> Config Class Initialized
INFO - 2024-02-27 01:21:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:21:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:21:02 --> Utf8 Class Initialized
INFO - 2024-02-27 01:21:02 --> URI Class Initialized
INFO - 2024-02-27 01:21:02 --> Router Class Initialized
INFO - 2024-02-27 01:21:02 --> Output Class Initialized
INFO - 2024-02-27 01:21:02 --> Security Class Initialized
DEBUG - 2024-02-27 01:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:21:02 --> Input Class Initialized
INFO - 2024-02-27 01:21:02 --> Language Class Initialized
INFO - 2024-02-27 01:21:02 --> Loader Class Initialized
INFO - 2024-02-27 01:21:02 --> Helper loaded: url_helper
INFO - 2024-02-27 01:21:02 --> Helper loaded: file_helper
INFO - 2024-02-27 01:21:02 --> Helper loaded: security_helper
INFO - 2024-02-27 01:21:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:21:02 --> Database Driver Class Initialized
INFO - 2024-02-27 01:21:02 --> Email Class Initialized
DEBUG - 2024-02-27 01:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:21:02 --> Helper loaded: form_helper
INFO - 2024-02-27 01:21:02 --> Form Validation Class Initialized
INFO - 2024-02-27 01:21:02 --> Controller Class Initialized
INFO - 2024-02-27 01:21:02 --> Model "User_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:21:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:21:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:21:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:21:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:21:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-27 01:21:02 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\report\cetakpesanan.php 132
INFO - 2024-02-27 01:21:03 --> Config Class Initialized
INFO - 2024-02-27 01:21:03 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:21:03 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:21:03 --> Utf8 Class Initialized
INFO - 2024-02-27 01:21:03 --> URI Class Initialized
INFO - 2024-02-27 01:21:03 --> Router Class Initialized
INFO - 2024-02-27 01:21:03 --> Output Class Initialized
INFO - 2024-02-27 01:21:03 --> Security Class Initialized
DEBUG - 2024-02-27 01:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:21:03 --> Input Class Initialized
INFO - 2024-02-27 01:21:03 --> Language Class Initialized
INFO - 2024-02-27 01:21:03 --> Loader Class Initialized
INFO - 2024-02-27 01:21:03 --> Helper loaded: url_helper
INFO - 2024-02-27 01:21:03 --> Helper loaded: file_helper
INFO - 2024-02-27 01:21:03 --> Helper loaded: security_helper
INFO - 2024-02-27 01:21:03 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:21:03 --> Database Driver Class Initialized
INFO - 2024-02-27 01:21:03 --> Email Class Initialized
DEBUG - 2024-02-27 01:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:21:03 --> Helper loaded: form_helper
INFO - 2024-02-27 01:21:03 --> Form Validation Class Initialized
INFO - 2024-02-27 01:21:03 --> Controller Class Initialized
INFO - 2024-02-27 01:21:03 --> Model "User_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:21:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:21:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:21:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:21:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-27 01:21:03 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\simba\application\views\report\cetakpesanan.php 132
INFO - 2024-02-27 01:21:12 --> Config Class Initialized
INFO - 2024-02-27 01:21:12 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:21:12 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:21:12 --> Utf8 Class Initialized
INFO - 2024-02-27 01:21:12 --> URI Class Initialized
INFO - 2024-02-27 01:21:12 --> Router Class Initialized
INFO - 2024-02-27 01:21:12 --> Output Class Initialized
INFO - 2024-02-27 01:21:12 --> Security Class Initialized
DEBUG - 2024-02-27 01:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:21:12 --> Input Class Initialized
INFO - 2024-02-27 01:21:12 --> Language Class Initialized
INFO - 2024-02-27 01:21:12 --> Loader Class Initialized
INFO - 2024-02-27 01:21:12 --> Helper loaded: url_helper
INFO - 2024-02-27 01:21:12 --> Helper loaded: file_helper
INFO - 2024-02-27 01:21:12 --> Helper loaded: security_helper
INFO - 2024-02-27 01:21:12 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:21:12 --> Database Driver Class Initialized
INFO - 2024-02-27 01:21:12 --> Email Class Initialized
DEBUG - 2024-02-27 01:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:21:12 --> Helper loaded: form_helper
INFO - 2024-02-27 01:21:12 --> Form Validation Class Initialized
INFO - 2024-02-27 01:21:12 --> Controller Class Initialized
INFO - 2024-02-27 01:21:12 --> Model "User_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:21:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:21:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:21:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:21:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:21:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:21:12 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:21:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:21:12 --> Final output sent to browser
DEBUG - 2024-02-27 01:21:12 --> Total execution time: 0.0655
INFO - 2024-02-27 01:21:33 --> Config Class Initialized
INFO - 2024-02-27 01:21:33 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:21:33 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:21:33 --> Utf8 Class Initialized
INFO - 2024-02-27 01:21:33 --> URI Class Initialized
INFO - 2024-02-27 01:21:33 --> Router Class Initialized
INFO - 2024-02-27 01:21:33 --> Output Class Initialized
INFO - 2024-02-27 01:21:33 --> Security Class Initialized
DEBUG - 2024-02-27 01:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:21:33 --> Input Class Initialized
INFO - 2024-02-27 01:21:33 --> Language Class Initialized
INFO - 2024-02-27 01:21:33 --> Loader Class Initialized
INFO - 2024-02-27 01:21:33 --> Helper loaded: url_helper
INFO - 2024-02-27 01:21:33 --> Helper loaded: file_helper
INFO - 2024-02-27 01:21:33 --> Helper loaded: security_helper
INFO - 2024-02-27 01:21:33 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:21:33 --> Database Driver Class Initialized
INFO - 2024-02-27 01:21:34 --> Email Class Initialized
DEBUG - 2024-02-27 01:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:21:34 --> Helper loaded: form_helper
INFO - 2024-02-27 01:21:34 --> Form Validation Class Initialized
INFO - 2024-02-27 01:21:34 --> Controller Class Initialized
INFO - 2024-02-27 01:21:34 --> Model "User_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:21:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:21:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-27 01:21:34 --> Severity: error --> Exception: Call to undefined method Pesanan_model::view_all_tempo() C:\xampp\htdocs\simba\application\controllers\Report.php 936
INFO - 2024-02-27 01:21:36 --> Config Class Initialized
INFO - 2024-02-27 01:21:36 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:21:36 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:21:36 --> Utf8 Class Initialized
INFO - 2024-02-27 01:21:36 --> URI Class Initialized
INFO - 2024-02-27 01:21:36 --> Router Class Initialized
INFO - 2024-02-27 01:21:36 --> Output Class Initialized
INFO - 2024-02-27 01:21:36 --> Security Class Initialized
DEBUG - 2024-02-27 01:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:21:36 --> Input Class Initialized
INFO - 2024-02-27 01:21:36 --> Language Class Initialized
INFO - 2024-02-27 01:21:36 --> Loader Class Initialized
INFO - 2024-02-27 01:21:36 --> Helper loaded: url_helper
INFO - 2024-02-27 01:21:36 --> Helper loaded: file_helper
INFO - 2024-02-27 01:21:36 --> Helper loaded: security_helper
INFO - 2024-02-27 01:21:36 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:21:36 --> Database Driver Class Initialized
INFO - 2024-02-27 01:21:36 --> Email Class Initialized
DEBUG - 2024-02-27 01:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:21:36 --> Helper loaded: form_helper
INFO - 2024-02-27 01:21:36 --> Form Validation Class Initialized
INFO - 2024-02-27 01:21:36 --> Controller Class Initialized
INFO - 2024-02-27 01:21:36 --> Model "User_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:21:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:21:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:21:36 --> Final output sent to browser
DEBUG - 2024-02-27 01:21:36 --> Total execution time: 0.0575
INFO - 2024-02-27 01:22:08 --> Config Class Initialized
INFO - 2024-02-27 01:22:08 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:22:08 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:22:08 --> Utf8 Class Initialized
INFO - 2024-02-27 01:22:08 --> URI Class Initialized
INFO - 2024-02-27 01:22:08 --> Router Class Initialized
INFO - 2024-02-27 01:22:08 --> Output Class Initialized
INFO - 2024-02-27 01:22:08 --> Security Class Initialized
DEBUG - 2024-02-27 01:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:22:08 --> Input Class Initialized
INFO - 2024-02-27 01:22:08 --> Language Class Initialized
INFO - 2024-02-27 01:22:08 --> Loader Class Initialized
INFO - 2024-02-27 01:22:08 --> Helper loaded: url_helper
INFO - 2024-02-27 01:22:08 --> Helper loaded: file_helper
INFO - 2024-02-27 01:22:08 --> Helper loaded: security_helper
INFO - 2024-02-27 01:22:08 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:22:08 --> Database Driver Class Initialized
INFO - 2024-02-27 01:22:08 --> Email Class Initialized
DEBUG - 2024-02-27 01:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:22:08 --> Helper loaded: form_helper
INFO - 2024-02-27 01:22:08 --> Form Validation Class Initialized
INFO - 2024-02-27 01:22:08 --> Controller Class Initialized
INFO - 2024-02-27 01:22:08 --> Model "User_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:22:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:22:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:22:08 --> Final output sent to browser
DEBUG - 2024-02-27 01:22:08 --> Total execution time: 0.0643
INFO - 2024-02-27 01:22:09 --> Config Class Initialized
INFO - 2024-02-27 01:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:22:09 --> Utf8 Class Initialized
INFO - 2024-02-27 01:22:09 --> URI Class Initialized
INFO - 2024-02-27 01:22:09 --> Router Class Initialized
INFO - 2024-02-27 01:22:09 --> Output Class Initialized
INFO - 2024-02-27 01:22:09 --> Security Class Initialized
DEBUG - 2024-02-27 01:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:22:09 --> Input Class Initialized
INFO - 2024-02-27 01:22:09 --> Language Class Initialized
INFO - 2024-02-27 01:22:09 --> Loader Class Initialized
INFO - 2024-02-27 01:22:09 --> Helper loaded: url_helper
INFO - 2024-02-27 01:22:09 --> Helper loaded: file_helper
INFO - 2024-02-27 01:22:09 --> Helper loaded: security_helper
INFO - 2024-02-27 01:22:09 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:22:09 --> Database Driver Class Initialized
INFO - 2024-02-27 01:22:09 --> Email Class Initialized
DEBUG - 2024-02-27 01:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:22:09 --> Helper loaded: form_helper
INFO - 2024-02-27 01:22:09 --> Form Validation Class Initialized
INFO - 2024-02-27 01:22:09 --> Controller Class Initialized
INFO - 2024-02-27 01:22:09 --> Model "User_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:22:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:22:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:22:09 --> Final output sent to browser
DEBUG - 2024-02-27 01:22:09 --> Total execution time: 0.1308
INFO - 2024-02-27 01:24:24 --> Config Class Initialized
INFO - 2024-02-27 01:24:24 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:24:24 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:24:24 --> Utf8 Class Initialized
INFO - 2024-02-27 01:24:24 --> URI Class Initialized
INFO - 2024-02-27 01:24:24 --> Router Class Initialized
INFO - 2024-02-27 01:24:24 --> Output Class Initialized
INFO - 2024-02-27 01:24:24 --> Security Class Initialized
DEBUG - 2024-02-27 01:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:24:24 --> Input Class Initialized
INFO - 2024-02-27 01:24:24 --> Language Class Initialized
INFO - 2024-02-27 01:24:24 --> Loader Class Initialized
INFO - 2024-02-27 01:24:24 --> Helper loaded: url_helper
INFO - 2024-02-27 01:24:24 --> Helper loaded: file_helper
INFO - 2024-02-27 01:24:24 --> Helper loaded: security_helper
INFO - 2024-02-27 01:24:24 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:24:24 --> Database Driver Class Initialized
INFO - 2024-02-27 01:24:24 --> Email Class Initialized
DEBUG - 2024-02-27 01:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:24:24 --> Helper loaded: form_helper
INFO - 2024-02-27 01:24:24 --> Form Validation Class Initialized
INFO - 2024-02-27 01:24:24 --> Controller Class Initialized
INFO - 2024-02-27 01:24:24 --> Model "User_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:24:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:24:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:24:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:24:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:24:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:24:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:24:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:24:24 --> Final output sent to browser
DEBUG - 2024-02-27 01:24:24 --> Total execution time: 0.0632
INFO - 2024-02-27 01:24:25 --> Config Class Initialized
INFO - 2024-02-27 01:24:25 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:24:25 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:24:25 --> Utf8 Class Initialized
INFO - 2024-02-27 01:24:25 --> URI Class Initialized
INFO - 2024-02-27 01:24:25 --> Router Class Initialized
INFO - 2024-02-27 01:24:25 --> Output Class Initialized
INFO - 2024-02-27 01:24:25 --> Security Class Initialized
DEBUG - 2024-02-27 01:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:24:25 --> Input Class Initialized
INFO - 2024-02-27 01:24:25 --> Language Class Initialized
INFO - 2024-02-27 01:24:25 --> Loader Class Initialized
INFO - 2024-02-27 01:24:25 --> Helper loaded: url_helper
INFO - 2024-02-27 01:24:25 --> Helper loaded: file_helper
INFO - 2024-02-27 01:24:25 --> Helper loaded: security_helper
INFO - 2024-02-27 01:24:25 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:24:25 --> Database Driver Class Initialized
INFO - 2024-02-27 01:24:25 --> Email Class Initialized
DEBUG - 2024-02-27 01:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:24:25 --> Helper loaded: form_helper
INFO - 2024-02-27 01:24:25 --> Form Validation Class Initialized
INFO - 2024-02-27 01:24:25 --> Controller Class Initialized
INFO - 2024-02-27 01:24:25 --> Model "User_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:24:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:24:25 --> Final output sent to browser
DEBUG - 2024-02-27 01:24:25 --> Total execution time: 0.1511
INFO - 2024-02-27 01:26:04 --> Config Class Initialized
INFO - 2024-02-27 01:26:04 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:26:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:26:05 --> Utf8 Class Initialized
INFO - 2024-02-27 01:26:05 --> URI Class Initialized
INFO - 2024-02-27 01:26:05 --> Router Class Initialized
INFO - 2024-02-27 01:26:05 --> Output Class Initialized
INFO - 2024-02-27 01:26:05 --> Security Class Initialized
DEBUG - 2024-02-27 01:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:26:05 --> Input Class Initialized
INFO - 2024-02-27 01:26:05 --> Language Class Initialized
INFO - 2024-02-27 01:26:05 --> Loader Class Initialized
INFO - 2024-02-27 01:26:05 --> Helper loaded: url_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: file_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: security_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:26:05 --> Database Driver Class Initialized
INFO - 2024-02-27 01:26:05 --> Email Class Initialized
DEBUG - 2024-02-27 01:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:26:05 --> Helper loaded: form_helper
INFO - 2024-02-27 01:26:05 --> Form Validation Class Initialized
INFO - 2024-02-27 01:26:05 --> Controller Class Initialized
INFO - 2024-02-27 01:26:05 --> Model "User_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:26:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:26:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:26:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:26:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:26:05 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:26:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:26:05 --> Final output sent to browser
DEBUG - 2024-02-27 01:26:05 --> Total execution time: 0.0681
INFO - 2024-02-27 01:26:05 --> Config Class Initialized
INFO - 2024-02-27 01:26:05 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:26:05 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:26:05 --> Utf8 Class Initialized
INFO - 2024-02-27 01:26:05 --> URI Class Initialized
INFO - 2024-02-27 01:26:05 --> Router Class Initialized
INFO - 2024-02-27 01:26:05 --> Output Class Initialized
INFO - 2024-02-27 01:26:05 --> Security Class Initialized
DEBUG - 2024-02-27 01:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:26:05 --> Input Class Initialized
INFO - 2024-02-27 01:26:05 --> Language Class Initialized
INFO - 2024-02-27 01:26:05 --> Loader Class Initialized
INFO - 2024-02-27 01:26:05 --> Helper loaded: url_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: file_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: security_helper
INFO - 2024-02-27 01:26:05 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:26:05 --> Database Driver Class Initialized
INFO - 2024-02-27 01:26:05 --> Email Class Initialized
DEBUG - 2024-02-27 01:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:26:05 --> Helper loaded: form_helper
INFO - 2024-02-27 01:26:05 --> Form Validation Class Initialized
INFO - 2024-02-27 01:26:05 --> Controller Class Initialized
INFO - 2024-02-27 01:26:05 --> Model "User_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:26:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:26:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:26:05 --> Final output sent to browser
DEBUG - 2024-02-27 01:26:05 --> Total execution time: 0.1684
INFO - 2024-02-27 01:26:17 --> Config Class Initialized
INFO - 2024-02-27 01:26:17 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:26:17 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:26:17 --> Utf8 Class Initialized
INFO - 2024-02-27 01:26:17 --> URI Class Initialized
INFO - 2024-02-27 01:26:17 --> Router Class Initialized
INFO - 2024-02-27 01:26:17 --> Output Class Initialized
INFO - 2024-02-27 01:26:17 --> Security Class Initialized
DEBUG - 2024-02-27 01:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:26:17 --> Input Class Initialized
INFO - 2024-02-27 01:26:17 --> Language Class Initialized
INFO - 2024-02-27 01:26:17 --> Loader Class Initialized
INFO - 2024-02-27 01:26:17 --> Helper loaded: url_helper
INFO - 2024-02-27 01:26:17 --> Helper loaded: file_helper
INFO - 2024-02-27 01:26:17 --> Helper loaded: security_helper
INFO - 2024-02-27 01:26:17 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:26:17 --> Database Driver Class Initialized
INFO - 2024-02-27 01:26:17 --> Email Class Initialized
DEBUG - 2024-02-27 01:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:26:17 --> Helper loaded: form_helper
INFO - 2024-02-27 01:26:17 --> Form Validation Class Initialized
INFO - 2024-02-27 01:26:17 --> Controller Class Initialized
INFO - 2024-02-27 01:26:17 --> Model "User_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:26:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:26:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:26:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:26:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:26:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:26:17 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-27 01:26:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:26:17 --> Final output sent to browser
DEBUG - 2024-02-27 01:26:17 --> Total execution time: 0.0659
INFO - 2024-02-27 01:26:27 --> Config Class Initialized
INFO - 2024-02-27 01:26:27 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:26:27 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:26:27 --> Utf8 Class Initialized
INFO - 2024-02-27 01:26:27 --> URI Class Initialized
INFO - 2024-02-27 01:26:27 --> Router Class Initialized
INFO - 2024-02-27 01:26:27 --> Output Class Initialized
INFO - 2024-02-27 01:26:27 --> Security Class Initialized
DEBUG - 2024-02-27 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:26:27 --> Input Class Initialized
INFO - 2024-02-27 01:26:27 --> Language Class Initialized
INFO - 2024-02-27 01:26:27 --> Loader Class Initialized
INFO - 2024-02-27 01:26:27 --> Helper loaded: url_helper
INFO - 2024-02-27 01:26:27 --> Helper loaded: file_helper
INFO - 2024-02-27 01:26:27 --> Helper loaded: security_helper
INFO - 2024-02-27 01:26:27 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:26:27 --> Database Driver Class Initialized
INFO - 2024-02-27 01:26:27 --> Email Class Initialized
DEBUG - 2024-02-27 01:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:26:27 --> Helper loaded: form_helper
INFO - 2024-02-27 01:26:27 --> Form Validation Class Initialized
INFO - 2024-02-27 01:26:27 --> Controller Class Initialized
INFO - 2024-02-27 01:26:27 --> Model "User_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:26:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:26:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:26:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:26:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:26:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:26:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-27 01:26:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:26:27 --> Final output sent to browser
DEBUG - 2024-02-27 01:26:27 --> Total execution time: 0.0721
INFO - 2024-02-27 01:27:54 --> Config Class Initialized
INFO - 2024-02-27 01:27:54 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:27:54 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:27:54 --> Utf8 Class Initialized
INFO - 2024-02-27 01:27:54 --> URI Class Initialized
INFO - 2024-02-27 01:27:54 --> Router Class Initialized
INFO - 2024-02-27 01:27:54 --> Output Class Initialized
INFO - 2024-02-27 01:27:54 --> Security Class Initialized
DEBUG - 2024-02-27 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:27:54 --> Input Class Initialized
INFO - 2024-02-27 01:27:54 --> Language Class Initialized
INFO - 2024-02-27 01:27:54 --> Loader Class Initialized
INFO - 2024-02-27 01:27:54 --> Helper loaded: url_helper
INFO - 2024-02-27 01:27:54 --> Helper loaded: file_helper
INFO - 2024-02-27 01:27:54 --> Helper loaded: security_helper
INFO - 2024-02-27 01:27:54 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:27:54 --> Database Driver Class Initialized
INFO - 2024-02-27 01:27:54 --> Email Class Initialized
DEBUG - 2024-02-27 01:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:27:54 --> Helper loaded: form_helper
INFO - 2024-02-27 01:27:54 --> Form Validation Class Initialized
INFO - 2024-02-27 01:27:54 --> Controller Class Initialized
INFO - 2024-02-27 01:27:54 --> Model "User_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:27:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:27:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:27:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:27:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:27:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:27:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-27 01:27:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:27:54 --> Final output sent to browser
DEBUG - 2024-02-27 01:27:54 --> Total execution time: 0.0653
INFO - 2024-02-27 01:27:57 --> Config Class Initialized
INFO - 2024-02-27 01:27:57 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:27:57 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:27:57 --> Utf8 Class Initialized
INFO - 2024-02-27 01:27:57 --> URI Class Initialized
INFO - 2024-02-27 01:27:57 --> Router Class Initialized
INFO - 2024-02-27 01:27:57 --> Output Class Initialized
INFO - 2024-02-27 01:27:57 --> Security Class Initialized
DEBUG - 2024-02-27 01:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:27:57 --> Input Class Initialized
INFO - 2024-02-27 01:27:57 --> Language Class Initialized
INFO - 2024-02-27 01:27:57 --> Loader Class Initialized
INFO - 2024-02-27 01:27:57 --> Helper loaded: url_helper
INFO - 2024-02-27 01:27:57 --> Helper loaded: file_helper
INFO - 2024-02-27 01:27:57 --> Helper loaded: security_helper
INFO - 2024-02-27 01:27:57 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:27:57 --> Database Driver Class Initialized
INFO - 2024-02-27 01:27:57 --> Email Class Initialized
DEBUG - 2024-02-27 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:27:57 --> Helper loaded: form_helper
INFO - 2024-02-27 01:27:57 --> Form Validation Class Initialized
INFO - 2024-02-27 01:27:57 --> Controller Class Initialized
INFO - 2024-02-27 01:27:57 --> Model "User_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:27:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:27:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:27:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:27:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:27:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:27:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-27 01:27:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:27:57 --> Final output sent to browser
DEBUG - 2024-02-27 01:27:57 --> Total execution time: 0.0679
INFO - 2024-02-27 01:27:58 --> Config Class Initialized
INFO - 2024-02-27 01:27:58 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:27:58 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:27:58 --> Utf8 Class Initialized
INFO - 2024-02-27 01:27:58 --> URI Class Initialized
INFO - 2024-02-27 01:27:58 --> Router Class Initialized
INFO - 2024-02-27 01:27:58 --> Output Class Initialized
INFO - 2024-02-27 01:27:58 --> Security Class Initialized
DEBUG - 2024-02-27 01:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:27:58 --> Input Class Initialized
INFO - 2024-02-27 01:27:58 --> Language Class Initialized
INFO - 2024-02-27 01:27:58 --> Loader Class Initialized
INFO - 2024-02-27 01:27:58 --> Helper loaded: url_helper
INFO - 2024-02-27 01:27:58 --> Helper loaded: file_helper
INFO - 2024-02-27 01:27:58 --> Helper loaded: security_helper
INFO - 2024-02-27 01:27:58 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:27:58 --> Database Driver Class Initialized
INFO - 2024-02-27 01:27:58 --> Email Class Initialized
DEBUG - 2024-02-27 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:27:58 --> Helper loaded: form_helper
INFO - 2024-02-27 01:27:58 --> Form Validation Class Initialized
INFO - 2024-02-27 01:27:58 --> Controller Class Initialized
INFO - 2024-02-27 01:27:58 --> Model "User_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:27:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:27:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 01:27:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:27:58 --> Final output sent to browser
DEBUG - 2024-02-27 01:27:58 --> Total execution time: 0.0753
INFO - 2024-02-27 01:27:59 --> Config Class Initialized
INFO - 2024-02-27 01:27:59 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:27:59 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:27:59 --> Utf8 Class Initialized
INFO - 2024-02-27 01:27:59 --> URI Class Initialized
INFO - 2024-02-27 01:27:59 --> Router Class Initialized
INFO - 2024-02-27 01:27:59 --> Output Class Initialized
INFO - 2024-02-27 01:27:59 --> Security Class Initialized
DEBUG - 2024-02-27 01:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:27:59 --> Input Class Initialized
INFO - 2024-02-27 01:27:59 --> Language Class Initialized
INFO - 2024-02-27 01:27:59 --> Loader Class Initialized
INFO - 2024-02-27 01:27:59 --> Helper loaded: url_helper
INFO - 2024-02-27 01:27:59 --> Helper loaded: file_helper
INFO - 2024-02-27 01:27:59 --> Helper loaded: security_helper
INFO - 2024-02-27 01:27:59 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:27:59 --> Database Driver Class Initialized
INFO - 2024-02-27 01:27:59 --> Email Class Initialized
DEBUG - 2024-02-27 01:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:27:59 --> Helper loaded: form_helper
INFO - 2024-02-27 01:27:59 --> Form Validation Class Initialized
INFO - 2024-02-27 01:27:59 --> Controller Class Initialized
INFO - 2024-02-27 01:27:59 --> Model "User_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:27:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:27:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:27:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:27:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:27:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:27:59 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-02-27 01:28:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:00 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:00 --> Total execution time: 0.0750
INFO - 2024-02-27 01:28:01 --> Config Class Initialized
INFO - 2024-02-27 01:28:01 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:01 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:01 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:01 --> URI Class Initialized
INFO - 2024-02-27 01:28:01 --> Router Class Initialized
INFO - 2024-02-27 01:28:01 --> Output Class Initialized
INFO - 2024-02-27 01:28:01 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:01 --> Input Class Initialized
INFO - 2024-02-27 01:28:01 --> Language Class Initialized
INFO - 2024-02-27 01:28:01 --> Loader Class Initialized
INFO - 2024-02-27 01:28:01 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:01 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:01 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:01 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:01 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:01 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:01 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:01 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:01 --> Controller Class Initialized
INFO - 2024-02-27 01:28:01 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:01 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-27 01:28:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:01 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:01 --> Total execution time: 0.0555
INFO - 2024-02-27 01:28:02 --> Config Class Initialized
INFO - 2024-02-27 01:28:02 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:02 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:02 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:02 --> URI Class Initialized
INFO - 2024-02-27 01:28:02 --> Router Class Initialized
INFO - 2024-02-27 01:28:02 --> Output Class Initialized
INFO - 2024-02-27 01:28:02 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:02 --> Input Class Initialized
INFO - 2024-02-27 01:28:02 --> Language Class Initialized
INFO - 2024-02-27 01:28:02 --> Loader Class Initialized
INFO - 2024-02-27 01:28:02 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:02 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:02 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:02 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:02 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:02 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:02 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:02 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:02 --> Controller Class Initialized
INFO - 2024-02-27 01:28:02 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-27 01:28:02 --> Severity: error --> Exception: Call to undefined method Permintaan_model::option_tahun() C:\xampp\htdocs\simba\application\controllers\Report.php 695
INFO - 2024-02-27 01:28:21 --> Config Class Initialized
INFO - 2024-02-27 01:28:21 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:21 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:21 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:21 --> URI Class Initialized
INFO - 2024-02-27 01:28:21 --> Router Class Initialized
INFO - 2024-02-27 01:28:21 --> Output Class Initialized
INFO - 2024-02-27 01:28:21 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:21 --> Input Class Initialized
INFO - 2024-02-27 01:28:21 --> Language Class Initialized
INFO - 2024-02-27 01:28:21 --> Loader Class Initialized
INFO - 2024-02-27 01:28:21 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:21 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:21 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:21 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:21 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:21 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:21 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:21 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:21 --> Controller Class Initialized
INFO - 2024-02-27 01:28:21 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:21 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpermintaan.php
INFO - 2024-02-27 01:28:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:21 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:21 --> Total execution time: 0.0665
INFO - 2024-02-27 01:28:29 --> Config Class Initialized
INFO - 2024-02-27 01:28:29 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:29 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:29 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:29 --> URI Class Initialized
INFO - 2024-02-27 01:28:29 --> Router Class Initialized
INFO - 2024-02-27 01:28:29 --> Output Class Initialized
INFO - 2024-02-27 01:28:29 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:29 --> Input Class Initialized
INFO - 2024-02-27 01:28:29 --> Language Class Initialized
INFO - 2024-02-27 01:28:29 --> Loader Class Initialized
INFO - 2024-02-27 01:28:29 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:29 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:29 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:29 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:29 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:29 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:29 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:29 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:29 --> Controller Class Initialized
INFO - 2024-02-27 01:28:29 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:29 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:29 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpermintaan.php
INFO - 2024-02-27 01:28:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:29 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:29 --> Total execution time: 0.0555
INFO - 2024-02-27 01:28:31 --> Config Class Initialized
INFO - 2024-02-27 01:28:31 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:31 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:31 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:31 --> URI Class Initialized
INFO - 2024-02-27 01:28:31 --> Router Class Initialized
INFO - 2024-02-27 01:28:31 --> Output Class Initialized
INFO - 2024-02-27 01:28:31 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:31 --> Input Class Initialized
INFO - 2024-02-27 01:28:31 --> Language Class Initialized
INFO - 2024-02-27 01:28:31 --> Loader Class Initialized
INFO - 2024-02-27 01:28:31 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:31 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:31 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:31 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:31 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:31 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:31 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:31 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:31 --> Controller Class Initialized
INFO - 2024-02-27 01:28:31 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:31 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:31 --> Total execution time: 0.1687
INFO - 2024-02-27 01:28:43 --> Config Class Initialized
INFO - 2024-02-27 01:28:43 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:43 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:43 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:43 --> URI Class Initialized
INFO - 2024-02-27 01:28:43 --> Router Class Initialized
INFO - 2024-02-27 01:28:43 --> Output Class Initialized
INFO - 2024-02-27 01:28:43 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:43 --> Input Class Initialized
INFO - 2024-02-27 01:28:43 --> Language Class Initialized
INFO - 2024-02-27 01:28:43 --> Loader Class Initialized
INFO - 2024-02-27 01:28:43 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:43 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:43 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:43 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:43 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:43 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:43 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:43 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:43 --> Controller Class Initialized
INFO - 2024-02-27 01:28:43 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:43 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpermintaan.php
INFO - 2024-02-27 01:28:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:43 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:43 --> Total execution time: 0.0792
INFO - 2024-02-27 01:28:44 --> Config Class Initialized
INFO - 2024-02-27 01:28:44 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:44 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:44 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:44 --> URI Class Initialized
INFO - 2024-02-27 01:28:44 --> Router Class Initialized
INFO - 2024-02-27 01:28:44 --> Output Class Initialized
INFO - 2024-02-27 01:28:44 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:44 --> Input Class Initialized
INFO - 2024-02-27 01:28:44 --> Language Class Initialized
INFO - 2024-02-27 01:28:44 --> Loader Class Initialized
INFO - 2024-02-27 01:28:44 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:44 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:44 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:44 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:44 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:44 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:44 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:44 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:44 --> Controller Class Initialized
INFO - 2024-02-27 01:28:44 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:44 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpermintaan.php
INFO - 2024-02-27 01:28:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:44 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:44 --> Total execution time: 0.0800
INFO - 2024-02-27 01:28:49 --> Config Class Initialized
INFO - 2024-02-27 01:28:49 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:49 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:49 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:49 --> URI Class Initialized
INFO - 2024-02-27 01:28:49 --> Router Class Initialized
INFO - 2024-02-27 01:28:49 --> Output Class Initialized
INFO - 2024-02-27 01:28:49 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:49 --> Input Class Initialized
INFO - 2024-02-27 01:28:49 --> Language Class Initialized
INFO - 2024-02-27 01:28:49 --> Loader Class Initialized
INFO - 2024-02-27 01:28:49 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:49 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:49 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:49 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:49 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:49 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:49 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:49 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:49 --> Controller Class Initialized
INFO - 2024-02-27 01:28:49 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-27 01:28:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-27 01:28:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-27 01:28:49 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpermintaan.php
INFO - 2024-02-27 01:28:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-27 01:28:49 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:49 --> Total execution time: 0.0573
INFO - 2024-02-27 01:28:51 --> Config Class Initialized
INFO - 2024-02-27 01:28:51 --> Hooks Class Initialized
DEBUG - 2024-02-27 01:28:51 --> UTF-8 Support Enabled
INFO - 2024-02-27 01:28:51 --> Utf8 Class Initialized
INFO - 2024-02-27 01:28:51 --> URI Class Initialized
INFO - 2024-02-27 01:28:51 --> Router Class Initialized
INFO - 2024-02-27 01:28:51 --> Output Class Initialized
INFO - 2024-02-27 01:28:51 --> Security Class Initialized
DEBUG - 2024-02-27 01:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 01:28:51 --> Input Class Initialized
INFO - 2024-02-27 01:28:51 --> Language Class Initialized
INFO - 2024-02-27 01:28:51 --> Loader Class Initialized
INFO - 2024-02-27 01:28:51 --> Helper loaded: url_helper
INFO - 2024-02-27 01:28:51 --> Helper loaded: file_helper
INFO - 2024-02-27 01:28:51 --> Helper loaded: security_helper
INFO - 2024-02-27 01:28:51 --> Helper loaded: wpu_helper
INFO - 2024-02-27 01:28:51 --> Database Driver Class Initialized
INFO - 2024-02-27 01:28:51 --> Email Class Initialized
DEBUG - 2024-02-27 01:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-27 01:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 01:28:51 --> Helper loaded: form_helper
INFO - 2024-02-27 01:28:51 --> Form Validation Class Initialized
INFO - 2024-02-27 01:28:51 --> Controller Class Initialized
INFO - 2024-02-27 01:28:51 --> Model "User_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Faktur_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Supplier_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-27 01:28:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-27 01:28:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-27 01:28:51 --> Final output sent to browser
DEBUG - 2024-02-27 01:28:51 --> Total execution time: 0.1503
