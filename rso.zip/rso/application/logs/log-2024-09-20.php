<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-20 11:07:59 --> Config Class Initialized
INFO - 2024-09-20 11:07:59 --> Hooks Class Initialized
DEBUG - 2024-09-20 11:07:59 --> UTF-8 Support Enabled
INFO - 2024-09-20 11:07:59 --> Utf8 Class Initialized
INFO - 2024-09-20 11:07:59 --> URI Class Initialized
DEBUG - 2024-09-20 11:07:59 --> No URI present. Default controller set.
INFO - 2024-09-20 11:07:59 --> Router Class Initialized
INFO - 2024-09-20 11:07:59 --> Output Class Initialized
INFO - 2024-09-20 11:07:59 --> Security Class Initialized
DEBUG - 2024-09-20 11:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 11:07:59 --> Input Class Initialized
INFO - 2024-09-20 11:07:59 --> Language Class Initialized
INFO - 2024-09-20 11:07:59 --> Loader Class Initialized
INFO - 2024-09-20 11:07:59 --> Helper loaded: url_helper
INFO - 2024-09-20 11:07:59 --> Helper loaded: file_helper
INFO - 2024-09-20 11:07:59 --> Helper loaded: security_helper
INFO - 2024-09-20 11:07:59 --> Helper loaded: wpu_helper
INFO - 2024-09-20 11:07:59 --> Database Driver Class Initialized
