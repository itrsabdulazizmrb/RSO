<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-24 05:15:35 --> Config Class Initialized
INFO - 2024-12-24 05:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:15:35 --> Utf8 Class Initialized
INFO - 2024-12-24 05:15:35 --> URI Class Initialized
DEBUG - 2024-12-24 05:15:35 --> No URI present. Default controller set.
INFO - 2024-12-24 05:15:35 --> Router Class Initialized
INFO - 2024-12-24 05:15:35 --> Output Class Initialized
INFO - 2024-12-24 05:15:35 --> Security Class Initialized
DEBUG - 2024-12-24 05:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:15:35 --> Input Class Initialized
INFO - 2024-12-24 05:15:35 --> Language Class Initialized
INFO - 2024-12-24 05:15:35 --> Loader Class Initialized
INFO - 2024-12-24 05:15:35 --> Helper loaded: url_helper
INFO - 2024-12-24 05:15:35 --> Helper loaded: file_helper
INFO - 2024-12-24 05:15:35 --> Helper loaded: security_helper
INFO - 2024-12-24 05:15:35 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:15:35 --> Database Driver Class Initialized
ERROR - 2024-12-24 05:15:45 --> Unable to connect to the database
INFO - 2024-12-24 05:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-24 05:15:48 --> Config Class Initialized
INFO - 2024-12-24 05:15:48 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:15:48 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:15:48 --> Utf8 Class Initialized
INFO - 2024-12-24 05:15:48 --> URI Class Initialized
DEBUG - 2024-12-24 05:15:48 --> No URI present. Default controller set.
INFO - 2024-12-24 05:15:48 --> Router Class Initialized
INFO - 2024-12-24 05:15:48 --> Output Class Initialized
INFO - 2024-12-24 05:15:48 --> Security Class Initialized
DEBUG - 2024-12-24 05:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:15:48 --> Input Class Initialized
INFO - 2024-12-24 05:15:48 --> Language Class Initialized
INFO - 2024-12-24 05:15:48 --> Loader Class Initialized
INFO - 2024-12-24 05:15:48 --> Helper loaded: url_helper
INFO - 2024-12-24 05:15:48 --> Helper loaded: file_helper
INFO - 2024-12-24 05:15:48 --> Helper loaded: security_helper
INFO - 2024-12-24 05:15:48 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:15:48 --> Database Driver Class Initialized
ERROR - 2024-12-24 05:15:58 --> Unable to connect to the database
INFO - 2024-12-24 05:15:58 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-24 05:16:56 --> Config Class Initialized
INFO - 2024-12-24 05:16:56 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:16:56 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:16:56 --> Utf8 Class Initialized
INFO - 2024-12-24 05:16:56 --> URI Class Initialized
DEBUG - 2024-12-24 05:16:56 --> No URI present. Default controller set.
INFO - 2024-12-24 05:16:56 --> Router Class Initialized
INFO - 2024-12-24 05:16:56 --> Output Class Initialized
INFO - 2024-12-24 05:16:56 --> Security Class Initialized
DEBUG - 2024-12-24 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:16:56 --> Input Class Initialized
INFO - 2024-12-24 05:16:56 --> Language Class Initialized
INFO - 2024-12-24 05:16:56 --> Loader Class Initialized
INFO - 2024-12-24 05:16:56 --> Helper loaded: url_helper
INFO - 2024-12-24 05:16:56 --> Helper loaded: file_helper
INFO - 2024-12-24 05:16:56 --> Helper loaded: security_helper
INFO - 2024-12-24 05:16:56 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:16:56 --> Database Driver Class Initialized
INFO - 2024-12-24 05:16:57 --> Email Class Initialized
DEBUG - 2024-12-24 05:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:16:57 --> Helper loaded: form_helper
INFO - 2024-12-24 05:16:57 --> Form Validation Class Initialized
INFO - 2024-12-24 05:16:57 --> Controller Class Initialized
DEBUG - 2024-12-24 05:16:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:16:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 05:16:57 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 05:16:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 05:16:57 --> Final output sent to browser
DEBUG - 2024-12-24 05:16:57 --> Total execution time: 0.9827
INFO - 2024-12-24 05:17:09 --> Config Class Initialized
INFO - 2024-12-24 05:17:09 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:17:09 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:17:09 --> Utf8 Class Initialized
INFO - 2024-12-24 05:17:09 --> URI Class Initialized
INFO - 2024-12-24 05:17:09 --> Router Class Initialized
INFO - 2024-12-24 05:17:09 --> Output Class Initialized
INFO - 2024-12-24 05:17:09 --> Security Class Initialized
DEBUG - 2024-12-24 05:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:17:09 --> Input Class Initialized
INFO - 2024-12-24 05:17:09 --> Language Class Initialized
INFO - 2024-12-24 05:17:09 --> Loader Class Initialized
INFO - 2024-12-24 05:17:09 --> Helper loaded: url_helper
INFO - 2024-12-24 05:17:09 --> Helper loaded: file_helper
INFO - 2024-12-24 05:17:09 --> Helper loaded: security_helper
INFO - 2024-12-24 05:17:09 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:17:09 --> Database Driver Class Initialized
INFO - 2024-12-24 05:17:10 --> Email Class Initialized
DEBUG - 2024-12-24 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:17:10 --> Helper loaded: form_helper
INFO - 2024-12-24 05:17:10 --> Form Validation Class Initialized
INFO - 2024-12-24 05:17:10 --> Controller Class Initialized
DEBUG - 2024-12-24 05:17:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:17:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 05:17:10 --> Config Class Initialized
INFO - 2024-12-24 05:17:10 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:17:10 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:17:10 --> Utf8 Class Initialized
INFO - 2024-12-24 05:17:10 --> URI Class Initialized
INFO - 2024-12-24 05:17:10 --> Router Class Initialized
INFO - 2024-12-24 05:17:10 --> Output Class Initialized
INFO - 2024-12-24 05:17:10 --> Security Class Initialized
DEBUG - 2024-12-24 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:17:10 --> Input Class Initialized
INFO - 2024-12-24 05:17:10 --> Language Class Initialized
INFO - 2024-12-24 05:17:10 --> Loader Class Initialized
INFO - 2024-12-24 05:17:10 --> Helper loaded: url_helper
INFO - 2024-12-24 05:17:10 --> Helper loaded: file_helper
INFO - 2024-12-24 05:17:10 --> Helper loaded: security_helper
INFO - 2024-12-24 05:17:10 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:17:10 --> Database Driver Class Initialized
INFO - 2024-12-24 05:17:11 --> Email Class Initialized
DEBUG - 2024-12-24 05:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:17:11 --> Helper loaded: form_helper
INFO - 2024-12-24 05:17:11 --> Form Validation Class Initialized
INFO - 2024-12-24 05:17:11 --> Controller Class Initialized
INFO - 2024-12-24 05:17:11 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:17:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:17:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:17:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:17:12 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:17:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:17:12 --> Final output sent to browser
DEBUG - 2024-12-24 05:17:12 --> Total execution time: 2.1836
INFO - 2024-12-24 05:22:19 --> Config Class Initialized
INFO - 2024-12-24 05:22:19 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:22:19 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:22:19 --> Utf8 Class Initialized
INFO - 2024-12-24 05:22:19 --> URI Class Initialized
INFO - 2024-12-24 05:22:19 --> Router Class Initialized
INFO - 2024-12-24 05:22:19 --> Output Class Initialized
INFO - 2024-12-24 05:22:19 --> Security Class Initialized
DEBUG - 2024-12-24 05:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:22:19 --> Input Class Initialized
INFO - 2024-12-24 05:22:19 --> Language Class Initialized
INFO - 2024-12-24 05:22:19 --> Loader Class Initialized
INFO - 2024-12-24 05:22:19 --> Helper loaded: url_helper
INFO - 2024-12-24 05:22:19 --> Helper loaded: file_helper
INFO - 2024-12-24 05:22:19 --> Helper loaded: security_helper
INFO - 2024-12-24 05:22:19 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:22:19 --> Database Driver Class Initialized
INFO - 2024-12-24 05:22:20 --> Email Class Initialized
DEBUG - 2024-12-24 05:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:22:20 --> Helper loaded: form_helper
INFO - 2024-12-24 05:22:20 --> Form Validation Class Initialized
INFO - 2024-12-24 05:22:20 --> Controller Class Initialized
INFO - 2024-12-24 05:22:20 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:22:21 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:22:21 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:22:21 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:22:21 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:22:21 --> Final output sent to browser
DEBUG - 2024-12-24 05:22:21 --> Total execution time: 1.7288
INFO - 2024-12-24 05:22:57 --> Config Class Initialized
INFO - 2024-12-24 05:22:57 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:22:57 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:22:57 --> Utf8 Class Initialized
INFO - 2024-12-24 05:22:57 --> URI Class Initialized
INFO - 2024-12-24 05:22:57 --> Router Class Initialized
INFO - 2024-12-24 05:22:57 --> Output Class Initialized
INFO - 2024-12-24 05:22:57 --> Security Class Initialized
DEBUG - 2024-12-24 05:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:22:57 --> Input Class Initialized
INFO - 2024-12-24 05:22:57 --> Language Class Initialized
INFO - 2024-12-24 05:22:57 --> Loader Class Initialized
INFO - 2024-12-24 05:22:57 --> Helper loaded: url_helper
INFO - 2024-12-24 05:22:57 --> Helper loaded: file_helper
INFO - 2024-12-24 05:22:57 --> Helper loaded: security_helper
INFO - 2024-12-24 05:22:57 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:22:57 --> Database Driver Class Initialized
INFO - 2024-12-24 05:22:58 --> Email Class Initialized
DEBUG - 2024-12-24 05:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:22:58 --> Helper loaded: form_helper
INFO - 2024-12-24 05:22:58 --> Form Validation Class Initialized
INFO - 2024-12-24 05:22:58 --> Controller Class Initialized
INFO - 2024-12-24 05:22:58 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:22:59 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:22:59 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:22:59 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:22:59 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:22:59 --> Final output sent to browser
DEBUG - 2024-12-24 05:22:59 --> Total execution time: 1.6449
INFO - 2024-12-24 05:30:01 --> Config Class Initialized
INFO - 2024-12-24 05:30:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:30:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:30:01 --> Utf8 Class Initialized
INFO - 2024-12-24 05:30:01 --> URI Class Initialized
INFO - 2024-12-24 05:30:01 --> Router Class Initialized
INFO - 2024-12-24 05:30:01 --> Output Class Initialized
INFO - 2024-12-24 05:30:01 --> Security Class Initialized
DEBUG - 2024-12-24 05:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:30:01 --> Input Class Initialized
INFO - 2024-12-24 05:30:01 --> Language Class Initialized
INFO - 2024-12-24 05:30:01 --> Loader Class Initialized
INFO - 2024-12-24 05:30:01 --> Helper loaded: url_helper
INFO - 2024-12-24 05:30:01 --> Helper loaded: file_helper
INFO - 2024-12-24 05:30:01 --> Helper loaded: security_helper
INFO - 2024-12-24 05:30:01 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:30:01 --> Database Driver Class Initialized
INFO - 2024-12-24 05:30:02 --> Email Class Initialized
DEBUG - 2024-12-24 05:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:30:02 --> Helper loaded: form_helper
INFO - 2024-12-24 05:30:02 --> Form Validation Class Initialized
INFO - 2024-12-24 05:30:02 --> Controller Class Initialized
INFO - 2024-12-24 05:30:02 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:30:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:30:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:30:03 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:30:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:30:03 --> Final output sent to browser
DEBUG - 2024-12-24 05:30:03 --> Total execution time: 1.6830
INFO - 2024-12-24 05:32:05 --> Config Class Initialized
INFO - 2024-12-24 05:32:05 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:32:05 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:32:05 --> Utf8 Class Initialized
INFO - 2024-12-24 05:32:05 --> URI Class Initialized
INFO - 2024-12-24 05:32:05 --> Router Class Initialized
INFO - 2024-12-24 05:32:05 --> Output Class Initialized
INFO - 2024-12-24 05:32:05 --> Security Class Initialized
DEBUG - 2024-12-24 05:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:32:05 --> Input Class Initialized
INFO - 2024-12-24 05:32:05 --> Language Class Initialized
INFO - 2024-12-24 05:32:05 --> Loader Class Initialized
INFO - 2024-12-24 05:32:05 --> Helper loaded: url_helper
INFO - 2024-12-24 05:32:05 --> Helper loaded: file_helper
INFO - 2024-12-24 05:32:05 --> Helper loaded: security_helper
INFO - 2024-12-24 05:32:05 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:32:05 --> Database Driver Class Initialized
INFO - 2024-12-24 05:32:06 --> Email Class Initialized
DEBUG - 2024-12-24 05:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:32:06 --> Helper loaded: form_helper
INFO - 2024-12-24 05:32:06 --> Form Validation Class Initialized
INFO - 2024-12-24 05:32:06 --> Controller Class Initialized
INFO - 2024-12-24 05:32:06 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:32:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-12-24 05:32:06 --> Severity: error --> Exception: Call to undefined method Antrol_model::getAntrol() C:\xampp\htdocs\rso\application\controllers\Antrol.php 37
INFO - 2024-12-24 05:32:26 --> Config Class Initialized
INFO - 2024-12-24 05:32:26 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:32:26 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:32:26 --> Utf8 Class Initialized
INFO - 2024-12-24 05:32:26 --> URI Class Initialized
INFO - 2024-12-24 05:32:26 --> Router Class Initialized
INFO - 2024-12-24 05:32:26 --> Output Class Initialized
INFO - 2024-12-24 05:32:26 --> Security Class Initialized
DEBUG - 2024-12-24 05:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:32:26 --> Input Class Initialized
INFO - 2024-12-24 05:32:26 --> Language Class Initialized
INFO - 2024-12-24 05:32:26 --> Loader Class Initialized
INFO - 2024-12-24 05:32:26 --> Helper loaded: url_helper
INFO - 2024-12-24 05:32:26 --> Helper loaded: file_helper
INFO - 2024-12-24 05:32:26 --> Helper loaded: security_helper
INFO - 2024-12-24 05:32:26 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:32:26 --> Database Driver Class Initialized
INFO - 2024-12-24 05:32:27 --> Email Class Initialized
DEBUG - 2024-12-24 05:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:32:27 --> Helper loaded: form_helper
INFO - 2024-12-24 05:32:27 --> Form Validation Class Initialized
INFO - 2024-12-24 05:32:27 --> Controller Class Initialized
INFO - 2024-12-24 05:32:27 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:32:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:32:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:32:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:32:28 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:32:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:32:28 --> Final output sent to browser
DEBUG - 2024-12-24 05:32:28 --> Total execution time: 1.6283
INFO - 2024-12-24 05:33:40 --> Config Class Initialized
INFO - 2024-12-24 05:33:40 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:33:40 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:33:40 --> Utf8 Class Initialized
INFO - 2024-12-24 05:33:40 --> URI Class Initialized
INFO - 2024-12-24 05:33:40 --> Router Class Initialized
INFO - 2024-12-24 05:33:40 --> Output Class Initialized
INFO - 2024-12-24 05:33:40 --> Security Class Initialized
DEBUG - 2024-12-24 05:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:33:40 --> Input Class Initialized
INFO - 2024-12-24 05:33:40 --> Language Class Initialized
INFO - 2024-12-24 05:33:40 --> Loader Class Initialized
INFO - 2024-12-24 05:33:40 --> Helper loaded: url_helper
INFO - 2024-12-24 05:33:40 --> Helper loaded: file_helper
INFO - 2024-12-24 05:33:40 --> Helper loaded: security_helper
INFO - 2024-12-24 05:33:40 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:33:40 --> Database Driver Class Initialized
INFO - 2024-12-24 05:33:41 --> Email Class Initialized
DEBUG - 2024-12-24 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:33:41 --> Helper loaded: form_helper
INFO - 2024-12-24 05:33:41 --> Form Validation Class Initialized
INFO - 2024-12-24 05:33:41 --> Controller Class Initialized
INFO - 2024-12-24 05:33:41 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:33:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:33:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:33:42 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:33:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:33:42 --> Final output sent to browser
DEBUG - 2024-12-24 05:33:42 --> Total execution time: 2.5309
INFO - 2024-12-24 05:36:47 --> Config Class Initialized
INFO - 2024-12-24 05:36:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:36:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:36:47 --> Utf8 Class Initialized
INFO - 2024-12-24 05:36:47 --> URI Class Initialized
INFO - 2024-12-24 05:36:47 --> Router Class Initialized
INFO - 2024-12-24 05:36:47 --> Output Class Initialized
INFO - 2024-12-24 05:36:47 --> Security Class Initialized
DEBUG - 2024-12-24 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:36:47 --> Input Class Initialized
INFO - 2024-12-24 05:36:47 --> Language Class Initialized
INFO - 2024-12-24 05:36:47 --> Loader Class Initialized
INFO - 2024-12-24 05:36:47 --> Helper loaded: url_helper
INFO - 2024-12-24 05:36:47 --> Helper loaded: file_helper
INFO - 2024-12-24 05:36:47 --> Helper loaded: security_helper
INFO - 2024-12-24 05:36:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:36:47 --> Database Driver Class Initialized
INFO - 2024-12-24 05:36:48 --> Email Class Initialized
DEBUG - 2024-12-24 05:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:36:48 --> Helper loaded: form_helper
INFO - 2024-12-24 05:36:48 --> Form Validation Class Initialized
INFO - 2024-12-24 05:36:48 --> Controller Class Initialized
INFO - 2024-12-24 05:36:48 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:36:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:36:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:36:50 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:36:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:36:50 --> Final output sent to browser
DEBUG - 2024-12-24 05:36:50 --> Total execution time: 2.6930
INFO - 2024-12-24 05:37:39 --> Config Class Initialized
INFO - 2024-12-24 05:37:39 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:37:39 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:37:39 --> Utf8 Class Initialized
INFO - 2024-12-24 05:37:39 --> URI Class Initialized
INFO - 2024-12-24 05:37:39 --> Router Class Initialized
INFO - 2024-12-24 05:37:39 --> Output Class Initialized
INFO - 2024-12-24 05:37:39 --> Security Class Initialized
DEBUG - 2024-12-24 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:37:39 --> Input Class Initialized
INFO - 2024-12-24 05:37:39 --> Language Class Initialized
INFO - 2024-12-24 05:37:39 --> Loader Class Initialized
INFO - 2024-12-24 05:37:39 --> Helper loaded: url_helper
INFO - 2024-12-24 05:37:39 --> Helper loaded: file_helper
INFO - 2024-12-24 05:37:39 --> Helper loaded: security_helper
INFO - 2024-12-24 05:37:39 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:37:39 --> Database Driver Class Initialized
INFO - 2024-12-24 05:37:39 --> Email Class Initialized
DEBUG - 2024-12-24 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:37:39 --> Helper loaded: form_helper
INFO - 2024-12-24 05:37:39 --> Form Validation Class Initialized
INFO - 2024-12-24 05:37:39 --> Controller Class Initialized
INFO - 2024-12-24 05:37:39 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:37:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:37:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:37:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:37:41 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:37:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:37:41 --> Final output sent to browser
DEBUG - 2024-12-24 05:37:41 --> Total execution time: 2.5928
INFO - 2024-12-24 05:38:02 --> Config Class Initialized
INFO - 2024-12-24 05:38:02 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:38:02 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:38:02 --> Utf8 Class Initialized
INFO - 2024-12-24 05:38:02 --> URI Class Initialized
INFO - 2024-12-24 05:38:02 --> Router Class Initialized
INFO - 2024-12-24 05:38:02 --> Output Class Initialized
INFO - 2024-12-24 05:38:02 --> Security Class Initialized
DEBUG - 2024-12-24 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:38:02 --> Input Class Initialized
INFO - 2024-12-24 05:38:02 --> Language Class Initialized
INFO - 2024-12-24 05:38:02 --> Loader Class Initialized
INFO - 2024-12-24 05:38:02 --> Helper loaded: url_helper
INFO - 2024-12-24 05:38:02 --> Helper loaded: file_helper
INFO - 2024-12-24 05:38:02 --> Helper loaded: security_helper
INFO - 2024-12-24 05:38:02 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:38:02 --> Database Driver Class Initialized
INFO - 2024-12-24 05:38:02 --> Email Class Initialized
DEBUG - 2024-12-24 05:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:38:02 --> Helper loaded: form_helper
INFO - 2024-12-24 05:38:02 --> Form Validation Class Initialized
INFO - 2024-12-24 05:38:02 --> Controller Class Initialized
INFO - 2024-12-24 05:38:02 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:38:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:38:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:38:04 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:38:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:38:04 --> Final output sent to browser
DEBUG - 2024-12-24 05:38:04 --> Total execution time: 2.7754
INFO - 2024-12-24 05:39:33 --> Config Class Initialized
INFO - 2024-12-24 05:39:33 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:39:33 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:39:33 --> Utf8 Class Initialized
INFO - 2024-12-24 05:39:33 --> URI Class Initialized
INFO - 2024-12-24 05:39:33 --> Router Class Initialized
INFO - 2024-12-24 05:39:33 --> Output Class Initialized
INFO - 2024-12-24 05:39:33 --> Security Class Initialized
DEBUG - 2024-12-24 05:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:39:33 --> Input Class Initialized
INFO - 2024-12-24 05:39:33 --> Language Class Initialized
INFO - 2024-12-24 05:39:33 --> Loader Class Initialized
INFO - 2024-12-24 05:39:33 --> Helper loaded: url_helper
INFO - 2024-12-24 05:39:33 --> Helper loaded: file_helper
INFO - 2024-12-24 05:39:33 --> Helper loaded: security_helper
INFO - 2024-12-24 05:39:33 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:39:33 --> Database Driver Class Initialized
INFO - 2024-12-24 05:39:34 --> Email Class Initialized
DEBUG - 2024-12-24 05:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:39:34 --> Helper loaded: form_helper
INFO - 2024-12-24 05:39:34 --> Form Validation Class Initialized
INFO - 2024-12-24 05:39:34 --> Controller Class Initialized
INFO - 2024-12-24 05:39:34 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:39:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:39:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:39:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:39:36 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:39:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:39:36 --> Final output sent to browser
DEBUG - 2024-12-24 05:39:36 --> Total execution time: 2.7902
INFO - 2024-12-24 05:41:01 --> Config Class Initialized
INFO - 2024-12-24 05:41:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:41:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:41:01 --> Utf8 Class Initialized
INFO - 2024-12-24 05:41:01 --> URI Class Initialized
INFO - 2024-12-24 05:41:01 --> Router Class Initialized
INFO - 2024-12-24 05:41:01 --> Output Class Initialized
INFO - 2024-12-24 05:41:01 --> Security Class Initialized
DEBUG - 2024-12-24 05:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:41:01 --> Input Class Initialized
INFO - 2024-12-24 05:41:01 --> Language Class Initialized
INFO - 2024-12-24 05:41:01 --> Loader Class Initialized
INFO - 2024-12-24 05:41:01 --> Helper loaded: url_helper
INFO - 2024-12-24 05:41:01 --> Helper loaded: file_helper
INFO - 2024-12-24 05:41:01 --> Helper loaded: security_helper
INFO - 2024-12-24 05:41:01 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:41:01 --> Database Driver Class Initialized
INFO - 2024-12-24 05:41:02 --> Email Class Initialized
DEBUG - 2024-12-24 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:41:02 --> Helper loaded: form_helper
INFO - 2024-12-24 05:41:02 --> Form Validation Class Initialized
INFO - 2024-12-24 05:41:02 --> Controller Class Initialized
INFO - 2024-12-24 05:41:02 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:41:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:41:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:41:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:41:04 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:41:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:41:04 --> Final output sent to browser
DEBUG - 2024-12-24 05:41:04 --> Total execution time: 3.0491
INFO - 2024-12-24 05:42:52 --> Config Class Initialized
INFO - 2024-12-24 05:42:52 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:42:52 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:42:52 --> Utf8 Class Initialized
INFO - 2024-12-24 05:42:52 --> URI Class Initialized
INFO - 2024-12-24 05:42:52 --> Router Class Initialized
INFO - 2024-12-24 05:42:52 --> Output Class Initialized
INFO - 2024-12-24 05:42:52 --> Security Class Initialized
DEBUG - 2024-12-24 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:42:52 --> Input Class Initialized
INFO - 2024-12-24 05:42:52 --> Language Class Initialized
INFO - 2024-12-24 05:42:52 --> Loader Class Initialized
INFO - 2024-12-24 05:42:52 --> Helper loaded: url_helper
INFO - 2024-12-24 05:42:52 --> Helper loaded: file_helper
INFO - 2024-12-24 05:42:52 --> Helper loaded: security_helper
INFO - 2024-12-24 05:42:52 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:42:52 --> Database Driver Class Initialized
INFO - 2024-12-24 05:42:53 --> Email Class Initialized
DEBUG - 2024-12-24 05:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:42:53 --> Helper loaded: form_helper
INFO - 2024-12-24 05:42:53 --> Form Validation Class Initialized
INFO - 2024-12-24 05:42:53 --> Controller Class Initialized
INFO - 2024-12-24 05:42:53 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:42:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:42:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:42:55 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:42:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:42:55 --> Final output sent to browser
DEBUG - 2024-12-24 05:42:55 --> Total execution time: 2.5706
INFO - 2024-12-24 05:43:21 --> Config Class Initialized
INFO - 2024-12-24 05:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:43:21 --> Utf8 Class Initialized
INFO - 2024-12-24 05:43:21 --> URI Class Initialized
INFO - 2024-12-24 05:43:21 --> Router Class Initialized
INFO - 2024-12-24 05:43:21 --> Output Class Initialized
INFO - 2024-12-24 05:43:21 --> Security Class Initialized
DEBUG - 2024-12-24 05:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:43:21 --> Input Class Initialized
INFO - 2024-12-24 05:43:21 --> Language Class Initialized
INFO - 2024-12-24 05:43:21 --> Loader Class Initialized
INFO - 2024-12-24 05:43:21 --> Helper loaded: url_helper
INFO - 2024-12-24 05:43:21 --> Helper loaded: file_helper
INFO - 2024-12-24 05:43:21 --> Helper loaded: security_helper
INFO - 2024-12-24 05:43:21 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:43:21 --> Database Driver Class Initialized
INFO - 2024-12-24 05:43:21 --> Email Class Initialized
DEBUG - 2024-12-24 05:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:43:21 --> Helper loaded: form_helper
INFO - 2024-12-24 05:43:21 --> Form Validation Class Initialized
INFO - 2024-12-24 05:43:21 --> Controller Class Initialized
INFO - 2024-12-24 05:43:21 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:43:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:43:23 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:43:23 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:43:23 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:43:23 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:43:23 --> Final output sent to browser
DEBUG - 2024-12-24 05:43:23 --> Total execution time: 2.6273
INFO - 2024-12-24 05:44:15 --> Config Class Initialized
INFO - 2024-12-24 05:44:15 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:44:15 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:44:15 --> Utf8 Class Initialized
INFO - 2024-12-24 05:44:15 --> URI Class Initialized
INFO - 2024-12-24 05:44:15 --> Router Class Initialized
INFO - 2024-12-24 05:44:15 --> Output Class Initialized
INFO - 2024-12-24 05:44:15 --> Security Class Initialized
DEBUG - 2024-12-24 05:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:44:15 --> Input Class Initialized
INFO - 2024-12-24 05:44:15 --> Language Class Initialized
INFO - 2024-12-24 05:44:15 --> Loader Class Initialized
INFO - 2024-12-24 05:44:15 --> Helper loaded: url_helper
INFO - 2024-12-24 05:44:15 --> Helper loaded: file_helper
INFO - 2024-12-24 05:44:15 --> Helper loaded: security_helper
INFO - 2024-12-24 05:44:15 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:44:15 --> Database Driver Class Initialized
INFO - 2024-12-24 05:44:16 --> Email Class Initialized
DEBUG - 2024-12-24 05:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:44:16 --> Helper loaded: form_helper
INFO - 2024-12-24 05:44:16 --> Form Validation Class Initialized
INFO - 2024-12-24 05:44:16 --> Controller Class Initialized
INFO - 2024-12-24 05:44:16 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:44:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:44:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:44:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:44:18 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:44:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:44:18 --> Final output sent to browser
DEBUG - 2024-12-24 05:44:18 --> Total execution time: 2.6617
INFO - 2024-12-24 05:44:45 --> Config Class Initialized
INFO - 2024-12-24 05:44:45 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:44:45 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:44:45 --> Utf8 Class Initialized
INFO - 2024-12-24 05:44:45 --> URI Class Initialized
INFO - 2024-12-24 05:44:45 --> Router Class Initialized
INFO - 2024-12-24 05:44:45 --> Output Class Initialized
INFO - 2024-12-24 05:44:45 --> Security Class Initialized
DEBUG - 2024-12-24 05:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:44:45 --> Input Class Initialized
INFO - 2024-12-24 05:44:45 --> Language Class Initialized
INFO - 2024-12-24 05:44:45 --> Loader Class Initialized
INFO - 2024-12-24 05:44:45 --> Helper loaded: url_helper
INFO - 2024-12-24 05:44:45 --> Helper loaded: file_helper
INFO - 2024-12-24 05:44:45 --> Helper loaded: security_helper
INFO - 2024-12-24 05:44:45 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:44:45 --> Database Driver Class Initialized
INFO - 2024-12-24 05:44:46 --> Email Class Initialized
DEBUG - 2024-12-24 05:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:44:46 --> Helper loaded: form_helper
INFO - 2024-12-24 05:44:46 --> Form Validation Class Initialized
INFO - 2024-12-24 05:44:46 --> Controller Class Initialized
INFO - 2024-12-24 05:44:46 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:44:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:44:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:44:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:44:48 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:44:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:44:48 --> Final output sent to browser
DEBUG - 2024-12-24 05:44:48 --> Total execution time: 2.9259
INFO - 2024-12-24 05:44:55 --> Config Class Initialized
INFO - 2024-12-24 05:44:55 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:44:55 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:44:55 --> Utf8 Class Initialized
INFO - 2024-12-24 05:44:55 --> URI Class Initialized
INFO - 2024-12-24 05:44:55 --> Router Class Initialized
INFO - 2024-12-24 05:44:55 --> Output Class Initialized
INFO - 2024-12-24 05:44:55 --> Security Class Initialized
DEBUG - 2024-12-24 05:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:44:55 --> Input Class Initialized
INFO - 2024-12-24 05:44:55 --> Language Class Initialized
INFO - 2024-12-24 05:44:55 --> Loader Class Initialized
INFO - 2024-12-24 05:44:55 --> Helper loaded: url_helper
INFO - 2024-12-24 05:44:55 --> Helper loaded: file_helper
INFO - 2024-12-24 05:44:55 --> Helper loaded: security_helper
INFO - 2024-12-24 05:44:55 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:44:55 --> Database Driver Class Initialized
INFO - 2024-12-24 05:44:55 --> Email Class Initialized
DEBUG - 2024-12-24 05:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:44:55 --> Helper loaded: form_helper
INFO - 2024-12-24 05:44:55 --> Form Validation Class Initialized
INFO - 2024-12-24 05:44:55 --> Controller Class Initialized
INFO - 2024-12-24 05:44:55 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:44:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:44:58 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:44:58 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:44:58 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:44:58 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:44:58 --> Final output sent to browser
DEBUG - 2024-12-24 05:44:58 --> Total execution time: 3.0009
INFO - 2024-12-24 05:46:07 --> Config Class Initialized
INFO - 2024-12-24 05:46:07 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:46:08 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:46:08 --> Utf8 Class Initialized
INFO - 2024-12-24 05:46:08 --> URI Class Initialized
INFO - 2024-12-24 05:46:08 --> Router Class Initialized
INFO - 2024-12-24 05:46:08 --> Output Class Initialized
INFO - 2024-12-24 05:46:08 --> Security Class Initialized
DEBUG - 2024-12-24 05:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:46:08 --> Input Class Initialized
INFO - 2024-12-24 05:46:08 --> Language Class Initialized
INFO - 2024-12-24 05:46:08 --> Loader Class Initialized
INFO - 2024-12-24 05:46:08 --> Helper loaded: url_helper
INFO - 2024-12-24 05:46:08 --> Helper loaded: file_helper
INFO - 2024-12-24 05:46:08 --> Helper loaded: security_helper
INFO - 2024-12-24 05:46:08 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:46:08 --> Database Driver Class Initialized
INFO - 2024-12-24 05:46:08 --> Email Class Initialized
DEBUG - 2024-12-24 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:46:08 --> Helper loaded: form_helper
INFO - 2024-12-24 05:46:08 --> Form Validation Class Initialized
INFO - 2024-12-24 05:46:08 --> Controller Class Initialized
INFO - 2024-12-24 05:46:08 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:46:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:46:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:46:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:46:10 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:46:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:46:10 --> Final output sent to browser
DEBUG - 2024-12-24 05:46:10 --> Total execution time: 2.6549
INFO - 2024-12-24 05:48:26 --> Config Class Initialized
INFO - 2024-12-24 05:48:26 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:48:26 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:48:26 --> Utf8 Class Initialized
INFO - 2024-12-24 05:48:26 --> URI Class Initialized
INFO - 2024-12-24 05:48:26 --> Router Class Initialized
INFO - 2024-12-24 05:48:26 --> Output Class Initialized
INFO - 2024-12-24 05:48:26 --> Security Class Initialized
DEBUG - 2024-12-24 05:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:48:26 --> Input Class Initialized
INFO - 2024-12-24 05:48:26 --> Language Class Initialized
INFO - 2024-12-24 05:48:26 --> Loader Class Initialized
INFO - 2024-12-24 05:48:26 --> Helper loaded: url_helper
INFO - 2024-12-24 05:48:26 --> Helper loaded: file_helper
INFO - 2024-12-24 05:48:26 --> Helper loaded: security_helper
INFO - 2024-12-24 05:48:26 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:48:26 --> Database Driver Class Initialized
INFO - 2024-12-24 05:48:27 --> Email Class Initialized
DEBUG - 2024-12-24 05:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:48:27 --> Helper loaded: form_helper
INFO - 2024-12-24 05:48:27 --> Form Validation Class Initialized
INFO - 2024-12-24 05:48:27 --> Controller Class Initialized
INFO - 2024-12-24 05:48:27 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:48:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:48:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:48:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:48:29 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:48:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:48:29 --> Final output sent to browser
DEBUG - 2024-12-24 05:48:29 --> Total execution time: 2.4716
INFO - 2024-12-24 05:48:40 --> Config Class Initialized
INFO - 2024-12-24 05:48:40 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:48:40 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:48:40 --> Utf8 Class Initialized
INFO - 2024-12-24 05:48:40 --> URI Class Initialized
INFO - 2024-12-24 05:48:40 --> Router Class Initialized
INFO - 2024-12-24 05:48:40 --> Output Class Initialized
INFO - 2024-12-24 05:48:40 --> Security Class Initialized
DEBUG - 2024-12-24 05:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:48:40 --> Input Class Initialized
INFO - 2024-12-24 05:48:40 --> Language Class Initialized
INFO - 2024-12-24 05:48:40 --> Loader Class Initialized
INFO - 2024-12-24 05:48:40 --> Helper loaded: url_helper
INFO - 2024-12-24 05:48:40 --> Helper loaded: file_helper
INFO - 2024-12-24 05:48:40 --> Helper loaded: security_helper
INFO - 2024-12-24 05:48:40 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:48:40 --> Database Driver Class Initialized
INFO - 2024-12-24 05:48:40 --> Email Class Initialized
DEBUG - 2024-12-24 05:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:48:40 --> Helper loaded: form_helper
INFO - 2024-12-24 05:48:40 --> Form Validation Class Initialized
INFO - 2024-12-24 05:48:40 --> Controller Class Initialized
INFO - 2024-12-24 05:48:40 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:48:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:48:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:48:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:48:43 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:48:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:48:43 --> Final output sent to browser
DEBUG - 2024-12-24 05:48:43 --> Total execution time: 3.0225
INFO - 2024-12-24 05:48:51 --> Config Class Initialized
INFO - 2024-12-24 05:48:51 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:48:51 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:48:51 --> Utf8 Class Initialized
INFO - 2024-12-24 05:48:51 --> URI Class Initialized
INFO - 2024-12-24 05:48:51 --> Router Class Initialized
INFO - 2024-12-24 05:48:51 --> Output Class Initialized
INFO - 2024-12-24 05:48:51 --> Security Class Initialized
DEBUG - 2024-12-24 05:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:48:51 --> Input Class Initialized
INFO - 2024-12-24 05:48:51 --> Language Class Initialized
INFO - 2024-12-24 05:48:51 --> Loader Class Initialized
INFO - 2024-12-24 05:48:51 --> Helper loaded: url_helper
INFO - 2024-12-24 05:48:51 --> Helper loaded: file_helper
INFO - 2024-12-24 05:48:51 --> Helper loaded: security_helper
INFO - 2024-12-24 05:48:51 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:48:51 --> Database Driver Class Initialized
INFO - 2024-12-24 05:48:51 --> Email Class Initialized
DEBUG - 2024-12-24 05:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:48:51 --> Helper loaded: form_helper
INFO - 2024-12-24 05:48:51 --> Form Validation Class Initialized
INFO - 2024-12-24 05:48:51 --> Controller Class Initialized
INFO - 2024-12-24 05:48:51 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:48:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:48:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:48:53 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:48:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:48:53 --> Final output sent to browser
DEBUG - 2024-12-24 05:48:53 --> Total execution time: 2.6340
INFO - 2024-12-24 05:49:08 --> Config Class Initialized
INFO - 2024-12-24 05:49:08 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:49:08 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:49:08 --> Utf8 Class Initialized
INFO - 2024-12-24 05:49:08 --> URI Class Initialized
INFO - 2024-12-24 05:49:08 --> Router Class Initialized
INFO - 2024-12-24 05:49:08 --> Output Class Initialized
INFO - 2024-12-24 05:49:08 --> Security Class Initialized
DEBUG - 2024-12-24 05:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:49:08 --> Input Class Initialized
INFO - 2024-12-24 05:49:08 --> Language Class Initialized
INFO - 2024-12-24 05:49:08 --> Loader Class Initialized
INFO - 2024-12-24 05:49:08 --> Helper loaded: url_helper
INFO - 2024-12-24 05:49:08 --> Helper loaded: file_helper
INFO - 2024-12-24 05:49:08 --> Helper loaded: security_helper
INFO - 2024-12-24 05:49:08 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:49:08 --> Database Driver Class Initialized
INFO - 2024-12-24 05:49:08 --> Email Class Initialized
DEBUG - 2024-12-24 05:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:49:08 --> Helper loaded: form_helper
INFO - 2024-12-24 05:49:08 --> Form Validation Class Initialized
INFO - 2024-12-24 05:49:08 --> Controller Class Initialized
INFO - 2024-12-24 05:49:08 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:49:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:49:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:49:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:49:10 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:49:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:49:10 --> Final output sent to browser
DEBUG - 2024-12-24 05:49:10 --> Total execution time: 2.5368
INFO - 2024-12-24 05:49:23 --> Config Class Initialized
INFO - 2024-12-24 05:49:23 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:49:23 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:49:23 --> Utf8 Class Initialized
INFO - 2024-12-24 05:49:23 --> URI Class Initialized
INFO - 2024-12-24 05:49:23 --> Router Class Initialized
INFO - 2024-12-24 05:49:23 --> Output Class Initialized
INFO - 2024-12-24 05:49:23 --> Security Class Initialized
DEBUG - 2024-12-24 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:49:23 --> Input Class Initialized
INFO - 2024-12-24 05:49:23 --> Language Class Initialized
INFO - 2024-12-24 05:49:23 --> Loader Class Initialized
INFO - 2024-12-24 05:49:23 --> Helper loaded: url_helper
INFO - 2024-12-24 05:49:23 --> Helper loaded: file_helper
INFO - 2024-12-24 05:49:23 --> Helper loaded: security_helper
INFO - 2024-12-24 05:49:23 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:49:23 --> Database Driver Class Initialized
INFO - 2024-12-24 05:49:24 --> Email Class Initialized
DEBUG - 2024-12-24 05:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:49:24 --> Helper loaded: form_helper
INFO - 2024-12-24 05:49:24 --> Form Validation Class Initialized
INFO - 2024-12-24 05:49:24 --> Controller Class Initialized
INFO - 2024-12-24 05:49:24 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:49:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:49:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:49:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:49:25 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:49:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:49:25 --> Final output sent to browser
DEBUG - 2024-12-24 05:49:25 --> Total execution time: 2.0568
INFO - 2024-12-24 05:49:31 --> Config Class Initialized
INFO - 2024-12-24 05:49:31 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:49:31 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:49:31 --> Utf8 Class Initialized
INFO - 2024-12-24 05:49:31 --> URI Class Initialized
INFO - 2024-12-24 05:49:31 --> Router Class Initialized
INFO - 2024-12-24 05:49:31 --> Output Class Initialized
INFO - 2024-12-24 05:49:31 --> Security Class Initialized
DEBUG - 2024-12-24 05:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:49:31 --> Input Class Initialized
INFO - 2024-12-24 05:49:31 --> Language Class Initialized
INFO - 2024-12-24 05:49:31 --> Loader Class Initialized
INFO - 2024-12-24 05:49:31 --> Helper loaded: url_helper
INFO - 2024-12-24 05:49:31 --> Helper loaded: file_helper
INFO - 2024-12-24 05:49:31 --> Helper loaded: security_helper
INFO - 2024-12-24 05:49:31 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:49:31 --> Database Driver Class Initialized
INFO - 2024-12-24 05:49:31 --> Email Class Initialized
DEBUG - 2024-12-24 05:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:49:31 --> Helper loaded: form_helper
INFO - 2024-12-24 05:49:31 --> Form Validation Class Initialized
INFO - 2024-12-24 05:49:31 --> Controller Class Initialized
INFO - 2024-12-24 05:49:31 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:49:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:49:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:49:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:49:33 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:49:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:49:33 --> Final output sent to browser
DEBUG - 2024-12-24 05:49:33 --> Total execution time: 2.3523
INFO - 2024-12-24 05:49:43 --> Config Class Initialized
INFO - 2024-12-24 05:49:43 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:49:43 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:49:43 --> Utf8 Class Initialized
INFO - 2024-12-24 05:49:43 --> URI Class Initialized
INFO - 2024-12-24 05:49:43 --> Router Class Initialized
INFO - 2024-12-24 05:49:43 --> Output Class Initialized
INFO - 2024-12-24 05:49:43 --> Security Class Initialized
DEBUG - 2024-12-24 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:49:43 --> Input Class Initialized
INFO - 2024-12-24 05:49:43 --> Language Class Initialized
INFO - 2024-12-24 05:49:43 --> Loader Class Initialized
INFO - 2024-12-24 05:49:43 --> Helper loaded: url_helper
INFO - 2024-12-24 05:49:43 --> Helper loaded: file_helper
INFO - 2024-12-24 05:49:43 --> Helper loaded: security_helper
INFO - 2024-12-24 05:49:43 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:49:43 --> Database Driver Class Initialized
INFO - 2024-12-24 05:49:44 --> Email Class Initialized
DEBUG - 2024-12-24 05:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:49:44 --> Helper loaded: form_helper
INFO - 2024-12-24 05:49:44 --> Form Validation Class Initialized
INFO - 2024-12-24 05:49:44 --> Controller Class Initialized
INFO - 2024-12-24 05:49:44 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:49:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:49:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:49:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:49:46 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:49:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:49:46 --> Final output sent to browser
DEBUG - 2024-12-24 05:49:46 --> Total execution time: 2.7027
INFO - 2024-12-24 05:50:02 --> Config Class Initialized
INFO - 2024-12-24 05:50:02 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:50:02 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:50:02 --> Utf8 Class Initialized
INFO - 2024-12-24 05:50:02 --> URI Class Initialized
INFO - 2024-12-24 05:50:02 --> Router Class Initialized
INFO - 2024-12-24 05:50:02 --> Output Class Initialized
INFO - 2024-12-24 05:50:02 --> Security Class Initialized
DEBUG - 2024-12-24 05:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:50:02 --> Input Class Initialized
INFO - 2024-12-24 05:50:02 --> Language Class Initialized
INFO - 2024-12-24 05:50:02 --> Loader Class Initialized
INFO - 2024-12-24 05:50:02 --> Helper loaded: url_helper
INFO - 2024-12-24 05:50:02 --> Helper loaded: file_helper
INFO - 2024-12-24 05:50:02 --> Helper loaded: security_helper
INFO - 2024-12-24 05:50:02 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:50:02 --> Database Driver Class Initialized
INFO - 2024-12-24 05:50:03 --> Email Class Initialized
DEBUG - 2024-12-24 05:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:50:03 --> Helper loaded: form_helper
INFO - 2024-12-24 05:50:03 --> Form Validation Class Initialized
INFO - 2024-12-24 05:50:03 --> Controller Class Initialized
INFO - 2024-12-24 05:50:03 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:50:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:50:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:50:05 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:50:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:50:05 --> Final output sent to browser
DEBUG - 2024-12-24 05:50:05 --> Total execution time: 3.0881
INFO - 2024-12-24 05:50:13 --> Config Class Initialized
INFO - 2024-12-24 05:50:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:50:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:50:13 --> Utf8 Class Initialized
INFO - 2024-12-24 05:50:13 --> URI Class Initialized
INFO - 2024-12-24 05:50:13 --> Router Class Initialized
INFO - 2024-12-24 05:50:13 --> Output Class Initialized
INFO - 2024-12-24 05:50:13 --> Security Class Initialized
DEBUG - 2024-12-24 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:50:13 --> Input Class Initialized
INFO - 2024-12-24 05:50:13 --> Language Class Initialized
INFO - 2024-12-24 05:50:13 --> Loader Class Initialized
INFO - 2024-12-24 05:50:13 --> Helper loaded: url_helper
INFO - 2024-12-24 05:50:13 --> Helper loaded: file_helper
INFO - 2024-12-24 05:50:13 --> Helper loaded: security_helper
INFO - 2024-12-24 05:50:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:50:13 --> Database Driver Class Initialized
INFO - 2024-12-24 05:50:13 --> Email Class Initialized
DEBUG - 2024-12-24 05:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:50:13 --> Helper loaded: form_helper
INFO - 2024-12-24 05:50:13 --> Form Validation Class Initialized
INFO - 2024-12-24 05:50:13 --> Controller Class Initialized
INFO - 2024-12-24 05:50:13 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:50:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:50:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:50:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:50:15 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:50:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:50:15 --> Final output sent to browser
DEBUG - 2024-12-24 05:50:15 --> Total execution time: 2.4330
INFO - 2024-12-24 05:51:13 --> Config Class Initialized
INFO - 2024-12-24 05:51:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:51:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:51:13 --> Utf8 Class Initialized
INFO - 2024-12-24 05:51:13 --> URI Class Initialized
INFO - 2024-12-24 05:51:13 --> Router Class Initialized
INFO - 2024-12-24 05:51:14 --> Output Class Initialized
INFO - 2024-12-24 05:51:14 --> Security Class Initialized
DEBUG - 2024-12-24 05:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:51:14 --> Input Class Initialized
INFO - 2024-12-24 05:51:14 --> Language Class Initialized
INFO - 2024-12-24 05:51:14 --> Loader Class Initialized
INFO - 2024-12-24 05:51:14 --> Helper loaded: url_helper
INFO - 2024-12-24 05:51:14 --> Helper loaded: file_helper
INFO - 2024-12-24 05:51:14 --> Helper loaded: security_helper
INFO - 2024-12-24 05:51:14 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:51:14 --> Database Driver Class Initialized
INFO - 2024-12-24 05:51:14 --> Email Class Initialized
DEBUG - 2024-12-24 05:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:51:14 --> Helper loaded: form_helper
INFO - 2024-12-24 05:51:14 --> Form Validation Class Initialized
INFO - 2024-12-24 05:51:14 --> Controller Class Initialized
INFO - 2024-12-24 05:51:14 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:51:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:51:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:51:16 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:51:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:51:16 --> Final output sent to browser
DEBUG - 2024-12-24 05:51:16 --> Total execution time: 2.7433
INFO - 2024-12-24 05:53:13 --> Config Class Initialized
INFO - 2024-12-24 05:53:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:53:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:53:13 --> Utf8 Class Initialized
INFO - 2024-12-24 05:53:13 --> URI Class Initialized
INFO - 2024-12-24 05:53:13 --> Router Class Initialized
INFO - 2024-12-24 05:53:13 --> Output Class Initialized
INFO - 2024-12-24 05:53:13 --> Security Class Initialized
DEBUG - 2024-12-24 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:53:13 --> Input Class Initialized
INFO - 2024-12-24 05:53:13 --> Language Class Initialized
INFO - 2024-12-24 05:53:13 --> Loader Class Initialized
INFO - 2024-12-24 05:53:13 --> Helper loaded: url_helper
INFO - 2024-12-24 05:53:13 --> Helper loaded: file_helper
INFO - 2024-12-24 05:53:13 --> Helper loaded: security_helper
INFO - 2024-12-24 05:53:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:53:13 --> Database Driver Class Initialized
INFO - 2024-12-24 05:53:13 --> Email Class Initialized
DEBUG - 2024-12-24 05:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:53:13 --> Helper loaded: form_helper
INFO - 2024-12-24 05:53:13 --> Form Validation Class Initialized
INFO - 2024-12-24 05:53:13 --> Controller Class Initialized
INFO - 2024-12-24 05:53:13 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:53:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:53:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:53:15 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:53:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:53:15 --> Final output sent to browser
DEBUG - 2024-12-24 05:53:15 --> Total execution time: 2.6831
INFO - 2024-12-24 05:55:46 --> Config Class Initialized
INFO - 2024-12-24 05:55:46 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:55:46 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:55:46 --> Utf8 Class Initialized
INFO - 2024-12-24 05:55:46 --> URI Class Initialized
INFO - 2024-12-24 05:55:46 --> Router Class Initialized
INFO - 2024-12-24 05:55:46 --> Output Class Initialized
INFO - 2024-12-24 05:55:46 --> Security Class Initialized
DEBUG - 2024-12-24 05:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:55:46 --> Input Class Initialized
INFO - 2024-12-24 05:55:46 --> Language Class Initialized
INFO - 2024-12-24 05:55:46 --> Loader Class Initialized
INFO - 2024-12-24 05:55:46 --> Helper loaded: url_helper
INFO - 2024-12-24 05:55:46 --> Helper loaded: file_helper
INFO - 2024-12-24 05:55:46 --> Helper loaded: security_helper
INFO - 2024-12-24 05:55:46 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:55:46 --> Database Driver Class Initialized
INFO - 2024-12-24 05:55:46 --> Email Class Initialized
DEBUG - 2024-12-24 05:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:55:46 --> Helper loaded: form_helper
INFO - 2024-12-24 05:55:46 --> Form Validation Class Initialized
INFO - 2024-12-24 05:55:46 --> Controller Class Initialized
INFO - 2024-12-24 05:55:46 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:55:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:55:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:55:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:55:49 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:55:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:55:49 --> Final output sent to browser
DEBUG - 2024-12-24 05:55:49 --> Total execution time: 2.7787
INFO - 2024-12-24 05:56:08 --> Config Class Initialized
INFO - 2024-12-24 05:56:08 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:56:08 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:56:08 --> Utf8 Class Initialized
INFO - 2024-12-24 05:56:08 --> URI Class Initialized
INFO - 2024-12-24 05:56:08 --> Router Class Initialized
INFO - 2024-12-24 05:56:08 --> Output Class Initialized
INFO - 2024-12-24 05:56:08 --> Security Class Initialized
DEBUG - 2024-12-24 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:56:08 --> Input Class Initialized
INFO - 2024-12-24 05:56:08 --> Language Class Initialized
INFO - 2024-12-24 05:56:08 --> Loader Class Initialized
INFO - 2024-12-24 05:56:08 --> Helper loaded: url_helper
INFO - 2024-12-24 05:56:08 --> Helper loaded: file_helper
INFO - 2024-12-24 05:56:08 --> Helper loaded: security_helper
INFO - 2024-12-24 05:56:08 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:56:08 --> Database Driver Class Initialized
INFO - 2024-12-24 05:56:09 --> Email Class Initialized
DEBUG - 2024-12-24 05:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:56:09 --> Helper loaded: form_helper
INFO - 2024-12-24 05:56:09 --> Form Validation Class Initialized
INFO - 2024-12-24 05:56:09 --> Controller Class Initialized
INFO - 2024-12-24 05:56:09 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:56:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:56:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:56:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:56:11 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:56:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:56:11 --> Final output sent to browser
DEBUG - 2024-12-24 05:56:11 --> Total execution time: 2.8499
INFO - 2024-12-24 05:56:25 --> Config Class Initialized
INFO - 2024-12-24 05:56:25 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:56:25 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:56:25 --> Utf8 Class Initialized
INFO - 2024-12-24 05:56:25 --> URI Class Initialized
INFO - 2024-12-24 05:56:25 --> Router Class Initialized
INFO - 2024-12-24 05:56:25 --> Output Class Initialized
INFO - 2024-12-24 05:56:25 --> Security Class Initialized
DEBUG - 2024-12-24 05:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:56:25 --> Input Class Initialized
INFO - 2024-12-24 05:56:25 --> Language Class Initialized
INFO - 2024-12-24 05:56:25 --> Loader Class Initialized
INFO - 2024-12-24 05:56:25 --> Helper loaded: url_helper
INFO - 2024-12-24 05:56:25 --> Helper loaded: file_helper
INFO - 2024-12-24 05:56:25 --> Helper loaded: security_helper
INFO - 2024-12-24 05:56:25 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:56:25 --> Database Driver Class Initialized
INFO - 2024-12-24 05:56:26 --> Email Class Initialized
DEBUG - 2024-12-24 05:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:56:26 --> Helper loaded: form_helper
INFO - 2024-12-24 05:56:26 --> Form Validation Class Initialized
INFO - 2024-12-24 05:56:26 --> Controller Class Initialized
INFO - 2024-12-24 05:56:26 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:56:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:56:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:56:28 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:56:28 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:56:28 --> Final output sent to browser
DEBUG - 2024-12-24 05:56:28 --> Total execution time: 2.6985
INFO - 2024-12-24 05:56:58 --> Config Class Initialized
INFO - 2024-12-24 05:56:58 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:56:58 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:56:58 --> Utf8 Class Initialized
INFO - 2024-12-24 05:56:58 --> URI Class Initialized
INFO - 2024-12-24 05:56:58 --> Router Class Initialized
INFO - 2024-12-24 05:56:58 --> Output Class Initialized
INFO - 2024-12-24 05:56:58 --> Security Class Initialized
DEBUG - 2024-12-24 05:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:56:58 --> Input Class Initialized
INFO - 2024-12-24 05:56:58 --> Language Class Initialized
INFO - 2024-12-24 05:56:58 --> Loader Class Initialized
INFO - 2024-12-24 05:56:58 --> Helper loaded: url_helper
INFO - 2024-12-24 05:56:58 --> Helper loaded: file_helper
INFO - 2024-12-24 05:56:58 --> Helper loaded: security_helper
INFO - 2024-12-24 05:56:58 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:56:58 --> Database Driver Class Initialized
INFO - 2024-12-24 05:56:59 --> Email Class Initialized
DEBUG - 2024-12-24 05:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:56:59 --> Helper loaded: form_helper
INFO - 2024-12-24 05:56:59 --> Form Validation Class Initialized
INFO - 2024-12-24 05:56:59 --> Controller Class Initialized
INFO - 2024-12-24 05:56:59 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:56:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:57:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:57:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:57:01 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:57:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:57:01 --> Final output sent to browser
DEBUG - 2024-12-24 05:57:01 --> Total execution time: 2.9884
INFO - 2024-12-24 05:57:32 --> Config Class Initialized
INFO - 2024-12-24 05:57:32 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:57:32 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:57:32 --> Utf8 Class Initialized
INFO - 2024-12-24 05:57:32 --> URI Class Initialized
INFO - 2024-12-24 05:57:32 --> Router Class Initialized
INFO - 2024-12-24 05:57:32 --> Output Class Initialized
INFO - 2024-12-24 05:57:32 --> Security Class Initialized
DEBUG - 2024-12-24 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:57:32 --> Input Class Initialized
INFO - 2024-12-24 05:57:32 --> Language Class Initialized
INFO - 2024-12-24 05:57:32 --> Loader Class Initialized
INFO - 2024-12-24 05:57:32 --> Helper loaded: url_helper
INFO - 2024-12-24 05:57:32 --> Helper loaded: file_helper
INFO - 2024-12-24 05:57:32 --> Helper loaded: security_helper
INFO - 2024-12-24 05:57:32 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:57:32 --> Database Driver Class Initialized
INFO - 2024-12-24 05:57:33 --> Email Class Initialized
DEBUG - 2024-12-24 05:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:57:33 --> Helper loaded: form_helper
INFO - 2024-12-24 05:57:33 --> Form Validation Class Initialized
INFO - 2024-12-24 05:57:33 --> Controller Class Initialized
INFO - 2024-12-24 05:57:33 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:57:35 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:57:35 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:57:35 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:57:35 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:57:35 --> Final output sent to browser
DEBUG - 2024-12-24 05:57:35 --> Total execution time: 2.5527
INFO - 2024-12-24 05:58:11 --> Config Class Initialized
INFO - 2024-12-24 05:58:11 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:58:11 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:58:11 --> Utf8 Class Initialized
INFO - 2024-12-24 05:58:11 --> URI Class Initialized
INFO - 2024-12-24 05:58:11 --> Router Class Initialized
INFO - 2024-12-24 05:58:11 --> Output Class Initialized
INFO - 2024-12-24 05:58:11 --> Security Class Initialized
DEBUG - 2024-12-24 05:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:58:11 --> Input Class Initialized
INFO - 2024-12-24 05:58:11 --> Language Class Initialized
INFO - 2024-12-24 05:58:11 --> Loader Class Initialized
INFO - 2024-12-24 05:58:11 --> Helper loaded: url_helper
INFO - 2024-12-24 05:58:11 --> Helper loaded: file_helper
INFO - 2024-12-24 05:58:11 --> Helper loaded: security_helper
INFO - 2024-12-24 05:58:11 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:58:11 --> Database Driver Class Initialized
INFO - 2024-12-24 05:58:11 --> Email Class Initialized
DEBUG - 2024-12-24 05:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:58:11 --> Helper loaded: form_helper
INFO - 2024-12-24 05:58:11 --> Form Validation Class Initialized
INFO - 2024-12-24 05:58:11 --> Controller Class Initialized
INFO - 2024-12-24 05:58:11 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:58:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:58:13 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:58:13 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:58:13 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:58:13 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:58:13 --> Final output sent to browser
DEBUG - 2024-12-24 05:58:13 --> Total execution time: 2.1332
INFO - 2024-12-24 05:58:29 --> Config Class Initialized
INFO - 2024-12-24 05:58:29 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:58:29 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:58:29 --> Utf8 Class Initialized
INFO - 2024-12-24 05:58:29 --> URI Class Initialized
INFO - 2024-12-24 05:58:29 --> Router Class Initialized
INFO - 2024-12-24 05:58:29 --> Output Class Initialized
INFO - 2024-12-24 05:58:29 --> Security Class Initialized
DEBUG - 2024-12-24 05:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:58:29 --> Input Class Initialized
INFO - 2024-12-24 05:58:29 --> Language Class Initialized
INFO - 2024-12-24 05:58:29 --> Loader Class Initialized
INFO - 2024-12-24 05:58:29 --> Helper loaded: url_helper
INFO - 2024-12-24 05:58:29 --> Helper loaded: file_helper
INFO - 2024-12-24 05:58:29 --> Helper loaded: security_helper
INFO - 2024-12-24 05:58:29 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:58:29 --> Database Driver Class Initialized
INFO - 2024-12-24 05:58:29 --> Email Class Initialized
DEBUG - 2024-12-24 05:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:58:29 --> Helper loaded: form_helper
INFO - 2024-12-24 05:58:29 --> Form Validation Class Initialized
INFO - 2024-12-24 05:58:29 --> Controller Class Initialized
INFO - 2024-12-24 05:58:29 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:58:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:58:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:58:31 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:58:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:58:31 --> Final output sent to browser
DEBUG - 2024-12-24 05:58:31 --> Total execution time: 2.5137
INFO - 2024-12-24 05:58:45 --> Config Class Initialized
INFO - 2024-12-24 05:58:45 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:58:45 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:58:45 --> Utf8 Class Initialized
INFO - 2024-12-24 05:58:45 --> URI Class Initialized
INFO - 2024-12-24 05:58:45 --> Router Class Initialized
INFO - 2024-12-24 05:58:45 --> Output Class Initialized
INFO - 2024-12-24 05:58:45 --> Security Class Initialized
DEBUG - 2024-12-24 05:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:58:45 --> Input Class Initialized
INFO - 2024-12-24 05:58:45 --> Language Class Initialized
INFO - 2024-12-24 05:58:45 --> Loader Class Initialized
INFO - 2024-12-24 05:58:45 --> Helper loaded: url_helper
INFO - 2024-12-24 05:58:45 --> Helper loaded: file_helper
INFO - 2024-12-24 05:58:45 --> Helper loaded: security_helper
INFO - 2024-12-24 05:58:45 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:58:45 --> Database Driver Class Initialized
INFO - 2024-12-24 05:58:45 --> Email Class Initialized
DEBUG - 2024-12-24 05:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:58:45 --> Helper loaded: form_helper
INFO - 2024-12-24 05:58:45 --> Form Validation Class Initialized
INFO - 2024-12-24 05:58:45 --> Controller Class Initialized
INFO - 2024-12-24 05:58:45 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:58:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:58:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:58:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:58:47 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:58:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:58:47 --> Final output sent to browser
DEBUG - 2024-12-24 05:58:47 --> Total execution time: 2.6778
INFO - 2024-12-24 05:59:08 --> Config Class Initialized
INFO - 2024-12-24 05:59:08 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:59:08 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:59:08 --> Utf8 Class Initialized
INFO - 2024-12-24 05:59:08 --> URI Class Initialized
INFO - 2024-12-24 05:59:08 --> Router Class Initialized
INFO - 2024-12-24 05:59:08 --> Output Class Initialized
INFO - 2024-12-24 05:59:08 --> Security Class Initialized
DEBUG - 2024-12-24 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:59:08 --> Input Class Initialized
INFO - 2024-12-24 05:59:08 --> Language Class Initialized
INFO - 2024-12-24 05:59:08 --> Loader Class Initialized
INFO - 2024-12-24 05:59:08 --> Helper loaded: url_helper
INFO - 2024-12-24 05:59:08 --> Helper loaded: file_helper
INFO - 2024-12-24 05:59:08 --> Helper loaded: security_helper
INFO - 2024-12-24 05:59:08 --> Helper loaded: wpu_helper
INFO - 2024-12-24 05:59:08 --> Database Driver Class Initialized
INFO - 2024-12-24 05:59:08 --> Email Class Initialized
DEBUG - 2024-12-24 05:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 05:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:59:08 --> Helper loaded: form_helper
INFO - 2024-12-24 05:59:08 --> Form Validation Class Initialized
INFO - 2024-12-24 05:59:08 --> Controller Class Initialized
INFO - 2024-12-24 05:59:08 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 05:59:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 05:59:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 05:59:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 05:59:10 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 05:59:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 05:59:10 --> Final output sent to browser
DEBUG - 2024-12-24 05:59:10 --> Total execution time: 2.5140
INFO - 2024-12-24 06:00:44 --> Config Class Initialized
INFO - 2024-12-24 06:00:44 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:00:44 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:00:44 --> Utf8 Class Initialized
INFO - 2024-12-24 06:00:44 --> URI Class Initialized
INFO - 2024-12-24 06:00:44 --> Router Class Initialized
INFO - 2024-12-24 06:00:44 --> Output Class Initialized
INFO - 2024-12-24 06:00:44 --> Security Class Initialized
DEBUG - 2024-12-24 06:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:00:44 --> Input Class Initialized
INFO - 2024-12-24 06:00:44 --> Language Class Initialized
INFO - 2024-12-24 06:00:44 --> Loader Class Initialized
INFO - 2024-12-24 06:00:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:00:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:00:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:00:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:00:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:00:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:00:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:00:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:00:44 --> Controller Class Initialized
INFO - 2024-12-24 06:00:44 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:00:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:00:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:00:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:00:49 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:00:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:00:49 --> Final output sent to browser
DEBUG - 2024-12-24 06:00:49 --> Total execution time: 4.9704
INFO - 2024-12-24 06:03:02 --> Config Class Initialized
INFO - 2024-12-24 06:03:02 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:03:02 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:03:02 --> Utf8 Class Initialized
INFO - 2024-12-24 06:03:02 --> URI Class Initialized
INFO - 2024-12-24 06:03:02 --> Router Class Initialized
INFO - 2024-12-24 06:03:02 --> Output Class Initialized
INFO - 2024-12-24 06:03:02 --> Security Class Initialized
DEBUG - 2024-12-24 06:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:03:02 --> Input Class Initialized
INFO - 2024-12-24 06:03:02 --> Language Class Initialized
INFO - 2024-12-24 06:03:02 --> Loader Class Initialized
INFO - 2024-12-24 06:03:02 --> Helper loaded: url_helper
INFO - 2024-12-24 06:03:02 --> Helper loaded: file_helper
INFO - 2024-12-24 06:03:02 --> Helper loaded: security_helper
INFO - 2024-12-24 06:03:02 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:03:02 --> Database Driver Class Initialized
INFO - 2024-12-24 06:03:02 --> Email Class Initialized
DEBUG - 2024-12-24 06:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:03:02 --> Helper loaded: form_helper
INFO - 2024-12-24 06:03:02 --> Form Validation Class Initialized
INFO - 2024-12-24 06:03:02 --> Controller Class Initialized
INFO - 2024-12-24 06:03:02 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:03:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:03:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:03:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:03:05 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:03:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:03:05 --> Final output sent to browser
DEBUG - 2024-12-24 06:03:05 --> Total execution time: 3.0411
INFO - 2024-12-24 06:04:12 --> Config Class Initialized
INFO - 2024-12-24 06:04:12 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:04:12 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:04:12 --> Utf8 Class Initialized
INFO - 2024-12-24 06:04:12 --> URI Class Initialized
INFO - 2024-12-24 06:04:12 --> Router Class Initialized
INFO - 2024-12-24 06:04:12 --> Output Class Initialized
INFO - 2024-12-24 06:04:12 --> Security Class Initialized
DEBUG - 2024-12-24 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:04:12 --> Input Class Initialized
INFO - 2024-12-24 06:04:12 --> Language Class Initialized
INFO - 2024-12-24 06:04:12 --> Loader Class Initialized
INFO - 2024-12-24 06:04:12 --> Helper loaded: url_helper
INFO - 2024-12-24 06:04:12 --> Helper loaded: file_helper
INFO - 2024-12-24 06:04:12 --> Helper loaded: security_helper
INFO - 2024-12-24 06:04:12 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:04:12 --> Database Driver Class Initialized
INFO - 2024-12-24 06:04:12 --> Email Class Initialized
DEBUG - 2024-12-24 06:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:04:12 --> Helper loaded: form_helper
INFO - 2024-12-24 06:04:12 --> Form Validation Class Initialized
INFO - 2024-12-24 06:04:12 --> Controller Class Initialized
INFO - 2024-12-24 06:04:12 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:04:14 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:04:14 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:04:14 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:04:14 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:04:14 --> Final output sent to browser
DEBUG - 2024-12-24 06:04:14 --> Total execution time: 2.4762
INFO - 2024-12-24 06:04:29 --> Config Class Initialized
INFO - 2024-12-24 06:04:29 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:04:29 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:04:29 --> Utf8 Class Initialized
INFO - 2024-12-24 06:04:29 --> URI Class Initialized
INFO - 2024-12-24 06:04:29 --> Router Class Initialized
INFO - 2024-12-24 06:04:29 --> Output Class Initialized
INFO - 2024-12-24 06:04:29 --> Security Class Initialized
DEBUG - 2024-12-24 06:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:04:29 --> Input Class Initialized
INFO - 2024-12-24 06:04:29 --> Language Class Initialized
INFO - 2024-12-24 06:04:29 --> Loader Class Initialized
INFO - 2024-12-24 06:04:29 --> Helper loaded: url_helper
INFO - 2024-12-24 06:04:29 --> Helper loaded: file_helper
INFO - 2024-12-24 06:04:29 --> Helper loaded: security_helper
INFO - 2024-12-24 06:04:29 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:04:29 --> Database Driver Class Initialized
INFO - 2024-12-24 06:04:29 --> Email Class Initialized
DEBUG - 2024-12-24 06:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:04:29 --> Helper loaded: form_helper
INFO - 2024-12-24 06:04:29 --> Form Validation Class Initialized
INFO - 2024-12-24 06:04:29 --> Controller Class Initialized
INFO - 2024-12-24 06:04:29 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:04:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:04:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:04:31 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:04:31 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:04:31 --> Final output sent to browser
DEBUG - 2024-12-24 06:04:31 --> Total execution time: 2.5806
INFO - 2024-12-24 06:04:45 --> Config Class Initialized
INFO - 2024-12-24 06:04:45 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:04:45 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:04:45 --> Utf8 Class Initialized
INFO - 2024-12-24 06:04:45 --> URI Class Initialized
INFO - 2024-12-24 06:04:45 --> Router Class Initialized
INFO - 2024-12-24 06:04:45 --> Output Class Initialized
INFO - 2024-12-24 06:04:45 --> Security Class Initialized
DEBUG - 2024-12-24 06:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:04:45 --> Input Class Initialized
INFO - 2024-12-24 06:04:45 --> Language Class Initialized
INFO - 2024-12-24 06:04:45 --> Loader Class Initialized
INFO - 2024-12-24 06:04:45 --> Helper loaded: url_helper
INFO - 2024-12-24 06:04:45 --> Helper loaded: file_helper
INFO - 2024-12-24 06:04:45 --> Helper loaded: security_helper
INFO - 2024-12-24 06:04:45 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:04:45 --> Database Driver Class Initialized
INFO - 2024-12-24 06:04:45 --> Email Class Initialized
DEBUG - 2024-12-24 06:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:04:45 --> Helper loaded: form_helper
INFO - 2024-12-24 06:04:45 --> Form Validation Class Initialized
INFO - 2024-12-24 06:04:45 --> Controller Class Initialized
INFO - 2024-12-24 06:04:45 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:04:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:04:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:04:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:04:47 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:04:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:04:47 --> Final output sent to browser
DEBUG - 2024-12-24 06:04:47 --> Total execution time: 2.5346
INFO - 2024-12-24 06:05:02 --> Config Class Initialized
INFO - 2024-12-24 06:05:02 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:05:02 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:05:02 --> Utf8 Class Initialized
INFO - 2024-12-24 06:05:02 --> URI Class Initialized
INFO - 2024-12-24 06:05:02 --> Router Class Initialized
INFO - 2024-12-24 06:05:02 --> Output Class Initialized
INFO - 2024-12-24 06:05:02 --> Security Class Initialized
DEBUG - 2024-12-24 06:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:05:02 --> Input Class Initialized
INFO - 2024-12-24 06:05:02 --> Language Class Initialized
INFO - 2024-12-24 06:05:02 --> Loader Class Initialized
INFO - 2024-12-24 06:05:02 --> Helper loaded: url_helper
INFO - 2024-12-24 06:05:02 --> Helper loaded: file_helper
INFO - 2024-12-24 06:05:02 --> Helper loaded: security_helper
INFO - 2024-12-24 06:05:02 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:05:02 --> Database Driver Class Initialized
INFO - 2024-12-24 06:05:02 --> Email Class Initialized
DEBUG - 2024-12-24 06:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:05:02 --> Helper loaded: form_helper
INFO - 2024-12-24 06:05:02 --> Form Validation Class Initialized
INFO - 2024-12-24 06:05:02 --> Controller Class Initialized
INFO - 2024-12-24 06:05:02 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:05:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:05:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:05:04 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:05:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:05:04 --> Final output sent to browser
DEBUG - 2024-12-24 06:05:04 --> Total execution time: 2.6011
INFO - 2024-12-24 06:06:44 --> Config Class Initialized
INFO - 2024-12-24 06:06:44 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:06:44 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:06:44 --> Utf8 Class Initialized
INFO - 2024-12-24 06:06:44 --> URI Class Initialized
INFO - 2024-12-24 06:06:44 --> Router Class Initialized
INFO - 2024-12-24 06:06:44 --> Output Class Initialized
INFO - 2024-12-24 06:06:44 --> Security Class Initialized
DEBUG - 2024-12-24 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:06:44 --> Input Class Initialized
INFO - 2024-12-24 06:06:44 --> Language Class Initialized
INFO - 2024-12-24 06:06:44 --> Loader Class Initialized
INFO - 2024-12-24 06:06:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:06:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:06:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:06:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:06:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:06:45 --> Email Class Initialized
DEBUG - 2024-12-24 06:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:06:45 --> Helper loaded: form_helper
INFO - 2024-12-24 06:06:45 --> Form Validation Class Initialized
INFO - 2024-12-24 06:06:45 --> Controller Class Initialized
INFO - 2024-12-24 06:06:45 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:06:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:06:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:06:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:06:47 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:06:47 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:06:47 --> Final output sent to browser
DEBUG - 2024-12-24 06:06:47 --> Total execution time: 2.7789
INFO - 2024-12-24 06:08:36 --> Config Class Initialized
INFO - 2024-12-24 06:08:36 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:08:36 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:08:36 --> Utf8 Class Initialized
INFO - 2024-12-24 06:08:36 --> URI Class Initialized
INFO - 2024-12-24 06:08:36 --> Router Class Initialized
INFO - 2024-12-24 06:08:36 --> Output Class Initialized
INFO - 2024-12-24 06:08:36 --> Security Class Initialized
DEBUG - 2024-12-24 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:08:36 --> Input Class Initialized
INFO - 2024-12-24 06:08:36 --> Language Class Initialized
INFO - 2024-12-24 06:08:36 --> Loader Class Initialized
INFO - 2024-12-24 06:08:36 --> Helper loaded: url_helper
INFO - 2024-12-24 06:08:36 --> Helper loaded: file_helper
INFO - 2024-12-24 06:08:36 --> Helper loaded: security_helper
INFO - 2024-12-24 06:08:36 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:08:36 --> Database Driver Class Initialized
INFO - 2024-12-24 06:08:37 --> Email Class Initialized
DEBUG - 2024-12-24 06:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:08:37 --> Helper loaded: form_helper
INFO - 2024-12-24 06:08:37 --> Form Validation Class Initialized
INFO - 2024-12-24 06:08:37 --> Controller Class Initialized
INFO - 2024-12-24 06:08:37 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:08:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:08:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:08:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:08:39 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:08:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:08:39 --> Final output sent to browser
DEBUG - 2024-12-24 06:08:39 --> Total execution time: 2.6059
INFO - 2024-12-24 06:09:49 --> Config Class Initialized
INFO - 2024-12-24 06:09:49 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:09:49 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:09:49 --> Utf8 Class Initialized
INFO - 2024-12-24 06:09:49 --> URI Class Initialized
INFO - 2024-12-24 06:09:49 --> Router Class Initialized
INFO - 2024-12-24 06:09:49 --> Output Class Initialized
INFO - 2024-12-24 06:09:49 --> Security Class Initialized
DEBUG - 2024-12-24 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:09:49 --> Input Class Initialized
INFO - 2024-12-24 06:09:49 --> Language Class Initialized
INFO - 2024-12-24 06:09:49 --> Loader Class Initialized
INFO - 2024-12-24 06:09:49 --> Helper loaded: url_helper
INFO - 2024-12-24 06:09:49 --> Helper loaded: file_helper
INFO - 2024-12-24 06:09:49 --> Helper loaded: security_helper
INFO - 2024-12-24 06:09:49 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:09:49 --> Database Driver Class Initialized
INFO - 2024-12-24 06:09:50 --> Email Class Initialized
DEBUG - 2024-12-24 06:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:09:50 --> Helper loaded: form_helper
INFO - 2024-12-24 06:09:50 --> Form Validation Class Initialized
INFO - 2024-12-24 06:09:50 --> Controller Class Initialized
INFO - 2024-12-24 06:09:50 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:09:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:09:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:09:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:09:52 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:09:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:09:52 --> Final output sent to browser
DEBUG - 2024-12-24 06:09:52 --> Total execution time: 2.8421
INFO - 2024-12-24 06:10:44 --> Config Class Initialized
INFO - 2024-12-24 06:10:44 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:10:44 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:10:44 --> Utf8 Class Initialized
INFO - 2024-12-24 06:10:44 --> URI Class Initialized
INFO - 2024-12-24 06:10:44 --> Router Class Initialized
INFO - 2024-12-24 06:10:44 --> Output Class Initialized
INFO - 2024-12-24 06:10:44 --> Security Class Initialized
DEBUG - 2024-12-24 06:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:10:44 --> Input Class Initialized
INFO - 2024-12-24 06:10:44 --> Language Class Initialized
INFO - 2024-12-24 06:10:44 --> Loader Class Initialized
INFO - 2024-12-24 06:10:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:10:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:10:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:10:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:10:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:10:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:10:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:10:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:10:44 --> Controller Class Initialized
INFO - 2024-12-24 06:10:44 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:10:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:10:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:10:46 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:10:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:10:46 --> Final output sent to browser
DEBUG - 2024-12-24 06:10:46 --> Total execution time: 2.6330
INFO - 2024-12-24 06:10:50 --> Config Class Initialized
INFO - 2024-12-24 06:10:50 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:10:50 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:10:50 --> Utf8 Class Initialized
INFO - 2024-12-24 06:10:50 --> URI Class Initialized
INFO - 2024-12-24 06:10:50 --> Router Class Initialized
INFO - 2024-12-24 06:10:50 --> Output Class Initialized
INFO - 2024-12-24 06:10:50 --> Security Class Initialized
DEBUG - 2024-12-24 06:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:10:50 --> Input Class Initialized
INFO - 2024-12-24 06:10:50 --> Language Class Initialized
INFO - 2024-12-24 06:10:50 --> Loader Class Initialized
INFO - 2024-12-24 06:10:50 --> Helper loaded: url_helper
INFO - 2024-12-24 06:10:50 --> Helper loaded: file_helper
INFO - 2024-12-24 06:10:50 --> Helper loaded: security_helper
INFO - 2024-12-24 06:10:50 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:10:50 --> Database Driver Class Initialized
INFO - 2024-12-24 06:10:51 --> Email Class Initialized
DEBUG - 2024-12-24 06:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:10:51 --> Helper loaded: form_helper
INFO - 2024-12-24 06:10:51 --> Form Validation Class Initialized
INFO - 2024-12-24 06:10:51 --> Controller Class Initialized
DEBUG - 2024-12-24 06:10:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:10:51 --> Config Class Initialized
INFO - 2024-12-24 06:10:51 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:10:51 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:10:51 --> Utf8 Class Initialized
INFO - 2024-12-24 06:10:51 --> URI Class Initialized
INFO - 2024-12-24 06:10:51 --> Router Class Initialized
INFO - 2024-12-24 06:10:51 --> Output Class Initialized
INFO - 2024-12-24 06:10:51 --> Security Class Initialized
DEBUG - 2024-12-24 06:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:10:51 --> Input Class Initialized
INFO - 2024-12-24 06:10:51 --> Language Class Initialized
INFO - 2024-12-24 06:10:51 --> Loader Class Initialized
INFO - 2024-12-24 06:10:51 --> Helper loaded: url_helper
INFO - 2024-12-24 06:10:51 --> Helper loaded: file_helper
INFO - 2024-12-24 06:10:51 --> Helper loaded: security_helper
INFO - 2024-12-24 06:10:51 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:10:51 --> Database Driver Class Initialized
INFO - 2024-12-24 06:10:52 --> Email Class Initialized
DEBUG - 2024-12-24 06:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:10:52 --> Helper loaded: form_helper
INFO - 2024-12-24 06:10:52 --> Form Validation Class Initialized
INFO - 2024-12-24 06:10:52 --> Controller Class Initialized
DEBUG - 2024-12-24 06:10:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:10:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:10:52 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:10:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:10:52 --> Final output sent to browser
DEBUG - 2024-12-24 06:10:52 --> Total execution time: 0.6727
INFO - 2024-12-24 06:11:11 --> Config Class Initialized
INFO - 2024-12-24 06:11:11 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:11 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:11 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:11 --> URI Class Initialized
INFO - 2024-12-24 06:11:11 --> Router Class Initialized
INFO - 2024-12-24 06:11:11 --> Output Class Initialized
INFO - 2024-12-24 06:11:11 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:11 --> Input Class Initialized
INFO - 2024-12-24 06:11:11 --> Language Class Initialized
INFO - 2024-12-24 06:11:11 --> Loader Class Initialized
INFO - 2024-12-24 06:11:11 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:11 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:11 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:11 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:11 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:11 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:11:11 --> Config Class Initialized
INFO - 2024-12-24 06:11:11 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:11 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:11 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:11 --> URI Class Initialized
INFO - 2024-12-24 06:11:11 --> Router Class Initialized
INFO - 2024-12-24 06:11:11 --> Output Class Initialized
INFO - 2024-12-24 06:11:11 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:11 --> Input Class Initialized
INFO - 2024-12-24 06:11:11 --> Language Class Initialized
INFO - 2024-12-24 06:11:11 --> Loader Class Initialized
INFO - 2024-12-24 06:11:11 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:11 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:11 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:12 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:12 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:12 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:12 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:11:12 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:11:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:11:12 --> Final output sent to browser
DEBUG - 2024-12-24 06:11:12 --> Total execution time: 0.6624
INFO - 2024-12-24 06:11:21 --> Config Class Initialized
INFO - 2024-12-24 06:11:21 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:21 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:21 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:21 --> URI Class Initialized
INFO - 2024-12-24 06:11:21 --> Router Class Initialized
INFO - 2024-12-24 06:11:21 --> Output Class Initialized
INFO - 2024-12-24 06:11:21 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:21 --> Input Class Initialized
INFO - 2024-12-24 06:11:21 --> Language Class Initialized
INFO - 2024-12-24 06:11:21 --> Loader Class Initialized
INFO - 2024-12-24 06:11:21 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:21 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:21 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:21 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:21 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:21 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:21 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:21 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:21 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:11:22 --> Config Class Initialized
INFO - 2024-12-24 06:11:22 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:22 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:22 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:22 --> URI Class Initialized
INFO - 2024-12-24 06:11:22 --> Router Class Initialized
INFO - 2024-12-24 06:11:22 --> Output Class Initialized
INFO - 2024-12-24 06:11:22 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:22 --> Input Class Initialized
INFO - 2024-12-24 06:11:22 --> Language Class Initialized
INFO - 2024-12-24 06:11:22 --> Loader Class Initialized
INFO - 2024-12-24 06:11:22 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:22 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:22 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:22 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:22 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:22 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:22 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:22 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:22 --> Controller Class Initialized
INFO - 2024-12-24 06:11:22 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:11:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:24 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:11:24 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:11:24 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:11:24 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:11:24 --> Final output sent to browser
DEBUG - 2024-12-24 06:11:24 --> Total execution time: 2.6277
INFO - 2024-12-24 06:11:28 --> Config Class Initialized
INFO - 2024-12-24 06:11:28 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:28 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:28 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:28 --> URI Class Initialized
INFO - 2024-12-24 06:11:28 --> Router Class Initialized
INFO - 2024-12-24 06:11:28 --> Output Class Initialized
INFO - 2024-12-24 06:11:28 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:28 --> Input Class Initialized
INFO - 2024-12-24 06:11:28 --> Language Class Initialized
INFO - 2024-12-24 06:11:28 --> Loader Class Initialized
INFO - 2024-12-24 06:11:28 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:28 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:28 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:28 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:28 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:29 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:29 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:29 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:29 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:29 --> Config Class Initialized
INFO - 2024-12-24 06:11:29 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:29 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:29 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:29 --> URI Class Initialized
INFO - 2024-12-24 06:11:29 --> Router Class Initialized
INFO - 2024-12-24 06:11:29 --> Output Class Initialized
INFO - 2024-12-24 06:11:29 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:29 --> Input Class Initialized
INFO - 2024-12-24 06:11:29 --> Language Class Initialized
INFO - 2024-12-24 06:11:29 --> Loader Class Initialized
INFO - 2024-12-24 06:11:29 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:29 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:29 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:29 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:29 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:29 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:29 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:29 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:29 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:11:29 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:11:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:11:29 --> Final output sent to browser
DEBUG - 2024-12-24 06:11:29 --> Total execution time: 0.6408
INFO - 2024-12-24 06:11:36 --> Config Class Initialized
INFO - 2024-12-24 06:11:36 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:36 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:36 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:36 --> URI Class Initialized
INFO - 2024-12-24 06:11:36 --> Router Class Initialized
INFO - 2024-12-24 06:11:36 --> Output Class Initialized
INFO - 2024-12-24 06:11:36 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:36 --> Input Class Initialized
INFO - 2024-12-24 06:11:36 --> Language Class Initialized
INFO - 2024-12-24 06:11:36 --> Loader Class Initialized
INFO - 2024-12-24 06:11:36 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:36 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:36 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:36 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:36 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:37 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:37 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:37 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:37 --> Controller Class Initialized
DEBUG - 2024-12-24 06:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:11:37 --> Config Class Initialized
INFO - 2024-12-24 06:11:37 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:11:37 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:11:37 --> Utf8 Class Initialized
INFO - 2024-12-24 06:11:37 --> URI Class Initialized
INFO - 2024-12-24 06:11:37 --> Router Class Initialized
INFO - 2024-12-24 06:11:37 --> Output Class Initialized
INFO - 2024-12-24 06:11:37 --> Security Class Initialized
DEBUG - 2024-12-24 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:11:37 --> Input Class Initialized
INFO - 2024-12-24 06:11:37 --> Language Class Initialized
INFO - 2024-12-24 06:11:37 --> Loader Class Initialized
INFO - 2024-12-24 06:11:37 --> Helper loaded: url_helper
INFO - 2024-12-24 06:11:37 --> Helper loaded: file_helper
INFO - 2024-12-24 06:11:37 --> Helper loaded: security_helper
INFO - 2024-12-24 06:11:37 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:11:37 --> Database Driver Class Initialized
INFO - 2024-12-24 06:11:38 --> Email Class Initialized
DEBUG - 2024-12-24 06:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:11:38 --> Helper loaded: form_helper
INFO - 2024-12-24 06:11:38 --> Form Validation Class Initialized
INFO - 2024-12-24 06:11:38 --> Controller Class Initialized
INFO - 2024-12-24 06:11:38 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:11:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:11:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:11:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:11:40 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:11:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:11:40 --> Final output sent to browser
DEBUG - 2024-12-24 06:11:40 --> Total execution time: 2.4310
INFO - 2024-12-24 06:12:32 --> Config Class Initialized
INFO - 2024-12-24 06:12:32 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:12:32 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:12:32 --> Utf8 Class Initialized
INFO - 2024-12-24 06:12:32 --> URI Class Initialized
INFO - 2024-12-24 06:12:32 --> Router Class Initialized
INFO - 2024-12-24 06:12:32 --> Output Class Initialized
INFO - 2024-12-24 06:12:32 --> Security Class Initialized
DEBUG - 2024-12-24 06:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:12:32 --> Input Class Initialized
INFO - 2024-12-24 06:12:32 --> Language Class Initialized
INFO - 2024-12-24 06:12:32 --> Loader Class Initialized
INFO - 2024-12-24 06:12:32 --> Helper loaded: url_helper
INFO - 2024-12-24 06:12:32 --> Helper loaded: file_helper
INFO - 2024-12-24 06:12:32 --> Helper loaded: security_helper
INFO - 2024-12-24 06:12:32 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:12:32 --> Database Driver Class Initialized
INFO - 2024-12-24 06:12:32 --> Email Class Initialized
DEBUG - 2024-12-24 06:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:12:32 --> Helper loaded: form_helper
INFO - 2024-12-24 06:12:32 --> Form Validation Class Initialized
INFO - 2024-12-24 06:12:32 --> Controller Class Initialized
INFO - 2024-12-24 06:12:32 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:12:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:12:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:12:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:12:36 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:12:36 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:12:36 --> Final output sent to browser
DEBUG - 2024-12-24 06:12:36 --> Total execution time: 4.8891
INFO - 2024-12-24 06:12:57 --> Config Class Initialized
INFO - 2024-12-24 06:12:57 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:12:57 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:12:57 --> Utf8 Class Initialized
INFO - 2024-12-24 06:12:57 --> URI Class Initialized
INFO - 2024-12-24 06:12:57 --> Router Class Initialized
INFO - 2024-12-24 06:12:57 --> Output Class Initialized
INFO - 2024-12-24 06:12:57 --> Security Class Initialized
DEBUG - 2024-12-24 06:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:12:57 --> Input Class Initialized
INFO - 2024-12-24 06:12:57 --> Language Class Initialized
ERROR - 2024-12-24 06:12:57 --> 404 Page Not Found: Rawat_jalan/index
INFO - 2024-12-24 06:12:58 --> Config Class Initialized
INFO - 2024-12-24 06:12:58 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:12:58 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:12:58 --> Utf8 Class Initialized
INFO - 2024-12-24 06:12:58 --> URI Class Initialized
INFO - 2024-12-24 06:12:58 --> Router Class Initialized
INFO - 2024-12-24 06:12:58 --> Output Class Initialized
INFO - 2024-12-24 06:12:58 --> Security Class Initialized
DEBUG - 2024-12-24 06:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:12:58 --> Input Class Initialized
INFO - 2024-12-24 06:12:58 --> Language Class Initialized
INFO - 2024-12-24 06:12:58 --> Loader Class Initialized
INFO - 2024-12-24 06:12:58 --> Helper loaded: url_helper
INFO - 2024-12-24 06:12:58 --> Helper loaded: file_helper
INFO - 2024-12-24 06:12:58 --> Helper loaded: security_helper
INFO - 2024-12-24 06:12:58 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:12:58 --> Database Driver Class Initialized
INFO - 2024-12-24 06:12:59 --> Email Class Initialized
DEBUG - 2024-12-24 06:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:12:59 --> Helper loaded: form_helper
INFO - 2024-12-24 06:12:59 --> Form Validation Class Initialized
INFO - 2024-12-24 06:12:59 --> Controller Class Initialized
INFO - 2024-12-24 06:12:59 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:12:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:00 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:00 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:00 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:01 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:01 --> Total execution time: 2.5016
INFO - 2024-12-24 06:13:12 --> Config Class Initialized
INFO - 2024-12-24 06:13:12 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:13:12 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:13:12 --> Utf8 Class Initialized
INFO - 2024-12-24 06:13:12 --> URI Class Initialized
INFO - 2024-12-24 06:13:12 --> Router Class Initialized
INFO - 2024-12-24 06:13:12 --> Output Class Initialized
INFO - 2024-12-24 06:13:12 --> Security Class Initialized
DEBUG - 2024-12-24 06:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:13:12 --> Input Class Initialized
INFO - 2024-12-24 06:13:12 --> Language Class Initialized
INFO - 2024-12-24 06:13:12 --> Loader Class Initialized
INFO - 2024-12-24 06:13:12 --> Helper loaded: url_helper
INFO - 2024-12-24 06:13:12 --> Helper loaded: file_helper
INFO - 2024-12-24 06:13:12 --> Helper loaded: security_helper
INFO - 2024-12-24 06:13:12 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:13:12 --> Database Driver Class Initialized
INFO - 2024-12-24 06:13:13 --> Email Class Initialized
DEBUG - 2024-12-24 06:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:13:13 --> Helper loaded: form_helper
INFO - 2024-12-24 06:13:13 --> Form Validation Class Initialized
INFO - 2024-12-24 06:13:13 --> Controller Class Initialized
INFO - 2024-12-24 06:13:13 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:13:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:15 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:15 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:15 --> Total execution time: 2.3629
INFO - 2024-12-24 06:13:22 --> Config Class Initialized
INFO - 2024-12-24 06:13:22 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:13:22 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:13:22 --> Utf8 Class Initialized
INFO - 2024-12-24 06:13:22 --> URI Class Initialized
INFO - 2024-12-24 06:13:22 --> Router Class Initialized
INFO - 2024-12-24 06:13:22 --> Output Class Initialized
INFO - 2024-12-24 06:13:22 --> Security Class Initialized
DEBUG - 2024-12-24 06:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:13:22 --> Input Class Initialized
INFO - 2024-12-24 06:13:22 --> Language Class Initialized
INFO - 2024-12-24 06:13:22 --> Loader Class Initialized
INFO - 2024-12-24 06:13:22 --> Helper loaded: url_helper
INFO - 2024-12-24 06:13:22 --> Helper loaded: file_helper
INFO - 2024-12-24 06:13:22 --> Helper loaded: security_helper
INFO - 2024-12-24 06:13:22 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:13:22 --> Database Driver Class Initialized
INFO - 2024-12-24 06:13:23 --> Email Class Initialized
DEBUG - 2024-12-24 06:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:13:23 --> Helper loaded: form_helper
INFO - 2024-12-24 06:13:23 --> Form Validation Class Initialized
INFO - 2024-12-24 06:13:23 --> Controller Class Initialized
INFO - 2024-12-24 06:13:23 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:13:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:25 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:25 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:25 --> Total execution time: 2.3364
INFO - 2024-12-24 06:13:30 --> Config Class Initialized
INFO - 2024-12-24 06:13:30 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:13:30 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:13:30 --> Utf8 Class Initialized
INFO - 2024-12-24 06:13:30 --> URI Class Initialized
INFO - 2024-12-24 06:13:30 --> Router Class Initialized
INFO - 2024-12-24 06:13:30 --> Output Class Initialized
INFO - 2024-12-24 06:13:30 --> Security Class Initialized
DEBUG - 2024-12-24 06:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:13:30 --> Input Class Initialized
INFO - 2024-12-24 06:13:30 --> Language Class Initialized
INFO - 2024-12-24 06:13:30 --> Loader Class Initialized
INFO - 2024-12-24 06:13:30 --> Helper loaded: url_helper
INFO - 2024-12-24 06:13:30 --> Helper loaded: file_helper
INFO - 2024-12-24 06:13:30 --> Helper loaded: security_helper
INFO - 2024-12-24 06:13:30 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:13:30 --> Database Driver Class Initialized
INFO - 2024-12-24 06:13:30 --> Email Class Initialized
DEBUG - 2024-12-24 06:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:13:30 --> Helper loaded: form_helper
INFO - 2024-12-24 06:13:30 --> Form Validation Class Initialized
INFO - 2024-12-24 06:13:30 --> Controller Class Initialized
INFO - 2024-12-24 06:13:30 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:13:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:32 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:32 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:32 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:32 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:32 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:32 --> Total execution time: 2.6420
INFO - 2024-12-24 06:13:42 --> Config Class Initialized
INFO - 2024-12-24 06:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:13:42 --> Utf8 Class Initialized
INFO - 2024-12-24 06:13:42 --> URI Class Initialized
INFO - 2024-12-24 06:13:42 --> Router Class Initialized
INFO - 2024-12-24 06:13:42 --> Output Class Initialized
INFO - 2024-12-24 06:13:42 --> Security Class Initialized
DEBUG - 2024-12-24 06:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:13:42 --> Input Class Initialized
INFO - 2024-12-24 06:13:42 --> Language Class Initialized
INFO - 2024-12-24 06:13:42 --> Loader Class Initialized
INFO - 2024-12-24 06:13:42 --> Helper loaded: url_helper
INFO - 2024-12-24 06:13:42 --> Helper loaded: file_helper
INFO - 2024-12-24 06:13:42 --> Helper loaded: security_helper
INFO - 2024-12-24 06:13:42 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:13:42 --> Database Driver Class Initialized
INFO - 2024-12-24 06:13:43 --> Email Class Initialized
DEBUG - 2024-12-24 06:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:13:43 --> Helper loaded: form_helper
INFO - 2024-12-24 06:13:43 --> Form Validation Class Initialized
INFO - 2024-12-24 06:13:43 --> Controller Class Initialized
INFO - 2024-12-24 06:13:43 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:13:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:44 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:44 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:44 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:44 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:44 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:44 --> Total execution time: 2.3063
INFO - 2024-12-24 06:13:47 --> Config Class Initialized
INFO - 2024-12-24 06:13:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:13:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:13:47 --> Utf8 Class Initialized
INFO - 2024-12-24 06:13:47 --> URI Class Initialized
INFO - 2024-12-24 06:13:47 --> Router Class Initialized
INFO - 2024-12-24 06:13:47 --> Output Class Initialized
INFO - 2024-12-24 06:13:47 --> Security Class Initialized
DEBUG - 2024-12-24 06:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:13:47 --> Input Class Initialized
INFO - 2024-12-24 06:13:47 --> Language Class Initialized
INFO - 2024-12-24 06:13:47 --> Loader Class Initialized
INFO - 2024-12-24 06:13:47 --> Helper loaded: url_helper
INFO - 2024-12-24 06:13:47 --> Helper loaded: file_helper
INFO - 2024-12-24 06:13:47 --> Helper loaded: security_helper
INFO - 2024-12-24 06:13:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:13:47 --> Database Driver Class Initialized
INFO - 2024-12-24 06:13:48 --> Email Class Initialized
DEBUG - 2024-12-24 06:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:13:48 --> Helper loaded: form_helper
INFO - 2024-12-24 06:13:48 --> Form Validation Class Initialized
INFO - 2024-12-24 06:13:48 --> Controller Class Initialized
INFO - 2024-12-24 06:13:48 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:13:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:13:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:13:49 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:13:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:13:49 --> Final output sent to browser
DEBUG - 2024-12-24 06:13:49 --> Total execution time: 2.3183
INFO - 2024-12-24 06:14:08 --> Config Class Initialized
INFO - 2024-12-24 06:14:08 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:14:08 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:14:08 --> Utf8 Class Initialized
INFO - 2024-12-24 06:14:08 --> URI Class Initialized
INFO - 2024-12-24 06:14:08 --> Router Class Initialized
INFO - 2024-12-24 06:14:08 --> Output Class Initialized
INFO - 2024-12-24 06:14:08 --> Security Class Initialized
DEBUG - 2024-12-24 06:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:14:08 --> Input Class Initialized
INFO - 2024-12-24 06:14:08 --> Language Class Initialized
INFO - 2024-12-24 06:14:08 --> Loader Class Initialized
INFO - 2024-12-24 06:14:08 --> Helper loaded: url_helper
INFO - 2024-12-24 06:14:08 --> Helper loaded: file_helper
INFO - 2024-12-24 06:14:08 --> Helper loaded: security_helper
INFO - 2024-12-24 06:14:08 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:14:08 --> Database Driver Class Initialized
INFO - 2024-12-24 06:14:08 --> Email Class Initialized
DEBUG - 2024-12-24 06:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:14:08 --> Helper loaded: form_helper
INFO - 2024-12-24 06:14:08 --> Form Validation Class Initialized
INFO - 2024-12-24 06:14:08 --> Controller Class Initialized
INFO - 2024-12-24 06:14:08 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:14:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:14:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:14:10 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:14:10 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:14:10 --> Final output sent to browser
DEBUG - 2024-12-24 06:14:10 --> Total execution time: 2.3836
INFO - 2024-12-24 06:15:17 --> Config Class Initialized
INFO - 2024-12-24 06:15:17 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:15:17 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:15:17 --> Utf8 Class Initialized
INFO - 2024-12-24 06:15:17 --> URI Class Initialized
INFO - 2024-12-24 06:15:17 --> Router Class Initialized
INFO - 2024-12-24 06:15:17 --> Output Class Initialized
INFO - 2024-12-24 06:15:17 --> Security Class Initialized
DEBUG - 2024-12-24 06:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:15:17 --> Input Class Initialized
INFO - 2024-12-24 06:15:17 --> Language Class Initialized
INFO - 2024-12-24 06:15:17 --> Loader Class Initialized
INFO - 2024-12-24 06:15:17 --> Helper loaded: url_helper
INFO - 2024-12-24 06:15:17 --> Helper loaded: file_helper
INFO - 2024-12-24 06:15:17 --> Helper loaded: security_helper
INFO - 2024-12-24 06:15:17 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:15:17 --> Database Driver Class Initialized
INFO - 2024-12-24 06:15:17 --> Email Class Initialized
DEBUG - 2024-12-24 06:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:15:17 --> Helper loaded: form_helper
INFO - 2024-12-24 06:15:17 --> Form Validation Class Initialized
INFO - 2024-12-24 06:15:17 --> Controller Class Initialized
INFO - 2024-12-24 06:15:17 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:15:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:15:19 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:15:19 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:15:19 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:15:19 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:15:19 --> Final output sent to browser
DEBUG - 2024-12-24 06:15:19 --> Total execution time: 2.6033
INFO - 2024-12-24 06:15:27 --> Config Class Initialized
INFO - 2024-12-24 06:15:27 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:15:27 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:15:27 --> Utf8 Class Initialized
INFO - 2024-12-24 06:15:27 --> URI Class Initialized
INFO - 2024-12-24 06:15:27 --> Router Class Initialized
INFO - 2024-12-24 06:15:27 --> Output Class Initialized
INFO - 2024-12-24 06:15:27 --> Security Class Initialized
DEBUG - 2024-12-24 06:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:15:27 --> Input Class Initialized
INFO - 2024-12-24 06:15:27 --> Language Class Initialized
INFO - 2024-12-24 06:15:27 --> Loader Class Initialized
INFO - 2024-12-24 06:15:27 --> Helper loaded: url_helper
INFO - 2024-12-24 06:15:27 --> Helper loaded: file_helper
INFO - 2024-12-24 06:15:27 --> Helper loaded: security_helper
INFO - 2024-12-24 06:15:27 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:15:27 --> Database Driver Class Initialized
INFO - 2024-12-24 06:15:27 --> Email Class Initialized
DEBUG - 2024-12-24 06:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:15:27 --> Helper loaded: form_helper
INFO - 2024-12-24 06:15:27 --> Form Validation Class Initialized
INFO - 2024-12-24 06:15:27 --> Controller Class Initialized
INFO - 2024-12-24 06:15:27 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:15:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:15:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:15:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:15:29 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:15:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:15:29 --> Final output sent to browser
DEBUG - 2024-12-24 06:15:29 --> Total execution time: 2.7028
INFO - 2024-12-24 06:15:54 --> Config Class Initialized
INFO - 2024-12-24 06:15:54 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:15:54 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:15:54 --> Utf8 Class Initialized
INFO - 2024-12-24 06:15:54 --> URI Class Initialized
INFO - 2024-12-24 06:15:54 --> Router Class Initialized
INFO - 2024-12-24 06:15:54 --> Output Class Initialized
INFO - 2024-12-24 06:15:54 --> Security Class Initialized
DEBUG - 2024-12-24 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:15:54 --> Input Class Initialized
INFO - 2024-12-24 06:15:54 --> Language Class Initialized
INFO - 2024-12-24 06:15:54 --> Loader Class Initialized
INFO - 2024-12-24 06:15:54 --> Helper loaded: url_helper
INFO - 2024-12-24 06:15:54 --> Helper loaded: file_helper
INFO - 2024-12-24 06:15:54 --> Helper loaded: security_helper
INFO - 2024-12-24 06:15:54 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:15:54 --> Database Driver Class Initialized
INFO - 2024-12-24 06:15:55 --> Email Class Initialized
DEBUG - 2024-12-24 06:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:15:55 --> Helper loaded: form_helper
INFO - 2024-12-24 06:15:55 --> Form Validation Class Initialized
INFO - 2024-12-24 06:15:55 --> Controller Class Initialized
INFO - 2024-12-24 06:15:55 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:15:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:15:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:15:57 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:15:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:15:57 --> Final output sent to browser
DEBUG - 2024-12-24 06:15:57 --> Total execution time: 2.6468
INFO - 2024-12-24 06:16:34 --> Config Class Initialized
INFO - 2024-12-24 06:16:34 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:16:34 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:16:34 --> Utf8 Class Initialized
INFO - 2024-12-24 06:16:34 --> URI Class Initialized
INFO - 2024-12-24 06:16:34 --> Router Class Initialized
INFO - 2024-12-24 06:16:34 --> Output Class Initialized
INFO - 2024-12-24 06:16:34 --> Security Class Initialized
DEBUG - 2024-12-24 06:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:16:34 --> Input Class Initialized
INFO - 2024-12-24 06:16:34 --> Language Class Initialized
INFO - 2024-12-24 06:16:34 --> Loader Class Initialized
INFO - 2024-12-24 06:16:34 --> Helper loaded: url_helper
INFO - 2024-12-24 06:16:34 --> Helper loaded: file_helper
INFO - 2024-12-24 06:16:34 --> Helper loaded: security_helper
INFO - 2024-12-24 06:16:34 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:16:34 --> Database Driver Class Initialized
INFO - 2024-12-24 06:16:34 --> Email Class Initialized
DEBUG - 2024-12-24 06:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:16:34 --> Helper loaded: form_helper
INFO - 2024-12-24 06:16:34 --> Form Validation Class Initialized
INFO - 2024-12-24 06:16:34 --> Controller Class Initialized
INFO - 2024-12-24 06:16:34 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:16:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:16:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:16:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:16:37 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:16:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:16:37 --> Final output sent to browser
DEBUG - 2024-12-24 06:16:37 --> Total execution time: 2.7643
INFO - 2024-12-24 06:16:47 --> Config Class Initialized
INFO - 2024-12-24 06:16:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:16:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:16:47 --> Utf8 Class Initialized
INFO - 2024-12-24 06:16:47 --> URI Class Initialized
INFO - 2024-12-24 06:16:47 --> Router Class Initialized
INFO - 2024-12-24 06:16:47 --> Output Class Initialized
INFO - 2024-12-24 06:16:47 --> Security Class Initialized
DEBUG - 2024-12-24 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:16:47 --> Input Class Initialized
INFO - 2024-12-24 06:16:47 --> Language Class Initialized
INFO - 2024-12-24 06:16:47 --> Loader Class Initialized
INFO - 2024-12-24 06:16:47 --> Helper loaded: url_helper
INFO - 2024-12-24 06:16:47 --> Helper loaded: file_helper
INFO - 2024-12-24 06:16:47 --> Helper loaded: security_helper
INFO - 2024-12-24 06:16:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:16:47 --> Database Driver Class Initialized
INFO - 2024-12-24 06:16:48 --> Email Class Initialized
DEBUG - 2024-12-24 06:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:16:48 --> Helper loaded: form_helper
INFO - 2024-12-24 06:16:48 --> Form Validation Class Initialized
INFO - 2024-12-24 06:16:48 --> Controller Class Initialized
INFO - 2024-12-24 06:16:48 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:16:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:16:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:16:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:16:50 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:16:50 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:16:50 --> Final output sent to browser
DEBUG - 2024-12-24 06:16:50 --> Total execution time: 2.6342
INFO - 2024-12-24 06:17:03 --> Config Class Initialized
INFO - 2024-12-24 06:17:03 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:03 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:03 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:03 --> URI Class Initialized
INFO - 2024-12-24 06:17:03 --> Router Class Initialized
INFO - 2024-12-24 06:17:03 --> Output Class Initialized
INFO - 2024-12-24 06:17:03 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:03 --> Input Class Initialized
INFO - 2024-12-24 06:17:03 --> Language Class Initialized
INFO - 2024-12-24 06:17:03 --> Loader Class Initialized
INFO - 2024-12-24 06:17:03 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:03 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:03 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:03 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:03 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:04 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:04 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:04 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:04 --> Controller Class Initialized
DEBUG - 2024-12-24 06:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:04 --> Config Class Initialized
INFO - 2024-12-24 06:17:04 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:04 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:04 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:04 --> URI Class Initialized
INFO - 2024-12-24 06:17:04 --> Router Class Initialized
INFO - 2024-12-24 06:17:04 --> Output Class Initialized
INFO - 2024-12-24 06:17:04 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:04 --> Input Class Initialized
INFO - 2024-12-24 06:17:04 --> Language Class Initialized
INFO - 2024-12-24 06:17:04 --> Loader Class Initialized
INFO - 2024-12-24 06:17:04 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:04 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:04 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:04 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:04 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:05 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:05 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:05 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:05 --> Controller Class Initialized
DEBUG - 2024-12-24 06:17:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:17:05 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:17:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:17:05 --> Final output sent to browser
DEBUG - 2024-12-24 06:17:05 --> Total execution time: 0.7186
INFO - 2024-12-24 06:17:06 --> Config Class Initialized
INFO - 2024-12-24 06:17:06 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:06 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:06 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:06 --> URI Class Initialized
INFO - 2024-12-24 06:17:06 --> Router Class Initialized
INFO - 2024-12-24 06:17:06 --> Output Class Initialized
INFO - 2024-12-24 06:17:06 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:06 --> Input Class Initialized
INFO - 2024-12-24 06:17:06 --> Language Class Initialized
INFO - 2024-12-24 06:17:06 --> Loader Class Initialized
INFO - 2024-12-24 06:17:06 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:06 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:06 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:06 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:06 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:07 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:07 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:07 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:07 --> Controller Class Initialized
DEBUG - 2024-12-24 06:17:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:17:07 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:17:07 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:17:07 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:17:07 --> Final output sent to browser
DEBUG - 2024-12-24 06:17:07 --> Total execution time: 0.6430
INFO - 2024-12-24 06:17:13 --> Config Class Initialized
INFO - 2024-12-24 06:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:13 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:13 --> URI Class Initialized
INFO - 2024-12-24 06:17:13 --> Router Class Initialized
INFO - 2024-12-24 06:17:13 --> Output Class Initialized
INFO - 2024-12-24 06:17:13 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:13 --> Input Class Initialized
INFO - 2024-12-24 06:17:13 --> Language Class Initialized
INFO - 2024-12-24 06:17:13 --> Loader Class Initialized
INFO - 2024-12-24 06:17:13 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:13 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:13 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:13 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:13 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:13 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:13 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:13 --> Controller Class Initialized
DEBUG - 2024-12-24 06:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:17:13 --> Config Class Initialized
INFO - 2024-12-24 06:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:14 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:14 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:14 --> URI Class Initialized
INFO - 2024-12-24 06:17:14 --> Router Class Initialized
INFO - 2024-12-24 06:17:14 --> Output Class Initialized
INFO - 2024-12-24 06:17:14 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:14 --> Input Class Initialized
INFO - 2024-12-24 06:17:14 --> Language Class Initialized
INFO - 2024-12-24 06:17:14 --> Loader Class Initialized
INFO - 2024-12-24 06:17:14 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:14 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:14 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:14 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:14 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:14 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:14 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:14 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:14 --> Controller Class Initialized
INFO - 2024-12-24 06:17:14 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:17:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:17:16 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:17:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:17:16 --> Final output sent to browser
DEBUG - 2024-12-24 06:17:16 --> Total execution time: 2.3178
INFO - 2024-12-24 06:17:44 --> Config Class Initialized
INFO - 2024-12-24 06:17:44 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:17:44 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:17:44 --> Utf8 Class Initialized
INFO - 2024-12-24 06:17:44 --> URI Class Initialized
INFO - 2024-12-24 06:17:44 --> Router Class Initialized
INFO - 2024-12-24 06:17:44 --> Output Class Initialized
INFO - 2024-12-24 06:17:44 --> Security Class Initialized
DEBUG - 2024-12-24 06:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:17:44 --> Input Class Initialized
INFO - 2024-12-24 06:17:44 --> Language Class Initialized
INFO - 2024-12-24 06:17:44 --> Loader Class Initialized
INFO - 2024-12-24 06:17:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:17:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:17:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:17:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:17:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:17:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:17:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:17:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:17:44 --> Controller Class Initialized
INFO - 2024-12-24 06:17:44 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:17:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:17:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:17:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:17:46 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:17:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:17:46 --> Final output sent to browser
DEBUG - 2024-12-24 06:17:46 --> Total execution time: 2.7024
INFO - 2024-12-24 06:18:13 --> Config Class Initialized
INFO - 2024-12-24 06:18:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:18:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:18:13 --> Utf8 Class Initialized
INFO - 2024-12-24 06:18:13 --> URI Class Initialized
INFO - 2024-12-24 06:18:13 --> Router Class Initialized
INFO - 2024-12-24 06:18:13 --> Output Class Initialized
INFO - 2024-12-24 06:18:13 --> Security Class Initialized
DEBUG - 2024-12-24 06:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:18:13 --> Input Class Initialized
INFO - 2024-12-24 06:18:13 --> Language Class Initialized
INFO - 2024-12-24 06:18:13 --> Loader Class Initialized
INFO - 2024-12-24 06:18:13 --> Helper loaded: url_helper
INFO - 2024-12-24 06:18:13 --> Helper loaded: file_helper
INFO - 2024-12-24 06:18:13 --> Helper loaded: security_helper
INFO - 2024-12-24 06:18:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:18:13 --> Database Driver Class Initialized
INFO - 2024-12-24 06:18:14 --> Email Class Initialized
DEBUG - 2024-12-24 06:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:18:14 --> Helper loaded: form_helper
INFO - 2024-12-24 06:18:14 --> Form Validation Class Initialized
INFO - 2024-12-24 06:18:14 --> Controller Class Initialized
INFO - 2024-12-24 06:18:14 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:18:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:18:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:18:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:18:16 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:18:16 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:18:16 --> Final output sent to browser
DEBUG - 2024-12-24 06:18:16 --> Total execution time: 2.4813
INFO - 2024-12-24 06:18:43 --> Config Class Initialized
INFO - 2024-12-24 06:18:43 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:18:43 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:18:43 --> Utf8 Class Initialized
INFO - 2024-12-24 06:18:43 --> URI Class Initialized
INFO - 2024-12-24 06:18:43 --> Router Class Initialized
INFO - 2024-12-24 06:18:43 --> Output Class Initialized
INFO - 2024-12-24 06:18:43 --> Security Class Initialized
DEBUG - 2024-12-24 06:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:18:43 --> Input Class Initialized
INFO - 2024-12-24 06:18:43 --> Language Class Initialized
INFO - 2024-12-24 06:18:43 --> Loader Class Initialized
INFO - 2024-12-24 06:18:43 --> Helper loaded: url_helper
INFO - 2024-12-24 06:18:43 --> Helper loaded: file_helper
INFO - 2024-12-24 06:18:43 --> Helper loaded: security_helper
INFO - 2024-12-24 06:18:43 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:18:43 --> Database Driver Class Initialized
INFO - 2024-12-24 06:18:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:18:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:18:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:18:44 --> Controller Class Initialized
INFO - 2024-12-24 06:18:44 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:18:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:18:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:18:46 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:18:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:18:46 --> Final output sent to browser
DEBUG - 2024-12-24 06:18:46 --> Total execution time: 2.5436
INFO - 2024-12-24 06:19:25 --> Config Class Initialized
INFO - 2024-12-24 06:19:25 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:19:25 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:19:25 --> Utf8 Class Initialized
INFO - 2024-12-24 06:19:25 --> URI Class Initialized
INFO - 2024-12-24 06:19:25 --> Router Class Initialized
INFO - 2024-12-24 06:19:25 --> Output Class Initialized
INFO - 2024-12-24 06:19:25 --> Security Class Initialized
DEBUG - 2024-12-24 06:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:19:25 --> Input Class Initialized
INFO - 2024-12-24 06:19:25 --> Language Class Initialized
INFO - 2024-12-24 06:19:25 --> Loader Class Initialized
INFO - 2024-12-24 06:19:25 --> Helper loaded: url_helper
INFO - 2024-12-24 06:19:25 --> Helper loaded: file_helper
INFO - 2024-12-24 06:19:25 --> Helper loaded: security_helper
INFO - 2024-12-24 06:19:25 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:19:25 --> Database Driver Class Initialized
INFO - 2024-12-24 06:19:25 --> Email Class Initialized
DEBUG - 2024-12-24 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:19:25 --> Helper loaded: form_helper
INFO - 2024-12-24 06:19:25 --> Form Validation Class Initialized
INFO - 2024-12-24 06:19:25 --> Controller Class Initialized
INFO - 2024-12-24 06:19:25 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:19:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:19:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:19:27 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:19:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:19:27 --> Final output sent to browser
DEBUG - 2024-12-24 06:19:27 --> Total execution time: 2.2546
INFO - 2024-12-24 06:20:13 --> Config Class Initialized
INFO - 2024-12-24 06:20:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:20:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:20:13 --> Utf8 Class Initialized
INFO - 2024-12-24 06:20:13 --> URI Class Initialized
INFO - 2024-12-24 06:20:13 --> Router Class Initialized
INFO - 2024-12-24 06:20:13 --> Output Class Initialized
INFO - 2024-12-24 06:20:13 --> Security Class Initialized
DEBUG - 2024-12-24 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:20:13 --> Input Class Initialized
INFO - 2024-12-24 06:20:13 --> Language Class Initialized
ERROR - 2024-12-24 06:20:13 --> 404 Page Not Found: Rawat_inap/index
INFO - 2024-12-24 06:20:16 --> Config Class Initialized
INFO - 2024-12-24 06:20:16 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:20:16 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:20:16 --> Utf8 Class Initialized
INFO - 2024-12-24 06:20:16 --> URI Class Initialized
INFO - 2024-12-24 06:20:16 --> Router Class Initialized
INFO - 2024-12-24 06:20:16 --> Output Class Initialized
INFO - 2024-12-24 06:20:16 --> Security Class Initialized
DEBUG - 2024-12-24 06:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:20:16 --> Input Class Initialized
INFO - 2024-12-24 06:20:16 --> Language Class Initialized
INFO - 2024-12-24 06:20:16 --> Loader Class Initialized
INFO - 2024-12-24 06:20:16 --> Helper loaded: url_helper
INFO - 2024-12-24 06:20:16 --> Helper loaded: file_helper
INFO - 2024-12-24 06:20:16 --> Helper loaded: security_helper
INFO - 2024-12-24 06:20:16 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:20:16 --> Database Driver Class Initialized
INFO - 2024-12-24 06:20:16 --> Email Class Initialized
DEBUG - 2024-12-24 06:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:20:16 --> Helper loaded: form_helper
INFO - 2024-12-24 06:20:16 --> Form Validation Class Initialized
INFO - 2024-12-24 06:20:16 --> Controller Class Initialized
INFO - 2024-12-24 06:20:16 --> Model "Antrol_model" initialized
DEBUG - 2024-12-24 06:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:20:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:20:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:20:18 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:20:18 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:20:18 --> Final output sent to browser
DEBUG - 2024-12-24 06:20:18 --> Total execution time: 2.6569
INFO - 2024-12-24 06:22:55 --> Config Class Initialized
INFO - 2024-12-24 06:22:55 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:22:55 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:22:55 --> Utf8 Class Initialized
INFO - 2024-12-24 06:22:55 --> URI Class Initialized
INFO - 2024-12-24 06:22:55 --> Router Class Initialized
INFO - 2024-12-24 06:22:55 --> Output Class Initialized
INFO - 2024-12-24 06:22:55 --> Security Class Initialized
DEBUG - 2024-12-24 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:22:55 --> Input Class Initialized
INFO - 2024-12-24 06:22:55 --> Language Class Initialized
ERROR - 2024-12-24 06:22:55 --> 404 Page Not Found: Antrol/data
INFO - 2024-12-24 06:22:56 --> Config Class Initialized
INFO - 2024-12-24 06:22:56 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:22:56 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:22:56 --> Utf8 Class Initialized
INFO - 2024-12-24 06:22:56 --> URI Class Initialized
INFO - 2024-12-24 06:22:56 --> Router Class Initialized
INFO - 2024-12-24 06:22:56 --> Output Class Initialized
INFO - 2024-12-24 06:22:56 --> Security Class Initialized
DEBUG - 2024-12-24 06:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:22:56 --> Input Class Initialized
INFO - 2024-12-24 06:22:56 --> Language Class Initialized
ERROR - 2024-12-24 06:22:56 --> 404 Page Not Found: Antrol/data
INFO - 2024-12-24 06:22:56 --> Config Class Initialized
INFO - 2024-12-24 06:22:56 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:22:56 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:22:56 --> Utf8 Class Initialized
INFO - 2024-12-24 06:22:56 --> URI Class Initialized
INFO - 2024-12-24 06:22:56 --> Router Class Initialized
INFO - 2024-12-24 06:22:56 --> Output Class Initialized
INFO - 2024-12-24 06:22:56 --> Security Class Initialized
DEBUG - 2024-12-24 06:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:22:56 --> Input Class Initialized
INFO - 2024-12-24 06:22:56 --> Language Class Initialized
ERROR - 2024-12-24 06:22:56 --> 404 Page Not Found: Antrol/data
INFO - 2024-12-24 06:22:58 --> Config Class Initialized
INFO - 2024-12-24 06:22:58 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:22:58 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:22:58 --> Utf8 Class Initialized
INFO - 2024-12-24 06:22:58 --> URI Class Initialized
INFO - 2024-12-24 06:22:58 --> Router Class Initialized
INFO - 2024-12-24 06:22:58 --> Output Class Initialized
INFO - 2024-12-24 06:22:58 --> Security Class Initialized
DEBUG - 2024-12-24 06:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:22:58 --> Input Class Initialized
INFO - 2024-12-24 06:22:58 --> Language Class Initialized
ERROR - 2024-12-24 06:22:58 --> 404 Page Not Found: Data/index
INFO - 2024-12-24 06:23:00 --> Config Class Initialized
INFO - 2024-12-24 06:23:00 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:23:00 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:23:00 --> Utf8 Class Initialized
INFO - 2024-12-24 06:23:00 --> URI Class Initialized
DEBUG - 2024-12-24 06:23:00 --> No URI present. Default controller set.
INFO - 2024-12-24 06:23:00 --> Router Class Initialized
INFO - 2024-12-24 06:23:00 --> Output Class Initialized
INFO - 2024-12-24 06:23:00 --> Security Class Initialized
DEBUG - 2024-12-24 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:23:00 --> Input Class Initialized
INFO - 2024-12-24 06:23:00 --> Language Class Initialized
INFO - 2024-12-24 06:23:00 --> Loader Class Initialized
INFO - 2024-12-24 06:23:00 --> Helper loaded: url_helper
INFO - 2024-12-24 06:23:00 --> Helper loaded: file_helper
INFO - 2024-12-24 06:23:00 --> Helper loaded: security_helper
INFO - 2024-12-24 06:23:00 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:23:00 --> Database Driver Class Initialized
INFO - 2024-12-24 06:23:01 --> Email Class Initialized
DEBUG - 2024-12-24 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:23:01 --> Helper loaded: form_helper
INFO - 2024-12-24 06:23:01 --> Form Validation Class Initialized
INFO - 2024-12-24 06:23:01 --> Controller Class Initialized
DEBUG - 2024-12-24 06:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:23:01 --> Config Class Initialized
INFO - 2024-12-24 06:23:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:23:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:23:01 --> Utf8 Class Initialized
INFO - 2024-12-24 06:23:01 --> URI Class Initialized
INFO - 2024-12-24 06:23:01 --> Router Class Initialized
INFO - 2024-12-24 06:23:01 --> Output Class Initialized
INFO - 2024-12-24 06:23:01 --> Security Class Initialized
DEBUG - 2024-12-24 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:23:01 --> Input Class Initialized
INFO - 2024-12-24 06:23:01 --> Language Class Initialized
ERROR - 2024-12-24 06:23:01 --> 404 Page Not Found: User/index
INFO - 2024-12-24 06:24:21 --> Config Class Initialized
INFO - 2024-12-24 06:24:21 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:24:21 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:24:21 --> Utf8 Class Initialized
INFO - 2024-12-24 06:24:21 --> URI Class Initialized
INFO - 2024-12-24 06:24:21 --> Router Class Initialized
INFO - 2024-12-24 06:24:21 --> Output Class Initialized
INFO - 2024-12-24 06:24:21 --> Security Class Initialized
DEBUG - 2024-12-24 06:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:24:22 --> Input Class Initialized
INFO - 2024-12-24 06:24:22 --> Language Class Initialized
ERROR - 2024-12-24 06:24:22 --> 404 Page Not Found: Logout/index
INFO - 2024-12-24 06:24:25 --> Config Class Initialized
INFO - 2024-12-24 06:24:25 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:24:25 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:24:25 --> Utf8 Class Initialized
INFO - 2024-12-24 06:24:25 --> URI Class Initialized
INFO - 2024-12-24 06:24:25 --> Router Class Initialized
INFO - 2024-12-24 06:24:25 --> Output Class Initialized
INFO - 2024-12-24 06:24:25 --> Security Class Initialized
DEBUG - 2024-12-24 06:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:24:25 --> Input Class Initialized
INFO - 2024-12-24 06:24:25 --> Language Class Initialized
INFO - 2024-12-24 06:24:25 --> Loader Class Initialized
INFO - 2024-12-24 06:24:25 --> Helper loaded: url_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: file_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: security_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:24:25 --> Database Driver Class Initialized
INFO - 2024-12-24 06:24:25 --> Email Class Initialized
DEBUG - 2024-12-24 06:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:24:25 --> Helper loaded: form_helper
INFO - 2024-12-24 06:24:25 --> Form Validation Class Initialized
INFO - 2024-12-24 06:24:25 --> Controller Class Initialized
DEBUG - 2024-12-24 06:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:24:25 --> Config Class Initialized
INFO - 2024-12-24 06:24:25 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:24:25 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:24:25 --> Utf8 Class Initialized
INFO - 2024-12-24 06:24:25 --> URI Class Initialized
INFO - 2024-12-24 06:24:25 --> Router Class Initialized
INFO - 2024-12-24 06:24:25 --> Output Class Initialized
INFO - 2024-12-24 06:24:25 --> Security Class Initialized
DEBUG - 2024-12-24 06:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:24:25 --> Input Class Initialized
INFO - 2024-12-24 06:24:25 --> Language Class Initialized
INFO - 2024-12-24 06:24:25 --> Loader Class Initialized
INFO - 2024-12-24 06:24:25 --> Helper loaded: url_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: file_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: security_helper
INFO - 2024-12-24 06:24:25 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:24:25 --> Database Driver Class Initialized
INFO - 2024-12-24 06:24:26 --> Email Class Initialized
DEBUG - 2024-12-24 06:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:24:26 --> Helper loaded: form_helper
INFO - 2024-12-24 06:24:26 --> Form Validation Class Initialized
INFO - 2024-12-24 06:24:26 --> Controller Class Initialized
DEBUG - 2024-12-24 06:24:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:24:26 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_header.php
INFO - 2024-12-24 06:24:26 --> File loaded: C:\xampp\htdocs\rso\application\views\auth/login.php
INFO - 2024-12-24 06:24:26 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/auth_footer.php
INFO - 2024-12-24 06:24:26 --> Final output sent to browser
DEBUG - 2024-12-24 06:24:26 --> Total execution time: 0.6301
INFO - 2024-12-24 06:24:31 --> Config Class Initialized
INFO - 2024-12-24 06:24:31 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:24:31 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:24:31 --> Utf8 Class Initialized
INFO - 2024-12-24 06:24:31 --> URI Class Initialized
INFO - 2024-12-24 06:24:31 --> Router Class Initialized
INFO - 2024-12-24 06:24:31 --> Output Class Initialized
INFO - 2024-12-24 06:24:31 --> Security Class Initialized
DEBUG - 2024-12-24 06:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:24:31 --> Input Class Initialized
INFO - 2024-12-24 06:24:31 --> Language Class Initialized
INFO - 2024-12-24 06:24:31 --> Loader Class Initialized
INFO - 2024-12-24 06:24:31 --> Helper loaded: url_helper
INFO - 2024-12-24 06:24:31 --> Helper loaded: file_helper
INFO - 2024-12-24 06:24:31 --> Helper loaded: security_helper
INFO - 2024-12-24 06:24:31 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:24:31 --> Database Driver Class Initialized
INFO - 2024-12-24 06:24:32 --> Email Class Initialized
DEBUG - 2024-12-24 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:24:32 --> Helper loaded: form_helper
INFO - 2024-12-24 06:24:32 --> Form Validation Class Initialized
INFO - 2024-12-24 06:24:32 --> Controller Class Initialized
DEBUG - 2024-12-24 06:24:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:24:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-24 06:24:32 --> Config Class Initialized
INFO - 2024-12-24 06:24:32 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:24:32 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:24:32 --> Utf8 Class Initialized
INFO - 2024-12-24 06:24:32 --> URI Class Initialized
INFO - 2024-12-24 06:24:32 --> Router Class Initialized
INFO - 2024-12-24 06:24:32 --> Output Class Initialized
INFO - 2024-12-24 06:24:32 --> Security Class Initialized
DEBUG - 2024-12-24 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:24:32 --> Input Class Initialized
INFO - 2024-12-24 06:24:32 --> Language Class Initialized
ERROR - 2024-12-24 06:24:32 --> 404 Page Not Found: Data/data
INFO - 2024-12-24 06:25:33 --> Config Class Initialized
INFO - 2024-12-24 06:25:33 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:25:33 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:25:33 --> Utf8 Class Initialized
INFO - 2024-12-24 06:25:33 --> URI Class Initialized
INFO - 2024-12-24 06:25:33 --> Router Class Initialized
INFO - 2024-12-24 06:25:33 --> Output Class Initialized
INFO - 2024-12-24 06:25:33 --> Security Class Initialized
DEBUG - 2024-12-24 06:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:25:33 --> Input Class Initialized
INFO - 2024-12-24 06:25:33 --> Language Class Initialized
ERROR - 2024-12-24 06:25:33 --> 404 Page Not Found: Data/data
INFO - 2024-12-24 06:25:36 --> Config Class Initialized
INFO - 2024-12-24 06:25:36 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:25:36 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:25:36 --> Utf8 Class Initialized
INFO - 2024-12-24 06:25:36 --> URI Class Initialized
INFO - 2024-12-24 06:25:36 --> Router Class Initialized
INFO - 2024-12-24 06:25:36 --> Output Class Initialized
INFO - 2024-12-24 06:25:36 --> Security Class Initialized
DEBUG - 2024-12-24 06:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:25:36 --> Input Class Initialized
INFO - 2024-12-24 06:25:36 --> Language Class Initialized
ERROR - 2024-12-24 06:25:36 --> 404 Page Not Found: Data/Data
INFO - 2024-12-24 06:25:43 --> Config Class Initialized
INFO - 2024-12-24 06:25:43 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:25:43 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:25:43 --> Utf8 Class Initialized
INFO - 2024-12-24 06:25:43 --> URI Class Initialized
INFO - 2024-12-24 06:25:43 --> Router Class Initialized
INFO - 2024-12-24 06:25:43 --> Output Class Initialized
INFO - 2024-12-24 06:25:43 --> Security Class Initialized
DEBUG - 2024-12-24 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:25:44 --> Input Class Initialized
INFO - 2024-12-24 06:25:44 --> Language Class Initialized
INFO - 2024-12-24 06:25:44 --> Loader Class Initialized
INFO - 2024-12-24 06:25:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:25:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:25:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:25:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:25:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:25:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:25:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:25:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:25:44 --> Controller Class Initialized
INFO - 2024-12-24 06:25:44 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:25:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:25:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:25:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:25:46 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:25:46 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:25:46 --> Final output sent to browser
DEBUG - 2024-12-24 06:25:46 --> Total execution time: 2.7972
INFO - 2024-12-24 06:25:48 --> Config Class Initialized
INFO - 2024-12-24 06:25:48 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:25:48 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:25:48 --> Utf8 Class Initialized
INFO - 2024-12-24 06:25:48 --> URI Class Initialized
INFO - 2024-12-24 06:25:48 --> Router Class Initialized
INFO - 2024-12-24 06:25:48 --> Output Class Initialized
INFO - 2024-12-24 06:25:48 --> Security Class Initialized
DEBUG - 2024-12-24 06:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:25:48 --> Input Class Initialized
INFO - 2024-12-24 06:25:48 --> Language Class Initialized
INFO - 2024-12-24 06:25:48 --> Loader Class Initialized
INFO - 2024-12-24 06:25:48 --> Helper loaded: url_helper
INFO - 2024-12-24 06:25:48 --> Helper loaded: file_helper
INFO - 2024-12-24 06:25:48 --> Helper loaded: security_helper
INFO - 2024-12-24 06:25:48 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:25:48 --> Database Driver Class Initialized
INFO - 2024-12-24 06:25:49 --> Email Class Initialized
DEBUG - 2024-12-24 06:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:25:49 --> Helper loaded: form_helper
INFO - 2024-12-24 06:25:49 --> Form Validation Class Initialized
INFO - 2024-12-24 06:25:49 --> Controller Class Initialized
INFO - 2024-12-24 06:25:49 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:25:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:25:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:25:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:25:51 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:25:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:25:51 --> Final output sent to browser
DEBUG - 2024-12-24 06:25:51 --> Total execution time: 2.5104
INFO - 2024-12-24 06:27:20 --> Config Class Initialized
INFO - 2024-12-24 06:27:20 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:27:20 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:27:20 --> Utf8 Class Initialized
INFO - 2024-12-24 06:27:20 --> URI Class Initialized
INFO - 2024-12-24 06:27:20 --> Router Class Initialized
INFO - 2024-12-24 06:27:20 --> Output Class Initialized
INFO - 2024-12-24 06:27:20 --> Security Class Initialized
DEBUG - 2024-12-24 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:27:20 --> Input Class Initialized
INFO - 2024-12-24 06:27:20 --> Language Class Initialized
INFO - 2024-12-24 06:27:20 --> Loader Class Initialized
INFO - 2024-12-24 06:27:20 --> Helper loaded: url_helper
INFO - 2024-12-24 06:27:20 --> Helper loaded: file_helper
INFO - 2024-12-24 06:27:20 --> Helper loaded: security_helper
INFO - 2024-12-24 06:27:20 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:27:20 --> Database Driver Class Initialized
INFO - 2024-12-24 06:27:20 --> Email Class Initialized
DEBUG - 2024-12-24 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:27:20 --> Helper loaded: form_helper
INFO - 2024-12-24 06:27:20 --> Form Validation Class Initialized
INFO - 2024-12-24 06:27:20 --> Controller Class Initialized
INFO - 2024-12-24 06:27:20 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:27:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:27:22 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:27:22 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:27:22 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:27:22 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:27:22 --> Final output sent to browser
DEBUG - 2024-12-24 06:27:22 --> Total execution time: 2.4853
INFO - 2024-12-24 06:27:35 --> Config Class Initialized
INFO - 2024-12-24 06:27:35 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:27:35 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:27:35 --> Utf8 Class Initialized
INFO - 2024-12-24 06:27:35 --> URI Class Initialized
INFO - 2024-12-24 06:27:35 --> Router Class Initialized
INFO - 2024-12-24 06:27:35 --> Output Class Initialized
INFO - 2024-12-24 06:27:35 --> Security Class Initialized
DEBUG - 2024-12-24 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:27:35 --> Input Class Initialized
INFO - 2024-12-24 06:27:35 --> Language Class Initialized
INFO - 2024-12-24 06:27:35 --> Loader Class Initialized
INFO - 2024-12-24 06:27:35 --> Helper loaded: url_helper
INFO - 2024-12-24 06:27:35 --> Helper loaded: file_helper
INFO - 2024-12-24 06:27:35 --> Helper loaded: security_helper
INFO - 2024-12-24 06:27:35 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:27:35 --> Database Driver Class Initialized
INFO - 2024-12-24 06:27:36 --> Email Class Initialized
DEBUG - 2024-12-24 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:27:36 --> Helper loaded: form_helper
INFO - 2024-12-24 06:27:36 --> Form Validation Class Initialized
INFO - 2024-12-24 06:27:36 --> Controller Class Initialized
INFO - 2024-12-24 06:27:36 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:27:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:27:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:27:38 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:27:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:27:38 --> Final output sent to browser
DEBUG - 2024-12-24 06:27:38 --> Total execution time: 2.5920
INFO - 2024-12-24 06:27:51 --> Config Class Initialized
INFO - 2024-12-24 06:27:51 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:27:51 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:27:51 --> Utf8 Class Initialized
INFO - 2024-12-24 06:27:51 --> URI Class Initialized
INFO - 2024-12-24 06:27:51 --> Router Class Initialized
INFO - 2024-12-24 06:27:51 --> Output Class Initialized
INFO - 2024-12-24 06:27:51 --> Security Class Initialized
DEBUG - 2024-12-24 06:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:27:51 --> Input Class Initialized
INFO - 2024-12-24 06:27:51 --> Language Class Initialized
INFO - 2024-12-24 06:27:51 --> Loader Class Initialized
INFO - 2024-12-24 06:27:51 --> Helper loaded: url_helper
INFO - 2024-12-24 06:27:51 --> Helper loaded: file_helper
INFO - 2024-12-24 06:27:51 --> Helper loaded: security_helper
INFO - 2024-12-24 06:27:51 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:27:51 --> Database Driver Class Initialized
INFO - 2024-12-24 06:27:52 --> Email Class Initialized
DEBUG - 2024-12-24 06:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:27:52 --> Helper loaded: form_helper
INFO - 2024-12-24 06:27:52 --> Form Validation Class Initialized
INFO - 2024-12-24 06:27:52 --> Controller Class Initialized
INFO - 2024-12-24 06:27:52 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:27:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:27:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:27:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:27:54 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:27:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:27:54 --> Final output sent to browser
DEBUG - 2024-12-24 06:27:54 --> Total execution time: 2.6445
INFO - 2024-12-24 06:28:33 --> Config Class Initialized
INFO - 2024-12-24 06:28:33 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:28:33 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:28:33 --> Utf8 Class Initialized
INFO - 2024-12-24 06:28:33 --> URI Class Initialized
INFO - 2024-12-24 06:28:33 --> Router Class Initialized
INFO - 2024-12-24 06:28:33 --> Output Class Initialized
INFO - 2024-12-24 06:28:33 --> Security Class Initialized
DEBUG - 2024-12-24 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:28:33 --> Input Class Initialized
INFO - 2024-12-24 06:28:33 --> Language Class Initialized
ERROR - 2024-12-24 06:28:33 --> 404 Page Not Found: Rawat_jalan/index
INFO - 2024-12-24 06:28:52 --> Config Class Initialized
INFO - 2024-12-24 06:28:52 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:28:52 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:28:52 --> Utf8 Class Initialized
INFO - 2024-12-24 06:28:52 --> URI Class Initialized
INFO - 2024-12-24 06:28:52 --> Router Class Initialized
INFO - 2024-12-24 06:28:52 --> Output Class Initialized
INFO - 2024-12-24 06:28:52 --> Security Class Initialized
DEBUG - 2024-12-24 06:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:28:52 --> Input Class Initialized
INFO - 2024-12-24 06:28:52 --> Language Class Initialized
INFO - 2024-12-24 06:28:52 --> Loader Class Initialized
INFO - 2024-12-24 06:28:52 --> Helper loaded: url_helper
INFO - 2024-12-24 06:28:52 --> Helper loaded: file_helper
INFO - 2024-12-24 06:28:52 --> Helper loaded: security_helper
INFO - 2024-12-24 06:28:52 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:28:52 --> Database Driver Class Initialized
INFO - 2024-12-24 06:28:53 --> Email Class Initialized
DEBUG - 2024-12-24 06:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:28:53 --> Helper loaded: form_helper
INFO - 2024-12-24 06:28:53 --> Form Validation Class Initialized
INFO - 2024-12-24 06:28:53 --> Controller Class Initialized
INFO - 2024-12-24 06:28:53 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:28:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:28:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:28:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:28:55 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:28:55 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:28:55 --> Final output sent to browser
DEBUG - 2024-12-24 06:28:55 --> Total execution time: 2.4449
INFO - 2024-12-24 06:28:58 --> Config Class Initialized
INFO - 2024-12-24 06:28:58 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:28:58 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:28:58 --> Utf8 Class Initialized
INFO - 2024-12-24 06:28:58 --> URI Class Initialized
INFO - 2024-12-24 06:28:58 --> Router Class Initialized
INFO - 2024-12-24 06:28:58 --> Output Class Initialized
INFO - 2024-12-24 06:28:58 --> Security Class Initialized
DEBUG - 2024-12-24 06:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:28:58 --> Input Class Initialized
INFO - 2024-12-24 06:28:58 --> Language Class Initialized
INFO - 2024-12-24 06:28:58 --> Loader Class Initialized
INFO - 2024-12-24 06:28:58 --> Helper loaded: url_helper
INFO - 2024-12-24 06:28:58 --> Helper loaded: file_helper
INFO - 2024-12-24 06:28:58 --> Helper loaded: security_helper
INFO - 2024-12-24 06:28:58 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:28:58 --> Database Driver Class Initialized
INFO - 2024-12-24 06:28:59 --> Email Class Initialized
DEBUG - 2024-12-24 06:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:28:59 --> Helper loaded: form_helper
INFO - 2024-12-24 06:28:59 --> Form Validation Class Initialized
INFO - 2024-12-24 06:28:59 --> Controller Class Initialized
INFO - 2024-12-24 06:28:59 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:28:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:29:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:29:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:29:01 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:29:01 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:29:01 --> Final output sent to browser
DEBUG - 2024-12-24 06:29:01 --> Total execution time: 2.6641
INFO - 2024-12-24 06:29:03 --> Config Class Initialized
INFO - 2024-12-24 06:29:03 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:29:03 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:29:03 --> Utf8 Class Initialized
INFO - 2024-12-24 06:29:03 --> URI Class Initialized
INFO - 2024-12-24 06:29:03 --> Router Class Initialized
INFO - 2024-12-24 06:29:03 --> Output Class Initialized
INFO - 2024-12-24 06:29:03 --> Security Class Initialized
DEBUG - 2024-12-24 06:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:29:03 --> Input Class Initialized
INFO - 2024-12-24 06:29:03 --> Language Class Initialized
INFO - 2024-12-24 06:29:03 --> Loader Class Initialized
INFO - 2024-12-24 06:29:03 --> Helper loaded: url_helper
INFO - 2024-12-24 06:29:03 --> Helper loaded: file_helper
INFO - 2024-12-24 06:29:03 --> Helper loaded: security_helper
INFO - 2024-12-24 06:29:03 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:29:03 --> Database Driver Class Initialized
INFO - 2024-12-24 06:29:03 --> Email Class Initialized
DEBUG - 2024-12-24 06:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:29:03 --> Helper loaded: form_helper
INFO - 2024-12-24 06:29:03 --> Form Validation Class Initialized
INFO - 2024-12-24 06:29:03 --> Controller Class Initialized
INFO - 2024-12-24 06:29:03 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:29:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:29:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:29:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:29:05 --> File loaded: C:\xampp\htdocs\rso\application\views\data/antrol.php
INFO - 2024-12-24 06:29:05 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:29:05 --> Final output sent to browser
DEBUG - 2024-12-24 06:29:05 --> Total execution time: 2.2886
INFO - 2024-12-24 06:34:01 --> Config Class Initialized
INFO - 2024-12-24 06:34:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:34:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:34:01 --> Utf8 Class Initialized
INFO - 2024-12-24 06:34:01 --> URI Class Initialized
INFO - 2024-12-24 06:34:01 --> Router Class Initialized
INFO - 2024-12-24 06:34:01 --> Output Class Initialized
INFO - 2024-12-24 06:34:01 --> Security Class Initialized
DEBUG - 2024-12-24 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:34:01 --> Input Class Initialized
INFO - 2024-12-24 06:34:01 --> Language Class Initialized
INFO - 2024-12-24 06:34:01 --> Loader Class Initialized
INFO - 2024-12-24 06:34:01 --> Helper loaded: url_helper
INFO - 2024-12-24 06:34:01 --> Helper loaded: file_helper
INFO - 2024-12-24 06:34:01 --> Helper loaded: security_helper
INFO - 2024-12-24 06:34:01 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:34:01 --> Database Driver Class Initialized
INFO - 2024-12-24 06:34:02 --> Email Class Initialized
DEBUG - 2024-12-24 06:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:34:02 --> Helper loaded: form_helper
INFO - 2024-12-24 06:34:02 --> Form Validation Class Initialized
INFO - 2024-12-24 06:34:02 --> Controller Class Initialized
INFO - 2024-12-24 06:34:02 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:34:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:34:04 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:34:10 --> Config Class Initialized
INFO - 2024-12-24 06:34:10 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:34:10 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:34:10 --> Utf8 Class Initialized
INFO - 2024-12-24 06:34:10 --> URI Class Initialized
INFO - 2024-12-24 06:34:10 --> Router Class Initialized
INFO - 2024-12-24 06:34:10 --> Output Class Initialized
INFO - 2024-12-24 06:34:10 --> Security Class Initialized
DEBUG - 2024-12-24 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:34:10 --> Input Class Initialized
INFO - 2024-12-24 06:34:10 --> Language Class Initialized
INFO - 2024-12-24 06:34:10 --> Loader Class Initialized
INFO - 2024-12-24 06:34:10 --> Helper loaded: url_helper
INFO - 2024-12-24 06:34:10 --> Helper loaded: file_helper
INFO - 2024-12-24 06:34:10 --> Helper loaded: security_helper
INFO - 2024-12-24 06:34:10 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:34:10 --> Database Driver Class Initialized
INFO - 2024-12-24 06:34:10 --> Email Class Initialized
DEBUG - 2024-12-24 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:34:10 --> Helper loaded: form_helper
INFO - 2024-12-24 06:34:10 --> Form Validation Class Initialized
INFO - 2024-12-24 06:34:10 --> Controller Class Initialized
INFO - 2024-12-24 06:34:10 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:34:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:34:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:34:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:34:12 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 06:34:12 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:34:12 --> Final output sent to browser
DEBUG - 2024-12-24 06:34:12 --> Total execution time: 2.2033
INFO - 2024-12-24 06:35:03 --> Config Class Initialized
INFO - 2024-12-24 06:35:03 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:35:03 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:35:03 --> Utf8 Class Initialized
INFO - 2024-12-24 06:35:03 --> URI Class Initialized
INFO - 2024-12-24 06:35:03 --> Router Class Initialized
INFO - 2024-12-24 06:35:03 --> Output Class Initialized
INFO - 2024-12-24 06:35:03 --> Security Class Initialized
DEBUG - 2024-12-24 06:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:35:03 --> Input Class Initialized
INFO - 2024-12-24 06:35:03 --> Language Class Initialized
INFO - 2024-12-24 06:35:03 --> Loader Class Initialized
INFO - 2024-12-24 06:35:03 --> Helper loaded: url_helper
INFO - 2024-12-24 06:35:03 --> Helper loaded: file_helper
INFO - 2024-12-24 06:35:03 --> Helper loaded: security_helper
INFO - 2024-12-24 06:35:03 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:35:03 --> Database Driver Class Initialized
INFO - 2024-12-24 06:35:04 --> Email Class Initialized
DEBUG - 2024-12-24 06:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:35:04 --> Helper loaded: form_helper
INFO - 2024-12-24 06:35:04 --> Form Validation Class Initialized
INFO - 2024-12-24 06:35:04 --> Controller Class Initialized
INFO - 2024-12-24 06:35:04 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:35:06 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:35:06 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:35:06 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 06:35:06 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:35:06 --> Final output sent to browser
DEBUG - 2024-12-24 06:35:06 --> Total execution time: 2.6099
INFO - 2024-12-24 06:46:44 --> Config Class Initialized
INFO - 2024-12-24 06:46:44 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:46:44 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:46:44 --> Utf8 Class Initialized
INFO - 2024-12-24 06:46:44 --> URI Class Initialized
INFO - 2024-12-24 06:46:44 --> Router Class Initialized
INFO - 2024-12-24 06:46:44 --> Output Class Initialized
INFO - 2024-12-24 06:46:44 --> Security Class Initialized
DEBUG - 2024-12-24 06:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:46:44 --> Input Class Initialized
INFO - 2024-12-24 06:46:44 --> Language Class Initialized
INFO - 2024-12-24 06:46:44 --> Loader Class Initialized
INFO - 2024-12-24 06:46:44 --> Helper loaded: url_helper
INFO - 2024-12-24 06:46:44 --> Helper loaded: file_helper
INFO - 2024-12-24 06:46:44 --> Helper loaded: security_helper
INFO - 2024-12-24 06:46:44 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:46:44 --> Database Driver Class Initialized
INFO - 2024-12-24 06:46:44 --> Email Class Initialized
DEBUG - 2024-12-24 06:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:46:44 --> Helper loaded: form_helper
INFO - 2024-12-24 06:46:44 --> Form Validation Class Initialized
INFO - 2024-12-24 06:46:44 --> Controller Class Initialized
INFO - 2024-12-24 06:46:44 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:46:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:46:45 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:46:45 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:46:45 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 06:46:45 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:46:45 --> Final output sent to browser
DEBUG - 2024-12-24 06:46:45 --> Total execution time: 1.4782
INFO - 2024-12-24 06:46:47 --> Config Class Initialized
INFO - 2024-12-24 06:46:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 06:46:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 06:46:47 --> Utf8 Class Initialized
INFO - 2024-12-24 06:46:47 --> URI Class Initialized
INFO - 2024-12-24 06:46:47 --> Router Class Initialized
INFO - 2024-12-24 06:46:47 --> Output Class Initialized
INFO - 2024-12-24 06:46:47 --> Security Class Initialized
DEBUG - 2024-12-24 06:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 06:46:47 --> Input Class Initialized
INFO - 2024-12-24 06:46:47 --> Language Class Initialized
INFO - 2024-12-24 06:46:47 --> Loader Class Initialized
INFO - 2024-12-24 06:46:47 --> Helper loaded: url_helper
INFO - 2024-12-24 06:46:47 --> Helper loaded: file_helper
INFO - 2024-12-24 06:46:47 --> Helper loaded: security_helper
INFO - 2024-12-24 06:46:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 06:46:47 --> Database Driver Class Initialized
INFO - 2024-12-24 06:46:47 --> Email Class Initialized
DEBUG - 2024-12-24 06:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 06:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 06:46:47 --> Helper loaded: form_helper
INFO - 2024-12-24 06:46:47 --> Form Validation Class Initialized
INFO - 2024-12-24 06:46:47 --> Controller Class Initialized
INFO - 2024-12-24 06:46:47 --> Model "Data_model" initialized
DEBUG - 2024-12-24 06:46:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 06:46:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 06:46:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 06:46:49 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 06:46:49 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 06:46:49 --> Final output sent to browser
DEBUG - 2024-12-24 06:46:49 --> Total execution time: 2.4088
INFO - 2024-12-24 07:00:39 --> Config Class Initialized
INFO - 2024-12-24 07:00:39 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:00:39 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:00:39 --> Utf8 Class Initialized
INFO - 2024-12-24 07:00:39 --> URI Class Initialized
INFO - 2024-12-24 07:00:39 --> Router Class Initialized
INFO - 2024-12-24 07:00:39 --> Output Class Initialized
INFO - 2024-12-24 07:00:39 --> Security Class Initialized
DEBUG - 2024-12-24 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:00:39 --> Input Class Initialized
INFO - 2024-12-24 07:00:39 --> Language Class Initialized
INFO - 2024-12-24 07:00:39 --> Loader Class Initialized
INFO - 2024-12-24 07:00:39 --> Helper loaded: url_helper
INFO - 2024-12-24 07:00:39 --> Helper loaded: file_helper
INFO - 2024-12-24 07:00:39 --> Helper loaded: security_helper
INFO - 2024-12-24 07:00:39 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:00:39 --> Database Driver Class Initialized
INFO - 2024-12-24 07:00:40 --> Email Class Initialized
DEBUG - 2024-12-24 07:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:00:40 --> Helper loaded: form_helper
INFO - 2024-12-24 07:00:40 --> Form Validation Class Initialized
INFO - 2024-12-24 07:00:40 --> Controller Class Initialized
INFO - 2024-12-24 07:00:40 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:00:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:00:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:00:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:00:40 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:00:40 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:00:40 --> Final output sent to browser
DEBUG - 2024-12-24 07:00:40 --> Total execution time: 1.3910
INFO - 2024-12-24 07:03:41 --> Config Class Initialized
INFO - 2024-12-24 07:03:41 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:03:41 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:03:41 --> Utf8 Class Initialized
INFO - 2024-12-24 07:03:41 --> URI Class Initialized
INFO - 2024-12-24 07:03:41 --> Router Class Initialized
INFO - 2024-12-24 07:03:41 --> Output Class Initialized
INFO - 2024-12-24 07:03:41 --> Security Class Initialized
DEBUG - 2024-12-24 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:03:41 --> Input Class Initialized
INFO - 2024-12-24 07:03:41 --> Language Class Initialized
INFO - 2024-12-24 07:03:41 --> Loader Class Initialized
INFO - 2024-12-24 07:03:41 --> Helper loaded: url_helper
INFO - 2024-12-24 07:03:41 --> Helper loaded: file_helper
INFO - 2024-12-24 07:03:41 --> Helper loaded: security_helper
INFO - 2024-12-24 07:03:41 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:03:41 --> Database Driver Class Initialized
INFO - 2024-12-24 07:03:42 --> Email Class Initialized
DEBUG - 2024-12-24 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:03:42 --> Helper loaded: form_helper
INFO - 2024-12-24 07:03:42 --> Form Validation Class Initialized
INFO - 2024-12-24 07:03:42 --> Controller Class Initialized
INFO - 2024-12-24 07:03:42 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:03:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:03:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:03:42 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:03:42 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:03:42 --> Final output sent to browser
DEBUG - 2024-12-24 07:03:42 --> Total execution time: 1.4123
INFO - 2024-12-24 07:03:46 --> Config Class Initialized
INFO - 2024-12-24 07:03:46 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:03:46 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:03:46 --> Utf8 Class Initialized
INFO - 2024-12-24 07:03:46 --> URI Class Initialized
INFO - 2024-12-24 07:03:46 --> Router Class Initialized
INFO - 2024-12-24 07:03:46 --> Output Class Initialized
INFO - 2024-12-24 07:03:46 --> Security Class Initialized
DEBUG - 2024-12-24 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:03:46 --> Input Class Initialized
INFO - 2024-12-24 07:03:46 --> Language Class Initialized
INFO - 2024-12-24 07:03:46 --> Loader Class Initialized
INFO - 2024-12-24 07:03:46 --> Helper loaded: url_helper
INFO - 2024-12-24 07:03:46 --> Helper loaded: file_helper
INFO - 2024-12-24 07:03:46 --> Helper loaded: security_helper
INFO - 2024-12-24 07:03:46 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:03:46 --> Database Driver Class Initialized
INFO - 2024-12-24 07:03:47 --> Email Class Initialized
DEBUG - 2024-12-24 07:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:03:47 --> Helper loaded: form_helper
INFO - 2024-12-24 07:03:47 --> Form Validation Class Initialized
INFO - 2024-12-24 07:03:47 --> Controller Class Initialized
INFO - 2024-12-24 07:03:47 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:03:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:03:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:03:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:03:48 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:03:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:03:48 --> Final output sent to browser
DEBUG - 2024-12-24 07:03:48 --> Total execution time: 1.9789
INFO - 2024-12-24 07:12:24 --> Config Class Initialized
INFO - 2024-12-24 07:12:24 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:12:24 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:12:24 --> Utf8 Class Initialized
INFO - 2024-12-24 07:12:24 --> URI Class Initialized
INFO - 2024-12-24 07:12:24 --> Router Class Initialized
INFO - 2024-12-24 07:12:24 --> Output Class Initialized
INFO - 2024-12-24 07:12:24 --> Security Class Initialized
DEBUG - 2024-12-24 07:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:12:24 --> Input Class Initialized
INFO - 2024-12-24 07:12:24 --> Language Class Initialized
INFO - 2024-12-24 07:12:24 --> Loader Class Initialized
INFO - 2024-12-24 07:12:24 --> Helper loaded: url_helper
INFO - 2024-12-24 07:12:24 --> Helper loaded: file_helper
INFO - 2024-12-24 07:12:24 --> Helper loaded: security_helper
INFO - 2024-12-24 07:12:24 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:12:24 --> Database Driver Class Initialized
INFO - 2024-12-24 07:12:24 --> Email Class Initialized
DEBUG - 2024-12-24 07:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:12:24 --> Helper loaded: form_helper
INFO - 2024-12-24 07:12:24 --> Form Validation Class Initialized
INFO - 2024-12-24 07:12:24 --> Controller Class Initialized
INFO - 2024-12-24 07:12:25 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:12:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:12:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:12:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:12:25 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:12:25 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:12:25 --> Final output sent to browser
DEBUG - 2024-12-24 07:12:25 --> Total execution time: 1.4201
INFO - 2024-12-24 07:12:47 --> Config Class Initialized
INFO - 2024-12-24 07:12:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:12:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:12:47 --> Utf8 Class Initialized
INFO - 2024-12-24 07:12:47 --> URI Class Initialized
INFO - 2024-12-24 07:12:47 --> Router Class Initialized
INFO - 2024-12-24 07:12:47 --> Output Class Initialized
INFO - 2024-12-24 07:12:47 --> Security Class Initialized
DEBUG - 2024-12-24 07:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:12:47 --> Input Class Initialized
INFO - 2024-12-24 07:12:47 --> Language Class Initialized
INFO - 2024-12-24 07:12:47 --> Loader Class Initialized
INFO - 2024-12-24 07:12:47 --> Helper loaded: url_helper
INFO - 2024-12-24 07:12:47 --> Helper loaded: file_helper
INFO - 2024-12-24 07:12:47 --> Helper loaded: security_helper
INFO - 2024-12-24 07:12:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:12:47 --> Database Driver Class Initialized
INFO - 2024-12-24 07:12:48 --> Email Class Initialized
DEBUG - 2024-12-24 07:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:12:48 --> Helper loaded: form_helper
INFO - 2024-12-24 07:12:48 --> Form Validation Class Initialized
INFO - 2024-12-24 07:12:48 --> Controller Class Initialized
INFO - 2024-12-24 07:12:48 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:12:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:12:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:12:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:12:48 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:12:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:12:48 --> Final output sent to browser
DEBUG - 2024-12-24 07:12:48 --> Total execution time: 1.3964
INFO - 2024-12-24 07:12:50 --> Config Class Initialized
INFO - 2024-12-24 07:12:50 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:12:50 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:12:50 --> Utf8 Class Initialized
INFO - 2024-12-24 07:12:50 --> URI Class Initialized
INFO - 2024-12-24 07:12:50 --> Router Class Initialized
INFO - 2024-12-24 07:12:50 --> Output Class Initialized
INFO - 2024-12-24 07:12:50 --> Security Class Initialized
DEBUG - 2024-12-24 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:12:50 --> Input Class Initialized
INFO - 2024-12-24 07:12:50 --> Language Class Initialized
INFO - 2024-12-24 07:12:50 --> Loader Class Initialized
INFO - 2024-12-24 07:12:50 --> Helper loaded: url_helper
INFO - 2024-12-24 07:12:50 --> Helper loaded: file_helper
INFO - 2024-12-24 07:12:50 --> Helper loaded: security_helper
INFO - 2024-12-24 07:12:50 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:12:50 --> Database Driver Class Initialized
INFO - 2024-12-24 07:12:51 --> Email Class Initialized
DEBUG - 2024-12-24 07:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:12:51 --> Helper loaded: form_helper
INFO - 2024-12-24 07:12:51 --> Form Validation Class Initialized
INFO - 2024-12-24 07:12:51 --> Controller Class Initialized
INFO - 2024-12-24 07:12:51 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:12:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:12:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:12:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:12:53 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:12:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:12:53 --> Final output sent to browser
DEBUG - 2024-12-24 07:12:53 --> Total execution time: 2.4383
INFO - 2024-12-24 07:12:55 --> Config Class Initialized
INFO - 2024-12-24 07:12:55 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:12:55 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:12:55 --> Utf8 Class Initialized
INFO - 2024-12-24 07:12:55 --> URI Class Initialized
INFO - 2024-12-24 07:12:55 --> Router Class Initialized
INFO - 2024-12-24 07:12:55 --> Output Class Initialized
INFO - 2024-12-24 07:12:55 --> Security Class Initialized
DEBUG - 2024-12-24 07:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:12:55 --> Input Class Initialized
INFO - 2024-12-24 07:12:55 --> Language Class Initialized
INFO - 2024-12-24 07:12:55 --> Loader Class Initialized
INFO - 2024-12-24 07:12:55 --> Helper loaded: url_helper
INFO - 2024-12-24 07:12:55 --> Helper loaded: file_helper
INFO - 2024-12-24 07:12:55 --> Helper loaded: security_helper
INFO - 2024-12-24 07:12:55 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:12:55 --> Database Driver Class Initialized
INFO - 2024-12-24 07:12:56 --> Email Class Initialized
DEBUG - 2024-12-24 07:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:12:56 --> Helper loaded: form_helper
INFO - 2024-12-24 07:12:56 --> Form Validation Class Initialized
INFO - 2024-12-24 07:12:56 --> Controller Class Initialized
INFO - 2024-12-24 07:12:56 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:12:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:12:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:12:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:12:57 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:12:57 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:12:57 --> Final output sent to browser
DEBUG - 2024-12-24 07:12:57 --> Total execution time: 1.3500
INFO - 2024-12-24 07:14:51 --> Config Class Initialized
INFO - 2024-12-24 07:14:51 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:14:51 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:14:51 --> Utf8 Class Initialized
INFO - 2024-12-24 07:14:51 --> URI Class Initialized
INFO - 2024-12-24 07:14:51 --> Router Class Initialized
INFO - 2024-12-24 07:14:51 --> Output Class Initialized
INFO - 2024-12-24 07:14:51 --> Security Class Initialized
DEBUG - 2024-12-24 07:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:14:51 --> Input Class Initialized
INFO - 2024-12-24 07:14:51 --> Language Class Initialized
INFO - 2024-12-24 07:14:51 --> Loader Class Initialized
INFO - 2024-12-24 07:14:51 --> Helper loaded: url_helper
INFO - 2024-12-24 07:14:51 --> Helper loaded: file_helper
INFO - 2024-12-24 07:14:51 --> Helper loaded: security_helper
INFO - 2024-12-24 07:14:51 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:14:51 --> Database Driver Class Initialized
INFO - 2024-12-24 07:14:51 --> Email Class Initialized
DEBUG - 2024-12-24 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:14:51 --> Helper loaded: form_helper
INFO - 2024-12-24 07:14:51 --> Form Validation Class Initialized
INFO - 2024-12-24 07:14:51 --> Controller Class Initialized
INFO - 2024-12-24 07:14:51 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:14:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:14:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:14:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:14:52 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:14:52 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:14:52 --> Final output sent to browser
DEBUG - 2024-12-24 07:14:52 --> Total execution time: 1.6531
INFO - 2024-12-24 07:17:27 --> Config Class Initialized
INFO - 2024-12-24 07:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:17:27 --> Utf8 Class Initialized
INFO - 2024-12-24 07:17:27 --> URI Class Initialized
INFO - 2024-12-24 07:17:27 --> Router Class Initialized
INFO - 2024-12-24 07:17:27 --> Output Class Initialized
INFO - 2024-12-24 07:17:27 --> Security Class Initialized
DEBUG - 2024-12-24 07:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:17:27 --> Input Class Initialized
INFO - 2024-12-24 07:17:27 --> Language Class Initialized
INFO - 2024-12-24 07:17:27 --> Loader Class Initialized
INFO - 2024-12-24 07:17:27 --> Helper loaded: url_helper
INFO - 2024-12-24 07:17:27 --> Helper loaded: file_helper
INFO - 2024-12-24 07:17:27 --> Helper loaded: security_helper
INFO - 2024-12-24 07:17:27 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:17:27 --> Database Driver Class Initialized
INFO - 2024-12-24 07:17:28 --> Email Class Initialized
DEBUG - 2024-12-24 07:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:17:28 --> Helper loaded: form_helper
INFO - 2024-12-24 07:17:28 --> Form Validation Class Initialized
INFO - 2024-12-24 07:17:28 --> Controller Class Initialized
INFO - 2024-12-24 07:17:28 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:17:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:17:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:17:29 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:17:29 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:17:29 --> Final output sent to browser
DEBUG - 2024-12-24 07:17:29 --> Total execution time: 1.4964
INFO - 2024-12-24 07:18:50 --> Config Class Initialized
INFO - 2024-12-24 07:18:50 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:18:50 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:18:50 --> Utf8 Class Initialized
INFO - 2024-12-24 07:18:50 --> URI Class Initialized
INFO - 2024-12-24 07:18:50 --> Router Class Initialized
INFO - 2024-12-24 07:18:50 --> Output Class Initialized
INFO - 2024-12-24 07:18:50 --> Security Class Initialized
DEBUG - 2024-12-24 07:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:18:50 --> Input Class Initialized
INFO - 2024-12-24 07:18:50 --> Language Class Initialized
INFO - 2024-12-24 07:18:50 --> Loader Class Initialized
INFO - 2024-12-24 07:18:50 --> Helper loaded: url_helper
INFO - 2024-12-24 07:18:50 --> Helper loaded: file_helper
INFO - 2024-12-24 07:18:50 --> Helper loaded: security_helper
INFO - 2024-12-24 07:18:50 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:18:50 --> Database Driver Class Initialized
INFO - 2024-12-24 07:18:51 --> Email Class Initialized
DEBUG - 2024-12-24 07:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:18:51 --> Helper loaded: form_helper
INFO - 2024-12-24 07:18:51 --> Form Validation Class Initialized
INFO - 2024-12-24 07:18:51 --> Controller Class Initialized
INFO - 2024-12-24 07:18:51 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:18:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:18:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:18:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:18:51 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:18:51 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:18:51 --> Final output sent to browser
DEBUG - 2024-12-24 07:18:51 --> Total execution time: 1.4720
INFO - 2024-12-24 07:20:01 --> Config Class Initialized
INFO - 2024-12-24 07:20:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:20:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:20:01 --> Utf8 Class Initialized
INFO - 2024-12-24 07:20:01 --> URI Class Initialized
INFO - 2024-12-24 07:20:01 --> Router Class Initialized
INFO - 2024-12-24 07:20:01 --> Output Class Initialized
INFO - 2024-12-24 07:20:01 --> Security Class Initialized
DEBUG - 2024-12-24 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:20:01 --> Input Class Initialized
INFO - 2024-12-24 07:20:01 --> Language Class Initialized
INFO - 2024-12-24 07:20:01 --> Loader Class Initialized
INFO - 2024-12-24 07:20:01 --> Helper loaded: url_helper
INFO - 2024-12-24 07:20:01 --> Helper loaded: file_helper
INFO - 2024-12-24 07:20:01 --> Helper loaded: security_helper
INFO - 2024-12-24 07:20:01 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:20:01 --> Database Driver Class Initialized
INFO - 2024-12-24 07:20:01 --> Email Class Initialized
DEBUG - 2024-12-24 07:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:20:01 --> Helper loaded: form_helper
INFO - 2024-12-24 07:20:01 --> Form Validation Class Initialized
INFO - 2024-12-24 07:20:01 --> Controller Class Initialized
INFO - 2024-12-24 07:20:01 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:20:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:20:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:20:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:20:03 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:20:03 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:20:03 --> Final output sent to browser
DEBUG - 2024-12-24 07:20:03 --> Total execution time: 2.2601
INFO - 2024-12-24 07:20:13 --> Config Class Initialized
INFO - 2024-12-24 07:20:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:20:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:20:13 --> Utf8 Class Initialized
INFO - 2024-12-24 07:20:13 --> URI Class Initialized
INFO - 2024-12-24 07:20:13 --> Router Class Initialized
INFO - 2024-12-24 07:20:13 --> Output Class Initialized
INFO - 2024-12-24 07:20:13 --> Security Class Initialized
DEBUG - 2024-12-24 07:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:20:13 --> Input Class Initialized
INFO - 2024-12-24 07:20:13 --> Language Class Initialized
INFO - 2024-12-24 07:20:13 --> Loader Class Initialized
INFO - 2024-12-24 07:20:13 --> Helper loaded: url_helper
INFO - 2024-12-24 07:20:13 --> Helper loaded: file_helper
INFO - 2024-12-24 07:20:13 --> Helper loaded: security_helper
INFO - 2024-12-24 07:20:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:20:13 --> Database Driver Class Initialized
INFO - 2024-12-24 07:20:13 --> Email Class Initialized
DEBUG - 2024-12-24 07:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:20:13 --> Helper loaded: form_helper
INFO - 2024-12-24 07:20:13 --> Form Validation Class Initialized
INFO - 2024-12-24 07:20:13 --> Controller Class Initialized
INFO - 2024-12-24 07:20:13 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:20:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:20:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:20:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:20:15 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:20:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:20:15 --> Final output sent to browser
DEBUG - 2024-12-24 07:20:15 --> Total execution time: 2.2260
INFO - 2024-12-24 07:20:30 --> Config Class Initialized
INFO - 2024-12-24 07:20:30 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:20:30 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:20:30 --> Utf8 Class Initialized
INFO - 2024-12-24 07:20:30 --> URI Class Initialized
INFO - 2024-12-24 07:20:30 --> Router Class Initialized
INFO - 2024-12-24 07:20:30 --> Output Class Initialized
INFO - 2024-12-24 07:20:30 --> Security Class Initialized
DEBUG - 2024-12-24 07:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:20:30 --> Input Class Initialized
INFO - 2024-12-24 07:20:30 --> Language Class Initialized
INFO - 2024-12-24 07:20:30 --> Loader Class Initialized
INFO - 2024-12-24 07:20:30 --> Helper loaded: url_helper
INFO - 2024-12-24 07:20:30 --> Helper loaded: file_helper
INFO - 2024-12-24 07:20:30 --> Helper loaded: security_helper
INFO - 2024-12-24 07:20:30 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:20:30 --> Database Driver Class Initialized
INFO - 2024-12-24 07:20:31 --> Email Class Initialized
DEBUG - 2024-12-24 07:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:20:31 --> Helper loaded: form_helper
INFO - 2024-12-24 07:20:31 --> Form Validation Class Initialized
INFO - 2024-12-24 07:20:31 --> Controller Class Initialized
INFO - 2024-12-24 07:20:31 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:20:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:20:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:20:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:20:33 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:20:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:20:33 --> Final output sent to browser
DEBUG - 2024-12-24 07:20:33 --> Total execution time: 2.5278
INFO - 2024-12-24 07:20:38 --> Config Class Initialized
INFO - 2024-12-24 07:20:38 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:20:38 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:20:38 --> Utf8 Class Initialized
INFO - 2024-12-24 07:20:38 --> URI Class Initialized
INFO - 2024-12-24 07:20:38 --> Router Class Initialized
INFO - 2024-12-24 07:20:38 --> Output Class Initialized
INFO - 2024-12-24 07:20:38 --> Security Class Initialized
DEBUG - 2024-12-24 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:20:38 --> Input Class Initialized
INFO - 2024-12-24 07:20:38 --> Language Class Initialized
INFO - 2024-12-24 07:20:38 --> Loader Class Initialized
INFO - 2024-12-24 07:20:38 --> Helper loaded: url_helper
INFO - 2024-12-24 07:20:38 --> Helper loaded: file_helper
INFO - 2024-12-24 07:20:38 --> Helper loaded: security_helper
INFO - 2024-12-24 07:20:38 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:20:38 --> Database Driver Class Initialized
INFO - 2024-12-24 07:20:38 --> Email Class Initialized
DEBUG - 2024-12-24 07:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:20:38 --> Helper loaded: form_helper
INFO - 2024-12-24 07:20:38 --> Form Validation Class Initialized
INFO - 2024-12-24 07:20:38 --> Controller Class Initialized
INFO - 2024-12-24 07:20:38 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:20:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:20:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:20:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:20:39 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:20:39 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:20:39 --> Final output sent to browser
DEBUG - 2024-12-24 07:20:39 --> Total execution time: 1.4293
INFO - 2024-12-24 07:21:13 --> Config Class Initialized
INFO - 2024-12-24 07:21:13 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:21:13 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:21:13 --> Utf8 Class Initialized
INFO - 2024-12-24 07:21:13 --> URI Class Initialized
INFO - 2024-12-24 07:21:13 --> Router Class Initialized
INFO - 2024-12-24 07:21:13 --> Output Class Initialized
INFO - 2024-12-24 07:21:13 --> Security Class Initialized
DEBUG - 2024-12-24 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:21:13 --> Input Class Initialized
INFO - 2024-12-24 07:21:13 --> Language Class Initialized
INFO - 2024-12-24 07:21:13 --> Loader Class Initialized
INFO - 2024-12-24 07:21:13 --> Helper loaded: url_helper
INFO - 2024-12-24 07:21:13 --> Helper loaded: file_helper
INFO - 2024-12-24 07:21:13 --> Helper loaded: security_helper
INFO - 2024-12-24 07:21:13 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:21:13 --> Database Driver Class Initialized
INFO - 2024-12-24 07:21:13 --> Email Class Initialized
DEBUG - 2024-12-24 07:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:21:13 --> Helper loaded: form_helper
INFO - 2024-12-24 07:21:13 --> Form Validation Class Initialized
INFO - 2024-12-24 07:21:13 --> Controller Class Initialized
INFO - 2024-12-24 07:21:13 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:21:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:21:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:21:15 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:21:15 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:21:15 --> Final output sent to browser
DEBUG - 2024-12-24 07:21:15 --> Total execution time: 2.5089
INFO - 2024-12-24 07:21:38 --> Config Class Initialized
INFO - 2024-12-24 07:21:38 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:21:38 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:21:38 --> Utf8 Class Initialized
INFO - 2024-12-24 07:21:38 --> URI Class Initialized
INFO - 2024-12-24 07:21:38 --> Router Class Initialized
INFO - 2024-12-24 07:21:38 --> Output Class Initialized
INFO - 2024-12-24 07:21:38 --> Security Class Initialized
DEBUG - 2024-12-24 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:21:38 --> Input Class Initialized
INFO - 2024-12-24 07:21:38 --> Language Class Initialized
INFO - 2024-12-24 07:21:38 --> Loader Class Initialized
INFO - 2024-12-24 07:21:38 --> Helper loaded: url_helper
INFO - 2024-12-24 07:21:38 --> Helper loaded: file_helper
INFO - 2024-12-24 07:21:38 --> Helper loaded: security_helper
INFO - 2024-12-24 07:21:38 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:21:38 --> Database Driver Class Initialized
INFO - 2024-12-24 07:21:39 --> Email Class Initialized
DEBUG - 2024-12-24 07:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:21:39 --> Helper loaded: form_helper
INFO - 2024-12-24 07:21:39 --> Form Validation Class Initialized
INFO - 2024-12-24 07:21:39 --> Controller Class Initialized
INFO - 2024-12-24 07:21:39 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:21:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:21:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:21:41 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:21:41 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:21:41 --> Final output sent to browser
DEBUG - 2024-12-24 07:21:41 --> Total execution time: 2.4573
INFO - 2024-12-24 07:22:31 --> Config Class Initialized
INFO - 2024-12-24 07:22:31 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:22:31 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:22:31 --> Utf8 Class Initialized
INFO - 2024-12-24 07:22:31 --> URI Class Initialized
INFO - 2024-12-24 07:22:31 --> Router Class Initialized
INFO - 2024-12-24 07:22:31 --> Output Class Initialized
INFO - 2024-12-24 07:22:31 --> Security Class Initialized
DEBUG - 2024-12-24 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:22:31 --> Input Class Initialized
INFO - 2024-12-24 07:22:31 --> Language Class Initialized
INFO - 2024-12-24 07:22:31 --> Loader Class Initialized
INFO - 2024-12-24 07:22:31 --> Helper loaded: url_helper
INFO - 2024-12-24 07:22:31 --> Helper loaded: file_helper
INFO - 2024-12-24 07:22:31 --> Helper loaded: security_helper
INFO - 2024-12-24 07:22:31 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:22:31 --> Database Driver Class Initialized
INFO - 2024-12-24 07:22:32 --> Email Class Initialized
DEBUG - 2024-12-24 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:22:32 --> Helper loaded: form_helper
INFO - 2024-12-24 07:22:32 --> Form Validation Class Initialized
INFO - 2024-12-24 07:22:32 --> Controller Class Initialized
INFO - 2024-12-24 07:22:32 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:22:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:22:33 --> Config Class Initialized
INFO - 2024-12-24 07:22:33 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:22:33 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:22:33 --> Utf8 Class Initialized
INFO - 2024-12-24 07:22:33 --> URI Class Initialized
INFO - 2024-12-24 07:22:33 --> Router Class Initialized
INFO - 2024-12-24 07:22:33 --> Output Class Initialized
INFO - 2024-12-24 07:22:33 --> Security Class Initialized
DEBUG - 2024-12-24 07:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:22:33 --> Input Class Initialized
INFO - 2024-12-24 07:22:33 --> Language Class Initialized
INFO - 2024-12-24 07:22:33 --> Loader Class Initialized
INFO - 2024-12-24 07:22:33 --> Helper loaded: url_helper
INFO - 2024-12-24 07:22:33 --> Helper loaded: file_helper
INFO - 2024-12-24 07:22:33 --> Helper loaded: security_helper
INFO - 2024-12-24 07:22:33 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:22:33 --> Database Driver Class Initialized
INFO - 2024-12-24 07:22:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:22:33 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:22:33 --> Email Class Initialized
INFO - 2024-12-24 07:22:33 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
DEBUG - 2024-12-24 07:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:22:34 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:22:34 --> Helper loaded: form_helper
INFO - 2024-12-24 07:22:34 --> Form Validation Class Initialized
INFO - 2024-12-24 07:22:34 --> Controller Class Initialized
INFO - 2024-12-24 07:22:34 --> Final output sent to browser
DEBUG - 2024-12-24 07:22:34 --> Total execution time: 2.4827
INFO - 2024-12-24 07:22:34 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:22:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-12-24 07:22:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'b.nm_bangsal as ruang,
		        k.kelas as kelas
            FROM reg_periksa' at line 23 - Invalid query: SELECT
    r.no_rkm_medis AS NRM,
                r.stts_daftar AS Pengunjung,
                rm.perujuk AS cara_masuk,
                r.tgl_registrasi AS Tanggal_Pendaftaran,
                px.nm_pasien AS nama,
                px.jk AS jenis_kelamin,
                ki.stts_pulang AS stts_pulang,  
                r.tgl_registrasi AS Tanggal_masuk,
                r.tgl_registrasi AS Tanggal_keluar,
                DATEDIFF(CURDATE(), px.tgl_lahir) AS umur_hari,
                px.alamat AS Alamat,
                px.kecamatanpj AS kecamatan,
                px.kabupatenpj AS kabupaten,
                px.propinsipj AS provinsi,
                GROUP_CONCAT(dpx.kd_penyakit SEPARATOR ';') AS diagnosa,
                GROUP_CONCAT(ppx.kode SEPARATOR ';') AS tindakan,
                rj.rujuk_ke AS cara_keluar,
                d.nm_dokter AS DPJP,
                pj.png_jawab AS Pembayaran,
                p.nm_poli AS Poli,
                r.status_poli AS Kunjungan
                b.nm_bangsal as ruang,
		        k.kelas as kelas
            FROM reg_periksa r
            LEFT JOIN dokter d ON r.kd_dokter = d.kd_dokter
            LEFT JOIN poliklinik p ON r.kd_poli = p.kd_poli
            LEFT JOIN pasien px ON r.no_rkm_medis = px.no_rkm_medis
            LEFT JOIN penjab pj ON r.kd_pj = pj.kd_pj
            LEFT JOIN diagnosa_pasien dpx ON r.no_rawat = dpx.no_rawat
            LEFT JOIN prosedur_pasien ppx ON r.no_rawat = ppx.no_rawat
            LEFT JOIN rujuk_masuk rm ON r.no_rawat = rm.no_rawat
            LEFT JOIN rujuk rj ON r.no_rawat = rj.no_rawat
            LEFT JOIN kamar_inap ki ON r.no_rawat = ki.no_rawat
            LEFT JOIN kamar k ON ki.kd_kamar = k.kd_kamar
            LEFT JOIN bangsal b ON k.kd_bangsal = b.kd_bangsal
            WHERE MONTH(r.tgl_registrasi) = MONTH(CURDATE())
              AND YEAR(r.tgl_registrasi) = YEAR(CURDATE())
              AND r.status_lanjut = 'ranap'
            GROUP BY r.no_rawat
INFO - 2024-12-24 07:22:34 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-24 07:22:42 --> Config Class Initialized
INFO - 2024-12-24 07:22:42 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:22:42 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:22:42 --> Utf8 Class Initialized
INFO - 2024-12-24 07:22:42 --> URI Class Initialized
INFO - 2024-12-24 07:22:42 --> Router Class Initialized
INFO - 2024-12-24 07:22:42 --> Output Class Initialized
INFO - 2024-12-24 07:22:42 --> Security Class Initialized
DEBUG - 2024-12-24 07:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:22:42 --> Input Class Initialized
INFO - 2024-12-24 07:22:42 --> Language Class Initialized
INFO - 2024-12-24 07:22:42 --> Loader Class Initialized
INFO - 2024-12-24 07:22:42 --> Helper loaded: url_helper
INFO - 2024-12-24 07:22:42 --> Helper loaded: file_helper
INFO - 2024-12-24 07:22:42 --> Helper loaded: security_helper
INFO - 2024-12-24 07:22:42 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:22:42 --> Database Driver Class Initialized
INFO - 2024-12-24 07:22:43 --> Email Class Initialized
DEBUG - 2024-12-24 07:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:22:43 --> Helper loaded: form_helper
INFO - 2024-12-24 07:22:43 --> Form Validation Class Initialized
INFO - 2024-12-24 07:22:43 --> Controller Class Initialized
INFO - 2024-12-24 07:22:43 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:22:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-12-24 07:22:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'b.nm_bangsal as ruang,
		        k.kelas as kelas,
            FROM reg_periks' at line 23 - Invalid query: SELECT
    r.no_rkm_medis AS NRM,
                r.stts_daftar AS Pengunjung,
                rm.perujuk AS cara_masuk,
                r.tgl_registrasi AS Tanggal_Pendaftaran,
                px.nm_pasien AS nama,
                px.jk AS jenis_kelamin,
                ki.stts_pulang AS stts_pulang,  
                r.tgl_registrasi AS Tanggal_masuk,
                r.tgl_registrasi AS Tanggal_keluar,
                DATEDIFF(CURDATE(), px.tgl_lahir) AS umur_hari,
                px.alamat AS Alamat,
                px.kecamatanpj AS kecamatan,
                px.kabupatenpj AS kabupaten,
                px.propinsipj AS provinsi,
                GROUP_CONCAT(dpx.kd_penyakit SEPARATOR ';') AS diagnosa,
                GROUP_CONCAT(ppx.kode SEPARATOR ';') AS tindakan,
                rj.rujuk_ke AS cara_keluar,
                d.nm_dokter AS DPJP,
                pj.png_jawab AS Pembayaran,
                p.nm_poli AS Poli,
                r.status_poli AS Kunjungan
                b.nm_bangsal as ruang,
		        k.kelas as kelas,
            FROM reg_periksa r
            LEFT JOIN dokter d ON r.kd_dokter = d.kd_dokter
            LEFT JOIN poliklinik p ON r.kd_poli = p.kd_poli
            LEFT JOIN pasien px ON r.no_rkm_medis = px.no_rkm_medis
            LEFT JOIN penjab pj ON r.kd_pj = pj.kd_pj
            LEFT JOIN diagnosa_pasien dpx ON r.no_rawat = dpx.no_rawat
            LEFT JOIN prosedur_pasien ppx ON r.no_rawat = ppx.no_rawat
            LEFT JOIN rujuk_masuk rm ON r.no_rawat = rm.no_rawat
            LEFT JOIN rujuk rj ON r.no_rawat = rj.no_rawat
            LEFT JOIN kamar_inap ki ON r.no_rawat = ki.no_rawat
            LEFT JOIN kamar k ON ki.kd_kamar = k.kd_kamar
            LEFT JOIN bangsal b ON k.kd_bangsal = b.kd_bangsal
            WHERE MONTH(r.tgl_registrasi) = MONTH(CURDATE())
              AND YEAR(r.tgl_registrasi) = YEAR(CURDATE())
              AND r.status_lanjut = 'ranap'
            GROUP BY r.no_rawat
INFO - 2024-12-24 07:22:44 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-24 07:22:51 --> Config Class Initialized
INFO - 2024-12-24 07:22:51 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:22:51 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:22:51 --> Utf8 Class Initialized
INFO - 2024-12-24 07:22:51 --> URI Class Initialized
INFO - 2024-12-24 07:22:51 --> Router Class Initialized
INFO - 2024-12-24 07:22:51 --> Output Class Initialized
INFO - 2024-12-24 07:22:51 --> Security Class Initialized
DEBUG - 2024-12-24 07:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:22:51 --> Input Class Initialized
INFO - 2024-12-24 07:22:51 --> Language Class Initialized
INFO - 2024-12-24 07:22:51 --> Loader Class Initialized
INFO - 2024-12-24 07:22:51 --> Helper loaded: url_helper
INFO - 2024-12-24 07:22:51 --> Helper loaded: file_helper
INFO - 2024-12-24 07:22:51 --> Helper loaded: security_helper
INFO - 2024-12-24 07:22:51 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:22:51 --> Database Driver Class Initialized
INFO - 2024-12-24 07:22:52 --> Email Class Initialized
DEBUG - 2024-12-24 07:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:22:52 --> Helper loaded: form_helper
INFO - 2024-12-24 07:22:52 --> Form Validation Class Initialized
INFO - 2024-12-24 07:22:52 --> Controller Class Initialized
INFO - 2024-12-24 07:22:52 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:22:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:22:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:22:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:22:53 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:22:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:22:53 --> Final output sent to browser
DEBUG - 2024-12-24 07:22:53 --> Total execution time: 1.4808
INFO - 2024-12-24 07:24:16 --> Config Class Initialized
INFO - 2024-12-24 07:24:16 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:24:16 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:24:16 --> Utf8 Class Initialized
INFO - 2024-12-24 07:24:16 --> URI Class Initialized
INFO - 2024-12-24 07:24:16 --> Router Class Initialized
INFO - 2024-12-24 07:24:16 --> Output Class Initialized
INFO - 2024-12-24 07:24:16 --> Security Class Initialized
DEBUG - 2024-12-24 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:24:16 --> Input Class Initialized
INFO - 2024-12-24 07:24:16 --> Language Class Initialized
INFO - 2024-12-24 07:24:16 --> Loader Class Initialized
INFO - 2024-12-24 07:24:16 --> Helper loaded: url_helper
INFO - 2024-12-24 07:24:16 --> Helper loaded: file_helper
INFO - 2024-12-24 07:24:16 --> Helper loaded: security_helper
INFO - 2024-12-24 07:24:16 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:24:16 --> Database Driver Class Initialized
INFO - 2024-12-24 07:24:17 --> Email Class Initialized
DEBUG - 2024-12-24 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:24:17 --> Helper loaded: form_helper
INFO - 2024-12-24 07:24:17 --> Form Validation Class Initialized
INFO - 2024-12-24 07:24:17 --> Controller Class Initialized
INFO - 2024-12-24 07:24:17 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:24:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:24:17 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:24:17 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:24:17 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:24:17 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:24:17 --> Final output sent to browser
DEBUG - 2024-12-24 07:24:17 --> Total execution time: 1.4599
INFO - 2024-12-24 07:24:52 --> Config Class Initialized
INFO - 2024-12-24 07:24:52 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:24:52 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:24:52 --> Utf8 Class Initialized
INFO - 2024-12-24 07:24:52 --> URI Class Initialized
INFO - 2024-12-24 07:24:52 --> Router Class Initialized
INFO - 2024-12-24 07:24:52 --> Output Class Initialized
INFO - 2024-12-24 07:24:52 --> Security Class Initialized
DEBUG - 2024-12-24 07:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:24:52 --> Input Class Initialized
INFO - 2024-12-24 07:24:52 --> Language Class Initialized
INFO - 2024-12-24 07:24:52 --> Loader Class Initialized
INFO - 2024-12-24 07:24:52 --> Helper loaded: url_helper
INFO - 2024-12-24 07:24:52 --> Helper loaded: file_helper
INFO - 2024-12-24 07:24:52 --> Helper loaded: security_helper
INFO - 2024-12-24 07:24:52 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:24:53 --> Database Driver Class Initialized
INFO - 2024-12-24 07:24:53 --> Email Class Initialized
DEBUG - 2024-12-24 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:24:53 --> Helper loaded: form_helper
INFO - 2024-12-24 07:24:53 --> Form Validation Class Initialized
INFO - 2024-12-24 07:24:53 --> Controller Class Initialized
INFO - 2024-12-24 07:24:53 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:24:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:24:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:24:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:24:54 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:24:54 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:24:54 --> Final output sent to browser
DEBUG - 2024-12-24 07:24:54 --> Total execution time: 1.4434
INFO - 2024-12-24 07:25:41 --> Config Class Initialized
INFO - 2024-12-24 07:25:41 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:25:41 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:25:41 --> Utf8 Class Initialized
INFO - 2024-12-24 07:25:41 --> URI Class Initialized
INFO - 2024-12-24 07:25:41 --> Router Class Initialized
INFO - 2024-12-24 07:25:41 --> Output Class Initialized
INFO - 2024-12-24 07:25:41 --> Security Class Initialized
DEBUG - 2024-12-24 07:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:25:41 --> Input Class Initialized
INFO - 2024-12-24 07:25:41 --> Language Class Initialized
INFO - 2024-12-24 07:25:41 --> Loader Class Initialized
INFO - 2024-12-24 07:25:41 --> Helper loaded: url_helper
INFO - 2024-12-24 07:25:41 --> Helper loaded: file_helper
INFO - 2024-12-24 07:25:41 --> Helper loaded: security_helper
INFO - 2024-12-24 07:25:41 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:25:41 --> Database Driver Class Initialized
INFO - 2024-12-24 07:25:42 --> Email Class Initialized
DEBUG - 2024-12-24 07:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:25:42 --> Helper loaded: form_helper
INFO - 2024-12-24 07:25:42 --> Form Validation Class Initialized
INFO - 2024-12-24 07:25:42 --> Controller Class Initialized
INFO - 2024-12-24 07:25:42 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:25:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:25:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:25:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:25:43 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:25:43 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:25:43 --> Final output sent to browser
DEBUG - 2024-12-24 07:25:43 --> Total execution time: 1.4884
INFO - 2024-12-24 07:26:10 --> Config Class Initialized
INFO - 2024-12-24 07:26:10 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:26:10 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:26:10 --> Utf8 Class Initialized
INFO - 2024-12-24 07:26:10 --> URI Class Initialized
INFO - 2024-12-24 07:26:10 --> Router Class Initialized
INFO - 2024-12-24 07:26:10 --> Output Class Initialized
INFO - 2024-12-24 07:26:10 --> Security Class Initialized
DEBUG - 2024-12-24 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:26:10 --> Input Class Initialized
INFO - 2024-12-24 07:26:10 --> Language Class Initialized
INFO - 2024-12-24 07:26:10 --> Loader Class Initialized
INFO - 2024-12-24 07:26:10 --> Helper loaded: url_helper
INFO - 2024-12-24 07:26:10 --> Helper loaded: file_helper
INFO - 2024-12-24 07:26:10 --> Helper loaded: security_helper
INFO - 2024-12-24 07:26:10 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:26:10 --> Database Driver Class Initialized
INFO - 2024-12-24 07:26:10 --> Email Class Initialized
DEBUG - 2024-12-24 07:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:26:10 --> Helper loaded: form_helper
INFO - 2024-12-24 07:26:10 --> Form Validation Class Initialized
INFO - 2024-12-24 07:26:10 --> Controller Class Initialized
INFO - 2024-12-24 07:26:10 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:26:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:26:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:26:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:26:11 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:26:11 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:26:11 --> Final output sent to browser
DEBUG - 2024-12-24 07:26:11 --> Total execution time: 1.5032
INFO - 2024-12-24 07:28:07 --> Config Class Initialized
INFO - 2024-12-24 07:28:07 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:28:07 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:28:07 --> Utf8 Class Initialized
INFO - 2024-12-24 07:28:07 --> URI Class Initialized
INFO - 2024-12-24 07:28:07 --> Router Class Initialized
INFO - 2024-12-24 07:28:07 --> Output Class Initialized
INFO - 2024-12-24 07:28:07 --> Security Class Initialized
DEBUG - 2024-12-24 07:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:28:07 --> Input Class Initialized
INFO - 2024-12-24 07:28:07 --> Language Class Initialized
INFO - 2024-12-24 07:28:07 --> Loader Class Initialized
INFO - 2024-12-24 07:28:07 --> Helper loaded: url_helper
INFO - 2024-12-24 07:28:07 --> Helper loaded: file_helper
INFO - 2024-12-24 07:28:07 --> Helper loaded: security_helper
INFO - 2024-12-24 07:28:07 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:28:07 --> Database Driver Class Initialized
INFO - 2024-12-24 07:28:08 --> Email Class Initialized
DEBUG - 2024-12-24 07:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:28:08 --> Helper loaded: form_helper
INFO - 2024-12-24 07:28:08 --> Form Validation Class Initialized
INFO - 2024-12-24 07:28:08 --> Controller Class Initialized
INFO - 2024-12-24 07:28:08 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:28:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:28:09 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:28:09 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:28:09 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:28:09 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:28:09 --> Final output sent to browser
DEBUG - 2024-12-24 07:28:09 --> Total execution time: 1.4768
INFO - 2024-12-24 07:28:36 --> Config Class Initialized
INFO - 2024-12-24 07:28:36 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:28:36 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:28:36 --> Utf8 Class Initialized
INFO - 2024-12-24 07:28:36 --> URI Class Initialized
INFO - 2024-12-24 07:28:36 --> Router Class Initialized
INFO - 2024-12-24 07:28:36 --> Output Class Initialized
INFO - 2024-12-24 07:28:36 --> Security Class Initialized
DEBUG - 2024-12-24 07:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:28:36 --> Input Class Initialized
INFO - 2024-12-24 07:28:36 --> Language Class Initialized
INFO - 2024-12-24 07:28:36 --> Loader Class Initialized
INFO - 2024-12-24 07:28:36 --> Helper loaded: url_helper
INFO - 2024-12-24 07:28:36 --> Helper loaded: file_helper
INFO - 2024-12-24 07:28:36 --> Helper loaded: security_helper
INFO - 2024-12-24 07:28:36 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:28:36 --> Database Driver Class Initialized
INFO - 2024-12-24 07:28:37 --> Email Class Initialized
DEBUG - 2024-12-24 07:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:28:37 --> Helper loaded: form_helper
INFO - 2024-12-24 07:28:37 --> Form Validation Class Initialized
INFO - 2024-12-24 07:28:37 --> Controller Class Initialized
INFO - 2024-12-24 07:28:37 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:28:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:28:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:28:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:28:38 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:28:38 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:28:38 --> Final output sent to browser
DEBUG - 2024-12-24 07:28:38 --> Total execution time: 1.4828
INFO - 2024-12-24 07:28:47 --> Config Class Initialized
INFO - 2024-12-24 07:28:47 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:28:47 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:28:47 --> Utf8 Class Initialized
INFO - 2024-12-24 07:28:47 --> URI Class Initialized
INFO - 2024-12-24 07:28:47 --> Router Class Initialized
INFO - 2024-12-24 07:28:47 --> Output Class Initialized
INFO - 2024-12-24 07:28:47 --> Security Class Initialized
DEBUG - 2024-12-24 07:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:28:47 --> Input Class Initialized
INFO - 2024-12-24 07:28:47 --> Language Class Initialized
INFO - 2024-12-24 07:28:47 --> Loader Class Initialized
INFO - 2024-12-24 07:28:47 --> Helper loaded: url_helper
INFO - 2024-12-24 07:28:47 --> Helper loaded: file_helper
INFO - 2024-12-24 07:28:47 --> Helper loaded: security_helper
INFO - 2024-12-24 07:28:47 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:28:47 --> Database Driver Class Initialized
INFO - 2024-12-24 07:28:47 --> Email Class Initialized
DEBUG - 2024-12-24 07:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:28:47 --> Helper loaded: form_helper
INFO - 2024-12-24 07:28:47 --> Form Validation Class Initialized
INFO - 2024-12-24 07:28:47 --> Controller Class Initialized
INFO - 2024-12-24 07:28:47 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:28:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:28:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:28:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:28:48 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:28:48 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:28:48 --> Final output sent to browser
DEBUG - 2024-12-24 07:28:48 --> Total execution time: 1.4703
INFO - 2024-12-24 07:28:52 --> Config Class Initialized
INFO - 2024-12-24 07:28:52 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:28:52 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:28:52 --> Utf8 Class Initialized
INFO - 2024-12-24 07:28:52 --> URI Class Initialized
INFO - 2024-12-24 07:28:52 --> Router Class Initialized
INFO - 2024-12-24 07:28:52 --> Output Class Initialized
INFO - 2024-12-24 07:28:52 --> Security Class Initialized
DEBUG - 2024-12-24 07:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:28:52 --> Input Class Initialized
INFO - 2024-12-24 07:28:52 --> Language Class Initialized
INFO - 2024-12-24 07:28:52 --> Loader Class Initialized
INFO - 2024-12-24 07:28:52 --> Helper loaded: url_helper
INFO - 2024-12-24 07:28:52 --> Helper loaded: file_helper
INFO - 2024-12-24 07:28:52 --> Helper loaded: security_helper
INFO - 2024-12-24 07:28:52 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:28:52 --> Database Driver Class Initialized
INFO - 2024-12-24 07:28:52 --> Email Class Initialized
DEBUG - 2024-12-24 07:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:28:52 --> Helper loaded: form_helper
INFO - 2024-12-24 07:28:52 --> Form Validation Class Initialized
INFO - 2024-12-24 07:28:52 --> Controller Class Initialized
INFO - 2024-12-24 07:28:52 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:28:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:28:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:28:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:28:53 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:28:53 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:28:53 --> Final output sent to browser
DEBUG - 2024-12-24 07:28:53 --> Total execution time: 1.4633
INFO - 2024-12-24 07:29:05 --> Config Class Initialized
INFO - 2024-12-24 07:29:05 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:29:05 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:29:05 --> Utf8 Class Initialized
INFO - 2024-12-24 07:29:05 --> URI Class Initialized
INFO - 2024-12-24 07:29:05 --> Router Class Initialized
INFO - 2024-12-24 07:29:05 --> Output Class Initialized
INFO - 2024-12-24 07:29:05 --> Security Class Initialized
DEBUG - 2024-12-24 07:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:29:05 --> Input Class Initialized
INFO - 2024-12-24 07:29:05 --> Language Class Initialized
INFO - 2024-12-24 07:29:05 --> Loader Class Initialized
INFO - 2024-12-24 07:29:05 --> Helper loaded: url_helper
INFO - 2024-12-24 07:29:05 --> Helper loaded: file_helper
INFO - 2024-12-24 07:29:05 --> Helper loaded: security_helper
INFO - 2024-12-24 07:29:05 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:29:05 --> Database Driver Class Initialized
INFO - 2024-12-24 07:29:06 --> Email Class Initialized
DEBUG - 2024-12-24 07:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:29:06 --> Helper loaded: form_helper
INFO - 2024-12-24 07:29:06 --> Form Validation Class Initialized
INFO - 2024-12-24 07:29:06 --> Controller Class Initialized
INFO - 2024-12-24 07:29:06 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:29:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:29:07 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:29:07 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:29:07 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:29:07 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:29:07 --> Final output sent to browser
DEBUG - 2024-12-24 07:29:07 --> Total execution time: 1.4709
INFO - 2024-12-24 07:31:25 --> Config Class Initialized
INFO - 2024-12-24 07:31:25 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:31:25 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:31:25 --> Utf8 Class Initialized
INFO - 2024-12-24 07:31:25 --> URI Class Initialized
INFO - 2024-12-24 07:31:25 --> Router Class Initialized
INFO - 2024-12-24 07:31:25 --> Output Class Initialized
INFO - 2024-12-24 07:31:25 --> Security Class Initialized
DEBUG - 2024-12-24 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:31:25 --> Input Class Initialized
INFO - 2024-12-24 07:31:25 --> Language Class Initialized
INFO - 2024-12-24 07:31:25 --> Loader Class Initialized
INFO - 2024-12-24 07:31:25 --> Helper loaded: url_helper
INFO - 2024-12-24 07:31:25 --> Helper loaded: file_helper
INFO - 2024-12-24 07:31:25 --> Helper loaded: security_helper
INFO - 2024-12-24 07:31:25 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:31:25 --> Database Driver Class Initialized
INFO - 2024-12-24 07:31:26 --> Email Class Initialized
DEBUG - 2024-12-24 07:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:31:26 --> Helper loaded: form_helper
INFO - 2024-12-24 07:31:26 --> Form Validation Class Initialized
INFO - 2024-12-24 07:31:26 --> Controller Class Initialized
INFO - 2024-12-24 07:31:26 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:31:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:31:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:31:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:31:27 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:31:27 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:31:27 --> Final output sent to browser
DEBUG - 2024-12-24 07:31:27 --> Total execution time: 1.4894
INFO - 2024-12-24 07:31:36 --> Config Class Initialized
INFO - 2024-12-24 07:31:36 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:31:36 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:31:36 --> Utf8 Class Initialized
INFO - 2024-12-24 07:31:36 --> URI Class Initialized
INFO - 2024-12-24 07:31:36 --> Router Class Initialized
INFO - 2024-12-24 07:31:36 --> Output Class Initialized
INFO - 2024-12-24 07:31:36 --> Security Class Initialized
DEBUG - 2024-12-24 07:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:31:36 --> Input Class Initialized
INFO - 2024-12-24 07:31:36 --> Language Class Initialized
INFO - 2024-12-24 07:31:36 --> Loader Class Initialized
INFO - 2024-12-24 07:31:36 --> Helper loaded: url_helper
INFO - 2024-12-24 07:31:36 --> Helper loaded: file_helper
INFO - 2024-12-24 07:31:36 --> Helper loaded: security_helper
INFO - 2024-12-24 07:31:36 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:31:36 --> Database Driver Class Initialized
INFO - 2024-12-24 07:31:37 --> Email Class Initialized
DEBUG - 2024-12-24 07:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:31:37 --> Helper loaded: form_helper
INFO - 2024-12-24 07:31:37 --> Form Validation Class Initialized
INFO - 2024-12-24 07:31:37 --> Controller Class Initialized
INFO - 2024-12-24 07:31:37 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:31:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:31:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:31:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:31:37 --> File loaded: C:\xampp\htdocs\rso\application\views\data/ranap.php
INFO - 2024-12-24 07:31:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:31:37 --> Final output sent to browser
DEBUG - 2024-12-24 07:31:37 --> Total execution time: 1.4695
INFO - 2024-12-24 07:32:35 --> Config Class Initialized
INFO - 2024-12-24 07:32:35 --> Hooks Class Initialized
DEBUG - 2024-12-24 07:32:35 --> UTF-8 Support Enabled
INFO - 2024-12-24 07:32:35 --> Utf8 Class Initialized
INFO - 2024-12-24 07:32:35 --> URI Class Initialized
INFO - 2024-12-24 07:32:35 --> Router Class Initialized
INFO - 2024-12-24 07:32:35 --> Output Class Initialized
INFO - 2024-12-24 07:32:35 --> Security Class Initialized
DEBUG - 2024-12-24 07:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 07:32:35 --> Input Class Initialized
INFO - 2024-12-24 07:32:35 --> Language Class Initialized
INFO - 2024-12-24 07:32:35 --> Loader Class Initialized
INFO - 2024-12-24 07:32:35 --> Helper loaded: url_helper
INFO - 2024-12-24 07:32:35 --> Helper loaded: file_helper
INFO - 2024-12-24 07:32:35 --> Helper loaded: security_helper
INFO - 2024-12-24 07:32:35 --> Helper loaded: wpu_helper
INFO - 2024-12-24 07:32:35 --> Database Driver Class Initialized
INFO - 2024-12-24 07:32:35 --> Email Class Initialized
DEBUG - 2024-12-24 07:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-24 07:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 07:32:35 --> Helper loaded: form_helper
INFO - 2024-12-24 07:32:35 --> Form Validation Class Initialized
INFO - 2024-12-24 07:32:35 --> Controller Class Initialized
INFO - 2024-12-24 07:32:35 --> Model "Data_model" initialized
DEBUG - 2024-12-24 07:32:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 07:32:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/header.php
INFO - 2024-12-24 07:32:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/topbar.php
INFO - 2024-12-24 07:32:37 --> File loaded: C:\xampp\htdocs\rso\application\views\data/rajal.php
INFO - 2024-12-24 07:32:37 --> File loaded: C:\xampp\htdocs\rso\application\views\templates/footer.php
INFO - 2024-12-24 07:32:37 --> Final output sent to browser
DEBUG - 2024-12-24 07:32:37 --> Total execution time: 2.4309
