<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-13 02:04:45 --> Config Class Initialized
INFO - 2024-09-13 02:04:45 --> Hooks Class Initialized
DEBUG - 2024-09-13 02:04:45 --> UTF-8 Support Enabled
INFO - 2024-09-13 02:04:45 --> Utf8 Class Initialized
INFO - 2024-09-13 02:04:45 --> URI Class Initialized
DEBUG - 2024-09-13 02:04:45 --> No URI present. Default controller set.
INFO - 2024-09-13 02:04:45 --> Router Class Initialized
INFO - 2024-09-13 02:04:45 --> Output Class Initialized
INFO - 2024-09-13 02:04:45 --> Security Class Initialized
DEBUG - 2024-09-13 02:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 02:04:45 --> Input Class Initialized
INFO - 2024-09-13 02:04:45 --> Language Class Initialized
INFO - 2024-09-13 02:04:45 --> Loader Class Initialized
INFO - 2024-09-13 02:04:45 --> Helper loaded: url_helper
INFO - 2024-09-13 02:04:45 --> Helper loaded: file_helper
INFO - 2024-09-13 02:04:45 --> Helper loaded: security_helper
INFO - 2024-09-13 02:04:45 --> Helper loaded: wpu_helper
INFO - 2024-09-13 02:04:45 --> Database Driver Class Initialized
INFO - 2024-09-13 02:04:50 --> Config Class Initialized
INFO - 2024-09-13 02:04:50 --> Hooks Class Initialized
DEBUG - 2024-09-13 02:04:50 --> UTF-8 Support Enabled
INFO - 2024-09-13 02:04:50 --> Utf8 Class Initialized
INFO - 2024-09-13 02:04:50 --> URI Class Initialized
DEBUG - 2024-09-13 02:04:50 --> No URI present. Default controller set.
INFO - 2024-09-13 02:04:50 --> Router Class Initialized
INFO - 2024-09-13 02:04:50 --> Output Class Initialized
INFO - 2024-09-13 02:04:50 --> Security Class Initialized
DEBUG - 2024-09-13 02:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 02:04:50 --> Input Class Initialized
INFO - 2024-09-13 02:04:50 --> Language Class Initialized
INFO - 2024-09-13 02:04:50 --> Loader Class Initialized
INFO - 2024-09-13 02:04:50 --> Helper loaded: url_helper
INFO - 2024-09-13 02:04:50 --> Helper loaded: file_helper
INFO - 2024-09-13 02:04:50 --> Helper loaded: security_helper
INFO - 2024-09-13 02:04:50 --> Helper loaded: wpu_helper
INFO - 2024-09-13 02:04:50 --> Database Driver Class Initialized
ERROR - 2024-09-13 02:05:16 --> Unable to connect to the database
INFO - 2024-09-13 02:05:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-13 05:08:39 --> Config Class Initialized
INFO - 2024-09-13 05:08:39 --> Hooks Class Initialized
DEBUG - 2024-09-13 05:08:39 --> UTF-8 Support Enabled
INFO - 2024-09-13 05:08:39 --> Utf8 Class Initialized
INFO - 2024-09-13 05:08:39 --> URI Class Initialized
DEBUG - 2024-09-13 05:08:39 --> No URI present. Default controller set.
INFO - 2024-09-13 05:08:39 --> Router Class Initialized
INFO - 2024-09-13 05:08:39 --> Output Class Initialized
INFO - 2024-09-13 05:08:39 --> Security Class Initialized
DEBUG - 2024-09-13 05:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 05:08:39 --> Input Class Initialized
INFO - 2024-09-13 05:08:39 --> Language Class Initialized
INFO - 2024-09-13 05:08:39 --> Loader Class Initialized
INFO - 2024-09-13 05:08:39 --> Helper loaded: url_helper
INFO - 2024-09-13 05:08:39 --> Helper loaded: file_helper
INFO - 2024-09-13 05:08:39 --> Helper loaded: security_helper
INFO - 2024-09-13 05:08:39 --> Helper loaded: wpu_helper
INFO - 2024-09-13 05:08:39 --> Database Driver Class Initialized
ERROR - 2024-09-13 05:09:09 --> Unable to connect to the database
INFO - 2024-09-13 05:09:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-13 06:25:57 --> Config Class Initialized
INFO - 2024-09-13 06:25:57 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:25:57 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:25:57 --> Utf8 Class Initialized
INFO - 2024-09-13 06:25:57 --> URI Class Initialized
INFO - 2024-09-13 06:25:57 --> Router Class Initialized
INFO - 2024-09-13 06:25:57 --> Output Class Initialized
INFO - 2024-09-13 06:25:57 --> Security Class Initialized
DEBUG - 2024-09-13 06:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:25:57 --> Input Class Initialized
INFO - 2024-09-13 06:25:57 --> Language Class Initialized
INFO - 2024-09-13 06:25:57 --> Loader Class Initialized
INFO - 2024-09-13 06:25:57 --> Helper loaded: url_helper
INFO - 2024-09-13 06:25:57 --> Helper loaded: file_helper
INFO - 2024-09-13 06:25:57 --> Helper loaded: security_helper
INFO - 2024-09-13 06:25:57 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:25:57 --> Database Driver Class Initialized
INFO - 2024-09-13 06:26:01 --> Config Class Initialized
INFO - 2024-09-13 06:26:01 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:26:01 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:26:01 --> Utf8 Class Initialized
INFO - 2024-09-13 06:26:01 --> URI Class Initialized
DEBUG - 2024-09-13 06:26:01 --> No URI present. Default controller set.
INFO - 2024-09-13 06:26:01 --> Router Class Initialized
INFO - 2024-09-13 06:26:01 --> Output Class Initialized
INFO - 2024-09-13 06:26:01 --> Security Class Initialized
DEBUG - 2024-09-13 06:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:26:01 --> Input Class Initialized
INFO - 2024-09-13 06:26:01 --> Language Class Initialized
INFO - 2024-09-13 06:26:01 --> Loader Class Initialized
INFO - 2024-09-13 06:26:01 --> Helper loaded: url_helper
INFO - 2024-09-13 06:26:01 --> Helper loaded: file_helper
INFO - 2024-09-13 06:26:01 --> Helper loaded: security_helper
INFO - 2024-09-13 06:26:01 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:26:01 --> Database Driver Class Initialized
ERROR - 2024-09-13 06:26:08 --> Unable to connect to the database
INFO - 2024-09-13 06:26:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-13 06:26:24 --> Config Class Initialized
INFO - 2024-09-13 06:26:24 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:26:24 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:26:24 --> Utf8 Class Initialized
INFO - 2024-09-13 06:26:24 --> URI Class Initialized
DEBUG - 2024-09-13 06:26:24 --> No URI present. Default controller set.
INFO - 2024-09-13 06:26:24 --> Router Class Initialized
INFO - 2024-09-13 06:26:24 --> Output Class Initialized
INFO - 2024-09-13 06:26:24 --> Security Class Initialized
DEBUG - 2024-09-13 06:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:26:24 --> Input Class Initialized
INFO - 2024-09-13 06:26:24 --> Language Class Initialized
INFO - 2024-09-13 06:26:24 --> Loader Class Initialized
INFO - 2024-09-13 06:26:24 --> Helper loaded: url_helper
INFO - 2024-09-13 06:26:24 --> Helper loaded: file_helper
INFO - 2024-09-13 06:26:24 --> Helper loaded: security_helper
INFO - 2024-09-13 06:26:24 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:26:24 --> Database Driver Class Initialized
ERROR - 2024-09-13 06:26:31 --> Unable to connect to the database
INFO - 2024-09-13 06:26:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-13 06:26:35 --> Config Class Initialized
INFO - 2024-09-13 06:26:35 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:26:35 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:26:35 --> Utf8 Class Initialized
INFO - 2024-09-13 06:26:35 --> URI Class Initialized
DEBUG - 2024-09-13 06:26:35 --> No URI present. Default controller set.
INFO - 2024-09-13 06:26:35 --> Router Class Initialized
INFO - 2024-09-13 06:26:35 --> Output Class Initialized
INFO - 2024-09-13 06:26:35 --> Security Class Initialized
DEBUG - 2024-09-13 06:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:26:35 --> Input Class Initialized
INFO - 2024-09-13 06:26:35 --> Language Class Initialized
INFO - 2024-09-13 06:26:35 --> Loader Class Initialized
INFO - 2024-09-13 06:26:35 --> Helper loaded: url_helper
INFO - 2024-09-13 06:26:35 --> Helper loaded: file_helper
INFO - 2024-09-13 06:26:35 --> Helper loaded: security_helper
INFO - 2024-09-13 06:26:35 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:26:35 --> Database Driver Class Initialized
ERROR - 2024-09-13 06:26:42 --> Unable to connect to the database
INFO - 2024-09-13 06:26:42 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-13 06:27:27 --> Config Class Initialized
INFO - 2024-09-13 06:27:27 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:27:27 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:27:27 --> Utf8 Class Initialized
INFO - 2024-09-13 06:27:27 --> URI Class Initialized
DEBUG - 2024-09-13 06:27:27 --> No URI present. Default controller set.
INFO - 2024-09-13 06:27:27 --> Router Class Initialized
INFO - 2024-09-13 06:27:27 --> Output Class Initialized
INFO - 2024-09-13 06:27:27 --> Security Class Initialized
DEBUG - 2024-09-13 06:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:27:27 --> Input Class Initialized
INFO - 2024-09-13 06:27:27 --> Language Class Initialized
INFO - 2024-09-13 06:27:27 --> Loader Class Initialized
INFO - 2024-09-13 06:27:27 --> Helper loaded: url_helper
INFO - 2024-09-13 06:27:27 --> Helper loaded: file_helper
INFO - 2024-09-13 06:27:27 --> Helper loaded: security_helper
INFO - 2024-09-13 06:27:27 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:27:27 --> Database Driver Class Initialized
INFO - 2024-09-13 06:27:27 --> Email Class Initialized
DEBUG - 2024-09-13 06:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 06:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 06:27:27 --> Helper loaded: form_helper
INFO - 2024-09-13 06:27:27 --> Form Validation Class Initialized
INFO - 2024-09-13 06:27:27 --> Controller Class Initialized
DEBUG - 2024-09-13 06:27:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 06:27:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 06:27:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 06:27:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 06:27:27 --> Final output sent to browser
DEBUG - 2024-09-13 06:27:27 --> Total execution time: 0.2223
INFO - 2024-09-13 06:27:30 --> Config Class Initialized
INFO - 2024-09-13 06:27:30 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:27:30 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:27:30 --> Utf8 Class Initialized
INFO - 2024-09-13 06:27:30 --> URI Class Initialized
INFO - 2024-09-13 06:27:30 --> Router Class Initialized
INFO - 2024-09-13 06:27:30 --> Output Class Initialized
INFO - 2024-09-13 06:27:30 --> Security Class Initialized
DEBUG - 2024-09-13 06:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:27:30 --> Input Class Initialized
INFO - 2024-09-13 06:27:30 --> Language Class Initialized
INFO - 2024-09-13 06:27:30 --> Loader Class Initialized
INFO - 2024-09-13 06:27:30 --> Helper loaded: url_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: file_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: security_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:27:30 --> Database Driver Class Initialized
INFO - 2024-09-13 06:27:30 --> Email Class Initialized
DEBUG - 2024-09-13 06:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 06:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 06:27:30 --> Helper loaded: form_helper
INFO - 2024-09-13 06:27:30 --> Form Validation Class Initialized
INFO - 2024-09-13 06:27:30 --> Controller Class Initialized
DEBUG - 2024-09-13 06:27:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 06:27:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-13 06:27:30 --> Config Class Initialized
INFO - 2024-09-13 06:27:30 --> Hooks Class Initialized
DEBUG - 2024-09-13 06:27:30 --> UTF-8 Support Enabled
INFO - 2024-09-13 06:27:30 --> Utf8 Class Initialized
INFO - 2024-09-13 06:27:30 --> URI Class Initialized
INFO - 2024-09-13 06:27:30 --> Router Class Initialized
INFO - 2024-09-13 06:27:30 --> Output Class Initialized
INFO - 2024-09-13 06:27:30 --> Security Class Initialized
DEBUG - 2024-09-13 06:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 06:27:30 --> Input Class Initialized
INFO - 2024-09-13 06:27:30 --> Language Class Initialized
INFO - 2024-09-13 06:27:30 --> Loader Class Initialized
INFO - 2024-09-13 06:27:30 --> Helper loaded: url_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: file_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: security_helper
INFO - 2024-09-13 06:27:30 --> Helper loaded: wpu_helper
INFO - 2024-09-13 06:27:30 --> Database Driver Class Initialized
INFO - 2024-09-13 06:27:30 --> Email Class Initialized
DEBUG - 2024-09-13 06:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 06:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 06:27:30 --> Helper loaded: form_helper
INFO - 2024-09-13 06:27:30 --> Form Validation Class Initialized
INFO - 2024-09-13 06:27:30 --> Controller Class Initialized
INFO - 2024-09-13 06:27:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-13 06:27:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 06:27:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-13 06:27:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-13 06:27:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-13 06:27:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-13 06:27:31 --> Final output sent to browser
DEBUG - 2024-09-13 06:27:31 --> Total execution time: 0.6111
INFO - 2024-09-13 09:25:33 --> Config Class Initialized
INFO - 2024-09-13 09:25:33 --> Hooks Class Initialized
DEBUG - 2024-09-13 09:25:33 --> UTF-8 Support Enabled
INFO - 2024-09-13 09:25:33 --> Utf8 Class Initialized
INFO - 2024-09-13 09:25:33 --> URI Class Initialized
DEBUG - 2024-09-13 09:25:33 --> No URI present. Default controller set.
INFO - 2024-09-13 09:25:33 --> Router Class Initialized
INFO - 2024-09-13 09:25:33 --> Output Class Initialized
INFO - 2024-09-13 09:25:33 --> Security Class Initialized
DEBUG - 2024-09-13 09:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 09:25:33 --> Input Class Initialized
INFO - 2024-09-13 09:25:33 --> Language Class Initialized
INFO - 2024-09-13 09:25:33 --> Loader Class Initialized
INFO - 2024-09-13 09:25:33 --> Helper loaded: url_helper
INFO - 2024-09-13 09:25:33 --> Helper loaded: file_helper
INFO - 2024-09-13 09:25:33 --> Helper loaded: security_helper
INFO - 2024-09-13 09:25:33 --> Helper loaded: wpu_helper
INFO - 2024-09-13 09:25:33 --> Database Driver Class Initialized
INFO - 2024-09-13 09:25:33 --> Email Class Initialized
DEBUG - 2024-09-13 09:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 09:25:33 --> Helper loaded: form_helper
INFO - 2024-09-13 09:25:33 --> Form Validation Class Initialized
INFO - 2024-09-13 09:25:33 --> Controller Class Initialized
DEBUG - 2024-09-13 09:25:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 09:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 09:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 09:25:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 09:25:33 --> Final output sent to browser
DEBUG - 2024-09-13 09:25:33 --> Total execution time: 0.2416
INFO - 2024-09-13 09:25:34 --> Config Class Initialized
INFO - 2024-09-13 09:25:34 --> Hooks Class Initialized
DEBUG - 2024-09-13 09:25:34 --> UTF-8 Support Enabled
INFO - 2024-09-13 09:25:34 --> Utf8 Class Initialized
INFO - 2024-09-13 09:25:34 --> URI Class Initialized
DEBUG - 2024-09-13 09:25:34 --> No URI present. Default controller set.
INFO - 2024-09-13 09:25:34 --> Router Class Initialized
INFO - 2024-09-13 09:25:34 --> Output Class Initialized
INFO - 2024-09-13 09:25:34 --> Security Class Initialized
DEBUG - 2024-09-13 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 09:25:34 --> Input Class Initialized
INFO - 2024-09-13 09:25:34 --> Language Class Initialized
INFO - 2024-09-13 09:25:34 --> Loader Class Initialized
INFO - 2024-09-13 09:25:34 --> Helper loaded: url_helper
INFO - 2024-09-13 09:25:34 --> Helper loaded: file_helper
INFO - 2024-09-13 09:25:34 --> Helper loaded: security_helper
INFO - 2024-09-13 09:25:34 --> Helper loaded: wpu_helper
INFO - 2024-09-13 09:25:34 --> Database Driver Class Initialized
INFO - 2024-09-13 09:25:35 --> Email Class Initialized
DEBUG - 2024-09-13 09:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 09:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 09:25:35 --> Helper loaded: form_helper
INFO - 2024-09-13 09:25:35 --> Form Validation Class Initialized
INFO - 2024-09-13 09:25:35 --> Controller Class Initialized
DEBUG - 2024-09-13 09:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 09:25:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 09:25:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 09:25:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 09:25:35 --> Final output sent to browser
DEBUG - 2024-09-13 09:25:35 --> Total execution time: 0.2403
INFO - 2024-09-13 12:42:02 --> Config Class Initialized
INFO - 2024-09-13 12:42:02 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:42:02 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:42:02 --> Utf8 Class Initialized
INFO - 2024-09-13 12:42:02 --> URI Class Initialized
DEBUG - 2024-09-13 12:42:02 --> No URI present. Default controller set.
INFO - 2024-09-13 12:42:02 --> Router Class Initialized
INFO - 2024-09-13 12:42:02 --> Output Class Initialized
INFO - 2024-09-13 12:42:02 --> Security Class Initialized
DEBUG - 2024-09-13 12:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:42:02 --> Input Class Initialized
INFO - 2024-09-13 12:42:02 --> Language Class Initialized
INFO - 2024-09-13 12:42:02 --> Loader Class Initialized
INFO - 2024-09-13 12:42:02 --> Helper loaded: url_helper
INFO - 2024-09-13 12:42:02 --> Helper loaded: file_helper
INFO - 2024-09-13 12:42:02 --> Helper loaded: security_helper
INFO - 2024-09-13 12:42:02 --> Helper loaded: wpu_helper
INFO - 2024-09-13 12:42:02 --> Database Driver Class Initialized
INFO - 2024-09-13 12:42:02 --> Email Class Initialized
DEBUG - 2024-09-13 12:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 12:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:42:02 --> Helper loaded: form_helper
INFO - 2024-09-13 12:42:02 --> Form Validation Class Initialized
INFO - 2024-09-13 12:42:02 --> Controller Class Initialized
DEBUG - 2024-09-13 12:42:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 12:42:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 12:42:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 12:42:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 12:42:02 --> Final output sent to browser
DEBUG - 2024-09-13 12:42:02 --> Total execution time: 0.2374
INFO - 2024-09-13 12:42:06 --> Config Class Initialized
INFO - 2024-09-13 12:42:06 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:42:06 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:42:06 --> Utf8 Class Initialized
INFO - 2024-09-13 12:42:06 --> URI Class Initialized
INFO - 2024-09-13 12:42:06 --> Router Class Initialized
INFO - 2024-09-13 12:42:06 --> Output Class Initialized
INFO - 2024-09-13 12:42:06 --> Security Class Initialized
DEBUG - 2024-09-13 12:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:42:06 --> Input Class Initialized
INFO - 2024-09-13 12:42:06 --> Language Class Initialized
INFO - 2024-09-13 12:42:06 --> Loader Class Initialized
INFO - 2024-09-13 12:42:06 --> Helper loaded: url_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: file_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: security_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: wpu_helper
INFO - 2024-09-13 12:42:06 --> Database Driver Class Initialized
INFO - 2024-09-13 12:42:06 --> Email Class Initialized
DEBUG - 2024-09-13 12:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 12:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:42:06 --> Helper loaded: form_helper
INFO - 2024-09-13 12:42:06 --> Form Validation Class Initialized
INFO - 2024-09-13 12:42:06 --> Controller Class Initialized
DEBUG - 2024-09-13 12:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 12:42:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-13 12:42:06 --> Config Class Initialized
INFO - 2024-09-13 12:42:06 --> Hooks Class Initialized
DEBUG - 2024-09-13 12:42:06 --> UTF-8 Support Enabled
INFO - 2024-09-13 12:42:06 --> Utf8 Class Initialized
INFO - 2024-09-13 12:42:06 --> URI Class Initialized
INFO - 2024-09-13 12:42:06 --> Router Class Initialized
INFO - 2024-09-13 12:42:06 --> Output Class Initialized
INFO - 2024-09-13 12:42:06 --> Security Class Initialized
DEBUG - 2024-09-13 12:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 12:42:06 --> Input Class Initialized
INFO - 2024-09-13 12:42:06 --> Language Class Initialized
INFO - 2024-09-13 12:42:06 --> Loader Class Initialized
INFO - 2024-09-13 12:42:06 --> Helper loaded: url_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: file_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: security_helper
INFO - 2024-09-13 12:42:06 --> Helper loaded: wpu_helper
INFO - 2024-09-13 12:42:06 --> Database Driver Class Initialized
INFO - 2024-09-13 12:42:07 --> Email Class Initialized
DEBUG - 2024-09-13 12:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 12:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 12:42:07 --> Helper loaded: form_helper
INFO - 2024-09-13 12:42:07 --> Form Validation Class Initialized
INFO - 2024-09-13 12:42:07 --> Controller Class Initialized
INFO - 2024-09-13 12:42:07 --> Model "Antrol_model" initialized
DEBUG - 2024-09-13 12:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 12:42:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-13 12:42:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-13 12:42:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-13 12:42:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-13 12:42:07 --> Final output sent to browser
DEBUG - 2024-09-13 12:42:07 --> Total execution time: 0.6401
INFO - 2024-09-13 17:26:33 --> Config Class Initialized
INFO - 2024-09-13 17:26:33 --> Hooks Class Initialized
DEBUG - 2024-09-13 17:26:33 --> UTF-8 Support Enabled
INFO - 2024-09-13 17:26:33 --> Utf8 Class Initialized
INFO - 2024-09-13 17:26:33 --> URI Class Initialized
DEBUG - 2024-09-13 17:26:33 --> No URI present. Default controller set.
INFO - 2024-09-13 17:26:33 --> Router Class Initialized
INFO - 2024-09-13 17:26:33 --> Output Class Initialized
INFO - 2024-09-13 17:26:33 --> Security Class Initialized
DEBUG - 2024-09-13 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 17:26:33 --> Input Class Initialized
INFO - 2024-09-13 17:26:33 --> Language Class Initialized
INFO - 2024-09-13 17:26:33 --> Loader Class Initialized
INFO - 2024-09-13 17:26:33 --> Helper loaded: url_helper
INFO - 2024-09-13 17:26:33 --> Helper loaded: file_helper
INFO - 2024-09-13 17:26:33 --> Helper loaded: security_helper
INFO - 2024-09-13 17:26:33 --> Helper loaded: wpu_helper
INFO - 2024-09-13 17:26:33 --> Database Driver Class Initialized
INFO - 2024-09-13 17:26:33 --> Email Class Initialized
DEBUG - 2024-09-13 17:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 17:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 17:26:33 --> Helper loaded: form_helper
INFO - 2024-09-13 17:26:33 --> Form Validation Class Initialized
INFO - 2024-09-13 17:26:33 --> Controller Class Initialized
DEBUG - 2024-09-13 17:26:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 17:26:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 17:26:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 17:26:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 17:26:33 --> Final output sent to browser
DEBUG - 2024-09-13 17:26:33 --> Total execution time: 0.2338
INFO - 2024-09-13 18:16:05 --> Config Class Initialized
INFO - 2024-09-13 18:16:05 --> Hooks Class Initialized
DEBUG - 2024-09-13 18:16:05 --> UTF-8 Support Enabled
INFO - 2024-09-13 18:16:05 --> Utf8 Class Initialized
INFO - 2024-09-13 18:16:05 --> URI Class Initialized
DEBUG - 2024-09-13 18:16:05 --> No URI present. Default controller set.
INFO - 2024-09-13 18:16:05 --> Router Class Initialized
INFO - 2024-09-13 18:16:05 --> Output Class Initialized
INFO - 2024-09-13 18:16:05 --> Security Class Initialized
DEBUG - 2024-09-13 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 18:16:05 --> Input Class Initialized
INFO - 2024-09-13 18:16:05 --> Language Class Initialized
INFO - 2024-09-13 18:16:05 --> Loader Class Initialized
INFO - 2024-09-13 18:16:05 --> Helper loaded: url_helper
INFO - 2024-09-13 18:16:05 --> Helper loaded: file_helper
INFO - 2024-09-13 18:16:05 --> Helper loaded: security_helper
INFO - 2024-09-13 18:16:05 --> Helper loaded: wpu_helper
INFO - 2024-09-13 18:16:05 --> Database Driver Class Initialized
INFO - 2024-09-13 18:16:05 --> Email Class Initialized
DEBUG - 2024-09-13 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 18:16:05 --> Helper loaded: form_helper
INFO - 2024-09-13 18:16:05 --> Form Validation Class Initialized
INFO - 2024-09-13 18:16:05 --> Controller Class Initialized
DEBUG - 2024-09-13 18:16:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 18:16:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 18:16:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 18:16:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 18:16:05 --> Final output sent to browser
DEBUG - 2024-09-13 18:16:05 --> Total execution time: 0.2252
INFO - 2024-09-13 18:16:06 --> Config Class Initialized
INFO - 2024-09-13 18:16:06 --> Hooks Class Initialized
DEBUG - 2024-09-13 18:16:06 --> UTF-8 Support Enabled
INFO - 2024-09-13 18:16:06 --> Utf8 Class Initialized
INFO - 2024-09-13 18:16:06 --> URI Class Initialized
DEBUG - 2024-09-13 18:16:06 --> No URI present. Default controller set.
INFO - 2024-09-13 18:16:06 --> Router Class Initialized
INFO - 2024-09-13 18:16:06 --> Output Class Initialized
INFO - 2024-09-13 18:16:06 --> Security Class Initialized
DEBUG - 2024-09-13 18:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-13 18:16:06 --> Input Class Initialized
INFO - 2024-09-13 18:16:06 --> Language Class Initialized
INFO - 2024-09-13 18:16:06 --> Loader Class Initialized
INFO - 2024-09-13 18:16:06 --> Helper loaded: url_helper
INFO - 2024-09-13 18:16:06 --> Helper loaded: file_helper
INFO - 2024-09-13 18:16:06 --> Helper loaded: security_helper
INFO - 2024-09-13 18:16:06 --> Helper loaded: wpu_helper
INFO - 2024-09-13 18:16:06 --> Database Driver Class Initialized
INFO - 2024-09-13 18:16:06 --> Email Class Initialized
DEBUG - 2024-09-13 18:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-13 18:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-13 18:16:06 --> Helper loaded: form_helper
INFO - 2024-09-13 18:16:06 --> Form Validation Class Initialized
INFO - 2024-09-13 18:16:06 --> Controller Class Initialized
DEBUG - 2024-09-13 18:16:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-13 18:16:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-13 18:16:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-13 18:16:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-13 18:16:06 --> Final output sent to browser
DEBUG - 2024-09-13 18:16:06 --> Total execution time: 0.4755
