<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-14 00:00:00 --> Config Class Initialized
INFO - 2024-08-14 00:00:00 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:00:00 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:00:00 --> Utf8 Class Initialized
INFO - 2024-08-14 00:00:00 --> URI Class Initialized
INFO - 2024-08-14 00:00:00 --> Router Class Initialized
INFO - 2024-08-14 00:00:00 --> Output Class Initialized
INFO - 2024-08-14 00:00:00 --> Security Class Initialized
DEBUG - 2024-08-14 00:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:00:00 --> Input Class Initialized
INFO - 2024-08-14 00:00:00 --> Language Class Initialized
INFO - 2024-08-14 00:00:00 --> Loader Class Initialized
INFO - 2024-08-14 00:00:00 --> Helper loaded: url_helper
INFO - 2024-08-14 00:00:00 --> Helper loaded: file_helper
INFO - 2024-08-14 00:00:00 --> Helper loaded: security_helper
INFO - 2024-08-14 00:00:00 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:00:00 --> Database Driver Class Initialized
INFO - 2024-08-14 00:00:00 --> Email Class Initialized
DEBUG - 2024-08-14 00:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:00:00 --> Helper loaded: form_helper
INFO - 2024-08-14 00:00:00 --> Form Validation Class Initialized
INFO - 2024-08-14 00:00:00 --> Controller Class Initialized
INFO - 2024-08-14 00:00:00 --> Model "User_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:00:00 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:00:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:00:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:00:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:00:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:00:00 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:00:00 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:00:00 --> Final output sent to browser
DEBUG - 2024-08-14 00:00:00 --> Total execution time: 0.1062
INFO - 2024-08-14 00:00:03 --> Config Class Initialized
INFO - 2024-08-14 00:00:03 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:00:03 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:00:03 --> Utf8 Class Initialized
INFO - 2024-08-14 00:00:03 --> URI Class Initialized
INFO - 2024-08-14 00:00:03 --> Router Class Initialized
INFO - 2024-08-14 00:00:03 --> Output Class Initialized
INFO - 2024-08-14 00:00:03 --> Security Class Initialized
DEBUG - 2024-08-14 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:00:03 --> Input Class Initialized
INFO - 2024-08-14 00:00:03 --> Language Class Initialized
INFO - 2024-08-14 00:00:03 --> Loader Class Initialized
INFO - 2024-08-14 00:00:03 --> Helper loaded: url_helper
INFO - 2024-08-14 00:00:03 --> Helper loaded: file_helper
INFO - 2024-08-14 00:00:03 --> Helper loaded: security_helper
INFO - 2024-08-14 00:00:03 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:00:03 --> Database Driver Class Initialized
INFO - 2024-08-14 00:00:03 --> Email Class Initialized
DEBUG - 2024-08-14 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:00:03 --> Helper loaded: form_helper
INFO - 2024-08-14 00:00:03 --> Form Validation Class Initialized
INFO - 2024-08-14 00:00:03 --> Controller Class Initialized
INFO - 2024-08-14 00:00:03 --> Model "User_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:00:03 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:00:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:00:04 --> Final output sent to browser
DEBUG - 2024-08-14 00:00:04 --> Total execution time: 1.3512
INFO - 2024-08-14 00:02:48 --> Config Class Initialized
INFO - 2024-08-14 00:02:48 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:02:48 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:02:48 --> Utf8 Class Initialized
INFO - 2024-08-14 00:02:48 --> URI Class Initialized
INFO - 2024-08-14 00:02:48 --> Router Class Initialized
INFO - 2024-08-14 00:02:48 --> Output Class Initialized
INFO - 2024-08-14 00:02:48 --> Security Class Initialized
DEBUG - 2024-08-14 00:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:02:48 --> Input Class Initialized
INFO - 2024-08-14 00:02:48 --> Language Class Initialized
INFO - 2024-08-14 00:02:48 --> Loader Class Initialized
INFO - 2024-08-14 00:02:48 --> Helper loaded: url_helper
INFO - 2024-08-14 00:02:48 --> Helper loaded: file_helper
INFO - 2024-08-14 00:02:48 --> Helper loaded: security_helper
INFO - 2024-08-14 00:02:48 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:02:48 --> Database Driver Class Initialized
INFO - 2024-08-14 00:02:48 --> Email Class Initialized
DEBUG - 2024-08-14 00:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:02:48 --> Helper loaded: form_helper
INFO - 2024-08-14 00:02:48 --> Form Validation Class Initialized
INFO - 2024-08-14 00:02:48 --> Controller Class Initialized
INFO - 2024-08-14 00:02:48 --> Model "User_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:02:48 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:02:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:02:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:02:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:02:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:02:49 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:02:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:02:49 --> Final output sent to browser
DEBUG - 2024-08-14 00:02:49 --> Total execution time: 0.1237
INFO - 2024-08-14 00:02:49 --> Config Class Initialized
INFO - 2024-08-14 00:02:49 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:02:49 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:02:49 --> Utf8 Class Initialized
INFO - 2024-08-14 00:02:49 --> URI Class Initialized
INFO - 2024-08-14 00:02:49 --> Router Class Initialized
INFO - 2024-08-14 00:02:49 --> Output Class Initialized
INFO - 2024-08-14 00:02:49 --> Security Class Initialized
DEBUG - 2024-08-14 00:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:02:49 --> Input Class Initialized
INFO - 2024-08-14 00:02:49 --> Language Class Initialized
ERROR - 2024-08-14 00:02:50 --> 404 Page Not Found: Your_export_url/index
INFO - 2024-08-14 00:02:52 --> Config Class Initialized
INFO - 2024-08-14 00:02:52 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:02:52 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:02:52 --> Utf8 Class Initialized
INFO - 2024-08-14 00:02:52 --> URI Class Initialized
INFO - 2024-08-14 00:02:52 --> Router Class Initialized
INFO - 2024-08-14 00:02:52 --> Output Class Initialized
INFO - 2024-08-14 00:02:52 --> Security Class Initialized
DEBUG - 2024-08-14 00:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:02:52 --> Input Class Initialized
INFO - 2024-08-14 00:02:52 --> Language Class Initialized
INFO - 2024-08-14 00:02:52 --> Loader Class Initialized
INFO - 2024-08-14 00:02:52 --> Helper loaded: url_helper
INFO - 2024-08-14 00:02:52 --> Helper loaded: file_helper
INFO - 2024-08-14 00:02:52 --> Helper loaded: security_helper
INFO - 2024-08-14 00:02:52 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:02:52 --> Database Driver Class Initialized
INFO - 2024-08-14 00:02:52 --> Email Class Initialized
DEBUG - 2024-08-14 00:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:02:52 --> Helper loaded: form_helper
INFO - 2024-08-14 00:02:52 --> Form Validation Class Initialized
INFO - 2024-08-14 00:02:52 --> Controller Class Initialized
INFO - 2024-08-14 00:02:52 --> Model "User_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:02:52 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:02:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:02:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:02:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:02:52 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:02:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:02:52 --> Final output sent to browser
DEBUG - 2024-08-14 00:02:52 --> Total execution time: 0.0709
INFO - 2024-08-14 00:03:09 --> Config Class Initialized
INFO - 2024-08-14 00:03:09 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:03:09 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:03:09 --> Utf8 Class Initialized
INFO - 2024-08-14 00:03:09 --> URI Class Initialized
INFO - 2024-08-14 00:03:09 --> Router Class Initialized
INFO - 2024-08-14 00:03:09 --> Output Class Initialized
INFO - 2024-08-14 00:03:09 --> Security Class Initialized
DEBUG - 2024-08-14 00:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:03:09 --> Input Class Initialized
INFO - 2024-08-14 00:03:09 --> Language Class Initialized
INFO - 2024-08-14 00:03:09 --> Loader Class Initialized
INFO - 2024-08-14 00:03:09 --> Helper loaded: url_helper
INFO - 2024-08-14 00:03:09 --> Helper loaded: file_helper
INFO - 2024-08-14 00:03:09 --> Helper loaded: security_helper
INFO - 2024-08-14 00:03:09 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:03:09 --> Database Driver Class Initialized
INFO - 2024-08-14 00:03:09 --> Email Class Initialized
DEBUG - 2024-08-14 00:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:03:09 --> Helper loaded: form_helper
INFO - 2024-08-14 00:03:09 --> Form Validation Class Initialized
INFO - 2024-08-14 00:03:09 --> Controller Class Initialized
INFO - 2024-08-14 00:03:09 --> Model "User_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:03:09 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:03:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:03:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:03:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:03:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:03:09 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:03:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:03:09 --> Final output sent to browser
DEBUG - 2024-08-14 00:03:09 --> Total execution time: 0.1170
INFO - 2024-08-14 00:03:30 --> Config Class Initialized
INFO - 2024-08-14 00:03:30 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:03:30 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:03:30 --> Utf8 Class Initialized
INFO - 2024-08-14 00:03:30 --> URI Class Initialized
INFO - 2024-08-14 00:03:30 --> Router Class Initialized
INFO - 2024-08-14 00:03:30 --> Output Class Initialized
INFO - 2024-08-14 00:03:30 --> Security Class Initialized
DEBUG - 2024-08-14 00:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:03:30 --> Input Class Initialized
INFO - 2024-08-14 00:03:30 --> Language Class Initialized
INFO - 2024-08-14 00:03:30 --> Loader Class Initialized
INFO - 2024-08-14 00:03:30 --> Helper loaded: url_helper
INFO - 2024-08-14 00:03:30 --> Helper loaded: file_helper
INFO - 2024-08-14 00:03:30 --> Helper loaded: security_helper
INFO - 2024-08-14 00:03:30 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:03:30 --> Database Driver Class Initialized
INFO - 2024-08-14 00:03:30 --> Email Class Initialized
DEBUG - 2024-08-14 00:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:03:30 --> Helper loaded: form_helper
INFO - 2024-08-14 00:03:30 --> Form Validation Class Initialized
INFO - 2024-08-14 00:03:30 --> Controller Class Initialized
INFO - 2024-08-14 00:03:30 --> Model "User_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:03:30 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:03:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:03:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:03:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:03:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:03:30 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:03:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:03:30 --> Final output sent to browser
DEBUG - 2024-08-14 00:03:30 --> Total execution time: 0.1226
INFO - 2024-08-14 00:03:36 --> Config Class Initialized
INFO - 2024-08-14 00:03:36 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:03:36 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:03:36 --> Utf8 Class Initialized
INFO - 2024-08-14 00:03:36 --> URI Class Initialized
INFO - 2024-08-14 00:03:36 --> Router Class Initialized
INFO - 2024-08-14 00:03:36 --> Output Class Initialized
INFO - 2024-08-14 00:03:36 --> Security Class Initialized
DEBUG - 2024-08-14 00:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:03:36 --> Input Class Initialized
INFO - 2024-08-14 00:03:36 --> Language Class Initialized
INFO - 2024-08-14 00:03:36 --> Loader Class Initialized
INFO - 2024-08-14 00:03:36 --> Helper loaded: url_helper
INFO - 2024-08-14 00:03:36 --> Helper loaded: file_helper
INFO - 2024-08-14 00:03:36 --> Helper loaded: security_helper
INFO - 2024-08-14 00:03:36 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:03:36 --> Database Driver Class Initialized
INFO - 2024-08-14 00:03:36 --> Email Class Initialized
DEBUG - 2024-08-14 00:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:03:36 --> Helper loaded: form_helper
INFO - 2024-08-14 00:03:36 --> Form Validation Class Initialized
INFO - 2024-08-14 00:03:36 --> Controller Class Initialized
INFO - 2024-08-14 00:03:36 --> Model "User_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:03:36 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:03:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:03:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:03:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:03:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:03:36 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:03:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:03:36 --> Final output sent to browser
DEBUG - 2024-08-14 00:03:36 --> Total execution time: 0.0947
INFO - 2024-08-14 00:03:51 --> Config Class Initialized
INFO - 2024-08-14 00:03:51 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:03:51 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:03:51 --> Utf8 Class Initialized
INFO - 2024-08-14 00:03:51 --> URI Class Initialized
INFO - 2024-08-14 00:03:51 --> Router Class Initialized
INFO - 2024-08-14 00:03:51 --> Output Class Initialized
INFO - 2024-08-14 00:03:51 --> Security Class Initialized
DEBUG - 2024-08-14 00:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:03:51 --> Input Class Initialized
INFO - 2024-08-14 00:03:51 --> Language Class Initialized
INFO - 2024-08-14 00:03:51 --> Loader Class Initialized
INFO - 2024-08-14 00:03:51 --> Helper loaded: url_helper
INFO - 2024-08-14 00:03:51 --> Helper loaded: file_helper
INFO - 2024-08-14 00:03:51 --> Helper loaded: security_helper
INFO - 2024-08-14 00:03:51 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:03:51 --> Database Driver Class Initialized
INFO - 2024-08-14 00:03:51 --> Email Class Initialized
DEBUG - 2024-08-14 00:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:03:51 --> Helper loaded: form_helper
INFO - 2024-08-14 00:03:51 --> Form Validation Class Initialized
INFO - 2024-08-14 00:03:51 --> Controller Class Initialized
INFO - 2024-08-14 00:03:51 --> Model "User_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:03:51 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:03:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:03:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:03:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:03:51 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:03:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:03:51 --> Final output sent to browser
DEBUG - 2024-08-14 00:03:51 --> Total execution time: 0.1301
INFO - 2024-08-14 00:04:21 --> Config Class Initialized
INFO - 2024-08-14 00:04:21 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:04:21 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:04:21 --> Utf8 Class Initialized
INFO - 2024-08-14 00:04:21 --> URI Class Initialized
INFO - 2024-08-14 00:04:21 --> Router Class Initialized
INFO - 2024-08-14 00:04:21 --> Output Class Initialized
INFO - 2024-08-14 00:04:21 --> Security Class Initialized
DEBUG - 2024-08-14 00:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:04:21 --> Input Class Initialized
INFO - 2024-08-14 00:04:21 --> Language Class Initialized
INFO - 2024-08-14 00:04:21 --> Loader Class Initialized
INFO - 2024-08-14 00:04:21 --> Helper loaded: url_helper
INFO - 2024-08-14 00:04:21 --> Helper loaded: file_helper
INFO - 2024-08-14 00:04:21 --> Helper loaded: security_helper
INFO - 2024-08-14 00:04:21 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:04:21 --> Database Driver Class Initialized
INFO - 2024-08-14 00:04:21 --> Email Class Initialized
DEBUG - 2024-08-14 00:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:04:21 --> Helper loaded: form_helper
INFO - 2024-08-14 00:04:21 --> Form Validation Class Initialized
INFO - 2024-08-14 00:04:21 --> Controller Class Initialized
INFO - 2024-08-14 00:04:21 --> Model "User_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:04:21 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:04:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:04:22 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:04:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:04:22 --> Final output sent to browser
DEBUG - 2024-08-14 00:04:22 --> Total execution time: 0.1221
INFO - 2024-08-14 00:05:16 --> Config Class Initialized
INFO - 2024-08-14 00:05:16 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:16 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:16 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:16 --> URI Class Initialized
INFO - 2024-08-14 00:05:16 --> Router Class Initialized
INFO - 2024-08-14 00:05:16 --> Output Class Initialized
INFO - 2024-08-14 00:05:16 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:16 --> Input Class Initialized
INFO - 2024-08-14 00:05:16 --> Language Class Initialized
INFO - 2024-08-14 00:05:16 --> Loader Class Initialized
INFO - 2024-08-14 00:05:16 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:16 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:16 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:16 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:16 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:16 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:16 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:16 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:16 --> Controller Class Initialized
INFO - 2024-08-14 00:05:16 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:16 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:16 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:16 --> Total execution time: 0.1332
INFO - 2024-08-14 00:05:22 --> Config Class Initialized
INFO - 2024-08-14 00:05:22 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:22 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:22 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:22 --> URI Class Initialized
INFO - 2024-08-14 00:05:22 --> Router Class Initialized
INFO - 2024-08-14 00:05:22 --> Output Class Initialized
INFO - 2024-08-14 00:05:22 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:22 --> Input Class Initialized
INFO - 2024-08-14 00:05:22 --> Language Class Initialized
INFO - 2024-08-14 00:05:22 --> Loader Class Initialized
INFO - 2024-08-14 00:05:22 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:22 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:22 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:22 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:22 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:22 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:22 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:22 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:22 --> Controller Class Initialized
INFO - 2024-08-14 00:05:22 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:22 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:22 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:22 --> Total execution time: 0.1161
INFO - 2024-08-14 00:05:35 --> Config Class Initialized
INFO - 2024-08-14 00:05:35 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:35 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:35 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:35 --> URI Class Initialized
INFO - 2024-08-14 00:05:35 --> Router Class Initialized
INFO - 2024-08-14 00:05:35 --> Output Class Initialized
INFO - 2024-08-14 00:05:35 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:35 --> Input Class Initialized
INFO - 2024-08-14 00:05:35 --> Language Class Initialized
INFO - 2024-08-14 00:05:35 --> Loader Class Initialized
INFO - 2024-08-14 00:05:35 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:35 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:35 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:35 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:35 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:35 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:35 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:35 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:35 --> Controller Class Initialized
INFO - 2024-08-14 00:05:35 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:35 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:35 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:35 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:35 --> Total execution time: 0.1136
INFO - 2024-08-14 00:05:43 --> Config Class Initialized
INFO - 2024-08-14 00:05:43 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:43 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:43 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:43 --> URI Class Initialized
INFO - 2024-08-14 00:05:43 --> Router Class Initialized
INFO - 2024-08-14 00:05:43 --> Output Class Initialized
INFO - 2024-08-14 00:05:43 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:43 --> Input Class Initialized
INFO - 2024-08-14 00:05:43 --> Language Class Initialized
INFO - 2024-08-14 00:05:43 --> Loader Class Initialized
INFO - 2024-08-14 00:05:43 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:43 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:43 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:43 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:43 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:43 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:43 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:43 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:43 --> Controller Class Initialized
INFO - 2024-08-14 00:05:43 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:43 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:43 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:43 --> Total execution time: 0.1027
INFO - 2024-08-14 00:05:48 --> Config Class Initialized
INFO - 2024-08-14 00:05:48 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:48 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:48 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:48 --> URI Class Initialized
INFO - 2024-08-14 00:05:48 --> Router Class Initialized
INFO - 2024-08-14 00:05:48 --> Output Class Initialized
INFO - 2024-08-14 00:05:48 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:48 --> Input Class Initialized
INFO - 2024-08-14 00:05:48 --> Language Class Initialized
INFO - 2024-08-14 00:05:48 --> Loader Class Initialized
INFO - 2024-08-14 00:05:48 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:48 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:48 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:48 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:48 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:48 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:48 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:48 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:48 --> Controller Class Initialized
INFO - 2024-08-14 00:05:48 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:48 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:48 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:48 --> Total execution time: 0.0950
INFO - 2024-08-14 00:05:52 --> Config Class Initialized
INFO - 2024-08-14 00:05:52 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:05:52 --> Utf8 Class Initialized
INFO - 2024-08-14 00:05:52 --> URI Class Initialized
INFO - 2024-08-14 00:05:52 --> Router Class Initialized
INFO - 2024-08-14 00:05:52 --> Output Class Initialized
INFO - 2024-08-14 00:05:52 --> Security Class Initialized
DEBUG - 2024-08-14 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:05:52 --> Input Class Initialized
INFO - 2024-08-14 00:05:52 --> Language Class Initialized
INFO - 2024-08-14 00:05:52 --> Loader Class Initialized
INFO - 2024-08-14 00:05:52 --> Helper loaded: url_helper
INFO - 2024-08-14 00:05:52 --> Helper loaded: file_helper
INFO - 2024-08-14 00:05:52 --> Helper loaded: security_helper
INFO - 2024-08-14 00:05:52 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:05:52 --> Database Driver Class Initialized
INFO - 2024-08-14 00:05:52 --> Email Class Initialized
DEBUG - 2024-08-14 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:05:52 --> Helper loaded: form_helper
INFO - 2024-08-14 00:05:52 --> Form Validation Class Initialized
INFO - 2024-08-14 00:05:52 --> Controller Class Initialized
INFO - 2024-08-14 00:05:52 --> Model "User_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:05:52 --> Final output sent to browser
DEBUG - 2024-08-14 00:05:52 --> Total execution time: 0.1019
INFO - 2024-08-14 00:06:01 --> Config Class Initialized
INFO - 2024-08-14 00:06:01 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:06:01 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:06:01 --> Utf8 Class Initialized
INFO - 2024-08-14 00:06:01 --> URI Class Initialized
INFO - 2024-08-14 00:06:01 --> Router Class Initialized
INFO - 2024-08-14 00:06:01 --> Output Class Initialized
INFO - 2024-08-14 00:06:01 --> Security Class Initialized
DEBUG - 2024-08-14 00:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:06:01 --> Input Class Initialized
INFO - 2024-08-14 00:06:01 --> Language Class Initialized
INFO - 2024-08-14 00:06:01 --> Loader Class Initialized
INFO - 2024-08-14 00:06:01 --> Helper loaded: url_helper
INFO - 2024-08-14 00:06:01 --> Helper loaded: file_helper
INFO - 2024-08-14 00:06:01 --> Helper loaded: security_helper
INFO - 2024-08-14 00:06:01 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:06:01 --> Database Driver Class Initialized
INFO - 2024-08-14 00:06:01 --> Email Class Initialized
DEBUG - 2024-08-14 00:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:06:01 --> Helper loaded: form_helper
INFO - 2024-08-14 00:06:01 --> Form Validation Class Initialized
INFO - 2024-08-14 00:06:01 --> Controller Class Initialized
INFO - 2024-08-14 00:06:01 --> Model "User_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:06:01 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:06:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:06:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:06:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:06:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:06:01 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:06:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:06:01 --> Final output sent to browser
DEBUG - 2024-08-14 00:06:01 --> Total execution time: 0.0708
INFO - 2024-08-14 00:06:05 --> Config Class Initialized
INFO - 2024-08-14 00:06:05 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:06:05 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:06:05 --> Utf8 Class Initialized
INFO - 2024-08-14 00:06:05 --> URI Class Initialized
INFO - 2024-08-14 00:06:05 --> Router Class Initialized
INFO - 2024-08-14 00:06:05 --> Output Class Initialized
INFO - 2024-08-14 00:06:05 --> Security Class Initialized
DEBUG - 2024-08-14 00:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:06:05 --> Input Class Initialized
INFO - 2024-08-14 00:06:05 --> Language Class Initialized
INFO - 2024-08-14 00:06:05 --> Loader Class Initialized
INFO - 2024-08-14 00:06:05 --> Helper loaded: url_helper
INFO - 2024-08-14 00:06:05 --> Helper loaded: file_helper
INFO - 2024-08-14 00:06:05 --> Helper loaded: security_helper
INFO - 2024-08-14 00:06:05 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:06:05 --> Database Driver Class Initialized
INFO - 2024-08-14 00:06:05 --> Email Class Initialized
DEBUG - 2024-08-14 00:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:06:05 --> Helper loaded: form_helper
INFO - 2024-08-14 00:06:05 --> Form Validation Class Initialized
INFO - 2024-08-14 00:06:05 --> Controller Class Initialized
INFO - 2024-08-14 00:06:05 --> Model "User_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:06:05 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:06:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:06:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:06:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:06:05 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:06:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:06:05 --> Final output sent to browser
DEBUG - 2024-08-14 00:06:05 --> Total execution time: 0.0547
INFO - 2024-08-14 00:06:11 --> Config Class Initialized
INFO - 2024-08-14 00:06:11 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:06:11 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:06:11 --> Utf8 Class Initialized
INFO - 2024-08-14 00:06:11 --> URI Class Initialized
INFO - 2024-08-14 00:06:11 --> Router Class Initialized
INFO - 2024-08-14 00:06:11 --> Output Class Initialized
INFO - 2024-08-14 00:06:11 --> Security Class Initialized
DEBUG - 2024-08-14 00:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:06:11 --> Input Class Initialized
INFO - 2024-08-14 00:06:11 --> Language Class Initialized
INFO - 2024-08-14 00:06:11 --> Loader Class Initialized
INFO - 2024-08-14 00:06:11 --> Helper loaded: url_helper
INFO - 2024-08-14 00:06:11 --> Helper loaded: file_helper
INFO - 2024-08-14 00:06:11 --> Helper loaded: security_helper
INFO - 2024-08-14 00:06:11 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:06:11 --> Database Driver Class Initialized
INFO - 2024-08-14 00:06:11 --> Email Class Initialized
DEBUG - 2024-08-14 00:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:06:11 --> Helper loaded: form_helper
INFO - 2024-08-14 00:06:11 --> Form Validation Class Initialized
INFO - 2024-08-14 00:06:11 --> Controller Class Initialized
INFO - 2024-08-14 00:06:11 --> Model "User_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:06:11 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:06:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:06:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:06:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:06:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:06:11 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:06:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:06:11 --> Final output sent to browser
DEBUG - 2024-08-14 00:06:11 --> Total execution time: 0.0973
INFO - 2024-08-14 00:07:01 --> Config Class Initialized
INFO - 2024-08-14 00:07:01 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:07:01 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:07:01 --> Utf8 Class Initialized
INFO - 2024-08-14 00:07:01 --> URI Class Initialized
INFO - 2024-08-14 00:07:01 --> Router Class Initialized
INFO - 2024-08-14 00:07:01 --> Output Class Initialized
INFO - 2024-08-14 00:07:01 --> Security Class Initialized
DEBUG - 2024-08-14 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:07:01 --> Input Class Initialized
INFO - 2024-08-14 00:07:01 --> Language Class Initialized
INFO - 2024-08-14 00:07:01 --> Loader Class Initialized
INFO - 2024-08-14 00:07:01 --> Helper loaded: url_helper
INFO - 2024-08-14 00:07:01 --> Helper loaded: file_helper
INFO - 2024-08-14 00:07:01 --> Helper loaded: security_helper
INFO - 2024-08-14 00:07:01 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:07:01 --> Database Driver Class Initialized
INFO - 2024-08-14 00:07:01 --> Email Class Initialized
DEBUG - 2024-08-14 00:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:07:01 --> Helper loaded: form_helper
INFO - 2024-08-14 00:07:01 --> Form Validation Class Initialized
INFO - 2024-08-14 00:07:01 --> Controller Class Initialized
INFO - 2024-08-14 00:07:01 --> Model "User_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:07:01 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:07:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:07:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:07:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:07:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:07:01 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:07:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:07:01 --> Final output sent to browser
DEBUG - 2024-08-14 00:07:01 --> Total execution time: 0.1213
INFO - 2024-08-14 00:07:07 --> Config Class Initialized
INFO - 2024-08-14 00:07:07 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:07:07 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:07:07 --> Utf8 Class Initialized
INFO - 2024-08-14 00:07:07 --> URI Class Initialized
INFO - 2024-08-14 00:07:07 --> Router Class Initialized
INFO - 2024-08-14 00:07:07 --> Output Class Initialized
INFO - 2024-08-14 00:07:07 --> Security Class Initialized
DEBUG - 2024-08-14 00:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:07:07 --> Input Class Initialized
INFO - 2024-08-14 00:07:07 --> Language Class Initialized
INFO - 2024-08-14 00:07:07 --> Loader Class Initialized
INFO - 2024-08-14 00:07:07 --> Helper loaded: url_helper
INFO - 2024-08-14 00:07:07 --> Helper loaded: file_helper
INFO - 2024-08-14 00:07:07 --> Helper loaded: security_helper
INFO - 2024-08-14 00:07:07 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:07:07 --> Database Driver Class Initialized
INFO - 2024-08-14 00:07:07 --> Email Class Initialized
DEBUG - 2024-08-14 00:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:07:07 --> Helper loaded: form_helper
INFO - 2024-08-14 00:07:07 --> Form Validation Class Initialized
INFO - 2024-08-14 00:07:07 --> Controller Class Initialized
INFO - 2024-08-14 00:07:07 --> Model "User_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:07:07 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:07:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:07:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:07:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:07:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:07:07 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 00:07:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:07:07 --> Final output sent to browser
DEBUG - 2024-08-14 00:07:07 --> Total execution time: 0.0558
INFO - 2024-08-14 00:18:00 --> Config Class Initialized
INFO - 2024-08-14 00:18:00 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:18:00 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:18:00 --> Utf8 Class Initialized
INFO - 2024-08-14 00:18:00 --> URI Class Initialized
INFO - 2024-08-14 00:18:00 --> Router Class Initialized
INFO - 2024-08-14 00:18:00 --> Output Class Initialized
INFO - 2024-08-14 00:18:00 --> Security Class Initialized
DEBUG - 2024-08-14 00:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:18:00 --> Input Class Initialized
INFO - 2024-08-14 00:18:00 --> Language Class Initialized
INFO - 2024-08-14 00:18:00 --> Loader Class Initialized
INFO - 2024-08-14 00:18:00 --> Helper loaded: url_helper
INFO - 2024-08-14 00:18:00 --> Helper loaded: file_helper
INFO - 2024-08-14 00:18:00 --> Helper loaded: security_helper
INFO - 2024-08-14 00:18:00 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:18:00 --> Database Driver Class Initialized
INFO - 2024-08-14 00:18:00 --> Email Class Initialized
DEBUG - 2024-08-14 00:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:18:00 --> Helper loaded: form_helper
INFO - 2024-08-14 00:18:00 --> Form Validation Class Initialized
INFO - 2024-08-14 00:18:00 --> Controller Class Initialized
INFO - 2024-08-14 00:18:00 --> Model "User_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:18:00 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:18:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-14 00:18:00 --> Severity: error --> Exception: Call to undefined method Pesanan_model::getInventaris() C:\xampp\htdocs\simba\application\controllers\Report.php 1046
INFO - 2024-08-14 00:22:05 --> Config Class Initialized
INFO - 2024-08-14 00:22:05 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:22:05 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:22:05 --> Utf8 Class Initialized
INFO - 2024-08-14 00:22:05 --> URI Class Initialized
INFO - 2024-08-14 00:22:05 --> Router Class Initialized
INFO - 2024-08-14 00:22:05 --> Output Class Initialized
INFO - 2024-08-14 00:22:05 --> Security Class Initialized
DEBUG - 2024-08-14 00:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:22:05 --> Input Class Initialized
INFO - 2024-08-14 00:22:05 --> Language Class Initialized
INFO - 2024-08-14 00:22:06 --> Loader Class Initialized
INFO - 2024-08-14 00:22:06 --> Helper loaded: url_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: file_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: security_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:22:06 --> Database Driver Class Initialized
INFO - 2024-08-14 00:22:06 --> Email Class Initialized
DEBUG - 2024-08-14 00:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:22:06 --> Helper loaded: form_helper
INFO - 2024-08-14 00:22:06 --> Form Validation Class Initialized
INFO - 2024-08-14 00:22:06 --> Controller Class Initialized
INFO - 2024-08-14 00:22:06 --> Model "User_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:22:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-14 00:22:06 --> Severity: error --> Exception: Call to a member function getInventaris() on null C:\xampp\htdocs\simba\application\controllers\Report.php 1046
INFO - 2024-08-14 00:22:06 --> Config Class Initialized
INFO - 2024-08-14 00:22:06 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:22:06 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:22:06 --> Utf8 Class Initialized
INFO - 2024-08-14 00:22:06 --> URI Class Initialized
INFO - 2024-08-14 00:22:06 --> Router Class Initialized
INFO - 2024-08-14 00:22:06 --> Output Class Initialized
INFO - 2024-08-14 00:22:06 --> Security Class Initialized
DEBUG - 2024-08-14 00:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:22:06 --> Input Class Initialized
INFO - 2024-08-14 00:22:06 --> Language Class Initialized
INFO - 2024-08-14 00:22:06 --> Loader Class Initialized
INFO - 2024-08-14 00:22:06 --> Helper loaded: url_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: file_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: security_helper
INFO - 2024-08-14 00:22:06 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:22:06 --> Database Driver Class Initialized
INFO - 2024-08-14 00:22:06 --> Email Class Initialized
DEBUG - 2024-08-14 00:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:22:06 --> Helper loaded: form_helper
INFO - 2024-08-14 00:22:06 --> Form Validation Class Initialized
INFO - 2024-08-14 00:22:06 --> Controller Class Initialized
INFO - 2024-08-14 00:22:06 --> Model "User_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:22:06 --> Model "Jenis_model" initialized
DEBUG - 2024-08-14 00:22:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-14 00:22:06 --> Severity: error --> Exception: Call to a member function getInventaris() on null C:\xampp\htdocs\simba\application\controllers\Report.php 1046
INFO - 2024-08-14 00:23:17 --> Config Class Initialized
INFO - 2024-08-14 00:23:17 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:23:17 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:23:17 --> Utf8 Class Initialized
INFO - 2024-08-14 00:23:17 --> URI Class Initialized
INFO - 2024-08-14 00:23:17 --> Router Class Initialized
INFO - 2024-08-14 00:23:17 --> Output Class Initialized
INFO - 2024-08-14 00:23:17 --> Security Class Initialized
DEBUG - 2024-08-14 00:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:23:17 --> Input Class Initialized
INFO - 2024-08-14 00:23:17 --> Language Class Initialized
INFO - 2024-08-14 00:23:17 --> Loader Class Initialized
INFO - 2024-08-14 00:23:17 --> Helper loaded: url_helper
INFO - 2024-08-14 00:23:17 --> Helper loaded: file_helper
INFO - 2024-08-14 00:23:17 --> Helper loaded: security_helper
INFO - 2024-08-14 00:23:17 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:23:17 --> Database Driver Class Initialized
INFO - 2024-08-14 00:23:17 --> Email Class Initialized
DEBUG - 2024-08-14 00:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:23:17 --> Helper loaded: form_helper
INFO - 2024-08-14 00:23:17 --> Form Validation Class Initialized
INFO - 2024-08-14 00:23:17 --> Controller Class Initialized
INFO - 2024-08-14 00:23:17 --> Model "User_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Jenis_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Barang_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 00:23:17 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 00:23:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:23:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:23:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:23:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:23:17 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 00:23:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:23:17 --> Final output sent to browser
DEBUG - 2024-08-14 00:23:17 --> Total execution time: 0.1580
INFO - 2024-08-14 00:23:29 --> Config Class Initialized
INFO - 2024-08-14 00:23:29 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:23:29 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:23:29 --> Utf8 Class Initialized
INFO - 2024-08-14 00:23:29 --> URI Class Initialized
INFO - 2024-08-14 00:23:29 --> Router Class Initialized
INFO - 2024-08-14 00:23:29 --> Output Class Initialized
INFO - 2024-08-14 00:23:29 --> Security Class Initialized
DEBUG - 2024-08-14 00:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:23:29 --> Input Class Initialized
INFO - 2024-08-14 00:23:29 --> Language Class Initialized
INFO - 2024-08-14 00:23:29 --> Loader Class Initialized
INFO - 2024-08-14 00:23:29 --> Helper loaded: url_helper
INFO - 2024-08-14 00:23:29 --> Helper loaded: file_helper
INFO - 2024-08-14 00:23:29 --> Helper loaded: security_helper
INFO - 2024-08-14 00:23:29 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:23:29 --> Database Driver Class Initialized
INFO - 2024-08-14 00:23:29 --> Email Class Initialized
DEBUG - 2024-08-14 00:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:23:29 --> Helper loaded: form_helper
INFO - 2024-08-14 00:23:29 --> Form Validation Class Initialized
INFO - 2024-08-14 00:23:29 --> Controller Class Initialized
INFO - 2024-08-14 00:23:29 --> Model "User_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Jenis_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Barang_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 00:23:29 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 00:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:23:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:23:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:23:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:23:29 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 00:23:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:23:29 --> Final output sent to browser
DEBUG - 2024-08-14 00:23:29 --> Total execution time: 0.0661
INFO - 2024-08-14 00:47:06 --> Config Class Initialized
INFO - 2024-08-14 00:47:06 --> Hooks Class Initialized
DEBUG - 2024-08-14 00:47:06 --> UTF-8 Support Enabled
INFO - 2024-08-14 00:47:06 --> Utf8 Class Initialized
INFO - 2024-08-14 00:47:06 --> URI Class Initialized
INFO - 2024-08-14 00:47:06 --> Router Class Initialized
INFO - 2024-08-14 00:47:06 --> Output Class Initialized
INFO - 2024-08-14 00:47:06 --> Security Class Initialized
DEBUG - 2024-08-14 00:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 00:47:06 --> Input Class Initialized
INFO - 2024-08-14 00:47:06 --> Language Class Initialized
INFO - 2024-08-14 00:47:06 --> Loader Class Initialized
INFO - 2024-08-14 00:47:06 --> Helper loaded: url_helper
INFO - 2024-08-14 00:47:06 --> Helper loaded: file_helper
INFO - 2024-08-14 00:47:06 --> Helper loaded: security_helper
INFO - 2024-08-14 00:47:06 --> Helper loaded: wpu_helper
INFO - 2024-08-14 00:47:06 --> Database Driver Class Initialized
INFO - 2024-08-14 00:47:06 --> Email Class Initialized
DEBUG - 2024-08-14 00:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 00:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 00:47:06 --> Helper loaded: form_helper
INFO - 2024-08-14 00:47:06 --> Form Validation Class Initialized
INFO - 2024-08-14 00:47:06 --> Controller Class Initialized
INFO - 2024-08-14 00:47:06 --> Model "User_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Faktur_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Supplier_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Jenis_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Barang_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 00:47:06 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 00:47:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 00:47:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 00:47:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 00:47:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 00:47:06 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 00:47:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 00:47:06 --> Final output sent to browser
DEBUG - 2024-08-14 00:47:06 --> Total execution time: 0.0746
INFO - 2024-08-14 16:12:02 --> Config Class Initialized
INFO - 2024-08-14 16:12:02 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:12:02 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:12:02 --> Utf8 Class Initialized
INFO - 2024-08-14 16:12:02 --> URI Class Initialized
DEBUG - 2024-08-14 16:12:02 --> No URI present. Default controller set.
INFO - 2024-08-14 16:12:02 --> Router Class Initialized
INFO - 2024-08-14 16:12:03 --> Output Class Initialized
INFO - 2024-08-14 16:12:03 --> Security Class Initialized
DEBUG - 2024-08-14 16:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:12:03 --> Input Class Initialized
INFO - 2024-08-14 16:12:03 --> Language Class Initialized
INFO - 2024-08-14 16:12:03 --> Loader Class Initialized
INFO - 2024-08-14 16:12:03 --> Helper loaded: url_helper
INFO - 2024-08-14 16:12:03 --> Helper loaded: file_helper
INFO - 2024-08-14 16:12:03 --> Helper loaded: security_helper
INFO - 2024-08-14 16:12:03 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:12:03 --> Database Driver Class Initialized
INFO - 2024-08-14 16:12:03 --> Email Class Initialized
DEBUG - 2024-08-14 16:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:12:03 --> Helper loaded: form_helper
INFO - 2024-08-14 16:12:03 --> Form Validation Class Initialized
INFO - 2024-08-14 16:12:03 --> Controller Class Initialized
DEBUG - 2024-08-14 16:12:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:12:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-14 16:12:03 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-14 16:12:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-14 16:12:03 --> Final output sent to browser
DEBUG - 2024-08-14 16:12:03 --> Total execution time: 0.6837
INFO - 2024-08-14 16:41:24 --> Config Class Initialized
INFO - 2024-08-14 16:41:24 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:41:24 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:41:24 --> Utf8 Class Initialized
INFO - 2024-08-14 16:41:24 --> URI Class Initialized
INFO - 2024-08-14 16:41:24 --> Router Class Initialized
INFO - 2024-08-14 16:41:24 --> Output Class Initialized
INFO - 2024-08-14 16:41:24 --> Security Class Initialized
DEBUG - 2024-08-14 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:41:24 --> Input Class Initialized
INFO - 2024-08-14 16:41:24 --> Language Class Initialized
INFO - 2024-08-14 16:41:24 --> Loader Class Initialized
INFO - 2024-08-14 16:41:24 --> Helper loaded: url_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: file_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: security_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:41:24 --> Database Driver Class Initialized
INFO - 2024-08-14 16:41:24 --> Email Class Initialized
DEBUG - 2024-08-14 16:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:41:24 --> Helper loaded: form_helper
INFO - 2024-08-14 16:41:24 --> Form Validation Class Initialized
INFO - 2024-08-14 16:41:24 --> Controller Class Initialized
DEBUG - 2024-08-14 16:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:41:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-14 16:41:24 --> Config Class Initialized
INFO - 2024-08-14 16:41:24 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:41:24 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:41:24 --> Utf8 Class Initialized
INFO - 2024-08-14 16:41:24 --> URI Class Initialized
INFO - 2024-08-14 16:41:24 --> Router Class Initialized
INFO - 2024-08-14 16:41:24 --> Output Class Initialized
INFO - 2024-08-14 16:41:24 --> Security Class Initialized
DEBUG - 2024-08-14 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:41:24 --> Input Class Initialized
INFO - 2024-08-14 16:41:24 --> Language Class Initialized
INFO - 2024-08-14 16:41:24 --> Loader Class Initialized
INFO - 2024-08-14 16:41:24 --> Helper loaded: url_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: file_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: security_helper
INFO - 2024-08-14 16:41:24 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:41:24 --> Database Driver Class Initialized
INFO - 2024-08-14 16:41:24 --> Email Class Initialized
DEBUG - 2024-08-14 16:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:41:24 --> Helper loaded: form_helper
INFO - 2024-08-14 16:41:24 --> Form Validation Class Initialized
INFO - 2024-08-14 16:41:24 --> Controller Class Initialized
INFO - 2024-08-14 16:41:24 --> Model "User_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:41:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:41:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:41:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:41:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:41:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-14 16:41:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:41:25 --> Final output sent to browser
DEBUG - 2024-08-14 16:41:25 --> Total execution time: 0.7830
INFO - 2024-08-14 16:41:26 --> Config Class Initialized
INFO - 2024-08-14 16:41:26 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:41:26 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:41:26 --> Utf8 Class Initialized
INFO - 2024-08-14 16:41:26 --> URI Class Initialized
INFO - 2024-08-14 16:41:26 --> Router Class Initialized
INFO - 2024-08-14 16:41:26 --> Output Class Initialized
INFO - 2024-08-14 16:41:26 --> Security Class Initialized
DEBUG - 2024-08-14 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:41:26 --> Input Class Initialized
INFO - 2024-08-14 16:41:26 --> Language Class Initialized
INFO - 2024-08-14 16:41:26 --> Loader Class Initialized
INFO - 2024-08-14 16:41:26 --> Helper loaded: url_helper
INFO - 2024-08-14 16:41:26 --> Helper loaded: file_helper
INFO - 2024-08-14 16:41:26 --> Helper loaded: security_helper
INFO - 2024-08-14 16:41:26 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:41:26 --> Database Driver Class Initialized
INFO - 2024-08-14 16:41:26 --> Email Class Initialized
DEBUG - 2024-08-14 16:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:41:26 --> Helper loaded: form_helper
INFO - 2024-08-14 16:41:26 --> Form Validation Class Initialized
INFO - 2024-08-14 16:41:26 --> Controller Class Initialized
INFO - 2024-08-14 16:41:26 --> Model "User_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:41:26 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:41:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:41:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:41:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:41:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:41:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-14 16:41:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:41:26 --> Final output sent to browser
DEBUG - 2024-08-14 16:41:26 --> Total execution time: 0.2025
INFO - 2024-08-14 16:41:59 --> Config Class Initialized
INFO - 2024-08-14 16:41:59 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:41:59 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:41:59 --> Utf8 Class Initialized
INFO - 2024-08-14 16:41:59 --> URI Class Initialized
INFO - 2024-08-14 16:41:59 --> Router Class Initialized
INFO - 2024-08-14 16:41:59 --> Output Class Initialized
INFO - 2024-08-14 16:41:59 --> Security Class Initialized
DEBUG - 2024-08-14 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:41:59 --> Input Class Initialized
INFO - 2024-08-14 16:41:59 --> Language Class Initialized
INFO - 2024-08-14 16:41:59 --> Loader Class Initialized
INFO - 2024-08-14 16:41:59 --> Helper loaded: url_helper
INFO - 2024-08-14 16:41:59 --> Helper loaded: file_helper
INFO - 2024-08-14 16:41:59 --> Helper loaded: security_helper
INFO - 2024-08-14 16:41:59 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:41:59 --> Database Driver Class Initialized
INFO - 2024-08-14 16:41:59 --> Email Class Initialized
DEBUG - 2024-08-14 16:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:41:59 --> Helper loaded: form_helper
INFO - 2024-08-14 16:41:59 --> Form Validation Class Initialized
INFO - 2024-08-14 16:41:59 --> Controller Class Initialized
INFO - 2024-08-14 16:41:59 --> Model "User_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:41:59 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:41:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:41:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:41:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:41:59 --> File loaded: C:\xampp\htdocs\simba\application\views\report/reportinventaris.php
INFO - 2024-08-14 16:41:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:41:59 --> Final output sent to browser
DEBUG - 2024-08-14 16:41:59 --> Total execution time: 0.0958
INFO - 2024-08-14 16:42:21 --> Config Class Initialized
INFO - 2024-08-14 16:42:21 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:42:21 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:42:21 --> Utf8 Class Initialized
INFO - 2024-08-14 16:42:21 --> URI Class Initialized
INFO - 2024-08-14 16:42:21 --> Router Class Initialized
INFO - 2024-08-14 16:42:21 --> Output Class Initialized
INFO - 2024-08-14 16:42:21 --> Security Class Initialized
DEBUG - 2024-08-14 16:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:42:21 --> Input Class Initialized
INFO - 2024-08-14 16:42:21 --> Language Class Initialized
INFO - 2024-08-14 16:42:21 --> Loader Class Initialized
INFO - 2024-08-14 16:42:21 --> Helper loaded: url_helper
INFO - 2024-08-14 16:42:21 --> Helper loaded: file_helper
INFO - 2024-08-14 16:42:21 --> Helper loaded: security_helper
INFO - 2024-08-14 16:42:21 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:42:21 --> Database Driver Class Initialized
INFO - 2024-08-14 16:42:21 --> Email Class Initialized
DEBUG - 2024-08-14 16:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:42:21 --> Helper loaded: form_helper
INFO - 2024-08-14 16:42:21 --> Form Validation Class Initialized
INFO - 2024-08-14 16:42:21 --> Controller Class Initialized
INFO - 2024-08-14 16:42:21 --> Model "User_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:42:21 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:42:22 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:42:22 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:42:22 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:42:22 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:42:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:42:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:42:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:42:22 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 16:42:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:42:22 --> Final output sent to browser
DEBUG - 2024-08-14 16:42:22 --> Total execution time: 0.1208
INFO - 2024-08-14 16:53:26 --> Config Class Initialized
INFO - 2024-08-14 16:53:26 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:53:26 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:53:26 --> Utf8 Class Initialized
INFO - 2024-08-14 16:53:26 --> URI Class Initialized
INFO - 2024-08-14 16:53:26 --> Router Class Initialized
INFO - 2024-08-14 16:53:26 --> Output Class Initialized
INFO - 2024-08-14 16:53:26 --> Security Class Initialized
DEBUG - 2024-08-14 16:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:53:26 --> Input Class Initialized
INFO - 2024-08-14 16:53:26 --> Language Class Initialized
INFO - 2024-08-14 16:53:26 --> Loader Class Initialized
INFO - 2024-08-14 16:53:26 --> Helper loaded: url_helper
INFO - 2024-08-14 16:53:26 --> Helper loaded: file_helper
INFO - 2024-08-14 16:53:26 --> Helper loaded: security_helper
INFO - 2024-08-14 16:53:26 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:53:26 --> Database Driver Class Initialized
INFO - 2024-08-14 16:53:26 --> Email Class Initialized
DEBUG - 2024-08-14 16:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:53:26 --> Helper loaded: form_helper
INFO - 2024-08-14 16:53:26 --> Form Validation Class Initialized
INFO - 2024-08-14 16:53:26 --> Controller Class Initialized
INFO - 2024-08-14 16:53:26 --> Model "User_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:53:26 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:53:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-14 16:53:26 --> Severity: error --> Exception: Call to undefined method Inventaris_model::view_all() C:\xampp\htdocs\simba\application\controllers\Report.php 1065
INFO - 2024-08-14 16:53:45 --> Config Class Initialized
INFO - 2024-08-14 16:53:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:53:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:53:45 --> Utf8 Class Initialized
INFO - 2024-08-14 16:53:45 --> URI Class Initialized
INFO - 2024-08-14 16:53:45 --> Router Class Initialized
INFO - 2024-08-14 16:53:45 --> Output Class Initialized
INFO - 2024-08-14 16:53:45 --> Security Class Initialized
DEBUG - 2024-08-14 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:53:45 --> Input Class Initialized
INFO - 2024-08-14 16:53:45 --> Language Class Initialized
INFO - 2024-08-14 16:53:45 --> Loader Class Initialized
INFO - 2024-08-14 16:53:45 --> Helper loaded: url_helper
INFO - 2024-08-14 16:53:45 --> Helper loaded: file_helper
INFO - 2024-08-14 16:53:45 --> Helper loaded: security_helper
INFO - 2024-08-14 16:53:45 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:53:45 --> Database Driver Class Initialized
INFO - 2024-08-14 16:53:45 --> Email Class Initialized
DEBUG - 2024-08-14 16:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:53:45 --> Helper loaded: form_helper
INFO - 2024-08-14 16:53:45 --> Form Validation Class Initialized
INFO - 2024-08-14 16:53:45 --> Controller Class Initialized
INFO - 2024-08-14 16:53:45 --> Model "User_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:53:45 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:53:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:53:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:53:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:53:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:53:45 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 16:53:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:53:45 --> Final output sent to browser
DEBUG - 2024-08-14 16:53:45 --> Total execution time: 0.1172
INFO - 2024-08-14 16:53:48 --> Config Class Initialized
INFO - 2024-08-14 16:53:48 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:53:48 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:53:48 --> Utf8 Class Initialized
INFO - 2024-08-14 16:53:48 --> URI Class Initialized
INFO - 2024-08-14 16:53:48 --> Router Class Initialized
INFO - 2024-08-14 16:53:48 --> Output Class Initialized
INFO - 2024-08-14 16:53:48 --> Security Class Initialized
DEBUG - 2024-08-14 16:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:53:48 --> Input Class Initialized
INFO - 2024-08-14 16:53:48 --> Language Class Initialized
INFO - 2024-08-14 16:53:48 --> Loader Class Initialized
INFO - 2024-08-14 16:53:48 --> Helper loaded: url_helper
INFO - 2024-08-14 16:53:48 --> Helper loaded: file_helper
INFO - 2024-08-14 16:53:48 --> Helper loaded: security_helper
INFO - 2024-08-14 16:53:48 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:53:48 --> Database Driver Class Initialized
INFO - 2024-08-14 16:53:48 --> Email Class Initialized
DEBUG - 2024-08-14 16:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:53:48 --> Helper loaded: form_helper
INFO - 2024-08-14 16:53:48 --> Form Validation Class Initialized
INFO - 2024-08-14 16:53:48 --> Controller Class Initialized
INFO - 2024-08-14 16:53:48 --> Model "User_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:53:48 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:53:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-14 16:53:48 --> Query error: Unknown column 'tanggal_faktur' in 'where clause' - Invalid query: SELECT `inventaris`.*, `inventaris_barang`.*, `inventaris_ruang`.*
FROM `inventaris`
JOIN `inventaris_barang` ON `inventaris`.`id_barang` = `inventaris_barang`.`id_barang`
JOIN `inventaris_ruang` ON `inventaris`.`id_ruang` = `inventaris_ruang`.`id_ruang`
WHERE YEAR(tanggal_faktur) = '2024'
INFO - 2024-08-14 16:53:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-08-14 16:54:39 --> Config Class Initialized
INFO - 2024-08-14 16:54:39 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:54:39 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:54:39 --> Utf8 Class Initialized
INFO - 2024-08-14 16:54:39 --> URI Class Initialized
INFO - 2024-08-14 16:54:39 --> Router Class Initialized
INFO - 2024-08-14 16:54:39 --> Output Class Initialized
INFO - 2024-08-14 16:54:39 --> Security Class Initialized
DEBUG - 2024-08-14 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:54:39 --> Input Class Initialized
INFO - 2024-08-14 16:54:39 --> Language Class Initialized
INFO - 2024-08-14 16:54:39 --> Loader Class Initialized
INFO - 2024-08-14 16:54:39 --> Helper loaded: url_helper
INFO - 2024-08-14 16:54:39 --> Helper loaded: file_helper
INFO - 2024-08-14 16:54:39 --> Helper loaded: security_helper
INFO - 2024-08-14 16:54:39 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:54:39 --> Database Driver Class Initialized
INFO - 2024-08-14 16:54:39 --> Email Class Initialized
DEBUG - 2024-08-14 16:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:54:39 --> Helper loaded: form_helper
INFO - 2024-08-14 16:54:39 --> Form Validation Class Initialized
INFO - 2024-08-14 16:54:39 --> Controller Class Initialized
INFO - 2024-08-14 16:54:39 --> Model "User_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:54:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:54:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:54:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:54:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:54:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:54:39 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 16:54:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:54:39 --> Final output sent to browser
DEBUG - 2024-08-14 16:54:39 --> Total execution time: 0.0960
INFO - 2024-08-14 16:54:42 --> Config Class Initialized
INFO - 2024-08-14 16:54:42 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:54:42 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:54:42 --> Utf8 Class Initialized
INFO - 2024-08-14 16:54:42 --> URI Class Initialized
INFO - 2024-08-14 16:54:42 --> Router Class Initialized
INFO - 2024-08-14 16:54:42 --> Output Class Initialized
INFO - 2024-08-14 16:54:42 --> Security Class Initialized
DEBUG - 2024-08-14 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:54:42 --> Input Class Initialized
INFO - 2024-08-14 16:54:42 --> Language Class Initialized
INFO - 2024-08-14 16:54:42 --> Loader Class Initialized
INFO - 2024-08-14 16:54:42 --> Helper loaded: url_helper
INFO - 2024-08-14 16:54:42 --> Helper loaded: file_helper
INFO - 2024-08-14 16:54:42 --> Helper loaded: security_helper
INFO - 2024-08-14 16:54:42 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:54:42 --> Database Driver Class Initialized
INFO - 2024-08-14 16:54:42 --> Email Class Initialized
DEBUG - 2024-08-14 16:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:54:42 --> Helper loaded: form_helper
INFO - 2024-08-14 16:54:42 --> Form Validation Class Initialized
INFO - 2024-08-14 16:54:42 --> Controller Class Initialized
INFO - 2024-08-14 16:54:42 --> Model "User_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:54:42 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:54:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 16:54:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 16:54:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 16:54:42 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 16:54:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 16:54:42 --> Final output sent to browser
DEBUG - 2024-08-14 16:54:42 --> Total execution time: 0.0791
INFO - 2024-08-14 16:54:43 --> Config Class Initialized
INFO - 2024-08-14 16:54:43 --> Hooks Class Initialized
DEBUG - 2024-08-14 16:54:43 --> UTF-8 Support Enabled
INFO - 2024-08-14 16:54:43 --> Utf8 Class Initialized
INFO - 2024-08-14 16:54:43 --> URI Class Initialized
INFO - 2024-08-14 16:54:43 --> Router Class Initialized
INFO - 2024-08-14 16:54:43 --> Output Class Initialized
INFO - 2024-08-14 16:54:43 --> Security Class Initialized
DEBUG - 2024-08-14 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 16:54:43 --> Input Class Initialized
INFO - 2024-08-14 16:54:43 --> Language Class Initialized
INFO - 2024-08-14 16:54:43 --> Loader Class Initialized
INFO - 2024-08-14 16:54:43 --> Helper loaded: url_helper
INFO - 2024-08-14 16:54:43 --> Helper loaded: file_helper
INFO - 2024-08-14 16:54:43 --> Helper loaded: security_helper
INFO - 2024-08-14 16:54:43 --> Helper loaded: wpu_helper
INFO - 2024-08-14 16:54:43 --> Database Driver Class Initialized
INFO - 2024-08-14 16:54:43 --> Email Class Initialized
DEBUG - 2024-08-14 16:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 16:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 16:54:43 --> Helper loaded: form_helper
INFO - 2024-08-14 16:54:43 --> Form Validation Class Initialized
INFO - 2024-08-14 16:54:43 --> Controller Class Initialized
INFO - 2024-08-14 16:54:43 --> Model "User_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Faktur_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Supplier_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Jenis_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Barang_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 16:54:43 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 16:54:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 16:54:44 --> Final output sent to browser
DEBUG - 2024-08-14 16:54:44 --> Total execution time: 1.4482
INFO - 2024-08-14 17:01:54 --> Config Class Initialized
INFO - 2024-08-14 17:01:54 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:01:54 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:01:54 --> Utf8 Class Initialized
INFO - 2024-08-14 17:01:54 --> URI Class Initialized
INFO - 2024-08-14 17:01:54 --> Router Class Initialized
INFO - 2024-08-14 17:01:54 --> Output Class Initialized
INFO - 2024-08-14 17:01:54 --> Security Class Initialized
DEBUG - 2024-08-14 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:01:54 --> Input Class Initialized
INFO - 2024-08-14 17:01:54 --> Language Class Initialized
INFO - 2024-08-14 17:01:54 --> Loader Class Initialized
INFO - 2024-08-14 17:01:54 --> Helper loaded: url_helper
INFO - 2024-08-14 17:01:54 --> Helper loaded: file_helper
INFO - 2024-08-14 17:01:54 --> Helper loaded: security_helper
INFO - 2024-08-14 17:01:54 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:01:54 --> Database Driver Class Initialized
INFO - 2024-08-14 17:01:54 --> Email Class Initialized
DEBUG - 2024-08-14 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:01:54 --> Helper loaded: form_helper
INFO - 2024-08-14 17:01:54 --> Form Validation Class Initialized
INFO - 2024-08-14 17:01:54 --> Controller Class Initialized
INFO - 2024-08-14 17:01:54 --> Model "User_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:01:54 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:01:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:01:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:01:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:01:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:01:54 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:01:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:01:54 --> Final output sent to browser
DEBUG - 2024-08-14 17:01:54 --> Total execution time: 0.0860
INFO - 2024-08-14 17:04:24 --> Config Class Initialized
INFO - 2024-08-14 17:04:24 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:04:24 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:04:24 --> Utf8 Class Initialized
INFO - 2024-08-14 17:04:24 --> URI Class Initialized
INFO - 2024-08-14 17:04:24 --> Router Class Initialized
INFO - 2024-08-14 17:04:24 --> Output Class Initialized
INFO - 2024-08-14 17:04:24 --> Security Class Initialized
DEBUG - 2024-08-14 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:04:24 --> Input Class Initialized
INFO - 2024-08-14 17:04:24 --> Language Class Initialized
INFO - 2024-08-14 17:04:24 --> Loader Class Initialized
INFO - 2024-08-14 17:04:24 --> Helper loaded: url_helper
INFO - 2024-08-14 17:04:24 --> Helper loaded: file_helper
INFO - 2024-08-14 17:04:24 --> Helper loaded: security_helper
INFO - 2024-08-14 17:04:24 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:04:24 --> Database Driver Class Initialized
INFO - 2024-08-14 17:04:24 --> Email Class Initialized
DEBUG - 2024-08-14 17:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:04:24 --> Helper loaded: form_helper
INFO - 2024-08-14 17:04:24 --> Form Validation Class Initialized
INFO - 2024-08-14 17:04:24 --> Controller Class Initialized
INFO - 2024-08-14 17:04:24 --> Model "User_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:04:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:04:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:04:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:04:24 --> Final output sent to browser
DEBUG - 2024-08-14 17:04:24 --> Total execution time: 0.0722
INFO - 2024-08-14 17:04:46 --> Config Class Initialized
INFO - 2024-08-14 17:04:46 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:04:46 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:04:46 --> Utf8 Class Initialized
INFO - 2024-08-14 17:04:46 --> URI Class Initialized
INFO - 2024-08-14 17:04:46 --> Router Class Initialized
INFO - 2024-08-14 17:04:46 --> Output Class Initialized
INFO - 2024-08-14 17:04:46 --> Security Class Initialized
DEBUG - 2024-08-14 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:04:46 --> Input Class Initialized
INFO - 2024-08-14 17:04:46 --> Language Class Initialized
INFO - 2024-08-14 17:04:46 --> Loader Class Initialized
INFO - 2024-08-14 17:04:46 --> Helper loaded: url_helper
INFO - 2024-08-14 17:04:46 --> Helper loaded: file_helper
INFO - 2024-08-14 17:04:46 --> Helper loaded: security_helper
INFO - 2024-08-14 17:04:46 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:04:46 --> Database Driver Class Initialized
INFO - 2024-08-14 17:04:46 --> Email Class Initialized
DEBUG - 2024-08-14 17:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:04:46 --> Helper loaded: form_helper
INFO - 2024-08-14 17:04:46 --> Form Validation Class Initialized
INFO - 2024-08-14 17:04:46 --> Controller Class Initialized
INFO - 2024-08-14 17:04:46 --> Model "User_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:04:46 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:04:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:04:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:04:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:04:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:04:46 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:04:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:04:46 --> Final output sent to browser
DEBUG - 2024-08-14 17:04:46 --> Total execution time: 0.1225
INFO - 2024-08-14 17:05:01 --> Config Class Initialized
INFO - 2024-08-14 17:05:01 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:01 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:01 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:01 --> URI Class Initialized
INFO - 2024-08-14 17:05:01 --> Router Class Initialized
INFO - 2024-08-14 17:05:01 --> Output Class Initialized
INFO - 2024-08-14 17:05:01 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:01 --> Input Class Initialized
INFO - 2024-08-14 17:05:01 --> Language Class Initialized
INFO - 2024-08-14 17:05:01 --> Loader Class Initialized
INFO - 2024-08-14 17:05:01 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:01 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:01 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:01 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:01 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:01 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:01 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:01 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:01 --> Controller Class Initialized
INFO - 2024-08-14 17:05:01 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:01 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:01 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:01 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:01 --> Total execution time: 0.0830
INFO - 2024-08-14 17:05:06 --> Config Class Initialized
INFO - 2024-08-14 17:05:06 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:06 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:06 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:06 --> URI Class Initialized
INFO - 2024-08-14 17:05:06 --> Router Class Initialized
INFO - 2024-08-14 17:05:06 --> Output Class Initialized
INFO - 2024-08-14 17:05:06 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:06 --> Input Class Initialized
INFO - 2024-08-14 17:05:06 --> Language Class Initialized
INFO - 2024-08-14 17:05:06 --> Loader Class Initialized
INFO - 2024-08-14 17:05:06 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:06 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:06 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:06 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:06 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:06 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:06 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:06 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:06 --> Controller Class Initialized
INFO - 2024-08-14 17:05:06 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:06 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:06 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:06 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:06 --> Total execution time: 0.0682
INFO - 2024-08-14 17:05:07 --> Config Class Initialized
INFO - 2024-08-14 17:05:07 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:07 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:07 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:07 --> URI Class Initialized
INFO - 2024-08-14 17:05:07 --> Router Class Initialized
INFO - 2024-08-14 17:05:07 --> Output Class Initialized
INFO - 2024-08-14 17:05:07 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:07 --> Input Class Initialized
INFO - 2024-08-14 17:05:07 --> Language Class Initialized
INFO - 2024-08-14 17:05:07 --> Loader Class Initialized
INFO - 2024-08-14 17:05:07 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:07 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:07 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:07 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:07 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:07 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:07 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:07 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:07 --> Controller Class Initialized
INFO - 2024-08-14 17:05:07 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:07 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:07 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 17:05:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:07 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:07 --> Total execution time: 0.1202
INFO - 2024-08-14 17:05:08 --> Config Class Initialized
INFO - 2024-08-14 17:05:08 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:08 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:08 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:08 --> URI Class Initialized
INFO - 2024-08-14 17:05:08 --> Router Class Initialized
INFO - 2024-08-14 17:05:08 --> Output Class Initialized
INFO - 2024-08-14 17:05:08 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:08 --> Input Class Initialized
INFO - 2024-08-14 17:05:08 --> Language Class Initialized
INFO - 2024-08-14 17:05:08 --> Loader Class Initialized
INFO - 2024-08-14 17:05:08 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:08 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:08 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:08 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:08 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:08 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:08 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:08 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:08 --> Controller Class Initialized
INFO - 2024-08-14 17:05:08 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:08 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 17:05:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:08 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:08 --> Total execution time: 0.0830
INFO - 2024-08-14 17:05:09 --> Config Class Initialized
INFO - 2024-08-14 17:05:09 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:09 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:09 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:09 --> URI Class Initialized
INFO - 2024-08-14 17:05:09 --> Router Class Initialized
INFO - 2024-08-14 17:05:09 --> Output Class Initialized
INFO - 2024-08-14 17:05:09 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:09 --> Input Class Initialized
INFO - 2024-08-14 17:05:09 --> Language Class Initialized
INFO - 2024-08-14 17:05:09 --> Loader Class Initialized
INFO - 2024-08-14 17:05:09 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:09 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:09 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:09 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:09 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:09 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:09 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:09 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:09 --> Controller Class Initialized
INFO - 2024-08-14 17:05:09 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:09 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:09 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 17:05:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:09 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:09 --> Total execution time: 0.0868
INFO - 2024-08-14 17:05:12 --> Config Class Initialized
INFO - 2024-08-14 17:05:12 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:12 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:12 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:12 --> URI Class Initialized
INFO - 2024-08-14 17:05:12 --> Router Class Initialized
INFO - 2024-08-14 17:05:12 --> Output Class Initialized
INFO - 2024-08-14 17:05:12 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:12 --> Input Class Initialized
INFO - 2024-08-14 17:05:12 --> Language Class Initialized
INFO - 2024-08-14 17:05:12 --> Loader Class Initialized
INFO - 2024-08-14 17:05:12 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:12 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:12 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:12 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:12 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:12 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:12 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:12 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:12 --> Controller Class Initialized
INFO - 2024-08-14 17:05:12 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:12 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:12 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-14 17:05:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:12 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:12 --> Total execution time: 0.0648
INFO - 2024-08-14 17:05:14 --> Config Class Initialized
INFO - 2024-08-14 17:05:14 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:14 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:14 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:14 --> URI Class Initialized
INFO - 2024-08-14 17:05:14 --> Router Class Initialized
INFO - 2024-08-14 17:05:14 --> Output Class Initialized
INFO - 2024-08-14 17:05:14 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:14 --> Input Class Initialized
INFO - 2024-08-14 17:05:14 --> Language Class Initialized
INFO - 2024-08-14 17:05:14 --> Loader Class Initialized
INFO - 2024-08-14 17:05:14 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:14 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:14 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:14 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:14 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:14 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:14 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:14 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:14 --> Controller Class Initialized
INFO - 2024-08-14 17:05:14 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:14 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:14 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:14 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:14 --> Total execution time: 0.0697
INFO - 2024-08-14 17:05:18 --> Config Class Initialized
INFO - 2024-08-14 17:05:18 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:18 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:18 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:18 --> URI Class Initialized
INFO - 2024-08-14 17:05:18 --> Router Class Initialized
INFO - 2024-08-14 17:05:18 --> Output Class Initialized
INFO - 2024-08-14 17:05:18 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:18 --> Input Class Initialized
INFO - 2024-08-14 17:05:18 --> Language Class Initialized
INFO - 2024-08-14 17:05:18 --> Loader Class Initialized
INFO - 2024-08-14 17:05:18 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:18 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:18 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:18 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:18 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:18 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:18 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:18 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:18 --> Controller Class Initialized
INFO - 2024-08-14 17:05:18 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:18 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:18 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:18 --> Total execution time: 0.0784
INFO - 2024-08-14 17:05:20 --> Config Class Initialized
INFO - 2024-08-14 17:05:20 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:20 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:20 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:20 --> URI Class Initialized
INFO - 2024-08-14 17:05:20 --> Router Class Initialized
INFO - 2024-08-14 17:05:20 --> Output Class Initialized
INFO - 2024-08-14 17:05:20 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:20 --> Input Class Initialized
INFO - 2024-08-14 17:05:20 --> Language Class Initialized
INFO - 2024-08-14 17:05:20 --> Loader Class Initialized
INFO - 2024-08-14 17:05:20 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:20 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:20 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:20 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:20 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:20 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:20 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:20 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:20 --> Controller Class Initialized
INFO - 2024-08-14 17:05:20 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:20 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:20 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:20 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:20 --> Total execution time: 0.0714
INFO - 2024-08-14 17:05:22 --> Config Class Initialized
INFO - 2024-08-14 17:05:22 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:22 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:22 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:22 --> URI Class Initialized
INFO - 2024-08-14 17:05:22 --> Router Class Initialized
INFO - 2024-08-14 17:05:22 --> Output Class Initialized
INFO - 2024-08-14 17:05:22 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:22 --> Input Class Initialized
INFO - 2024-08-14 17:05:22 --> Language Class Initialized
INFO - 2024-08-14 17:05:22 --> Loader Class Initialized
INFO - 2024-08-14 17:05:22 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:22 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:22 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:22 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:22 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:22 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:22 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:22 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:22 --> Controller Class Initialized
INFO - 2024-08-14 17:05:22 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:22 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:22 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:22 --> Total execution time: 0.0673
INFO - 2024-08-14 17:05:23 --> Config Class Initialized
INFO - 2024-08-14 17:05:23 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:23 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:23 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:23 --> URI Class Initialized
INFO - 2024-08-14 17:05:23 --> Router Class Initialized
INFO - 2024-08-14 17:05:23 --> Output Class Initialized
INFO - 2024-08-14 17:05:23 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:23 --> Input Class Initialized
INFO - 2024-08-14 17:05:23 --> Language Class Initialized
INFO - 2024-08-14 17:05:23 --> Loader Class Initialized
INFO - 2024-08-14 17:05:23 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:23 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:23 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:23 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:23 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:23 --> Controller Class Initialized
INFO - 2024-08-14 17:05:23 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:23 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:23 --> Total execution time: 0.0706
INFO - 2024-08-14 17:05:23 --> Config Class Initialized
INFO - 2024-08-14 17:05:23 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:23 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:23 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:23 --> URI Class Initialized
INFO - 2024-08-14 17:05:23 --> Router Class Initialized
INFO - 2024-08-14 17:05:23 --> Output Class Initialized
INFO - 2024-08-14 17:05:23 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:23 --> Input Class Initialized
INFO - 2024-08-14 17:05:23 --> Language Class Initialized
INFO - 2024-08-14 17:05:23 --> Loader Class Initialized
INFO - 2024-08-14 17:05:23 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:23 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:23 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:23 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:23 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:23 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:23 --> Controller Class Initialized
INFO - 2024-08-14 17:05:23 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:23 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:23 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:23 --> Total execution time: 0.0537
INFO - 2024-08-14 17:05:24 --> Config Class Initialized
INFO - 2024-08-14 17:05:24 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:24 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:24 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:24 --> URI Class Initialized
INFO - 2024-08-14 17:05:24 --> Router Class Initialized
INFO - 2024-08-14 17:05:24 --> Output Class Initialized
INFO - 2024-08-14 17:05:24 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:24 --> Input Class Initialized
INFO - 2024-08-14 17:05:24 --> Language Class Initialized
INFO - 2024-08-14 17:05:24 --> Loader Class Initialized
INFO - 2024-08-14 17:05:24 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:24 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:24 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:24 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:24 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:24 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:24 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:24 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:24 --> Controller Class Initialized
INFO - 2024-08-14 17:05:24 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:24 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:24 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:24 --> Total execution time: 0.0665
INFO - 2024-08-14 17:05:25 --> Config Class Initialized
INFO - 2024-08-14 17:05:25 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:25 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:25 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:25 --> URI Class Initialized
INFO - 2024-08-14 17:05:25 --> Router Class Initialized
INFO - 2024-08-14 17:05:25 --> Output Class Initialized
INFO - 2024-08-14 17:05:25 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:25 --> Input Class Initialized
INFO - 2024-08-14 17:05:25 --> Language Class Initialized
INFO - 2024-08-14 17:05:25 --> Loader Class Initialized
INFO - 2024-08-14 17:05:25 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:25 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:25 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:25 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:25 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:25 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:25 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:25 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:25 --> Controller Class Initialized
INFO - 2024-08-14 17:05:25 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:25 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:25 --> File loaded: C:\xampp\htdocs\simba\application\views\report/reportinventaris.php
INFO - 2024-08-14 17:05:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:25 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:25 --> Total execution time: 0.0802
INFO - 2024-08-14 17:05:26 --> Config Class Initialized
INFO - 2024-08-14 17:05:26 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:26 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:26 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:26 --> URI Class Initialized
INFO - 2024-08-14 17:05:26 --> Router Class Initialized
INFO - 2024-08-14 17:05:26 --> Output Class Initialized
INFO - 2024-08-14 17:05:26 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:26 --> Input Class Initialized
INFO - 2024-08-14 17:05:26 --> Language Class Initialized
INFO - 2024-08-14 17:05:26 --> Loader Class Initialized
INFO - 2024-08-14 17:05:26 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:26 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:26 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:26 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:26 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:26 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:26 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:26 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:26 --> Controller Class Initialized
INFO - 2024-08-14 17:05:26 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:26 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:26 --> File loaded: C:\xampp\htdocs\simba\application\views\report/reportinventaris.php
INFO - 2024-08-14 17:05:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:26 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:26 --> Total execution time: 0.0807
INFO - 2024-08-14 17:05:29 --> Config Class Initialized
INFO - 2024-08-14 17:05:29 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:29 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:29 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:29 --> URI Class Initialized
INFO - 2024-08-14 17:05:29 --> Router Class Initialized
INFO - 2024-08-14 17:05:29 --> Output Class Initialized
INFO - 2024-08-14 17:05:29 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:29 --> Input Class Initialized
INFO - 2024-08-14 17:05:29 --> Language Class Initialized
INFO - 2024-08-14 17:05:29 --> Loader Class Initialized
INFO - 2024-08-14 17:05:29 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:29 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:29 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:29 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:29 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:29 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:30 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:30 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:30 --> Controller Class Initialized
INFO - 2024-08-14 17:05:30 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:30 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:30 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:30 --> Total execution time: 0.0787
INFO - 2024-08-14 17:05:40 --> Config Class Initialized
INFO - 2024-08-14 17:05:40 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:40 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:40 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:40 --> URI Class Initialized
INFO - 2024-08-14 17:05:40 --> Router Class Initialized
INFO - 2024-08-14 17:05:40 --> Output Class Initialized
INFO - 2024-08-14 17:05:40 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:40 --> Input Class Initialized
INFO - 2024-08-14 17:05:40 --> Language Class Initialized
INFO - 2024-08-14 17:05:40 --> Loader Class Initialized
INFO - 2024-08-14 17:05:40 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:40 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:40 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:40 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:40 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:40 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:40 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:40 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:40 --> Controller Class Initialized
INFO - 2024-08-14 17:05:40 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:40 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:40 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:40 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:40 --> Total execution time: 0.0618
INFO - 2024-08-14 17:05:56 --> Config Class Initialized
INFO - 2024-08-14 17:05:56 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:56 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:56 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:56 --> URI Class Initialized
INFO - 2024-08-14 17:05:56 --> Router Class Initialized
INFO - 2024-08-14 17:05:56 --> Output Class Initialized
INFO - 2024-08-14 17:05:56 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:56 --> Input Class Initialized
INFO - 2024-08-14 17:05:56 --> Language Class Initialized
INFO - 2024-08-14 17:05:56 --> Loader Class Initialized
INFO - 2024-08-14 17:05:56 --> Helper loaded: url_helper
INFO - 2024-08-14 17:05:56 --> Helper loaded: file_helper
INFO - 2024-08-14 17:05:56 --> Helper loaded: security_helper
INFO - 2024-08-14 17:05:56 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:05:56 --> Database Driver Class Initialized
INFO - 2024-08-14 17:05:56 --> Email Class Initialized
DEBUG - 2024-08-14 17:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:05:56 --> Helper loaded: form_helper
INFO - 2024-08-14 17:05:56 --> Form Validation Class Initialized
INFO - 2024-08-14 17:05:56 --> Controller Class Initialized
INFO - 2024-08-14 17:05:56 --> Model "User_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:05:56 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:05:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:05:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:05:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:05:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:05:56 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:05:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:05:56 --> Final output sent to browser
DEBUG - 2024-08-14 17:05:56 --> Total execution time: 0.0557
INFO - 2024-08-14 17:05:59 --> Config Class Initialized
INFO - 2024-08-14 17:05:59 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:05:59 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:05:59 --> Utf8 Class Initialized
INFO - 2024-08-14 17:05:59 --> URI Class Initialized
INFO - 2024-08-14 17:05:59 --> Router Class Initialized
INFO - 2024-08-14 17:05:59 --> Output Class Initialized
INFO - 2024-08-14 17:05:59 --> Security Class Initialized
DEBUG - 2024-08-14 17:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:05:59 --> Input Class Initialized
INFO - 2024-08-14 17:05:59 --> Language Class Initialized
ERROR - 2024-08-14 17:05:59 --> 404 Page Not Found: Exportinventaris/index
INFO - 2024-08-14 17:21:16 --> Config Class Initialized
INFO - 2024-08-14 17:21:16 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:16 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:16 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:16 --> URI Class Initialized
INFO - 2024-08-14 17:21:16 --> Router Class Initialized
INFO - 2024-08-14 17:21:16 --> Output Class Initialized
INFO - 2024-08-14 17:21:16 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:16 --> Input Class Initialized
INFO - 2024-08-14 17:21:16 --> Language Class Initialized
INFO - 2024-08-14 17:21:16 --> Loader Class Initialized
INFO - 2024-08-14 17:21:16 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:16 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:16 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:16 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:16 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:16 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:16 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:16 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:16 --> Controller Class Initialized
INFO - 2024-08-14 17:21:16 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:16 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:16 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:16 --> Total execution time: 0.0636
INFO - 2024-08-14 17:21:31 --> Config Class Initialized
INFO - 2024-08-14 17:21:31 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:31 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:31 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:31 --> URI Class Initialized
INFO - 2024-08-14 17:21:31 --> Router Class Initialized
INFO - 2024-08-14 17:21:31 --> Output Class Initialized
INFO - 2024-08-14 17:21:31 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:31 --> Input Class Initialized
INFO - 2024-08-14 17:21:31 --> Language Class Initialized
INFO - 2024-08-14 17:21:31 --> Loader Class Initialized
INFO - 2024-08-14 17:21:31 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:31 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:31 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:31 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:31 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:31 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:31 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:31 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:31 --> Controller Class Initialized
INFO - 2024-08-14 17:21:31 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:31 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:31 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:31 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:31 --> Total execution time: 0.1474
INFO - 2024-08-14 17:21:32 --> Config Class Initialized
INFO - 2024-08-14 17:21:32 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:32 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:32 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:32 --> URI Class Initialized
INFO - 2024-08-14 17:21:32 --> Router Class Initialized
INFO - 2024-08-14 17:21:32 --> Output Class Initialized
INFO - 2024-08-14 17:21:32 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:32 --> Input Class Initialized
INFO - 2024-08-14 17:21:32 --> Language Class Initialized
INFO - 2024-08-14 17:21:32 --> Loader Class Initialized
INFO - 2024-08-14 17:21:32 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:32 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:32 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:32 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:32 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:32 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:32 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:32 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:32 --> Controller Class Initialized
INFO - 2024-08-14 17:21:32 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:32 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:32 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:32 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:32 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:33 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:33 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:33 --> Total execution time: 0.0774
INFO - 2024-08-14 17:21:35 --> Config Class Initialized
INFO - 2024-08-14 17:21:35 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:35 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:35 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:35 --> URI Class Initialized
INFO - 2024-08-14 17:21:35 --> Router Class Initialized
INFO - 2024-08-14 17:21:35 --> Output Class Initialized
INFO - 2024-08-14 17:21:35 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:35 --> Input Class Initialized
INFO - 2024-08-14 17:21:35 --> Language Class Initialized
INFO - 2024-08-14 17:21:35 --> Loader Class Initialized
INFO - 2024-08-14 17:21:35 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:35 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:35 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:35 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:35 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:35 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:35 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:35 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:35 --> Controller Class Initialized
INFO - 2024-08-14 17:21:35 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:35 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:35 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:35 --> Total execution time: 0.1201
INFO - 2024-08-14 17:21:39 --> Config Class Initialized
INFO - 2024-08-14 17:21:39 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:39 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:39 --> URI Class Initialized
INFO - 2024-08-14 17:21:39 --> Router Class Initialized
INFO - 2024-08-14 17:21:39 --> Output Class Initialized
INFO - 2024-08-14 17:21:39 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:39 --> Input Class Initialized
INFO - 2024-08-14 17:21:39 --> Language Class Initialized
INFO - 2024-08-14 17:21:39 --> Loader Class Initialized
INFO - 2024-08-14 17:21:39 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:39 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:39 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:39 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:39 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:39 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:39 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:39 --> Controller Class Initialized
INFO - 2024-08-14 17:21:39 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:39 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:39 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:39 --> Total execution time: 0.0757
INFO - 2024-08-14 17:21:45 --> Config Class Initialized
INFO - 2024-08-14 17:21:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 17:21:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 17:21:45 --> Utf8 Class Initialized
INFO - 2024-08-14 17:21:45 --> URI Class Initialized
INFO - 2024-08-14 17:21:45 --> Router Class Initialized
INFO - 2024-08-14 17:21:45 --> Output Class Initialized
INFO - 2024-08-14 17:21:45 --> Security Class Initialized
DEBUG - 2024-08-14 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 17:21:45 --> Input Class Initialized
INFO - 2024-08-14 17:21:45 --> Language Class Initialized
INFO - 2024-08-14 17:21:45 --> Loader Class Initialized
INFO - 2024-08-14 17:21:45 --> Helper loaded: url_helper
INFO - 2024-08-14 17:21:45 --> Helper loaded: file_helper
INFO - 2024-08-14 17:21:45 --> Helper loaded: security_helper
INFO - 2024-08-14 17:21:45 --> Helper loaded: wpu_helper
INFO - 2024-08-14 17:21:45 --> Database Driver Class Initialized
INFO - 2024-08-14 17:21:45 --> Email Class Initialized
DEBUG - 2024-08-14 17:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 17:21:45 --> Helper loaded: form_helper
INFO - 2024-08-14 17:21:45 --> Form Validation Class Initialized
INFO - 2024-08-14 17:21:45 --> Controller Class Initialized
INFO - 2024-08-14 17:21:45 --> Model "User_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Permintaan_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Faktur_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Pesanan_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Supplier_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Jenis_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Inventaris_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Barang_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Perbaikan_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Peminjaman_model" initialized
INFO - 2024-08-14 17:21:45 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-14 17:21:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 17:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-14 17:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-14 17:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-14 17:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-14 17:21:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-14 17:21:45 --> Final output sent to browser
DEBUG - 2024-08-14 17:21:45 --> Total execution time: 0.1266
INFO - 2024-08-14 23:54:01 --> Config Class Initialized
INFO - 2024-08-14 23:54:01 --> Hooks Class Initialized
DEBUG - 2024-08-14 23:54:01 --> UTF-8 Support Enabled
INFO - 2024-08-14 23:54:01 --> Utf8 Class Initialized
INFO - 2024-08-14 23:54:01 --> URI Class Initialized
DEBUG - 2024-08-14 23:54:01 --> No URI present. Default controller set.
INFO - 2024-08-14 23:54:01 --> Router Class Initialized
INFO - 2024-08-14 23:54:01 --> Output Class Initialized
INFO - 2024-08-14 23:54:01 --> Security Class Initialized
DEBUG - 2024-08-14 23:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 23:54:01 --> Input Class Initialized
INFO - 2024-08-14 23:54:01 --> Language Class Initialized
INFO - 2024-08-14 23:54:01 --> Loader Class Initialized
INFO - 2024-08-14 23:54:01 --> Helper loaded: url_helper
INFO - 2024-08-14 23:54:01 --> Helper loaded: file_helper
INFO - 2024-08-14 23:54:01 --> Helper loaded: security_helper
INFO - 2024-08-14 23:54:01 --> Helper loaded: wpu_helper
INFO - 2024-08-14 23:54:01 --> Database Driver Class Initialized
INFO - 2024-08-14 23:54:01 --> Email Class Initialized
DEBUG - 2024-08-14 23:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-14 23:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 23:54:01 --> Helper loaded: form_helper
INFO - 2024-08-14 23:54:01 --> Form Validation Class Initialized
INFO - 2024-08-14 23:54:01 --> Controller Class Initialized
DEBUG - 2024-08-14 23:54:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-14 23:54:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-14 23:54:01 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-14 23:54:01 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-14 23:54:01 --> Final output sent to browser
DEBUG - 2024-08-14 23:54:01 --> Total execution time: 0.7770
