<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-26 02:25:55 --> Config Class Initialized
INFO - 2024-10-26 02:25:55 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:25:55 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:25:55 --> Utf8 Class Initialized
INFO - 2024-10-26 02:25:55 --> URI Class Initialized
DEBUG - 2024-10-26 02:25:55 --> No URI present. Default controller set.
INFO - 2024-10-26 02:25:55 --> Router Class Initialized
INFO - 2024-10-26 02:25:55 --> Output Class Initialized
INFO - 2024-10-26 02:25:55 --> Security Class Initialized
DEBUG - 2024-10-26 02:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:25:55 --> Input Class Initialized
INFO - 2024-10-26 02:25:55 --> Language Class Initialized
INFO - 2024-10-26 02:25:55 --> Loader Class Initialized
INFO - 2024-10-26 02:25:55 --> Helper loaded: url_helper
INFO - 2024-10-26 02:25:55 --> Helper loaded: file_helper
INFO - 2024-10-26 02:25:55 --> Helper loaded: security_helper
INFO - 2024-10-26 02:25:55 --> Helper loaded: wpu_helper
INFO - 2024-10-26 02:25:55 --> Database Driver Class Initialized
ERROR - 2024-10-26 02:25:59 --> Unable to connect to the database
INFO - 2024-10-26 02:25:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-26 02:26:01 --> Config Class Initialized
INFO - 2024-10-26 02:26:01 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:26:01 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:26:01 --> Utf8 Class Initialized
INFO - 2024-10-26 02:26:01 --> URI Class Initialized
DEBUG - 2024-10-26 02:26:01 --> No URI present. Default controller set.
INFO - 2024-10-26 02:26:01 --> Router Class Initialized
INFO - 2024-10-26 02:26:01 --> Output Class Initialized
INFO - 2024-10-26 02:26:01 --> Security Class Initialized
DEBUG - 2024-10-26 02:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:26:01 --> Input Class Initialized
INFO - 2024-10-26 02:26:01 --> Language Class Initialized
INFO - 2024-10-26 02:26:01 --> Loader Class Initialized
INFO - 2024-10-26 02:26:01 --> Helper loaded: url_helper
INFO - 2024-10-26 02:26:01 --> Helper loaded: file_helper
INFO - 2024-10-26 02:26:01 --> Helper loaded: security_helper
INFO - 2024-10-26 02:26:01 --> Helper loaded: wpu_helper
INFO - 2024-10-26 02:26:01 --> Database Driver Class Initialized
ERROR - 2024-10-26 02:26:02 --> Unable to connect to the database
INFO - 2024-10-26 02:26:02 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-26 02:26:14 --> Config Class Initialized
INFO - 2024-10-26 02:26:14 --> Hooks Class Initialized
DEBUG - 2024-10-26 02:26:14 --> UTF-8 Support Enabled
INFO - 2024-10-26 02:26:14 --> Utf8 Class Initialized
INFO - 2024-10-26 02:26:14 --> URI Class Initialized
INFO - 2024-10-26 02:26:14 --> Router Class Initialized
INFO - 2024-10-26 02:26:14 --> Output Class Initialized
INFO - 2024-10-26 02:26:14 --> Security Class Initialized
DEBUG - 2024-10-26 02:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 02:26:14 --> Input Class Initialized
INFO - 2024-10-26 02:26:14 --> Language Class Initialized
ERROR - 2024-10-26 02:26:14 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-26 08:40:04 --> Config Class Initialized
INFO - 2024-10-26 08:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-26 08:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-26 08:40:04 --> Utf8 Class Initialized
INFO - 2024-10-26 08:40:04 --> URI Class Initialized
DEBUG - 2024-10-26 08:40:04 --> No URI present. Default controller set.
INFO - 2024-10-26 08:40:04 --> Router Class Initialized
INFO - 2024-10-26 08:40:04 --> Output Class Initialized
INFO - 2024-10-26 08:40:04 --> Security Class Initialized
DEBUG - 2024-10-26 08:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 08:40:04 --> Input Class Initialized
INFO - 2024-10-26 08:40:04 --> Language Class Initialized
INFO - 2024-10-26 08:40:04 --> Loader Class Initialized
INFO - 2024-10-26 08:40:04 --> Helper loaded: url_helper
INFO - 2024-10-26 08:40:04 --> Helper loaded: file_helper
INFO - 2024-10-26 08:40:04 --> Helper loaded: security_helper
INFO - 2024-10-26 08:40:04 --> Helper loaded: wpu_helper
INFO - 2024-10-26 08:40:04 --> Database Driver Class Initialized
ERROR - 2024-10-26 08:40:07 --> Unable to connect to the database
INFO - 2024-10-26 08:40:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-26 14:21:35 --> Config Class Initialized
INFO - 2024-10-26 14:21:35 --> Hooks Class Initialized
DEBUG - 2024-10-26 14:21:35 --> UTF-8 Support Enabled
INFO - 2024-10-26 14:21:35 --> Utf8 Class Initialized
INFO - 2024-10-26 14:21:35 --> URI Class Initialized
DEBUG - 2024-10-26 14:21:35 --> No URI present. Default controller set.
INFO - 2024-10-26 14:21:35 --> Router Class Initialized
INFO - 2024-10-26 14:21:35 --> Output Class Initialized
INFO - 2024-10-26 14:21:35 --> Security Class Initialized
DEBUG - 2024-10-26 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 14:21:35 --> Input Class Initialized
INFO - 2024-10-26 14:21:35 --> Language Class Initialized
INFO - 2024-10-26 14:21:35 --> Loader Class Initialized
INFO - 2024-10-26 14:21:35 --> Helper loaded: url_helper
INFO - 2024-10-26 14:21:35 --> Helper loaded: file_helper
INFO - 2024-10-26 14:21:35 --> Helper loaded: security_helper
INFO - 2024-10-26 14:21:35 --> Helper loaded: wpu_helper
INFO - 2024-10-26 14:21:35 --> Database Driver Class Initialized
INFO - 2024-10-26 14:21:35 --> Email Class Initialized
DEBUG - 2024-10-26 14:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-26 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 14:21:35 --> Helper loaded: form_helper
INFO - 2024-10-26 14:21:35 --> Form Validation Class Initialized
INFO - 2024-10-26 14:21:35 --> Controller Class Initialized
DEBUG - 2024-10-26 14:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-26 14:21:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-26 14:21:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-26 14:21:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-26 14:21:35 --> Final output sent to browser
DEBUG - 2024-10-26 14:21:35 --> Total execution time: 0.2231
