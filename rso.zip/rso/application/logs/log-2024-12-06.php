<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-06 04:22:08 --> Config Class Initialized
INFO - 2024-12-06 04:22:08 --> Hooks Class Initialized
DEBUG - 2024-12-06 04:22:08 --> UTF-8 Support Enabled
INFO - 2024-12-06 04:22:08 --> Utf8 Class Initialized
INFO - 2024-12-06 04:22:08 --> URI Class Initialized
DEBUG - 2024-12-06 04:22:08 --> No URI present. Default controller set.
INFO - 2024-12-06 04:22:08 --> Router Class Initialized
INFO - 2024-12-06 04:22:08 --> Output Class Initialized
INFO - 2024-12-06 04:22:08 --> Security Class Initialized
DEBUG - 2024-12-06 04:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 04:22:08 --> Input Class Initialized
INFO - 2024-12-06 04:22:08 --> Language Class Initialized
INFO - 2024-12-06 04:22:08 --> Loader Class Initialized
INFO - 2024-12-06 04:22:08 --> Helper loaded: url_helper
INFO - 2024-12-06 04:22:08 --> Helper loaded: file_helper
INFO - 2024-12-06 04:22:08 --> Helper loaded: security_helper
INFO - 2024-12-06 04:22:08 --> Helper loaded: wpu_helper
INFO - 2024-12-06 04:22:08 --> Database Driver Class Initialized
INFO - 2024-12-06 04:22:08 --> Email Class Initialized
DEBUG - 2024-12-06 04:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 04:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 04:22:08 --> Helper loaded: form_helper
INFO - 2024-12-06 04:22:08 --> Form Validation Class Initialized
INFO - 2024-12-06 04:22:08 --> Controller Class Initialized
DEBUG - 2024-12-06 04:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 04:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 04:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 04:22:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 04:22:08 --> Final output sent to browser
DEBUG - 2024-12-06 04:22:08 --> Total execution time: 0.4144
INFO - 2024-12-06 07:23:43 --> Config Class Initialized
INFO - 2024-12-06 07:23:43 --> Hooks Class Initialized
DEBUG - 2024-12-06 07:23:43 --> UTF-8 Support Enabled
INFO - 2024-12-06 07:23:43 --> Utf8 Class Initialized
INFO - 2024-12-06 07:23:43 --> URI Class Initialized
DEBUG - 2024-12-06 07:23:43 --> No URI present. Default controller set.
INFO - 2024-12-06 07:23:43 --> Router Class Initialized
INFO - 2024-12-06 07:23:43 --> Output Class Initialized
INFO - 2024-12-06 07:23:43 --> Security Class Initialized
DEBUG - 2024-12-06 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 07:23:43 --> Input Class Initialized
INFO - 2024-12-06 07:23:43 --> Language Class Initialized
INFO - 2024-12-06 07:23:43 --> Loader Class Initialized
INFO - 2024-12-06 07:23:43 --> Helper loaded: url_helper
INFO - 2024-12-06 07:23:43 --> Helper loaded: file_helper
INFO - 2024-12-06 07:23:43 --> Helper loaded: security_helper
INFO - 2024-12-06 07:23:43 --> Helper loaded: wpu_helper
INFO - 2024-12-06 07:23:43 --> Database Driver Class Initialized
INFO - 2024-12-06 07:23:43 --> Email Class Initialized
DEBUG - 2024-12-06 07:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 07:23:43 --> Helper loaded: form_helper
INFO - 2024-12-06 07:23:43 --> Form Validation Class Initialized
INFO - 2024-12-06 07:23:43 --> Controller Class Initialized
DEBUG - 2024-12-06 07:23:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 07:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 07:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 07:23:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 07:23:43 --> Final output sent to browser
DEBUG - 2024-12-06 07:23:43 --> Total execution time: 0.4366
INFO - 2024-12-06 07:23:44 --> Config Class Initialized
INFO - 2024-12-06 07:23:44 --> Hooks Class Initialized
DEBUG - 2024-12-06 07:23:44 --> UTF-8 Support Enabled
INFO - 2024-12-06 07:23:44 --> Utf8 Class Initialized
INFO - 2024-12-06 07:23:44 --> URI Class Initialized
INFO - 2024-12-06 07:23:44 --> Router Class Initialized
INFO - 2024-12-06 07:23:44 --> Output Class Initialized
INFO - 2024-12-06 07:23:44 --> Security Class Initialized
DEBUG - 2024-12-06 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 07:23:44 --> Input Class Initialized
INFO - 2024-12-06 07:23:44 --> Language Class Initialized
ERROR - 2024-12-06 07:23:44 --> 404 Page Not Found: Adstxt/index
INFO - 2024-12-06 07:23:45 --> Config Class Initialized
INFO - 2024-12-06 07:23:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 07:23:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 07:23:45 --> Utf8 Class Initialized
INFO - 2024-12-06 07:23:45 --> URI Class Initialized
DEBUG - 2024-12-06 07:23:45 --> No URI present. Default controller set.
INFO - 2024-12-06 07:23:45 --> Router Class Initialized
INFO - 2024-12-06 07:23:45 --> Output Class Initialized
INFO - 2024-12-06 07:23:45 --> Security Class Initialized
DEBUG - 2024-12-06 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 07:23:45 --> Input Class Initialized
INFO - 2024-12-06 07:23:45 --> Language Class Initialized
INFO - 2024-12-06 07:23:45 --> Loader Class Initialized
INFO - 2024-12-06 07:23:45 --> Helper loaded: url_helper
INFO - 2024-12-06 07:23:45 --> Helper loaded: file_helper
INFO - 2024-12-06 07:23:45 --> Helper loaded: security_helper
INFO - 2024-12-06 07:23:45 --> Helper loaded: wpu_helper
INFO - 2024-12-06 07:23:45 --> Database Driver Class Initialized
INFO - 2024-12-06 07:23:45 --> Email Class Initialized
DEBUG - 2024-12-06 07:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 07:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 07:23:45 --> Helper loaded: form_helper
INFO - 2024-12-06 07:23:45 --> Form Validation Class Initialized
INFO - 2024-12-06 07:23:45 --> Controller Class Initialized
DEBUG - 2024-12-06 07:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 07:23:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 07:23:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 07:23:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 07:23:45 --> Final output sent to browser
DEBUG - 2024-12-06 07:23:45 --> Total execution time: 0.4255
INFO - 2024-12-06 07:23:50 --> Config Class Initialized
INFO - 2024-12-06 07:23:50 --> Hooks Class Initialized
DEBUG - 2024-12-06 07:23:50 --> UTF-8 Support Enabled
INFO - 2024-12-06 07:23:50 --> Utf8 Class Initialized
INFO - 2024-12-06 07:23:50 --> URI Class Initialized
INFO - 2024-12-06 07:23:50 --> Router Class Initialized
INFO - 2024-12-06 07:23:50 --> Output Class Initialized
INFO - 2024-12-06 07:23:50 --> Security Class Initialized
DEBUG - 2024-12-06 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 07:23:50 --> Input Class Initialized
INFO - 2024-12-06 07:23:50 --> Language Class Initialized
ERROR - 2024-12-06 07:23:50 --> 404 Page Not Found: Adstxt/index
INFO - 2024-12-06 09:15:40 --> Config Class Initialized
INFO - 2024-12-06 09:15:40 --> Hooks Class Initialized
DEBUG - 2024-12-06 09:15:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 09:15:41 --> Utf8 Class Initialized
INFO - 2024-12-06 09:15:41 --> URI Class Initialized
DEBUG - 2024-12-06 09:15:41 --> No URI present. Default controller set.
INFO - 2024-12-06 09:15:41 --> Router Class Initialized
INFO - 2024-12-06 09:15:41 --> Output Class Initialized
INFO - 2024-12-06 09:15:41 --> Security Class Initialized
DEBUG - 2024-12-06 09:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 09:15:41 --> Input Class Initialized
INFO - 2024-12-06 09:15:41 --> Language Class Initialized
INFO - 2024-12-06 09:15:41 --> Loader Class Initialized
INFO - 2024-12-06 09:15:41 --> Helper loaded: url_helper
INFO - 2024-12-06 09:15:41 --> Helper loaded: file_helper
INFO - 2024-12-06 09:15:41 --> Helper loaded: security_helper
INFO - 2024-12-06 09:15:41 --> Helper loaded: wpu_helper
INFO - 2024-12-06 09:15:41 --> Database Driver Class Initialized
INFO - 2024-12-06 09:15:41 --> Email Class Initialized
DEBUG - 2024-12-06 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 09:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 09:15:41 --> Helper loaded: form_helper
INFO - 2024-12-06 09:15:41 --> Form Validation Class Initialized
INFO - 2024-12-06 09:15:41 --> Controller Class Initialized
DEBUG - 2024-12-06 09:15:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 09:15:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 09:15:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 09:15:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 09:15:41 --> Final output sent to browser
DEBUG - 2024-12-06 09:15:41 --> Total execution time: 0.4062
INFO - 2024-12-06 15:46:36 --> Config Class Initialized
INFO - 2024-12-06 15:46:36 --> Hooks Class Initialized
DEBUG - 2024-12-06 15:46:36 --> UTF-8 Support Enabled
INFO - 2024-12-06 15:46:36 --> Utf8 Class Initialized
INFO - 2024-12-06 15:46:36 --> URI Class Initialized
DEBUG - 2024-12-06 15:46:36 --> No URI present. Default controller set.
INFO - 2024-12-06 15:46:36 --> Router Class Initialized
INFO - 2024-12-06 15:46:36 --> Output Class Initialized
INFO - 2024-12-06 15:46:36 --> Security Class Initialized
DEBUG - 2024-12-06 15:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 15:46:36 --> Input Class Initialized
INFO - 2024-12-06 15:46:36 --> Language Class Initialized
INFO - 2024-12-06 15:46:36 --> Loader Class Initialized
INFO - 2024-12-06 15:46:36 --> Helper loaded: url_helper
INFO - 2024-12-06 15:46:36 --> Helper loaded: file_helper
INFO - 2024-12-06 15:46:36 --> Helper loaded: security_helper
INFO - 2024-12-06 15:46:36 --> Helper loaded: wpu_helper
INFO - 2024-12-06 15:46:36 --> Database Driver Class Initialized
INFO - 2024-12-06 15:46:37 --> Email Class Initialized
DEBUG - 2024-12-06 15:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 15:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 15:46:37 --> Helper loaded: form_helper
INFO - 2024-12-06 15:46:37 --> Form Validation Class Initialized
INFO - 2024-12-06 15:46:37 --> Controller Class Initialized
DEBUG - 2024-12-06 15:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 15:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 15:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 15:46:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 15:46:37 --> Final output sent to browser
DEBUG - 2024-12-06 15:46:37 --> Total execution time: 0.4185
INFO - 2024-12-06 16:48:41 --> Config Class Initialized
INFO - 2024-12-06 16:48:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:41 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:41 --> URI Class Initialized
INFO - 2024-12-06 16:48:41 --> Router Class Initialized
INFO - 2024-12-06 16:48:41 --> Output Class Initialized
INFO - 2024-12-06 16:48:41 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:41 --> Input Class Initialized
INFO - 2024-12-06 16:48:41 --> Language Class Initialized
ERROR - 2024-12-06 16:48:41 --> 404 Page Not Found: Atomxml/index
INFO - 2024-12-06 16:48:42 --> Config Class Initialized
INFO - 2024-12-06 16:48:42 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:42 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:42 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:42 --> URI Class Initialized
INFO - 2024-12-06 16:48:42 --> Router Class Initialized
INFO - 2024-12-06 16:48:42 --> Output Class Initialized
INFO - 2024-12-06 16:48:42 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:42 --> Input Class Initialized
INFO - 2024-12-06 16:48:42 --> Language Class Initialized
ERROR - 2024-12-06 16:48:42 --> 404 Page Not Found: Sitemap_indexxml/index
INFO - 2024-12-06 16:48:43 --> Config Class Initialized
INFO - 2024-12-06 16:48:43 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:43 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:43 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:43 --> URI Class Initialized
INFO - 2024-12-06 16:48:43 --> Router Class Initialized
INFO - 2024-12-06 16:48:43 --> Output Class Initialized
INFO - 2024-12-06 16:48:43 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:43 --> Input Class Initialized
INFO - 2024-12-06 16:48:43 --> Language Class Initialized
ERROR - 2024-12-06 16:48:43 --> 404 Page Not Found: Sitemapsxml/index
INFO - 2024-12-06 16:48:45 --> Config Class Initialized
INFO - 2024-12-06 16:48:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:45 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:45 --> URI Class Initialized
INFO - 2024-12-06 16:48:45 --> Router Class Initialized
INFO - 2024-12-06 16:48:45 --> Output Class Initialized
INFO - 2024-12-06 16:48:45 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:45 --> Input Class Initialized
INFO - 2024-12-06 16:48:45 --> Language Class Initialized
ERROR - 2024-12-06 16:48:45 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-12-06 16:48:51 --> Config Class Initialized
INFO - 2024-12-06 16:48:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:51 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:51 --> URI Class Initialized
INFO - 2024-12-06 16:48:51 --> Router Class Initialized
INFO - 2024-12-06 16:48:51 --> Output Class Initialized
INFO - 2024-12-06 16:48:51 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:51 --> Input Class Initialized
INFO - 2024-12-06 16:48:51 --> Language Class Initialized
ERROR - 2024-12-06 16:48:51 --> 404 Page Not Found: Sitemapxmlgz/index
INFO - 2024-12-06 16:48:52 --> Config Class Initialized
INFO - 2024-12-06 16:48:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 16:48:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 16:48:52 --> Utf8 Class Initialized
INFO - 2024-12-06 16:48:52 --> URI Class Initialized
INFO - 2024-12-06 16:48:52 --> Router Class Initialized
INFO - 2024-12-06 16:48:52 --> Output Class Initialized
INFO - 2024-12-06 16:48:52 --> Security Class Initialized
DEBUG - 2024-12-06 16:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 16:48:52 --> Input Class Initialized
INFO - 2024-12-06 16:48:52 --> Language Class Initialized
ERROR - 2024-12-06 16:48:52 --> 404 Page Not Found: Sitemaptxt/index
INFO - 2024-12-06 18:45:46 --> Config Class Initialized
INFO - 2024-12-06 18:45:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:45:46 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:45:46 --> Utf8 Class Initialized
INFO - 2024-12-06 18:45:46 --> URI Class Initialized
DEBUG - 2024-12-06 18:45:46 --> No URI present. Default controller set.
INFO - 2024-12-06 18:45:46 --> Router Class Initialized
INFO - 2024-12-06 18:45:46 --> Output Class Initialized
INFO - 2024-12-06 18:45:46 --> Security Class Initialized
DEBUG - 2024-12-06 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:45:46 --> Input Class Initialized
INFO - 2024-12-06 18:45:46 --> Language Class Initialized
INFO - 2024-12-06 18:45:46 --> Loader Class Initialized
INFO - 2024-12-06 18:45:46 --> Helper loaded: url_helper
INFO - 2024-12-06 18:45:46 --> Helper loaded: file_helper
INFO - 2024-12-06 18:45:46 --> Helper loaded: security_helper
INFO - 2024-12-06 18:45:46 --> Helper loaded: wpu_helper
INFO - 2024-12-06 18:45:46 --> Database Driver Class Initialized
INFO - 2024-12-06 18:45:46 --> Email Class Initialized
DEBUG - 2024-12-06 18:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 18:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 18:45:46 --> Helper loaded: form_helper
INFO - 2024-12-06 18:45:46 --> Form Validation Class Initialized
INFO - 2024-12-06 18:45:46 --> Controller Class Initialized
DEBUG - 2024-12-06 18:45:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 18:45:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 18:45:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 18:45:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 18:45:46 --> Final output sent to browser
DEBUG - 2024-12-06 18:45:46 --> Total execution time: 0.4304
INFO - 2024-12-06 18:45:47 --> Config Class Initialized
INFO - 2024-12-06 18:45:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:45:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:45:47 --> Utf8 Class Initialized
INFO - 2024-12-06 18:45:47 --> URI Class Initialized
DEBUG - 2024-12-06 18:45:47 --> No URI present. Default controller set.
INFO - 2024-12-06 18:45:47 --> Router Class Initialized
INFO - 2024-12-06 18:45:47 --> Output Class Initialized
INFO - 2024-12-06 18:45:47 --> Security Class Initialized
DEBUG - 2024-12-06 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:45:47 --> Input Class Initialized
INFO - 2024-12-06 18:45:47 --> Language Class Initialized
INFO - 2024-12-06 18:45:47 --> Loader Class Initialized
INFO - 2024-12-06 18:45:47 --> Helper loaded: url_helper
INFO - 2024-12-06 18:45:47 --> Helper loaded: file_helper
INFO - 2024-12-06 18:45:47 --> Helper loaded: security_helper
INFO - 2024-12-06 18:45:47 --> Helper loaded: wpu_helper
INFO - 2024-12-06 18:45:47 --> Database Driver Class Initialized
INFO - 2024-12-06 18:45:48 --> Email Class Initialized
DEBUG - 2024-12-06 18:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 18:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 18:45:48 --> Helper loaded: form_helper
INFO - 2024-12-06 18:45:48 --> Form Validation Class Initialized
INFO - 2024-12-06 18:45:48 --> Controller Class Initialized
DEBUG - 2024-12-06 18:45:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 18:45:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 18:45:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 18:45:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 18:45:48 --> Final output sent to browser
DEBUG - 2024-12-06 18:45:48 --> Total execution time: 0.4173
INFO - 2024-12-06 18:48:46 --> Config Class Initialized
INFO - 2024-12-06 18:48:46 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:48:46 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:48:46 --> Utf8 Class Initialized
INFO - 2024-12-06 18:48:46 --> URI Class Initialized
DEBUG - 2024-12-06 18:48:46 --> No URI present. Default controller set.
INFO - 2024-12-06 18:48:46 --> Router Class Initialized
INFO - 2024-12-06 18:48:46 --> Output Class Initialized
INFO - 2024-12-06 18:48:46 --> Security Class Initialized
DEBUG - 2024-12-06 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:48:46 --> Input Class Initialized
INFO - 2024-12-06 18:48:46 --> Language Class Initialized
INFO - 2024-12-06 18:48:46 --> Loader Class Initialized
INFO - 2024-12-06 18:48:46 --> Helper loaded: url_helper
INFO - 2024-12-06 18:48:46 --> Helper loaded: file_helper
INFO - 2024-12-06 18:48:46 --> Helper loaded: security_helper
INFO - 2024-12-06 18:48:46 --> Helper loaded: wpu_helper
INFO - 2024-12-06 18:48:46 --> Database Driver Class Initialized
INFO - 2024-12-06 18:48:47 --> Email Class Initialized
DEBUG - 2024-12-06 18:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-06 18:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 18:48:47 --> Helper loaded: form_helper
INFO - 2024-12-06 18:48:47 --> Form Validation Class Initialized
INFO - 2024-12-06 18:48:47 --> Controller Class Initialized
DEBUG - 2024-12-06 18:48:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-06 18:48:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-06 18:48:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-06 18:48:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-06 18:48:47 --> Final output sent to browser
DEBUG - 2024-12-06 18:48:47 --> Total execution time: 0.4419
INFO - 2024-12-06 18:49:21 --> Config Class Initialized
INFO - 2024-12-06 18:49:21 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:49:21 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:49:21 --> Utf8 Class Initialized
INFO - 2024-12-06 18:49:21 --> URI Class Initialized
INFO - 2024-12-06 18:49:21 --> Router Class Initialized
INFO - 2024-12-06 18:49:21 --> Output Class Initialized
INFO - 2024-12-06 18:49:21 --> Security Class Initialized
DEBUG - 2024-12-06 18:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:49:21 --> Input Class Initialized
INFO - 2024-12-06 18:49:21 --> Language Class Initialized
ERROR - 2024-12-06 18:49:21 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:49:22 --> Config Class Initialized
INFO - 2024-12-06 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:49:22 --> Utf8 Class Initialized
INFO - 2024-12-06 18:49:22 --> URI Class Initialized
INFO - 2024-12-06 18:49:22 --> Router Class Initialized
INFO - 2024-12-06 18:49:22 --> Output Class Initialized
INFO - 2024-12-06 18:49:22 --> Security Class Initialized
DEBUG - 2024-12-06 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:49:22 --> Input Class Initialized
INFO - 2024-12-06 18:49:22 --> Language Class Initialized
ERROR - 2024-12-06 18:49:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:49:22 --> Config Class Initialized
INFO - 2024-12-06 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:49:22 --> Utf8 Class Initialized
INFO - 2024-12-06 18:49:22 --> Config Class Initialized
INFO - 2024-12-06 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:49:22 --> Utf8 Class Initialized
INFO - 2024-12-06 18:49:22 --> URI Class Initialized
INFO - 2024-12-06 18:49:22 --> Router Class Initialized
INFO - 2024-12-06 18:49:22 --> URI Class Initialized
INFO - 2024-12-06 18:49:22 --> Output Class Initialized
INFO - 2024-12-06 18:49:22 --> Router Class Initialized
INFO - 2024-12-06 18:49:22 --> Security Class Initialized
INFO - 2024-12-06 18:49:22 --> Output Class Initialized
DEBUG - 2024-12-06 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:49:22 --> Input Class Initialized
INFO - 2024-12-06 18:49:22 --> Language Class Initialized
ERROR - 2024-12-06 18:49:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:49:22 --> Security Class Initialized
DEBUG - 2024-12-06 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:49:22 --> Input Class Initialized
INFO - 2024-12-06 18:49:22 --> Language Class Initialized
ERROR - 2024-12-06 18:49:22 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:49:22 --> Config Class Initialized
INFO - 2024-12-06 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:49:22 --> Utf8 Class Initialized
INFO - 2024-12-06 18:49:22 --> URI Class Initialized
INFO - 2024-12-06 18:49:22 --> Router Class Initialized
INFO - 2024-12-06 18:49:22 --> Output Class Initialized
INFO - 2024-12-06 18:49:22 --> Security Class Initialized
DEBUG - 2024-12-06 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:49:22 --> Input Class Initialized
INFO - 2024-12-06 18:49:22 --> Language Class Initialized
ERROR - 2024-12-06 18:49:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:09 --> Config Class Initialized
INFO - 2024-12-06 18:50:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:09 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:09 --> URI Class Initialized
INFO - 2024-12-06 18:50:09 --> Router Class Initialized
INFO - 2024-12-06 18:50:09 --> Output Class Initialized
INFO - 2024-12-06 18:50:09 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:09 --> Input Class Initialized
INFO - 2024-12-06 18:50:09 --> Language Class Initialized
ERROR - 2024-12-06 18:50:09 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:09 --> Config Class Initialized
INFO - 2024-12-06 18:50:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:09 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:09 --> URI Class Initialized
INFO - 2024-12-06 18:50:09 --> Router Class Initialized
INFO - 2024-12-06 18:50:09 --> Output Class Initialized
INFO - 2024-12-06 18:50:09 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:09 --> Input Class Initialized
INFO - 2024-12-06 18:50:09 --> Language Class Initialized
ERROR - 2024-12-06 18:50:09 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:50:10 --> Config Class Initialized
INFO - 2024-12-06 18:50:10 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:10 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:10 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:10 --> URI Class Initialized
INFO - 2024-12-06 18:50:10 --> Router Class Initialized
INFO - 2024-12-06 18:50:10 --> Output Class Initialized
INFO - 2024-12-06 18:50:10 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:10 --> Input Class Initialized
INFO - 2024-12-06 18:50:10 --> Language Class Initialized
ERROR - 2024-12-06 18:50:10 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:10 --> Config Class Initialized
INFO - 2024-12-06 18:50:10 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:10 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:10 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:10 --> URI Class Initialized
INFO - 2024-12-06 18:50:10 --> Router Class Initialized
INFO - 2024-12-06 18:50:10 --> Output Class Initialized
INFO - 2024-12-06 18:50:10 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:10 --> Input Class Initialized
INFO - 2024-12-06 18:50:10 --> Language Class Initialized
ERROR - 2024-12-06 18:50:10 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:10 --> Config Class Initialized
INFO - 2024-12-06 18:50:10 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:10 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:10 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:10 --> URI Class Initialized
INFO - 2024-12-06 18:50:10 --> Router Class Initialized
INFO - 2024-12-06 18:50:10 --> Output Class Initialized
INFO - 2024-12-06 18:50:10 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:10 --> Input Class Initialized
INFO - 2024-12-06 18:50:10 --> Language Class Initialized
ERROR - 2024-12-06 18:50:10 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:51 --> Config Class Initialized
INFO - 2024-12-06 18:50:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:51 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:51 --> URI Class Initialized
INFO - 2024-12-06 18:50:51 --> Router Class Initialized
INFO - 2024-12-06 18:50:51 --> Output Class Initialized
INFO - 2024-12-06 18:50:51 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:51 --> Input Class Initialized
INFO - 2024-12-06 18:50:51 --> Language Class Initialized
ERROR - 2024-12-06 18:50:51 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:50:51 --> Config Class Initialized
INFO - 2024-12-06 18:50:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:51 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:51 --> Config Class Initialized
INFO - 2024-12-06 18:50:51 --> Hooks Class Initialized
INFO - 2024-12-06 18:50:51 --> URI Class Initialized
DEBUG - 2024-12-06 18:50:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:51 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:51 --> Router Class Initialized
INFO - 2024-12-06 18:50:51 --> URI Class Initialized
INFO - 2024-12-06 18:50:51 --> Router Class Initialized
INFO - 2024-12-06 18:50:51 --> Output Class Initialized
INFO - 2024-12-06 18:50:51 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:51 --> Input Class Initialized
INFO - 2024-12-06 18:50:51 --> Language Class Initialized
ERROR - 2024-12-06 18:50:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:51 --> Output Class Initialized
INFO - 2024-12-06 18:50:51 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:51 --> Input Class Initialized
INFO - 2024-12-06 18:50:51 --> Language Class Initialized
ERROR - 2024-12-06 18:50:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:51 --> Config Class Initialized
INFO - 2024-12-06 18:50:51 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:51 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:51 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:51 --> URI Class Initialized
INFO - 2024-12-06 18:50:51 --> Router Class Initialized
INFO - 2024-12-06 18:50:51 --> Output Class Initialized
INFO - 2024-12-06 18:50:51 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:51 --> Input Class Initialized
INFO - 2024-12-06 18:50:51 --> Language Class Initialized
ERROR - 2024-12-06 18:50:51 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:50:53 --> Config Class Initialized
INFO - 2024-12-06 18:50:53 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:50:53 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:50:53 --> Utf8 Class Initialized
INFO - 2024-12-06 18:50:53 --> URI Class Initialized
INFO - 2024-12-06 18:50:53 --> Router Class Initialized
INFO - 2024-12-06 18:50:53 --> Output Class Initialized
INFO - 2024-12-06 18:50:53 --> Security Class Initialized
DEBUG - 2024-12-06 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:50:53 --> Input Class Initialized
INFO - 2024-12-06 18:50:53 --> Language Class Initialized
ERROR - 2024-12-06 18:50:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:51:40 --> Config Class Initialized
INFO - 2024-12-06 18:51:40 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:51:40 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:51:40 --> Utf8 Class Initialized
INFO - 2024-12-06 18:51:40 --> URI Class Initialized
INFO - 2024-12-06 18:51:40 --> Router Class Initialized
INFO - 2024-12-06 18:51:40 --> Output Class Initialized
INFO - 2024-12-06 18:51:40 --> Security Class Initialized
DEBUG - 2024-12-06 18:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:51:40 --> Input Class Initialized
INFO - 2024-12-06 18:51:40 --> Language Class Initialized
ERROR - 2024-12-06 18:51:40 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:51:40 --> Config Class Initialized
INFO - 2024-12-06 18:51:40 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:51:40 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:51:40 --> Utf8 Class Initialized
INFO - 2024-12-06 18:51:40 --> URI Class Initialized
INFO - 2024-12-06 18:51:40 --> Router Class Initialized
INFO - 2024-12-06 18:51:40 --> Output Class Initialized
INFO - 2024-12-06 18:51:40 --> Security Class Initialized
DEBUG - 2024-12-06 18:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:51:40 --> Input Class Initialized
INFO - 2024-12-06 18:51:40 --> Language Class Initialized
ERROR - 2024-12-06 18:51:40 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:51:40 --> Config Class Initialized
INFO - 2024-12-06 18:51:40 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:51:40 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:51:40 --> Utf8 Class Initialized
INFO - 2024-12-06 18:51:40 --> URI Class Initialized
INFO - 2024-12-06 18:51:40 --> Router Class Initialized
INFO - 2024-12-06 18:51:40 --> Output Class Initialized
INFO - 2024-12-06 18:51:40 --> Security Class Initialized
DEBUG - 2024-12-06 18:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:51:40 --> Input Class Initialized
INFO - 2024-12-06 18:51:40 --> Language Class Initialized
ERROR - 2024-12-06 18:51:40 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:51:41 --> Config Class Initialized
INFO - 2024-12-06 18:51:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:51:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:51:41 --> Utf8 Class Initialized
INFO - 2024-12-06 18:51:41 --> URI Class Initialized
INFO - 2024-12-06 18:51:41 --> Router Class Initialized
INFO - 2024-12-06 18:51:41 --> Output Class Initialized
INFO - 2024-12-06 18:51:41 --> Security Class Initialized
DEBUG - 2024-12-06 18:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:51:41 --> Input Class Initialized
INFO - 2024-12-06 18:51:41 --> Language Class Initialized
ERROR - 2024-12-06 18:51:41 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:51:41 --> Config Class Initialized
INFO - 2024-12-06 18:51:41 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:51:41 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:51:41 --> Utf8 Class Initialized
INFO - 2024-12-06 18:51:41 --> URI Class Initialized
INFO - 2024-12-06 18:51:41 --> Router Class Initialized
INFO - 2024-12-06 18:51:41 --> Output Class Initialized
INFO - 2024-12-06 18:51:41 --> Security Class Initialized
DEBUG - 2024-12-06 18:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:51:41 --> Input Class Initialized
INFO - 2024-12-06 18:51:41 --> Language Class Initialized
ERROR - 2024-12-06 18:51:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:52:24 --> Config Class Initialized
INFO - 2024-12-06 18:52:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:52:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:52:24 --> Utf8 Class Initialized
INFO - 2024-12-06 18:52:24 --> URI Class Initialized
INFO - 2024-12-06 18:52:24 --> Router Class Initialized
INFO - 2024-12-06 18:52:24 --> Output Class Initialized
INFO - 2024-12-06 18:52:24 --> Security Class Initialized
DEBUG - 2024-12-06 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:52:24 --> Input Class Initialized
INFO - 2024-12-06 18:52:24 --> Language Class Initialized
ERROR - 2024-12-06 18:52:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:52:24 --> Config Class Initialized
INFO - 2024-12-06 18:52:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:52:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:52:24 --> Utf8 Class Initialized
INFO - 2024-12-06 18:52:24 --> URI Class Initialized
INFO - 2024-12-06 18:52:24 --> Router Class Initialized
INFO - 2024-12-06 18:52:24 --> Output Class Initialized
INFO - 2024-12-06 18:52:24 --> Security Class Initialized
DEBUG - 2024-12-06 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:52:24 --> Input Class Initialized
INFO - 2024-12-06 18:52:24 --> Language Class Initialized
ERROR - 2024-12-06 18:52:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:52:24 --> Config Class Initialized
INFO - 2024-12-06 18:52:24 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:52:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:52:24 --> Utf8 Class Initialized
INFO - 2024-12-06 18:52:24 --> URI Class Initialized
INFO - 2024-12-06 18:52:24 --> Router Class Initialized
INFO - 2024-12-06 18:52:24 --> Config Class Initialized
INFO - 2024-12-06 18:52:24 --> Hooks Class Initialized
INFO - 2024-12-06 18:52:24 --> Output Class Initialized
DEBUG - 2024-12-06 18:52:24 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:52:24 --> Utf8 Class Initialized
INFO - 2024-12-06 18:52:24 --> Security Class Initialized
INFO - 2024-12-06 18:52:24 --> URI Class Initialized
DEBUG - 2024-12-06 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:52:24 --> Input Class Initialized
INFO - 2024-12-06 18:52:24 --> Router Class Initialized
INFO - 2024-12-06 18:52:24 --> Language Class Initialized
INFO - 2024-12-06 18:52:24 --> Output Class Initialized
ERROR - 2024-12-06 18:52:24 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:52:24 --> Security Class Initialized
DEBUG - 2024-12-06 18:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:52:24 --> Input Class Initialized
INFO - 2024-12-06 18:52:24 --> Language Class Initialized
ERROR - 2024-12-06 18:52:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:52:26 --> Config Class Initialized
INFO - 2024-12-06 18:52:26 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:52:26 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:52:26 --> Utf8 Class Initialized
INFO - 2024-12-06 18:52:26 --> URI Class Initialized
INFO - 2024-12-06 18:52:26 --> Router Class Initialized
INFO - 2024-12-06 18:52:26 --> Output Class Initialized
INFO - 2024-12-06 18:52:26 --> Security Class Initialized
DEBUG - 2024-12-06 18:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:52:26 --> Input Class Initialized
INFO - 2024-12-06 18:52:26 --> Language Class Initialized
ERROR - 2024-12-06 18:52:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:06 --> Config Class Initialized
INFO - 2024-12-06 18:53:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:06 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:06 --> URI Class Initialized
INFO - 2024-12-06 18:53:06 --> Router Class Initialized
INFO - 2024-12-06 18:53:06 --> Output Class Initialized
INFO - 2024-12-06 18:53:06 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:06 --> Input Class Initialized
INFO - 2024-12-06 18:53:06 --> Language Class Initialized
ERROR - 2024-12-06 18:53:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:06 --> Config Class Initialized
INFO - 2024-12-06 18:53:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:06 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:06 --> URI Class Initialized
INFO - 2024-12-06 18:53:06 --> Router Class Initialized
INFO - 2024-12-06 18:53:06 --> Output Class Initialized
INFO - 2024-12-06 18:53:06 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:06 --> Input Class Initialized
INFO - 2024-12-06 18:53:06 --> Language Class Initialized
ERROR - 2024-12-06 18:53:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:06 --> Config Class Initialized
INFO - 2024-12-06 18:53:06 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:06 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:06 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:06 --> URI Class Initialized
INFO - 2024-12-06 18:53:06 --> Router Class Initialized
INFO - 2024-12-06 18:53:06 --> Output Class Initialized
INFO - 2024-12-06 18:53:06 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:06 --> Input Class Initialized
INFO - 2024-12-06 18:53:06 --> Language Class Initialized
ERROR - 2024-12-06 18:53:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:07 --> Config Class Initialized
INFO - 2024-12-06 18:53:07 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:07 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:07 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:07 --> URI Class Initialized
INFO - 2024-12-06 18:53:07 --> Router Class Initialized
INFO - 2024-12-06 18:53:07 --> Output Class Initialized
INFO - 2024-12-06 18:53:07 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:07 --> Input Class Initialized
INFO - 2024-12-06 18:53:07 --> Language Class Initialized
ERROR - 2024-12-06 18:53:07 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:08 --> Config Class Initialized
INFO - 2024-12-06 18:53:08 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:08 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:08 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:08 --> URI Class Initialized
INFO - 2024-12-06 18:53:08 --> Router Class Initialized
INFO - 2024-12-06 18:53:08 --> Output Class Initialized
INFO - 2024-12-06 18:53:08 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:08 --> Input Class Initialized
INFO - 2024-12-06 18:53:08 --> Language Class Initialized
ERROR - 2024-12-06 18:53:08 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:53:45 --> Config Class Initialized
INFO - 2024-12-06 18:53:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:45 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:45 --> URI Class Initialized
INFO - 2024-12-06 18:53:45 --> Router Class Initialized
INFO - 2024-12-06 18:53:45 --> Output Class Initialized
INFO - 2024-12-06 18:53:45 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:45 --> Input Class Initialized
INFO - 2024-12-06 18:53:45 --> Language Class Initialized
ERROR - 2024-12-06 18:53:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:45 --> Config Class Initialized
INFO - 2024-12-06 18:53:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:45 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:45 --> URI Class Initialized
INFO - 2024-12-06 18:53:45 --> Router Class Initialized
INFO - 2024-12-06 18:53:45 --> Output Class Initialized
INFO - 2024-12-06 18:53:45 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:45 --> Input Class Initialized
INFO - 2024-12-06 18:53:45 --> Language Class Initialized
ERROR - 2024-12-06 18:53:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:45 --> Config Class Initialized
INFO - 2024-12-06 18:53:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:45 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:45 --> URI Class Initialized
INFO - 2024-12-06 18:53:45 --> Router Class Initialized
INFO - 2024-12-06 18:53:45 --> Output Class Initialized
INFO - 2024-12-06 18:53:45 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:45 --> Input Class Initialized
INFO - 2024-12-06 18:53:45 --> Language Class Initialized
ERROR - 2024-12-06 18:53:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:53:45 --> Config Class Initialized
INFO - 2024-12-06 18:53:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:45 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:45 --> URI Class Initialized
INFO - 2024-12-06 18:53:45 --> Router Class Initialized
INFO - 2024-12-06 18:53:45 --> Output Class Initialized
INFO - 2024-12-06 18:53:45 --> Security Class Initialized
INFO - 2024-12-06 18:53:45 --> Config Class Initialized
INFO - 2024-12-06 18:53:45 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:45 --> Input Class Initialized
INFO - 2024-12-06 18:53:45 --> Language Class Initialized
ERROR - 2024-12-06 18:53:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-06 18:53:45 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:53:45 --> Utf8 Class Initialized
INFO - 2024-12-06 18:53:45 --> URI Class Initialized
INFO - 2024-12-06 18:53:45 --> Router Class Initialized
INFO - 2024-12-06 18:53:45 --> Output Class Initialized
INFO - 2024-12-06 18:53:45 --> Security Class Initialized
DEBUG - 2024-12-06 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:53:45 --> Input Class Initialized
INFO - 2024-12-06 18:53:45 --> Language Class Initialized
ERROR - 2024-12-06 18:53:45 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:54:16 --> Config Class Initialized
INFO - 2024-12-06 18:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:16 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:16 --> Config Class Initialized
INFO - 2024-12-06 18:54:16 --> Hooks Class Initialized
INFO - 2024-12-06 18:54:16 --> URI Class Initialized
INFO - 2024-12-06 18:54:16 --> Router Class Initialized
DEBUG - 2024-12-06 18:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:16 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:16 --> URI Class Initialized
INFO - 2024-12-06 18:54:16 --> Output Class Initialized
INFO - 2024-12-06 18:54:16 --> Router Class Initialized
INFO - 2024-12-06 18:54:16 --> Security Class Initialized
INFO - 2024-12-06 18:54:16 --> Output Class Initialized
DEBUG - 2024-12-06 18:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:16 --> Input Class Initialized
INFO - 2024-12-06 18:54:16 --> Language Class Initialized
INFO - 2024-12-06 18:54:16 --> Security Class Initialized
ERROR - 2024-12-06 18:54:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-12-06 18:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:16 --> Input Class Initialized
INFO - 2024-12-06 18:54:16 --> Language Class Initialized
ERROR - 2024-12-06 18:54:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:18 --> Config Class Initialized
INFO - 2024-12-06 18:54:18 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:18 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:18 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:18 --> URI Class Initialized
INFO - 2024-12-06 18:54:18 --> Router Class Initialized
INFO - 2024-12-06 18:54:18 --> Output Class Initialized
INFO - 2024-12-06 18:54:18 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:18 --> Input Class Initialized
INFO - 2024-12-06 18:54:18 --> Language Class Initialized
ERROR - 2024-12-06 18:54:18 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:18 --> Config Class Initialized
INFO - 2024-12-06 18:54:18 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:18 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:18 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:18 --> URI Class Initialized
INFO - 2024-12-06 18:54:18 --> Router Class Initialized
INFO - 2024-12-06 18:54:18 --> Output Class Initialized
INFO - 2024-12-06 18:54:18 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:18 --> Input Class Initialized
INFO - 2024-12-06 18:54:18 --> Language Class Initialized
ERROR - 2024-12-06 18:54:18 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:19 --> Config Class Initialized
INFO - 2024-12-06 18:54:19 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:19 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:19 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:19 --> URI Class Initialized
INFO - 2024-12-06 18:54:19 --> Router Class Initialized
INFO - 2024-12-06 18:54:19 --> Output Class Initialized
INFO - 2024-12-06 18:54:19 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:19 --> Input Class Initialized
INFO - 2024-12-06 18:54:19 --> Language Class Initialized
ERROR - 2024-12-06 18:54:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:20 --> Config Class Initialized
INFO - 2024-12-06 18:54:20 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:20 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:20 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:20 --> URI Class Initialized
INFO - 2024-12-06 18:54:20 --> Router Class Initialized
INFO - 2024-12-06 18:54:20 --> Output Class Initialized
INFO - 2024-12-06 18:54:20 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:20 --> Input Class Initialized
INFO - 2024-12-06 18:54:20 --> Language Class Initialized
ERROR - 2024-12-06 18:54:20 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:47 --> Config Class Initialized
INFO - 2024-12-06 18:54:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:47 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:47 --> URI Class Initialized
INFO - 2024-12-06 18:54:47 --> Router Class Initialized
INFO - 2024-12-06 18:54:47 --> Output Class Initialized
INFO - 2024-12-06 18:54:47 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:47 --> Input Class Initialized
INFO - 2024-12-06 18:54:47 --> Language Class Initialized
ERROR - 2024-12-06 18:54:47 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-06 18:54:47 --> Config Class Initialized
INFO - 2024-12-06 18:54:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:47 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:47 --> URI Class Initialized
INFO - 2024-12-06 18:54:47 --> Router Class Initialized
INFO - 2024-12-06 18:54:47 --> Output Class Initialized
INFO - 2024-12-06 18:54:47 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:47 --> Input Class Initialized
INFO - 2024-12-06 18:54:47 --> Language Class Initialized
ERROR - 2024-12-06 18:54:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:47 --> Config Class Initialized
INFO - 2024-12-06 18:54:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:47 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:47 --> URI Class Initialized
INFO - 2024-12-06 18:54:47 --> Router Class Initialized
INFO - 2024-12-06 18:54:47 --> Output Class Initialized
INFO - 2024-12-06 18:54:47 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:47 --> Input Class Initialized
INFO - 2024-12-06 18:54:47 --> Language Class Initialized
ERROR - 2024-12-06 18:54:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:47 --> Config Class Initialized
INFO - 2024-12-06 18:54:47 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:47 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:47 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:47 --> URI Class Initialized
INFO - 2024-12-06 18:54:47 --> Router Class Initialized
INFO - 2024-12-06 18:54:47 --> Output Class Initialized
INFO - 2024-12-06 18:54:47 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:47 --> Input Class Initialized
INFO - 2024-12-06 18:54:47 --> Language Class Initialized
ERROR - 2024-12-06 18:54:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:48 --> Config Class Initialized
INFO - 2024-12-06 18:54:48 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:48 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:48 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:48 --> URI Class Initialized
INFO - 2024-12-06 18:54:48 --> Router Class Initialized
INFO - 2024-12-06 18:54:48 --> Output Class Initialized
INFO - 2024-12-06 18:54:48 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:48 --> Input Class Initialized
INFO - 2024-12-06 18:54:48 --> Language Class Initialized
ERROR - 2024-12-06 18:54:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-06 18:54:52 --> Config Class Initialized
INFO - 2024-12-06 18:54:52 --> Hooks Class Initialized
DEBUG - 2024-12-06 18:54:52 --> UTF-8 Support Enabled
INFO - 2024-12-06 18:54:52 --> Utf8 Class Initialized
INFO - 2024-12-06 18:54:52 --> URI Class Initialized
INFO - 2024-12-06 18:54:52 --> Router Class Initialized
INFO - 2024-12-06 18:54:52 --> Output Class Initialized
INFO - 2024-12-06 18:54:52 --> Security Class Initialized
DEBUG - 2024-12-06 18:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 18:54:52 --> Input Class Initialized
INFO - 2024-12-06 18:54:52 --> Language Class Initialized
ERROR - 2024-12-06 18:54:52 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
