<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-21 02:42:02 --> Config Class Initialized
INFO - 2024-11-21 02:42:02 --> Hooks Class Initialized
DEBUG - 2024-11-21 02:42:02 --> UTF-8 Support Enabled
INFO - 2024-11-21 02:42:02 --> Utf8 Class Initialized
INFO - 2024-11-21 02:42:02 --> URI Class Initialized
DEBUG - 2024-11-21 02:42:02 --> No URI present. Default controller set.
INFO - 2024-11-21 02:42:02 --> Router Class Initialized
INFO - 2024-11-21 02:42:02 --> Output Class Initialized
INFO - 2024-11-21 02:42:02 --> Security Class Initialized
DEBUG - 2024-11-21 02:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 02:42:02 --> Input Class Initialized
INFO - 2024-11-21 02:42:02 --> Language Class Initialized
INFO - 2024-11-21 02:42:02 --> Loader Class Initialized
INFO - 2024-11-21 02:42:02 --> Helper loaded: url_helper
INFO - 2024-11-21 02:42:02 --> Helper loaded: file_helper
INFO - 2024-11-21 02:42:02 --> Helper loaded: security_helper
INFO - 2024-11-21 02:42:02 --> Helper loaded: wpu_helper
INFO - 2024-11-21 02:42:02 --> Database Driver Class Initialized
INFO - 2024-11-21 02:42:03 --> Email Class Initialized
DEBUG - 2024-11-21 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 02:42:03 --> Helper loaded: form_helper
INFO - 2024-11-21 02:42:03 --> Form Validation Class Initialized
INFO - 2024-11-21 02:42:03 --> Controller Class Initialized
DEBUG - 2024-11-21 02:42:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 02:42:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 02:42:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 02:42:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 02:42:03 --> Final output sent to browser
DEBUG - 2024-11-21 02:42:03 --> Total execution time: 0.4346
INFO - 2024-11-21 02:42:07 --> Config Class Initialized
INFO - 2024-11-21 02:42:07 --> Hooks Class Initialized
DEBUG - 2024-11-21 02:42:07 --> UTF-8 Support Enabled
INFO - 2024-11-21 02:42:07 --> Utf8 Class Initialized
INFO - 2024-11-21 02:42:07 --> URI Class Initialized
DEBUG - 2024-11-21 02:42:07 --> No URI present. Default controller set.
INFO - 2024-11-21 02:42:07 --> Router Class Initialized
INFO - 2024-11-21 02:42:07 --> Output Class Initialized
INFO - 2024-11-21 02:42:07 --> Security Class Initialized
DEBUG - 2024-11-21 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 02:42:07 --> Input Class Initialized
INFO - 2024-11-21 02:42:07 --> Language Class Initialized
INFO - 2024-11-21 02:42:07 --> Loader Class Initialized
INFO - 2024-11-21 02:42:07 --> Helper loaded: url_helper
INFO - 2024-11-21 02:42:07 --> Helper loaded: file_helper
INFO - 2024-11-21 02:42:07 --> Helper loaded: security_helper
INFO - 2024-11-21 02:42:07 --> Helper loaded: wpu_helper
INFO - 2024-11-21 02:42:07 --> Database Driver Class Initialized
INFO - 2024-11-21 02:42:08 --> Email Class Initialized
DEBUG - 2024-11-21 02:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 02:42:08 --> Helper loaded: form_helper
INFO - 2024-11-21 02:42:08 --> Form Validation Class Initialized
INFO - 2024-11-21 02:42:08 --> Controller Class Initialized
DEBUG - 2024-11-21 02:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 02:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 02:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 02:42:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 02:42:08 --> Final output sent to browser
DEBUG - 2024-11-21 02:42:08 --> Total execution time: 0.4765
INFO - 2024-11-21 03:03:19 --> Config Class Initialized
INFO - 2024-11-21 03:03:19 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:03:19 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:03:19 --> Utf8 Class Initialized
INFO - 2024-11-21 03:03:19 --> URI Class Initialized
DEBUG - 2024-11-21 03:03:19 --> No URI present. Default controller set.
INFO - 2024-11-21 03:03:19 --> Router Class Initialized
INFO - 2024-11-21 03:03:19 --> Output Class Initialized
INFO - 2024-11-21 03:03:19 --> Security Class Initialized
DEBUG - 2024-11-21 03:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:03:19 --> Input Class Initialized
INFO - 2024-11-21 03:03:19 --> Language Class Initialized
INFO - 2024-11-21 03:03:19 --> Loader Class Initialized
INFO - 2024-11-21 03:03:19 --> Helper loaded: url_helper
INFO - 2024-11-21 03:03:19 --> Helper loaded: file_helper
INFO - 2024-11-21 03:03:19 --> Helper loaded: security_helper
INFO - 2024-11-21 03:03:19 --> Helper loaded: wpu_helper
INFO - 2024-11-21 03:03:19 --> Database Driver Class Initialized
INFO - 2024-11-21 03:03:20 --> Email Class Initialized
DEBUG - 2024-11-21 03:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 03:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:03:20 --> Helper loaded: form_helper
INFO - 2024-11-21 03:03:20 --> Form Validation Class Initialized
INFO - 2024-11-21 03:03:20 --> Controller Class Initialized
DEBUG - 2024-11-21 03:03:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 03:03:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 03:03:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 03:03:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 03:03:20 --> Final output sent to browser
DEBUG - 2024-11-21 03:03:20 --> Total execution time: 0.4221
INFO - 2024-11-21 03:03:30 --> Config Class Initialized
INFO - 2024-11-21 03:03:30 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:03:30 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:03:30 --> Utf8 Class Initialized
INFO - 2024-11-21 03:03:30 --> URI Class Initialized
DEBUG - 2024-11-21 03:03:30 --> No URI present. Default controller set.
INFO - 2024-11-21 03:03:30 --> Router Class Initialized
INFO - 2024-11-21 03:03:30 --> Output Class Initialized
INFO - 2024-11-21 03:03:30 --> Security Class Initialized
DEBUG - 2024-11-21 03:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:03:30 --> Input Class Initialized
INFO - 2024-11-21 03:03:30 --> Language Class Initialized
INFO - 2024-11-21 03:03:30 --> Loader Class Initialized
INFO - 2024-11-21 03:03:30 --> Helper loaded: url_helper
INFO - 2024-11-21 03:03:30 --> Helper loaded: file_helper
INFO - 2024-11-21 03:03:30 --> Helper loaded: security_helper
INFO - 2024-11-21 03:03:30 --> Helper loaded: wpu_helper
INFO - 2024-11-21 03:03:30 --> Database Driver Class Initialized
INFO - 2024-11-21 03:03:31 --> Email Class Initialized
DEBUG - 2024-11-21 03:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 03:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:03:31 --> Helper loaded: form_helper
INFO - 2024-11-21 03:03:31 --> Form Validation Class Initialized
INFO - 2024-11-21 03:03:31 --> Controller Class Initialized
DEBUG - 2024-11-21 03:03:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 03:03:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 03:03:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 03:03:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 03:03:31 --> Final output sent to browser
DEBUG - 2024-11-21 03:03:31 --> Total execution time: 0.4426
INFO - 2024-11-21 03:03:39 --> Config Class Initialized
INFO - 2024-11-21 03:03:39 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:03:39 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:03:39 --> Utf8 Class Initialized
INFO - 2024-11-21 03:03:39 --> URI Class Initialized
DEBUG - 2024-11-21 03:03:39 --> No URI present. Default controller set.
INFO - 2024-11-21 03:03:39 --> Router Class Initialized
INFO - 2024-11-21 03:03:39 --> Output Class Initialized
INFO - 2024-11-21 03:03:39 --> Security Class Initialized
DEBUG - 2024-11-21 03:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:03:39 --> Input Class Initialized
INFO - 2024-11-21 03:03:39 --> Language Class Initialized
INFO - 2024-11-21 03:03:39 --> Loader Class Initialized
INFO - 2024-11-21 03:03:39 --> Helper loaded: url_helper
INFO - 2024-11-21 03:03:39 --> Helper loaded: file_helper
INFO - 2024-11-21 03:03:39 --> Helper loaded: security_helper
INFO - 2024-11-21 03:03:39 --> Helper loaded: wpu_helper
INFO - 2024-11-21 03:03:39 --> Database Driver Class Initialized
INFO - 2024-11-21 03:03:39 --> Email Class Initialized
DEBUG - 2024-11-21 03:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 03:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:03:39 --> Helper loaded: form_helper
INFO - 2024-11-21 03:03:39 --> Form Validation Class Initialized
INFO - 2024-11-21 03:03:39 --> Controller Class Initialized
DEBUG - 2024-11-21 03:03:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 03:03:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 03:03:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 03:03:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 03:03:39 --> Final output sent to browser
DEBUG - 2024-11-21 03:03:39 --> Total execution time: 0.5066
INFO - 2024-11-21 08:04:57 --> Config Class Initialized
INFO - 2024-11-21 08:04:57 --> Hooks Class Initialized
DEBUG - 2024-11-21 08:04:57 --> UTF-8 Support Enabled
INFO - 2024-11-21 08:04:57 --> Utf8 Class Initialized
INFO - 2024-11-21 08:04:57 --> URI Class Initialized
DEBUG - 2024-11-21 08:04:57 --> No URI present. Default controller set.
INFO - 2024-11-21 08:04:57 --> Router Class Initialized
INFO - 2024-11-21 08:04:57 --> Output Class Initialized
INFO - 2024-11-21 08:04:57 --> Security Class Initialized
DEBUG - 2024-11-21 08:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 08:04:57 --> Input Class Initialized
INFO - 2024-11-21 08:04:57 --> Language Class Initialized
INFO - 2024-11-21 08:04:57 --> Loader Class Initialized
INFO - 2024-11-21 08:04:57 --> Helper loaded: url_helper
INFO - 2024-11-21 08:04:57 --> Helper loaded: file_helper
INFO - 2024-11-21 08:04:57 --> Helper loaded: security_helper
INFO - 2024-11-21 08:04:57 --> Helper loaded: wpu_helper
INFO - 2024-11-21 08:04:57 --> Database Driver Class Initialized
INFO - 2024-11-21 08:04:57 --> Email Class Initialized
DEBUG - 2024-11-21 08:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-21 08:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 08:04:57 --> Helper loaded: form_helper
INFO - 2024-11-21 08:04:57 --> Form Validation Class Initialized
INFO - 2024-11-21 08:04:57 --> Controller Class Initialized
DEBUG - 2024-11-21 08:04:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-21 08:04:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-21 08:04:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-21 08:04:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-21 08:04:57 --> Final output sent to browser
DEBUG - 2024-11-21 08:04:57 --> Total execution time: 0.4378
