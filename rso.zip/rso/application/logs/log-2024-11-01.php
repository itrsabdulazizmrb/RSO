<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-01 00:55:34 --> Config Class Initialized
INFO - 2024-11-01 00:55:34 --> Hooks Class Initialized
DEBUG - 2024-11-01 00:55:34 --> UTF-8 Support Enabled
INFO - 2024-11-01 00:55:34 --> Utf8 Class Initialized
INFO - 2024-11-01 00:55:34 --> URI Class Initialized
DEBUG - 2024-11-01 00:55:34 --> No URI present. Default controller set.
INFO - 2024-11-01 00:55:34 --> Router Class Initialized
INFO - 2024-11-01 00:55:34 --> Output Class Initialized
INFO - 2024-11-01 00:55:34 --> Security Class Initialized
DEBUG - 2024-11-01 00:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 00:55:34 --> Input Class Initialized
INFO - 2024-11-01 00:55:34 --> Language Class Initialized
INFO - 2024-11-01 00:55:34 --> Loader Class Initialized
INFO - 2024-11-01 00:55:34 --> Helper loaded: url_helper
INFO - 2024-11-01 00:55:34 --> Helper loaded: file_helper
INFO - 2024-11-01 00:55:34 --> Helper loaded: security_helper
INFO - 2024-11-01 00:55:34 --> Helper loaded: wpu_helper
INFO - 2024-11-01 00:55:34 --> Database Driver Class Initialized
ERROR - 2024-11-01 00:55:41 --> Unable to connect to the database
INFO - 2024-11-01 00:55:41 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-01 07:03:22 --> Config Class Initialized
INFO - 2024-11-01 07:03:22 --> Hooks Class Initialized
DEBUG - 2024-11-01 07:03:22 --> UTF-8 Support Enabled
INFO - 2024-11-01 07:03:22 --> Utf8 Class Initialized
INFO - 2024-11-01 07:03:22 --> URI Class Initialized
DEBUG - 2024-11-01 07:03:22 --> No URI present. Default controller set.
INFO - 2024-11-01 07:03:22 --> Router Class Initialized
INFO - 2024-11-01 07:03:22 --> Output Class Initialized
INFO - 2024-11-01 07:03:22 --> Security Class Initialized
DEBUG - 2024-11-01 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 07:03:22 --> Input Class Initialized
INFO - 2024-11-01 07:03:22 --> Language Class Initialized
INFO - 2024-11-01 07:03:22 --> Loader Class Initialized
INFO - 2024-11-01 07:03:22 --> Helper loaded: url_helper
INFO - 2024-11-01 07:03:22 --> Helper loaded: file_helper
INFO - 2024-11-01 07:03:22 --> Helper loaded: security_helper
INFO - 2024-11-01 07:03:22 --> Helper loaded: wpu_helper
INFO - 2024-11-01 07:03:22 --> Database Driver Class Initialized
ERROR - 2024-11-01 07:03:30 --> Unable to connect to the database
INFO - 2024-11-01 07:03:30 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-01 07:07:09 --> Config Class Initialized
INFO - 2024-11-01 07:07:09 --> Hooks Class Initialized
DEBUG - 2024-11-01 07:07:09 --> UTF-8 Support Enabled
INFO - 2024-11-01 07:07:09 --> Utf8 Class Initialized
INFO - 2024-11-01 07:07:09 --> URI Class Initialized
DEBUG - 2024-11-01 07:07:09 --> No URI present. Default controller set.
INFO - 2024-11-01 07:07:09 --> Router Class Initialized
INFO - 2024-11-01 07:07:09 --> Output Class Initialized
INFO - 2024-11-01 07:07:09 --> Security Class Initialized
DEBUG - 2024-11-01 07:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 07:07:09 --> Input Class Initialized
INFO - 2024-11-01 07:07:09 --> Language Class Initialized
INFO - 2024-11-01 07:07:09 --> Loader Class Initialized
INFO - 2024-11-01 07:07:09 --> Helper loaded: url_helper
INFO - 2024-11-01 07:07:09 --> Helper loaded: file_helper
INFO - 2024-11-01 07:07:09 --> Helper loaded: security_helper
INFO - 2024-11-01 07:07:09 --> Helper loaded: wpu_helper
INFO - 2024-11-01 07:07:09 --> Database Driver Class Initialized
ERROR - 2024-11-01 07:07:16 --> Unable to connect to the database
INFO - 2024-11-01 07:07:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-01 08:31:49 --> Config Class Initialized
INFO - 2024-11-01 08:31:49 --> Hooks Class Initialized
DEBUG - 2024-11-01 08:31:49 --> UTF-8 Support Enabled
INFO - 2024-11-01 08:31:49 --> Utf8 Class Initialized
INFO - 2024-11-01 08:31:49 --> URI Class Initialized
DEBUG - 2024-11-01 08:31:49 --> No URI present. Default controller set.
INFO - 2024-11-01 08:31:49 --> Router Class Initialized
INFO - 2024-11-01 08:31:49 --> Output Class Initialized
INFO - 2024-11-01 08:31:49 --> Security Class Initialized
DEBUG - 2024-11-01 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 08:31:49 --> Input Class Initialized
INFO - 2024-11-01 08:31:49 --> Language Class Initialized
INFO - 2024-11-01 08:31:49 --> Loader Class Initialized
INFO - 2024-11-01 08:31:49 --> Helper loaded: url_helper
INFO - 2024-11-01 08:31:49 --> Helper loaded: file_helper
INFO - 2024-11-01 08:31:49 --> Helper loaded: security_helper
INFO - 2024-11-01 08:31:49 --> Helper loaded: wpu_helper
INFO - 2024-11-01 08:31:49 --> Database Driver Class Initialized
ERROR - 2024-11-01 08:31:56 --> Unable to connect to the database
INFO - 2024-11-01 08:31:56 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-01 20:29:26 --> Config Class Initialized
INFO - 2024-11-01 20:29:26 --> Hooks Class Initialized
DEBUG - 2024-11-01 20:29:26 --> UTF-8 Support Enabled
INFO - 2024-11-01 20:29:26 --> Utf8 Class Initialized
INFO - 2024-11-01 20:29:26 --> URI Class Initialized
DEBUG - 2024-11-01 20:29:26 --> No URI present. Default controller set.
INFO - 2024-11-01 20:29:26 --> Router Class Initialized
INFO - 2024-11-01 20:29:26 --> Output Class Initialized
INFO - 2024-11-01 20:29:26 --> Security Class Initialized
DEBUG - 2024-11-01 20:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 20:29:26 --> Input Class Initialized
INFO - 2024-11-01 20:29:26 --> Language Class Initialized
INFO - 2024-11-01 20:29:26 --> Loader Class Initialized
INFO - 2024-11-01 20:29:26 --> Helper loaded: url_helper
INFO - 2024-11-01 20:29:26 --> Helper loaded: file_helper
INFO - 2024-11-01 20:29:26 --> Helper loaded: security_helper
INFO - 2024-11-01 20:29:26 --> Helper loaded: wpu_helper
INFO - 2024-11-01 20:29:26 --> Database Driver Class Initialized
ERROR - 2024-11-01 20:29:33 --> Unable to connect to the database
INFO - 2024-11-01 20:29:33 --> Language file loaded: language/english/db_lang.php
