<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-03 02:24:43 --> Config Class Initialized
INFO - 2024-12-03 02:24:43 --> Hooks Class Initialized
DEBUG - 2024-12-03 02:24:43 --> UTF-8 Support Enabled
INFO - 2024-12-03 02:24:43 --> Utf8 Class Initialized
INFO - 2024-12-03 02:24:43 --> URI Class Initialized
DEBUG - 2024-12-03 02:24:43 --> No URI present. Default controller set.
INFO - 2024-12-03 02:24:43 --> Router Class Initialized
INFO - 2024-12-03 02:24:43 --> Output Class Initialized
INFO - 2024-12-03 02:24:43 --> Security Class Initialized
DEBUG - 2024-12-03 02:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 02:24:43 --> Input Class Initialized
INFO - 2024-12-03 02:24:43 --> Language Class Initialized
INFO - 2024-12-03 02:24:43 --> Loader Class Initialized
INFO - 2024-12-03 02:24:43 --> Helper loaded: url_helper
INFO - 2024-12-03 02:24:43 --> Helper loaded: file_helper
INFO - 2024-12-03 02:24:43 --> Helper loaded: security_helper
INFO - 2024-12-03 02:24:43 --> Helper loaded: wpu_helper
INFO - 2024-12-03 02:24:43 --> Database Driver Class Initialized
INFO - 2024-12-03 02:24:44 --> Email Class Initialized
DEBUG - 2024-12-03 02:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 02:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 02:24:44 --> Helper loaded: form_helper
INFO - 2024-12-03 02:24:44 --> Form Validation Class Initialized
INFO - 2024-12-03 02:24:44 --> Controller Class Initialized
DEBUG - 2024-12-03 02:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 02:24:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 02:24:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 02:24:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 02:24:44 --> Final output sent to browser
DEBUG - 2024-12-03 02:24:44 --> Total execution time: 0.4300
INFO - 2024-12-03 02:24:46 --> Config Class Initialized
INFO - 2024-12-03 02:24:46 --> Hooks Class Initialized
DEBUG - 2024-12-03 02:24:46 --> UTF-8 Support Enabled
INFO - 2024-12-03 02:24:46 --> Utf8 Class Initialized
INFO - 2024-12-03 02:24:46 --> URI Class Initialized
INFO - 2024-12-03 02:24:46 --> Router Class Initialized
INFO - 2024-12-03 02:24:46 --> Output Class Initialized
INFO - 2024-12-03 02:24:46 --> Security Class Initialized
DEBUG - 2024-12-03 02:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 02:24:46 --> Input Class Initialized
INFO - 2024-12-03 02:24:46 --> Language Class Initialized
INFO - 2024-12-03 02:24:46 --> Loader Class Initialized
INFO - 2024-12-03 02:24:46 --> Helper loaded: url_helper
INFO - 2024-12-03 02:24:46 --> Helper loaded: file_helper
INFO - 2024-12-03 02:24:46 --> Helper loaded: security_helper
INFO - 2024-12-03 02:24:46 --> Helper loaded: wpu_helper
INFO - 2024-12-03 02:24:46 --> Database Driver Class Initialized
INFO - 2024-12-03 02:24:47 --> Email Class Initialized
DEBUG - 2024-12-03 02:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 02:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 02:24:47 --> Helper loaded: form_helper
INFO - 2024-12-03 02:24:47 --> Form Validation Class Initialized
INFO - 2024-12-03 02:24:47 --> Controller Class Initialized
DEBUG - 2024-12-03 02:24:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 02:24:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-03 02:24:48 --> Config Class Initialized
INFO - 2024-12-03 02:24:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 02:24:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 02:24:48 --> Utf8 Class Initialized
INFO - 2024-12-03 02:24:48 --> URI Class Initialized
INFO - 2024-12-03 02:24:48 --> Router Class Initialized
INFO - 2024-12-03 02:24:48 --> Output Class Initialized
INFO - 2024-12-03 02:24:48 --> Security Class Initialized
DEBUG - 2024-12-03 02:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 02:24:48 --> Input Class Initialized
INFO - 2024-12-03 02:24:48 --> Language Class Initialized
INFO - 2024-12-03 02:24:48 --> Loader Class Initialized
INFO - 2024-12-03 02:24:48 --> Helper loaded: url_helper
INFO - 2024-12-03 02:24:48 --> Helper loaded: file_helper
INFO - 2024-12-03 02:24:48 --> Helper loaded: security_helper
INFO - 2024-12-03 02:24:48 --> Helper loaded: wpu_helper
INFO - 2024-12-03 02:24:48 --> Database Driver Class Initialized
INFO - 2024-12-03 02:24:48 --> Email Class Initialized
DEBUG - 2024-12-03 02:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 02:24:48 --> Helper loaded: form_helper
INFO - 2024-12-03 02:24:48 --> Form Validation Class Initialized
INFO - 2024-12-03 02:24:48 --> Controller Class Initialized
INFO - 2024-12-03 02:24:48 --> Model "Antrol_model" initialized
DEBUG - 2024-12-03 02:24:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 02:24:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-03 02:24:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-03 02:24:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-03 02:24:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-03 02:24:49 --> Final output sent to browser
DEBUG - 2024-12-03 02:24:49 --> Total execution time: 0.9925
INFO - 2024-12-03 06:06:38 --> Config Class Initialized
INFO - 2024-12-03 06:06:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:06:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:06:38 --> Utf8 Class Initialized
INFO - 2024-12-03 06:06:38 --> URI Class Initialized
DEBUG - 2024-12-03 06:06:38 --> No URI present. Default controller set.
INFO - 2024-12-03 06:06:38 --> Router Class Initialized
INFO - 2024-12-03 06:06:38 --> Config Class Initialized
INFO - 2024-12-03 06:06:38 --> Hooks Class Initialized
INFO - 2024-12-03 06:06:38 --> Output Class Initialized
DEBUG - 2024-12-03 06:06:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:06:38 --> Utf8 Class Initialized
INFO - 2024-12-03 06:06:38 --> Security Class Initialized
INFO - 2024-12-03 06:06:38 --> URI Class Initialized
DEBUG - 2024-12-03 06:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-03 06:06:38 --> No URI present. Default controller set.
INFO - 2024-12-03 06:06:38 --> Router Class Initialized
INFO - 2024-12-03 06:06:38 --> Output Class Initialized
INFO - 2024-12-03 06:06:38 --> Input Class Initialized
INFO - 2024-12-03 06:06:38 --> Security Class Initialized
INFO - 2024-12-03 06:06:38 --> Language Class Initialized
DEBUG - 2024-12-03 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:06:38 --> Input Class Initialized
INFO - 2024-12-03 06:06:38 --> Language Class Initialized
INFO - 2024-12-03 06:06:38 --> Loader Class Initialized
INFO - 2024-12-03 06:06:38 --> Helper loaded: url_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: file_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: security_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:06:38 --> Database Driver Class Initialized
INFO - 2024-12-03 06:06:38 --> Loader Class Initialized
INFO - 2024-12-03 06:06:38 --> Helper loaded: url_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: file_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: security_helper
INFO - 2024-12-03 06:06:38 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:06:38 --> Database Driver Class Initialized
INFO - 2024-12-03 06:06:39 --> Email Class Initialized
DEBUG - 2024-12-03 06:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:06:39 --> Helper loaded: form_helper
INFO - 2024-12-03 06:06:39 --> Form Validation Class Initialized
INFO - 2024-12-03 06:06:39 --> Controller Class Initialized
DEBUG - 2024-12-03 06:06:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:06:39 --> Final output sent to browser
DEBUG - 2024-12-03 06:06:39 --> Total execution time: 0.4335
INFO - 2024-12-03 06:06:39 --> Email Class Initialized
DEBUG - 2024-12-03 06:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:06:39 --> Helper loaded: form_helper
INFO - 2024-12-03 06:06:39 --> Form Validation Class Initialized
INFO - 2024-12-03 06:06:39 --> Controller Class Initialized
DEBUG - 2024-12-03 06:06:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:06:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:06:39 --> Final output sent to browser
DEBUG - 2024-12-03 06:06:39 --> Total execution time: 0.4791
INFO - 2024-12-03 06:06:39 --> Config Class Initialized
INFO - 2024-12-03 06:06:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:06:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:06:39 --> Utf8 Class Initialized
INFO - 2024-12-03 06:06:39 --> URI Class Initialized
DEBUG - 2024-12-03 06:06:39 --> No URI present. Default controller set.
INFO - 2024-12-03 06:06:39 --> Router Class Initialized
INFO - 2024-12-03 06:06:39 --> Output Class Initialized
INFO - 2024-12-03 06:06:39 --> Security Class Initialized
DEBUG - 2024-12-03 06:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:06:39 --> Input Class Initialized
INFO - 2024-12-03 06:06:39 --> Language Class Initialized
INFO - 2024-12-03 06:06:39 --> Loader Class Initialized
INFO - 2024-12-03 06:06:39 --> Helper loaded: url_helper
INFO - 2024-12-03 06:06:39 --> Helper loaded: file_helper
INFO - 2024-12-03 06:06:39 --> Helper loaded: security_helper
INFO - 2024-12-03 06:06:39 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:06:39 --> Database Driver Class Initialized
INFO - 2024-12-03 06:06:40 --> Config Class Initialized
INFO - 2024-12-03 06:06:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:06:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:06:40 --> Utf8 Class Initialized
INFO - 2024-12-03 06:06:40 --> URI Class Initialized
DEBUG - 2024-12-03 06:06:40 --> No URI present. Default controller set.
INFO - 2024-12-03 06:06:40 --> Router Class Initialized
INFO - 2024-12-03 06:06:40 --> Output Class Initialized
INFO - 2024-12-03 06:06:40 --> Security Class Initialized
DEBUG - 2024-12-03 06:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:06:40 --> Input Class Initialized
INFO - 2024-12-03 06:06:40 --> Language Class Initialized
INFO - 2024-12-03 06:06:40 --> Loader Class Initialized
INFO - 2024-12-03 06:06:40 --> Helper loaded: url_helper
INFO - 2024-12-03 06:06:40 --> Helper loaded: file_helper
INFO - 2024-12-03 06:06:40 --> Helper loaded: security_helper
INFO - 2024-12-03 06:06:40 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:06:40 --> Database Driver Class Initialized
INFO - 2024-12-03 06:06:40 --> Email Class Initialized
DEBUG - 2024-12-03 06:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:06:40 --> Helper loaded: form_helper
INFO - 2024-12-03 06:06:40 --> Form Validation Class Initialized
INFO - 2024-12-03 06:06:40 --> Controller Class Initialized
DEBUG - 2024-12-03 06:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:06:40 --> Final output sent to browser
DEBUG - 2024-12-03 06:06:40 --> Total execution time: 0.4413
INFO - 2024-12-03 06:06:40 --> Email Class Initialized
DEBUG - 2024-12-03 06:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:06:40 --> Helper loaded: form_helper
INFO - 2024-12-03 06:06:40 --> Form Validation Class Initialized
INFO - 2024-12-03 06:06:40 --> Controller Class Initialized
DEBUG - 2024-12-03 06:06:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:06:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:06:40 --> Final output sent to browser
DEBUG - 2024-12-03 06:06:40 --> Total execution time: 0.4249
INFO - 2024-12-03 06:07:52 --> Config Class Initialized
INFO - 2024-12-03 06:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:52 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:52 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:52 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:52 --> Router Class Initialized
INFO - 2024-12-03 06:07:52 --> Output Class Initialized
INFO - 2024-12-03 06:07:52 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:52 --> Input Class Initialized
INFO - 2024-12-03 06:07:52 --> Language Class Initialized
INFO - 2024-12-03 06:07:52 --> Loader Class Initialized
INFO - 2024-12-03 06:07:52 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:52 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:52 --> Config Class Initialized
INFO - 2024-12-03 06:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:52 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:52 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:52 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:52 --> Router Class Initialized
INFO - 2024-12-03 06:07:52 --> Output Class Initialized
INFO - 2024-12-03 06:07:52 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:52 --> Input Class Initialized
INFO - 2024-12-03 06:07:52 --> Language Class Initialized
INFO - 2024-12-03 06:07:52 --> Loader Class Initialized
INFO - 2024-12-03 06:07:52 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:52 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:52 --> Config Class Initialized
INFO - 2024-12-03 06:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:52 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:52 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:52 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:52 --> Router Class Initialized
INFO - 2024-12-03 06:07:52 --> Output Class Initialized
INFO - 2024-12-03 06:07:52 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:52 --> Input Class Initialized
INFO - 2024-12-03 06:07:52 --> Language Class Initialized
INFO - 2024-12-03 06:07:52 --> Loader Class Initialized
INFO - 2024-12-03 06:07:52 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:52 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:52 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:52 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:52 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:52 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:52 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:52 --> Total execution time: 0.4501
INFO - 2024-12-03 06:07:52 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:52 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:52 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:52 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:52 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:52 --> Total execution time: 0.4394
INFO - 2024-12-03 06:07:52 --> Config Class Initialized
INFO - 2024-12-03 06:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:52 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:52 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:52 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:52 --> Router Class Initialized
INFO - 2024-12-03 06:07:52 --> Output Class Initialized
INFO - 2024-12-03 06:07:52 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:52 --> Input Class Initialized
INFO - 2024-12-03 06:07:52 --> Language Class Initialized
INFO - 2024-12-03 06:07:52 --> Loader Class Initialized
INFO - 2024-12-03 06:07:52 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:52 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:52 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:52 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:52 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:52 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:52 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:52 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:52 --> Total execution time: 0.4389
INFO - 2024-12-03 06:07:53 --> Config Class Initialized
INFO - 2024-12-03 06:07:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:53 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:53 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:53 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:53 --> Router Class Initialized
INFO - 2024-12-03 06:07:53 --> Output Class Initialized
INFO - 2024-12-03 06:07:53 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:53 --> Input Class Initialized
INFO - 2024-12-03 06:07:53 --> Language Class Initialized
INFO - 2024-12-03 06:07:53 --> Loader Class Initialized
INFO - 2024-12-03 06:07:53 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:53 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:53 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:53 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:53 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:53 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:53 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:53 --> Total execution time: 0.4295
INFO - 2024-12-03 06:07:53 --> Config Class Initialized
INFO - 2024-12-03 06:07:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:53 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:53 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:53 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:53 --> Router Class Initialized
INFO - 2024-12-03 06:07:53 --> Output Class Initialized
INFO - 2024-12-03 06:07:53 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:53 --> Input Class Initialized
INFO - 2024-12-03 06:07:53 --> Language Class Initialized
INFO - 2024-12-03 06:07:53 --> Loader Class Initialized
INFO - 2024-12-03 06:07:53 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:53 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:53 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:53 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:53 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:53 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:53 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:53 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:53 --> Total execution time: 0.4658
INFO - 2024-12-03 06:07:53 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:53 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:53 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:53 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:53 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:53 --> Total execution time: 0.4623
INFO - 2024-12-03 06:07:53 --> Config Class Initialized
INFO - 2024-12-03 06:07:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:54 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:54 --> URI Class Initialized
INFO - 2024-12-03 06:07:54 --> Router Class Initialized
INFO - 2024-12-03 06:07:54 --> Output Class Initialized
INFO - 2024-12-03 06:07:54 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:54 --> Input Class Initialized
INFO - 2024-12-03 06:07:54 --> Language Class Initialized
ERROR - 2024-12-03 06:07:54 --> 404 Page Not Found: Server/index
INFO - 2024-12-03 06:07:54 --> Config Class Initialized
INFO - 2024-12-03 06:07:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:54 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:54 --> URI Class Initialized
INFO - 2024-12-03 06:07:54 --> Router Class Initialized
INFO - 2024-12-03 06:07:54 --> Output Class Initialized
INFO - 2024-12-03 06:07:54 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:54 --> Input Class Initialized
INFO - 2024-12-03 06:07:54 --> Language Class Initialized
ERROR - 2024-12-03 06:07:54 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2024-12-03 06:07:54 --> Config Class Initialized
INFO - 2024-12-03 06:07:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:54 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:54 --> URI Class Initialized
INFO - 2024-12-03 06:07:54 --> Router Class Initialized
INFO - 2024-12-03 06:07:54 --> Output Class Initialized
INFO - 2024-12-03 06:07:54 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:54 --> Input Class Initialized
INFO - 2024-12-03 06:07:54 --> Language Class Initialized
ERROR - 2024-12-03 06:07:54 --> 404 Page Not Found: Server/index
INFO - 2024-12-03 06:07:54 --> Config Class Initialized
INFO - 2024-12-03 06:07:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:54 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:54 --> URI Class Initialized
INFO - 2024-12-03 06:07:54 --> Router Class Initialized
INFO - 2024-12-03 06:07:54 --> Output Class Initialized
INFO - 2024-12-03 06:07:54 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:54 --> Input Class Initialized
INFO - 2024-12-03 06:07:54 --> Language Class Initialized
ERROR - 2024-12-03 06:07:54 --> 404 Page Not Found: About/index
INFO - 2024-12-03 06:07:55 --> Config Class Initialized
INFO - 2024-12-03 06:07:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:55 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:55 --> URI Class Initialized
INFO - 2024-12-03 06:07:55 --> Router Class Initialized
INFO - 2024-12-03 06:07:55 --> Output Class Initialized
INFO - 2024-12-03 06:07:55 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:55 --> Input Class Initialized
INFO - 2024-12-03 06:07:55 --> Language Class Initialized
ERROR - 2024-12-03 06:07:55 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2024-12-03 06:07:55 --> Config Class Initialized
INFO - 2024-12-03 06:07:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:55 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:55 --> URI Class Initialized
INFO - 2024-12-03 06:07:55 --> Router Class Initialized
INFO - 2024-12-03 06:07:55 --> Output Class Initialized
INFO - 2024-12-03 06:07:55 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:55 --> Input Class Initialized
INFO - 2024-12-03 06:07:55 --> Language Class Initialized
ERROR - 2024-12-03 06:07:55 --> 404 Page Not Found: Debug/default
INFO - 2024-12-03 06:07:55 --> Config Class Initialized
INFO - 2024-12-03 06:07:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:55 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:55 --> URI Class Initialized
INFO - 2024-12-03 06:07:55 --> Router Class Initialized
INFO - 2024-12-03 06:07:55 --> Output Class Initialized
INFO - 2024-12-03 06:07:55 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:55 --> Input Class Initialized
INFO - 2024-12-03 06:07:55 --> Language Class Initialized
ERROR - 2024-12-03 06:07:55 --> 404 Page Not Found: About/index
INFO - 2024-12-03 06:07:55 --> Config Class Initialized
INFO - 2024-12-03 06:07:55 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:55 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:55 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:55 --> URI Class Initialized
INFO - 2024-12-03 06:07:55 --> Router Class Initialized
INFO - 2024-12-03 06:07:55 --> Output Class Initialized
INFO - 2024-12-03 06:07:55 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:55 --> Input Class Initialized
INFO - 2024-12-03 06:07:55 --> Language Class Initialized
ERROR - 2024-12-03 06:07:55 --> 404 Page Not Found: V2/_catalog
INFO - 2024-12-03 06:07:56 --> Config Class Initialized
INFO - 2024-12-03 06:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:56 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:56 --> URI Class Initialized
INFO - 2024-12-03 06:07:56 --> Router Class Initialized
INFO - 2024-12-03 06:07:56 --> Output Class Initialized
INFO - 2024-12-03 06:07:56 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:56 --> Input Class Initialized
INFO - 2024-12-03 06:07:56 --> Language Class Initialized
ERROR - 2024-12-03 06:07:56 --> 404 Page Not Found: Ecp/Current
INFO - 2024-12-03 06:07:56 --> Config Class Initialized
INFO - 2024-12-03 06:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:56 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:56 --> URI Class Initialized
INFO - 2024-12-03 06:07:56 --> Router Class Initialized
INFO - 2024-12-03 06:07:56 --> Output Class Initialized
INFO - 2024-12-03 06:07:56 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:56 --> Input Class Initialized
INFO - 2024-12-03 06:07:56 --> Language Class Initialized
ERROR - 2024-12-03 06:07:56 --> 404 Page Not Found: Debug/default
INFO - 2024-12-03 06:07:56 --> Config Class Initialized
INFO - 2024-12-03 06:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:56 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:56 --> URI Class Initialized
INFO - 2024-12-03 06:07:56 --> Router Class Initialized
INFO - 2024-12-03 06:07:56 --> Output Class Initialized
INFO - 2024-12-03 06:07:56 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:56 --> Input Class Initialized
INFO - 2024-12-03 06:07:56 --> Language Class Initialized
ERROR - 2024-12-03 06:07:56 --> 404 Page Not Found: Server-status/index
INFO - 2024-12-03 06:07:56 --> Config Class Initialized
INFO - 2024-12-03 06:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:56 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:56 --> URI Class Initialized
INFO - 2024-12-03 06:07:56 --> Router Class Initialized
INFO - 2024-12-03 06:07:56 --> Output Class Initialized
INFO - 2024-12-03 06:07:56 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:56 --> Input Class Initialized
INFO - 2024-12-03 06:07:56 --> Language Class Initialized
ERROR - 2024-12-03 06:07:56 --> 404 Page Not Found: V2/_catalog
INFO - 2024-12-03 06:07:57 --> Config Class Initialized
INFO - 2024-12-03 06:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:57 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:57 --> URI Class Initialized
DEBUG - 2024-12-03 06:07:57 --> No URI present. Default controller set.
INFO - 2024-12-03 06:07:57 --> Router Class Initialized
INFO - 2024-12-03 06:07:57 --> Output Class Initialized
INFO - 2024-12-03 06:07:57 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:57 --> Input Class Initialized
INFO - 2024-12-03 06:07:57 --> Language Class Initialized
INFO - 2024-12-03 06:07:57 --> Loader Class Initialized
INFO - 2024-12-03 06:07:57 --> Helper loaded: url_helper
INFO - 2024-12-03 06:07:57 --> Helper loaded: file_helper
INFO - 2024-12-03 06:07:57 --> Helper loaded: security_helper
INFO - 2024-12-03 06:07:57 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:07:57 --> Database Driver Class Initialized
INFO - 2024-12-03 06:07:57 --> Config Class Initialized
INFO - 2024-12-03 06:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:57 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:57 --> URI Class Initialized
INFO - 2024-12-03 06:07:57 --> Router Class Initialized
INFO - 2024-12-03 06:07:57 --> Output Class Initialized
INFO - 2024-12-03 06:07:57 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:57 --> Input Class Initialized
INFO - 2024-12-03 06:07:57 --> Language Class Initialized
ERROR - 2024-12-03 06:07:57 --> 404 Page Not Found: Loginaction/index
INFO - 2024-12-03 06:07:57 --> Email Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:07:57 --> Helper loaded: form_helper
INFO - 2024-12-03 06:07:57 --> Form Validation Class Initialized
INFO - 2024-12-03 06:07:57 --> Controller Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:07:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:07:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:07:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:07:57 --> Final output sent to browser
DEBUG - 2024-12-03 06:07:57 --> Total execution time: 0.4534
INFO - 2024-12-03 06:07:57 --> Config Class Initialized
INFO - 2024-12-03 06:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:57 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:57 --> URI Class Initialized
INFO - 2024-12-03 06:07:57 --> Router Class Initialized
INFO - 2024-12-03 06:07:57 --> Output Class Initialized
INFO - 2024-12-03 06:07:57 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:57 --> Input Class Initialized
INFO - 2024-12-03 06:07:57 --> Language Class Initialized
ERROR - 2024-12-03 06:07:57 --> 404 Page Not Found: Ecp/Current
INFO - 2024-12-03 06:07:57 --> Config Class Initialized
INFO - 2024-12-03 06:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:57 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:57 --> URI Class Initialized
INFO - 2024-12-03 06:07:57 --> Router Class Initialized
INFO - 2024-12-03 06:07:57 --> Output Class Initialized
INFO - 2024-12-03 06:07:57 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:57 --> Input Class Initialized
INFO - 2024-12-03 06:07:57 --> Language Class Initialized
ERROR - 2024-12-03 06:07:57 --> 404 Page Not Found: _all_dbs/index
INFO - 2024-12-03 06:07:58 --> Config Class Initialized
INFO - 2024-12-03 06:07:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:58 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:58 --> URI Class Initialized
INFO - 2024-12-03 06:07:58 --> Router Class Initialized
INFO - 2024-12-03 06:07:58 --> Output Class Initialized
INFO - 2024-12-03 06:07:58 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:58 --> Input Class Initialized
INFO - 2024-12-03 06:07:58 --> Language Class Initialized
ERROR - 2024-12-03 06:07:58 --> 404 Page Not Found: Server-status/index
INFO - 2024-12-03 06:07:58 --> Config Class Initialized
INFO - 2024-12-03 06:07:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:58 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:58 --> URI Class Initialized
INFO - 2024-12-03 06:07:58 --> Router Class Initialized
INFO - 2024-12-03 06:07:58 --> Output Class Initialized
INFO - 2024-12-03 06:07:58 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:58 --> Input Class Initialized
INFO - 2024-12-03 06:07:58 --> Language Class Initialized
ERROR - 2024-12-03 06:07:58 --> 404 Page Not Found: Server/index
INFO - 2024-12-03 06:07:58 --> Config Class Initialized
INFO - 2024-12-03 06:07:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:58 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:58 --> URI Class Initialized
INFO - 2024-12-03 06:07:58 --> Router Class Initialized
INFO - 2024-12-03 06:07:58 --> Output Class Initialized
INFO - 2024-12-03 06:07:58 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:58 --> Input Class Initialized
INFO - 2024-12-03 06:07:58 --> Language Class Initialized
ERROR - 2024-12-03 06:07:58 --> 404 Page Not Found: DS_Store/index
INFO - 2024-12-03 06:07:58 --> Config Class Initialized
INFO - 2024-12-03 06:07:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:58 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:58 --> URI Class Initialized
INFO - 2024-12-03 06:07:58 --> Router Class Initialized
INFO - 2024-12-03 06:07:58 --> Output Class Initialized
INFO - 2024-12-03 06:07:58 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:58 --> Input Class Initialized
INFO - 2024-12-03 06:07:58 --> Language Class Initialized
ERROR - 2024-12-03 06:07:58 --> 404 Page Not Found: Loginaction/index
INFO - 2024-12-03 06:07:58 --> Config Class Initialized
INFO - 2024-12-03 06:07:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:58 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:58 --> URI Class Initialized
INFO - 2024-12-03 06:07:58 --> Router Class Initialized
INFO - 2024-12-03 06:07:58 --> Output Class Initialized
INFO - 2024-12-03 06:07:58 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:58 --> Input Class Initialized
INFO - 2024-12-03 06:07:58 --> Language Class Initialized
ERROR - 2024-12-03 06:07:58 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2024-12-03 06:07:59 --> Config Class Initialized
INFO - 2024-12-03 06:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:59 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:59 --> URI Class Initialized
INFO - 2024-12-03 06:07:59 --> Router Class Initialized
INFO - 2024-12-03 06:07:59 --> Output Class Initialized
INFO - 2024-12-03 06:07:59 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:59 --> Input Class Initialized
INFO - 2024-12-03 06:07:59 --> Language Class Initialized
ERROR - 2024-12-03 06:07:59 --> 404 Page Not Found: _all_dbs/index
INFO - 2024-12-03 06:07:59 --> Config Class Initialized
INFO - 2024-12-03 06:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:59 --> Utf8 Class Initialized
INFO - 2024-12-03 06:07:59 --> URI Class Initialized
INFO - 2024-12-03 06:07:59 --> Router Class Initialized
INFO - 2024-12-03 06:07:59 --> Output Class Initialized
INFO - 2024-12-03 06:07:59 --> Security Class Initialized
DEBUG - 2024-12-03 06:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:07:59 --> Input Class Initialized
INFO - 2024-12-03 06:07:59 --> Language Class Initialized
ERROR - 2024-12-03 06:07:59 --> 404 Page Not Found: About/index
INFO - 2024-12-03 06:07:59 --> Config Class Initialized
INFO - 2024-12-03 06:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:07:59 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
DEBUG - 2024-12-03 06:08:00 --> No URI present. Default controller set.
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
INFO - 2024-12-03 06:08:00 --> Loader Class Initialized
INFO - 2024-12-03 06:08:00 --> Helper loaded: url_helper
INFO - 2024-12-03 06:08:00 --> Helper loaded: file_helper
INFO - 2024-12-03 06:08:00 --> Helper loaded: security_helper
INFO - 2024-12-03 06:08:00 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:08:00 --> Database Driver Class Initialized
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
ERROR - 2024-12-03 06:08:00 --> 404 Page Not Found: Configjson/index
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
ERROR - 2024-12-03 06:08:00 --> 404 Page Not Found: Debug/default
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
ERROR - 2024-12-03 06:08:00 --> 404 Page Not Found: DS_Store/index
INFO - 2024-12-03 06:08:00 --> Email Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:08:00 --> Helper loaded: form_helper
INFO - 2024-12-03 06:08:00 --> Form Validation Class Initialized
INFO - 2024-12-03 06:08:00 --> Controller Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:08:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:08:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:08:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:08:00 --> Final output sent to browser
DEBUG - 2024-12-03 06:08:00 --> Total execution time: 0.4414
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
ERROR - 2024-12-03 06:08:00 --> 404 Page Not Found: Telescope/requests
INFO - 2024-12-03 06:08:00 --> Config Class Initialized
INFO - 2024-12-03 06:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:00 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:00 --> URI Class Initialized
INFO - 2024-12-03 06:08:00 --> Router Class Initialized
INFO - 2024-12-03 06:08:00 --> Output Class Initialized
INFO - 2024-12-03 06:08:00 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:00 --> Input Class Initialized
INFO - 2024-12-03 06:08:00 --> Language Class Initialized
ERROR - 2024-12-03 06:08:00 --> 404 Page Not Found: V2/_catalog
INFO - 2024-12-03 06:08:01 --> Config Class Initialized
INFO - 2024-12-03 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:01 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:01 --> URI Class Initialized
DEBUG - 2024-12-03 06:08:01 --> No URI present. Default controller set.
INFO - 2024-12-03 06:08:01 --> Router Class Initialized
INFO - 2024-12-03 06:08:01 --> Output Class Initialized
INFO - 2024-12-03 06:08:01 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:01 --> Input Class Initialized
INFO - 2024-12-03 06:08:01 --> Language Class Initialized
INFO - 2024-12-03 06:08:01 --> Loader Class Initialized
INFO - 2024-12-03 06:08:01 --> Helper loaded: url_helper
INFO - 2024-12-03 06:08:01 --> Helper loaded: file_helper
INFO - 2024-12-03 06:08:01 --> Helper loaded: security_helper
INFO - 2024-12-03 06:08:01 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:08:01 --> Database Driver Class Initialized
INFO - 2024-12-03 06:08:01 --> Config Class Initialized
INFO - 2024-12-03 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:01 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:01 --> URI Class Initialized
INFO - 2024-12-03 06:08:01 --> Router Class Initialized
INFO - 2024-12-03 06:08:01 --> Output Class Initialized
INFO - 2024-12-03 06:08:01 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:01 --> Input Class Initialized
INFO - 2024-12-03 06:08:01 --> Language Class Initialized
ERROR - 2024-12-03 06:08:01 --> 404 Page Not Found: Server/index
INFO - 2024-12-03 06:08:01 --> Email Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:08:01 --> Helper loaded: form_helper
INFO - 2024-12-03 06:08:01 --> Form Validation Class Initialized
INFO - 2024-12-03 06:08:01 --> Controller Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:08:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:08:01 --> Final output sent to browser
DEBUG - 2024-12-03 06:08:01 --> Total execution time: 0.4482
INFO - 2024-12-03 06:08:01 --> Config Class Initialized
INFO - 2024-12-03 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:01 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:01 --> URI Class Initialized
INFO - 2024-12-03 06:08:01 --> Router Class Initialized
INFO - 2024-12-03 06:08:01 --> Output Class Initialized
INFO - 2024-12-03 06:08:01 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:01 --> Input Class Initialized
INFO - 2024-12-03 06:08:01 --> Language Class Initialized
ERROR - 2024-12-03 06:08:01 --> 404 Page Not Found: Ecp/Current
INFO - 2024-12-03 06:08:01 --> Config Class Initialized
INFO - 2024-12-03 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:01 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:01 --> URI Class Initialized
INFO - 2024-12-03 06:08:01 --> Router Class Initialized
INFO - 2024-12-03 06:08:01 --> Output Class Initialized
INFO - 2024-12-03 06:08:01 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:01 --> Input Class Initialized
INFO - 2024-12-03 06:08:01 --> Language Class Initialized
ERROR - 2024-12-03 06:08:01 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2024-12-03 06:08:01 --> Config Class Initialized
INFO - 2024-12-03 06:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:01 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:02 --> Config Class Initialized
INFO - 2024-12-03 06:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:02 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:02 --> URI Class Initialized
INFO - 2024-12-03 06:08:02 --> Router Class Initialized
INFO - 2024-12-03 06:08:02 --> Output Class Initialized
INFO - 2024-12-03 06:08:02 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:02 --> Input Class Initialized
INFO - 2024-12-03 06:08:02 --> Language Class Initialized
ERROR - 2024-12-03 06:08:02 --> 404 Page Not Found: Server-status/index
INFO - 2024-12-03 06:08:02 --> Config Class Initialized
INFO - 2024-12-03 06:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:02 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:02 --> URI Class Initialized
INFO - 2024-12-03 06:08:02 --> Router Class Initialized
INFO - 2024-12-03 06:08:02 --> Output Class Initialized
INFO - 2024-12-03 06:08:02 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:02 --> Input Class Initialized
INFO - 2024-12-03 06:08:02 --> Language Class Initialized
ERROR - 2024-12-03 06:08:02 --> 404 Page Not Found: About/index
INFO - 2024-12-03 06:08:02 --> Config Class Initialized
INFO - 2024-12-03 06:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:02 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:02 --> URI Class Initialized
INFO - 2024-12-03 06:08:02 --> Router Class Initialized
INFO - 2024-12-03 06:08:02 --> Output Class Initialized
INFO - 2024-12-03 06:08:02 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:02 --> Input Class Initialized
INFO - 2024-12-03 06:08:02 --> Language Class Initialized
ERROR - 2024-12-03 06:08:02 --> 404 Page Not Found: Configjson/index
INFO - 2024-12-03 06:08:03 --> Config Class Initialized
INFO - 2024-12-03 06:08:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:03 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:03 --> URI Class Initialized
INFO - 2024-12-03 06:08:03 --> Router Class Initialized
INFO - 2024-12-03 06:08:03 --> Output Class Initialized
INFO - 2024-12-03 06:08:03 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:03 --> Input Class Initialized
INFO - 2024-12-03 06:08:03 --> Language Class Initialized
ERROR - 2024-12-03 06:08:03 --> 404 Page Not Found: Loginaction/index
INFO - 2024-12-03 06:08:03 --> Config Class Initialized
INFO - 2024-12-03 06:08:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:03 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:03 --> URI Class Initialized
INFO - 2024-12-03 06:08:03 --> Router Class Initialized
INFO - 2024-12-03 06:08:03 --> Output Class Initialized
INFO - 2024-12-03 06:08:03 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:03 --> Input Class Initialized
INFO - 2024-12-03 06:08:03 --> Language Class Initialized
ERROR - 2024-12-03 06:08:03 --> 404 Page Not Found: Debug/default
INFO - 2024-12-03 06:08:03 --> Config Class Initialized
INFO - 2024-12-03 06:08:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:03 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:03 --> URI Class Initialized
INFO - 2024-12-03 06:08:03 --> Router Class Initialized
INFO - 2024-12-03 06:08:03 --> Output Class Initialized
INFO - 2024-12-03 06:08:03 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:03 --> Input Class Initialized
INFO - 2024-12-03 06:08:03 --> Language Class Initialized
ERROR - 2024-12-03 06:08:03 --> 404 Page Not Found: Telescope/requests
INFO - 2024-12-03 06:08:04 --> Config Class Initialized
INFO - 2024-12-03 06:08:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:04 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:04 --> URI Class Initialized
INFO - 2024-12-03 06:08:04 --> Router Class Initialized
INFO - 2024-12-03 06:08:04 --> Output Class Initialized
INFO - 2024-12-03 06:08:04 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:04 --> Input Class Initialized
INFO - 2024-12-03 06:08:04 --> Language Class Initialized
ERROR - 2024-12-03 06:08:04 --> 404 Page Not Found: _all_dbs/index
INFO - 2024-12-03 06:08:04 --> Config Class Initialized
INFO - 2024-12-03 06:08:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:04 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:04 --> URI Class Initialized
DEBUG - 2024-12-03 06:08:04 --> No URI present. Default controller set.
INFO - 2024-12-03 06:08:04 --> Router Class Initialized
INFO - 2024-12-03 06:08:04 --> Output Class Initialized
INFO - 2024-12-03 06:08:04 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:04 --> Input Class Initialized
INFO - 2024-12-03 06:08:04 --> Language Class Initialized
INFO - 2024-12-03 06:08:04 --> Loader Class Initialized
INFO - 2024-12-03 06:08:04 --> Helper loaded: url_helper
INFO - 2024-12-03 06:08:04 --> Helper loaded: file_helper
INFO - 2024-12-03 06:08:04 --> Helper loaded: security_helper
INFO - 2024-12-03 06:08:04 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:08:04 --> Database Driver Class Initialized
INFO - 2024-12-03 06:08:04 --> Config Class Initialized
INFO - 2024-12-03 06:08:04 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:04 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:04 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:04 --> URI Class Initialized
INFO - 2024-12-03 06:08:04 --> Router Class Initialized
INFO - 2024-12-03 06:08:04 --> Output Class Initialized
INFO - 2024-12-03 06:08:04 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:04 --> Input Class Initialized
INFO - 2024-12-03 06:08:04 --> Language Class Initialized
ERROR - 2024-12-03 06:08:04 --> 404 Page Not Found: V2/_catalog
INFO - 2024-12-03 06:08:05 --> Email Class Initialized
DEBUG - 2024-12-03 06:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:08:05 --> Helper loaded: form_helper
INFO - 2024-12-03 06:08:05 --> Form Validation Class Initialized
INFO - 2024-12-03 06:08:05 --> Controller Class Initialized
DEBUG - 2024-12-03 06:08:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:08:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:08:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:08:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:08:05 --> Final output sent to browser
DEBUG - 2024-12-03 06:08:05 --> Total execution time: 0.4577
INFO - 2024-12-03 06:08:05 --> Config Class Initialized
INFO - 2024-12-03 06:08:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:05 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:05 --> URI Class Initialized
INFO - 2024-12-03 06:08:05 --> Router Class Initialized
INFO - 2024-12-03 06:08:05 --> Output Class Initialized
INFO - 2024-12-03 06:08:05 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:05 --> Input Class Initialized
INFO - 2024-12-03 06:08:05 --> Language Class Initialized
ERROR - 2024-12-03 06:08:05 --> 404 Page Not Found: DS_Store/index
INFO - 2024-12-03 06:08:06 --> Config Class Initialized
INFO - 2024-12-03 06:08:06 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:06 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:06 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:06 --> URI Class Initialized
INFO - 2024-12-03 06:08:06 --> Router Class Initialized
INFO - 2024-12-03 06:08:06 --> Output Class Initialized
INFO - 2024-12-03 06:08:06 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:06 --> Input Class Initialized
INFO - 2024-12-03 06:08:06 --> Language Class Initialized
ERROR - 2024-12-03 06:08:06 --> 404 Page Not Found: Ecp/Current
INFO - 2024-12-03 06:08:07 --> Config Class Initialized
INFO - 2024-12-03 06:08:07 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:07 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:07 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:08 --> Config Class Initialized
INFO - 2024-12-03 06:08:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:08 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:08 --> URI Class Initialized
INFO - 2024-12-03 06:08:08 --> Router Class Initialized
INFO - 2024-12-03 06:08:08 --> Output Class Initialized
INFO - 2024-12-03 06:08:08 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:08 --> Input Class Initialized
INFO - 2024-12-03 06:08:08 --> Language Class Initialized
ERROR - 2024-12-03 06:08:08 --> 404 Page Not Found: Server-status/index
INFO - 2024-12-03 06:08:08 --> Config Class Initialized
INFO - 2024-12-03 06:08:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:08 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:08 --> URI Class Initialized
INFO - 2024-12-03 06:08:08 --> Router Class Initialized
INFO - 2024-12-03 06:08:08 --> Output Class Initialized
INFO - 2024-12-03 06:08:08 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:08 --> Input Class Initialized
INFO - 2024-12-03 06:08:08 --> Language Class Initialized
ERROR - 2024-12-03 06:08:08 --> 404 Page Not Found: Configjson/index
INFO - 2024-12-03 06:08:09 --> Config Class Initialized
INFO - 2024-12-03 06:08:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:09 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:09 --> URI Class Initialized
INFO - 2024-12-03 06:08:09 --> Router Class Initialized
INFO - 2024-12-03 06:08:09 --> Output Class Initialized
INFO - 2024-12-03 06:08:09 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:09 --> Input Class Initialized
INFO - 2024-12-03 06:08:09 --> Language Class Initialized
ERROR - 2024-12-03 06:08:09 --> 404 Page Not Found: Loginaction/index
INFO - 2024-12-03 06:08:09 --> Config Class Initialized
INFO - 2024-12-03 06:08:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:09 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:09 --> URI Class Initialized
INFO - 2024-12-03 06:08:09 --> Router Class Initialized
INFO - 2024-12-03 06:08:09 --> Output Class Initialized
INFO - 2024-12-03 06:08:09 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:09 --> Input Class Initialized
INFO - 2024-12-03 06:08:09 --> Language Class Initialized
ERROR - 2024-12-03 06:08:09 --> 404 Page Not Found: Telescope/requests
INFO - 2024-12-03 06:08:10 --> Config Class Initialized
INFO - 2024-12-03 06:08:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:10 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:10 --> URI Class Initialized
INFO - 2024-12-03 06:08:10 --> Router Class Initialized
INFO - 2024-12-03 06:08:10 --> Output Class Initialized
INFO - 2024-12-03 06:08:10 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:10 --> Input Class Initialized
INFO - 2024-12-03 06:08:10 --> Language Class Initialized
ERROR - 2024-12-03 06:08:10 --> 404 Page Not Found: _all_dbs/index
INFO - 2024-12-03 06:08:10 --> Config Class Initialized
INFO - 2024-12-03 06:08:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:10 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:10 --> URI Class Initialized
DEBUG - 2024-12-03 06:08:10 --> No URI present. Default controller set.
INFO - 2024-12-03 06:08:10 --> Router Class Initialized
INFO - 2024-12-03 06:08:10 --> Output Class Initialized
INFO - 2024-12-03 06:08:10 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:10 --> Input Class Initialized
INFO - 2024-12-03 06:08:10 --> Language Class Initialized
INFO - 2024-12-03 06:08:10 --> Loader Class Initialized
INFO - 2024-12-03 06:08:10 --> Helper loaded: url_helper
INFO - 2024-12-03 06:08:10 --> Helper loaded: file_helper
INFO - 2024-12-03 06:08:10 --> Helper loaded: security_helper
INFO - 2024-12-03 06:08:10 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:08:10 --> Database Driver Class Initialized
INFO - 2024-12-03 06:08:11 --> Email Class Initialized
DEBUG - 2024-12-03 06:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:08:11 --> Helper loaded: form_helper
INFO - 2024-12-03 06:08:11 --> Form Validation Class Initialized
INFO - 2024-12-03 06:08:11 --> Controller Class Initialized
DEBUG - 2024-12-03 06:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:08:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:08:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:08:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:08:11 --> Final output sent to browser
DEBUG - 2024-12-03 06:08:11 --> Total execution time: 0.4540
INFO - 2024-12-03 06:08:12 --> Config Class Initialized
INFO - 2024-12-03 06:08:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:12 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:12 --> URI Class Initialized
INFO - 2024-12-03 06:08:12 --> Router Class Initialized
INFO - 2024-12-03 06:08:12 --> Output Class Initialized
INFO - 2024-12-03 06:08:12 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:12 --> Input Class Initialized
INFO - 2024-12-03 06:08:12 --> Language Class Initialized
ERROR - 2024-12-03 06:08:12 --> 404 Page Not Found: DS_Store/index
INFO - 2024-12-03 06:08:15 --> Config Class Initialized
INFO - 2024-12-03 06:08:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:15 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:16 --> Config Class Initialized
INFO - 2024-12-03 06:08:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:16 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:16 --> URI Class Initialized
INFO - 2024-12-03 06:08:16 --> Router Class Initialized
INFO - 2024-12-03 06:08:16 --> Output Class Initialized
INFO - 2024-12-03 06:08:16 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:16 --> Input Class Initialized
INFO - 2024-12-03 06:08:16 --> Language Class Initialized
ERROR - 2024-12-03 06:08:16 --> 404 Page Not Found: Configjson/index
INFO - 2024-12-03 06:08:18 --> Config Class Initialized
INFO - 2024-12-03 06:08:18 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:18 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:18 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:18 --> URI Class Initialized
INFO - 2024-12-03 06:08:18 --> Router Class Initialized
INFO - 2024-12-03 06:08:18 --> Output Class Initialized
INFO - 2024-12-03 06:08:18 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:18 --> Input Class Initialized
INFO - 2024-12-03 06:08:18 --> Language Class Initialized
ERROR - 2024-12-03 06:08:18 --> 404 Page Not Found: Telescope/requests
INFO - 2024-12-03 06:08:19 --> Config Class Initialized
INFO - 2024-12-03 06:08:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:08:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:08:19 --> Utf8 Class Initialized
INFO - 2024-12-03 06:08:19 --> URI Class Initialized
DEBUG - 2024-12-03 06:08:19 --> No URI present. Default controller set.
INFO - 2024-12-03 06:08:19 --> Router Class Initialized
INFO - 2024-12-03 06:08:19 --> Output Class Initialized
INFO - 2024-12-03 06:08:19 --> Security Class Initialized
DEBUG - 2024-12-03 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:08:19 --> Input Class Initialized
INFO - 2024-12-03 06:08:19 --> Language Class Initialized
INFO - 2024-12-03 06:08:19 --> Loader Class Initialized
INFO - 2024-12-03 06:08:19 --> Helper loaded: url_helper
INFO - 2024-12-03 06:08:19 --> Helper loaded: file_helper
INFO - 2024-12-03 06:08:19 --> Helper loaded: security_helper
INFO - 2024-12-03 06:08:19 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:08:19 --> Database Driver Class Initialized
INFO - 2024-12-03 06:08:19 --> Email Class Initialized
DEBUG - 2024-12-03 06:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:08:19 --> Helper loaded: form_helper
INFO - 2024-12-03 06:08:19 --> Form Validation Class Initialized
INFO - 2024-12-03 06:08:19 --> Controller Class Initialized
DEBUG - 2024-12-03 06:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:08:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:08:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:08:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:08:19 --> Final output sent to browser
DEBUG - 2024-12-03 06:08:19 --> Total execution time: 0.4391
INFO - 2024-12-03 06:11:35 --> Config Class Initialized
INFO - 2024-12-03 06:11:35 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:11:35 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:11:35 --> Utf8 Class Initialized
INFO - 2024-12-03 06:11:35 --> URI Class Initialized
DEBUG - 2024-12-03 06:11:35 --> No URI present. Default controller set.
INFO - 2024-12-03 06:11:35 --> Router Class Initialized
INFO - 2024-12-03 06:11:35 --> Output Class Initialized
INFO - 2024-12-03 06:11:35 --> Security Class Initialized
DEBUG - 2024-12-03 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:11:35 --> Input Class Initialized
INFO - 2024-12-03 06:11:35 --> Language Class Initialized
INFO - 2024-12-03 06:11:35 --> Loader Class Initialized
INFO - 2024-12-03 06:11:35 --> Helper loaded: url_helper
INFO - 2024-12-03 06:11:35 --> Helper loaded: file_helper
INFO - 2024-12-03 06:11:35 --> Helper loaded: security_helper
INFO - 2024-12-03 06:11:35 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:11:35 --> Database Driver Class Initialized
INFO - 2024-12-03 06:11:35 --> Email Class Initialized
DEBUG - 2024-12-03 06:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:11:35 --> Helper loaded: form_helper
INFO - 2024-12-03 06:11:35 --> Form Validation Class Initialized
INFO - 2024-12-03 06:11:35 --> Controller Class Initialized
DEBUG - 2024-12-03 06:11:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:11:35 --> Final output sent to browser
DEBUG - 2024-12-03 06:11:35 --> Total execution time: 0.4542
INFO - 2024-12-03 06:11:53 --> Config Class Initialized
INFO - 2024-12-03 06:11:53 --> Hooks Class Initialized
DEBUG - 2024-12-03 06:11:53 --> UTF-8 Support Enabled
INFO - 2024-12-03 06:11:53 --> Utf8 Class Initialized
INFO - 2024-12-03 06:11:53 --> URI Class Initialized
DEBUG - 2024-12-03 06:11:53 --> No URI present. Default controller set.
INFO - 2024-12-03 06:11:53 --> Router Class Initialized
INFO - 2024-12-03 06:11:53 --> Output Class Initialized
INFO - 2024-12-03 06:11:53 --> Security Class Initialized
DEBUG - 2024-12-03 06:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 06:11:53 --> Input Class Initialized
INFO - 2024-12-03 06:11:53 --> Language Class Initialized
INFO - 2024-12-03 06:11:53 --> Loader Class Initialized
INFO - 2024-12-03 06:11:53 --> Helper loaded: url_helper
INFO - 2024-12-03 06:11:53 --> Helper loaded: file_helper
INFO - 2024-12-03 06:11:53 --> Helper loaded: security_helper
INFO - 2024-12-03 06:11:53 --> Helper loaded: wpu_helper
INFO - 2024-12-03 06:11:53 --> Database Driver Class Initialized
INFO - 2024-12-03 06:11:54 --> Email Class Initialized
DEBUG - 2024-12-03 06:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 06:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 06:11:54 --> Helper loaded: form_helper
INFO - 2024-12-03 06:11:54 --> Form Validation Class Initialized
INFO - 2024-12-03 06:11:54 --> Controller Class Initialized
DEBUG - 2024-12-03 06:11:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 06:11:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 06:11:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 06:11:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 06:11:54 --> Final output sent to browser
DEBUG - 2024-12-03 06:11:54 --> Total execution time: 0.4535
INFO - 2024-12-03 07:21:14 --> Config Class Initialized
INFO - 2024-12-03 07:21:14 --> Hooks Class Initialized
DEBUG - 2024-12-03 07:21:14 --> UTF-8 Support Enabled
INFO - 2024-12-03 07:21:14 --> Utf8 Class Initialized
INFO - 2024-12-03 07:21:14 --> URI Class Initialized
DEBUG - 2024-12-03 07:21:14 --> No URI present. Default controller set.
INFO - 2024-12-03 07:21:14 --> Router Class Initialized
INFO - 2024-12-03 07:21:14 --> Output Class Initialized
INFO - 2024-12-03 07:21:14 --> Security Class Initialized
DEBUG - 2024-12-03 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 07:21:14 --> Input Class Initialized
INFO - 2024-12-03 07:21:14 --> Language Class Initialized
INFO - 2024-12-03 07:21:15 --> Loader Class Initialized
INFO - 2024-12-03 07:21:15 --> Helper loaded: url_helper
INFO - 2024-12-03 07:21:15 --> Helper loaded: file_helper
INFO - 2024-12-03 07:21:15 --> Helper loaded: security_helper
INFO - 2024-12-03 07:21:15 --> Helper loaded: wpu_helper
INFO - 2024-12-03 07:21:15 --> Database Driver Class Initialized
INFO - 2024-12-03 07:21:15 --> Email Class Initialized
DEBUG - 2024-12-03 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 07:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 07:21:15 --> Helper loaded: form_helper
INFO - 2024-12-03 07:21:15 --> Form Validation Class Initialized
INFO - 2024-12-03 07:21:15 --> Controller Class Initialized
DEBUG - 2024-12-03 07:21:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 07:21:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 07:21:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 07:21:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 07:21:15 --> Final output sent to browser
DEBUG - 2024-12-03 07:21:15 --> Total execution time: 0.4584
INFO - 2024-12-03 07:21:17 --> Config Class Initialized
INFO - 2024-12-03 07:21:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 07:21:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 07:21:17 --> Utf8 Class Initialized
INFO - 2024-12-03 07:21:17 --> URI Class Initialized
DEBUG - 2024-12-03 07:21:17 --> No URI present. Default controller set.
INFO - 2024-12-03 07:21:17 --> Router Class Initialized
INFO - 2024-12-03 07:21:17 --> Output Class Initialized
INFO - 2024-12-03 07:21:17 --> Security Class Initialized
DEBUG - 2024-12-03 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 07:21:17 --> Input Class Initialized
INFO - 2024-12-03 07:21:17 --> Language Class Initialized
INFO - 2024-12-03 07:21:17 --> Loader Class Initialized
INFO - 2024-12-03 07:21:17 --> Helper loaded: url_helper
INFO - 2024-12-03 07:21:17 --> Helper loaded: file_helper
INFO - 2024-12-03 07:21:17 --> Helper loaded: security_helper
INFO - 2024-12-03 07:21:17 --> Helper loaded: wpu_helper
INFO - 2024-12-03 07:21:17 --> Database Driver Class Initialized
INFO - 2024-12-03 07:21:17 --> Email Class Initialized
DEBUG - 2024-12-03 07:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 07:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 07:21:17 --> Helper loaded: form_helper
INFO - 2024-12-03 07:21:17 --> Form Validation Class Initialized
INFO - 2024-12-03 07:21:17 --> Controller Class Initialized
DEBUG - 2024-12-03 07:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 07:21:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 07:21:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 07:21:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 07:21:17 --> Final output sent to browser
DEBUG - 2024-12-03 07:21:17 --> Total execution time: 0.4464
INFO - 2024-12-03 07:21:24 --> Config Class Initialized
INFO - 2024-12-03 07:21:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 07:21:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 07:21:24 --> Utf8 Class Initialized
INFO - 2024-12-03 07:21:24 --> URI Class Initialized
DEBUG - 2024-12-03 07:21:24 --> No URI present. Default controller set.
INFO - 2024-12-03 07:21:24 --> Router Class Initialized
INFO - 2024-12-03 07:21:24 --> Output Class Initialized
INFO - 2024-12-03 07:21:24 --> Security Class Initialized
DEBUG - 2024-12-03 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 07:21:24 --> Input Class Initialized
INFO - 2024-12-03 07:21:24 --> Language Class Initialized
INFO - 2024-12-03 07:21:24 --> Loader Class Initialized
INFO - 2024-12-03 07:21:24 --> Helper loaded: url_helper
INFO - 2024-12-03 07:21:24 --> Helper loaded: file_helper
INFO - 2024-12-03 07:21:24 --> Helper loaded: security_helper
INFO - 2024-12-03 07:21:24 --> Helper loaded: wpu_helper
INFO - 2024-12-03 07:21:24 --> Database Driver Class Initialized
INFO - 2024-12-03 07:21:25 --> Email Class Initialized
DEBUG - 2024-12-03 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 07:21:25 --> Helper loaded: form_helper
INFO - 2024-12-03 07:21:25 --> Form Validation Class Initialized
INFO - 2024-12-03 07:21:25 --> Controller Class Initialized
DEBUG - 2024-12-03 07:21:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 07:21:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 07:21:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 07:21:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 07:21:25 --> Final output sent to browser
DEBUG - 2024-12-03 07:21:25 --> Total execution time: 0.4170
INFO - 2024-12-03 07:21:51 --> Config Class Initialized
INFO - 2024-12-03 07:21:51 --> Hooks Class Initialized
DEBUG - 2024-12-03 07:21:51 --> UTF-8 Support Enabled
INFO - 2024-12-03 07:21:51 --> Utf8 Class Initialized
INFO - 2024-12-03 07:21:51 --> URI Class Initialized
DEBUG - 2024-12-03 07:21:51 --> No URI present. Default controller set.
INFO - 2024-12-03 07:21:51 --> Router Class Initialized
INFO - 2024-12-03 07:21:51 --> Output Class Initialized
INFO - 2024-12-03 07:21:51 --> Security Class Initialized
DEBUG - 2024-12-03 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 07:21:51 --> Input Class Initialized
INFO - 2024-12-03 07:21:51 --> Language Class Initialized
INFO - 2024-12-03 07:21:51 --> Loader Class Initialized
INFO - 2024-12-03 07:21:51 --> Helper loaded: url_helper
INFO - 2024-12-03 07:21:51 --> Helper loaded: file_helper
INFO - 2024-12-03 07:21:51 --> Helper loaded: security_helper
INFO - 2024-12-03 07:21:51 --> Helper loaded: wpu_helper
INFO - 2024-12-03 07:21:51 --> Database Driver Class Initialized
INFO - 2024-12-03 07:21:52 --> Email Class Initialized
DEBUG - 2024-12-03 07:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 07:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 07:21:52 --> Helper loaded: form_helper
INFO - 2024-12-03 07:21:52 --> Form Validation Class Initialized
INFO - 2024-12-03 07:21:52 --> Controller Class Initialized
DEBUG - 2024-12-03 07:21:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 07:21:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 07:21:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 07:21:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 07:21:52 --> Final output sent to browser
DEBUG - 2024-12-03 07:21:52 --> Total execution time: 0.4643
INFO - 2024-12-03 09:41:58 --> Config Class Initialized
INFO - 2024-12-03 09:41:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 09:41:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 09:41:58 --> Utf8 Class Initialized
INFO - 2024-12-03 09:41:58 --> URI Class Initialized
DEBUG - 2024-12-03 09:41:58 --> No URI present. Default controller set.
INFO - 2024-12-03 09:41:58 --> Router Class Initialized
INFO - 2024-12-03 09:41:58 --> Output Class Initialized
INFO - 2024-12-03 09:41:58 --> Security Class Initialized
DEBUG - 2024-12-03 09:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 09:41:58 --> Input Class Initialized
INFO - 2024-12-03 09:41:58 --> Language Class Initialized
INFO - 2024-12-03 09:41:58 --> Loader Class Initialized
INFO - 2024-12-03 09:41:58 --> Helper loaded: url_helper
INFO - 2024-12-03 09:41:58 --> Helper loaded: file_helper
INFO - 2024-12-03 09:41:58 --> Helper loaded: security_helper
INFO - 2024-12-03 09:41:58 --> Helper loaded: wpu_helper
INFO - 2024-12-03 09:41:58 --> Database Driver Class Initialized
INFO - 2024-12-03 09:41:59 --> Email Class Initialized
DEBUG - 2024-12-03 09:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 09:41:59 --> Helper loaded: form_helper
INFO - 2024-12-03 09:41:59 --> Form Validation Class Initialized
INFO - 2024-12-03 09:41:59 --> Controller Class Initialized
DEBUG - 2024-12-03 09:41:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 09:41:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 09:41:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 09:41:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 09:41:59 --> Final output sent to browser
DEBUG - 2024-12-03 09:41:59 --> Total execution time: 0.4034
INFO - 2024-12-03 10:21:21 --> Config Class Initialized
INFO - 2024-12-03 10:21:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:21:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:21:21 --> Utf8 Class Initialized
INFO - 2024-12-03 10:21:21 --> URI Class Initialized
INFO - 2024-12-03 10:21:21 --> Router Class Initialized
INFO - 2024-12-03 10:21:21 --> Output Class Initialized
INFO - 2024-12-03 10:21:21 --> Security Class Initialized
DEBUG - 2024-12-03 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:21:21 --> Input Class Initialized
INFO - 2024-12-03 10:21:21 --> Language Class Initialized
ERROR - 2024-12-03 10:21:21 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-03 10:21:21 --> Config Class Initialized
INFO - 2024-12-03 10:21:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:21:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:21:21 --> Utf8 Class Initialized
INFO - 2024-12-03 10:21:21 --> URI Class Initialized
DEBUG - 2024-12-03 10:21:21 --> No URI present. Default controller set.
INFO - 2024-12-03 10:21:21 --> Router Class Initialized
INFO - 2024-12-03 10:21:21 --> Output Class Initialized
INFO - 2024-12-03 10:21:21 --> Security Class Initialized
DEBUG - 2024-12-03 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:21:21 --> Input Class Initialized
INFO - 2024-12-03 10:21:21 --> Language Class Initialized
INFO - 2024-12-03 10:21:21 --> Loader Class Initialized
INFO - 2024-12-03 10:21:21 --> Helper loaded: url_helper
INFO - 2024-12-03 10:21:21 --> Helper loaded: file_helper
INFO - 2024-12-03 10:21:21 --> Helper loaded: security_helper
INFO - 2024-12-03 10:21:21 --> Helper loaded: wpu_helper
INFO - 2024-12-03 10:21:21 --> Database Driver Class Initialized
INFO - 2024-12-03 10:21:22 --> Email Class Initialized
DEBUG - 2024-12-03 10:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:21:22 --> Helper loaded: form_helper
INFO - 2024-12-03 10:21:22 --> Form Validation Class Initialized
INFO - 2024-12-03 10:21:22 --> Controller Class Initialized
DEBUG - 2024-12-03 10:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 10:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 10:21:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 10:21:22 --> Final output sent to browser
DEBUG - 2024-12-03 10:21:22 --> Total execution time: 0.4257
INFO - 2024-12-03 10:29:15 --> Config Class Initialized
INFO - 2024-12-03 10:29:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 10:29:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 10:29:15 --> Utf8 Class Initialized
INFO - 2024-12-03 10:29:15 --> URI Class Initialized
DEBUG - 2024-12-03 10:29:15 --> No URI present. Default controller set.
INFO - 2024-12-03 10:29:15 --> Router Class Initialized
INFO - 2024-12-03 10:29:15 --> Output Class Initialized
INFO - 2024-12-03 10:29:15 --> Security Class Initialized
DEBUG - 2024-12-03 10:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 10:29:15 --> Input Class Initialized
INFO - 2024-12-03 10:29:15 --> Language Class Initialized
INFO - 2024-12-03 10:29:15 --> Loader Class Initialized
INFO - 2024-12-03 10:29:15 --> Helper loaded: url_helper
INFO - 2024-12-03 10:29:15 --> Helper loaded: file_helper
INFO - 2024-12-03 10:29:15 --> Helper loaded: security_helper
INFO - 2024-12-03 10:29:15 --> Helper loaded: wpu_helper
INFO - 2024-12-03 10:29:15 --> Database Driver Class Initialized
INFO - 2024-12-03 10:29:15 --> Email Class Initialized
DEBUG - 2024-12-03 10:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 10:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 10:29:15 --> Helper loaded: form_helper
INFO - 2024-12-03 10:29:15 --> Form Validation Class Initialized
INFO - 2024-12-03 10:29:15 --> Controller Class Initialized
DEBUG - 2024-12-03 10:29:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 10:29:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 10:29:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 10:29:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 10:29:15 --> Final output sent to browser
DEBUG - 2024-12-03 10:29:15 --> Total execution time: 0.4239
INFO - 2024-12-03 11:39:13 --> Config Class Initialized
INFO - 2024-12-03 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:39:13 --> Utf8 Class Initialized
INFO - 2024-12-03 11:39:13 --> URI Class Initialized
INFO - 2024-12-03 11:39:13 --> Router Class Initialized
INFO - 2024-12-03 11:39:13 --> Output Class Initialized
INFO - 2024-12-03 11:39:13 --> Security Class Initialized
DEBUG - 2024-12-03 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:39:13 --> Input Class Initialized
INFO - 2024-12-03 11:39:13 --> Language Class Initialized
ERROR - 2024-12-03 11:39:13 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2024-12-03 11:39:13 --> Config Class Initialized
INFO - 2024-12-03 11:39:13 --> Hooks Class Initialized
DEBUG - 2024-12-03 11:39:13 --> UTF-8 Support Enabled
INFO - 2024-12-03 11:39:13 --> Utf8 Class Initialized
INFO - 2024-12-03 11:39:13 --> URI Class Initialized
INFO - 2024-12-03 11:39:13 --> Router Class Initialized
INFO - 2024-12-03 11:39:13 --> Output Class Initialized
INFO - 2024-12-03 11:39:13 --> Security Class Initialized
DEBUG - 2024-12-03 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 11:39:13 --> Input Class Initialized
INFO - 2024-12-03 11:39:13 --> Language Class Initialized
ERROR - 2024-12-03 11:39:13 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2024-12-03 13:31:27 --> Config Class Initialized
INFO - 2024-12-03 13:31:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 13:31:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 13:31:27 --> Utf8 Class Initialized
INFO - 2024-12-03 13:31:27 --> URI Class Initialized
DEBUG - 2024-12-03 13:31:27 --> No URI present. Default controller set.
INFO - 2024-12-03 13:31:27 --> Router Class Initialized
INFO - 2024-12-03 13:31:27 --> Output Class Initialized
INFO - 2024-12-03 13:31:27 --> Security Class Initialized
DEBUG - 2024-12-03 13:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 13:31:27 --> Input Class Initialized
INFO - 2024-12-03 13:31:27 --> Language Class Initialized
INFO - 2024-12-03 13:31:27 --> Loader Class Initialized
INFO - 2024-12-03 13:31:27 --> Helper loaded: url_helper
INFO - 2024-12-03 13:31:27 --> Helper loaded: file_helper
INFO - 2024-12-03 13:31:27 --> Helper loaded: security_helper
INFO - 2024-12-03 13:31:27 --> Helper loaded: wpu_helper
INFO - 2024-12-03 13:31:27 --> Database Driver Class Initialized
INFO - 2024-12-03 13:31:28 --> Email Class Initialized
DEBUG - 2024-12-03 13:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 13:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 13:31:28 --> Helper loaded: form_helper
INFO - 2024-12-03 13:31:28 --> Form Validation Class Initialized
INFO - 2024-12-03 13:31:28 --> Controller Class Initialized
DEBUG - 2024-12-03 13:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 13:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 13:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 13:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 13:31:28 --> Final output sent to browser
DEBUG - 2024-12-03 13:31:28 --> Total execution time: 0.4397
INFO - 2024-12-03 14:07:31 --> Config Class Initialized
INFO - 2024-12-03 14:07:31 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:07:31 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:07:31 --> Utf8 Class Initialized
INFO - 2024-12-03 14:07:31 --> URI Class Initialized
DEBUG - 2024-12-03 14:07:31 --> No URI present. Default controller set.
INFO - 2024-12-03 14:07:31 --> Router Class Initialized
INFO - 2024-12-03 14:07:31 --> Output Class Initialized
INFO - 2024-12-03 14:07:31 --> Security Class Initialized
DEBUG - 2024-12-03 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:07:31 --> Input Class Initialized
INFO - 2024-12-03 14:07:31 --> Language Class Initialized
INFO - 2024-12-03 14:07:31 --> Loader Class Initialized
INFO - 2024-12-03 14:07:31 --> Helper loaded: url_helper
INFO - 2024-12-03 14:07:31 --> Helper loaded: file_helper
INFO - 2024-12-03 14:07:31 --> Helper loaded: security_helper
INFO - 2024-12-03 14:07:31 --> Helper loaded: wpu_helper
INFO - 2024-12-03 14:07:31 --> Database Driver Class Initialized
INFO - 2024-12-03 14:07:31 --> Email Class Initialized
DEBUG - 2024-12-03 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:07:31 --> Helper loaded: form_helper
INFO - 2024-12-03 14:07:31 --> Form Validation Class Initialized
INFO - 2024-12-03 14:07:31 --> Controller Class Initialized
DEBUG - 2024-12-03 14:07:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 14:07:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 14:07:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 14:07:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 14:07:31 --> Final output sent to browser
DEBUG - 2024-12-03 14:07:31 --> Total execution time: 0.4205
INFO - 2024-12-03 15:24:39 --> Config Class Initialized
INFO - 2024-12-03 15:24:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:24:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:24:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:24:39 --> URI Class Initialized
DEBUG - 2024-12-03 15:24:39 --> No URI present. Default controller set.
INFO - 2024-12-03 15:24:39 --> Router Class Initialized
INFO - 2024-12-03 15:24:39 --> Output Class Initialized
INFO - 2024-12-03 15:24:39 --> Security Class Initialized
DEBUG - 2024-12-03 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:24:39 --> Input Class Initialized
INFO - 2024-12-03 15:24:39 --> Language Class Initialized
INFO - 2024-12-03 15:24:39 --> Loader Class Initialized
INFO - 2024-12-03 15:24:39 --> Helper loaded: url_helper
INFO - 2024-12-03 15:24:39 --> Helper loaded: file_helper
INFO - 2024-12-03 15:24:39 --> Helper loaded: security_helper
INFO - 2024-12-03 15:24:39 --> Helper loaded: wpu_helper
INFO - 2024-12-03 15:24:39 --> Database Driver Class Initialized
INFO - 2024-12-03 15:24:39 --> Email Class Initialized
DEBUG - 2024-12-03 15:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-03 15:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:24:39 --> Helper loaded: form_helper
INFO - 2024-12-03 15:24:39 --> Form Validation Class Initialized
INFO - 2024-12-03 15:24:39 --> Controller Class Initialized
DEBUG - 2024-12-03 15:24:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-03 15:24:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-03 15:24:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-03 15:24:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-03 15:24:39 --> Final output sent to browser
DEBUG - 2024-12-03 15:24:39 --> Total execution time: 0.4566
INFO - 2024-12-03 15:25:01 --> Config Class Initialized
INFO - 2024-12-03 15:25:01 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:01 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:01 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:01 --> URI Class Initialized
INFO - 2024-12-03 15:25:01 --> Router Class Initialized
INFO - 2024-12-03 15:25:01 --> Output Class Initialized
INFO - 2024-12-03 15:25:01 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:01 --> Input Class Initialized
INFO - 2024-12-03 15:25:01 --> Language Class Initialized
ERROR - 2024-12-03 15:25:01 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:02 --> Config Class Initialized
INFO - 2024-12-03 15:25:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:02 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:02 --> URI Class Initialized
INFO - 2024-12-03 15:25:02 --> Config Class Initialized
INFO - 2024-12-03 15:25:02 --> Hooks Class Initialized
INFO - 2024-12-03 15:25:02 --> Router Class Initialized
INFO - 2024-12-03 15:25:02 --> Output Class Initialized
INFO - 2024-12-03 15:25:02 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:02 --> Input Class Initialized
INFO - 2024-12-03 15:25:02 --> Language Class Initialized
ERROR - 2024-12-03 15:25:02 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-03 15:25:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:02 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:02 --> URI Class Initialized
INFO - 2024-12-03 15:25:02 --> Router Class Initialized
INFO - 2024-12-03 15:25:02 --> Output Class Initialized
INFO - 2024-12-03 15:25:02 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:02 --> Input Class Initialized
INFO - 2024-12-03 15:25:02 --> Language Class Initialized
ERROR - 2024-12-03 15:25:02 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-03 15:25:02 --> Config Class Initialized
INFO - 2024-12-03 15:25:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:02 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:02 --> URI Class Initialized
INFO - 2024-12-03 15:25:02 --> Router Class Initialized
INFO - 2024-12-03 15:25:02 --> Output Class Initialized
INFO - 2024-12-03 15:25:02 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:02 --> Input Class Initialized
INFO - 2024-12-03 15:25:02 --> Language Class Initialized
ERROR - 2024-12-03 15:25:02 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:02 --> Config Class Initialized
INFO - 2024-12-03 15:25:02 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:02 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:02 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:02 --> URI Class Initialized
INFO - 2024-12-03 15:25:02 --> Router Class Initialized
INFO - 2024-12-03 15:25:02 --> Output Class Initialized
INFO - 2024-12-03 15:25:02 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:02 --> Input Class Initialized
INFO - 2024-12-03 15:25:02 --> Language Class Initialized
ERROR - 2024-12-03 15:25:02 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:19 --> Config Class Initialized
INFO - 2024-12-03 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:19 --> Config Class Initialized
INFO - 2024-12-03 15:25:19 --> Hooks Class Initialized
INFO - 2024-12-03 15:25:19 --> URI Class Initialized
INFO - 2024-12-03 15:25:19 --> Config Class Initialized
INFO - 2024-12-03 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:19 --> Router Class Initialized
INFO - 2024-12-03 15:25:19 --> URI Class Initialized
INFO - 2024-12-03 15:25:19 --> Config Class Initialized
INFO - 2024-12-03 15:25:19 --> Hooks Class Initialized
INFO - 2024-12-03 15:25:19 --> Router Class Initialized
INFO - 2024-12-03 15:25:19 --> Output Class Initialized
DEBUG - 2024-12-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:19 --> Utf8 Class Initialized
DEBUG - 2024-12-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:19 --> Output Class Initialized
INFO - 2024-12-03 15:25:19 --> Security Class Initialized
INFO - 2024-12-03 15:25:19 --> URI Class Initialized
INFO - 2024-12-03 15:25:19 --> URI Class Initialized
INFO - 2024-12-03 15:25:19 --> Security Class Initialized
INFO - 2024-12-03 15:25:19 --> Router Class Initialized
DEBUG - 2024-12-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:19 --> Router Class Initialized
DEBUG - 2024-12-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:19 --> Input Class Initialized
INFO - 2024-12-03 15:25:19 --> Input Class Initialized
INFO - 2024-12-03 15:25:19 --> Language Class Initialized
INFO - 2024-12-03 15:25:19 --> Language Class Initialized
INFO - 2024-12-03 15:25:19 --> Output Class Initialized
ERROR - 2024-12-03 15:25:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-03 15:25:19 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-03 15:25:19 --> Output Class Initialized
INFO - 2024-12-03 15:25:19 --> Security Class Initialized
INFO - 2024-12-03 15:25:19 --> Config Class Initialized
INFO - 2024-12-03 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:19 --> Input Class Initialized
INFO - 2024-12-03 15:25:19 --> Language Class Initialized
INFO - 2024-12-03 15:25:19 --> Security Class Initialized
ERROR - 2024-12-03 15:25:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:19 --> Utf8 Class Initialized
DEBUG - 2024-12-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:19 --> Input Class Initialized
INFO - 2024-12-03 15:25:19 --> URI Class Initialized
INFO - 2024-12-03 15:25:19 --> Language Class Initialized
INFO - 2024-12-03 15:25:19 --> Router Class Initialized
ERROR - 2024-12-03 15:25:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:19 --> Output Class Initialized
INFO - 2024-12-03 15:25:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:19 --> Input Class Initialized
INFO - 2024-12-03 15:25:19 --> Language Class Initialized
ERROR - 2024-12-03 15:25:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:39 --> Config Class Initialized
INFO - 2024-12-03 15:25:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:39 --> Config Class Initialized
INFO - 2024-12-03 15:25:39 --> Hooks Class Initialized
INFO - 2024-12-03 15:25:39 --> URI Class Initialized
DEBUG - 2024-12-03 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:39 --> Router Class Initialized
INFO - 2024-12-03 15:25:39 --> URI Class Initialized
INFO - 2024-12-03 15:25:39 --> Router Class Initialized
INFO - 2024-12-03 15:25:39 --> Output Class Initialized
INFO - 2024-12-03 15:25:39 --> Output Class Initialized
INFO - 2024-12-03 15:25:39 --> Security Class Initialized
INFO - 2024-12-03 15:25:39 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:39 --> Input Class Initialized
DEBUG - 2024-12-03 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:39 --> Language Class Initialized
INFO - 2024-12-03 15:25:39 --> Input Class Initialized
INFO - 2024-12-03 15:25:39 --> Language Class Initialized
ERROR - 2024-12-03 15:25:39 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-03 15:25:39 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-03 15:25:39 --> Config Class Initialized
INFO - 2024-12-03 15:25:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:39 --> URI Class Initialized
INFO - 2024-12-03 15:25:39 --> Router Class Initialized
INFO - 2024-12-03 15:25:39 --> Output Class Initialized
INFO - 2024-12-03 15:25:39 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:39 --> Input Class Initialized
INFO - 2024-12-03 15:25:39 --> Language Class Initialized
ERROR - 2024-12-03 15:25:39 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:39 --> Config Class Initialized
INFO - 2024-12-03 15:25:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:39 --> URI Class Initialized
INFO - 2024-12-03 15:25:39 --> Router Class Initialized
INFO - 2024-12-03 15:25:39 --> Output Class Initialized
INFO - 2024-12-03 15:25:39 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:39 --> Input Class Initialized
INFO - 2024-12-03 15:25:39 --> Language Class Initialized
ERROR - 2024-12-03 15:25:39 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:39 --> Config Class Initialized
INFO - 2024-12-03 15:25:39 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:39 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:39 --> URI Class Initialized
INFO - 2024-12-03 15:25:39 --> Router Class Initialized
INFO - 2024-12-03 15:25:39 --> Output Class Initialized
INFO - 2024-12-03 15:25:39 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:39 --> Input Class Initialized
INFO - 2024-12-03 15:25:39 --> Language Class Initialized
ERROR - 2024-12-03 15:25:39 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:57 --> Config Class Initialized
INFO - 2024-12-03 15:25:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:57 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:57 --> URI Class Initialized
INFO - 2024-12-03 15:25:57 --> Router Class Initialized
INFO - 2024-12-03 15:25:57 --> Output Class Initialized
INFO - 2024-12-03 15:25:57 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:57 --> Input Class Initialized
INFO - 2024-12-03 15:25:57 --> Language Class Initialized
INFO - 2024-12-03 15:25:57 --> Config Class Initialized
INFO - 2024-12-03 15:25:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:57 --> Utf8 Class Initialized
ERROR - 2024-12-03 15:25:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:57 --> URI Class Initialized
INFO - 2024-12-03 15:25:57 --> Router Class Initialized
INFO - 2024-12-03 15:25:57 --> Output Class Initialized
INFO - 2024-12-03 15:25:57 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:57 --> Input Class Initialized
INFO - 2024-12-03 15:25:57 --> Language Class Initialized
ERROR - 2024-12-03 15:25:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:57 --> Config Class Initialized
INFO - 2024-12-03 15:25:57 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:57 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:57 --> Config Class Initialized
INFO - 2024-12-03 15:25:57 --> Hooks Class Initialized
INFO - 2024-12-03 15:25:57 --> URI Class Initialized
DEBUG - 2024-12-03 15:25:57 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:57 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:57 --> Router Class Initialized
INFO - 2024-12-03 15:25:57 --> URI Class Initialized
INFO - 2024-12-03 15:25:57 --> Output Class Initialized
INFO - 2024-12-03 15:25:57 --> Router Class Initialized
INFO - 2024-12-03 15:25:57 --> Security Class Initialized
INFO - 2024-12-03 15:25:57 --> Output Class Initialized
DEBUG - 2024-12-03 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:57 --> Input Class Initialized
INFO - 2024-12-03 15:25:57 --> Language Class Initialized
INFO - 2024-12-03 15:25:57 --> Security Class Initialized
ERROR - 2024-12-03 15:25:57 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-12-03 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:57 --> Input Class Initialized
INFO - 2024-12-03 15:25:57 --> Language Class Initialized
ERROR - 2024-12-03 15:25:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:25:58 --> Config Class Initialized
INFO - 2024-12-03 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:58 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:58 --> URI Class Initialized
INFO - 2024-12-03 15:25:58 --> Router Class Initialized
INFO - 2024-12-03 15:25:58 --> Output Class Initialized
INFO - 2024-12-03 15:25:58 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:58 --> Input Class Initialized
INFO - 2024-12-03 15:25:58 --> Language Class Initialized
ERROR - 2024-12-03 15:25:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:19 --> Config Class Initialized
INFO - 2024-12-03 15:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:19 --> URI Class Initialized
INFO - 2024-12-03 15:26:19 --> Router Class Initialized
INFO - 2024-12-03 15:26:19 --> Output Class Initialized
INFO - 2024-12-03 15:26:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:19 --> Input Class Initialized
INFO - 2024-12-03 15:26:19 --> Language Class Initialized
ERROR - 2024-12-03 15:26:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:19 --> Config Class Initialized
INFO - 2024-12-03 15:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:19 --> URI Class Initialized
INFO - 2024-12-03 15:26:19 --> Router Class Initialized
INFO - 2024-12-03 15:26:19 --> Output Class Initialized
INFO - 2024-12-03 15:26:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:19 --> Input Class Initialized
INFO - 2024-12-03 15:26:19 --> Language Class Initialized
ERROR - 2024-12-03 15:26:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:19 --> Config Class Initialized
INFO - 2024-12-03 15:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:19 --> URI Class Initialized
INFO - 2024-12-03 15:26:19 --> Router Class Initialized
INFO - 2024-12-03 15:26:19 --> Output Class Initialized
INFO - 2024-12-03 15:26:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:19 --> Input Class Initialized
INFO - 2024-12-03 15:26:19 --> Language Class Initialized
ERROR - 2024-12-03 15:26:19 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-03 15:26:19 --> Config Class Initialized
INFO - 2024-12-03 15:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:19 --> URI Class Initialized
INFO - 2024-12-03 15:26:19 --> Router Class Initialized
INFO - 2024-12-03 15:26:19 --> Output Class Initialized
INFO - 2024-12-03 15:26:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:19 --> Input Class Initialized
INFO - 2024-12-03 15:26:19 --> Language Class Initialized
ERROR - 2024-12-03 15:26:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:19 --> Config Class Initialized
INFO - 2024-12-03 15:26:19 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:19 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:19 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:19 --> URI Class Initialized
INFO - 2024-12-03 15:26:19 --> Router Class Initialized
INFO - 2024-12-03 15:26:19 --> Output Class Initialized
INFO - 2024-12-03 15:26:19 --> Security Class Initialized
DEBUG - 2024-12-03 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:19 --> Input Class Initialized
INFO - 2024-12-03 15:26:19 --> Language Class Initialized
ERROR - 2024-12-03 15:26:19 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:36 --> Config Class Initialized
INFO - 2024-12-03 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:36 --> Config Class Initialized
INFO - 2024-12-03 15:26:36 --> Hooks Class Initialized
INFO - 2024-12-03 15:26:36 --> URI Class Initialized
DEBUG - 2024-12-03 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:36 --> Router Class Initialized
INFO - 2024-12-03 15:26:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:36 --> URI Class Initialized
INFO - 2024-12-03 15:26:36 --> Output Class Initialized
INFO - 2024-12-03 15:26:36 --> Router Class Initialized
INFO - 2024-12-03 15:26:36 --> Security Class Initialized
INFO - 2024-12-03 15:26:36 --> Output Class Initialized
DEBUG - 2024-12-03 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:36 --> Input Class Initialized
INFO - 2024-12-03 15:26:36 --> Security Class Initialized
INFO - 2024-12-03 15:26:36 --> Language Class Initialized
ERROR - 2024-12-03 15:26:36 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-12-03 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:36 --> Input Class Initialized
INFO - 2024-12-03 15:26:36 --> Language Class Initialized
ERROR - 2024-12-03 15:26:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 15:26:36 --> Config Class Initialized
INFO - 2024-12-03 15:26:36 --> Hooks Class Initialized
INFO - 2024-12-03 15:26:36 --> Config Class Initialized
INFO - 2024-12-03 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:36 --> Utf8 Class Initialized
DEBUG - 2024-12-03 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:36 --> Config Class Initialized
INFO - 2024-12-03 15:26:36 --> Hooks Class Initialized
INFO - 2024-12-03 15:26:36 --> URI Class Initialized
INFO - 2024-12-03 15:26:36 --> URI Class Initialized
INFO - 2024-12-03 15:26:36 --> Router Class Initialized
DEBUG - 2024-12-03 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:26:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:26:36 --> Router Class Initialized
INFO - 2024-12-03 15:26:36 --> URI Class Initialized
INFO - 2024-12-03 15:26:36 --> Output Class Initialized
INFO - 2024-12-03 15:26:36 --> Output Class Initialized
INFO - 2024-12-03 15:26:36 --> Router Class Initialized
INFO - 2024-12-03 15:26:36 --> Security Class Initialized
INFO - 2024-12-03 15:26:36 --> Security Class Initialized
INFO - 2024-12-03 15:26:36 --> Output Class Initialized
DEBUG - 2024-12-03 15:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-03 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:36 --> Input Class Initialized
INFO - 2024-12-03 15:26:36 --> Input Class Initialized
INFO - 2024-12-03 15:26:36 --> Language Class Initialized
INFO - 2024-12-03 15:26:36 --> Language Class Initialized
INFO - 2024-12-03 15:26:36 --> Security Class Initialized
ERROR - 2024-12-03 15:26:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-03 15:26:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-03 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:26:36 --> Input Class Initialized
INFO - 2024-12-03 15:26:36 --> Language Class Initialized
ERROR - 2024-12-03 15:26:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-03 21:44:16 --> Config Class Initialized
INFO - 2024-12-03 21:44:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 21:44:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 21:44:16 --> Utf8 Class Initialized
INFO - 2024-12-03 21:44:16 --> URI Class Initialized
DEBUG - 2024-12-03 21:44:16 --> No URI present. Default controller set.
INFO - 2024-12-03 21:44:16 --> Router Class Initialized
INFO - 2024-12-03 21:44:16 --> Output Class Initialized
INFO - 2024-12-03 21:44:16 --> Security Class Initialized
DEBUG - 2024-12-03 21:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 21:44:16 --> Input Class Initialized
INFO - 2024-12-03 21:44:16 --> Language Class Initialized
INFO - 2024-12-03 21:44:16 --> Loader Class Initialized
INFO - 2024-12-03 21:44:16 --> Helper loaded: url_helper
INFO - 2024-12-03 21:44:16 --> Helper loaded: file_helper
INFO - 2024-12-03 21:44:16 --> Helper loaded: security_helper
INFO - 2024-12-03 21:44:16 --> Helper loaded: wpu_helper
INFO - 2024-12-03 21:44:16 --> Database Driver Class Initialized
INFO - 2024-12-03 21:44:56 --> Config Class Initialized
INFO - 2024-12-03 21:44:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 21:44:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 21:44:56 --> Utf8 Class Initialized
INFO - 2024-12-03 21:44:56 --> URI Class Initialized
DEBUG - 2024-12-03 21:44:56 --> No URI present. Default controller set.
INFO - 2024-12-03 21:44:56 --> Router Class Initialized
INFO - 2024-12-03 21:44:56 --> Output Class Initialized
INFO - 2024-12-03 21:44:56 --> Security Class Initialized
DEBUG - 2024-12-03 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 21:44:56 --> Input Class Initialized
INFO - 2024-12-03 21:44:56 --> Language Class Initialized
INFO - 2024-12-03 21:44:56 --> Loader Class Initialized
INFO - 2024-12-03 21:44:56 --> Helper loaded: url_helper
INFO - 2024-12-03 21:44:56 --> Helper loaded: file_helper
INFO - 2024-12-03 21:44:56 --> Helper loaded: security_helper
INFO - 2024-12-03 21:44:56 --> Helper loaded: wpu_helper
INFO - 2024-12-03 21:44:56 --> Database Driver Class Initialized
