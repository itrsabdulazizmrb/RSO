<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-23 06:02:09 --> Config Class Initialized
INFO - 2024-09-23 06:02:09 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:02:09 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:02:09 --> Utf8 Class Initialized
INFO - 2024-09-23 06:02:09 --> URI Class Initialized
DEBUG - 2024-09-23 06:02:09 --> No URI present. Default controller set.
INFO - 2024-09-23 06:02:09 --> Router Class Initialized
INFO - 2024-09-23 06:02:09 --> Output Class Initialized
INFO - 2024-09-23 06:02:09 --> Security Class Initialized
DEBUG - 2024-09-23 06:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:02:09 --> Input Class Initialized
INFO - 2024-09-23 06:02:09 --> Language Class Initialized
INFO - 2024-09-23 06:02:09 --> Loader Class Initialized
INFO - 2024-09-23 06:02:09 --> Helper loaded: url_helper
INFO - 2024-09-23 06:02:09 --> Helper loaded: file_helper
INFO - 2024-09-23 06:02:09 --> Helper loaded: security_helper
INFO - 2024-09-23 06:02:09 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:02:09 --> Database Driver Class Initialized
INFO - 2024-09-23 06:02:23 --> Config Class Initialized
INFO - 2024-09-23 06:02:23 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:02:23 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:02:23 --> Utf8 Class Initialized
INFO - 2024-09-23 06:02:23 --> URI Class Initialized
DEBUG - 2024-09-23 06:02:23 --> No URI present. Default controller set.
INFO - 2024-09-23 06:02:23 --> Router Class Initialized
INFO - 2024-09-23 06:02:23 --> Output Class Initialized
INFO - 2024-09-23 06:02:23 --> Security Class Initialized
DEBUG - 2024-09-23 06:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:02:23 --> Input Class Initialized
INFO - 2024-09-23 06:02:23 --> Language Class Initialized
INFO - 2024-09-23 06:02:23 --> Loader Class Initialized
INFO - 2024-09-23 06:02:23 --> Helper loaded: url_helper
INFO - 2024-09-23 06:02:23 --> Helper loaded: file_helper
INFO - 2024-09-23 06:02:23 --> Helper loaded: security_helper
INFO - 2024-09-23 06:02:23 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:02:23 --> Database Driver Class Initialized
INFO - 2024-09-23 06:32:19 --> Config Class Initialized
INFO - 2024-09-23 06:32:19 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:32:19 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:32:19 --> Utf8 Class Initialized
INFO - 2024-09-23 06:32:19 --> URI Class Initialized
DEBUG - 2024-09-23 06:32:19 --> No URI present. Default controller set.
INFO - 2024-09-23 06:32:19 --> Router Class Initialized
INFO - 2024-09-23 06:32:19 --> Output Class Initialized
INFO - 2024-09-23 06:32:19 --> Security Class Initialized
DEBUG - 2024-09-23 06:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:32:19 --> Input Class Initialized
INFO - 2024-09-23 06:32:19 --> Language Class Initialized
INFO - 2024-09-23 06:32:19 --> Loader Class Initialized
INFO - 2024-09-23 06:32:19 --> Helper loaded: url_helper
INFO - 2024-09-23 06:32:19 --> Helper loaded: file_helper
INFO - 2024-09-23 06:32:19 --> Helper loaded: security_helper
INFO - 2024-09-23 06:32:19 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:32:19 --> Database Driver Class Initialized
INFO - 2024-09-23 06:33:05 --> Config Class Initialized
INFO - 2024-09-23 06:33:05 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:33:05 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:33:05 --> Utf8 Class Initialized
INFO - 2024-09-23 06:33:05 --> URI Class Initialized
DEBUG - 2024-09-23 06:33:05 --> No URI present. Default controller set.
INFO - 2024-09-23 06:33:05 --> Router Class Initialized
INFO - 2024-09-23 06:33:05 --> Output Class Initialized
INFO - 2024-09-23 06:33:05 --> Security Class Initialized
DEBUG - 2024-09-23 06:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:33:05 --> Input Class Initialized
INFO - 2024-09-23 06:33:05 --> Language Class Initialized
INFO - 2024-09-23 06:33:05 --> Loader Class Initialized
INFO - 2024-09-23 06:33:05 --> Helper loaded: url_helper
INFO - 2024-09-23 06:33:05 --> Helper loaded: file_helper
INFO - 2024-09-23 06:33:05 --> Helper loaded: security_helper
INFO - 2024-09-23 06:33:05 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:33:05 --> Database Driver Class Initialized
INFO - 2024-09-23 06:33:33 --> Config Class Initialized
INFO - 2024-09-23 06:33:33 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:33:33 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:33:33 --> Utf8 Class Initialized
INFO - 2024-09-23 06:33:33 --> URI Class Initialized
INFO - 2024-09-23 06:33:33 --> Router Class Initialized
INFO - 2024-09-23 06:33:33 --> Output Class Initialized
INFO - 2024-09-23 06:33:33 --> Security Class Initialized
DEBUG - 2024-09-23 06:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:33:33 --> Input Class Initialized
INFO - 2024-09-23 06:33:33 --> Language Class Initialized
INFO - 2024-09-23 06:33:33 --> Loader Class Initialized
INFO - 2024-09-23 06:33:33 --> Helper loaded: url_helper
INFO - 2024-09-23 06:33:33 --> Helper loaded: file_helper
INFO - 2024-09-23 06:33:33 --> Helper loaded: security_helper
INFO - 2024-09-23 06:33:33 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:33:33 --> Database Driver Class Initialized
INFO - 2024-09-23 06:35:15 --> Config Class Initialized
INFO - 2024-09-23 06:35:15 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:35:15 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:35:15 --> Utf8 Class Initialized
INFO - 2024-09-23 06:35:15 --> URI Class Initialized
DEBUG - 2024-09-23 06:35:15 --> No URI present. Default controller set.
INFO - 2024-09-23 06:35:15 --> Router Class Initialized
INFO - 2024-09-23 06:35:15 --> Output Class Initialized
INFO - 2024-09-23 06:35:15 --> Security Class Initialized
DEBUG - 2024-09-23 06:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:35:15 --> Input Class Initialized
INFO - 2024-09-23 06:35:15 --> Language Class Initialized
INFO - 2024-09-23 06:35:15 --> Loader Class Initialized
INFO - 2024-09-23 06:35:15 --> Helper loaded: url_helper
INFO - 2024-09-23 06:35:15 --> Helper loaded: file_helper
INFO - 2024-09-23 06:35:15 --> Helper loaded: security_helper
INFO - 2024-09-23 06:35:15 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:35:15 --> Database Driver Class Initialized
INFO - 2024-09-23 06:48:39 --> Config Class Initialized
INFO - 2024-09-23 06:48:39 --> Hooks Class Initialized
DEBUG - 2024-09-23 06:48:39 --> UTF-8 Support Enabled
INFO - 2024-09-23 06:48:39 --> Utf8 Class Initialized
INFO - 2024-09-23 06:48:39 --> URI Class Initialized
DEBUG - 2024-09-23 06:48:39 --> No URI present. Default controller set.
INFO - 2024-09-23 06:48:39 --> Router Class Initialized
INFO - 2024-09-23 06:48:39 --> Output Class Initialized
INFO - 2024-09-23 06:48:39 --> Security Class Initialized
DEBUG - 2024-09-23 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 06:48:39 --> Input Class Initialized
INFO - 2024-09-23 06:48:39 --> Language Class Initialized
INFO - 2024-09-23 06:48:39 --> Loader Class Initialized
INFO - 2024-09-23 06:48:39 --> Helper loaded: url_helper
INFO - 2024-09-23 06:48:39 --> Helper loaded: file_helper
INFO - 2024-09-23 06:48:39 --> Helper loaded: security_helper
INFO - 2024-09-23 06:48:39 --> Helper loaded: wpu_helper
INFO - 2024-09-23 06:48:39 --> Database Driver Class Initialized
INFO - 2024-09-23 07:19:28 --> Config Class Initialized
INFO - 2024-09-23 07:19:28 --> Hooks Class Initialized
DEBUG - 2024-09-23 07:19:28 --> UTF-8 Support Enabled
INFO - 2024-09-23 07:19:28 --> Utf8 Class Initialized
INFO - 2024-09-23 07:19:28 --> URI Class Initialized
DEBUG - 2024-09-23 07:19:28 --> No URI present. Default controller set.
INFO - 2024-09-23 07:19:28 --> Router Class Initialized
INFO - 2024-09-23 07:19:28 --> Output Class Initialized
INFO - 2024-09-23 07:19:28 --> Security Class Initialized
DEBUG - 2024-09-23 07:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 07:19:28 --> Input Class Initialized
INFO - 2024-09-23 07:19:28 --> Language Class Initialized
INFO - 2024-09-23 07:19:28 --> Loader Class Initialized
INFO - 2024-09-23 07:19:28 --> Helper loaded: url_helper
INFO - 2024-09-23 07:19:28 --> Helper loaded: file_helper
INFO - 2024-09-23 07:19:28 --> Helper loaded: security_helper
INFO - 2024-09-23 07:19:28 --> Helper loaded: wpu_helper
INFO - 2024-09-23 07:19:28 --> Database Driver Class Initialized
ERROR - 2024-09-23 07:19:30 --> Unable to connect to the database
INFO - 2024-09-23 07:19:30 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 07:19:30 --> Config Class Initialized
INFO - 2024-09-23 07:19:30 --> Hooks Class Initialized
DEBUG - 2024-09-23 07:19:30 --> UTF-8 Support Enabled
INFO - 2024-09-23 07:19:30 --> Utf8 Class Initialized
INFO - 2024-09-23 07:19:30 --> URI Class Initialized
DEBUG - 2024-09-23 07:19:30 --> No URI present. Default controller set.
INFO - 2024-09-23 07:19:30 --> Router Class Initialized
INFO - 2024-09-23 07:19:30 --> Output Class Initialized
INFO - 2024-09-23 07:19:30 --> Security Class Initialized
DEBUG - 2024-09-23 07:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 07:19:30 --> Input Class Initialized
INFO - 2024-09-23 07:19:30 --> Language Class Initialized
INFO - 2024-09-23 07:19:30 --> Loader Class Initialized
INFO - 2024-09-23 07:19:30 --> Helper loaded: url_helper
INFO - 2024-09-23 07:19:30 --> Helper loaded: file_helper
INFO - 2024-09-23 07:19:30 --> Helper loaded: security_helper
INFO - 2024-09-23 07:19:30 --> Helper loaded: wpu_helper
INFO - 2024-09-23 07:19:30 --> Database Driver Class Initialized
INFO - 2024-09-23 07:19:31 --> Config Class Initialized
INFO - 2024-09-23 07:19:31 --> Hooks Class Initialized
DEBUG - 2024-09-23 07:19:31 --> UTF-8 Support Enabled
INFO - 2024-09-23 07:19:31 --> Utf8 Class Initialized
INFO - 2024-09-23 07:19:31 --> URI Class Initialized
DEBUG - 2024-09-23 07:19:31 --> No URI present. Default controller set.
INFO - 2024-09-23 07:19:31 --> Router Class Initialized
INFO - 2024-09-23 07:19:31 --> Output Class Initialized
INFO - 2024-09-23 07:19:31 --> Security Class Initialized
DEBUG - 2024-09-23 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 07:19:31 --> Input Class Initialized
INFO - 2024-09-23 07:19:31 --> Language Class Initialized
INFO - 2024-09-23 07:19:31 --> Loader Class Initialized
INFO - 2024-09-23 07:19:31 --> Helper loaded: url_helper
INFO - 2024-09-23 07:19:31 --> Helper loaded: file_helper
INFO - 2024-09-23 07:19:31 --> Helper loaded: security_helper
INFO - 2024-09-23 07:19:31 --> Helper loaded: wpu_helper
INFO - 2024-09-23 07:19:31 --> Database Driver Class Initialized
ERROR - 2024-09-23 07:19:33 --> Unable to connect to the database
ERROR - 2024-09-23 07:19:33 --> Unable to connect to the database
INFO - 2024-09-23 07:19:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 07:19:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 11:13:06 --> Config Class Initialized
INFO - 2024-09-23 11:13:06 --> Hooks Class Initialized
DEBUG - 2024-09-23 11:13:06 --> UTF-8 Support Enabled
INFO - 2024-09-23 11:13:06 --> Utf8 Class Initialized
INFO - 2024-09-23 11:13:06 --> URI Class Initialized
DEBUG - 2024-09-23 11:13:06 --> No URI present. Default controller set.
INFO - 2024-09-23 11:13:06 --> Router Class Initialized
INFO - 2024-09-23 11:13:06 --> Output Class Initialized
INFO - 2024-09-23 11:13:06 --> Security Class Initialized
DEBUG - 2024-09-23 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 11:13:06 --> Input Class Initialized
INFO - 2024-09-23 11:13:06 --> Language Class Initialized
INFO - 2024-09-23 11:13:06 --> Loader Class Initialized
INFO - 2024-09-23 11:13:06 --> Helper loaded: url_helper
INFO - 2024-09-23 11:13:06 --> Helper loaded: file_helper
INFO - 2024-09-23 11:13:06 --> Helper loaded: security_helper
INFO - 2024-09-23 11:13:06 --> Helper loaded: wpu_helper
INFO - 2024-09-23 11:13:06 --> Database Driver Class Initialized
ERROR - 2024-09-23 11:13:38 --> Unable to connect to the database
INFO - 2024-09-23 11:13:38 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 16:59:12 --> Config Class Initialized
INFO - 2024-09-23 16:59:12 --> Hooks Class Initialized
DEBUG - 2024-09-23 16:59:12 --> UTF-8 Support Enabled
INFO - 2024-09-23 16:59:12 --> Utf8 Class Initialized
INFO - 2024-09-23 16:59:12 --> URI Class Initialized
DEBUG - 2024-09-23 16:59:12 --> No URI present. Default controller set.
INFO - 2024-09-23 16:59:12 --> Router Class Initialized
INFO - 2024-09-23 16:59:12 --> Output Class Initialized
INFO - 2024-09-23 16:59:12 --> Security Class Initialized
DEBUG - 2024-09-23 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 16:59:12 --> Input Class Initialized
INFO - 2024-09-23 16:59:12 --> Language Class Initialized
INFO - 2024-09-23 16:59:12 --> Loader Class Initialized
INFO - 2024-09-23 16:59:12 --> Helper loaded: url_helper
INFO - 2024-09-23 16:59:12 --> Helper loaded: file_helper
INFO - 2024-09-23 16:59:12 --> Helper loaded: security_helper
INFO - 2024-09-23 16:59:12 --> Helper loaded: wpu_helper
INFO - 2024-09-23 16:59:12 --> Database Driver Class Initialized
ERROR - 2024-09-23 16:59:43 --> Unable to connect to the database
INFO - 2024-09-23 16:59:43 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 21:41:36 --> Config Class Initialized
INFO - 2024-09-23 21:41:36 --> Hooks Class Initialized
DEBUG - 2024-09-23 21:41:36 --> UTF-8 Support Enabled
INFO - 2024-09-23 21:41:36 --> Utf8 Class Initialized
INFO - 2024-09-23 21:41:36 --> URI Class Initialized
DEBUG - 2024-09-23 21:41:36 --> No URI present. Default controller set.
INFO - 2024-09-23 21:41:36 --> Router Class Initialized
INFO - 2024-09-23 21:41:36 --> Output Class Initialized
INFO - 2024-09-23 21:41:36 --> Security Class Initialized
DEBUG - 2024-09-23 21:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 21:41:36 --> Input Class Initialized
INFO - 2024-09-23 21:41:36 --> Language Class Initialized
INFO - 2024-09-23 21:41:36 --> Loader Class Initialized
INFO - 2024-09-23 21:41:36 --> Helper loaded: url_helper
INFO - 2024-09-23 21:41:36 --> Helper loaded: file_helper
INFO - 2024-09-23 21:41:36 --> Helper loaded: security_helper
INFO - 2024-09-23 21:41:36 --> Helper loaded: wpu_helper
INFO - 2024-09-23 21:41:36 --> Database Driver Class Initialized
ERROR - 2024-09-23 21:42:07 --> Unable to connect to the database
INFO - 2024-09-23 21:42:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-23 21:44:30 --> Config Class Initialized
INFO - 2024-09-23 21:44:30 --> Hooks Class Initialized
DEBUG - 2024-09-23 21:44:30 --> UTF-8 Support Enabled
INFO - 2024-09-23 21:44:30 --> Utf8 Class Initialized
INFO - 2024-09-23 21:44:30 --> URI Class Initialized
DEBUG - 2024-09-23 21:44:30 --> No URI present. Default controller set.
INFO - 2024-09-23 21:44:30 --> Router Class Initialized
INFO - 2024-09-23 21:44:30 --> Output Class Initialized
INFO - 2024-09-23 21:44:30 --> Security Class Initialized
DEBUG - 2024-09-23 21:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 21:44:30 --> Input Class Initialized
INFO - 2024-09-23 21:44:30 --> Language Class Initialized
INFO - 2024-09-23 21:44:30 --> Loader Class Initialized
INFO - 2024-09-23 21:44:30 --> Helper loaded: url_helper
INFO - 2024-09-23 21:44:30 --> Helper loaded: file_helper
INFO - 2024-09-23 21:44:30 --> Helper loaded: security_helper
INFO - 2024-09-23 21:44:30 --> Helper loaded: wpu_helper
INFO - 2024-09-23 21:44:30 --> Database Driver Class Initialized
INFO - 2024-09-23 21:44:30 --> Email Class Initialized
DEBUG - 2024-09-23 21:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-23 21:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 21:44:30 --> Helper loaded: form_helper
INFO - 2024-09-23 21:44:30 --> Form Validation Class Initialized
INFO - 2024-09-23 21:44:30 --> Controller Class Initialized
DEBUG - 2024-09-23 21:44:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-23 21:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-23 21:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-23 21:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-23 21:44:30 --> Final output sent to browser
DEBUG - 2024-09-23 21:44:30 --> Total execution time: 0.2152
INFO - 2024-09-23 22:01:47 --> Config Class Initialized
INFO - 2024-09-23 22:01:47 --> Hooks Class Initialized
DEBUG - 2024-09-23 22:01:47 --> UTF-8 Support Enabled
INFO - 2024-09-23 22:01:47 --> Utf8 Class Initialized
INFO - 2024-09-23 22:01:47 --> URI Class Initialized
INFO - 2024-09-23 22:01:47 --> Router Class Initialized
INFO - 2024-09-23 22:01:47 --> Output Class Initialized
INFO - 2024-09-23 22:01:47 --> Security Class Initialized
DEBUG - 2024-09-23 22:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 22:01:47 --> Input Class Initialized
INFO - 2024-09-23 22:01:47 --> Language Class Initialized
INFO - 2024-09-23 22:01:47 --> Loader Class Initialized
INFO - 2024-09-23 22:01:47 --> Helper loaded: url_helper
INFO - 2024-09-23 22:01:47 --> Helper loaded: file_helper
INFO - 2024-09-23 22:01:47 --> Helper loaded: security_helper
INFO - 2024-09-23 22:01:47 --> Helper loaded: wpu_helper
INFO - 2024-09-23 22:01:47 --> Database Driver Class Initialized
INFO - 2024-09-23 22:01:48 --> Email Class Initialized
DEBUG - 2024-09-23 22:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-23 22:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 22:01:48 --> Helper loaded: form_helper
INFO - 2024-09-23 22:01:48 --> Form Validation Class Initialized
INFO - 2024-09-23 22:01:48 --> Controller Class Initialized
DEBUG - 2024-09-23 22:01:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-23 22:01:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-23 22:01:48 --> Config Class Initialized
INFO - 2024-09-23 22:01:48 --> Hooks Class Initialized
DEBUG - 2024-09-23 22:01:48 --> UTF-8 Support Enabled
INFO - 2024-09-23 22:01:48 --> Utf8 Class Initialized
INFO - 2024-09-23 22:01:48 --> URI Class Initialized
INFO - 2024-09-23 22:01:48 --> Router Class Initialized
INFO - 2024-09-23 22:01:48 --> Output Class Initialized
INFO - 2024-09-23 22:01:48 --> Security Class Initialized
DEBUG - 2024-09-23 22:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-23 22:01:48 --> Input Class Initialized
INFO - 2024-09-23 22:01:48 --> Language Class Initialized
INFO - 2024-09-23 22:01:48 --> Loader Class Initialized
INFO - 2024-09-23 22:01:48 --> Helper loaded: url_helper
INFO - 2024-09-23 22:01:48 --> Helper loaded: file_helper
INFO - 2024-09-23 22:01:48 --> Helper loaded: security_helper
INFO - 2024-09-23 22:01:48 --> Helper loaded: wpu_helper
INFO - 2024-09-23 22:01:48 --> Database Driver Class Initialized
INFO - 2024-09-23 22:01:48 --> Email Class Initialized
DEBUG - 2024-09-23 22:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-23 22:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-23 22:01:48 --> Helper loaded: form_helper
INFO - 2024-09-23 22:01:48 --> Form Validation Class Initialized
INFO - 2024-09-23 22:01:48 --> Controller Class Initialized
INFO - 2024-09-23 22:01:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-23 22:01:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-23 22:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-23 22:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-23 22:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-23 22:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-23 22:01:48 --> Final output sent to browser
DEBUG - 2024-09-23 22:01:48 --> Total execution time: 0.5990
