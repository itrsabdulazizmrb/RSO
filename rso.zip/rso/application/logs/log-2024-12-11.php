<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-11 03:07:46 --> Config Class Initialized
INFO - 2024-12-11 03:07:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:07:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:07:46 --> Utf8 Class Initialized
INFO - 2024-12-11 03:07:46 --> URI Class Initialized
DEBUG - 2024-12-11 03:07:46 --> No URI present. Default controller set.
INFO - 2024-12-11 03:07:46 --> Router Class Initialized
INFO - 2024-12-11 03:07:46 --> Output Class Initialized
INFO - 2024-12-11 03:07:46 --> Security Class Initialized
DEBUG - 2024-12-11 03:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:07:46 --> Input Class Initialized
INFO - 2024-12-11 03:07:46 --> Language Class Initialized
INFO - 2024-12-11 03:07:46 --> Loader Class Initialized
INFO - 2024-12-11 03:07:46 --> Helper loaded: url_helper
INFO - 2024-12-11 03:07:46 --> Helper loaded: file_helper
INFO - 2024-12-11 03:07:46 --> Helper loaded: security_helper
INFO - 2024-12-11 03:07:46 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:07:46 --> Database Driver Class Initialized
INFO - 2024-12-11 03:07:46 --> Email Class Initialized
DEBUG - 2024-12-11 03:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:07:46 --> Helper loaded: form_helper
INFO - 2024-12-11 03:07:46 --> Form Validation Class Initialized
INFO - 2024-12-11 03:07:46 --> Controller Class Initialized
DEBUG - 2024-12-11 03:07:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:07:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 03:07:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 03:07:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 03:07:46 --> Final output sent to browser
DEBUG - 2024-12-11 03:07:46 --> Total execution time: 0.4353
INFO - 2024-12-11 03:07:51 --> Config Class Initialized
INFO - 2024-12-11 03:07:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:07:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:07:51 --> Utf8 Class Initialized
INFO - 2024-12-11 03:07:51 --> URI Class Initialized
INFO - 2024-12-11 03:07:51 --> Router Class Initialized
INFO - 2024-12-11 03:07:51 --> Output Class Initialized
INFO - 2024-12-11 03:07:51 --> Security Class Initialized
DEBUG - 2024-12-11 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:07:51 --> Input Class Initialized
INFO - 2024-12-11 03:07:51 --> Language Class Initialized
INFO - 2024-12-11 03:07:51 --> Loader Class Initialized
INFO - 2024-12-11 03:07:51 --> Helper loaded: url_helper
INFO - 2024-12-11 03:07:51 --> Helper loaded: file_helper
INFO - 2024-12-11 03:07:51 --> Helper loaded: security_helper
INFO - 2024-12-11 03:07:51 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:07:51 --> Database Driver Class Initialized
INFO - 2024-12-11 03:07:51 --> Email Class Initialized
DEBUG - 2024-12-11 03:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:07:51 --> Helper loaded: form_helper
INFO - 2024-12-11 03:07:51 --> Form Validation Class Initialized
INFO - 2024-12-11 03:07:51 --> Controller Class Initialized
DEBUG - 2024-12-11 03:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:07:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-11 03:07:52 --> Config Class Initialized
INFO - 2024-12-11 03:07:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:07:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:07:52 --> Utf8 Class Initialized
INFO - 2024-12-11 03:07:52 --> URI Class Initialized
INFO - 2024-12-11 03:07:52 --> Router Class Initialized
INFO - 2024-12-11 03:07:52 --> Output Class Initialized
INFO - 2024-12-11 03:07:52 --> Security Class Initialized
DEBUG - 2024-12-11 03:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:07:52 --> Input Class Initialized
INFO - 2024-12-11 03:07:52 --> Language Class Initialized
INFO - 2024-12-11 03:07:52 --> Loader Class Initialized
INFO - 2024-12-11 03:07:52 --> Helper loaded: url_helper
INFO - 2024-12-11 03:07:52 --> Helper loaded: file_helper
INFO - 2024-12-11 03:07:52 --> Helper loaded: security_helper
INFO - 2024-12-11 03:07:52 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:07:52 --> Database Driver Class Initialized
INFO - 2024-12-11 03:07:52 --> Email Class Initialized
DEBUG - 2024-12-11 03:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:07:52 --> Helper loaded: form_helper
INFO - 2024-12-11 03:07:52 --> Form Validation Class Initialized
INFO - 2024-12-11 03:07:52 --> Controller Class Initialized
INFO - 2024-12-11 03:07:52 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:07:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-11 03:07:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:07:53 --> Final output sent to browser
DEBUG - 2024-12-11 03:07:53 --> Total execution time: 1.0370
INFO - 2024-12-11 03:08:11 --> Config Class Initialized
INFO - 2024-12-11 03:08:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:08:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:08:11 --> Utf8 Class Initialized
INFO - 2024-12-11 03:08:11 --> URI Class Initialized
INFO - 2024-12-11 03:08:11 --> Router Class Initialized
INFO - 2024-12-11 03:08:11 --> Output Class Initialized
INFO - 2024-12-11 03:08:11 --> Security Class Initialized
DEBUG - 2024-12-11 03:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:08:11 --> Input Class Initialized
INFO - 2024-12-11 03:08:11 --> Language Class Initialized
INFO - 2024-12-11 03:08:11 --> Loader Class Initialized
INFO - 2024-12-11 03:08:11 --> Helper loaded: url_helper
INFO - 2024-12-11 03:08:11 --> Helper loaded: file_helper
INFO - 2024-12-11 03:08:11 --> Helper loaded: security_helper
INFO - 2024-12-11 03:08:11 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:08:11 --> Database Driver Class Initialized
INFO - 2024-12-11 03:08:11 --> Email Class Initialized
DEBUG - 2024-12-11 03:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:08:11 --> Helper loaded: form_helper
INFO - 2024-12-11 03:08:11 --> Form Validation Class Initialized
INFO - 2024-12-11 03:08:11 --> Controller Class Initialized
INFO - 2024-12-11 03:08:11 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:08:12 --> Final output sent to browser
DEBUG - 2024-12-11 03:08:12 --> Total execution time: 0.9758
INFO - 2024-12-11 03:08:25 --> Config Class Initialized
INFO - 2024-12-11 03:08:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:08:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:08:25 --> Utf8 Class Initialized
INFO - 2024-12-11 03:08:25 --> URI Class Initialized
INFO - 2024-12-11 03:08:25 --> Router Class Initialized
INFO - 2024-12-11 03:08:25 --> Output Class Initialized
INFO - 2024-12-11 03:08:25 --> Security Class Initialized
DEBUG - 2024-12-11 03:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:08:25 --> Input Class Initialized
INFO - 2024-12-11 03:08:25 --> Language Class Initialized
INFO - 2024-12-11 03:08:25 --> Loader Class Initialized
INFO - 2024-12-11 03:08:25 --> Helper loaded: url_helper
INFO - 2024-12-11 03:08:25 --> Helper loaded: file_helper
INFO - 2024-12-11 03:08:25 --> Helper loaded: security_helper
INFO - 2024-12-11 03:08:25 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:08:25 --> Database Driver Class Initialized
INFO - 2024-12-11 03:08:25 --> Email Class Initialized
DEBUG - 2024-12-11 03:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:08:25 --> Helper loaded: form_helper
INFO - 2024-12-11 03:08:25 --> Form Validation Class Initialized
INFO - 2024-12-11 03:08:25 --> Controller Class Initialized
INFO - 2024-12-11 03:08:25 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:08:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:08:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:08:26 --> Final output sent to browser
DEBUG - 2024-12-11 03:08:26 --> Total execution time: 0.9282
INFO - 2024-12-11 03:08:28 --> Config Class Initialized
INFO - 2024-12-11 03:08:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:08:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:08:28 --> Utf8 Class Initialized
INFO - 2024-12-11 03:08:28 --> URI Class Initialized
INFO - 2024-12-11 03:08:28 --> Router Class Initialized
INFO - 2024-12-11 03:08:28 --> Output Class Initialized
INFO - 2024-12-11 03:08:28 --> Security Class Initialized
DEBUG - 2024-12-11 03:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:08:28 --> Input Class Initialized
INFO - 2024-12-11 03:08:28 --> Language Class Initialized
INFO - 2024-12-11 03:08:28 --> Loader Class Initialized
INFO - 2024-12-11 03:08:28 --> Helper loaded: url_helper
INFO - 2024-12-11 03:08:28 --> Helper loaded: file_helper
INFO - 2024-12-11 03:08:28 --> Helper loaded: security_helper
INFO - 2024-12-11 03:08:28 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:08:28 --> Database Driver Class Initialized
INFO - 2024-12-11 03:08:28 --> Email Class Initialized
DEBUG - 2024-12-11 03:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:08:28 --> Helper loaded: form_helper
INFO - 2024-12-11 03:08:28 --> Form Validation Class Initialized
INFO - 2024-12-11 03:08:28 --> Controller Class Initialized
INFO - 2024-12-11 03:08:28 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:08:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:08:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:08:29 --> Final output sent to browser
DEBUG - 2024-12-11 03:08:29 --> Total execution time: 0.8802
INFO - 2024-12-11 03:08:30 --> Config Class Initialized
INFO - 2024-12-11 03:08:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:08:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:08:30 --> Utf8 Class Initialized
INFO - 2024-12-11 03:08:30 --> URI Class Initialized
INFO - 2024-12-11 03:08:30 --> Router Class Initialized
INFO - 2024-12-11 03:08:30 --> Output Class Initialized
INFO - 2024-12-11 03:08:30 --> Security Class Initialized
DEBUG - 2024-12-11 03:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:08:30 --> Input Class Initialized
INFO - 2024-12-11 03:08:30 --> Language Class Initialized
INFO - 2024-12-11 03:08:30 --> Loader Class Initialized
INFO - 2024-12-11 03:08:30 --> Helper loaded: url_helper
INFO - 2024-12-11 03:08:30 --> Helper loaded: file_helper
INFO - 2024-12-11 03:08:30 --> Helper loaded: security_helper
INFO - 2024-12-11 03:08:30 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:08:30 --> Database Driver Class Initialized
INFO - 2024-12-11 03:08:30 --> Email Class Initialized
DEBUG - 2024-12-11 03:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:08:30 --> Helper loaded: form_helper
INFO - 2024-12-11 03:08:30 --> Form Validation Class Initialized
INFO - 2024-12-11 03:08:30 --> Controller Class Initialized
INFO - 2024-12-11 03:08:30 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:08:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:08:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:08:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:08:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-11 03:08:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:08:31 --> Final output sent to browser
DEBUG - 2024-12-11 03:08:31 --> Total execution time: 0.9971
INFO - 2024-12-11 03:11:45 --> Config Class Initialized
INFO - 2024-12-11 03:11:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:45 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:45 --> URI Class Initialized
INFO - 2024-12-11 03:11:45 --> Router Class Initialized
INFO - 2024-12-11 03:11:45 --> Output Class Initialized
INFO - 2024-12-11 03:11:45 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:45 --> Input Class Initialized
INFO - 2024-12-11 03:11:45 --> Language Class Initialized
INFO - 2024-12-11 03:11:45 --> Loader Class Initialized
INFO - 2024-12-11 03:11:45 --> Helper loaded: url_helper
INFO - 2024-12-11 03:11:45 --> Helper loaded: file_helper
INFO - 2024-12-11 03:11:45 --> Helper loaded: security_helper
INFO - 2024-12-11 03:11:45 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:11:45 --> Database Driver Class Initialized
INFO - 2024-12-11 03:11:45 --> Email Class Initialized
DEBUG - 2024-12-11 03:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:11:45 --> Helper loaded: form_helper
INFO - 2024-12-11 03:11:45 --> Form Validation Class Initialized
INFO - 2024-12-11 03:11:45 --> Controller Class Initialized
INFO - 2024-12-11 03:11:45 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:11:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:11:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:11:46 --> Final output sent to browser
DEBUG - 2024-12-11 03:11:46 --> Total execution time: 0.9722
INFO - 2024-12-11 03:11:50 --> Config Class Initialized
INFO - 2024-12-11 03:11:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:50 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:50 --> URI Class Initialized
INFO - 2024-12-11 03:11:50 --> Router Class Initialized
INFO - 2024-12-11 03:11:50 --> Output Class Initialized
INFO - 2024-12-11 03:11:50 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:50 --> Input Class Initialized
INFO - 2024-12-11 03:11:50 --> Language Class Initialized
INFO - 2024-12-11 03:11:50 --> Loader Class Initialized
INFO - 2024-12-11 03:11:50 --> Helper loaded: url_helper
INFO - 2024-12-11 03:11:50 --> Helper loaded: file_helper
INFO - 2024-12-11 03:11:50 --> Helper loaded: security_helper
INFO - 2024-12-11 03:11:50 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:11:50 --> Database Driver Class Initialized
INFO - 2024-12-11 03:11:51 --> Email Class Initialized
DEBUG - 2024-12-11 03:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:11:51 --> Helper loaded: form_helper
INFO - 2024-12-11 03:11:51 --> Form Validation Class Initialized
INFO - 2024-12-11 03:11:51 --> Controller Class Initialized
INFO - 2024-12-11 03:11:51 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:11:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:11:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:11:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:11:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-11 03:11:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:11:51 --> Final output sent to browser
DEBUG - 2024-12-11 03:11:51 --> Total execution time: 1.0562
INFO - 2024-12-11 03:11:52 --> Config Class Initialized
INFO - 2024-12-11 03:11:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:52 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:52 --> URI Class Initialized
DEBUG - 2024-12-11 03:11:52 --> No URI present. Default controller set.
INFO - 2024-12-11 03:11:52 --> Router Class Initialized
INFO - 2024-12-11 03:11:52 --> Output Class Initialized
INFO - 2024-12-11 03:11:52 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:52 --> Input Class Initialized
INFO - 2024-12-11 03:11:52 --> Language Class Initialized
INFO - 2024-12-11 03:11:52 --> Loader Class Initialized
INFO - 2024-12-11 03:11:52 --> Helper loaded: url_helper
INFO - 2024-12-11 03:11:52 --> Helper loaded: file_helper
INFO - 2024-12-11 03:11:52 --> Helper loaded: security_helper
INFO - 2024-12-11 03:11:52 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:11:52 --> Database Driver Class Initialized
INFO - 2024-12-11 03:11:52 --> Email Class Initialized
DEBUG - 2024-12-11 03:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:11:52 --> Helper loaded: form_helper
INFO - 2024-12-11 03:11:52 --> Form Validation Class Initialized
INFO - 2024-12-11 03:11:52 --> Controller Class Initialized
DEBUG - 2024-12-11 03:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:11:53 --> Config Class Initialized
INFO - 2024-12-11 03:11:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:53 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:53 --> URI Class Initialized
INFO - 2024-12-11 03:11:53 --> Router Class Initialized
INFO - 2024-12-11 03:11:53 --> Output Class Initialized
INFO - 2024-12-11 03:11:53 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:53 --> Input Class Initialized
INFO - 2024-12-11 03:11:53 --> Language Class Initialized
ERROR - 2024-12-11 03:11:53 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:11:57 --> Config Class Initialized
INFO - 2024-12-11 03:11:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:57 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:57 --> URI Class Initialized
DEBUG - 2024-12-11 03:11:57 --> No URI present. Default controller set.
INFO - 2024-12-11 03:11:57 --> Router Class Initialized
INFO - 2024-12-11 03:11:57 --> Output Class Initialized
INFO - 2024-12-11 03:11:57 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:57 --> Input Class Initialized
INFO - 2024-12-11 03:11:57 --> Language Class Initialized
INFO - 2024-12-11 03:11:57 --> Loader Class Initialized
INFO - 2024-12-11 03:11:57 --> Helper loaded: url_helper
INFO - 2024-12-11 03:11:57 --> Helper loaded: file_helper
INFO - 2024-12-11 03:11:57 --> Helper loaded: security_helper
INFO - 2024-12-11 03:11:57 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:11:57 --> Database Driver Class Initialized
INFO - 2024-12-11 03:11:58 --> Email Class Initialized
DEBUG - 2024-12-11 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:11:58 --> Helper loaded: form_helper
INFO - 2024-12-11 03:11:58 --> Form Validation Class Initialized
INFO - 2024-12-11 03:11:58 --> Controller Class Initialized
DEBUG - 2024-12-11 03:11:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:11:58 --> Config Class Initialized
INFO - 2024-12-11 03:11:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:11:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:11:58 --> Utf8 Class Initialized
INFO - 2024-12-11 03:11:58 --> URI Class Initialized
INFO - 2024-12-11 03:11:58 --> Router Class Initialized
INFO - 2024-12-11 03:11:58 --> Output Class Initialized
INFO - 2024-12-11 03:11:58 --> Security Class Initialized
DEBUG - 2024-12-11 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:11:58 --> Input Class Initialized
INFO - 2024-12-11 03:11:58 --> Language Class Initialized
ERROR - 2024-12-11 03:11:58 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:12:06 --> Config Class Initialized
INFO - 2024-12-11 03:12:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:06 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:06 --> URI Class Initialized
DEBUG - 2024-12-11 03:12:06 --> No URI present. Default controller set.
INFO - 2024-12-11 03:12:06 --> Router Class Initialized
INFO - 2024-12-11 03:12:06 --> Output Class Initialized
INFO - 2024-12-11 03:12:06 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:06 --> Input Class Initialized
INFO - 2024-12-11 03:12:06 --> Language Class Initialized
INFO - 2024-12-11 03:12:06 --> Loader Class Initialized
INFO - 2024-12-11 03:12:06 --> Helper loaded: url_helper
INFO - 2024-12-11 03:12:06 --> Helper loaded: file_helper
INFO - 2024-12-11 03:12:06 --> Helper loaded: security_helper
INFO - 2024-12-11 03:12:06 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:12:06 --> Database Driver Class Initialized
INFO - 2024-12-11 03:12:07 --> Email Class Initialized
DEBUG - 2024-12-11 03:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:12:07 --> Helper loaded: form_helper
INFO - 2024-12-11 03:12:07 --> Form Validation Class Initialized
INFO - 2024-12-11 03:12:07 --> Controller Class Initialized
DEBUG - 2024-12-11 03:12:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:12:07 --> Config Class Initialized
INFO - 2024-12-11 03:12:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:07 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:07 --> URI Class Initialized
INFO - 2024-12-11 03:12:07 --> Router Class Initialized
INFO - 2024-12-11 03:12:07 --> Output Class Initialized
INFO - 2024-12-11 03:12:07 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:07 --> Input Class Initialized
INFO - 2024-12-11 03:12:07 --> Language Class Initialized
ERROR - 2024-12-11 03:12:07 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:12:13 --> Config Class Initialized
INFO - 2024-12-11 03:12:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:13 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:13 --> URI Class Initialized
INFO - 2024-12-11 03:12:13 --> Router Class Initialized
INFO - 2024-12-11 03:12:13 --> Output Class Initialized
INFO - 2024-12-11 03:12:13 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:13 --> Input Class Initialized
INFO - 2024-12-11 03:12:13 --> Language Class Initialized
ERROR - 2024-12-11 03:12:13 --> 404 Page Not Found: Login/index
INFO - 2024-12-11 03:12:20 --> Config Class Initialized
INFO - 2024-12-11 03:12:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:20 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:20 --> URI Class Initialized
DEBUG - 2024-12-11 03:12:20 --> No URI present. Default controller set.
INFO - 2024-12-11 03:12:20 --> Router Class Initialized
INFO - 2024-12-11 03:12:20 --> Output Class Initialized
INFO - 2024-12-11 03:12:20 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:20 --> Input Class Initialized
INFO - 2024-12-11 03:12:20 --> Language Class Initialized
INFO - 2024-12-11 03:12:20 --> Loader Class Initialized
INFO - 2024-12-11 03:12:20 --> Helper loaded: url_helper
INFO - 2024-12-11 03:12:20 --> Helper loaded: file_helper
INFO - 2024-12-11 03:12:20 --> Helper loaded: security_helper
INFO - 2024-12-11 03:12:20 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:12:20 --> Database Driver Class Initialized
INFO - 2024-12-11 03:12:21 --> Email Class Initialized
DEBUG - 2024-12-11 03:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:12:21 --> Helper loaded: form_helper
INFO - 2024-12-11 03:12:21 --> Form Validation Class Initialized
INFO - 2024-12-11 03:12:21 --> Controller Class Initialized
DEBUG - 2024-12-11 03:12:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:12:21 --> Config Class Initialized
INFO - 2024-12-11 03:12:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:21 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:21 --> URI Class Initialized
INFO - 2024-12-11 03:12:21 --> Router Class Initialized
INFO - 2024-12-11 03:12:21 --> Output Class Initialized
INFO - 2024-12-11 03:12:21 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:21 --> Input Class Initialized
INFO - 2024-12-11 03:12:21 --> Language Class Initialized
ERROR - 2024-12-11 03:12:21 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:12:35 --> Config Class Initialized
INFO - 2024-12-11 03:12:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:35 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:35 --> URI Class Initialized
DEBUG - 2024-12-11 03:12:35 --> No URI present. Default controller set.
INFO - 2024-12-11 03:12:35 --> Router Class Initialized
INFO - 2024-12-11 03:12:35 --> Output Class Initialized
INFO - 2024-12-11 03:12:35 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:35 --> Input Class Initialized
INFO - 2024-12-11 03:12:35 --> Language Class Initialized
INFO - 2024-12-11 03:12:35 --> Loader Class Initialized
INFO - 2024-12-11 03:12:35 --> Helper loaded: url_helper
INFO - 2024-12-11 03:12:35 --> Helper loaded: file_helper
INFO - 2024-12-11 03:12:35 --> Helper loaded: security_helper
INFO - 2024-12-11 03:12:35 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:12:35 --> Database Driver Class Initialized
INFO - 2024-12-11 03:12:36 --> Email Class Initialized
DEBUG - 2024-12-11 03:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:12:36 --> Helper loaded: form_helper
INFO - 2024-12-11 03:12:36 --> Form Validation Class Initialized
INFO - 2024-12-11 03:12:36 --> Controller Class Initialized
DEBUG - 2024-12-11 03:12:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:12:36 --> Config Class Initialized
INFO - 2024-12-11 03:12:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:36 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:36 --> URI Class Initialized
INFO - 2024-12-11 03:12:36 --> Router Class Initialized
INFO - 2024-12-11 03:12:36 --> Output Class Initialized
INFO - 2024-12-11 03:12:36 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:36 --> Input Class Initialized
INFO - 2024-12-11 03:12:36 --> Language Class Initialized
ERROR - 2024-12-11 03:12:36 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:12:53 --> Config Class Initialized
INFO - 2024-12-11 03:12:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:53 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:53 --> URI Class Initialized
DEBUG - 2024-12-11 03:12:53 --> No URI present. Default controller set.
INFO - 2024-12-11 03:12:53 --> Router Class Initialized
INFO - 2024-12-11 03:12:53 --> Output Class Initialized
INFO - 2024-12-11 03:12:53 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:53 --> Input Class Initialized
INFO - 2024-12-11 03:12:53 --> Language Class Initialized
INFO - 2024-12-11 03:12:53 --> Loader Class Initialized
INFO - 2024-12-11 03:12:53 --> Helper loaded: url_helper
INFO - 2024-12-11 03:12:53 --> Helper loaded: file_helper
INFO - 2024-12-11 03:12:53 --> Helper loaded: security_helper
INFO - 2024-12-11 03:12:53 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:12:53 --> Database Driver Class Initialized
INFO - 2024-12-11 03:12:53 --> Email Class Initialized
DEBUG - 2024-12-11 03:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:12:53 --> Helper loaded: form_helper
INFO - 2024-12-11 03:12:53 --> Form Validation Class Initialized
INFO - 2024-12-11 03:12:53 --> Controller Class Initialized
DEBUG - 2024-12-11 03:12:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:12:54 --> Config Class Initialized
INFO - 2024-12-11 03:12:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:12:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:12:54 --> Utf8 Class Initialized
INFO - 2024-12-11 03:12:54 --> URI Class Initialized
INFO - 2024-12-11 03:12:54 --> Router Class Initialized
INFO - 2024-12-11 03:12:54 --> Output Class Initialized
INFO - 2024-12-11 03:12:54 --> Security Class Initialized
DEBUG - 2024-12-11 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:12:54 --> Input Class Initialized
INFO - 2024-12-11 03:12:54 --> Language Class Initialized
ERROR - 2024-12-11 03:12:54 --> 404 Page Not Found: User/index
INFO - 2024-12-11 03:13:08 --> Config Class Initialized
INFO - 2024-12-11 03:13:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:13:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:13:08 --> Utf8 Class Initialized
INFO - 2024-12-11 03:13:08 --> URI Class Initialized
INFO - 2024-12-11 03:13:08 --> Router Class Initialized
INFO - 2024-12-11 03:13:08 --> Output Class Initialized
INFO - 2024-12-11 03:13:08 --> Security Class Initialized
DEBUG - 2024-12-11 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:13:08 --> Input Class Initialized
INFO - 2024-12-11 03:13:08 --> Language Class Initialized
ERROR - 2024-12-11 03:13:08 --> 404 Page Not Found: Home/index
INFO - 2024-12-11 03:13:15 --> Config Class Initialized
INFO - 2024-12-11 03:13:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:13:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:13:15 --> Utf8 Class Initialized
INFO - 2024-12-11 03:13:15 --> URI Class Initialized
INFO - 2024-12-11 03:13:15 --> Router Class Initialized
INFO - 2024-12-11 03:13:15 --> Output Class Initialized
INFO - 2024-12-11 03:13:15 --> Security Class Initialized
DEBUG - 2024-12-11 03:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:13:15 --> Input Class Initialized
INFO - 2024-12-11 03:13:15 --> Language Class Initialized
ERROR - 2024-12-11 03:13:15 --> 404 Page Not Found: Login/index
INFO - 2024-12-11 03:13:23 --> Config Class Initialized
INFO - 2024-12-11 03:13:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:13:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:13:23 --> Utf8 Class Initialized
INFO - 2024-12-11 03:13:23 --> URI Class Initialized
INFO - 2024-12-11 03:13:23 --> Router Class Initialized
INFO - 2024-12-11 03:13:23 --> Output Class Initialized
INFO - 2024-12-11 03:13:23 --> Security Class Initialized
DEBUG - 2024-12-11 03:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:13:23 --> Input Class Initialized
INFO - 2024-12-11 03:13:23 --> Language Class Initialized
INFO - 2024-12-11 03:13:23 --> Loader Class Initialized
INFO - 2024-12-11 03:13:23 --> Helper loaded: url_helper
INFO - 2024-12-11 03:13:23 --> Helper loaded: file_helper
INFO - 2024-12-11 03:13:23 --> Helper loaded: security_helper
INFO - 2024-12-11 03:13:23 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:13:23 --> Database Driver Class Initialized
INFO - 2024-12-11 03:13:23 --> Email Class Initialized
DEBUG - 2024-12-11 03:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:13:23 --> Helper loaded: form_helper
INFO - 2024-12-11 03:13:23 --> Form Validation Class Initialized
INFO - 2024-12-11 03:13:23 --> Controller Class Initialized
INFO - 2024-12-11 03:13:23 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:13:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-11 03:13:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:13:24 --> Final output sent to browser
DEBUG - 2024-12-11 03:13:24 --> Total execution time: 1.0042
INFO - 2024-12-11 03:40:45 --> Config Class Initialized
INFO - 2024-12-11 03:40:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:40:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:40:45 --> Utf8 Class Initialized
INFO - 2024-12-11 03:40:45 --> URI Class Initialized
INFO - 2024-12-11 03:40:45 --> Router Class Initialized
INFO - 2024-12-11 03:40:45 --> Output Class Initialized
INFO - 2024-12-11 03:40:45 --> Security Class Initialized
DEBUG - 2024-12-11 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:40:45 --> Input Class Initialized
INFO - 2024-12-11 03:40:45 --> Language Class Initialized
INFO - 2024-12-11 03:40:45 --> Loader Class Initialized
INFO - 2024-12-11 03:40:45 --> Helper loaded: url_helper
INFO - 2024-12-11 03:40:45 --> Helper loaded: file_helper
INFO - 2024-12-11 03:40:45 --> Helper loaded: security_helper
INFO - 2024-12-11 03:40:45 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:40:45 --> Database Driver Class Initialized
INFO - 2024-12-11 03:40:46 --> Email Class Initialized
DEBUG - 2024-12-11 03:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:40:46 --> Helper loaded: form_helper
INFO - 2024-12-11 03:40:46 --> Form Validation Class Initialized
INFO - 2024-12-11 03:40:46 --> Controller Class Initialized
INFO - 2024-12-11 03:40:46 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:40:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:40:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:40:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:40:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:40:46 --> Final output sent to browser
DEBUG - 2024-12-11 03:40:46 --> Total execution time: 0.9369
INFO - 2024-12-11 03:41:00 --> Config Class Initialized
INFO - 2024-12-11 03:41:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:41:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:41:00 --> Utf8 Class Initialized
INFO - 2024-12-11 03:41:00 --> URI Class Initialized
INFO - 2024-12-11 03:41:00 --> Router Class Initialized
INFO - 2024-12-11 03:41:00 --> Output Class Initialized
INFO - 2024-12-11 03:41:00 --> Security Class Initialized
DEBUG - 2024-12-11 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:41:00 --> Input Class Initialized
INFO - 2024-12-11 03:41:00 --> Language Class Initialized
INFO - 2024-12-11 03:41:00 --> Loader Class Initialized
INFO - 2024-12-11 03:41:00 --> Helper loaded: url_helper
INFO - 2024-12-11 03:41:00 --> Helper loaded: file_helper
INFO - 2024-12-11 03:41:00 --> Helper loaded: security_helper
INFO - 2024-12-11 03:41:00 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:41:00 --> Database Driver Class Initialized
INFO - 2024-12-11 03:41:00 --> Email Class Initialized
DEBUG - 2024-12-11 03:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:41:00 --> Helper loaded: form_helper
INFO - 2024-12-11 03:41:00 --> Form Validation Class Initialized
INFO - 2024-12-11 03:41:00 --> Controller Class Initialized
INFO - 2024-12-11 03:41:00 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:41:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:41:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-11 03:41:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-11 03:41:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-11 03:41:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-11 03:41:01 --> Final output sent to browser
DEBUG - 2024-12-11 03:41:01 --> Total execution time: 0.8442
INFO - 2024-12-11 03:41:32 --> Config Class Initialized
INFO - 2024-12-11 03:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 03:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 03:41:32 --> Utf8 Class Initialized
INFO - 2024-12-11 03:41:32 --> URI Class Initialized
INFO - 2024-12-11 03:41:32 --> Router Class Initialized
INFO - 2024-12-11 03:41:32 --> Output Class Initialized
INFO - 2024-12-11 03:41:32 --> Security Class Initialized
DEBUG - 2024-12-11 03:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 03:41:32 --> Input Class Initialized
INFO - 2024-12-11 03:41:32 --> Language Class Initialized
INFO - 2024-12-11 03:41:32 --> Loader Class Initialized
INFO - 2024-12-11 03:41:32 --> Helper loaded: url_helper
INFO - 2024-12-11 03:41:32 --> Helper loaded: file_helper
INFO - 2024-12-11 03:41:32 --> Helper loaded: security_helper
INFO - 2024-12-11 03:41:32 --> Helper loaded: wpu_helper
INFO - 2024-12-11 03:41:32 --> Database Driver Class Initialized
INFO - 2024-12-11 03:41:32 --> Email Class Initialized
DEBUG - 2024-12-11 03:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 03:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 03:41:32 --> Helper loaded: form_helper
INFO - 2024-12-11 03:41:32 --> Form Validation Class Initialized
INFO - 2024-12-11 03:41:32 --> Controller Class Initialized
INFO - 2024-12-11 03:41:32 --> Model "Antrol_model" initialized
DEBUG - 2024-12-11 03:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 03:41:33 --> Final output sent to browser
DEBUG - 2024-12-11 03:41:33 --> Total execution time: 0.7491
INFO - 2024-12-11 07:51:18 --> Config Class Initialized
INFO - 2024-12-11 07:51:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:18 --> URI Class Initialized
INFO - 2024-12-11 07:51:18 --> Router Class Initialized
INFO - 2024-12-11 07:51:18 --> Output Class Initialized
INFO - 2024-12-11 07:51:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:18 --> Input Class Initialized
INFO - 2024-12-11 07:51:18 --> Language Class Initialized
ERROR - 2024-12-11 07:51:18 --> 404 Page Not Found: Wp-admin/6g2YLrfanMN.php
INFO - 2024-12-11 07:51:24 --> Config Class Initialized
INFO - 2024-12-11 07:51:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:24 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:24 --> URI Class Initialized
INFO - 2024-12-11 07:51:24 --> Router Class Initialized
INFO - 2024-12-11 07:51:24 --> Output Class Initialized
INFO - 2024-12-11 07:51:24 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:24 --> Input Class Initialized
INFO - 2024-12-11 07:51:24 --> Language Class Initialized
ERROR - 2024-12-11 07:51:24 --> 404 Page Not Found: Wp-admin/3RLav89rgCo.php
INFO - 2024-12-11 07:51:24 --> Config Class Initialized
INFO - 2024-12-11 07:51:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:24 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:24 --> URI Class Initialized
INFO - 2024-12-11 07:51:24 --> Router Class Initialized
INFO - 2024-12-11 07:51:24 --> Output Class Initialized
INFO - 2024-12-11 07:51:24 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:24 --> Input Class Initialized
INFO - 2024-12-11 07:51:24 --> Language Class Initialized
ERROR - 2024-12-11 07:51:24 --> 404 Page Not Found: Wp-admin/tnzZFs1UJCI.php
INFO - 2024-12-11 07:51:30 --> Config Class Initialized
INFO - 2024-12-11 07:51:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:30 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:30 --> URI Class Initialized
INFO - 2024-12-11 07:51:30 --> Router Class Initialized
INFO - 2024-12-11 07:51:30 --> Output Class Initialized
INFO - 2024-12-11 07:51:30 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:30 --> Input Class Initialized
INFO - 2024-12-11 07:51:30 --> Language Class Initialized
ERROR - 2024-12-11 07:51:30 --> 404 Page Not Found: ACZG7WrONXuphp/index
INFO - 2024-12-11 07:51:33 --> Config Class Initialized
INFO - 2024-12-11 07:51:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:33 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:33 --> URI Class Initialized
INFO - 2024-12-11 07:51:33 --> Router Class Initialized
INFO - 2024-12-11 07:51:33 --> Output Class Initialized
INFO - 2024-12-11 07:51:33 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:33 --> Input Class Initialized
INFO - 2024-12-11 07:51:33 --> Language Class Initialized
ERROR - 2024-12-11 07:51:33 --> 404 Page Not Found: CZJDzAmiwb5php/index
INFO - 2024-12-11 07:51:33 --> Config Class Initialized
INFO - 2024-12-11 07:51:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:33 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:33 --> URI Class Initialized
INFO - 2024-12-11 07:51:33 --> Router Class Initialized
INFO - 2024-12-11 07:51:33 --> Output Class Initialized
INFO - 2024-12-11 07:51:33 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:33 --> Input Class Initialized
INFO - 2024-12-11 07:51:33 --> Language Class Initialized
ERROR - 2024-12-11 07:51:33 --> 404 Page Not Found: Wp-admin/E5gwdQqtVrl.php
INFO - 2024-12-11 07:51:34 --> Config Class Initialized
INFO - 2024-12-11 07:51:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:34 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:34 --> URI Class Initialized
INFO - 2024-12-11 07:51:34 --> Router Class Initialized
INFO - 2024-12-11 07:51:34 --> Output Class Initialized
INFO - 2024-12-11 07:51:34 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:34 --> Input Class Initialized
INFO - 2024-12-11 07:51:34 --> Language Class Initialized
ERROR - 2024-12-11 07:51:34 --> 404 Page Not Found: Wp-admin/RCKGnLUlwFW.php
INFO - 2024-12-11 07:51:36 --> Config Class Initialized
INFO - 2024-12-11 07:51:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:36 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:36 --> URI Class Initialized
INFO - 2024-12-11 07:51:36 --> Router Class Initialized
INFO - 2024-12-11 07:51:36 --> Output Class Initialized
INFO - 2024-12-11 07:51:36 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:36 --> Input Class Initialized
INFO - 2024-12-11 07:51:36 --> Language Class Initialized
ERROR - 2024-12-11 07:51:36 --> 404 Page Not Found: Wp-admin/LTOXBIdvFcW.php
INFO - 2024-12-11 07:51:39 --> Config Class Initialized
INFO - 2024-12-11 07:51:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:39 --> URI Class Initialized
INFO - 2024-12-11 07:51:39 --> Router Class Initialized
INFO - 2024-12-11 07:51:39 --> Output Class Initialized
INFO - 2024-12-11 07:51:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:39 --> Input Class Initialized
INFO - 2024-12-11 07:51:39 --> Language Class Initialized
ERROR - 2024-12-11 07:51:39 --> 404 Page Not Found: Wp-admin/uFXL4dV28Eg.php
INFO - 2024-12-11 07:51:39 --> Config Class Initialized
INFO - 2024-12-11 07:51:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:39 --> URI Class Initialized
INFO - 2024-12-11 07:51:39 --> Router Class Initialized
INFO - 2024-12-11 07:51:39 --> Output Class Initialized
INFO - 2024-12-11 07:51:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:39 --> Input Class Initialized
INFO - 2024-12-11 07:51:39 --> Language Class Initialized
ERROR - 2024-12-11 07:51:39 --> 404 Page Not Found: Wp-admin/ziS58MyPkwJ.php
INFO - 2024-12-11 07:51:52 --> Config Class Initialized
INFO - 2024-12-11 07:51:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:52 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:52 --> URI Class Initialized
INFO - 2024-12-11 07:51:52 --> Router Class Initialized
INFO - 2024-12-11 07:51:52 --> Output Class Initialized
INFO - 2024-12-11 07:51:52 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:52 --> Input Class Initialized
INFO - 2024-12-11 07:51:52 --> Language Class Initialized
ERROR - 2024-12-11 07:51:52 --> 404 Page Not Found: 5akMrG39yXhphp/index
INFO - 2024-12-11 07:51:53 --> Config Class Initialized
INFO - 2024-12-11 07:51:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:53 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:53 --> URI Class Initialized
INFO - 2024-12-11 07:51:53 --> Router Class Initialized
INFO - 2024-12-11 07:51:53 --> Output Class Initialized
INFO - 2024-12-11 07:51:53 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:53 --> Input Class Initialized
INFO - 2024-12-11 07:51:53 --> Language Class Initialized
ERROR - 2024-12-11 07:51:53 --> 404 Page Not Found: Wp-admin/DFbY82BZ6xI.php
INFO - 2024-12-11 07:51:54 --> Config Class Initialized
INFO - 2024-12-11 07:51:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:54 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:54 --> URI Class Initialized
INFO - 2024-12-11 07:51:54 --> Router Class Initialized
INFO - 2024-12-11 07:51:54 --> Output Class Initialized
INFO - 2024-12-11 07:51:54 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:54 --> Input Class Initialized
INFO - 2024-12-11 07:51:54 --> Language Class Initialized
ERROR - 2024-12-11 07:51:54 --> 404 Page Not Found: ElGhjnL9Bpxphp/index
INFO - 2024-12-11 07:51:58 --> Config Class Initialized
INFO - 2024-12-11 07:51:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:51:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:51:58 --> Utf8 Class Initialized
INFO - 2024-12-11 07:51:58 --> URI Class Initialized
INFO - 2024-12-11 07:51:58 --> Router Class Initialized
INFO - 2024-12-11 07:51:58 --> Output Class Initialized
INFO - 2024-12-11 07:51:58 --> Security Class Initialized
DEBUG - 2024-12-11 07:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:51:58 --> Input Class Initialized
INFO - 2024-12-11 07:51:58 --> Language Class Initialized
ERROR - 2024-12-11 07:51:58 --> 404 Page Not Found: 3HyUQSpoAMPphp/index
INFO - 2024-12-11 07:52:00 --> Config Class Initialized
INFO - 2024-12-11 07:52:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:00 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:00 --> URI Class Initialized
INFO - 2024-12-11 07:52:00 --> Router Class Initialized
INFO - 2024-12-11 07:52:00 --> Output Class Initialized
INFO - 2024-12-11 07:52:00 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:00 --> Input Class Initialized
INFO - 2024-12-11 07:52:00 --> Language Class Initialized
ERROR - 2024-12-11 07:52:00 --> 404 Page Not Found: Wp-admin/Xn3K5sCOrbe.php
INFO - 2024-12-11 07:52:03 --> Config Class Initialized
INFO - 2024-12-11 07:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:03 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:03 --> URI Class Initialized
INFO - 2024-12-11 07:52:03 --> Router Class Initialized
INFO - 2024-12-11 07:52:03 --> Output Class Initialized
INFO - 2024-12-11 07:52:03 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:03 --> Input Class Initialized
INFO - 2024-12-11 07:52:03 --> Language Class Initialized
ERROR - 2024-12-11 07:52:03 --> 404 Page Not Found: Wp-admin/692gMP8ZXdJ.php
INFO - 2024-12-11 07:52:07 --> Config Class Initialized
INFO - 2024-12-11 07:52:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:07 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:07 --> URI Class Initialized
INFO - 2024-12-11 07:52:07 --> Router Class Initialized
INFO - 2024-12-11 07:52:07 --> Output Class Initialized
INFO - 2024-12-11 07:52:07 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:07 --> Input Class Initialized
INFO - 2024-12-11 07:52:07 --> Language Class Initialized
ERROR - 2024-12-11 07:52:07 --> 404 Page Not Found: NKoAnW59aL2php/index
INFO - 2024-12-11 07:52:09 --> Config Class Initialized
INFO - 2024-12-11 07:52:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:09 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:09 --> URI Class Initialized
INFO - 2024-12-11 07:52:09 --> Router Class Initialized
INFO - 2024-12-11 07:52:09 --> Output Class Initialized
INFO - 2024-12-11 07:52:09 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:09 --> Input Class Initialized
INFO - 2024-12-11 07:52:09 --> Language Class Initialized
ERROR - 2024-12-11 07:52:09 --> 404 Page Not Found: Wp-admin/OrUg1MbtNFJ.php
INFO - 2024-12-11 07:52:10 --> Config Class Initialized
INFO - 2024-12-11 07:52:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:10 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:10 --> URI Class Initialized
INFO - 2024-12-11 07:52:10 --> Router Class Initialized
INFO - 2024-12-11 07:52:10 --> Output Class Initialized
INFO - 2024-12-11 07:52:10 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:10 --> Input Class Initialized
INFO - 2024-12-11 07:52:10 --> Language Class Initialized
ERROR - 2024-12-11 07:52:10 --> 404 Page Not Found: Wp-admin/lnq1Yfd2K7c.php
INFO - 2024-12-11 07:52:13 --> Config Class Initialized
INFO - 2024-12-11 07:52:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:13 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:13 --> URI Class Initialized
INFO - 2024-12-11 07:52:13 --> Router Class Initialized
INFO - 2024-12-11 07:52:13 --> Output Class Initialized
INFO - 2024-12-11 07:52:13 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:13 --> Input Class Initialized
INFO - 2024-12-11 07:52:13 --> Language Class Initialized
ERROR - 2024-12-11 07:52:13 --> 404 Page Not Found: Wp-admin/ztZiL32lUN9.php
INFO - 2024-12-11 07:52:17 --> Config Class Initialized
INFO - 2024-12-11 07:52:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:17 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:17 --> URI Class Initialized
INFO - 2024-12-11 07:52:17 --> Router Class Initialized
INFO - 2024-12-11 07:52:17 --> Output Class Initialized
INFO - 2024-12-11 07:52:17 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:17 --> Input Class Initialized
INFO - 2024-12-11 07:52:17 --> Language Class Initialized
ERROR - 2024-12-11 07:52:17 --> 404 Page Not Found: Wp-admin/ERm13uWKQkf.php
INFO - 2024-12-11 07:52:21 --> Config Class Initialized
INFO - 2024-12-11 07:52:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:21 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:21 --> URI Class Initialized
INFO - 2024-12-11 07:52:21 --> Router Class Initialized
INFO - 2024-12-11 07:52:21 --> Output Class Initialized
INFO - 2024-12-11 07:52:21 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:21 --> Input Class Initialized
INFO - 2024-12-11 07:52:21 --> Language Class Initialized
ERROR - 2024-12-11 07:52:21 --> 404 Page Not Found: Wp-admin/pSwNlF4D3OK.php
INFO - 2024-12-11 07:52:26 --> Config Class Initialized
INFO - 2024-12-11 07:52:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:26 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:26 --> URI Class Initialized
INFO - 2024-12-11 07:52:26 --> Router Class Initialized
INFO - 2024-12-11 07:52:26 --> Output Class Initialized
INFO - 2024-12-11 07:52:26 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:26 --> Input Class Initialized
INFO - 2024-12-11 07:52:26 --> Language Class Initialized
ERROR - 2024-12-11 07:52:26 --> 404 Page Not Found: WIdU3XS1pnKphp/index
INFO - 2024-12-11 07:52:29 --> Config Class Initialized
INFO - 2024-12-11 07:52:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:29 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:29 --> URI Class Initialized
INFO - 2024-12-11 07:52:29 --> Router Class Initialized
INFO - 2024-12-11 07:52:29 --> Output Class Initialized
INFO - 2024-12-11 07:52:29 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:29 --> Input Class Initialized
INFO - 2024-12-11 07:52:29 --> Language Class Initialized
ERROR - 2024-12-11 07:52:29 --> 404 Page Not Found: BVkcURsKmXYphp/index
INFO - 2024-12-11 07:52:33 --> Config Class Initialized
INFO - 2024-12-11 07:52:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:33 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:33 --> URI Class Initialized
INFO - 2024-12-11 07:52:33 --> Router Class Initialized
INFO - 2024-12-11 07:52:33 --> Output Class Initialized
INFO - 2024-12-11 07:52:33 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:33 --> Input Class Initialized
INFO - 2024-12-11 07:52:33 --> Language Class Initialized
ERROR - 2024-12-11 07:52:33 --> 404 Page Not Found: Wp-admin/VGi9Ulu3cNK.php
INFO - 2024-12-11 07:52:44 --> Config Class Initialized
INFO - 2024-12-11 07:52:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:44 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:44 --> URI Class Initialized
INFO - 2024-12-11 07:52:44 --> Router Class Initialized
INFO - 2024-12-11 07:52:44 --> Output Class Initialized
INFO - 2024-12-11 07:52:44 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:44 --> Input Class Initialized
INFO - 2024-12-11 07:52:44 --> Language Class Initialized
ERROR - 2024-12-11 07:52:44 --> 404 Page Not Found: BvNqadf139Qphp/index
INFO - 2024-12-11 07:52:45 --> Config Class Initialized
INFO - 2024-12-11 07:52:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:45 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:45 --> URI Class Initialized
INFO - 2024-12-11 07:52:45 --> Router Class Initialized
INFO - 2024-12-11 07:52:45 --> Output Class Initialized
INFO - 2024-12-11 07:52:45 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:45 --> Input Class Initialized
INFO - 2024-12-11 07:52:45 --> Language Class Initialized
ERROR - 2024-12-11 07:52:45 --> 404 Page Not Found: Wp-admin/gSvRCDBTNyz.php
INFO - 2024-12-11 07:52:46 --> Config Class Initialized
INFO - 2024-12-11 07:52:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:46 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:46 --> URI Class Initialized
INFO - 2024-12-11 07:52:46 --> Router Class Initialized
INFO - 2024-12-11 07:52:46 --> Output Class Initialized
INFO - 2024-12-11 07:52:46 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:46 --> Input Class Initialized
INFO - 2024-12-11 07:52:46 --> Language Class Initialized
ERROR - 2024-12-11 07:52:46 --> 404 Page Not Found: Wp-admin/JCmEkIBKQ4o.php
INFO - 2024-12-11 07:52:51 --> Config Class Initialized
INFO - 2024-12-11 07:52:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:51 --> URI Class Initialized
INFO - 2024-12-11 07:52:51 --> Router Class Initialized
INFO - 2024-12-11 07:52:51 --> Output Class Initialized
INFO - 2024-12-11 07:52:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:51 --> Input Class Initialized
INFO - 2024-12-11 07:52:51 --> Language Class Initialized
ERROR - 2024-12-11 07:52:51 --> 404 Page Not Found: Wp-admin/q4ote6ixcvr.php
INFO - 2024-12-11 07:52:51 --> Config Class Initialized
INFO - 2024-12-11 07:52:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:51 --> URI Class Initialized
INFO - 2024-12-11 07:52:51 --> Router Class Initialized
INFO - 2024-12-11 07:52:51 --> Output Class Initialized
INFO - 2024-12-11 07:52:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:51 --> Input Class Initialized
INFO - 2024-12-11 07:52:51 --> Language Class Initialized
ERROR - 2024-12-11 07:52:51 --> 404 Page Not Found: Wp-admin/JIeXVFin91G.php
INFO - 2024-12-11 07:52:57 --> Config Class Initialized
INFO - 2024-12-11 07:52:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:57 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:57 --> URI Class Initialized
INFO - 2024-12-11 07:52:57 --> Router Class Initialized
INFO - 2024-12-11 07:52:57 --> Output Class Initialized
INFO - 2024-12-11 07:52:57 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:57 --> Input Class Initialized
INFO - 2024-12-11 07:52:57 --> Language Class Initialized
ERROR - 2024-12-11 07:52:57 --> 404 Page Not Found: Wp-admin/DzVCZOPHKGS.php
INFO - 2024-12-11 07:52:59 --> Config Class Initialized
INFO - 2024-12-11 07:52:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:52:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:52:59 --> Utf8 Class Initialized
INFO - 2024-12-11 07:52:59 --> URI Class Initialized
INFO - 2024-12-11 07:52:59 --> Router Class Initialized
INFO - 2024-12-11 07:52:59 --> Output Class Initialized
INFO - 2024-12-11 07:52:59 --> Security Class Initialized
DEBUG - 2024-12-11 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:52:59 --> Input Class Initialized
INFO - 2024-12-11 07:52:59 --> Language Class Initialized
ERROR - 2024-12-11 07:52:59 --> 404 Page Not Found: T4w9xQnHMcjphp/index
INFO - 2024-12-11 07:53:02 --> Config Class Initialized
INFO - 2024-12-11 07:53:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:02 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:02 --> URI Class Initialized
INFO - 2024-12-11 07:53:02 --> Router Class Initialized
INFO - 2024-12-11 07:53:02 --> Output Class Initialized
INFO - 2024-12-11 07:53:02 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:02 --> Input Class Initialized
INFO - 2024-12-11 07:53:02 --> Language Class Initialized
ERROR - 2024-12-11 07:53:02 --> 404 Page Not Found: Wp-admin/uOFoeprh9SV.php
INFO - 2024-12-11 07:53:03 --> Config Class Initialized
INFO - 2024-12-11 07:53:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:03 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:03 --> URI Class Initialized
INFO - 2024-12-11 07:53:03 --> Router Class Initialized
INFO - 2024-12-11 07:53:03 --> Output Class Initialized
INFO - 2024-12-11 07:53:03 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:03 --> Input Class Initialized
INFO - 2024-12-11 07:53:03 --> Language Class Initialized
ERROR - 2024-12-11 07:53:03 --> 404 Page Not Found: IOoCabgSkB7php/index
INFO - 2024-12-11 07:53:05 --> Config Class Initialized
INFO - 2024-12-11 07:53:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:05 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:05 --> URI Class Initialized
INFO - 2024-12-11 07:53:05 --> Router Class Initialized
INFO - 2024-12-11 07:53:05 --> Output Class Initialized
INFO - 2024-12-11 07:53:05 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:05 --> Input Class Initialized
INFO - 2024-12-11 07:53:05 --> Language Class Initialized
ERROR - 2024-12-11 07:53:05 --> 404 Page Not Found: IypD2VA5PFTphp/index
INFO - 2024-12-11 07:53:07 --> Config Class Initialized
INFO - 2024-12-11 07:53:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:07 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:07 --> URI Class Initialized
INFO - 2024-12-11 07:53:07 --> Router Class Initialized
INFO - 2024-12-11 07:53:07 --> Output Class Initialized
INFO - 2024-12-11 07:53:07 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:07 --> Input Class Initialized
INFO - 2024-12-11 07:53:07 --> Language Class Initialized
ERROR - 2024-12-11 07:53:07 --> 404 Page Not Found: Wp-admin/4qocEAlL76R.php
INFO - 2024-12-11 07:53:16 --> Config Class Initialized
INFO - 2024-12-11 07:53:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:16 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:16 --> URI Class Initialized
INFO - 2024-12-11 07:53:16 --> Router Class Initialized
INFO - 2024-12-11 07:53:16 --> Output Class Initialized
INFO - 2024-12-11 07:53:16 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:16 --> Input Class Initialized
INFO - 2024-12-11 07:53:16 --> Language Class Initialized
ERROR - 2024-12-11 07:53:16 --> 404 Page Not Found: Wp-admin/OFKV9RNJELv.php
INFO - 2024-12-11 07:53:22 --> Config Class Initialized
INFO - 2024-12-11 07:53:22 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:22 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:22 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:22 --> URI Class Initialized
INFO - 2024-12-11 07:53:22 --> Router Class Initialized
INFO - 2024-12-11 07:53:22 --> Output Class Initialized
INFO - 2024-12-11 07:53:22 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:22 --> Input Class Initialized
INFO - 2024-12-11 07:53:22 --> Language Class Initialized
ERROR - 2024-12-11 07:53:22 --> 404 Page Not Found: Wp-admin/RrHkVuZ56ai.php
INFO - 2024-12-11 07:53:27 --> Config Class Initialized
INFO - 2024-12-11 07:53:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:27 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:27 --> URI Class Initialized
INFO - 2024-12-11 07:53:27 --> Router Class Initialized
INFO - 2024-12-11 07:53:27 --> Output Class Initialized
INFO - 2024-12-11 07:53:27 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:27 --> Input Class Initialized
INFO - 2024-12-11 07:53:27 --> Language Class Initialized
ERROR - 2024-12-11 07:53:27 --> 404 Page Not Found: FYKsamfL8XOphp/index
INFO - 2024-12-11 07:53:29 --> Config Class Initialized
INFO - 2024-12-11 07:53:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:29 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:29 --> URI Class Initialized
INFO - 2024-12-11 07:53:29 --> Router Class Initialized
INFO - 2024-12-11 07:53:29 --> Output Class Initialized
INFO - 2024-12-11 07:53:29 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:29 --> Input Class Initialized
INFO - 2024-12-11 07:53:29 --> Language Class Initialized
ERROR - 2024-12-11 07:53:29 --> 404 Page Not Found: Wp-admin/dT8Boz6efAO.php
INFO - 2024-12-11 07:53:31 --> Config Class Initialized
INFO - 2024-12-11 07:53:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:31 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:31 --> URI Class Initialized
INFO - 2024-12-11 07:53:31 --> Router Class Initialized
INFO - 2024-12-11 07:53:31 --> Output Class Initialized
INFO - 2024-12-11 07:53:31 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:31 --> Input Class Initialized
INFO - 2024-12-11 07:53:31 --> Language Class Initialized
ERROR - 2024-12-11 07:53:31 --> 404 Page Not Found: 8DPKmUxBbXaphp/index
INFO - 2024-12-11 07:53:33 --> Config Class Initialized
INFO - 2024-12-11 07:53:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:33 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:33 --> URI Class Initialized
INFO - 2024-12-11 07:53:33 --> Router Class Initialized
INFO - 2024-12-11 07:53:33 --> Output Class Initialized
INFO - 2024-12-11 07:53:33 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:33 --> Input Class Initialized
INFO - 2024-12-11 07:53:33 --> Language Class Initialized
ERROR - 2024-12-11 07:53:33 --> 404 Page Not Found: Wp-admin/uzTYoVtHveP.php
INFO - 2024-12-11 07:53:35 --> Config Class Initialized
INFO - 2024-12-11 07:53:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:35 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:35 --> URI Class Initialized
INFO - 2024-12-11 07:53:35 --> Router Class Initialized
INFO - 2024-12-11 07:53:35 --> Output Class Initialized
INFO - 2024-12-11 07:53:35 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:35 --> Input Class Initialized
INFO - 2024-12-11 07:53:35 --> Language Class Initialized
ERROR - 2024-12-11 07:53:35 --> 404 Page Not Found: 1Ci2tP4y3MHphp/index
INFO - 2024-12-11 07:53:38 --> Config Class Initialized
INFO - 2024-12-11 07:53:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:38 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:38 --> URI Class Initialized
INFO - 2024-12-11 07:53:38 --> Router Class Initialized
INFO - 2024-12-11 07:53:38 --> Output Class Initialized
INFO - 2024-12-11 07:53:38 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:38 --> Input Class Initialized
INFO - 2024-12-11 07:53:38 --> Language Class Initialized
ERROR - 2024-12-11 07:53:38 --> 404 Page Not Found: Wp-admin/WxsCw1NvmiJ.php
INFO - 2024-12-11 07:53:39 --> Config Class Initialized
INFO - 2024-12-11 07:53:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:39 --> URI Class Initialized
INFO - 2024-12-11 07:53:39 --> Router Class Initialized
INFO - 2024-12-11 07:53:39 --> Output Class Initialized
INFO - 2024-12-11 07:53:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:39 --> Input Class Initialized
INFO - 2024-12-11 07:53:39 --> Language Class Initialized
ERROR - 2024-12-11 07:53:39 --> 404 Page Not Found: Wp-admin/nYXROxcgFUD.php
INFO - 2024-12-11 07:53:40 --> Config Class Initialized
INFO - 2024-12-11 07:53:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:40 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:40 --> URI Class Initialized
INFO - 2024-12-11 07:53:40 --> Router Class Initialized
INFO - 2024-12-11 07:53:40 --> Output Class Initialized
INFO - 2024-12-11 07:53:40 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:40 --> Input Class Initialized
INFO - 2024-12-11 07:53:40 --> Language Class Initialized
ERROR - 2024-12-11 07:53:40 --> 404 Page Not Found: Wp-admin/dVm38qhH2Mb.php
INFO - 2024-12-11 07:53:42 --> Config Class Initialized
INFO - 2024-12-11 07:53:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:42 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:42 --> URI Class Initialized
INFO - 2024-12-11 07:53:42 --> Router Class Initialized
INFO - 2024-12-11 07:53:42 --> Output Class Initialized
INFO - 2024-12-11 07:53:42 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:42 --> Input Class Initialized
INFO - 2024-12-11 07:53:42 --> Language Class Initialized
ERROR - 2024-12-11 07:53:42 --> 404 Page Not Found: Wp-admin/IGNetZ5EWj9.php
INFO - 2024-12-11 07:53:46 --> Config Class Initialized
INFO - 2024-12-11 07:53:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:46 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:46 --> URI Class Initialized
INFO - 2024-12-11 07:53:46 --> Router Class Initialized
INFO - 2024-12-11 07:53:46 --> Output Class Initialized
INFO - 2024-12-11 07:53:46 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:46 --> Input Class Initialized
INFO - 2024-12-11 07:53:46 --> Language Class Initialized
ERROR - 2024-12-11 07:53:46 --> 404 Page Not Found: Wp-admin/hpiAr5Ug6XB.php
INFO - 2024-12-11 07:53:59 --> Config Class Initialized
INFO - 2024-12-11 07:53:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:53:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:53:59 --> Utf8 Class Initialized
INFO - 2024-12-11 07:53:59 --> URI Class Initialized
INFO - 2024-12-11 07:53:59 --> Router Class Initialized
INFO - 2024-12-11 07:53:59 --> Output Class Initialized
INFO - 2024-12-11 07:53:59 --> Security Class Initialized
DEBUG - 2024-12-11 07:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:53:59 --> Input Class Initialized
INFO - 2024-12-11 07:53:59 --> Language Class Initialized
ERROR - 2024-12-11 07:53:59 --> 404 Page Not Found: Wp-admin/sOEHKdTFuo6.php
INFO - 2024-12-11 07:54:03 --> Config Class Initialized
INFO - 2024-12-11 07:54:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:03 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:03 --> URI Class Initialized
INFO - 2024-12-11 07:54:03 --> Router Class Initialized
INFO - 2024-12-11 07:54:03 --> Output Class Initialized
INFO - 2024-12-11 07:54:03 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:03 --> Input Class Initialized
INFO - 2024-12-11 07:54:03 --> Language Class Initialized
ERROR - 2024-12-11 07:54:03 --> 404 Page Not Found: Wp-admin/fZvyeKNkrFJ.php
INFO - 2024-12-11 07:54:05 --> Config Class Initialized
INFO - 2024-12-11 07:54:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:05 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:05 --> URI Class Initialized
INFO - 2024-12-11 07:54:05 --> Router Class Initialized
INFO - 2024-12-11 07:54:05 --> Output Class Initialized
INFO - 2024-12-11 07:54:05 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:05 --> Input Class Initialized
INFO - 2024-12-11 07:54:05 --> Language Class Initialized
ERROR - 2024-12-11 07:54:05 --> 404 Page Not Found: Vmlp4CEoR6rphp/index
INFO - 2024-12-11 07:54:08 --> Config Class Initialized
INFO - 2024-12-11 07:54:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:08 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:08 --> URI Class Initialized
INFO - 2024-12-11 07:54:08 --> Router Class Initialized
INFO - 2024-12-11 07:54:08 --> Output Class Initialized
INFO - 2024-12-11 07:54:08 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:08 --> Input Class Initialized
INFO - 2024-12-11 07:54:08 --> Language Class Initialized
ERROR - 2024-12-11 07:54:08 --> 404 Page Not Found: Wp-admin/QVSeY6ZG9bt.php
INFO - 2024-12-11 07:54:09 --> Config Class Initialized
INFO - 2024-12-11 07:54:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:09 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:09 --> URI Class Initialized
INFO - 2024-12-11 07:54:09 --> Router Class Initialized
INFO - 2024-12-11 07:54:09 --> Output Class Initialized
INFO - 2024-12-11 07:54:09 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:09 --> Input Class Initialized
INFO - 2024-12-11 07:54:09 --> Language Class Initialized
ERROR - 2024-12-11 07:54:09 --> 404 Page Not Found: RYxmkv2e3b8php/index
INFO - 2024-12-11 07:54:10 --> Config Class Initialized
INFO - 2024-12-11 07:54:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:10 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:10 --> URI Class Initialized
INFO - 2024-12-11 07:54:10 --> Router Class Initialized
INFO - 2024-12-11 07:54:10 --> Output Class Initialized
INFO - 2024-12-11 07:54:10 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:10 --> Input Class Initialized
INFO - 2024-12-11 07:54:10 --> Language Class Initialized
ERROR - 2024-12-11 07:54:10 --> 404 Page Not Found: Wp-admin/vabPw1mI86A.php
INFO - 2024-12-11 07:54:13 --> Config Class Initialized
INFO - 2024-12-11 07:54:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:13 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:13 --> URI Class Initialized
INFO - 2024-12-11 07:54:13 --> Router Class Initialized
INFO - 2024-12-11 07:54:13 --> Output Class Initialized
INFO - 2024-12-11 07:54:13 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:13 --> Input Class Initialized
INFO - 2024-12-11 07:54:13 --> Language Class Initialized
ERROR - 2024-12-11 07:54:13 --> 404 Page Not Found: 7q5GYsF6gEtphp/index
INFO - 2024-12-11 07:54:14 --> Config Class Initialized
INFO - 2024-12-11 07:54:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:14 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:14 --> URI Class Initialized
INFO - 2024-12-11 07:54:14 --> Router Class Initialized
INFO - 2024-12-11 07:54:14 --> Output Class Initialized
INFO - 2024-12-11 07:54:14 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:14 --> Input Class Initialized
INFO - 2024-12-11 07:54:14 --> Language Class Initialized
ERROR - 2024-12-11 07:54:14 --> 404 Page Not Found: Wp-admin/cFxeh8oaNWd.php
INFO - 2024-12-11 07:54:15 --> Config Class Initialized
INFO - 2024-12-11 07:54:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:15 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:15 --> URI Class Initialized
INFO - 2024-12-11 07:54:15 --> Router Class Initialized
INFO - 2024-12-11 07:54:15 --> Output Class Initialized
INFO - 2024-12-11 07:54:15 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:15 --> Input Class Initialized
INFO - 2024-12-11 07:54:15 --> Language Class Initialized
ERROR - 2024-12-11 07:54:15 --> 404 Page Not Found: Wp-admin/mV9YDZFSlh8.php
INFO - 2024-12-11 07:54:16 --> Config Class Initialized
INFO - 2024-12-11 07:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:16 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:16 --> URI Class Initialized
INFO - 2024-12-11 07:54:16 --> Router Class Initialized
INFO - 2024-12-11 07:54:16 --> Output Class Initialized
INFO - 2024-12-11 07:54:16 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:16 --> Input Class Initialized
INFO - 2024-12-11 07:54:16 --> Language Class Initialized
ERROR - 2024-12-11 07:54:16 --> 404 Page Not Found: Wp-admin/PEs9A1MB3bw.php
INFO - 2024-12-11 07:54:16 --> Config Class Initialized
INFO - 2024-12-11 07:54:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:16 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:16 --> URI Class Initialized
INFO - 2024-12-11 07:54:16 --> Router Class Initialized
INFO - 2024-12-11 07:54:16 --> Output Class Initialized
INFO - 2024-12-11 07:54:16 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:17 --> Input Class Initialized
INFO - 2024-12-11 07:54:17 --> Language Class Initialized
ERROR - 2024-12-11 07:54:17 --> 404 Page Not Found: Wp-admin/AvdoKjsNP9I.php
INFO - 2024-12-11 07:54:18 --> Config Class Initialized
INFO - 2024-12-11 07:54:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:18 --> URI Class Initialized
INFO - 2024-12-11 07:54:18 --> Router Class Initialized
INFO - 2024-12-11 07:54:18 --> Output Class Initialized
INFO - 2024-12-11 07:54:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:18 --> Input Class Initialized
INFO - 2024-12-11 07:54:18 --> Language Class Initialized
ERROR - 2024-12-11 07:54:18 --> 404 Page Not Found: Wp-admin/MTmZKpGOqXU.php
INFO - 2024-12-11 07:54:32 --> Config Class Initialized
INFO - 2024-12-11 07:54:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:32 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:32 --> URI Class Initialized
INFO - 2024-12-11 07:54:32 --> Router Class Initialized
INFO - 2024-12-11 07:54:32 --> Output Class Initialized
INFO - 2024-12-11 07:54:32 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:32 --> Input Class Initialized
INFO - 2024-12-11 07:54:32 --> Language Class Initialized
ERROR - 2024-12-11 07:54:32 --> 404 Page Not Found: YzYhgTvwU4Ophp/index
INFO - 2024-12-11 07:54:35 --> Config Class Initialized
INFO - 2024-12-11 07:54:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:35 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:35 --> URI Class Initialized
INFO - 2024-12-11 07:54:35 --> Router Class Initialized
INFO - 2024-12-11 07:54:35 --> Output Class Initialized
INFO - 2024-12-11 07:54:35 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:35 --> Input Class Initialized
INFO - 2024-12-11 07:54:35 --> Language Class Initialized
ERROR - 2024-12-11 07:54:35 --> 404 Page Not Found: Wp-admin/ES9nLvNezGC.php
INFO - 2024-12-11 07:54:35 --> Config Class Initialized
INFO - 2024-12-11 07:54:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:35 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:35 --> URI Class Initialized
INFO - 2024-12-11 07:54:35 --> Router Class Initialized
INFO - 2024-12-11 07:54:35 --> Output Class Initialized
INFO - 2024-12-11 07:54:35 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:35 --> Input Class Initialized
INFO - 2024-12-11 07:54:35 --> Language Class Initialized
ERROR - 2024-12-11 07:54:35 --> 404 Page Not Found: Wp-admin/NA7q59wVSCc.php
INFO - 2024-12-11 07:54:42 --> Config Class Initialized
INFO - 2024-12-11 07:54:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:42 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:42 --> URI Class Initialized
INFO - 2024-12-11 07:54:42 --> Router Class Initialized
INFO - 2024-12-11 07:54:42 --> Output Class Initialized
INFO - 2024-12-11 07:54:42 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:42 --> Input Class Initialized
INFO - 2024-12-11 07:54:42 --> Language Class Initialized
ERROR - 2024-12-11 07:54:42 --> 404 Page Not Found: Wp-admin/7tQpBDdau6b.php
INFO - 2024-12-11 07:54:44 --> Config Class Initialized
INFO - 2024-12-11 07:54:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:44 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:44 --> URI Class Initialized
INFO - 2024-12-11 07:54:44 --> Router Class Initialized
INFO - 2024-12-11 07:54:44 --> Output Class Initialized
INFO - 2024-12-11 07:54:44 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:44 --> Input Class Initialized
INFO - 2024-12-11 07:54:44 --> Language Class Initialized
ERROR - 2024-12-11 07:54:44 --> 404 Page Not Found: Wp-admin/zlXb8oFtBpx.php
INFO - 2024-12-11 07:54:46 --> Config Class Initialized
INFO - 2024-12-11 07:54:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:46 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:46 --> URI Class Initialized
INFO - 2024-12-11 07:54:46 --> Router Class Initialized
INFO - 2024-12-11 07:54:46 --> Output Class Initialized
INFO - 2024-12-11 07:54:46 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:46 --> Input Class Initialized
INFO - 2024-12-11 07:54:46 --> Language Class Initialized
ERROR - 2024-12-11 07:54:46 --> 404 Page Not Found: GUe6CYjyAITphp/index
INFO - 2024-12-11 07:54:47 --> Config Class Initialized
INFO - 2024-12-11 07:54:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:47 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:47 --> URI Class Initialized
INFO - 2024-12-11 07:54:47 --> Router Class Initialized
INFO - 2024-12-11 07:54:47 --> Output Class Initialized
INFO - 2024-12-11 07:54:47 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:47 --> Input Class Initialized
INFO - 2024-12-11 07:54:47 --> Language Class Initialized
ERROR - 2024-12-11 07:54:47 --> 404 Page Not Found: 6SVPUuNQKXyphp/index
INFO - 2024-12-11 07:54:51 --> Config Class Initialized
INFO - 2024-12-11 07:54:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:51 --> URI Class Initialized
INFO - 2024-12-11 07:54:51 --> Router Class Initialized
INFO - 2024-12-11 07:54:51 --> Output Class Initialized
INFO - 2024-12-11 07:54:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:51 --> Input Class Initialized
INFO - 2024-12-11 07:54:51 --> Language Class Initialized
ERROR - 2024-12-11 07:54:51 --> 404 Page Not Found: Wly8veJbTLFphp/index
INFO - 2024-12-11 07:54:53 --> Config Class Initialized
INFO - 2024-12-11 07:54:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:53 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:53 --> URI Class Initialized
INFO - 2024-12-11 07:54:53 --> Router Class Initialized
INFO - 2024-12-11 07:54:53 --> Output Class Initialized
INFO - 2024-12-11 07:54:53 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:53 --> Input Class Initialized
INFO - 2024-12-11 07:54:53 --> Language Class Initialized
ERROR - 2024-12-11 07:54:53 --> 404 Page Not Found: Wp-admin/WXKq5DNZgVe.php
INFO - 2024-12-11 07:54:58 --> Config Class Initialized
INFO - 2024-12-11 07:54:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:54:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:54:58 --> Utf8 Class Initialized
INFO - 2024-12-11 07:54:58 --> URI Class Initialized
INFO - 2024-12-11 07:54:58 --> Router Class Initialized
INFO - 2024-12-11 07:54:58 --> Output Class Initialized
INFO - 2024-12-11 07:54:58 --> Security Class Initialized
DEBUG - 2024-12-11 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:54:58 --> Input Class Initialized
INFO - 2024-12-11 07:54:58 --> Language Class Initialized
ERROR - 2024-12-11 07:54:58 --> 404 Page Not Found: Wp-admin/1lK6cQxuRFG.php
INFO - 2024-12-11 07:55:03 --> Config Class Initialized
INFO - 2024-12-11 07:55:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:03 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:03 --> URI Class Initialized
INFO - 2024-12-11 07:55:03 --> Router Class Initialized
INFO - 2024-12-11 07:55:03 --> Output Class Initialized
INFO - 2024-12-11 07:55:03 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:03 --> Input Class Initialized
INFO - 2024-12-11 07:55:03 --> Language Class Initialized
ERROR - 2024-12-11 07:55:03 --> 404 Page Not Found: Wp-admin/VWPal3Iz7ZA.php
INFO - 2024-12-11 07:55:06 --> Config Class Initialized
INFO - 2024-12-11 07:55:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:06 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:06 --> URI Class Initialized
INFO - 2024-12-11 07:55:06 --> Router Class Initialized
INFO - 2024-12-11 07:55:06 --> Output Class Initialized
INFO - 2024-12-11 07:55:06 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:06 --> Input Class Initialized
INFO - 2024-12-11 07:55:06 --> Language Class Initialized
ERROR - 2024-12-11 07:55:06 --> 404 Page Not Found: RekhG6LpsZ3php/index
INFO - 2024-12-11 07:55:08 --> Config Class Initialized
INFO - 2024-12-11 07:55:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:08 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:08 --> URI Class Initialized
INFO - 2024-12-11 07:55:08 --> Router Class Initialized
INFO - 2024-12-11 07:55:08 --> Output Class Initialized
INFO - 2024-12-11 07:55:08 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:08 --> Input Class Initialized
INFO - 2024-12-11 07:55:08 --> Language Class Initialized
ERROR - 2024-12-11 07:55:08 --> 404 Page Not Found: Wp-admin/ijrlJwthAMX.php
INFO - 2024-12-11 07:55:09 --> Config Class Initialized
INFO - 2024-12-11 07:55:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:09 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:09 --> URI Class Initialized
INFO - 2024-12-11 07:55:09 --> Router Class Initialized
INFO - 2024-12-11 07:55:09 --> Output Class Initialized
INFO - 2024-12-11 07:55:09 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:09 --> Input Class Initialized
INFO - 2024-12-11 07:55:09 --> Language Class Initialized
ERROR - 2024-12-11 07:55:09 --> 404 Page Not Found: Wp-admin/8kyif4m3NLJ.php
INFO - 2024-12-11 07:55:11 --> Config Class Initialized
INFO - 2024-12-11 07:55:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:11 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:11 --> URI Class Initialized
INFO - 2024-12-11 07:55:11 --> Router Class Initialized
INFO - 2024-12-11 07:55:11 --> Output Class Initialized
INFO - 2024-12-11 07:55:11 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:11 --> Input Class Initialized
INFO - 2024-12-11 07:55:11 --> Language Class Initialized
ERROR - 2024-12-11 07:55:11 --> 404 Page Not Found: EUYisnztjLmphp/index
INFO - 2024-12-11 07:55:17 --> Config Class Initialized
INFO - 2024-12-11 07:55:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:17 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:17 --> URI Class Initialized
INFO - 2024-12-11 07:55:17 --> Router Class Initialized
INFO - 2024-12-11 07:55:17 --> Output Class Initialized
INFO - 2024-12-11 07:55:17 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:17 --> Input Class Initialized
INFO - 2024-12-11 07:55:17 --> Language Class Initialized
ERROR - 2024-12-11 07:55:17 --> 404 Page Not Found: Wp-admin/5SkuMyp2qCI.php
INFO - 2024-12-11 07:55:18 --> Config Class Initialized
INFO - 2024-12-11 07:55:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:18 --> URI Class Initialized
INFO - 2024-12-11 07:55:18 --> Router Class Initialized
INFO - 2024-12-11 07:55:18 --> Output Class Initialized
INFO - 2024-12-11 07:55:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:18 --> Input Class Initialized
INFO - 2024-12-11 07:55:18 --> Language Class Initialized
ERROR - 2024-12-11 07:55:18 --> 404 Page Not Found: Wp-admin/h8fiwMJRIoV.php
INFO - 2024-12-11 07:55:19 --> Config Class Initialized
INFO - 2024-12-11 07:55:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:19 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:19 --> URI Class Initialized
INFO - 2024-12-11 07:55:19 --> Router Class Initialized
INFO - 2024-12-11 07:55:19 --> Output Class Initialized
INFO - 2024-12-11 07:55:19 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:19 --> Input Class Initialized
INFO - 2024-12-11 07:55:19 --> Language Class Initialized
ERROR - 2024-12-11 07:55:19 --> 404 Page Not Found: Wp-admin/JSlc3d7smjg.php
INFO - 2024-12-11 07:55:21 --> Config Class Initialized
INFO - 2024-12-11 07:55:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:21 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:21 --> URI Class Initialized
INFO - 2024-12-11 07:55:21 --> Router Class Initialized
INFO - 2024-12-11 07:55:21 --> Output Class Initialized
INFO - 2024-12-11 07:55:21 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:21 --> Input Class Initialized
INFO - 2024-12-11 07:55:21 --> Language Class Initialized
ERROR - 2024-12-11 07:55:21 --> 404 Page Not Found: Wp-admin/wIBOC96nJLV.php
INFO - 2024-12-11 07:55:26 --> Config Class Initialized
INFO - 2024-12-11 07:55:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:26 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:26 --> URI Class Initialized
INFO - 2024-12-11 07:55:26 --> Router Class Initialized
INFO - 2024-12-11 07:55:26 --> Output Class Initialized
INFO - 2024-12-11 07:55:26 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:26 --> Input Class Initialized
INFO - 2024-12-11 07:55:26 --> Language Class Initialized
ERROR - 2024-12-11 07:55:26 --> 404 Page Not Found: Wp-admin/8laIR5T14Hx.php
INFO - 2024-12-11 07:55:30 --> Config Class Initialized
INFO - 2024-12-11 07:55:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:30 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:30 --> URI Class Initialized
INFO - 2024-12-11 07:55:30 --> Router Class Initialized
INFO - 2024-12-11 07:55:30 --> Output Class Initialized
INFO - 2024-12-11 07:55:30 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:30 --> Input Class Initialized
INFO - 2024-12-11 07:55:30 --> Language Class Initialized
ERROR - 2024-12-11 07:55:30 --> 404 Page Not Found: Wp-admin/Y2pVCoqJENI.php
INFO - 2024-12-11 07:55:39 --> Config Class Initialized
INFO - 2024-12-11 07:55:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:39 --> URI Class Initialized
INFO - 2024-12-11 07:55:39 --> Router Class Initialized
INFO - 2024-12-11 07:55:39 --> Output Class Initialized
INFO - 2024-12-11 07:55:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:39 --> Input Class Initialized
INFO - 2024-12-11 07:55:39 --> Language Class Initialized
ERROR - 2024-12-11 07:55:39 --> 404 Page Not Found: Wp-admin/S6HMz7OmcxD.php
INFO - 2024-12-11 07:55:39 --> Config Class Initialized
INFO - 2024-12-11 07:55:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:39 --> URI Class Initialized
INFO - 2024-12-11 07:55:39 --> Router Class Initialized
INFO - 2024-12-11 07:55:39 --> Output Class Initialized
INFO - 2024-12-11 07:55:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:39 --> Input Class Initialized
INFO - 2024-12-11 07:55:39 --> Language Class Initialized
ERROR - 2024-12-11 07:55:39 --> 404 Page Not Found: Wp-admin/jk46yBprNeF.php
INFO - 2024-12-11 07:55:43 --> Config Class Initialized
INFO - 2024-12-11 07:55:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:43 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:43 --> URI Class Initialized
INFO - 2024-12-11 07:55:43 --> Router Class Initialized
INFO - 2024-12-11 07:55:43 --> Output Class Initialized
INFO - 2024-12-11 07:55:43 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:43 --> Input Class Initialized
INFO - 2024-12-11 07:55:43 --> Language Class Initialized
ERROR - 2024-12-11 07:55:43 --> 404 Page Not Found: XVSCEaqQ9p1php/index
INFO - 2024-12-11 07:55:43 --> Config Class Initialized
INFO - 2024-12-11 07:55:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:43 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:43 --> URI Class Initialized
INFO - 2024-12-11 07:55:43 --> Router Class Initialized
INFO - 2024-12-11 07:55:43 --> Output Class Initialized
INFO - 2024-12-11 07:55:43 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:43 --> Input Class Initialized
INFO - 2024-12-11 07:55:43 --> Language Class Initialized
ERROR - 2024-12-11 07:55:43 --> 404 Page Not Found: Wp-admin/47FijhTcb65.php
INFO - 2024-12-11 07:55:44 --> Config Class Initialized
INFO - 2024-12-11 07:55:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:44 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:44 --> URI Class Initialized
INFO - 2024-12-11 07:55:44 --> Router Class Initialized
INFO - 2024-12-11 07:55:44 --> Output Class Initialized
INFO - 2024-12-11 07:55:44 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:44 --> Input Class Initialized
INFO - 2024-12-11 07:55:44 --> Language Class Initialized
ERROR - 2024-12-11 07:55:44 --> 404 Page Not Found: Wp-admin/G2nRFHOfC1r.php
INFO - 2024-12-11 07:55:45 --> Config Class Initialized
INFO - 2024-12-11 07:55:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:45 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:45 --> URI Class Initialized
INFO - 2024-12-11 07:55:45 --> Router Class Initialized
INFO - 2024-12-11 07:55:45 --> Output Class Initialized
INFO - 2024-12-11 07:55:45 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:45 --> Input Class Initialized
INFO - 2024-12-11 07:55:45 --> Language Class Initialized
ERROR - 2024-12-11 07:55:45 --> 404 Page Not Found: DjXAZSd8yMkphp/index
INFO - 2024-12-11 07:55:48 --> Config Class Initialized
INFO - 2024-12-11 07:55:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:48 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:48 --> URI Class Initialized
INFO - 2024-12-11 07:55:48 --> Router Class Initialized
INFO - 2024-12-11 07:55:48 --> Output Class Initialized
INFO - 2024-12-11 07:55:48 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:48 --> Input Class Initialized
INFO - 2024-12-11 07:55:48 --> Language Class Initialized
ERROR - 2024-12-11 07:55:48 --> 404 Page Not Found: Wp-admin/sYpGdXWqfJi.php
INFO - 2024-12-11 07:55:49 --> Config Class Initialized
INFO - 2024-12-11 07:55:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:49 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:49 --> URI Class Initialized
INFO - 2024-12-11 07:55:49 --> Router Class Initialized
INFO - 2024-12-11 07:55:49 --> Output Class Initialized
INFO - 2024-12-11 07:55:49 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:49 --> Input Class Initialized
INFO - 2024-12-11 07:55:49 --> Language Class Initialized
ERROR - 2024-12-11 07:55:49 --> 404 Page Not Found: Wp-admin/q5IOSnlUeVd.php
INFO - 2024-12-11 07:55:55 --> Config Class Initialized
INFO - 2024-12-11 07:55:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:55:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:55:55 --> Utf8 Class Initialized
INFO - 2024-12-11 07:55:55 --> URI Class Initialized
INFO - 2024-12-11 07:55:55 --> Router Class Initialized
INFO - 2024-12-11 07:55:55 --> Output Class Initialized
INFO - 2024-12-11 07:55:55 --> Security Class Initialized
DEBUG - 2024-12-11 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:55:55 --> Input Class Initialized
INFO - 2024-12-11 07:55:55 --> Language Class Initialized
ERROR - 2024-12-11 07:55:55 --> 404 Page Not Found: Ng58Uuvx2TXphp/index
INFO - 2024-12-11 07:56:05 --> Config Class Initialized
INFO - 2024-12-11 07:56:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:05 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:05 --> URI Class Initialized
INFO - 2024-12-11 07:56:05 --> Router Class Initialized
INFO - 2024-12-11 07:56:05 --> Output Class Initialized
INFO - 2024-12-11 07:56:05 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:05 --> Input Class Initialized
INFO - 2024-12-11 07:56:05 --> Language Class Initialized
ERROR - 2024-12-11 07:56:05 --> 404 Page Not Found: Wp-admin/ziQAjy7pnsX.php
INFO - 2024-12-11 07:56:08 --> Config Class Initialized
INFO - 2024-12-11 07:56:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:08 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:08 --> URI Class Initialized
INFO - 2024-12-11 07:56:08 --> Router Class Initialized
INFO - 2024-12-11 07:56:08 --> Output Class Initialized
INFO - 2024-12-11 07:56:08 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:08 --> Input Class Initialized
INFO - 2024-12-11 07:56:08 --> Language Class Initialized
ERROR - 2024-12-11 07:56:08 --> 404 Page Not Found: HMfSZq1DGUzphp/index
INFO - 2024-12-11 07:56:16 --> Config Class Initialized
INFO - 2024-12-11 07:56:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:16 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:16 --> URI Class Initialized
INFO - 2024-12-11 07:56:16 --> Router Class Initialized
INFO - 2024-12-11 07:56:16 --> Output Class Initialized
INFO - 2024-12-11 07:56:16 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:16 --> Input Class Initialized
INFO - 2024-12-11 07:56:16 --> Language Class Initialized
ERROR - 2024-12-11 07:56:16 --> 404 Page Not Found: Pmy9MQrigZBphp/index
INFO - 2024-12-11 07:56:17 --> Config Class Initialized
INFO - 2024-12-11 07:56:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:17 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:17 --> URI Class Initialized
INFO - 2024-12-11 07:56:17 --> Router Class Initialized
INFO - 2024-12-11 07:56:17 --> Output Class Initialized
INFO - 2024-12-11 07:56:17 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:17 --> Input Class Initialized
INFO - 2024-12-11 07:56:17 --> Language Class Initialized
ERROR - 2024-12-11 07:56:17 --> 404 Page Not Found: Wp-admin/PLTbSKmhOI7.php
INFO - 2024-12-11 07:56:21 --> Config Class Initialized
INFO - 2024-12-11 07:56:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:21 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:21 --> URI Class Initialized
INFO - 2024-12-11 07:56:21 --> Router Class Initialized
INFO - 2024-12-11 07:56:21 --> Output Class Initialized
INFO - 2024-12-11 07:56:21 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:21 --> Input Class Initialized
INFO - 2024-12-11 07:56:21 --> Language Class Initialized
ERROR - 2024-12-11 07:56:21 --> 404 Page Not Found: Wp-admin/5d2Npyxrwh3.php
INFO - 2024-12-11 07:56:21 --> Config Class Initialized
INFO - 2024-12-11 07:56:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:21 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:21 --> URI Class Initialized
INFO - 2024-12-11 07:56:21 --> Router Class Initialized
INFO - 2024-12-11 07:56:21 --> Output Class Initialized
INFO - 2024-12-11 07:56:21 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:21 --> Input Class Initialized
INFO - 2024-12-11 07:56:21 --> Language Class Initialized
ERROR - 2024-12-11 07:56:21 --> 404 Page Not Found: Wp-admin/uQMqjdpEGsK.php
INFO - 2024-12-11 07:56:34 --> Config Class Initialized
INFO - 2024-12-11 07:56:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:34 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:34 --> URI Class Initialized
INFO - 2024-12-11 07:56:34 --> Router Class Initialized
INFO - 2024-12-11 07:56:34 --> Output Class Initialized
INFO - 2024-12-11 07:56:34 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:34 --> Input Class Initialized
INFO - 2024-12-11 07:56:34 --> Language Class Initialized
ERROR - 2024-12-11 07:56:34 --> 404 Page Not Found: Wp-admin/mRkfVPMN1d8.php
INFO - 2024-12-11 07:56:35 --> Config Class Initialized
INFO - 2024-12-11 07:56:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:35 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:35 --> URI Class Initialized
INFO - 2024-12-11 07:56:35 --> Router Class Initialized
INFO - 2024-12-11 07:56:35 --> Output Class Initialized
INFO - 2024-12-11 07:56:35 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:35 --> Input Class Initialized
INFO - 2024-12-11 07:56:35 --> Language Class Initialized
ERROR - 2024-12-11 07:56:35 --> 404 Page Not Found: Wp-admin/5nBP4g8lKhy.php
INFO - 2024-12-11 07:56:38 --> Config Class Initialized
INFO - 2024-12-11 07:56:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:38 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:38 --> URI Class Initialized
INFO - 2024-12-11 07:56:38 --> Router Class Initialized
INFO - 2024-12-11 07:56:38 --> Output Class Initialized
INFO - 2024-12-11 07:56:38 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:38 --> Input Class Initialized
INFO - 2024-12-11 07:56:38 --> Language Class Initialized
ERROR - 2024-12-11 07:56:38 --> 404 Page Not Found: Wp-admin/twPzEUSMDN7.php
INFO - 2024-12-11 07:56:43 --> Config Class Initialized
INFO - 2024-12-11 07:56:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:43 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:43 --> URI Class Initialized
INFO - 2024-12-11 07:56:43 --> Router Class Initialized
INFO - 2024-12-11 07:56:43 --> Output Class Initialized
INFO - 2024-12-11 07:56:43 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:43 --> Input Class Initialized
INFO - 2024-12-11 07:56:43 --> Language Class Initialized
ERROR - 2024-12-11 07:56:43 --> 404 Page Not Found: Wp-admin/w6Hte1ZPoDb.php
INFO - 2024-12-11 07:56:44 --> Config Class Initialized
INFO - 2024-12-11 07:56:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:44 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:44 --> URI Class Initialized
INFO - 2024-12-11 07:56:44 --> Router Class Initialized
INFO - 2024-12-11 07:56:44 --> Output Class Initialized
INFO - 2024-12-11 07:56:44 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:44 --> Input Class Initialized
INFO - 2024-12-11 07:56:44 --> Language Class Initialized
ERROR - 2024-12-11 07:56:44 --> 404 Page Not Found: Wp-admin/7Vncwps6JCO.php
INFO - 2024-12-11 07:56:47 --> Config Class Initialized
INFO - 2024-12-11 07:56:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:47 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:47 --> URI Class Initialized
INFO - 2024-12-11 07:56:47 --> Router Class Initialized
INFO - 2024-12-11 07:56:47 --> Output Class Initialized
INFO - 2024-12-11 07:56:47 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:47 --> Input Class Initialized
INFO - 2024-12-11 07:56:47 --> Language Class Initialized
ERROR - 2024-12-11 07:56:47 --> 404 Page Not Found: Wp-admin/eX8ZQ2KBcTp.php
INFO - 2024-12-11 07:56:48 --> Config Class Initialized
INFO - 2024-12-11 07:56:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:48 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:48 --> URI Class Initialized
INFO - 2024-12-11 07:56:48 --> Router Class Initialized
INFO - 2024-12-11 07:56:48 --> Output Class Initialized
INFO - 2024-12-11 07:56:48 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:48 --> Input Class Initialized
INFO - 2024-12-11 07:56:48 --> Language Class Initialized
ERROR - 2024-12-11 07:56:48 --> 404 Page Not Found: Wp-admin/rWfkRJGEj4i.php
INFO - 2024-12-11 07:56:49 --> Config Class Initialized
INFO - 2024-12-11 07:56:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:49 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:49 --> URI Class Initialized
INFO - 2024-12-11 07:56:49 --> Router Class Initialized
INFO - 2024-12-11 07:56:49 --> Output Class Initialized
INFO - 2024-12-11 07:56:49 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:49 --> Input Class Initialized
INFO - 2024-12-11 07:56:49 --> Language Class Initialized
ERROR - 2024-12-11 07:56:49 --> 404 Page Not Found: Wp-admin/XQ3LNmipdVF.php
INFO - 2024-12-11 07:56:51 --> Config Class Initialized
INFO - 2024-12-11 07:56:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:51 --> URI Class Initialized
INFO - 2024-12-11 07:56:51 --> Router Class Initialized
INFO - 2024-12-11 07:56:51 --> Output Class Initialized
INFO - 2024-12-11 07:56:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:51 --> Input Class Initialized
INFO - 2024-12-11 07:56:51 --> Language Class Initialized
ERROR - 2024-12-11 07:56:51 --> 404 Page Not Found: Wp-admin/ZkrwD52GNHE.php
INFO - 2024-12-11 07:56:53 --> Config Class Initialized
INFO - 2024-12-11 07:56:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:53 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:53 --> URI Class Initialized
INFO - 2024-12-11 07:56:53 --> Router Class Initialized
INFO - 2024-12-11 07:56:53 --> Output Class Initialized
INFO - 2024-12-11 07:56:53 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:53 --> Input Class Initialized
INFO - 2024-12-11 07:56:53 --> Language Class Initialized
ERROR - 2024-12-11 07:56:53 --> 404 Page Not Found: Wp-admin/UXp634mrDZs.php
INFO - 2024-12-11 07:56:54 --> Config Class Initialized
INFO - 2024-12-11 07:56:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:54 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:54 --> URI Class Initialized
INFO - 2024-12-11 07:56:54 --> Router Class Initialized
INFO - 2024-12-11 07:56:54 --> Output Class Initialized
INFO - 2024-12-11 07:56:54 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:54 --> Input Class Initialized
INFO - 2024-12-11 07:56:54 --> Language Class Initialized
ERROR - 2024-12-11 07:56:54 --> 404 Page Not Found: Wp-admin/GgThJRea628.php
INFO - 2024-12-11 07:56:58 --> Config Class Initialized
INFO - 2024-12-11 07:56:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:58 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:58 --> URI Class Initialized
INFO - 2024-12-11 07:56:58 --> Router Class Initialized
INFO - 2024-12-11 07:56:58 --> Output Class Initialized
INFO - 2024-12-11 07:56:58 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:58 --> Input Class Initialized
INFO - 2024-12-11 07:56:58 --> Language Class Initialized
ERROR - 2024-12-11 07:56:58 --> 404 Page Not Found: Wp-admin/ArXRH3UkoZS.php
INFO - 2024-12-11 07:56:59 --> Config Class Initialized
INFO - 2024-12-11 07:56:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:56:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:56:59 --> Utf8 Class Initialized
INFO - 2024-12-11 07:56:59 --> URI Class Initialized
INFO - 2024-12-11 07:56:59 --> Router Class Initialized
INFO - 2024-12-11 07:56:59 --> Output Class Initialized
INFO - 2024-12-11 07:56:59 --> Security Class Initialized
DEBUG - 2024-12-11 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:56:59 --> Input Class Initialized
INFO - 2024-12-11 07:56:59 --> Language Class Initialized
ERROR - 2024-12-11 07:56:59 --> 404 Page Not Found: Wp-admin/7bJfhoZVHwv.php
INFO - 2024-12-11 07:57:01 --> Config Class Initialized
INFO - 2024-12-11 07:57:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:01 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:01 --> URI Class Initialized
INFO - 2024-12-11 07:57:01 --> Router Class Initialized
INFO - 2024-12-11 07:57:01 --> Output Class Initialized
INFO - 2024-12-11 07:57:01 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:01 --> Input Class Initialized
INFO - 2024-12-11 07:57:01 --> Language Class Initialized
ERROR - 2024-12-11 07:57:01 --> 404 Page Not Found: Wp-admin/Q1ft5xT8OVM.php
INFO - 2024-12-11 07:57:03 --> Config Class Initialized
INFO - 2024-12-11 07:57:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:03 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:03 --> URI Class Initialized
INFO - 2024-12-11 07:57:03 --> Router Class Initialized
INFO - 2024-12-11 07:57:03 --> Output Class Initialized
INFO - 2024-12-11 07:57:03 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:03 --> Input Class Initialized
INFO - 2024-12-11 07:57:03 --> Language Class Initialized
ERROR - 2024-12-11 07:57:03 --> 404 Page Not Found: Wp-admin/JbjnrZsdL3X.php
INFO - 2024-12-11 07:57:06 --> Config Class Initialized
INFO - 2024-12-11 07:57:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:06 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:06 --> URI Class Initialized
INFO - 2024-12-11 07:57:06 --> Router Class Initialized
INFO - 2024-12-11 07:57:06 --> Output Class Initialized
INFO - 2024-12-11 07:57:06 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:06 --> Input Class Initialized
INFO - 2024-12-11 07:57:06 --> Language Class Initialized
ERROR - 2024-12-11 07:57:06 --> 404 Page Not Found: NwHsaGq6yMrphp/index
INFO - 2024-12-11 07:57:07 --> Config Class Initialized
INFO - 2024-12-11 07:57:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:07 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:07 --> URI Class Initialized
INFO - 2024-12-11 07:57:07 --> Router Class Initialized
INFO - 2024-12-11 07:57:07 --> Output Class Initialized
INFO - 2024-12-11 07:57:07 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:07 --> Input Class Initialized
INFO - 2024-12-11 07:57:07 --> Language Class Initialized
ERROR - 2024-12-11 07:57:07 --> 404 Page Not Found: SOUwjQsmMX4php/index
INFO - 2024-12-11 07:57:07 --> Config Class Initialized
INFO - 2024-12-11 07:57:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:07 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:07 --> URI Class Initialized
INFO - 2024-12-11 07:57:07 --> Router Class Initialized
INFO - 2024-12-11 07:57:07 --> Output Class Initialized
INFO - 2024-12-11 07:57:07 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:07 --> Input Class Initialized
INFO - 2024-12-11 07:57:07 --> Language Class Initialized
ERROR - 2024-12-11 07:57:07 --> 404 Page Not Found: Wp-admin/Vply6CqS8I3.php
INFO - 2024-12-11 07:57:09 --> Config Class Initialized
INFO - 2024-12-11 07:57:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:09 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:09 --> URI Class Initialized
INFO - 2024-12-11 07:57:09 --> Router Class Initialized
INFO - 2024-12-11 07:57:09 --> Output Class Initialized
INFO - 2024-12-11 07:57:09 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:09 --> Input Class Initialized
INFO - 2024-12-11 07:57:09 --> Language Class Initialized
ERROR - 2024-12-11 07:57:09 --> 404 Page Not Found: C4WYUPwIfNJphp/index
INFO - 2024-12-11 07:57:11 --> Config Class Initialized
INFO - 2024-12-11 07:57:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:11 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:11 --> URI Class Initialized
INFO - 2024-12-11 07:57:11 --> Router Class Initialized
INFO - 2024-12-11 07:57:11 --> Output Class Initialized
INFO - 2024-12-11 07:57:11 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:11 --> Input Class Initialized
INFO - 2024-12-11 07:57:11 --> Language Class Initialized
ERROR - 2024-12-11 07:57:11 --> 404 Page Not Found: Wp-admin/jXkqsT8dHYp.php
INFO - 2024-12-11 07:57:14 --> Config Class Initialized
INFO - 2024-12-11 07:57:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:14 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:14 --> URI Class Initialized
INFO - 2024-12-11 07:57:14 --> Router Class Initialized
INFO - 2024-12-11 07:57:14 --> Output Class Initialized
INFO - 2024-12-11 07:57:14 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:14 --> Input Class Initialized
INFO - 2024-12-11 07:57:14 --> Language Class Initialized
ERROR - 2024-12-11 07:57:14 --> 404 Page Not Found: Wp-admin/vzaLd8xeI1h.php
INFO - 2024-12-11 07:57:15 --> Config Class Initialized
INFO - 2024-12-11 07:57:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:15 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:15 --> URI Class Initialized
INFO - 2024-12-11 07:57:15 --> Router Class Initialized
INFO - 2024-12-11 07:57:15 --> Output Class Initialized
INFO - 2024-12-11 07:57:15 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:15 --> Input Class Initialized
INFO - 2024-12-11 07:57:15 --> Language Class Initialized
ERROR - 2024-12-11 07:57:15 --> 404 Page Not Found: Wp-admin/RD5Vth4Cqrj.php
INFO - 2024-12-11 07:57:17 --> Config Class Initialized
INFO - 2024-12-11 07:57:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:17 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:17 --> URI Class Initialized
INFO - 2024-12-11 07:57:17 --> Router Class Initialized
INFO - 2024-12-11 07:57:17 --> Output Class Initialized
INFO - 2024-12-11 07:57:17 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:17 --> Input Class Initialized
INFO - 2024-12-11 07:57:17 --> Language Class Initialized
ERROR - 2024-12-11 07:57:17 --> 404 Page Not Found: Wp-admin/R37YCfIhTnw.php
INFO - 2024-12-11 07:57:18 --> Config Class Initialized
INFO - 2024-12-11 07:57:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:18 --> URI Class Initialized
INFO - 2024-12-11 07:57:18 --> Router Class Initialized
INFO - 2024-12-11 07:57:18 --> Output Class Initialized
INFO - 2024-12-11 07:57:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:18 --> Input Class Initialized
INFO - 2024-12-11 07:57:18 --> Language Class Initialized
ERROR - 2024-12-11 07:57:18 --> 404 Page Not Found: Wp-admin/ZPpKcxDr2eh.php
INFO - 2024-12-11 07:57:19 --> Config Class Initialized
INFO - 2024-12-11 07:57:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:19 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:19 --> URI Class Initialized
INFO - 2024-12-11 07:57:19 --> Router Class Initialized
INFO - 2024-12-11 07:57:19 --> Output Class Initialized
INFO - 2024-12-11 07:57:19 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:19 --> Input Class Initialized
INFO - 2024-12-11 07:57:19 --> Language Class Initialized
ERROR - 2024-12-11 07:57:19 --> 404 Page Not Found: Wp-admin/unSEm8Kf2P6.php
INFO - 2024-12-11 07:57:20 --> Config Class Initialized
INFO - 2024-12-11 07:57:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:20 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:20 --> URI Class Initialized
INFO - 2024-12-11 07:57:20 --> Router Class Initialized
INFO - 2024-12-11 07:57:20 --> Output Class Initialized
INFO - 2024-12-11 07:57:20 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:20 --> Input Class Initialized
INFO - 2024-12-11 07:57:20 --> Language Class Initialized
ERROR - 2024-12-11 07:57:20 --> 404 Page Not Found: Wp-admin/lxKCfkmZiMD.php
INFO - 2024-12-11 07:57:21 --> Config Class Initialized
INFO - 2024-12-11 07:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:21 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:21 --> URI Class Initialized
INFO - 2024-12-11 07:57:21 --> Router Class Initialized
INFO - 2024-12-11 07:57:21 --> Output Class Initialized
INFO - 2024-12-11 07:57:21 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:21 --> Input Class Initialized
INFO - 2024-12-11 07:57:21 --> Language Class Initialized
ERROR - 2024-12-11 07:57:21 --> 404 Page Not Found: Wp-admin/Trka3NUxzu6.php
INFO - 2024-12-11 07:57:22 --> Config Class Initialized
INFO - 2024-12-11 07:57:22 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:22 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:22 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:22 --> URI Class Initialized
INFO - 2024-12-11 07:57:22 --> Router Class Initialized
INFO - 2024-12-11 07:57:22 --> Output Class Initialized
INFO - 2024-12-11 07:57:22 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:22 --> Input Class Initialized
INFO - 2024-12-11 07:57:22 --> Language Class Initialized
ERROR - 2024-12-11 07:57:22 --> 404 Page Not Found: Wp-admin/YCIQl6XUkOw.php
INFO - 2024-12-11 07:57:23 --> Config Class Initialized
INFO - 2024-12-11 07:57:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:23 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:23 --> URI Class Initialized
INFO - 2024-12-11 07:57:23 --> Router Class Initialized
INFO - 2024-12-11 07:57:23 --> Output Class Initialized
INFO - 2024-12-11 07:57:23 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:23 --> Input Class Initialized
INFO - 2024-12-11 07:57:23 --> Language Class Initialized
ERROR - 2024-12-11 07:57:23 --> 404 Page Not Found: Wp-admin/iDf7CPEUBdu.php
INFO - 2024-12-11 07:57:24 --> Config Class Initialized
INFO - 2024-12-11 07:57:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:24 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:24 --> URI Class Initialized
INFO - 2024-12-11 07:57:24 --> Router Class Initialized
INFO - 2024-12-11 07:57:24 --> Output Class Initialized
INFO - 2024-12-11 07:57:24 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:24 --> Input Class Initialized
INFO - 2024-12-11 07:57:24 --> Language Class Initialized
ERROR - 2024-12-11 07:57:24 --> 404 Page Not Found: Wp-admin/1NsglpbmihP.php
INFO - 2024-12-11 07:57:25 --> Config Class Initialized
INFO - 2024-12-11 07:57:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:25 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:25 --> URI Class Initialized
INFO - 2024-12-11 07:57:25 --> Router Class Initialized
INFO - 2024-12-11 07:57:25 --> Output Class Initialized
INFO - 2024-12-11 07:57:25 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:25 --> Input Class Initialized
INFO - 2024-12-11 07:57:25 --> Language Class Initialized
ERROR - 2024-12-11 07:57:25 --> 404 Page Not Found: Wp-admin/cA1nd3DPhLx.php
INFO - 2024-12-11 07:57:28 --> Config Class Initialized
INFO - 2024-12-11 07:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:28 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:28 --> URI Class Initialized
INFO - 2024-12-11 07:57:28 --> Router Class Initialized
INFO - 2024-12-11 07:57:28 --> Output Class Initialized
INFO - 2024-12-11 07:57:28 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:28 --> Input Class Initialized
INFO - 2024-12-11 07:57:28 --> Language Class Initialized
ERROR - 2024-12-11 07:57:28 --> 404 Page Not Found: QRbsjoCFz9Jphp/index
INFO - 2024-12-11 07:57:36 --> Config Class Initialized
INFO - 2024-12-11 07:57:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:36 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:36 --> URI Class Initialized
INFO - 2024-12-11 07:57:36 --> Router Class Initialized
INFO - 2024-12-11 07:57:36 --> Output Class Initialized
INFO - 2024-12-11 07:57:36 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:36 --> Input Class Initialized
INFO - 2024-12-11 07:57:36 --> Language Class Initialized
ERROR - 2024-12-11 07:57:36 --> 404 Page Not Found: InmN2D5Haolphp/index
INFO - 2024-12-11 07:57:41 --> Config Class Initialized
INFO - 2024-12-11 07:57:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:41 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:41 --> URI Class Initialized
INFO - 2024-12-11 07:57:41 --> Router Class Initialized
INFO - 2024-12-11 07:57:41 --> Output Class Initialized
INFO - 2024-12-11 07:57:41 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:41 --> Input Class Initialized
INFO - 2024-12-11 07:57:41 --> Language Class Initialized
ERROR - 2024-12-11 07:57:41 --> 404 Page Not Found: Wp-admin/H4SEiYmCl7t.php
INFO - 2024-12-11 07:57:47 --> Config Class Initialized
INFO - 2024-12-11 07:57:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:47 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:47 --> URI Class Initialized
INFO - 2024-12-11 07:57:47 --> Router Class Initialized
INFO - 2024-12-11 07:57:47 --> Output Class Initialized
INFO - 2024-12-11 07:57:47 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:47 --> Input Class Initialized
INFO - 2024-12-11 07:57:47 --> Language Class Initialized
ERROR - 2024-12-11 07:57:47 --> 404 Page Not Found: QPVAHc4eEONphp/index
INFO - 2024-12-11 07:57:50 --> Config Class Initialized
INFO - 2024-12-11 07:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:50 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:50 --> URI Class Initialized
INFO - 2024-12-11 07:57:50 --> Router Class Initialized
INFO - 2024-12-11 07:57:50 --> Output Class Initialized
INFO - 2024-12-11 07:57:50 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:50 --> Input Class Initialized
INFO - 2024-12-11 07:57:50 --> Language Class Initialized
ERROR - 2024-12-11 07:57:50 --> 404 Page Not Found: Wp-admin/SPycWUDsuGr.php
INFO - 2024-12-11 07:57:51 --> Config Class Initialized
INFO - 2024-12-11 07:57:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:51 --> URI Class Initialized
INFO - 2024-12-11 07:57:51 --> Router Class Initialized
INFO - 2024-12-11 07:57:51 --> Output Class Initialized
INFO - 2024-12-11 07:57:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:51 --> Input Class Initialized
INFO - 2024-12-11 07:57:51 --> Language Class Initialized
ERROR - 2024-12-11 07:57:51 --> 404 Page Not Found: NCo53zRutj9php/index
INFO - 2024-12-11 07:57:52 --> Config Class Initialized
INFO - 2024-12-11 07:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:52 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:52 --> URI Class Initialized
INFO - 2024-12-11 07:57:52 --> Router Class Initialized
INFO - 2024-12-11 07:57:52 --> Output Class Initialized
INFO - 2024-12-11 07:57:52 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:52 --> Input Class Initialized
INFO - 2024-12-11 07:57:52 --> Language Class Initialized
ERROR - 2024-12-11 07:57:52 --> 404 Page Not Found: Ae2d3Y9PMEZphp/index
INFO - 2024-12-11 07:57:57 --> Config Class Initialized
INFO - 2024-12-11 07:57:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:57:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:57:57 --> Utf8 Class Initialized
INFO - 2024-12-11 07:57:57 --> URI Class Initialized
INFO - 2024-12-11 07:57:57 --> Router Class Initialized
INFO - 2024-12-11 07:57:57 --> Output Class Initialized
INFO - 2024-12-11 07:57:57 --> Security Class Initialized
DEBUG - 2024-12-11 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:57:57 --> Input Class Initialized
INFO - 2024-12-11 07:57:57 --> Language Class Initialized
ERROR - 2024-12-11 07:57:57 --> 404 Page Not Found: APsTHSdqGb2php/index
INFO - 2024-12-11 07:58:00 --> Config Class Initialized
INFO - 2024-12-11 07:58:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:00 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:00 --> URI Class Initialized
INFO - 2024-12-11 07:58:00 --> Router Class Initialized
INFO - 2024-12-11 07:58:00 --> Output Class Initialized
INFO - 2024-12-11 07:58:00 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:00 --> Input Class Initialized
INFO - 2024-12-11 07:58:00 --> Language Class Initialized
ERROR - 2024-12-11 07:58:00 --> 404 Page Not Found: RJU8xelhSHEphp/index
INFO - 2024-12-11 07:58:02 --> Config Class Initialized
INFO - 2024-12-11 07:58:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:02 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:02 --> URI Class Initialized
INFO - 2024-12-11 07:58:02 --> Router Class Initialized
INFO - 2024-12-11 07:58:02 --> Output Class Initialized
INFO - 2024-12-11 07:58:02 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:02 --> Input Class Initialized
INFO - 2024-12-11 07:58:02 --> Language Class Initialized
ERROR - 2024-12-11 07:58:02 --> 404 Page Not Found: Wp-admin/zIcBvRxS3PW.php
INFO - 2024-12-11 07:58:05 --> Config Class Initialized
INFO - 2024-12-11 07:58:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:05 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:05 --> URI Class Initialized
INFO - 2024-12-11 07:58:05 --> Router Class Initialized
INFO - 2024-12-11 07:58:05 --> Output Class Initialized
INFO - 2024-12-11 07:58:05 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:05 --> Input Class Initialized
INFO - 2024-12-11 07:58:05 --> Language Class Initialized
ERROR - 2024-12-11 07:58:05 --> 404 Page Not Found: Wp-admin/xBP6GZcW32q.php
INFO - 2024-12-11 07:58:06 --> Config Class Initialized
INFO - 2024-12-11 07:58:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:06 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:06 --> URI Class Initialized
INFO - 2024-12-11 07:58:06 --> Router Class Initialized
INFO - 2024-12-11 07:58:06 --> Output Class Initialized
INFO - 2024-12-11 07:58:06 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:06 --> Input Class Initialized
INFO - 2024-12-11 07:58:06 --> Language Class Initialized
ERROR - 2024-12-11 07:58:06 --> 404 Page Not Found: 6HtUGxR3pDZphp/index
INFO - 2024-12-11 07:58:08 --> Config Class Initialized
INFO - 2024-12-11 07:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:08 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:08 --> URI Class Initialized
INFO - 2024-12-11 07:58:08 --> Router Class Initialized
INFO - 2024-12-11 07:58:08 --> Output Class Initialized
INFO - 2024-12-11 07:58:08 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:08 --> Input Class Initialized
INFO - 2024-12-11 07:58:08 --> Language Class Initialized
ERROR - 2024-12-11 07:58:08 --> 404 Page Not Found: Wp-admin/nhfrpG1W48j.php
INFO - 2024-12-11 07:58:10 --> Config Class Initialized
INFO - 2024-12-11 07:58:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:10 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:10 --> URI Class Initialized
INFO - 2024-12-11 07:58:10 --> Router Class Initialized
INFO - 2024-12-11 07:58:10 --> Output Class Initialized
INFO - 2024-12-11 07:58:10 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:10 --> Input Class Initialized
INFO - 2024-12-11 07:58:10 --> Language Class Initialized
ERROR - 2024-12-11 07:58:10 --> 404 Page Not Found: Wp-admin/JQVplhWGEjT.php
INFO - 2024-12-11 07:58:12 --> Config Class Initialized
INFO - 2024-12-11 07:58:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:12 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:12 --> URI Class Initialized
INFO - 2024-12-11 07:58:12 --> Router Class Initialized
INFO - 2024-12-11 07:58:12 --> Output Class Initialized
INFO - 2024-12-11 07:58:12 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:12 --> Input Class Initialized
INFO - 2024-12-11 07:58:12 --> Language Class Initialized
ERROR - 2024-12-11 07:58:12 --> 404 Page Not Found: Wp-admin/a5uPEjzehk1.php
INFO - 2024-12-11 07:58:14 --> Config Class Initialized
INFO - 2024-12-11 07:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:14 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:14 --> URI Class Initialized
INFO - 2024-12-11 07:58:14 --> Router Class Initialized
INFO - 2024-12-11 07:58:14 --> Output Class Initialized
INFO - 2024-12-11 07:58:14 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:14 --> Input Class Initialized
INFO - 2024-12-11 07:58:14 --> Language Class Initialized
ERROR - 2024-12-11 07:58:14 --> 404 Page Not Found: Wp-admin/Gu2NdI1gPFL.php
INFO - 2024-12-11 07:58:18 --> Config Class Initialized
INFO - 2024-12-11 07:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:18 --> URI Class Initialized
INFO - 2024-12-11 07:58:18 --> Router Class Initialized
INFO - 2024-12-11 07:58:18 --> Output Class Initialized
INFO - 2024-12-11 07:58:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:18 --> Input Class Initialized
INFO - 2024-12-11 07:58:18 --> Language Class Initialized
ERROR - 2024-12-11 07:58:18 --> 404 Page Not Found: Wp-admin/CjJ1wlcvVzU.php
INFO - 2024-12-11 07:58:18 --> Config Class Initialized
INFO - 2024-12-11 07:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:18 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:18 --> URI Class Initialized
INFO - 2024-12-11 07:58:18 --> Router Class Initialized
INFO - 2024-12-11 07:58:18 --> Output Class Initialized
INFO - 2024-12-11 07:58:18 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:18 --> Input Class Initialized
INFO - 2024-12-11 07:58:18 --> Language Class Initialized
ERROR - 2024-12-11 07:58:18 --> 404 Page Not Found: Wp-admin/XDKCe7dfgim.php
INFO - 2024-12-11 07:58:19 --> Config Class Initialized
INFO - 2024-12-11 07:58:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:19 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:19 --> URI Class Initialized
INFO - 2024-12-11 07:58:19 --> Router Class Initialized
INFO - 2024-12-11 07:58:19 --> Output Class Initialized
INFO - 2024-12-11 07:58:19 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:19 --> Input Class Initialized
INFO - 2024-12-11 07:58:19 --> Language Class Initialized
ERROR - 2024-12-11 07:58:19 --> 404 Page Not Found: Wp-admin/TqbrGSylIoC.php
INFO - 2024-12-11 07:58:20 --> Config Class Initialized
INFO - 2024-12-11 07:58:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:20 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:20 --> URI Class Initialized
INFO - 2024-12-11 07:58:20 --> Router Class Initialized
INFO - 2024-12-11 07:58:20 --> Output Class Initialized
INFO - 2024-12-11 07:58:20 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:20 --> Input Class Initialized
INFO - 2024-12-11 07:58:20 --> Language Class Initialized
ERROR - 2024-12-11 07:58:20 --> 404 Page Not Found: Wp-admin/lwkpqx1UJ9f.php
INFO - 2024-12-11 07:58:25 --> Config Class Initialized
INFO - 2024-12-11 07:58:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:25 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:25 --> URI Class Initialized
INFO - 2024-12-11 07:58:25 --> Router Class Initialized
INFO - 2024-12-11 07:58:25 --> Output Class Initialized
INFO - 2024-12-11 07:58:25 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:25 --> Input Class Initialized
INFO - 2024-12-11 07:58:25 --> Language Class Initialized
ERROR - 2024-12-11 07:58:25 --> 404 Page Not Found: Wp-admin/vtXe2CGYWo7.php
INFO - 2024-12-11 07:58:26 --> Config Class Initialized
INFO - 2024-12-11 07:58:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:26 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:26 --> URI Class Initialized
INFO - 2024-12-11 07:58:26 --> Router Class Initialized
INFO - 2024-12-11 07:58:26 --> Output Class Initialized
INFO - 2024-12-11 07:58:26 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:26 --> Input Class Initialized
INFO - 2024-12-11 07:58:26 --> Language Class Initialized
ERROR - 2024-12-11 07:58:26 --> 404 Page Not Found: Wp-admin/3atWH1PVUE5.php
INFO - 2024-12-11 07:58:26 --> Config Class Initialized
INFO - 2024-12-11 07:58:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:26 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:26 --> URI Class Initialized
INFO - 2024-12-11 07:58:26 --> Router Class Initialized
INFO - 2024-12-11 07:58:26 --> Output Class Initialized
INFO - 2024-12-11 07:58:26 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:26 --> Input Class Initialized
INFO - 2024-12-11 07:58:26 --> Language Class Initialized
ERROR - 2024-12-11 07:58:26 --> 404 Page Not Found: Wp-admin/I3UXbCfrRkW.php
INFO - 2024-12-11 07:58:29 --> Config Class Initialized
INFO - 2024-12-11 07:58:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:29 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:29 --> URI Class Initialized
INFO - 2024-12-11 07:58:29 --> Router Class Initialized
INFO - 2024-12-11 07:58:29 --> Output Class Initialized
INFO - 2024-12-11 07:58:29 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:29 --> Input Class Initialized
INFO - 2024-12-11 07:58:29 --> Language Class Initialized
ERROR - 2024-12-11 07:58:29 --> 404 Page Not Found: J2OIxTcQdFJphp/index
INFO - 2024-12-11 07:58:31 --> Config Class Initialized
INFO - 2024-12-11 07:58:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:31 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:31 --> URI Class Initialized
INFO - 2024-12-11 07:58:31 --> Router Class Initialized
INFO - 2024-12-11 07:58:31 --> Output Class Initialized
INFO - 2024-12-11 07:58:31 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:31 --> Input Class Initialized
INFO - 2024-12-11 07:58:31 --> Language Class Initialized
ERROR - 2024-12-11 07:58:31 --> 404 Page Not Found: Wp-admin/ciCtTwgNHKo.php
INFO - 2024-12-11 07:58:38 --> Config Class Initialized
INFO - 2024-12-11 07:58:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:38 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:38 --> URI Class Initialized
INFO - 2024-12-11 07:58:38 --> Router Class Initialized
INFO - 2024-12-11 07:58:38 --> Output Class Initialized
INFO - 2024-12-11 07:58:38 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:38 --> Input Class Initialized
INFO - 2024-12-11 07:58:38 --> Language Class Initialized
ERROR - 2024-12-11 07:58:38 --> 404 Page Not Found: CeDgIsRE2SPphp/index
INFO - 2024-12-11 07:58:47 --> Config Class Initialized
INFO - 2024-12-11 07:58:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:47 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:47 --> URI Class Initialized
INFO - 2024-12-11 07:58:47 --> Router Class Initialized
INFO - 2024-12-11 07:58:47 --> Output Class Initialized
INFO - 2024-12-11 07:58:47 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:47 --> Input Class Initialized
INFO - 2024-12-11 07:58:47 --> Language Class Initialized
ERROR - 2024-12-11 07:58:47 --> 404 Page Not Found: Wp-admin/UpKYHjMPagu.php
INFO - 2024-12-11 07:58:49 --> Config Class Initialized
INFO - 2024-12-11 07:58:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:49 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:49 --> URI Class Initialized
INFO - 2024-12-11 07:58:49 --> Router Class Initialized
INFO - 2024-12-11 07:58:49 --> Output Class Initialized
INFO - 2024-12-11 07:58:49 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:49 --> Input Class Initialized
INFO - 2024-12-11 07:58:49 --> Language Class Initialized
ERROR - 2024-12-11 07:58:49 --> 404 Page Not Found: SwW2oAIqSyrphp/index
INFO - 2024-12-11 07:58:50 --> Config Class Initialized
INFO - 2024-12-11 07:58:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:50 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:50 --> URI Class Initialized
INFO - 2024-12-11 07:58:50 --> Router Class Initialized
INFO - 2024-12-11 07:58:50 --> Output Class Initialized
INFO - 2024-12-11 07:58:50 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:50 --> Input Class Initialized
INFO - 2024-12-11 07:58:50 --> Language Class Initialized
ERROR - 2024-12-11 07:58:50 --> 404 Page Not Found: Wp-admin/E6sDY4FPQJg.php
INFO - 2024-12-11 07:58:51 --> Config Class Initialized
INFO - 2024-12-11 07:58:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:51 --> URI Class Initialized
INFO - 2024-12-11 07:58:51 --> Router Class Initialized
INFO - 2024-12-11 07:58:51 --> Output Class Initialized
INFO - 2024-12-11 07:58:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:51 --> Input Class Initialized
INFO - 2024-12-11 07:58:51 --> Language Class Initialized
ERROR - 2024-12-11 07:58:51 --> 404 Page Not Found: Wp-admin/LsSTylNuZqw.php
INFO - 2024-12-11 07:58:53 --> Config Class Initialized
INFO - 2024-12-11 07:58:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:53 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:53 --> URI Class Initialized
INFO - 2024-12-11 07:58:53 --> Router Class Initialized
INFO - 2024-12-11 07:58:53 --> Output Class Initialized
INFO - 2024-12-11 07:58:53 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:53 --> Input Class Initialized
INFO - 2024-12-11 07:58:53 --> Language Class Initialized
ERROR - 2024-12-11 07:58:53 --> 404 Page Not Found: Wp-admin/muiR6HcIzNG.php
INFO - 2024-12-11 07:58:55 --> Config Class Initialized
INFO - 2024-12-11 07:58:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:55 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:55 --> URI Class Initialized
INFO - 2024-12-11 07:58:55 --> Router Class Initialized
INFO - 2024-12-11 07:58:55 --> Output Class Initialized
INFO - 2024-12-11 07:58:55 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:55 --> Input Class Initialized
INFO - 2024-12-11 07:58:55 --> Language Class Initialized
ERROR - 2024-12-11 07:58:55 --> 404 Page Not Found: Wp-admin/DuG1xUHMwnK.php
INFO - 2024-12-11 07:58:56 --> Config Class Initialized
INFO - 2024-12-11 07:58:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:56 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:56 --> URI Class Initialized
INFO - 2024-12-11 07:58:56 --> Router Class Initialized
INFO - 2024-12-11 07:58:56 --> Output Class Initialized
INFO - 2024-12-11 07:58:56 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:56 --> Input Class Initialized
INFO - 2024-12-11 07:58:56 --> Language Class Initialized
ERROR - 2024-12-11 07:58:56 --> 404 Page Not Found: Fo1t9ewGOZ5php/index
INFO - 2024-12-11 07:58:57 --> Config Class Initialized
INFO - 2024-12-11 07:58:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:58:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:58:57 --> Utf8 Class Initialized
INFO - 2024-12-11 07:58:57 --> URI Class Initialized
INFO - 2024-12-11 07:58:57 --> Router Class Initialized
INFO - 2024-12-11 07:58:57 --> Output Class Initialized
INFO - 2024-12-11 07:58:57 --> Security Class Initialized
DEBUG - 2024-12-11 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:58:57 --> Input Class Initialized
INFO - 2024-12-11 07:58:57 --> Language Class Initialized
ERROR - 2024-12-11 07:58:57 --> 404 Page Not Found: Wp-admin/QWKfSgUkrby.php
INFO - 2024-12-11 07:59:01 --> Config Class Initialized
INFO - 2024-12-11 07:59:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:01 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:01 --> URI Class Initialized
INFO - 2024-12-11 07:59:01 --> Router Class Initialized
INFO - 2024-12-11 07:59:01 --> Output Class Initialized
INFO - 2024-12-11 07:59:01 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:01 --> Input Class Initialized
INFO - 2024-12-11 07:59:01 --> Language Class Initialized
ERROR - 2024-12-11 07:59:01 --> 404 Page Not Found: Wp-admin/CwVKpXHxcW8.php
INFO - 2024-12-11 07:59:02 --> Config Class Initialized
INFO - 2024-12-11 07:59:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:02 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:02 --> URI Class Initialized
INFO - 2024-12-11 07:59:02 --> Router Class Initialized
INFO - 2024-12-11 07:59:02 --> Output Class Initialized
INFO - 2024-12-11 07:59:02 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:02 --> Input Class Initialized
INFO - 2024-12-11 07:59:02 --> Language Class Initialized
ERROR - 2024-12-11 07:59:02 --> 404 Page Not Found: Wp-admin/RCPY3HtIQ5a.php
INFO - 2024-12-11 07:59:04 --> Config Class Initialized
INFO - 2024-12-11 07:59:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:04 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:04 --> URI Class Initialized
INFO - 2024-12-11 07:59:04 --> Router Class Initialized
INFO - 2024-12-11 07:59:04 --> Output Class Initialized
INFO - 2024-12-11 07:59:04 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:04 --> Input Class Initialized
INFO - 2024-12-11 07:59:04 --> Language Class Initialized
ERROR - 2024-12-11 07:59:04 --> 404 Page Not Found: Wp-admin/oBndQ2JSH4C.php
INFO - 2024-12-11 07:59:08 --> Config Class Initialized
INFO - 2024-12-11 07:59:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:08 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:08 --> URI Class Initialized
INFO - 2024-12-11 07:59:08 --> Router Class Initialized
INFO - 2024-12-11 07:59:08 --> Output Class Initialized
INFO - 2024-12-11 07:59:08 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:08 --> Input Class Initialized
INFO - 2024-12-11 07:59:08 --> Language Class Initialized
ERROR - 2024-12-11 07:59:08 --> 404 Page Not Found: Wp-admin/CvsmexRHBqU.php
INFO - 2024-12-11 07:59:20 --> Config Class Initialized
INFO - 2024-12-11 07:59:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:20 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:20 --> URI Class Initialized
INFO - 2024-12-11 07:59:20 --> Router Class Initialized
INFO - 2024-12-11 07:59:20 --> Output Class Initialized
INFO - 2024-12-11 07:59:20 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:20 --> Input Class Initialized
INFO - 2024-12-11 07:59:20 --> Language Class Initialized
ERROR - 2024-12-11 07:59:20 --> 404 Page Not Found: XQqloKbZYgCphp/index
INFO - 2024-12-11 07:59:23 --> Config Class Initialized
INFO - 2024-12-11 07:59:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:23 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:23 --> URI Class Initialized
INFO - 2024-12-11 07:59:23 --> Router Class Initialized
INFO - 2024-12-11 07:59:23 --> Output Class Initialized
INFO - 2024-12-11 07:59:23 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:23 --> Input Class Initialized
INFO - 2024-12-11 07:59:23 --> Language Class Initialized
ERROR - 2024-12-11 07:59:23 --> 404 Page Not Found: NL78M4RCWsOphp/index
INFO - 2024-12-11 07:59:25 --> Config Class Initialized
INFO - 2024-12-11 07:59:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:25 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:25 --> URI Class Initialized
INFO - 2024-12-11 07:59:25 --> Router Class Initialized
INFO - 2024-12-11 07:59:25 --> Output Class Initialized
INFO - 2024-12-11 07:59:25 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:25 --> Input Class Initialized
INFO - 2024-12-11 07:59:25 --> Language Class Initialized
ERROR - 2024-12-11 07:59:25 --> 404 Page Not Found: Wp-admin/KlIYHMGVnyc.php
INFO - 2024-12-11 07:59:25 --> Config Class Initialized
INFO - 2024-12-11 07:59:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:25 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:25 --> URI Class Initialized
INFO - 2024-12-11 07:59:25 --> Router Class Initialized
INFO - 2024-12-11 07:59:25 --> Output Class Initialized
INFO - 2024-12-11 07:59:25 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:25 --> Input Class Initialized
INFO - 2024-12-11 07:59:25 --> Language Class Initialized
ERROR - 2024-12-11 07:59:25 --> 404 Page Not Found: Wp-admin/ct7R6lwIh1W.php
INFO - 2024-12-11 07:59:30 --> Config Class Initialized
INFO - 2024-12-11 07:59:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:30 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:30 --> URI Class Initialized
INFO - 2024-12-11 07:59:30 --> Router Class Initialized
INFO - 2024-12-11 07:59:30 --> Output Class Initialized
INFO - 2024-12-11 07:59:30 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:30 --> Input Class Initialized
INFO - 2024-12-11 07:59:30 --> Language Class Initialized
ERROR - 2024-12-11 07:59:30 --> 404 Page Not Found: Wp-admin/SoBThd4g8lZ.php
INFO - 2024-12-11 07:59:36 --> Config Class Initialized
INFO - 2024-12-11 07:59:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:36 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:36 --> URI Class Initialized
INFO - 2024-12-11 07:59:36 --> Router Class Initialized
INFO - 2024-12-11 07:59:36 --> Output Class Initialized
INFO - 2024-12-11 07:59:36 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:36 --> Input Class Initialized
INFO - 2024-12-11 07:59:36 --> Language Class Initialized
ERROR - 2024-12-11 07:59:36 --> 404 Page Not Found: Wp-admin/ot4xuRp8IEL.php
INFO - 2024-12-11 07:59:39 --> Config Class Initialized
INFO - 2024-12-11 07:59:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:39 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:39 --> URI Class Initialized
INFO - 2024-12-11 07:59:39 --> Router Class Initialized
INFO - 2024-12-11 07:59:39 --> Output Class Initialized
INFO - 2024-12-11 07:59:39 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:39 --> Input Class Initialized
INFO - 2024-12-11 07:59:39 --> Language Class Initialized
ERROR - 2024-12-11 07:59:39 --> 404 Page Not Found: Wp-admin/sWryBKJYDPh.php
INFO - 2024-12-11 07:59:44 --> Config Class Initialized
INFO - 2024-12-11 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:44 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:44 --> URI Class Initialized
INFO - 2024-12-11 07:59:44 --> Router Class Initialized
INFO - 2024-12-11 07:59:44 --> Output Class Initialized
INFO - 2024-12-11 07:59:44 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:44 --> Input Class Initialized
INFO - 2024-12-11 07:59:44 --> Language Class Initialized
ERROR - 2024-12-11 07:59:44 --> 404 Page Not Found: Wp-admin/QFgWt3bwHL8.php
INFO - 2024-12-11 07:59:46 --> Config Class Initialized
INFO - 2024-12-11 07:59:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:46 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:46 --> URI Class Initialized
INFO - 2024-12-11 07:59:46 --> Router Class Initialized
INFO - 2024-12-11 07:59:46 --> Output Class Initialized
INFO - 2024-12-11 07:59:46 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:46 --> Input Class Initialized
INFO - 2024-12-11 07:59:46 --> Language Class Initialized
ERROR - 2024-12-11 07:59:46 --> 404 Page Not Found: Wp-admin/h7cfPADW9op.php
INFO - 2024-12-11 07:59:47 --> Config Class Initialized
INFO - 2024-12-11 07:59:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:47 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:47 --> URI Class Initialized
INFO - 2024-12-11 07:59:47 --> Router Class Initialized
INFO - 2024-12-11 07:59:47 --> Output Class Initialized
INFO - 2024-12-11 07:59:47 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:47 --> Input Class Initialized
INFO - 2024-12-11 07:59:47 --> Language Class Initialized
ERROR - 2024-12-11 07:59:47 --> 404 Page Not Found: Wp-admin/EqdZ37vcxjT.php
INFO - 2024-12-11 07:59:48 --> Config Class Initialized
INFO - 2024-12-11 07:59:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:48 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:48 --> URI Class Initialized
INFO - 2024-12-11 07:59:48 --> Router Class Initialized
INFO - 2024-12-11 07:59:48 --> Output Class Initialized
INFO - 2024-12-11 07:59:48 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:48 --> Input Class Initialized
INFO - 2024-12-11 07:59:48 --> Language Class Initialized
ERROR - 2024-12-11 07:59:48 --> 404 Page Not Found: Wp-admin/Ug2qyA1IcjB.php
INFO - 2024-12-11 07:59:50 --> Config Class Initialized
INFO - 2024-12-11 07:59:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:50 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:50 --> URI Class Initialized
INFO - 2024-12-11 07:59:50 --> Router Class Initialized
INFO - 2024-12-11 07:59:50 --> Output Class Initialized
INFO - 2024-12-11 07:59:50 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:50 --> Input Class Initialized
INFO - 2024-12-11 07:59:50 --> Language Class Initialized
ERROR - 2024-12-11 07:59:50 --> 404 Page Not Found: Wp-admin/dNls67Eq1VP.php
INFO - 2024-12-11 07:59:51 --> Config Class Initialized
INFO - 2024-12-11 07:59:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:51 --> URI Class Initialized
INFO - 2024-12-11 07:59:51 --> Router Class Initialized
INFO - 2024-12-11 07:59:51 --> Output Class Initialized
INFO - 2024-12-11 07:59:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:51 --> Input Class Initialized
INFO - 2024-12-11 07:59:51 --> Language Class Initialized
ERROR - 2024-12-11 07:59:51 --> 404 Page Not Found: Wp-admin/AmRbFD5t8Kk.php
INFO - 2024-12-11 07:59:51 --> Config Class Initialized
INFO - 2024-12-11 07:59:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:51 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:51 --> URI Class Initialized
INFO - 2024-12-11 07:59:51 --> Router Class Initialized
INFO - 2024-12-11 07:59:51 --> Output Class Initialized
INFO - 2024-12-11 07:59:51 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:51 --> Input Class Initialized
INFO - 2024-12-11 07:59:51 --> Language Class Initialized
ERROR - 2024-12-11 07:59:51 --> 404 Page Not Found: Wp-admin/DnkMmtzY8Fx.php
INFO - 2024-12-11 07:59:52 --> Config Class Initialized
INFO - 2024-12-11 07:59:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:52 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:52 --> URI Class Initialized
INFO - 2024-12-11 07:59:52 --> Router Class Initialized
INFO - 2024-12-11 07:59:52 --> Output Class Initialized
INFO - 2024-12-11 07:59:52 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:52 --> Input Class Initialized
INFO - 2024-12-11 07:59:52 --> Language Class Initialized
ERROR - 2024-12-11 07:59:52 --> 404 Page Not Found: Components/4ewufvIGoqA.php
INFO - 2024-12-11 07:59:52 --> Config Class Initialized
INFO - 2024-12-11 07:59:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:52 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:52 --> URI Class Initialized
INFO - 2024-12-11 07:59:52 --> Router Class Initialized
INFO - 2024-12-11 07:59:52 --> Output Class Initialized
INFO - 2024-12-11 07:59:52 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:52 --> Input Class Initialized
INFO - 2024-12-11 07:59:52 --> Language Class Initialized
ERROR - 2024-12-11 07:59:52 --> 404 Page Not Found: Wp-admin/MtNvAy89hVR.php
INFO - 2024-12-11 07:59:54 --> Config Class Initialized
INFO - 2024-12-11 07:59:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:54 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:54 --> URI Class Initialized
INFO - 2024-12-11 07:59:54 --> Router Class Initialized
INFO - 2024-12-11 07:59:54 --> Output Class Initialized
INFO - 2024-12-11 07:59:54 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:54 --> Input Class Initialized
INFO - 2024-12-11 07:59:54 --> Language Class Initialized
ERROR - 2024-12-11 07:59:54 --> 404 Page Not Found: Wp-admin/bFvanS3Vtil.php
INFO - 2024-12-11 07:59:55 --> Config Class Initialized
INFO - 2024-12-11 07:59:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:55 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:55 --> URI Class Initialized
INFO - 2024-12-11 07:59:55 --> Router Class Initialized
INFO - 2024-12-11 07:59:55 --> Output Class Initialized
INFO - 2024-12-11 07:59:55 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:55 --> Input Class Initialized
INFO - 2024-12-11 07:59:55 --> Language Class Initialized
ERROR - 2024-12-11 07:59:55 --> 404 Page Not Found: PUISoNBaEnKphp/index
INFO - 2024-12-11 07:59:57 --> Config Class Initialized
INFO - 2024-12-11 07:59:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 07:59:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 07:59:57 --> Utf8 Class Initialized
INFO - 2024-12-11 07:59:57 --> URI Class Initialized
INFO - 2024-12-11 07:59:57 --> Router Class Initialized
INFO - 2024-12-11 07:59:57 --> Output Class Initialized
INFO - 2024-12-11 07:59:57 --> Security Class Initialized
DEBUG - 2024-12-11 07:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 07:59:57 --> Input Class Initialized
INFO - 2024-12-11 07:59:57 --> Language Class Initialized
ERROR - 2024-12-11 07:59:57 --> 404 Page Not Found: 5Y9iCD6RXVwphp/index
INFO - 2024-12-11 08:00:02 --> Config Class Initialized
INFO - 2024-12-11 08:00:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:02 --> URI Class Initialized
INFO - 2024-12-11 08:00:02 --> Router Class Initialized
INFO - 2024-12-11 08:00:02 --> Output Class Initialized
INFO - 2024-12-11 08:00:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:02 --> Input Class Initialized
INFO - 2024-12-11 08:00:02 --> Language Class Initialized
ERROR - 2024-12-11 08:00:02 --> 404 Page Not Found: Wp-admin/uzOgHSWiJNe.php
INFO - 2024-12-11 08:00:06 --> Config Class Initialized
INFO - 2024-12-11 08:00:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:06 --> URI Class Initialized
INFO - 2024-12-11 08:00:06 --> Router Class Initialized
INFO - 2024-12-11 08:00:06 --> Output Class Initialized
INFO - 2024-12-11 08:00:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:06 --> Input Class Initialized
INFO - 2024-12-11 08:00:06 --> Language Class Initialized
ERROR - 2024-12-11 08:00:06 --> 404 Page Not Found: Wp-admin/n9GwEV6ietu.php
INFO - 2024-12-11 08:00:07 --> Config Class Initialized
INFO - 2024-12-11 08:00:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:07 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:07 --> URI Class Initialized
INFO - 2024-12-11 08:00:07 --> Router Class Initialized
INFO - 2024-12-11 08:00:07 --> Output Class Initialized
INFO - 2024-12-11 08:00:07 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:07 --> Input Class Initialized
INFO - 2024-12-11 08:00:07 --> Language Class Initialized
ERROR - 2024-12-11 08:00:07 --> 404 Page Not Found: Wp-admin/kASWyg28wTQ.php
INFO - 2024-12-11 08:00:11 --> Config Class Initialized
INFO - 2024-12-11 08:00:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:11 --> URI Class Initialized
INFO - 2024-12-11 08:00:11 --> Router Class Initialized
INFO - 2024-12-11 08:00:11 --> Output Class Initialized
INFO - 2024-12-11 08:00:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:11 --> Input Class Initialized
INFO - 2024-12-11 08:00:11 --> Language Class Initialized
ERROR - 2024-12-11 08:00:11 --> 404 Page Not Found: Wp-admin/QFCW7d1yDqo.php
INFO - 2024-12-11 08:00:14 --> Config Class Initialized
INFO - 2024-12-11 08:00:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:14 --> URI Class Initialized
INFO - 2024-12-11 08:00:14 --> Router Class Initialized
INFO - 2024-12-11 08:00:14 --> Output Class Initialized
INFO - 2024-12-11 08:00:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:14 --> Input Class Initialized
INFO - 2024-12-11 08:00:14 --> Language Class Initialized
ERROR - 2024-12-11 08:00:14 --> 404 Page Not Found: Wp-admin/vHTPBC6cyoL.php
INFO - 2024-12-11 08:00:18 --> Config Class Initialized
INFO - 2024-12-11 08:00:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:18 --> URI Class Initialized
INFO - 2024-12-11 08:00:18 --> Router Class Initialized
INFO - 2024-12-11 08:00:18 --> Output Class Initialized
INFO - 2024-12-11 08:00:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:18 --> Input Class Initialized
INFO - 2024-12-11 08:00:18 --> Language Class Initialized
ERROR - 2024-12-11 08:00:18 --> 404 Page Not Found: Wp-admin/uxFcqhjIpzs.php
INFO - 2024-12-11 08:00:21 --> Config Class Initialized
INFO - 2024-12-11 08:00:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:21 --> URI Class Initialized
INFO - 2024-12-11 08:00:21 --> Router Class Initialized
INFO - 2024-12-11 08:00:21 --> Output Class Initialized
INFO - 2024-12-11 08:00:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:21 --> Input Class Initialized
INFO - 2024-12-11 08:00:21 --> Language Class Initialized
ERROR - 2024-12-11 08:00:21 --> 404 Page Not Found: Wp-admin/javQryPZoK8.php
INFO - 2024-12-11 08:00:27 --> Config Class Initialized
INFO - 2024-12-11 08:00:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:27 --> URI Class Initialized
INFO - 2024-12-11 08:00:27 --> Router Class Initialized
INFO - 2024-12-11 08:00:27 --> Output Class Initialized
INFO - 2024-12-11 08:00:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:27 --> Input Class Initialized
INFO - 2024-12-11 08:00:27 --> Language Class Initialized
ERROR - 2024-12-11 08:00:27 --> 404 Page Not Found: Wp-admin/wBq8oXvZr4g.php
INFO - 2024-12-11 08:00:27 --> Config Class Initialized
INFO - 2024-12-11 08:00:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:27 --> URI Class Initialized
INFO - 2024-12-11 08:00:27 --> Router Class Initialized
INFO - 2024-12-11 08:00:27 --> Output Class Initialized
INFO - 2024-12-11 08:00:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:27 --> Input Class Initialized
INFO - 2024-12-11 08:00:27 --> Language Class Initialized
ERROR - 2024-12-11 08:00:27 --> 404 Page Not Found: Hp6TZkc7jsIphp/index
INFO - 2024-12-11 08:00:27 --> Config Class Initialized
INFO - 2024-12-11 08:00:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:27 --> URI Class Initialized
INFO - 2024-12-11 08:00:27 --> Router Class Initialized
INFO - 2024-12-11 08:00:27 --> Output Class Initialized
INFO - 2024-12-11 08:00:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:27 --> Input Class Initialized
INFO - 2024-12-11 08:00:27 --> Language Class Initialized
ERROR - 2024-12-11 08:00:27 --> 404 Page Not Found: Wp-admin/AQ3ZDkzG7Ku.php
INFO - 2024-12-11 08:00:29 --> Config Class Initialized
INFO - 2024-12-11 08:00:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:29 --> URI Class Initialized
INFO - 2024-12-11 08:00:29 --> Router Class Initialized
INFO - 2024-12-11 08:00:29 --> Output Class Initialized
INFO - 2024-12-11 08:00:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:29 --> Input Class Initialized
INFO - 2024-12-11 08:00:29 --> Language Class Initialized
ERROR - 2024-12-11 08:00:29 --> 404 Page Not Found: MgaGjyeHJSDphp/index
INFO - 2024-12-11 08:00:30 --> Config Class Initialized
INFO - 2024-12-11 08:00:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:30 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:30 --> URI Class Initialized
INFO - 2024-12-11 08:00:30 --> Router Class Initialized
INFO - 2024-12-11 08:00:30 --> Output Class Initialized
INFO - 2024-12-11 08:00:30 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:30 --> Input Class Initialized
INFO - 2024-12-11 08:00:30 --> Language Class Initialized
ERROR - 2024-12-11 08:00:30 --> 404 Page Not Found: VnjNzE7DFQOphp/index
INFO - 2024-12-11 08:00:30 --> Config Class Initialized
INFO - 2024-12-11 08:00:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:30 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:30 --> URI Class Initialized
INFO - 2024-12-11 08:00:30 --> Router Class Initialized
INFO - 2024-12-11 08:00:30 --> Output Class Initialized
INFO - 2024-12-11 08:00:30 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:30 --> Input Class Initialized
INFO - 2024-12-11 08:00:30 --> Language Class Initialized
ERROR - 2024-12-11 08:00:30 --> 404 Page Not Found: FDWm7uVaxT3php/index
INFO - 2024-12-11 08:00:33 --> Config Class Initialized
INFO - 2024-12-11 08:00:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:33 --> URI Class Initialized
INFO - 2024-12-11 08:00:33 --> Router Class Initialized
INFO - 2024-12-11 08:00:33 --> Output Class Initialized
INFO - 2024-12-11 08:00:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:33 --> Input Class Initialized
INFO - 2024-12-11 08:00:33 --> Language Class Initialized
ERROR - 2024-12-11 08:00:33 --> 404 Page Not Found: Wp-admin/DPzMq9R7KAL.php
INFO - 2024-12-11 08:00:37 --> Config Class Initialized
INFO - 2024-12-11 08:00:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:37 --> URI Class Initialized
INFO - 2024-12-11 08:00:37 --> Router Class Initialized
INFO - 2024-12-11 08:00:37 --> Output Class Initialized
INFO - 2024-12-11 08:00:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:37 --> Input Class Initialized
INFO - 2024-12-11 08:00:37 --> Language Class Initialized
ERROR - 2024-12-11 08:00:37 --> 404 Page Not Found: P9BGrEMH2TWphp/index
INFO - 2024-12-11 08:00:37 --> Config Class Initialized
INFO - 2024-12-11 08:00:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:37 --> URI Class Initialized
INFO - 2024-12-11 08:00:37 --> Router Class Initialized
INFO - 2024-12-11 08:00:37 --> Output Class Initialized
INFO - 2024-12-11 08:00:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:37 --> Input Class Initialized
INFO - 2024-12-11 08:00:37 --> Language Class Initialized
ERROR - 2024-12-11 08:00:37 --> 404 Page Not Found: Wp-admin/Lmt9syzj4Sp.php
INFO - 2024-12-11 08:00:38 --> Config Class Initialized
INFO - 2024-12-11 08:00:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:38 --> URI Class Initialized
INFO - 2024-12-11 08:00:38 --> Router Class Initialized
INFO - 2024-12-11 08:00:38 --> Output Class Initialized
INFO - 2024-12-11 08:00:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:38 --> Input Class Initialized
INFO - 2024-12-11 08:00:38 --> Language Class Initialized
ERROR - 2024-12-11 08:00:38 --> 404 Page Not Found: Wp-admin/3uLQjF76CJx.php
INFO - 2024-12-11 08:00:39 --> Config Class Initialized
INFO - 2024-12-11 08:00:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:39 --> URI Class Initialized
INFO - 2024-12-11 08:00:39 --> Router Class Initialized
INFO - 2024-12-11 08:00:39 --> Output Class Initialized
INFO - 2024-12-11 08:00:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:39 --> Input Class Initialized
INFO - 2024-12-11 08:00:39 --> Language Class Initialized
ERROR - 2024-12-11 08:00:39 --> 404 Page Not Found: PiRSCMUth2qphp/index
INFO - 2024-12-11 08:00:39 --> Config Class Initialized
INFO - 2024-12-11 08:00:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:39 --> URI Class Initialized
INFO - 2024-12-11 08:00:39 --> Router Class Initialized
INFO - 2024-12-11 08:00:39 --> Output Class Initialized
INFO - 2024-12-11 08:00:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:39 --> Input Class Initialized
INFO - 2024-12-11 08:00:39 --> Language Class Initialized
ERROR - 2024-12-11 08:00:39 --> 404 Page Not Found: Wp-admin/R6giuh4FSMN.php
INFO - 2024-12-11 08:00:43 --> Config Class Initialized
INFO - 2024-12-11 08:00:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:43 --> URI Class Initialized
INFO - 2024-12-11 08:00:43 --> Router Class Initialized
INFO - 2024-12-11 08:00:43 --> Output Class Initialized
INFO - 2024-12-11 08:00:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:43 --> Input Class Initialized
INFO - 2024-12-11 08:00:43 --> Language Class Initialized
ERROR - 2024-12-11 08:00:43 --> 404 Page Not Found: Wp-admin/Er6huC3n5BU.php
INFO - 2024-12-11 08:00:44 --> Config Class Initialized
INFO - 2024-12-11 08:00:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:44 --> URI Class Initialized
INFO - 2024-12-11 08:00:44 --> Router Class Initialized
INFO - 2024-12-11 08:00:44 --> Output Class Initialized
INFO - 2024-12-11 08:00:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:44 --> Input Class Initialized
INFO - 2024-12-11 08:00:44 --> Language Class Initialized
ERROR - 2024-12-11 08:00:44 --> 404 Page Not Found: JUYDtoWzfLrphp/index
INFO - 2024-12-11 08:00:45 --> Config Class Initialized
INFO - 2024-12-11 08:00:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:45 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:45 --> URI Class Initialized
INFO - 2024-12-11 08:00:45 --> Router Class Initialized
INFO - 2024-12-11 08:00:45 --> Output Class Initialized
INFO - 2024-12-11 08:00:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:45 --> Input Class Initialized
INFO - 2024-12-11 08:00:45 --> Language Class Initialized
ERROR - 2024-12-11 08:00:45 --> 404 Page Not Found: WefEZ3MrDipphp/index
INFO - 2024-12-11 08:00:49 --> Config Class Initialized
INFO - 2024-12-11 08:00:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:49 --> URI Class Initialized
INFO - 2024-12-11 08:00:49 --> Router Class Initialized
INFO - 2024-12-11 08:00:49 --> Output Class Initialized
INFO - 2024-12-11 08:00:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:49 --> Input Class Initialized
INFO - 2024-12-11 08:00:49 --> Language Class Initialized
ERROR - 2024-12-11 08:00:49 --> 404 Page Not Found: Wp-admin/X52SkQOCAEb.php
INFO - 2024-12-11 08:00:50 --> Config Class Initialized
INFO - 2024-12-11 08:00:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:50 --> URI Class Initialized
INFO - 2024-12-11 08:00:50 --> Router Class Initialized
INFO - 2024-12-11 08:00:50 --> Output Class Initialized
INFO - 2024-12-11 08:00:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:50 --> Input Class Initialized
INFO - 2024-12-11 08:00:50 --> Language Class Initialized
ERROR - 2024-12-11 08:00:50 --> 404 Page Not Found: Wp-admin/SLnHOVjUmDB.php
INFO - 2024-12-11 08:00:54 --> Config Class Initialized
INFO - 2024-12-11 08:00:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:54 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:54 --> URI Class Initialized
INFO - 2024-12-11 08:00:54 --> Router Class Initialized
INFO - 2024-12-11 08:00:54 --> Output Class Initialized
INFO - 2024-12-11 08:00:54 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:54 --> Input Class Initialized
INFO - 2024-12-11 08:00:54 --> Language Class Initialized
ERROR - 2024-12-11 08:00:54 --> 404 Page Not Found: Wp-admin/xBXtAoNv7G1.php
INFO - 2024-12-11 08:00:56 --> Config Class Initialized
INFO - 2024-12-11 08:00:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:56 --> URI Class Initialized
INFO - 2024-12-11 08:00:56 --> Router Class Initialized
INFO - 2024-12-11 08:00:56 --> Output Class Initialized
INFO - 2024-12-11 08:00:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:56 --> Input Class Initialized
INFO - 2024-12-11 08:00:56 --> Language Class Initialized
ERROR - 2024-12-11 08:00:56 --> 404 Page Not Found: Wp-admin/5t6rFPxbInQ.php
INFO - 2024-12-11 08:00:59 --> Config Class Initialized
INFO - 2024-12-11 08:00:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:00:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:00:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:00:59 --> URI Class Initialized
INFO - 2024-12-11 08:00:59 --> Router Class Initialized
INFO - 2024-12-11 08:00:59 --> Output Class Initialized
INFO - 2024-12-11 08:00:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:00:59 --> Input Class Initialized
INFO - 2024-12-11 08:00:59 --> Language Class Initialized
ERROR - 2024-12-11 08:00:59 --> 404 Page Not Found: Wp-admin/PoEYHGqahiv.php
INFO - 2024-12-11 08:01:02 --> Config Class Initialized
INFO - 2024-12-11 08:01:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:02 --> URI Class Initialized
INFO - 2024-12-11 08:01:02 --> Router Class Initialized
INFO - 2024-12-11 08:01:02 --> Output Class Initialized
INFO - 2024-12-11 08:01:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:02 --> Input Class Initialized
INFO - 2024-12-11 08:01:02 --> Language Class Initialized
ERROR - 2024-12-11 08:01:02 --> 404 Page Not Found: 3WicLqk8Y5Ophp/index
INFO - 2024-12-11 08:01:02 --> Config Class Initialized
INFO - 2024-12-11 08:01:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:02 --> URI Class Initialized
INFO - 2024-12-11 08:01:02 --> Router Class Initialized
INFO - 2024-12-11 08:01:02 --> Output Class Initialized
INFO - 2024-12-11 08:01:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:02 --> Input Class Initialized
INFO - 2024-12-11 08:01:02 --> Language Class Initialized
ERROR - 2024-12-11 08:01:02 --> 404 Page Not Found: Wp-admin/XDQ2WV5Gztd.php
INFO - 2024-12-11 08:01:04 --> Config Class Initialized
INFO - 2024-12-11 08:01:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:04 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:04 --> URI Class Initialized
INFO - 2024-12-11 08:01:04 --> Router Class Initialized
INFO - 2024-12-11 08:01:04 --> Output Class Initialized
INFO - 2024-12-11 08:01:04 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:04 --> Input Class Initialized
INFO - 2024-12-11 08:01:04 --> Language Class Initialized
ERROR - 2024-12-11 08:01:04 --> 404 Page Not Found: DYnarIQoRX5php/index
INFO - 2024-12-11 08:01:09 --> Config Class Initialized
INFO - 2024-12-11 08:01:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:09 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:09 --> URI Class Initialized
INFO - 2024-12-11 08:01:09 --> Router Class Initialized
INFO - 2024-12-11 08:01:09 --> Output Class Initialized
INFO - 2024-12-11 08:01:09 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:09 --> Input Class Initialized
INFO - 2024-12-11 08:01:09 --> Language Class Initialized
ERROR - 2024-12-11 08:01:09 --> 404 Page Not Found: Wp-admin/XvjTtV7Rgxk.php
INFO - 2024-12-11 08:01:10 --> Config Class Initialized
INFO - 2024-12-11 08:01:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:10 --> URI Class Initialized
INFO - 2024-12-11 08:01:10 --> Router Class Initialized
INFO - 2024-12-11 08:01:10 --> Output Class Initialized
INFO - 2024-12-11 08:01:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:10 --> Input Class Initialized
INFO - 2024-12-11 08:01:10 --> Language Class Initialized
ERROR - 2024-12-11 08:01:10 --> 404 Page Not Found: Wp-admin/hRUvN2BKbTo.php
INFO - 2024-12-11 08:01:11 --> Config Class Initialized
INFO - 2024-12-11 08:01:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:11 --> URI Class Initialized
INFO - 2024-12-11 08:01:11 --> Router Class Initialized
INFO - 2024-12-11 08:01:11 --> Output Class Initialized
INFO - 2024-12-11 08:01:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:11 --> Input Class Initialized
INFO - 2024-12-11 08:01:11 --> Language Class Initialized
ERROR - 2024-12-11 08:01:11 --> 404 Page Not Found: Wp-admin/O8auK79lXr4.php
INFO - 2024-12-11 08:01:19 --> Config Class Initialized
INFO - 2024-12-11 08:01:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:19 --> URI Class Initialized
INFO - 2024-12-11 08:01:19 --> Router Class Initialized
INFO - 2024-12-11 08:01:19 --> Output Class Initialized
INFO - 2024-12-11 08:01:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:19 --> Input Class Initialized
INFO - 2024-12-11 08:01:19 --> Language Class Initialized
ERROR - 2024-12-11 08:01:19 --> 404 Page Not Found: Wp-admin/SfEz5onH3WK.php
INFO - 2024-12-11 08:01:23 --> Config Class Initialized
INFO - 2024-12-11 08:01:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:23 --> URI Class Initialized
INFO - 2024-12-11 08:01:23 --> Router Class Initialized
INFO - 2024-12-11 08:01:23 --> Output Class Initialized
INFO - 2024-12-11 08:01:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:23 --> Input Class Initialized
INFO - 2024-12-11 08:01:23 --> Language Class Initialized
ERROR - 2024-12-11 08:01:23 --> 404 Page Not Found: JoviWgMcV1rphp/index
INFO - 2024-12-11 08:01:27 --> Config Class Initialized
INFO - 2024-12-11 08:01:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:27 --> URI Class Initialized
INFO - 2024-12-11 08:01:27 --> Router Class Initialized
INFO - 2024-12-11 08:01:27 --> Output Class Initialized
INFO - 2024-12-11 08:01:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:27 --> Input Class Initialized
INFO - 2024-12-11 08:01:27 --> Language Class Initialized
ERROR - 2024-12-11 08:01:27 --> 404 Page Not Found: C9ePxtsJ3anphp/index
INFO - 2024-12-11 08:01:32 --> Config Class Initialized
INFO - 2024-12-11 08:01:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:32 --> URI Class Initialized
INFO - 2024-12-11 08:01:32 --> Router Class Initialized
INFO - 2024-12-11 08:01:32 --> Output Class Initialized
INFO - 2024-12-11 08:01:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:32 --> Input Class Initialized
INFO - 2024-12-11 08:01:32 --> Language Class Initialized
ERROR - 2024-12-11 08:01:32 --> 404 Page Not Found: DYzkFuQW3mVphp/index
INFO - 2024-12-11 08:01:44 --> Config Class Initialized
INFO - 2024-12-11 08:01:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:44 --> URI Class Initialized
INFO - 2024-12-11 08:01:44 --> Router Class Initialized
INFO - 2024-12-11 08:01:44 --> Output Class Initialized
INFO - 2024-12-11 08:01:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:44 --> Input Class Initialized
INFO - 2024-12-11 08:01:44 --> Language Class Initialized
ERROR - 2024-12-11 08:01:44 --> 404 Page Not Found: Wp-admin/SqnUpINdEca.php
INFO - 2024-12-11 08:01:51 --> Config Class Initialized
INFO - 2024-12-11 08:01:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:51 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:51 --> URI Class Initialized
INFO - 2024-12-11 08:01:51 --> Router Class Initialized
INFO - 2024-12-11 08:01:51 --> Output Class Initialized
INFO - 2024-12-11 08:01:51 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:51 --> Input Class Initialized
INFO - 2024-12-11 08:01:51 --> Language Class Initialized
ERROR - 2024-12-11 08:01:51 --> 404 Page Not Found: Wp-admin/rkOucshDCdp.php
INFO - 2024-12-11 08:01:51 --> Config Class Initialized
INFO - 2024-12-11 08:01:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:51 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:51 --> URI Class Initialized
INFO - 2024-12-11 08:01:51 --> Router Class Initialized
INFO - 2024-12-11 08:01:51 --> Output Class Initialized
INFO - 2024-12-11 08:01:51 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:51 --> Input Class Initialized
INFO - 2024-12-11 08:01:51 --> Language Class Initialized
ERROR - 2024-12-11 08:01:51 --> 404 Page Not Found: Wp-admin/suWlgUZYCSA.php
INFO - 2024-12-11 08:01:56 --> Config Class Initialized
INFO - 2024-12-11 08:01:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:01:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:01:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:01:56 --> URI Class Initialized
INFO - 2024-12-11 08:01:56 --> Router Class Initialized
INFO - 2024-12-11 08:01:56 --> Output Class Initialized
INFO - 2024-12-11 08:01:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:01:56 --> Input Class Initialized
INFO - 2024-12-11 08:01:56 --> Language Class Initialized
ERROR - 2024-12-11 08:01:56 --> 404 Page Not Found: Wp-admin/9st52fAwxeX.php
INFO - 2024-12-11 08:02:00 --> Config Class Initialized
INFO - 2024-12-11 08:02:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:00 --> URI Class Initialized
INFO - 2024-12-11 08:02:00 --> Router Class Initialized
INFO - 2024-12-11 08:02:00 --> Output Class Initialized
INFO - 2024-12-11 08:02:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:00 --> Input Class Initialized
INFO - 2024-12-11 08:02:00 --> Language Class Initialized
ERROR - 2024-12-11 08:02:00 --> 404 Page Not Found: Wp-admin/SDX167dneoU.php
INFO - 2024-12-11 08:02:07 --> Config Class Initialized
INFO - 2024-12-11 08:02:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:07 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:07 --> URI Class Initialized
INFO - 2024-12-11 08:02:07 --> Router Class Initialized
INFO - 2024-12-11 08:02:07 --> Output Class Initialized
INFO - 2024-12-11 08:02:07 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:07 --> Input Class Initialized
INFO - 2024-12-11 08:02:07 --> Language Class Initialized
ERROR - 2024-12-11 08:02:07 --> 404 Page Not Found: Wp-admin/EQ7Z8rXgvM9.php
INFO - 2024-12-11 08:02:09 --> Config Class Initialized
INFO - 2024-12-11 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:09 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:09 --> URI Class Initialized
INFO - 2024-12-11 08:02:09 --> Router Class Initialized
INFO - 2024-12-11 08:02:09 --> Output Class Initialized
INFO - 2024-12-11 08:02:09 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:09 --> Input Class Initialized
INFO - 2024-12-11 08:02:09 --> Language Class Initialized
ERROR - 2024-12-11 08:02:09 --> 404 Page Not Found: Wp-admin/miAOrhNocu4.php
INFO - 2024-12-11 08:02:11 --> Config Class Initialized
INFO - 2024-12-11 08:02:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:11 --> URI Class Initialized
INFO - 2024-12-11 08:02:11 --> Router Class Initialized
INFO - 2024-12-11 08:02:11 --> Output Class Initialized
INFO - 2024-12-11 08:02:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:11 --> Input Class Initialized
INFO - 2024-12-11 08:02:11 --> Language Class Initialized
ERROR - 2024-12-11 08:02:11 --> 404 Page Not Found: Wp-admin/JIB4DNdxKmW.php
INFO - 2024-12-11 08:02:16 --> Config Class Initialized
INFO - 2024-12-11 08:02:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:16 --> URI Class Initialized
INFO - 2024-12-11 08:02:16 --> Router Class Initialized
INFO - 2024-12-11 08:02:16 --> Output Class Initialized
INFO - 2024-12-11 08:02:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:16 --> Input Class Initialized
INFO - 2024-12-11 08:02:16 --> Language Class Initialized
ERROR - 2024-12-11 08:02:16 --> 404 Page Not Found: Wp-admin/hsM64BStoVX.php
INFO - 2024-12-11 08:02:17 --> Config Class Initialized
INFO - 2024-12-11 08:02:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:17 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:17 --> URI Class Initialized
INFO - 2024-12-11 08:02:17 --> Router Class Initialized
INFO - 2024-12-11 08:02:17 --> Output Class Initialized
INFO - 2024-12-11 08:02:17 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:17 --> Input Class Initialized
INFO - 2024-12-11 08:02:17 --> Language Class Initialized
ERROR - 2024-12-11 08:02:17 --> 404 Page Not Found: Wp-admin/YwDGu19A5UE.php
INFO - 2024-12-11 08:02:18 --> Config Class Initialized
INFO - 2024-12-11 08:02:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:18 --> URI Class Initialized
INFO - 2024-12-11 08:02:18 --> Router Class Initialized
INFO - 2024-12-11 08:02:18 --> Output Class Initialized
INFO - 2024-12-11 08:02:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:18 --> Input Class Initialized
INFO - 2024-12-11 08:02:18 --> Language Class Initialized
ERROR - 2024-12-11 08:02:18 --> 404 Page Not Found: Wp-admin/vUJdni8hkLr.php
INFO - 2024-12-11 08:02:23 --> Config Class Initialized
INFO - 2024-12-11 08:02:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:23 --> URI Class Initialized
INFO - 2024-12-11 08:02:23 --> Router Class Initialized
INFO - 2024-12-11 08:02:23 --> Output Class Initialized
INFO - 2024-12-11 08:02:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:23 --> Input Class Initialized
INFO - 2024-12-11 08:02:23 --> Language Class Initialized
ERROR - 2024-12-11 08:02:23 --> 404 Page Not Found: FfD1hkTIdOKphp/index
INFO - 2024-12-11 08:02:24 --> Config Class Initialized
INFO - 2024-12-11 08:02:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:24 --> URI Class Initialized
INFO - 2024-12-11 08:02:24 --> Router Class Initialized
INFO - 2024-12-11 08:02:24 --> Output Class Initialized
INFO - 2024-12-11 08:02:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:24 --> Input Class Initialized
INFO - 2024-12-11 08:02:24 --> Language Class Initialized
ERROR - 2024-12-11 08:02:24 --> 404 Page Not Found: Wp-admin/tBPDLqjOyiu.php
INFO - 2024-12-11 08:02:27 --> Config Class Initialized
INFO - 2024-12-11 08:02:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:27 --> URI Class Initialized
INFO - 2024-12-11 08:02:27 --> Router Class Initialized
INFO - 2024-12-11 08:02:27 --> Output Class Initialized
INFO - 2024-12-11 08:02:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:27 --> Input Class Initialized
INFO - 2024-12-11 08:02:27 --> Language Class Initialized
ERROR - 2024-12-11 08:02:27 --> 404 Page Not Found: Wp-admin/u7GWs4DmU9q.php
INFO - 2024-12-11 08:02:27 --> Config Class Initialized
INFO - 2024-12-11 08:02:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:27 --> URI Class Initialized
INFO - 2024-12-11 08:02:27 --> Router Class Initialized
INFO - 2024-12-11 08:02:27 --> Output Class Initialized
INFO - 2024-12-11 08:02:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:27 --> Input Class Initialized
INFO - 2024-12-11 08:02:27 --> Language Class Initialized
ERROR - 2024-12-11 08:02:27 --> 404 Page Not Found: HMjNuJfybSsphp/index
INFO - 2024-12-11 08:02:36 --> Config Class Initialized
INFO - 2024-12-11 08:02:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:36 --> URI Class Initialized
INFO - 2024-12-11 08:02:36 --> Router Class Initialized
INFO - 2024-12-11 08:02:36 --> Output Class Initialized
INFO - 2024-12-11 08:02:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:36 --> Input Class Initialized
INFO - 2024-12-11 08:02:36 --> Language Class Initialized
ERROR - 2024-12-11 08:02:36 --> 404 Page Not Found: Wp-admin/Blg3xYbeqIr.php
INFO - 2024-12-11 08:02:37 --> Config Class Initialized
INFO - 2024-12-11 08:02:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:37 --> URI Class Initialized
INFO - 2024-12-11 08:02:37 --> Router Class Initialized
INFO - 2024-12-11 08:02:37 --> Output Class Initialized
INFO - 2024-12-11 08:02:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:37 --> Input Class Initialized
INFO - 2024-12-11 08:02:37 --> Language Class Initialized
ERROR - 2024-12-11 08:02:37 --> 404 Page Not Found: Wp-admin/bxUHQj59ouC.php
INFO - 2024-12-11 08:02:44 --> Config Class Initialized
INFO - 2024-12-11 08:02:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:44 --> URI Class Initialized
INFO - 2024-12-11 08:02:44 --> Router Class Initialized
INFO - 2024-12-11 08:02:44 --> Output Class Initialized
INFO - 2024-12-11 08:02:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:44 --> Input Class Initialized
INFO - 2024-12-11 08:02:44 --> Language Class Initialized
ERROR - 2024-12-11 08:02:44 --> 404 Page Not Found: Wp-admin/sOafJ8QbgA4.php
INFO - 2024-12-11 08:02:56 --> Config Class Initialized
INFO - 2024-12-11 08:02:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:02:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:02:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:02:56 --> URI Class Initialized
INFO - 2024-12-11 08:02:56 --> Router Class Initialized
INFO - 2024-12-11 08:02:56 --> Output Class Initialized
INFO - 2024-12-11 08:02:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:02:56 --> Input Class Initialized
INFO - 2024-12-11 08:02:56 --> Language Class Initialized
ERROR - 2024-12-11 08:02:56 --> 404 Page Not Found: Wp-admin/Ov1HXYiEreM.php
INFO - 2024-12-11 08:03:11 --> Config Class Initialized
INFO - 2024-12-11 08:03:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:11 --> URI Class Initialized
INFO - 2024-12-11 08:03:11 --> Router Class Initialized
INFO - 2024-12-11 08:03:11 --> Output Class Initialized
INFO - 2024-12-11 08:03:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:11 --> Input Class Initialized
INFO - 2024-12-11 08:03:11 --> Language Class Initialized
ERROR - 2024-12-11 08:03:11 --> 404 Page Not Found: Wp-admin/qWC5PX1fRbO.php
INFO - 2024-12-11 08:03:13 --> Config Class Initialized
INFO - 2024-12-11 08:03:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:13 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:13 --> URI Class Initialized
INFO - 2024-12-11 08:03:13 --> Router Class Initialized
INFO - 2024-12-11 08:03:13 --> Output Class Initialized
INFO - 2024-12-11 08:03:13 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:13 --> Input Class Initialized
INFO - 2024-12-11 08:03:13 --> Language Class Initialized
ERROR - 2024-12-11 08:03:13 --> 404 Page Not Found: Wp-admin/mXZhLR4kfI7.php
INFO - 2024-12-11 08:03:16 --> Config Class Initialized
INFO - 2024-12-11 08:03:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:16 --> URI Class Initialized
INFO - 2024-12-11 08:03:16 --> Router Class Initialized
INFO - 2024-12-11 08:03:16 --> Output Class Initialized
INFO - 2024-12-11 08:03:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:16 --> Input Class Initialized
INFO - 2024-12-11 08:03:16 --> Language Class Initialized
ERROR - 2024-12-11 08:03:16 --> 404 Page Not Found: Wp-admin/HjVEbnczS51.php
INFO - 2024-12-11 08:03:23 --> Config Class Initialized
INFO - 2024-12-11 08:03:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:23 --> URI Class Initialized
INFO - 2024-12-11 08:03:23 --> Router Class Initialized
INFO - 2024-12-11 08:03:23 --> Output Class Initialized
INFO - 2024-12-11 08:03:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:23 --> Input Class Initialized
INFO - 2024-12-11 08:03:23 --> Language Class Initialized
ERROR - 2024-12-11 08:03:23 --> 404 Page Not Found: Wp-admin/MfA4l7nRtGv.php
INFO - 2024-12-11 08:03:24 --> Config Class Initialized
INFO - 2024-12-11 08:03:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:24 --> URI Class Initialized
INFO - 2024-12-11 08:03:24 --> Router Class Initialized
INFO - 2024-12-11 08:03:24 --> Output Class Initialized
INFO - 2024-12-11 08:03:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:24 --> Input Class Initialized
INFO - 2024-12-11 08:03:24 --> Language Class Initialized
ERROR - 2024-12-11 08:03:24 --> 404 Page Not Found: KIn7Jsbqj8Pphp/index
INFO - 2024-12-11 08:03:25 --> Config Class Initialized
INFO - 2024-12-11 08:03:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:25 --> URI Class Initialized
INFO - 2024-12-11 08:03:25 --> Router Class Initialized
INFO - 2024-12-11 08:03:25 --> Output Class Initialized
INFO - 2024-12-11 08:03:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:25 --> Input Class Initialized
INFO - 2024-12-11 08:03:25 --> Language Class Initialized
ERROR - 2024-12-11 08:03:25 --> 404 Page Not Found: X6R5fkgPSqrphp/index
INFO - 2024-12-11 08:03:25 --> Config Class Initialized
INFO - 2024-12-11 08:03:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:25 --> URI Class Initialized
INFO - 2024-12-11 08:03:25 --> Router Class Initialized
INFO - 2024-12-11 08:03:25 --> Output Class Initialized
INFO - 2024-12-11 08:03:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:25 --> Input Class Initialized
INFO - 2024-12-11 08:03:25 --> Language Class Initialized
ERROR - 2024-12-11 08:03:25 --> 404 Page Not Found: Wp-admin/epEWV3s6Zmn.php
INFO - 2024-12-11 08:03:25 --> Config Class Initialized
INFO - 2024-12-11 08:03:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:25 --> URI Class Initialized
INFO - 2024-12-11 08:03:25 --> Router Class Initialized
INFO - 2024-12-11 08:03:25 --> Output Class Initialized
INFO - 2024-12-11 08:03:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:25 --> Input Class Initialized
INFO - 2024-12-11 08:03:25 --> Language Class Initialized
ERROR - 2024-12-11 08:03:25 --> 404 Page Not Found: BseMj489U2uphp/index
INFO - 2024-12-11 08:03:30 --> Config Class Initialized
INFO - 2024-12-11 08:03:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:30 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:30 --> URI Class Initialized
INFO - 2024-12-11 08:03:30 --> Router Class Initialized
INFO - 2024-12-11 08:03:30 --> Output Class Initialized
INFO - 2024-12-11 08:03:30 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:30 --> Input Class Initialized
INFO - 2024-12-11 08:03:30 --> Language Class Initialized
ERROR - 2024-12-11 08:03:30 --> 404 Page Not Found: Wp-admin/KquVb8Zcgmv.php
INFO - 2024-12-11 08:03:33 --> Config Class Initialized
INFO - 2024-12-11 08:03:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:33 --> URI Class Initialized
INFO - 2024-12-11 08:03:33 --> Router Class Initialized
INFO - 2024-12-11 08:03:33 --> Output Class Initialized
INFO - 2024-12-11 08:03:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:33 --> Input Class Initialized
INFO - 2024-12-11 08:03:33 --> Language Class Initialized
ERROR - 2024-12-11 08:03:33 --> 404 Page Not Found: Wp-admin/aTAvtDqNdyY.php
INFO - 2024-12-11 08:03:38 --> Config Class Initialized
INFO - 2024-12-11 08:03:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:38 --> URI Class Initialized
INFO - 2024-12-11 08:03:38 --> Router Class Initialized
INFO - 2024-12-11 08:03:38 --> Output Class Initialized
INFO - 2024-12-11 08:03:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:38 --> Input Class Initialized
INFO - 2024-12-11 08:03:38 --> Language Class Initialized
ERROR - 2024-12-11 08:03:38 --> 404 Page Not Found: L8alz5VS6yrphp/index
INFO - 2024-12-11 08:03:40 --> Config Class Initialized
INFO - 2024-12-11 08:03:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:40 --> URI Class Initialized
INFO - 2024-12-11 08:03:40 --> Router Class Initialized
INFO - 2024-12-11 08:03:40 --> Output Class Initialized
INFO - 2024-12-11 08:03:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:40 --> Input Class Initialized
INFO - 2024-12-11 08:03:40 --> Language Class Initialized
ERROR - 2024-12-11 08:03:40 --> 404 Page Not Found: Wp-admin/28ij9yJkCXN.php
INFO - 2024-12-11 08:03:40 --> Config Class Initialized
INFO - 2024-12-11 08:03:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:40 --> URI Class Initialized
INFO - 2024-12-11 08:03:40 --> Router Class Initialized
INFO - 2024-12-11 08:03:40 --> Output Class Initialized
INFO - 2024-12-11 08:03:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:40 --> Input Class Initialized
INFO - 2024-12-11 08:03:40 --> Language Class Initialized
ERROR - 2024-12-11 08:03:40 --> 404 Page Not Found: Wp-admin/7Hc24EZs8uJ.php
INFO - 2024-12-11 08:03:42 --> Config Class Initialized
INFO - 2024-12-11 08:03:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:42 --> URI Class Initialized
INFO - 2024-12-11 08:03:42 --> Router Class Initialized
INFO - 2024-12-11 08:03:42 --> Output Class Initialized
INFO - 2024-12-11 08:03:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:42 --> Input Class Initialized
INFO - 2024-12-11 08:03:42 --> Language Class Initialized
ERROR - 2024-12-11 08:03:42 --> 404 Page Not Found: Wp-admin/HJdfy2GBREp.php
INFO - 2024-12-11 08:03:48 --> Config Class Initialized
INFO - 2024-12-11 08:03:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:48 --> URI Class Initialized
INFO - 2024-12-11 08:03:48 --> Router Class Initialized
INFO - 2024-12-11 08:03:48 --> Output Class Initialized
INFO - 2024-12-11 08:03:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:48 --> Input Class Initialized
INFO - 2024-12-11 08:03:48 --> Language Class Initialized
ERROR - 2024-12-11 08:03:48 --> 404 Page Not Found: Components/rogIQYitlTm.php
INFO - 2024-12-11 08:03:53 --> Config Class Initialized
INFO - 2024-12-11 08:03:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:53 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:53 --> URI Class Initialized
INFO - 2024-12-11 08:03:53 --> Router Class Initialized
INFO - 2024-12-11 08:03:53 --> Output Class Initialized
INFO - 2024-12-11 08:03:53 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:53 --> Input Class Initialized
INFO - 2024-12-11 08:03:53 --> Language Class Initialized
ERROR - 2024-12-11 08:03:53 --> 404 Page Not Found: 285Vg3RBHZpphp/index
INFO - 2024-12-11 08:03:53 --> Config Class Initialized
INFO - 2024-12-11 08:03:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:53 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:53 --> URI Class Initialized
INFO - 2024-12-11 08:03:53 --> Router Class Initialized
INFO - 2024-12-11 08:03:53 --> Output Class Initialized
INFO - 2024-12-11 08:03:53 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:53 --> Input Class Initialized
INFO - 2024-12-11 08:03:53 --> Language Class Initialized
ERROR - 2024-12-11 08:03:53 --> 404 Page Not Found: SLrbvWtMEpGphp/index
INFO - 2024-12-11 08:03:54 --> Config Class Initialized
INFO - 2024-12-11 08:03:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:54 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:54 --> URI Class Initialized
INFO - 2024-12-11 08:03:54 --> Router Class Initialized
INFO - 2024-12-11 08:03:54 --> Output Class Initialized
INFO - 2024-12-11 08:03:54 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:54 --> Input Class Initialized
INFO - 2024-12-11 08:03:54 --> Language Class Initialized
ERROR - 2024-12-11 08:03:54 --> 404 Page Not Found: Wp-admin/eso9RTHbO8x.php
INFO - 2024-12-11 08:03:55 --> Config Class Initialized
INFO - 2024-12-11 08:03:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:55 --> URI Class Initialized
INFO - 2024-12-11 08:03:55 --> Router Class Initialized
INFO - 2024-12-11 08:03:55 --> Output Class Initialized
INFO - 2024-12-11 08:03:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:55 --> Input Class Initialized
INFO - 2024-12-11 08:03:55 --> Language Class Initialized
ERROR - 2024-12-11 08:03:55 --> 404 Page Not Found: Components/dpF5OX1DSWP.php
INFO - 2024-12-11 08:03:56 --> Config Class Initialized
INFO - 2024-12-11 08:03:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:56 --> URI Class Initialized
INFO - 2024-12-11 08:03:56 --> Router Class Initialized
INFO - 2024-12-11 08:03:56 --> Output Class Initialized
INFO - 2024-12-11 08:03:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:56 --> Input Class Initialized
INFO - 2024-12-11 08:03:56 --> Language Class Initialized
ERROR - 2024-12-11 08:03:56 --> 404 Page Not Found: Wp-admin/Z2Dri8ypXbv.php
INFO - 2024-12-11 08:03:57 --> Config Class Initialized
INFO - 2024-12-11 08:03:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:57 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:57 --> URI Class Initialized
INFO - 2024-12-11 08:03:57 --> Router Class Initialized
INFO - 2024-12-11 08:03:57 --> Output Class Initialized
INFO - 2024-12-11 08:03:57 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:57 --> Input Class Initialized
INFO - 2024-12-11 08:03:57 --> Language Class Initialized
ERROR - 2024-12-11 08:03:57 --> 404 Page Not Found: Wp-admin/khV93Mq8tO7.php
INFO - 2024-12-11 08:03:58 --> Config Class Initialized
INFO - 2024-12-11 08:03:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:58 --> URI Class Initialized
INFO - 2024-12-11 08:03:58 --> Router Class Initialized
INFO - 2024-12-11 08:03:58 --> Output Class Initialized
INFO - 2024-12-11 08:03:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:58 --> Input Class Initialized
INFO - 2024-12-11 08:03:58 --> Language Class Initialized
ERROR - 2024-12-11 08:03:58 --> 404 Page Not Found: Wp-admin/ipjqJNwcm95.php
INFO - 2024-12-11 08:03:58 --> Config Class Initialized
INFO - 2024-12-11 08:03:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:58 --> URI Class Initialized
INFO - 2024-12-11 08:03:58 --> Router Class Initialized
INFO - 2024-12-11 08:03:58 --> Output Class Initialized
INFO - 2024-12-11 08:03:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:58 --> Input Class Initialized
INFO - 2024-12-11 08:03:58 --> Language Class Initialized
ERROR - 2024-12-11 08:03:58 --> 404 Page Not Found: Wp-admin/VRP3CzTEDc5.php
INFO - 2024-12-11 08:03:59 --> Config Class Initialized
INFO - 2024-12-11 08:03:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:59 --> URI Class Initialized
INFO - 2024-12-11 08:03:59 --> Router Class Initialized
INFO - 2024-12-11 08:03:59 --> Output Class Initialized
INFO - 2024-12-11 08:03:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:59 --> Input Class Initialized
INFO - 2024-12-11 08:03:59 --> Language Class Initialized
ERROR - 2024-12-11 08:03:59 --> 404 Page Not Found: YuVkxDYtm6hphp/index
INFO - 2024-12-11 08:03:59 --> Config Class Initialized
INFO - 2024-12-11 08:03:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:03:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:03:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:03:59 --> URI Class Initialized
INFO - 2024-12-11 08:03:59 --> Router Class Initialized
INFO - 2024-12-11 08:03:59 --> Output Class Initialized
INFO - 2024-12-11 08:03:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:03:59 --> Input Class Initialized
INFO - 2024-12-11 08:03:59 --> Language Class Initialized
ERROR - 2024-12-11 08:03:59 --> 404 Page Not Found: Wp-admin/dliFmj4oL8b.php
INFO - 2024-12-11 08:04:00 --> Config Class Initialized
INFO - 2024-12-11 08:04:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:00 --> URI Class Initialized
INFO - 2024-12-11 08:04:00 --> Router Class Initialized
INFO - 2024-12-11 08:04:00 --> Output Class Initialized
INFO - 2024-12-11 08:04:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:00 --> Input Class Initialized
INFO - 2024-12-11 08:04:00 --> Language Class Initialized
ERROR - 2024-12-11 08:04:00 --> 404 Page Not Found: Wp-admin/pWd3rZ7vuIK.php
INFO - 2024-12-11 08:04:05 --> Config Class Initialized
INFO - 2024-12-11 08:04:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:05 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:05 --> URI Class Initialized
INFO - 2024-12-11 08:04:05 --> Router Class Initialized
INFO - 2024-12-11 08:04:05 --> Output Class Initialized
INFO - 2024-12-11 08:04:05 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:05 --> Input Class Initialized
INFO - 2024-12-11 08:04:05 --> Language Class Initialized
ERROR - 2024-12-11 08:04:05 --> 404 Page Not Found: Wp-admin/Y4uV9XDAxlB.php
INFO - 2024-12-11 08:04:09 --> Config Class Initialized
INFO - 2024-12-11 08:04:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:09 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:09 --> URI Class Initialized
INFO - 2024-12-11 08:04:09 --> Router Class Initialized
INFO - 2024-12-11 08:04:09 --> Output Class Initialized
INFO - 2024-12-11 08:04:09 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:09 --> Input Class Initialized
INFO - 2024-12-11 08:04:09 --> Language Class Initialized
ERROR - 2024-12-11 08:04:09 --> 404 Page Not Found: Wp-admin/MdznBLlyb1I.php
INFO - 2024-12-11 08:04:10 --> Config Class Initialized
INFO - 2024-12-11 08:04:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:10 --> URI Class Initialized
INFO - 2024-12-11 08:04:10 --> Router Class Initialized
INFO - 2024-12-11 08:04:10 --> Output Class Initialized
INFO - 2024-12-11 08:04:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:10 --> Input Class Initialized
INFO - 2024-12-11 08:04:10 --> Language Class Initialized
ERROR - 2024-12-11 08:04:10 --> 404 Page Not Found: Wp-admin/TIhPmgnR3qL.php
INFO - 2024-12-11 08:04:16 --> Config Class Initialized
INFO - 2024-12-11 08:04:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:16 --> URI Class Initialized
INFO - 2024-12-11 08:04:16 --> Router Class Initialized
INFO - 2024-12-11 08:04:16 --> Output Class Initialized
INFO - 2024-12-11 08:04:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:16 --> Input Class Initialized
INFO - 2024-12-11 08:04:16 --> Language Class Initialized
ERROR - 2024-12-11 08:04:16 --> 404 Page Not Found: 3pXOiWKM9jTphp/index
INFO - 2024-12-11 08:04:19 --> Config Class Initialized
INFO - 2024-12-11 08:04:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:19 --> URI Class Initialized
INFO - 2024-12-11 08:04:19 --> Router Class Initialized
INFO - 2024-12-11 08:04:19 --> Output Class Initialized
INFO - 2024-12-11 08:04:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:19 --> Input Class Initialized
INFO - 2024-12-11 08:04:19 --> Language Class Initialized
ERROR - 2024-12-11 08:04:19 --> 404 Page Not Found: Wp-admin/y43kd2CJmnA.php
INFO - 2024-12-11 08:04:22 --> Config Class Initialized
INFO - 2024-12-11 08:04:22 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:22 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:22 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:22 --> URI Class Initialized
INFO - 2024-12-11 08:04:22 --> Router Class Initialized
INFO - 2024-12-11 08:04:22 --> Output Class Initialized
INFO - 2024-12-11 08:04:22 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:22 --> Input Class Initialized
INFO - 2024-12-11 08:04:22 --> Language Class Initialized
ERROR - 2024-12-11 08:04:22 --> 404 Page Not Found: FiBj8ctGmY3php/index
INFO - 2024-12-11 08:04:24 --> Config Class Initialized
INFO - 2024-12-11 08:04:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:24 --> URI Class Initialized
INFO - 2024-12-11 08:04:24 --> Router Class Initialized
INFO - 2024-12-11 08:04:24 --> Output Class Initialized
INFO - 2024-12-11 08:04:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:24 --> Input Class Initialized
INFO - 2024-12-11 08:04:24 --> Language Class Initialized
ERROR - 2024-12-11 08:04:24 --> 404 Page Not Found: Wp-admin/hgfM8SanFOZ.php
INFO - 2024-12-11 08:04:25 --> Config Class Initialized
INFO - 2024-12-11 08:04:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:25 --> URI Class Initialized
INFO - 2024-12-11 08:04:25 --> Router Class Initialized
INFO - 2024-12-11 08:04:25 --> Output Class Initialized
INFO - 2024-12-11 08:04:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:25 --> Input Class Initialized
INFO - 2024-12-11 08:04:25 --> Language Class Initialized
ERROR - 2024-12-11 08:04:25 --> 404 Page Not Found: Wp-admin/Hxol8N51P3y.php
INFO - 2024-12-11 08:04:27 --> Config Class Initialized
INFO - 2024-12-11 08:04:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:27 --> URI Class Initialized
INFO - 2024-12-11 08:04:27 --> Router Class Initialized
INFO - 2024-12-11 08:04:27 --> Output Class Initialized
INFO - 2024-12-11 08:04:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:27 --> Input Class Initialized
INFO - 2024-12-11 08:04:27 --> Language Class Initialized
ERROR - 2024-12-11 08:04:27 --> 404 Page Not Found: Wp-admin/FdG5Hhn6PTL.php
INFO - 2024-12-11 08:04:28 --> Config Class Initialized
INFO - 2024-12-11 08:04:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:28 --> URI Class Initialized
INFO - 2024-12-11 08:04:28 --> Router Class Initialized
INFO - 2024-12-11 08:04:28 --> Output Class Initialized
INFO - 2024-12-11 08:04:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:28 --> Input Class Initialized
INFO - 2024-12-11 08:04:28 --> Language Class Initialized
ERROR - 2024-12-11 08:04:28 --> 404 Page Not Found: Wp-admin/EqWMymw81hD.php
INFO - 2024-12-11 08:04:33 --> Config Class Initialized
INFO - 2024-12-11 08:04:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:33 --> URI Class Initialized
INFO - 2024-12-11 08:04:33 --> Router Class Initialized
INFO - 2024-12-11 08:04:33 --> Output Class Initialized
INFO - 2024-12-11 08:04:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:33 --> Input Class Initialized
INFO - 2024-12-11 08:04:33 --> Language Class Initialized
ERROR - 2024-12-11 08:04:33 --> 404 Page Not Found: DfWSUD72Fxyphp/index
INFO - 2024-12-11 08:04:34 --> Config Class Initialized
INFO - 2024-12-11 08:04:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:34 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:34 --> URI Class Initialized
INFO - 2024-12-11 08:04:34 --> Router Class Initialized
INFO - 2024-12-11 08:04:34 --> Output Class Initialized
INFO - 2024-12-11 08:04:34 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:34 --> Input Class Initialized
INFO - 2024-12-11 08:04:34 --> Language Class Initialized
ERROR - 2024-12-11 08:04:34 --> 404 Page Not Found: Wp-admin/gc1ueN9Mlot.php
INFO - 2024-12-11 08:04:52 --> Config Class Initialized
INFO - 2024-12-11 08:04:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:52 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:52 --> URI Class Initialized
INFO - 2024-12-11 08:04:52 --> Router Class Initialized
INFO - 2024-12-11 08:04:52 --> Output Class Initialized
INFO - 2024-12-11 08:04:52 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:52 --> Input Class Initialized
INFO - 2024-12-11 08:04:52 --> Language Class Initialized
ERROR - 2024-12-11 08:04:52 --> 404 Page Not Found: Wp-admin/u5EdJX3yYU4.php
INFO - 2024-12-11 08:04:54 --> Config Class Initialized
INFO - 2024-12-11 08:04:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:54 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:54 --> URI Class Initialized
INFO - 2024-12-11 08:04:54 --> Router Class Initialized
INFO - 2024-12-11 08:04:54 --> Output Class Initialized
INFO - 2024-12-11 08:04:54 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:54 --> Input Class Initialized
INFO - 2024-12-11 08:04:54 --> Language Class Initialized
ERROR - 2024-12-11 08:04:54 --> 404 Page Not Found: Wp-admin/bXcCSVYx3dF.php
INFO - 2024-12-11 08:04:55 --> Config Class Initialized
INFO - 2024-12-11 08:04:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:55 --> URI Class Initialized
INFO - 2024-12-11 08:04:55 --> Router Class Initialized
INFO - 2024-12-11 08:04:55 --> Output Class Initialized
INFO - 2024-12-11 08:04:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:55 --> Input Class Initialized
INFO - 2024-12-11 08:04:55 --> Language Class Initialized
ERROR - 2024-12-11 08:04:55 --> 404 Page Not Found: Wp-admin/tiqD8ZAmfhB.php
INFO - 2024-12-11 08:04:56 --> Config Class Initialized
INFO - 2024-12-11 08:04:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:56 --> URI Class Initialized
INFO - 2024-12-11 08:04:56 --> Router Class Initialized
INFO - 2024-12-11 08:04:56 --> Output Class Initialized
INFO - 2024-12-11 08:04:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:56 --> Input Class Initialized
INFO - 2024-12-11 08:04:56 --> Language Class Initialized
ERROR - 2024-12-11 08:04:56 --> 404 Page Not Found: Wp-admin/gAOByolWURr.php
INFO - 2024-12-11 08:04:59 --> Config Class Initialized
INFO - 2024-12-11 08:04:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:04:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:04:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:04:59 --> URI Class Initialized
INFO - 2024-12-11 08:04:59 --> Router Class Initialized
INFO - 2024-12-11 08:04:59 --> Output Class Initialized
INFO - 2024-12-11 08:04:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:04:59 --> Input Class Initialized
INFO - 2024-12-11 08:04:59 --> Language Class Initialized
ERROR - 2024-12-11 08:04:59 --> 404 Page Not Found: SmPBZRdWcrzphp/index
INFO - 2024-12-11 08:05:00 --> Config Class Initialized
INFO - 2024-12-11 08:05:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:00 --> URI Class Initialized
INFO - 2024-12-11 08:05:00 --> Router Class Initialized
INFO - 2024-12-11 08:05:00 --> Output Class Initialized
INFO - 2024-12-11 08:05:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:00 --> Input Class Initialized
INFO - 2024-12-11 08:05:00 --> Language Class Initialized
ERROR - 2024-12-11 08:05:00 --> 404 Page Not Found: Ymxfi9rzboOphp/index
INFO - 2024-12-11 08:05:01 --> Config Class Initialized
INFO - 2024-12-11 08:05:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:01 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:01 --> URI Class Initialized
INFO - 2024-12-11 08:05:01 --> Router Class Initialized
INFO - 2024-12-11 08:05:01 --> Output Class Initialized
INFO - 2024-12-11 08:05:01 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:01 --> Input Class Initialized
INFO - 2024-12-11 08:05:01 --> Language Class Initialized
ERROR - 2024-12-11 08:05:01 --> 404 Page Not Found: Wp-admin/QKPsD6wu3AF.php
INFO - 2024-12-11 08:05:06 --> Config Class Initialized
INFO - 2024-12-11 08:05:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:06 --> URI Class Initialized
INFO - 2024-12-11 08:05:06 --> Router Class Initialized
INFO - 2024-12-11 08:05:06 --> Output Class Initialized
INFO - 2024-12-11 08:05:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:06 --> Input Class Initialized
INFO - 2024-12-11 08:05:06 --> Language Class Initialized
ERROR - 2024-12-11 08:05:06 --> 404 Page Not Found: BzWTsCrQR2cphp/index
INFO - 2024-12-11 08:05:11 --> Config Class Initialized
INFO - 2024-12-11 08:05:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:11 --> URI Class Initialized
INFO - 2024-12-11 08:05:11 --> Router Class Initialized
INFO - 2024-12-11 08:05:11 --> Output Class Initialized
INFO - 2024-12-11 08:05:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:11 --> Input Class Initialized
INFO - 2024-12-11 08:05:11 --> Language Class Initialized
ERROR - 2024-12-11 08:05:11 --> 404 Page Not Found: NlFHmxwq5piphp/index
INFO - 2024-12-11 08:05:16 --> Config Class Initialized
INFO - 2024-12-11 08:05:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:16 --> URI Class Initialized
INFO - 2024-12-11 08:05:16 --> Router Class Initialized
INFO - 2024-12-11 08:05:16 --> Output Class Initialized
INFO - 2024-12-11 08:05:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:16 --> Input Class Initialized
INFO - 2024-12-11 08:05:16 --> Language Class Initialized
ERROR - 2024-12-11 08:05:16 --> 404 Page Not Found: Wp-admin/gySdI8DmUKz.php
INFO - 2024-12-11 08:05:16 --> Config Class Initialized
INFO - 2024-12-11 08:05:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:16 --> URI Class Initialized
INFO - 2024-12-11 08:05:16 --> Router Class Initialized
INFO - 2024-12-11 08:05:16 --> Output Class Initialized
INFO - 2024-12-11 08:05:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:16 --> Input Class Initialized
INFO - 2024-12-11 08:05:16 --> Language Class Initialized
ERROR - 2024-12-11 08:05:16 --> 404 Page Not Found: Wp-admin/4lwI98pMdmD.php
INFO - 2024-12-11 08:05:17 --> Config Class Initialized
INFO - 2024-12-11 08:05:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:17 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:17 --> URI Class Initialized
INFO - 2024-12-11 08:05:17 --> Router Class Initialized
INFO - 2024-12-11 08:05:17 --> Output Class Initialized
INFO - 2024-12-11 08:05:17 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:17 --> Input Class Initialized
INFO - 2024-12-11 08:05:17 --> Language Class Initialized
ERROR - 2024-12-11 08:05:17 --> 404 Page Not Found: Wp-admin/4g93wCevDqp.php
INFO - 2024-12-11 08:05:20 --> Config Class Initialized
INFO - 2024-12-11 08:05:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:20 --> URI Class Initialized
INFO - 2024-12-11 08:05:20 --> Router Class Initialized
INFO - 2024-12-11 08:05:20 --> Output Class Initialized
INFO - 2024-12-11 08:05:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:20 --> Input Class Initialized
INFO - 2024-12-11 08:05:20 --> Language Class Initialized
ERROR - 2024-12-11 08:05:20 --> 404 Page Not Found: 4nZrd9oaxsvphp/index
INFO - 2024-12-11 08:05:21 --> Config Class Initialized
INFO - 2024-12-11 08:05:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:21 --> URI Class Initialized
INFO - 2024-12-11 08:05:21 --> Router Class Initialized
INFO - 2024-12-11 08:05:21 --> Output Class Initialized
INFO - 2024-12-11 08:05:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:21 --> Input Class Initialized
INFO - 2024-12-11 08:05:21 --> Language Class Initialized
ERROR - 2024-12-11 08:05:21 --> 404 Page Not Found: CUBIRkMHXNKphp/index
INFO - 2024-12-11 08:05:23 --> Config Class Initialized
INFO - 2024-12-11 08:05:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:23 --> URI Class Initialized
INFO - 2024-12-11 08:05:23 --> Router Class Initialized
INFO - 2024-12-11 08:05:23 --> Output Class Initialized
INFO - 2024-12-11 08:05:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:23 --> Input Class Initialized
INFO - 2024-12-11 08:05:23 --> Language Class Initialized
ERROR - 2024-12-11 08:05:23 --> 404 Page Not Found: Wp-admin/4CBR6m8Ofqp.php
INFO - 2024-12-11 08:05:24 --> Config Class Initialized
INFO - 2024-12-11 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:24 --> URI Class Initialized
INFO - 2024-12-11 08:05:24 --> Router Class Initialized
INFO - 2024-12-11 08:05:24 --> Output Class Initialized
INFO - 2024-12-11 08:05:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:24 --> Input Class Initialized
INFO - 2024-12-11 08:05:24 --> Language Class Initialized
ERROR - 2024-12-11 08:05:24 --> 404 Page Not Found: Wp-admin/KYkCFat6wrc.php
INFO - 2024-12-11 08:05:31 --> Config Class Initialized
INFO - 2024-12-11 08:05:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:31 --> URI Class Initialized
INFO - 2024-12-11 08:05:31 --> Router Class Initialized
INFO - 2024-12-11 08:05:31 --> Output Class Initialized
INFO - 2024-12-11 08:05:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:31 --> Input Class Initialized
INFO - 2024-12-11 08:05:31 --> Language Class Initialized
ERROR - 2024-12-11 08:05:31 --> 404 Page Not Found: Wp-admin/A4bGn2p9jWz.php
INFO - 2024-12-11 08:05:33 --> Config Class Initialized
INFO - 2024-12-11 08:05:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:33 --> URI Class Initialized
INFO - 2024-12-11 08:05:33 --> Router Class Initialized
INFO - 2024-12-11 08:05:33 --> Output Class Initialized
INFO - 2024-12-11 08:05:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:33 --> Input Class Initialized
INFO - 2024-12-11 08:05:33 --> Language Class Initialized
ERROR - 2024-12-11 08:05:33 --> 404 Page Not Found: Wp-admin/vNl8MKYPGyp.php
INFO - 2024-12-11 08:05:35 --> Config Class Initialized
INFO - 2024-12-11 08:05:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:35 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:35 --> URI Class Initialized
INFO - 2024-12-11 08:05:35 --> Router Class Initialized
INFO - 2024-12-11 08:05:35 --> Output Class Initialized
INFO - 2024-12-11 08:05:35 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:35 --> Input Class Initialized
INFO - 2024-12-11 08:05:35 --> Language Class Initialized
ERROR - 2024-12-11 08:05:35 --> 404 Page Not Found: Wp-admin/HuM6SZoPWvL.php
INFO - 2024-12-11 08:05:38 --> Config Class Initialized
INFO - 2024-12-11 08:05:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:38 --> URI Class Initialized
INFO - 2024-12-11 08:05:38 --> Router Class Initialized
INFO - 2024-12-11 08:05:38 --> Output Class Initialized
INFO - 2024-12-11 08:05:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:38 --> Input Class Initialized
INFO - 2024-12-11 08:05:38 --> Language Class Initialized
ERROR - 2024-12-11 08:05:38 --> 404 Page Not Found: Wp-admin/hwxOQEfFUMT.php
INFO - 2024-12-11 08:05:39 --> Config Class Initialized
INFO - 2024-12-11 08:05:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:39 --> URI Class Initialized
INFO - 2024-12-11 08:05:39 --> Router Class Initialized
INFO - 2024-12-11 08:05:39 --> Output Class Initialized
INFO - 2024-12-11 08:05:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:39 --> Input Class Initialized
INFO - 2024-12-11 08:05:39 --> Language Class Initialized
ERROR - 2024-12-11 08:05:39 --> 404 Page Not Found: Wp-admin/sV4AR5WKQ2C.php
INFO - 2024-12-11 08:05:41 --> Config Class Initialized
INFO - 2024-12-11 08:05:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:41 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:41 --> URI Class Initialized
INFO - 2024-12-11 08:05:41 --> Router Class Initialized
INFO - 2024-12-11 08:05:41 --> Output Class Initialized
INFO - 2024-12-11 08:05:41 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:41 --> Input Class Initialized
INFO - 2024-12-11 08:05:41 --> Language Class Initialized
ERROR - 2024-12-11 08:05:41 --> 404 Page Not Found: Bhk49ZId735php/index
INFO - 2024-12-11 08:05:44 --> Config Class Initialized
INFO - 2024-12-11 08:05:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:44 --> URI Class Initialized
INFO - 2024-12-11 08:05:44 --> Router Class Initialized
INFO - 2024-12-11 08:05:44 --> Output Class Initialized
INFO - 2024-12-11 08:05:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:44 --> Input Class Initialized
INFO - 2024-12-11 08:05:44 --> Language Class Initialized
ERROR - 2024-12-11 08:05:44 --> 404 Page Not Found: Wp-admin/kxwfP8FsZtA.php
INFO - 2024-12-11 08:05:46 --> Config Class Initialized
INFO - 2024-12-11 08:05:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:46 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:46 --> URI Class Initialized
INFO - 2024-12-11 08:05:46 --> Router Class Initialized
INFO - 2024-12-11 08:05:46 --> Output Class Initialized
INFO - 2024-12-11 08:05:46 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:46 --> Input Class Initialized
INFO - 2024-12-11 08:05:46 --> Language Class Initialized
ERROR - 2024-12-11 08:05:46 --> 404 Page Not Found: Wp-admin/scuaxR824bh.php
INFO - 2024-12-11 08:05:48 --> Config Class Initialized
INFO - 2024-12-11 08:05:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:48 --> URI Class Initialized
INFO - 2024-12-11 08:05:48 --> Router Class Initialized
INFO - 2024-12-11 08:05:48 --> Output Class Initialized
INFO - 2024-12-11 08:05:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:48 --> Input Class Initialized
INFO - 2024-12-11 08:05:48 --> Language Class Initialized
ERROR - 2024-12-11 08:05:48 --> 404 Page Not Found: X791sPZvCEaphp/index
INFO - 2024-12-11 08:05:50 --> Config Class Initialized
INFO - 2024-12-11 08:05:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:50 --> URI Class Initialized
INFO - 2024-12-11 08:05:50 --> Router Class Initialized
INFO - 2024-12-11 08:05:50 --> Output Class Initialized
INFO - 2024-12-11 08:05:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:50 --> Input Class Initialized
INFO - 2024-12-11 08:05:50 --> Language Class Initialized
ERROR - 2024-12-11 08:05:50 --> 404 Page Not Found: Wp-admin/k5lefq27ZgW.php
INFO - 2024-12-11 08:05:58 --> Config Class Initialized
INFO - 2024-12-11 08:05:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:05:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:05:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:05:58 --> URI Class Initialized
INFO - 2024-12-11 08:05:58 --> Router Class Initialized
INFO - 2024-12-11 08:05:58 --> Output Class Initialized
INFO - 2024-12-11 08:05:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:05:58 --> Input Class Initialized
INFO - 2024-12-11 08:05:58 --> Language Class Initialized
ERROR - 2024-12-11 08:05:58 --> 404 Page Not Found: Wp-admin/q9NoDSUfnJv.php
INFO - 2024-12-11 08:06:06 --> Config Class Initialized
INFO - 2024-12-11 08:06:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:06 --> URI Class Initialized
INFO - 2024-12-11 08:06:06 --> Router Class Initialized
INFO - 2024-12-11 08:06:06 --> Output Class Initialized
INFO - 2024-12-11 08:06:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:06 --> Input Class Initialized
INFO - 2024-12-11 08:06:06 --> Language Class Initialized
ERROR - 2024-12-11 08:06:06 --> 404 Page Not Found: Wp-admin/EQk3Dn8dKHp.php
INFO - 2024-12-11 08:06:06 --> Config Class Initialized
INFO - 2024-12-11 08:06:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:06 --> URI Class Initialized
INFO - 2024-12-11 08:06:06 --> Router Class Initialized
INFO - 2024-12-11 08:06:06 --> Output Class Initialized
INFO - 2024-12-11 08:06:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:06 --> Input Class Initialized
INFO - 2024-12-11 08:06:06 --> Language Class Initialized
ERROR - 2024-12-11 08:06:06 --> 404 Page Not Found: Wp-admin/h9fqid1OGJa.php
INFO - 2024-12-11 08:06:16 --> Config Class Initialized
INFO - 2024-12-11 08:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:16 --> URI Class Initialized
INFO - 2024-12-11 08:06:16 --> Router Class Initialized
INFO - 2024-12-11 08:06:16 --> Output Class Initialized
INFO - 2024-12-11 08:06:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:16 --> Input Class Initialized
INFO - 2024-12-11 08:06:16 --> Language Class Initialized
ERROR - 2024-12-11 08:06:16 --> 404 Page Not Found: Wp-admin/idq3OMgoyPe.php
INFO - 2024-12-11 08:06:16 --> Config Class Initialized
INFO - 2024-12-11 08:06:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:16 --> URI Class Initialized
INFO - 2024-12-11 08:06:16 --> Router Class Initialized
INFO - 2024-12-11 08:06:16 --> Output Class Initialized
INFO - 2024-12-11 08:06:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:16 --> Input Class Initialized
INFO - 2024-12-11 08:06:16 --> Language Class Initialized
ERROR - 2024-12-11 08:06:16 --> 404 Page Not Found: UnIPw421GRHphp/index
INFO - 2024-12-11 08:06:18 --> Config Class Initialized
INFO - 2024-12-11 08:06:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:18 --> URI Class Initialized
INFO - 2024-12-11 08:06:18 --> Router Class Initialized
INFO - 2024-12-11 08:06:18 --> Output Class Initialized
INFO - 2024-12-11 08:06:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:18 --> Input Class Initialized
INFO - 2024-12-11 08:06:18 --> Language Class Initialized
ERROR - 2024-12-11 08:06:18 --> 404 Page Not Found: Wp-admin/Qj3SRyghdxV.php
INFO - 2024-12-11 08:06:20 --> Config Class Initialized
INFO - 2024-12-11 08:06:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:20 --> URI Class Initialized
INFO - 2024-12-11 08:06:20 --> Router Class Initialized
INFO - 2024-12-11 08:06:20 --> Output Class Initialized
INFO - 2024-12-11 08:06:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:20 --> Input Class Initialized
INFO - 2024-12-11 08:06:20 --> Language Class Initialized
ERROR - 2024-12-11 08:06:20 --> 404 Page Not Found: Wp-admin/XvqKJbouAki.php
INFO - 2024-12-11 08:06:20 --> Config Class Initialized
INFO - 2024-12-11 08:06:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:20 --> URI Class Initialized
INFO - 2024-12-11 08:06:20 --> Router Class Initialized
INFO - 2024-12-11 08:06:20 --> Output Class Initialized
INFO - 2024-12-11 08:06:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:20 --> Input Class Initialized
INFO - 2024-12-11 08:06:20 --> Language Class Initialized
ERROR - 2024-12-11 08:06:20 --> 404 Page Not Found: UabVjiNPlkephp/index
INFO - 2024-12-11 08:06:23 --> Config Class Initialized
INFO - 2024-12-11 08:06:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:23 --> URI Class Initialized
INFO - 2024-12-11 08:06:23 --> Router Class Initialized
INFO - 2024-12-11 08:06:23 --> Output Class Initialized
INFO - 2024-12-11 08:06:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:23 --> Input Class Initialized
INFO - 2024-12-11 08:06:23 --> Language Class Initialized
ERROR - 2024-12-11 08:06:23 --> 404 Page Not Found: Wp-admin/CMR2bIADB5X.php
INFO - 2024-12-11 08:06:23 --> Config Class Initialized
INFO - 2024-12-11 08:06:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:23 --> URI Class Initialized
INFO - 2024-12-11 08:06:23 --> Router Class Initialized
INFO - 2024-12-11 08:06:23 --> Output Class Initialized
INFO - 2024-12-11 08:06:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:23 --> Input Class Initialized
INFO - 2024-12-11 08:06:23 --> Language Class Initialized
ERROR - 2024-12-11 08:06:23 --> 404 Page Not Found: 7chPvSRLyarphp/index
INFO - 2024-12-11 08:06:25 --> Config Class Initialized
INFO - 2024-12-11 08:06:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:25 --> URI Class Initialized
INFO - 2024-12-11 08:06:25 --> Router Class Initialized
INFO - 2024-12-11 08:06:25 --> Output Class Initialized
INFO - 2024-12-11 08:06:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:25 --> Input Class Initialized
INFO - 2024-12-11 08:06:25 --> Language Class Initialized
ERROR - 2024-12-11 08:06:25 --> 404 Page Not Found: Components/24iTUWK6cjl.php
INFO - 2024-12-11 08:06:26 --> Config Class Initialized
INFO - 2024-12-11 08:06:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:26 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:26 --> URI Class Initialized
INFO - 2024-12-11 08:06:26 --> Router Class Initialized
INFO - 2024-12-11 08:06:27 --> Output Class Initialized
INFO - 2024-12-11 08:06:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:27 --> Input Class Initialized
INFO - 2024-12-11 08:06:27 --> Language Class Initialized
ERROR - 2024-12-11 08:06:27 --> 404 Page Not Found: Wp-admin/vqUADh7RaOB.php
INFO - 2024-12-11 08:06:28 --> Config Class Initialized
INFO - 2024-12-11 08:06:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:28 --> URI Class Initialized
INFO - 2024-12-11 08:06:28 --> Router Class Initialized
INFO - 2024-12-11 08:06:28 --> Output Class Initialized
INFO - 2024-12-11 08:06:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:28 --> Input Class Initialized
INFO - 2024-12-11 08:06:28 --> Language Class Initialized
ERROR - 2024-12-11 08:06:28 --> 404 Page Not Found: BeMaJ2j1mTVphp/index
INFO - 2024-12-11 08:06:28 --> Config Class Initialized
INFO - 2024-12-11 08:06:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:28 --> URI Class Initialized
INFO - 2024-12-11 08:06:28 --> Router Class Initialized
INFO - 2024-12-11 08:06:28 --> Output Class Initialized
INFO - 2024-12-11 08:06:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:28 --> Input Class Initialized
INFO - 2024-12-11 08:06:28 --> Language Class Initialized
ERROR - 2024-12-11 08:06:28 --> 404 Page Not Found: 3PUMx4SWVuvphp/index
INFO - 2024-12-11 08:06:29 --> Config Class Initialized
INFO - 2024-12-11 08:06:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:29 --> URI Class Initialized
INFO - 2024-12-11 08:06:29 --> Router Class Initialized
INFO - 2024-12-11 08:06:29 --> Output Class Initialized
INFO - 2024-12-11 08:06:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:29 --> Input Class Initialized
INFO - 2024-12-11 08:06:29 --> Language Class Initialized
ERROR - 2024-12-11 08:06:29 --> 404 Page Not Found: Wp-admin/jvhFSus6YCN.php
INFO - 2024-12-11 08:06:31 --> Config Class Initialized
INFO - 2024-12-11 08:06:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:31 --> URI Class Initialized
INFO - 2024-12-11 08:06:31 --> Router Class Initialized
INFO - 2024-12-11 08:06:31 --> Output Class Initialized
INFO - 2024-12-11 08:06:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:31 --> Input Class Initialized
INFO - 2024-12-11 08:06:31 --> Language Class Initialized
ERROR - 2024-12-11 08:06:31 --> 404 Page Not Found: Wp-admin/4mL5aYsoxXi.php
INFO - 2024-12-11 08:06:32 --> Config Class Initialized
INFO - 2024-12-11 08:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:32 --> URI Class Initialized
INFO - 2024-12-11 08:06:32 --> Router Class Initialized
INFO - 2024-12-11 08:06:32 --> Output Class Initialized
INFO - 2024-12-11 08:06:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:32 --> Input Class Initialized
INFO - 2024-12-11 08:06:32 --> Language Class Initialized
ERROR - 2024-12-11 08:06:32 --> 404 Page Not Found: Wp-admin/5URHzv8JLkS.php
INFO - 2024-12-11 08:06:33 --> Config Class Initialized
INFO - 2024-12-11 08:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:33 --> URI Class Initialized
INFO - 2024-12-11 08:06:33 --> Router Class Initialized
INFO - 2024-12-11 08:06:33 --> Output Class Initialized
INFO - 2024-12-11 08:06:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:33 --> Input Class Initialized
INFO - 2024-12-11 08:06:33 --> Language Class Initialized
ERROR - 2024-12-11 08:06:33 --> 404 Page Not Found: Wp-admin/rIYu4BGv7MO.php
INFO - 2024-12-11 08:06:35 --> Config Class Initialized
INFO - 2024-12-11 08:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:35 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:35 --> URI Class Initialized
INFO - 2024-12-11 08:06:35 --> Router Class Initialized
INFO - 2024-12-11 08:06:35 --> Output Class Initialized
INFO - 2024-12-11 08:06:35 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:35 --> Input Class Initialized
INFO - 2024-12-11 08:06:35 --> Language Class Initialized
ERROR - 2024-12-11 08:06:35 --> 404 Page Not Found: Wp-admin/4AuOyXK5z6C.php
INFO - 2024-12-11 08:06:36 --> Config Class Initialized
INFO - 2024-12-11 08:06:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:36 --> URI Class Initialized
INFO - 2024-12-11 08:06:36 --> Router Class Initialized
INFO - 2024-12-11 08:06:36 --> Output Class Initialized
INFO - 2024-12-11 08:06:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:36 --> Input Class Initialized
INFO - 2024-12-11 08:06:36 --> Language Class Initialized
ERROR - 2024-12-11 08:06:36 --> 404 Page Not Found: Wp-admin/R9DLBxecwp1.php
INFO - 2024-12-11 08:06:36 --> Config Class Initialized
INFO - 2024-12-11 08:06:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:36 --> URI Class Initialized
INFO - 2024-12-11 08:06:36 --> Router Class Initialized
INFO - 2024-12-11 08:06:36 --> Output Class Initialized
INFO - 2024-12-11 08:06:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:36 --> Input Class Initialized
INFO - 2024-12-11 08:06:36 --> Language Class Initialized
ERROR - 2024-12-11 08:06:36 --> 404 Page Not Found: Wp-admin/eAYOB9KCaZw.php
INFO - 2024-12-11 08:06:37 --> Config Class Initialized
INFO - 2024-12-11 08:06:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:37 --> URI Class Initialized
INFO - 2024-12-11 08:06:37 --> Router Class Initialized
INFO - 2024-12-11 08:06:37 --> Output Class Initialized
INFO - 2024-12-11 08:06:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:37 --> Input Class Initialized
INFO - 2024-12-11 08:06:37 --> Language Class Initialized
ERROR - 2024-12-11 08:06:37 --> 404 Page Not Found: Wp-admin/DmgkrvGU4IK.php
INFO - 2024-12-11 08:06:39 --> Config Class Initialized
INFO - 2024-12-11 08:06:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:39 --> URI Class Initialized
INFO - 2024-12-11 08:06:39 --> Router Class Initialized
INFO - 2024-12-11 08:06:39 --> Output Class Initialized
INFO - 2024-12-11 08:06:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:39 --> Input Class Initialized
INFO - 2024-12-11 08:06:39 --> Language Class Initialized
ERROR - 2024-12-11 08:06:39 --> 404 Page Not Found: 3MNme65K7O4php/index
INFO - 2024-12-11 08:06:40 --> Config Class Initialized
INFO - 2024-12-11 08:06:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:40 --> URI Class Initialized
INFO - 2024-12-11 08:06:40 --> Router Class Initialized
INFO - 2024-12-11 08:06:40 --> Output Class Initialized
INFO - 2024-12-11 08:06:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:40 --> Input Class Initialized
INFO - 2024-12-11 08:06:40 --> Language Class Initialized
ERROR - 2024-12-11 08:06:40 --> 404 Page Not Found: X1S6CHKJubiphp/index
INFO - 2024-12-11 08:06:41 --> Config Class Initialized
INFO - 2024-12-11 08:06:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:41 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:41 --> URI Class Initialized
INFO - 2024-12-11 08:06:41 --> Router Class Initialized
INFO - 2024-12-11 08:06:41 --> Output Class Initialized
INFO - 2024-12-11 08:06:41 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:41 --> Input Class Initialized
INFO - 2024-12-11 08:06:41 --> Language Class Initialized
ERROR - 2024-12-11 08:06:41 --> 404 Page Not Found: GUNMntdko63php/index
INFO - 2024-12-11 08:06:42 --> Config Class Initialized
INFO - 2024-12-11 08:06:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:42 --> URI Class Initialized
INFO - 2024-12-11 08:06:42 --> Router Class Initialized
INFO - 2024-12-11 08:06:42 --> Output Class Initialized
INFO - 2024-12-11 08:06:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:42 --> Input Class Initialized
INFO - 2024-12-11 08:06:42 --> Language Class Initialized
ERROR - 2024-12-11 08:06:42 --> 404 Page Not Found: Wp-admin/JM9coIqm64t.php
INFO - 2024-12-11 08:06:43 --> Config Class Initialized
INFO - 2024-12-11 08:06:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:43 --> URI Class Initialized
INFO - 2024-12-11 08:06:43 --> Router Class Initialized
INFO - 2024-12-11 08:06:43 --> Output Class Initialized
INFO - 2024-12-11 08:06:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:43 --> Input Class Initialized
INFO - 2024-12-11 08:06:43 --> Language Class Initialized
ERROR - 2024-12-11 08:06:43 --> 404 Page Not Found: Wp-admin/Cn6OEKu1oNG.php
INFO - 2024-12-11 08:06:50 --> Config Class Initialized
INFO - 2024-12-11 08:06:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:50 --> URI Class Initialized
INFO - 2024-12-11 08:06:50 --> Router Class Initialized
INFO - 2024-12-11 08:06:50 --> Output Class Initialized
INFO - 2024-12-11 08:06:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:50 --> Input Class Initialized
INFO - 2024-12-11 08:06:50 --> Language Class Initialized
ERROR - 2024-12-11 08:06:50 --> 404 Page Not Found: Wp-admin/6hjdymn5AYk.php
INFO - 2024-12-11 08:06:57 --> Config Class Initialized
INFO - 2024-12-11 08:06:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:57 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:57 --> URI Class Initialized
INFO - 2024-12-11 08:06:57 --> Router Class Initialized
INFO - 2024-12-11 08:06:57 --> Output Class Initialized
INFO - 2024-12-11 08:06:57 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:57 --> Input Class Initialized
INFO - 2024-12-11 08:06:57 --> Language Class Initialized
ERROR - 2024-12-11 08:06:57 --> 404 Page Not Found: Wp-admin/DQNhwiknYGF.php
INFO - 2024-12-11 08:06:58 --> Config Class Initialized
INFO - 2024-12-11 08:06:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:58 --> URI Class Initialized
INFO - 2024-12-11 08:06:58 --> Router Class Initialized
INFO - 2024-12-11 08:06:58 --> Output Class Initialized
INFO - 2024-12-11 08:06:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:58 --> Input Class Initialized
INFO - 2024-12-11 08:06:58 --> Language Class Initialized
ERROR - 2024-12-11 08:06:58 --> 404 Page Not Found: Wp-admin/mN93zcpWnAF.php
INFO - 2024-12-11 08:06:59 --> Config Class Initialized
INFO - 2024-12-11 08:06:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:59 --> URI Class Initialized
INFO - 2024-12-11 08:06:59 --> Router Class Initialized
INFO - 2024-12-11 08:06:59 --> Output Class Initialized
INFO - 2024-12-11 08:06:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:59 --> Input Class Initialized
INFO - 2024-12-11 08:06:59 --> Language Class Initialized
ERROR - 2024-12-11 08:06:59 --> 404 Page Not Found: Wp-admin/eqfOMaQy8Rg.php
INFO - 2024-12-11 08:06:59 --> Config Class Initialized
INFO - 2024-12-11 08:06:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:06:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:06:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:06:59 --> URI Class Initialized
INFO - 2024-12-11 08:06:59 --> Router Class Initialized
INFO - 2024-12-11 08:06:59 --> Output Class Initialized
INFO - 2024-12-11 08:06:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:06:59 --> Input Class Initialized
INFO - 2024-12-11 08:06:59 --> Language Class Initialized
ERROR - 2024-12-11 08:06:59 --> 404 Page Not Found: OwYXNpTMs35php/index
INFO - 2024-12-11 08:07:05 --> Config Class Initialized
INFO - 2024-12-11 08:07:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:05 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:05 --> URI Class Initialized
INFO - 2024-12-11 08:07:05 --> Router Class Initialized
INFO - 2024-12-11 08:07:05 --> Output Class Initialized
INFO - 2024-12-11 08:07:05 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:05 --> Input Class Initialized
INFO - 2024-12-11 08:07:05 --> Language Class Initialized
ERROR - 2024-12-11 08:07:05 --> 404 Page Not Found: Wp-admin/YWKFTUBR63n.php
INFO - 2024-12-11 08:07:08 --> Config Class Initialized
INFO - 2024-12-11 08:07:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:08 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:08 --> URI Class Initialized
INFO - 2024-12-11 08:07:08 --> Router Class Initialized
INFO - 2024-12-11 08:07:08 --> Output Class Initialized
INFO - 2024-12-11 08:07:08 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:08 --> Input Class Initialized
INFO - 2024-12-11 08:07:08 --> Language Class Initialized
ERROR - 2024-12-11 08:07:08 --> 404 Page Not Found: KHNwWi2f6EAphp/index
INFO - 2024-12-11 08:07:09 --> Config Class Initialized
INFO - 2024-12-11 08:07:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:09 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:09 --> URI Class Initialized
INFO - 2024-12-11 08:07:09 --> Router Class Initialized
INFO - 2024-12-11 08:07:09 --> Output Class Initialized
INFO - 2024-12-11 08:07:09 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:09 --> Input Class Initialized
INFO - 2024-12-11 08:07:09 --> Language Class Initialized
ERROR - 2024-12-11 08:07:09 --> 404 Page Not Found: UQCEqmzj8JSphp/index
INFO - 2024-12-11 08:07:11 --> Config Class Initialized
INFO - 2024-12-11 08:07:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:11 --> URI Class Initialized
INFO - 2024-12-11 08:07:11 --> Router Class Initialized
INFO - 2024-12-11 08:07:11 --> Output Class Initialized
INFO - 2024-12-11 08:07:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:11 --> Input Class Initialized
INFO - 2024-12-11 08:07:11 --> Language Class Initialized
ERROR - 2024-12-11 08:07:11 --> 404 Page Not Found: Wp-admin/GfQWOFP53aH.php
INFO - 2024-12-11 08:07:16 --> Config Class Initialized
INFO - 2024-12-11 08:07:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:16 --> URI Class Initialized
INFO - 2024-12-11 08:07:16 --> Router Class Initialized
INFO - 2024-12-11 08:07:16 --> Output Class Initialized
INFO - 2024-12-11 08:07:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:16 --> Input Class Initialized
INFO - 2024-12-11 08:07:16 --> Language Class Initialized
ERROR - 2024-12-11 08:07:16 --> 404 Page Not Found: I28vpVOsatbphp/index
INFO - 2024-12-11 08:07:17 --> Config Class Initialized
INFO - 2024-12-11 08:07:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:17 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:17 --> URI Class Initialized
INFO - 2024-12-11 08:07:17 --> Router Class Initialized
INFO - 2024-12-11 08:07:17 --> Output Class Initialized
INFO - 2024-12-11 08:07:17 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:17 --> Input Class Initialized
INFO - 2024-12-11 08:07:17 --> Language Class Initialized
ERROR - 2024-12-11 08:07:17 --> 404 Page Not Found: 6Shs7ALxBqVphp/index
INFO - 2024-12-11 08:07:20 --> Config Class Initialized
INFO - 2024-12-11 08:07:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:20 --> URI Class Initialized
INFO - 2024-12-11 08:07:20 --> Router Class Initialized
INFO - 2024-12-11 08:07:20 --> Output Class Initialized
INFO - 2024-12-11 08:07:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:20 --> Input Class Initialized
INFO - 2024-12-11 08:07:20 --> Language Class Initialized
ERROR - 2024-12-11 08:07:20 --> 404 Page Not Found: Wp-admin/amkPyvZcKG8.php
INFO - 2024-12-11 08:07:29 --> Config Class Initialized
INFO - 2024-12-11 08:07:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:29 --> URI Class Initialized
INFO - 2024-12-11 08:07:29 --> Router Class Initialized
INFO - 2024-12-11 08:07:29 --> Output Class Initialized
INFO - 2024-12-11 08:07:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:29 --> Input Class Initialized
INFO - 2024-12-11 08:07:29 --> Language Class Initialized
ERROR - 2024-12-11 08:07:29 --> 404 Page Not Found: Kpli9JSafD6php/index
INFO - 2024-12-11 08:07:30 --> Config Class Initialized
INFO - 2024-12-11 08:07:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:30 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:30 --> URI Class Initialized
INFO - 2024-12-11 08:07:30 --> Router Class Initialized
INFO - 2024-12-11 08:07:30 --> Output Class Initialized
INFO - 2024-12-11 08:07:30 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:30 --> Input Class Initialized
INFO - 2024-12-11 08:07:30 --> Language Class Initialized
ERROR - 2024-12-11 08:07:30 --> 404 Page Not Found: V7hzN4IwsHlphp/index
INFO - 2024-12-11 08:07:32 --> Config Class Initialized
INFO - 2024-12-11 08:07:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:32 --> URI Class Initialized
INFO - 2024-12-11 08:07:32 --> Router Class Initialized
INFO - 2024-12-11 08:07:32 --> Output Class Initialized
INFO - 2024-12-11 08:07:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:32 --> Input Class Initialized
INFO - 2024-12-11 08:07:32 --> Language Class Initialized
ERROR - 2024-12-11 08:07:32 --> 404 Page Not Found: Wp-admin/UAf4jBn5i73.php
INFO - 2024-12-11 08:07:36 --> Config Class Initialized
INFO - 2024-12-11 08:07:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:36 --> URI Class Initialized
INFO - 2024-12-11 08:07:36 --> Router Class Initialized
INFO - 2024-12-11 08:07:36 --> Output Class Initialized
INFO - 2024-12-11 08:07:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:36 --> Input Class Initialized
INFO - 2024-12-11 08:07:36 --> Language Class Initialized
ERROR - 2024-12-11 08:07:36 --> 404 Page Not Found: Wp-admin/kCfw7bsOQv2.php
INFO - 2024-12-11 08:07:40 --> Config Class Initialized
INFO - 2024-12-11 08:07:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:40 --> URI Class Initialized
INFO - 2024-12-11 08:07:40 --> Router Class Initialized
INFO - 2024-12-11 08:07:40 --> Output Class Initialized
INFO - 2024-12-11 08:07:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:40 --> Input Class Initialized
INFO - 2024-12-11 08:07:40 --> Language Class Initialized
ERROR - 2024-12-11 08:07:40 --> 404 Page Not Found: Wp-admin/6g2YLrfanMN.php
INFO - 2024-12-11 08:07:42 --> Config Class Initialized
INFO - 2024-12-11 08:07:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:42 --> URI Class Initialized
INFO - 2024-12-11 08:07:42 --> Router Class Initialized
INFO - 2024-12-11 08:07:42 --> Output Class Initialized
INFO - 2024-12-11 08:07:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:42 --> Input Class Initialized
INFO - 2024-12-11 08:07:42 --> Language Class Initialized
ERROR - 2024-12-11 08:07:42 --> 404 Page Not Found: Wp-admin/3RLav89rgCo.php
INFO - 2024-12-11 08:07:42 --> Config Class Initialized
INFO - 2024-12-11 08:07:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:42 --> URI Class Initialized
INFO - 2024-12-11 08:07:42 --> Router Class Initialized
INFO - 2024-12-11 08:07:42 --> Output Class Initialized
INFO - 2024-12-11 08:07:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:42 --> Input Class Initialized
INFO - 2024-12-11 08:07:42 --> Language Class Initialized
ERROR - 2024-12-11 08:07:42 --> 404 Page Not Found: Wp-admin/tnzZFs1UJCI.php
INFO - 2024-12-11 08:07:43 --> Config Class Initialized
INFO - 2024-12-11 08:07:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:43 --> URI Class Initialized
INFO - 2024-12-11 08:07:43 --> Router Class Initialized
INFO - 2024-12-11 08:07:43 --> Output Class Initialized
INFO - 2024-12-11 08:07:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:43 --> Input Class Initialized
INFO - 2024-12-11 08:07:43 --> Language Class Initialized
ERROR - 2024-12-11 08:07:43 --> 404 Page Not Found: ACZG7WrONXuphp/index
INFO - 2024-12-11 08:07:44 --> Config Class Initialized
INFO - 2024-12-11 08:07:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:07:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:07:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:07:44 --> URI Class Initialized
INFO - 2024-12-11 08:07:44 --> Router Class Initialized
INFO - 2024-12-11 08:07:44 --> Output Class Initialized
INFO - 2024-12-11 08:07:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:07:44 --> Input Class Initialized
INFO - 2024-12-11 08:07:44 --> Language Class Initialized
ERROR - 2024-12-11 08:07:44 --> 404 Page Not Found: CZJDzAmiwb5php/index
INFO - 2024-12-11 08:08:00 --> Config Class Initialized
INFO - 2024-12-11 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:00 --> URI Class Initialized
INFO - 2024-12-11 08:08:00 --> Router Class Initialized
INFO - 2024-12-11 08:08:00 --> Output Class Initialized
INFO - 2024-12-11 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:00 --> Input Class Initialized
INFO - 2024-12-11 08:08:00 --> Language Class Initialized
ERROR - 2024-12-11 08:08:00 --> 404 Page Not Found: Wp-admin/E5gwdQqtVrl.php
INFO - 2024-12-11 08:08:04 --> Config Class Initialized
INFO - 2024-12-11 08:08:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:04 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:04 --> URI Class Initialized
INFO - 2024-12-11 08:08:04 --> Router Class Initialized
INFO - 2024-12-11 08:08:04 --> Output Class Initialized
INFO - 2024-12-11 08:08:04 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:04 --> Input Class Initialized
INFO - 2024-12-11 08:08:04 --> Language Class Initialized
ERROR - 2024-12-11 08:08:04 --> 404 Page Not Found: Wp-admin/RCKGnLUlwFW.php
INFO - 2024-12-11 08:08:06 --> Config Class Initialized
INFO - 2024-12-11 08:08:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:06 --> URI Class Initialized
INFO - 2024-12-11 08:08:06 --> Router Class Initialized
INFO - 2024-12-11 08:08:06 --> Output Class Initialized
INFO - 2024-12-11 08:08:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:06 --> Input Class Initialized
INFO - 2024-12-11 08:08:06 --> Language Class Initialized
ERROR - 2024-12-11 08:08:06 --> 404 Page Not Found: Wp-admin/LTOXBIdvFcW.php
INFO - 2024-12-11 08:08:07 --> Config Class Initialized
INFO - 2024-12-11 08:08:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:07 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:07 --> URI Class Initialized
INFO - 2024-12-11 08:08:07 --> Router Class Initialized
INFO - 2024-12-11 08:08:07 --> Output Class Initialized
INFO - 2024-12-11 08:08:07 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:07 --> Input Class Initialized
INFO - 2024-12-11 08:08:07 --> Language Class Initialized
ERROR - 2024-12-11 08:08:07 --> 404 Page Not Found: Wp-admin/uFXL4dV28Eg.php
INFO - 2024-12-11 08:08:10 --> Config Class Initialized
INFO - 2024-12-11 08:08:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:10 --> URI Class Initialized
INFO - 2024-12-11 08:08:10 --> Router Class Initialized
INFO - 2024-12-11 08:08:10 --> Output Class Initialized
INFO - 2024-12-11 08:08:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:10 --> Input Class Initialized
INFO - 2024-12-11 08:08:10 --> Language Class Initialized
ERROR - 2024-12-11 08:08:10 --> 404 Page Not Found: Wp-admin/ziS58MyPkwJ.php
INFO - 2024-12-11 08:08:13 --> Config Class Initialized
INFO - 2024-12-11 08:08:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:13 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:13 --> URI Class Initialized
INFO - 2024-12-11 08:08:13 --> Router Class Initialized
INFO - 2024-12-11 08:08:13 --> Output Class Initialized
INFO - 2024-12-11 08:08:13 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:13 --> Input Class Initialized
INFO - 2024-12-11 08:08:13 --> Language Class Initialized
ERROR - 2024-12-11 08:08:13 --> 404 Page Not Found: 5akMrG39yXhphp/index
INFO - 2024-12-11 08:08:14 --> Config Class Initialized
INFO - 2024-12-11 08:08:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:14 --> URI Class Initialized
INFO - 2024-12-11 08:08:14 --> Router Class Initialized
INFO - 2024-12-11 08:08:14 --> Output Class Initialized
INFO - 2024-12-11 08:08:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:14 --> Input Class Initialized
INFO - 2024-12-11 08:08:14 --> Language Class Initialized
ERROR - 2024-12-11 08:08:14 --> 404 Page Not Found: Wp-admin/DFbY82BZ6xI.php
INFO - 2024-12-11 08:08:18 --> Config Class Initialized
INFO - 2024-12-11 08:08:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:18 --> URI Class Initialized
INFO - 2024-12-11 08:08:18 --> Router Class Initialized
INFO - 2024-12-11 08:08:18 --> Output Class Initialized
INFO - 2024-12-11 08:08:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:18 --> Input Class Initialized
INFO - 2024-12-11 08:08:18 --> Language Class Initialized
ERROR - 2024-12-11 08:08:18 --> 404 Page Not Found: ElGhjnL9Bpxphp/index
INFO - 2024-12-11 08:08:19 --> Config Class Initialized
INFO - 2024-12-11 08:08:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:19 --> URI Class Initialized
INFO - 2024-12-11 08:08:19 --> Router Class Initialized
INFO - 2024-12-11 08:08:19 --> Output Class Initialized
INFO - 2024-12-11 08:08:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:19 --> Input Class Initialized
INFO - 2024-12-11 08:08:19 --> Language Class Initialized
ERROR - 2024-12-11 08:08:19 --> 404 Page Not Found: 3HyUQSpoAMPphp/index
INFO - 2024-12-11 08:08:32 --> Config Class Initialized
INFO - 2024-12-11 08:08:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:32 --> URI Class Initialized
INFO - 2024-12-11 08:08:32 --> Router Class Initialized
INFO - 2024-12-11 08:08:32 --> Output Class Initialized
INFO - 2024-12-11 08:08:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:32 --> Input Class Initialized
INFO - 2024-12-11 08:08:32 --> Language Class Initialized
ERROR - 2024-12-11 08:08:32 --> 404 Page Not Found: Wp-admin/Xn3K5sCOrbe.php
INFO - 2024-12-11 08:08:36 --> Config Class Initialized
INFO - 2024-12-11 08:08:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:36 --> URI Class Initialized
INFO - 2024-12-11 08:08:36 --> Router Class Initialized
INFO - 2024-12-11 08:08:36 --> Output Class Initialized
INFO - 2024-12-11 08:08:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:36 --> Input Class Initialized
INFO - 2024-12-11 08:08:36 --> Language Class Initialized
ERROR - 2024-12-11 08:08:36 --> 404 Page Not Found: Wp-admin/692gMP8ZXdJ.php
INFO - 2024-12-11 08:08:37 --> Config Class Initialized
INFO - 2024-12-11 08:08:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:37 --> URI Class Initialized
INFO - 2024-12-11 08:08:37 --> Router Class Initialized
INFO - 2024-12-11 08:08:37 --> Output Class Initialized
INFO - 2024-12-11 08:08:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:37 --> Input Class Initialized
INFO - 2024-12-11 08:08:37 --> Language Class Initialized
ERROR - 2024-12-11 08:08:37 --> 404 Page Not Found: NKoAnW59aL2php/index
INFO - 2024-12-11 08:08:40 --> Config Class Initialized
INFO - 2024-12-11 08:08:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:40 --> URI Class Initialized
INFO - 2024-12-11 08:08:40 --> Router Class Initialized
INFO - 2024-12-11 08:08:40 --> Output Class Initialized
INFO - 2024-12-11 08:08:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:40 --> Input Class Initialized
INFO - 2024-12-11 08:08:40 --> Language Class Initialized
ERROR - 2024-12-11 08:08:40 --> 404 Page Not Found: Wp-admin/OrUg1MbtNFJ.php
INFO - 2024-12-11 08:08:43 --> Config Class Initialized
INFO - 2024-12-11 08:08:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:43 --> URI Class Initialized
INFO - 2024-12-11 08:08:43 --> Router Class Initialized
INFO - 2024-12-11 08:08:43 --> Output Class Initialized
INFO - 2024-12-11 08:08:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:43 --> Input Class Initialized
INFO - 2024-12-11 08:08:43 --> Language Class Initialized
ERROR - 2024-12-11 08:08:43 --> 404 Page Not Found: Wp-admin/lnq1Yfd2K7c.php
INFO - 2024-12-11 08:08:45 --> Config Class Initialized
INFO - 2024-12-11 08:08:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:45 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:45 --> URI Class Initialized
INFO - 2024-12-11 08:08:45 --> Router Class Initialized
INFO - 2024-12-11 08:08:45 --> Output Class Initialized
INFO - 2024-12-11 08:08:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:45 --> Input Class Initialized
INFO - 2024-12-11 08:08:45 --> Language Class Initialized
ERROR - 2024-12-11 08:08:45 --> 404 Page Not Found: Wp-admin/ztZiL32lUN9.php
INFO - 2024-12-11 08:08:46 --> Config Class Initialized
INFO - 2024-12-11 08:08:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:46 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:46 --> URI Class Initialized
INFO - 2024-12-11 08:08:46 --> Router Class Initialized
INFO - 2024-12-11 08:08:46 --> Output Class Initialized
INFO - 2024-12-11 08:08:46 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:46 --> Input Class Initialized
INFO - 2024-12-11 08:08:46 --> Language Class Initialized
ERROR - 2024-12-11 08:08:46 --> 404 Page Not Found: Wp-admin/ERm13uWKQkf.php
INFO - 2024-12-11 08:08:48 --> Config Class Initialized
INFO - 2024-12-11 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:48 --> URI Class Initialized
INFO - 2024-12-11 08:08:48 --> Router Class Initialized
INFO - 2024-12-11 08:08:48 --> Output Class Initialized
INFO - 2024-12-11 08:08:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:48 --> Input Class Initialized
INFO - 2024-12-11 08:08:48 --> Language Class Initialized
ERROR - 2024-12-11 08:08:48 --> 404 Page Not Found: Wp-admin/pSwNlF4D3OK.php
INFO - 2024-12-11 08:08:48 --> Config Class Initialized
INFO - 2024-12-11 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:48 --> URI Class Initialized
INFO - 2024-12-11 08:08:48 --> Router Class Initialized
INFO - 2024-12-11 08:08:48 --> Output Class Initialized
INFO - 2024-12-11 08:08:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:48 --> Input Class Initialized
INFO - 2024-12-11 08:08:48 --> Language Class Initialized
ERROR - 2024-12-11 08:08:48 --> 404 Page Not Found: WIdU3XS1pnKphp/index
INFO - 2024-12-11 08:08:55 --> Config Class Initialized
INFO - 2024-12-11 08:08:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:55 --> URI Class Initialized
INFO - 2024-12-11 08:08:55 --> Router Class Initialized
INFO - 2024-12-11 08:08:55 --> Output Class Initialized
INFO - 2024-12-11 08:08:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:55 --> Input Class Initialized
INFO - 2024-12-11 08:08:55 --> Language Class Initialized
ERROR - 2024-12-11 08:08:55 --> 404 Page Not Found: BVkcURsKmXYphp/index
INFO - 2024-12-11 08:08:57 --> Config Class Initialized
INFO - 2024-12-11 08:08:57 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:57 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:57 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:57 --> URI Class Initialized
INFO - 2024-12-11 08:08:57 --> Router Class Initialized
INFO - 2024-12-11 08:08:57 --> Output Class Initialized
INFO - 2024-12-11 08:08:57 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:57 --> Input Class Initialized
INFO - 2024-12-11 08:08:57 --> Language Class Initialized
ERROR - 2024-12-11 08:08:57 --> 404 Page Not Found: Wp-admin/VGi9Ulu3cNK.php
INFO - 2024-12-11 08:08:58 --> Config Class Initialized
INFO - 2024-12-11 08:08:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:08:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:08:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:08:58 --> URI Class Initialized
INFO - 2024-12-11 08:08:58 --> Router Class Initialized
INFO - 2024-12-11 08:08:58 --> Output Class Initialized
INFO - 2024-12-11 08:08:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:08:58 --> Input Class Initialized
INFO - 2024-12-11 08:08:58 --> Language Class Initialized
ERROR - 2024-12-11 08:08:58 --> 404 Page Not Found: BvNqadf139Qphp/index
INFO - 2024-12-11 08:09:03 --> Config Class Initialized
INFO - 2024-12-11 08:09:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:03 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:03 --> URI Class Initialized
INFO - 2024-12-11 08:09:03 --> Router Class Initialized
INFO - 2024-12-11 08:09:03 --> Output Class Initialized
INFO - 2024-12-11 08:09:03 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:03 --> Input Class Initialized
INFO - 2024-12-11 08:09:03 --> Language Class Initialized
ERROR - 2024-12-11 08:09:03 --> 404 Page Not Found: Wp-admin/gSvRCDBTNyz.php
INFO - 2024-12-11 08:09:06 --> Config Class Initialized
INFO - 2024-12-11 08:09:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:06 --> URI Class Initialized
INFO - 2024-12-11 08:09:06 --> Router Class Initialized
INFO - 2024-12-11 08:09:06 --> Output Class Initialized
INFO - 2024-12-11 08:09:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:06 --> Input Class Initialized
INFO - 2024-12-11 08:09:06 --> Language Class Initialized
ERROR - 2024-12-11 08:09:06 --> 404 Page Not Found: Wp-admin/JCmEkIBKQ4o.php
INFO - 2024-12-11 08:09:09 --> Config Class Initialized
INFO - 2024-12-11 08:09:09 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:09 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:09 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:09 --> URI Class Initialized
INFO - 2024-12-11 08:09:09 --> Router Class Initialized
INFO - 2024-12-11 08:09:09 --> Output Class Initialized
INFO - 2024-12-11 08:09:09 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:09 --> Input Class Initialized
INFO - 2024-12-11 08:09:09 --> Language Class Initialized
ERROR - 2024-12-11 08:09:09 --> 404 Page Not Found: Wp-admin/q4ote6ixcvr.php
INFO - 2024-12-11 08:09:11 --> Config Class Initialized
INFO - 2024-12-11 08:09:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:11 --> URI Class Initialized
INFO - 2024-12-11 08:09:11 --> Router Class Initialized
INFO - 2024-12-11 08:09:11 --> Output Class Initialized
INFO - 2024-12-11 08:09:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:11 --> Input Class Initialized
INFO - 2024-12-11 08:09:11 --> Language Class Initialized
ERROR - 2024-12-11 08:09:11 --> 404 Page Not Found: Wp-admin/JIeXVFin91G.php
INFO - 2024-12-11 08:09:15 --> Config Class Initialized
INFO - 2024-12-11 08:09:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:15 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:15 --> URI Class Initialized
INFO - 2024-12-11 08:09:15 --> Router Class Initialized
INFO - 2024-12-11 08:09:15 --> Output Class Initialized
INFO - 2024-12-11 08:09:15 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:15 --> Input Class Initialized
INFO - 2024-12-11 08:09:15 --> Language Class Initialized
ERROR - 2024-12-11 08:09:15 --> 404 Page Not Found: Wp-admin/DzVCZOPHKGS.php
INFO - 2024-12-11 08:09:16 --> Config Class Initialized
INFO - 2024-12-11 08:09:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:16 --> URI Class Initialized
INFO - 2024-12-11 08:09:16 --> Router Class Initialized
INFO - 2024-12-11 08:09:16 --> Output Class Initialized
INFO - 2024-12-11 08:09:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:16 --> Input Class Initialized
INFO - 2024-12-11 08:09:16 --> Language Class Initialized
ERROR - 2024-12-11 08:09:16 --> 404 Page Not Found: T4w9xQnHMcjphp/index
INFO - 2024-12-11 08:09:17 --> Config Class Initialized
INFO - 2024-12-11 08:09:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:17 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:17 --> URI Class Initialized
INFO - 2024-12-11 08:09:17 --> Router Class Initialized
INFO - 2024-12-11 08:09:17 --> Output Class Initialized
INFO - 2024-12-11 08:09:17 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:17 --> Input Class Initialized
INFO - 2024-12-11 08:09:17 --> Language Class Initialized
ERROR - 2024-12-11 08:09:17 --> 404 Page Not Found: Wp-admin/uOFoeprh9SV.php
INFO - 2024-12-11 08:09:17 --> Config Class Initialized
INFO - 2024-12-11 08:09:17 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:17 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:17 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:17 --> URI Class Initialized
INFO - 2024-12-11 08:09:17 --> Router Class Initialized
INFO - 2024-12-11 08:09:17 --> Output Class Initialized
INFO - 2024-12-11 08:09:17 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:17 --> Input Class Initialized
INFO - 2024-12-11 08:09:17 --> Language Class Initialized
ERROR - 2024-12-11 08:09:17 --> 404 Page Not Found: IOoCabgSkB7php/index
INFO - 2024-12-11 08:09:19 --> Config Class Initialized
INFO - 2024-12-11 08:09:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:19 --> URI Class Initialized
INFO - 2024-12-11 08:09:19 --> Router Class Initialized
INFO - 2024-12-11 08:09:19 --> Output Class Initialized
INFO - 2024-12-11 08:09:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:19 --> Input Class Initialized
INFO - 2024-12-11 08:09:19 --> Language Class Initialized
ERROR - 2024-12-11 08:09:19 --> 404 Page Not Found: IypD2VA5PFTphp/index
INFO - 2024-12-11 08:09:23 --> Config Class Initialized
INFO - 2024-12-11 08:09:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:23 --> URI Class Initialized
INFO - 2024-12-11 08:09:23 --> Router Class Initialized
INFO - 2024-12-11 08:09:23 --> Output Class Initialized
INFO - 2024-12-11 08:09:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:23 --> Input Class Initialized
INFO - 2024-12-11 08:09:23 --> Language Class Initialized
ERROR - 2024-12-11 08:09:23 --> 404 Page Not Found: Wp-admin/4qocEAlL76R.php
INFO - 2024-12-11 08:09:24 --> Config Class Initialized
INFO - 2024-12-11 08:09:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:24 --> URI Class Initialized
INFO - 2024-12-11 08:09:24 --> Router Class Initialized
INFO - 2024-12-11 08:09:24 --> Output Class Initialized
INFO - 2024-12-11 08:09:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:24 --> Input Class Initialized
INFO - 2024-12-11 08:09:24 --> Language Class Initialized
ERROR - 2024-12-11 08:09:24 --> 404 Page Not Found: Wp-admin/OFKV9RNJELv.php
INFO - 2024-12-11 08:09:25 --> Config Class Initialized
INFO - 2024-12-11 08:09:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:25 --> URI Class Initialized
INFO - 2024-12-11 08:09:25 --> Router Class Initialized
INFO - 2024-12-11 08:09:25 --> Output Class Initialized
INFO - 2024-12-11 08:09:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:25 --> Input Class Initialized
INFO - 2024-12-11 08:09:25 --> Language Class Initialized
ERROR - 2024-12-11 08:09:25 --> 404 Page Not Found: Wp-admin/RrHkVuZ56ai.php
INFO - 2024-12-11 08:09:28 --> Config Class Initialized
INFO - 2024-12-11 08:09:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:28 --> URI Class Initialized
INFO - 2024-12-11 08:09:28 --> Router Class Initialized
INFO - 2024-12-11 08:09:28 --> Output Class Initialized
INFO - 2024-12-11 08:09:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:28 --> Input Class Initialized
INFO - 2024-12-11 08:09:28 --> Language Class Initialized
ERROR - 2024-12-11 08:09:28 --> 404 Page Not Found: FYKsamfL8XOphp/index
INFO - 2024-12-11 08:09:28 --> Config Class Initialized
INFO - 2024-12-11 08:09:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:28 --> URI Class Initialized
INFO - 2024-12-11 08:09:28 --> Router Class Initialized
INFO - 2024-12-11 08:09:28 --> Output Class Initialized
INFO - 2024-12-11 08:09:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:28 --> Input Class Initialized
INFO - 2024-12-11 08:09:28 --> Language Class Initialized
ERROR - 2024-12-11 08:09:28 --> 404 Page Not Found: Wp-admin/dT8Boz6efAO.php
INFO - 2024-12-11 08:09:31 --> Config Class Initialized
INFO - 2024-12-11 08:09:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:31 --> URI Class Initialized
INFO - 2024-12-11 08:09:31 --> Router Class Initialized
INFO - 2024-12-11 08:09:31 --> Output Class Initialized
INFO - 2024-12-11 08:09:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:31 --> Input Class Initialized
INFO - 2024-12-11 08:09:31 --> Language Class Initialized
ERROR - 2024-12-11 08:09:31 --> 404 Page Not Found: 8DPKmUxBbXaphp/index
INFO - 2024-12-11 08:09:31 --> Config Class Initialized
INFO - 2024-12-11 08:09:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:31 --> URI Class Initialized
INFO - 2024-12-11 08:09:31 --> Router Class Initialized
INFO - 2024-12-11 08:09:31 --> Output Class Initialized
INFO - 2024-12-11 08:09:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:31 --> Input Class Initialized
INFO - 2024-12-11 08:09:31 --> Language Class Initialized
ERROR - 2024-12-11 08:09:31 --> 404 Page Not Found: Wp-admin/uzTYoVtHveP.php
INFO - 2024-12-11 08:09:36 --> Config Class Initialized
INFO - 2024-12-11 08:09:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:36 --> URI Class Initialized
INFO - 2024-12-11 08:09:36 --> Router Class Initialized
INFO - 2024-12-11 08:09:36 --> Output Class Initialized
INFO - 2024-12-11 08:09:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:36 --> Input Class Initialized
INFO - 2024-12-11 08:09:36 --> Language Class Initialized
ERROR - 2024-12-11 08:09:36 --> 404 Page Not Found: 1Ci2tP4y3MHphp/index
INFO - 2024-12-11 08:09:38 --> Config Class Initialized
INFO - 2024-12-11 08:09:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:38 --> URI Class Initialized
INFO - 2024-12-11 08:09:38 --> Router Class Initialized
INFO - 2024-12-11 08:09:38 --> Output Class Initialized
INFO - 2024-12-11 08:09:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:38 --> Input Class Initialized
INFO - 2024-12-11 08:09:38 --> Language Class Initialized
ERROR - 2024-12-11 08:09:38 --> 404 Page Not Found: Wp-admin/WxsCw1NvmiJ.php
INFO - 2024-12-11 08:09:39 --> Config Class Initialized
INFO - 2024-12-11 08:09:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:39 --> URI Class Initialized
INFO - 2024-12-11 08:09:39 --> Router Class Initialized
INFO - 2024-12-11 08:09:39 --> Output Class Initialized
INFO - 2024-12-11 08:09:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:39 --> Input Class Initialized
INFO - 2024-12-11 08:09:39 --> Language Class Initialized
ERROR - 2024-12-11 08:09:39 --> 404 Page Not Found: Wp-admin/nYXROxcgFUD.php
INFO - 2024-12-11 08:09:40 --> Config Class Initialized
INFO - 2024-12-11 08:09:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:40 --> URI Class Initialized
INFO - 2024-12-11 08:09:40 --> Router Class Initialized
INFO - 2024-12-11 08:09:40 --> Output Class Initialized
INFO - 2024-12-11 08:09:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:40 --> Input Class Initialized
INFO - 2024-12-11 08:09:40 --> Language Class Initialized
ERROR - 2024-12-11 08:09:40 --> 404 Page Not Found: Wp-admin/dVm38qhH2Mb.php
INFO - 2024-12-11 08:09:50 --> Config Class Initialized
INFO - 2024-12-11 08:09:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:50 --> URI Class Initialized
INFO - 2024-12-11 08:09:50 --> Router Class Initialized
INFO - 2024-12-11 08:09:50 --> Output Class Initialized
INFO - 2024-12-11 08:09:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:50 --> Input Class Initialized
INFO - 2024-12-11 08:09:50 --> Language Class Initialized
ERROR - 2024-12-11 08:09:50 --> 404 Page Not Found: Wp-admin/IGNetZ5EWj9.php
INFO - 2024-12-11 08:09:54 --> Config Class Initialized
INFO - 2024-12-11 08:09:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:54 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:54 --> URI Class Initialized
INFO - 2024-12-11 08:09:54 --> Router Class Initialized
INFO - 2024-12-11 08:09:54 --> Output Class Initialized
INFO - 2024-12-11 08:09:54 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:54 --> Input Class Initialized
INFO - 2024-12-11 08:09:54 --> Language Class Initialized
ERROR - 2024-12-11 08:09:54 --> 404 Page Not Found: Wp-admin/hpiAr5Ug6XB.php
INFO - 2024-12-11 08:09:55 --> Config Class Initialized
INFO - 2024-12-11 08:09:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:55 --> URI Class Initialized
INFO - 2024-12-11 08:09:55 --> Router Class Initialized
INFO - 2024-12-11 08:09:55 --> Output Class Initialized
INFO - 2024-12-11 08:09:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:55 --> Input Class Initialized
INFO - 2024-12-11 08:09:55 --> Language Class Initialized
ERROR - 2024-12-11 08:09:55 --> 404 Page Not Found: Wp-admin/sOEHKdTFuo6.php
INFO - 2024-12-11 08:09:56 --> Config Class Initialized
INFO - 2024-12-11 08:09:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:09:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:09:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:09:56 --> URI Class Initialized
INFO - 2024-12-11 08:09:56 --> Router Class Initialized
INFO - 2024-12-11 08:09:56 --> Output Class Initialized
INFO - 2024-12-11 08:09:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:09:56 --> Input Class Initialized
INFO - 2024-12-11 08:09:56 --> Language Class Initialized
ERROR - 2024-12-11 08:09:56 --> 404 Page Not Found: Wp-admin/fZvyeKNkrFJ.php
INFO - 2024-12-11 08:10:00 --> Config Class Initialized
INFO - 2024-12-11 08:10:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:00 --> URI Class Initialized
INFO - 2024-12-11 08:10:00 --> Router Class Initialized
INFO - 2024-12-11 08:10:00 --> Output Class Initialized
INFO - 2024-12-11 08:10:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:00 --> Input Class Initialized
INFO - 2024-12-11 08:10:00 --> Language Class Initialized
ERROR - 2024-12-11 08:10:00 --> 404 Page Not Found: Vmlp4CEoR6rphp/index
INFO - 2024-12-11 08:10:02 --> Config Class Initialized
INFO - 2024-12-11 08:10:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:02 --> URI Class Initialized
INFO - 2024-12-11 08:10:02 --> Router Class Initialized
INFO - 2024-12-11 08:10:02 --> Output Class Initialized
INFO - 2024-12-11 08:10:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:02 --> Input Class Initialized
INFO - 2024-12-11 08:10:02 --> Language Class Initialized
ERROR - 2024-12-11 08:10:02 --> 404 Page Not Found: Wp-admin/QVSeY6ZG9bt.php
INFO - 2024-12-11 08:10:08 --> Config Class Initialized
INFO - 2024-12-11 08:10:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:08 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:08 --> URI Class Initialized
INFO - 2024-12-11 08:10:08 --> Router Class Initialized
INFO - 2024-12-11 08:10:08 --> Output Class Initialized
INFO - 2024-12-11 08:10:08 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:08 --> Input Class Initialized
INFO - 2024-12-11 08:10:08 --> Language Class Initialized
ERROR - 2024-12-11 08:10:08 --> 404 Page Not Found: RYxmkv2e3b8php/index
INFO - 2024-12-11 08:10:11 --> Config Class Initialized
INFO - 2024-12-11 08:10:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:11 --> URI Class Initialized
INFO - 2024-12-11 08:10:11 --> Router Class Initialized
INFO - 2024-12-11 08:10:11 --> Output Class Initialized
INFO - 2024-12-11 08:10:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:11 --> Input Class Initialized
INFO - 2024-12-11 08:10:11 --> Language Class Initialized
ERROR - 2024-12-11 08:10:11 --> 404 Page Not Found: Wp-admin/vabPw1mI86A.php
INFO - 2024-12-11 08:10:20 --> Config Class Initialized
INFO - 2024-12-11 08:10:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:20 --> URI Class Initialized
INFO - 2024-12-11 08:10:20 --> Router Class Initialized
INFO - 2024-12-11 08:10:20 --> Output Class Initialized
INFO - 2024-12-11 08:10:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:20 --> Input Class Initialized
INFO - 2024-12-11 08:10:20 --> Language Class Initialized
ERROR - 2024-12-11 08:10:20 --> 404 Page Not Found: 7q5GYsF6gEtphp/index
INFO - 2024-12-11 08:10:23 --> Config Class Initialized
INFO - 2024-12-11 08:10:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:23 --> URI Class Initialized
INFO - 2024-12-11 08:10:23 --> Router Class Initialized
INFO - 2024-12-11 08:10:23 --> Output Class Initialized
INFO - 2024-12-11 08:10:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:23 --> Input Class Initialized
INFO - 2024-12-11 08:10:23 --> Language Class Initialized
ERROR - 2024-12-11 08:10:23 --> 404 Page Not Found: Wp-admin/cFxeh8oaNWd.php
INFO - 2024-12-11 08:10:25 --> Config Class Initialized
INFO - 2024-12-11 08:10:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:25 --> URI Class Initialized
INFO - 2024-12-11 08:10:25 --> Router Class Initialized
INFO - 2024-12-11 08:10:25 --> Output Class Initialized
INFO - 2024-12-11 08:10:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:25 --> Input Class Initialized
INFO - 2024-12-11 08:10:25 --> Language Class Initialized
ERROR - 2024-12-11 08:10:25 --> 404 Page Not Found: Wp-admin/mV9YDZFSlh8.php
INFO - 2024-12-11 08:10:26 --> Config Class Initialized
INFO - 2024-12-11 08:10:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:26 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:26 --> URI Class Initialized
INFO - 2024-12-11 08:10:26 --> Router Class Initialized
INFO - 2024-12-11 08:10:26 --> Output Class Initialized
INFO - 2024-12-11 08:10:26 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:26 --> Input Class Initialized
INFO - 2024-12-11 08:10:26 --> Language Class Initialized
ERROR - 2024-12-11 08:10:26 --> 404 Page Not Found: Wp-admin/PEs9A1MB3bw.php
INFO - 2024-12-11 08:10:27 --> Config Class Initialized
INFO - 2024-12-11 08:10:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:27 --> URI Class Initialized
INFO - 2024-12-11 08:10:27 --> Router Class Initialized
INFO - 2024-12-11 08:10:27 --> Output Class Initialized
INFO - 2024-12-11 08:10:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:27 --> Input Class Initialized
INFO - 2024-12-11 08:10:27 --> Language Class Initialized
ERROR - 2024-12-11 08:10:27 --> 404 Page Not Found: Wp-admin/AvdoKjsNP9I.php
INFO - 2024-12-11 08:10:29 --> Config Class Initialized
INFO - 2024-12-11 08:10:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:29 --> URI Class Initialized
INFO - 2024-12-11 08:10:29 --> Router Class Initialized
INFO - 2024-12-11 08:10:29 --> Output Class Initialized
INFO - 2024-12-11 08:10:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:29 --> Input Class Initialized
INFO - 2024-12-11 08:10:29 --> Language Class Initialized
ERROR - 2024-12-11 08:10:29 --> 404 Page Not Found: Wp-admin/MTmZKpGOqXU.php
INFO - 2024-12-11 08:10:32 --> Config Class Initialized
INFO - 2024-12-11 08:10:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:32 --> URI Class Initialized
INFO - 2024-12-11 08:10:32 --> Router Class Initialized
INFO - 2024-12-11 08:10:32 --> Output Class Initialized
INFO - 2024-12-11 08:10:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:32 --> Input Class Initialized
INFO - 2024-12-11 08:10:32 --> Language Class Initialized
ERROR - 2024-12-11 08:10:32 --> 404 Page Not Found: YzYhgTvwU4Ophp/index
INFO - 2024-12-11 08:10:32 --> Config Class Initialized
INFO - 2024-12-11 08:10:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:32 --> URI Class Initialized
INFO - 2024-12-11 08:10:32 --> Router Class Initialized
INFO - 2024-12-11 08:10:32 --> Output Class Initialized
INFO - 2024-12-11 08:10:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:32 --> Input Class Initialized
INFO - 2024-12-11 08:10:32 --> Language Class Initialized
ERROR - 2024-12-11 08:10:32 --> 404 Page Not Found: Wp-admin/ES9nLvNezGC.php
INFO - 2024-12-11 08:10:34 --> Config Class Initialized
INFO - 2024-12-11 08:10:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:34 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:34 --> URI Class Initialized
INFO - 2024-12-11 08:10:34 --> Router Class Initialized
INFO - 2024-12-11 08:10:34 --> Output Class Initialized
INFO - 2024-12-11 08:10:34 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:34 --> Input Class Initialized
INFO - 2024-12-11 08:10:34 --> Language Class Initialized
ERROR - 2024-12-11 08:10:34 --> 404 Page Not Found: Wp-admin/NA7q59wVSCc.php
INFO - 2024-12-11 08:10:37 --> Config Class Initialized
INFO - 2024-12-11 08:10:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:37 --> URI Class Initialized
INFO - 2024-12-11 08:10:37 --> Router Class Initialized
INFO - 2024-12-11 08:10:37 --> Output Class Initialized
INFO - 2024-12-11 08:10:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:37 --> Input Class Initialized
INFO - 2024-12-11 08:10:37 --> Language Class Initialized
ERROR - 2024-12-11 08:10:37 --> 404 Page Not Found: Wp-admin/7tQpBDdau6b.php
INFO - 2024-12-11 08:10:38 --> Config Class Initialized
INFO - 2024-12-11 08:10:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:38 --> URI Class Initialized
INFO - 2024-12-11 08:10:38 --> Router Class Initialized
INFO - 2024-12-11 08:10:38 --> Output Class Initialized
INFO - 2024-12-11 08:10:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:38 --> Input Class Initialized
INFO - 2024-12-11 08:10:38 --> Language Class Initialized
ERROR - 2024-12-11 08:10:38 --> 404 Page Not Found: Wp-admin/zlXb8oFtBpx.php
INFO - 2024-12-11 08:10:54 --> Config Class Initialized
INFO - 2024-12-11 08:10:54 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:54 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:54 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:54 --> URI Class Initialized
INFO - 2024-12-11 08:10:54 --> Router Class Initialized
INFO - 2024-12-11 08:10:54 --> Output Class Initialized
INFO - 2024-12-11 08:10:54 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:54 --> Input Class Initialized
INFO - 2024-12-11 08:10:54 --> Language Class Initialized
ERROR - 2024-12-11 08:10:54 --> 404 Page Not Found: GUe6CYjyAITphp/index
INFO - 2024-12-11 08:10:55 --> Config Class Initialized
INFO - 2024-12-11 08:10:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:55 --> URI Class Initialized
INFO - 2024-12-11 08:10:55 --> Router Class Initialized
INFO - 2024-12-11 08:10:55 --> Output Class Initialized
INFO - 2024-12-11 08:10:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:55 --> Input Class Initialized
INFO - 2024-12-11 08:10:55 --> Language Class Initialized
ERROR - 2024-12-11 08:10:55 --> 404 Page Not Found: 6SVPUuNQKXyphp/index
INFO - 2024-12-11 08:10:56 --> Config Class Initialized
INFO - 2024-12-11 08:10:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:10:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:10:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:10:56 --> URI Class Initialized
INFO - 2024-12-11 08:10:56 --> Router Class Initialized
INFO - 2024-12-11 08:10:56 --> Output Class Initialized
INFO - 2024-12-11 08:10:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:10:56 --> Input Class Initialized
INFO - 2024-12-11 08:10:56 --> Language Class Initialized
ERROR - 2024-12-11 08:10:56 --> 404 Page Not Found: Wly8veJbTLFphp/index
INFO - 2024-12-11 08:11:06 --> Config Class Initialized
INFO - 2024-12-11 08:11:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:06 --> URI Class Initialized
INFO - 2024-12-11 08:11:06 --> Router Class Initialized
INFO - 2024-12-11 08:11:06 --> Output Class Initialized
INFO - 2024-12-11 08:11:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:06 --> Input Class Initialized
INFO - 2024-12-11 08:11:06 --> Language Class Initialized
ERROR - 2024-12-11 08:11:06 --> 404 Page Not Found: Wp-admin/WXKq5DNZgVe.php
INFO - 2024-12-11 08:11:07 --> Config Class Initialized
INFO - 2024-12-11 08:11:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:07 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:07 --> URI Class Initialized
INFO - 2024-12-11 08:11:07 --> Router Class Initialized
INFO - 2024-12-11 08:11:07 --> Output Class Initialized
INFO - 2024-12-11 08:11:07 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:07 --> Input Class Initialized
INFO - 2024-12-11 08:11:07 --> Language Class Initialized
ERROR - 2024-12-11 08:11:07 --> 404 Page Not Found: Wp-admin/1lK6cQxuRFG.php
INFO - 2024-12-11 08:11:07 --> Config Class Initialized
INFO - 2024-12-11 08:11:07 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:07 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:07 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:07 --> URI Class Initialized
INFO - 2024-12-11 08:11:07 --> Router Class Initialized
INFO - 2024-12-11 08:11:07 --> Output Class Initialized
INFO - 2024-12-11 08:11:07 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:07 --> Input Class Initialized
INFO - 2024-12-11 08:11:07 --> Language Class Initialized
ERROR - 2024-12-11 08:11:07 --> 404 Page Not Found: Wp-admin/VWPal3Iz7ZA.php
INFO - 2024-12-11 08:11:10 --> Config Class Initialized
INFO - 2024-12-11 08:11:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:10 --> URI Class Initialized
INFO - 2024-12-11 08:11:10 --> Router Class Initialized
INFO - 2024-12-11 08:11:10 --> Output Class Initialized
INFO - 2024-12-11 08:11:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:10 --> Input Class Initialized
INFO - 2024-12-11 08:11:10 --> Language Class Initialized
ERROR - 2024-12-11 08:11:10 --> 404 Page Not Found: RekhG6LpsZ3php/index
INFO - 2024-12-11 08:11:12 --> Config Class Initialized
INFO - 2024-12-11 08:11:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:12 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:12 --> URI Class Initialized
INFO - 2024-12-11 08:11:12 --> Router Class Initialized
INFO - 2024-12-11 08:11:12 --> Output Class Initialized
INFO - 2024-12-11 08:11:12 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:12 --> Input Class Initialized
INFO - 2024-12-11 08:11:12 --> Language Class Initialized
ERROR - 2024-12-11 08:11:12 --> 404 Page Not Found: Wp-admin/ijrlJwthAMX.php
INFO - 2024-12-11 08:11:13 --> Config Class Initialized
INFO - 2024-12-11 08:11:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:13 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:13 --> URI Class Initialized
INFO - 2024-12-11 08:11:13 --> Router Class Initialized
INFO - 2024-12-11 08:11:13 --> Output Class Initialized
INFO - 2024-12-11 08:11:13 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:13 --> Input Class Initialized
INFO - 2024-12-11 08:11:13 --> Language Class Initialized
ERROR - 2024-12-11 08:11:13 --> 404 Page Not Found: Wp-admin/8kyif4m3NLJ.php
INFO - 2024-12-11 08:11:14 --> Config Class Initialized
INFO - 2024-12-11 08:11:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:14 --> URI Class Initialized
INFO - 2024-12-11 08:11:14 --> Router Class Initialized
INFO - 2024-12-11 08:11:14 --> Output Class Initialized
INFO - 2024-12-11 08:11:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:14 --> Input Class Initialized
INFO - 2024-12-11 08:11:14 --> Language Class Initialized
ERROR - 2024-12-11 08:11:14 --> 404 Page Not Found: EUYisnztjLmphp/index
INFO - 2024-12-11 08:11:19 --> Config Class Initialized
INFO - 2024-12-11 08:11:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:19 --> URI Class Initialized
INFO - 2024-12-11 08:11:19 --> Router Class Initialized
INFO - 2024-12-11 08:11:19 --> Output Class Initialized
INFO - 2024-12-11 08:11:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:19 --> Input Class Initialized
INFO - 2024-12-11 08:11:19 --> Language Class Initialized
ERROR - 2024-12-11 08:11:19 --> 404 Page Not Found: Wp-admin/5SkuMyp2qCI.php
INFO - 2024-12-11 08:11:20 --> Config Class Initialized
INFO - 2024-12-11 08:11:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:20 --> URI Class Initialized
INFO - 2024-12-11 08:11:20 --> Router Class Initialized
INFO - 2024-12-11 08:11:20 --> Output Class Initialized
INFO - 2024-12-11 08:11:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:20 --> Input Class Initialized
INFO - 2024-12-11 08:11:20 --> Language Class Initialized
ERROR - 2024-12-11 08:11:20 --> 404 Page Not Found: Wp-admin/h8fiwMJRIoV.php
INFO - 2024-12-11 08:11:21 --> Config Class Initialized
INFO - 2024-12-11 08:11:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:21 --> URI Class Initialized
INFO - 2024-12-11 08:11:21 --> Router Class Initialized
INFO - 2024-12-11 08:11:21 --> Output Class Initialized
INFO - 2024-12-11 08:11:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:21 --> Input Class Initialized
INFO - 2024-12-11 08:11:21 --> Language Class Initialized
ERROR - 2024-12-11 08:11:21 --> 404 Page Not Found: Wp-admin/JSlc3d7smjg.php
INFO - 2024-12-11 08:11:24 --> Config Class Initialized
INFO - 2024-12-11 08:11:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:24 --> URI Class Initialized
INFO - 2024-12-11 08:11:24 --> Router Class Initialized
INFO - 2024-12-11 08:11:24 --> Output Class Initialized
INFO - 2024-12-11 08:11:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:24 --> Input Class Initialized
INFO - 2024-12-11 08:11:24 --> Language Class Initialized
ERROR - 2024-12-11 08:11:24 --> 404 Page Not Found: Wp-admin/wIBOC96nJLV.php
INFO - 2024-12-11 08:11:25 --> Config Class Initialized
INFO - 2024-12-11 08:11:25 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:25 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:25 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:25 --> URI Class Initialized
INFO - 2024-12-11 08:11:25 --> Router Class Initialized
INFO - 2024-12-11 08:11:25 --> Output Class Initialized
INFO - 2024-12-11 08:11:25 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:25 --> Input Class Initialized
INFO - 2024-12-11 08:11:25 --> Language Class Initialized
ERROR - 2024-12-11 08:11:25 --> 404 Page Not Found: Wp-admin/8laIR5T14Hx.php
INFO - 2024-12-11 08:11:27 --> Config Class Initialized
INFO - 2024-12-11 08:11:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:27 --> URI Class Initialized
INFO - 2024-12-11 08:11:27 --> Router Class Initialized
INFO - 2024-12-11 08:11:27 --> Output Class Initialized
INFO - 2024-12-11 08:11:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:27 --> Input Class Initialized
INFO - 2024-12-11 08:11:27 --> Language Class Initialized
ERROR - 2024-12-11 08:11:27 --> 404 Page Not Found: Wp-admin/Y2pVCoqJENI.php
INFO - 2024-12-11 08:11:27 --> Config Class Initialized
INFO - 2024-12-11 08:11:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:27 --> URI Class Initialized
INFO - 2024-12-11 08:11:27 --> Router Class Initialized
INFO - 2024-12-11 08:11:27 --> Output Class Initialized
INFO - 2024-12-11 08:11:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:27 --> Input Class Initialized
INFO - 2024-12-11 08:11:27 --> Language Class Initialized
ERROR - 2024-12-11 08:11:27 --> 404 Page Not Found: Wp-admin/S6HMz7OmcxD.php
INFO - 2024-12-11 08:11:29 --> Config Class Initialized
INFO - 2024-12-11 08:11:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:29 --> URI Class Initialized
INFO - 2024-12-11 08:11:29 --> Router Class Initialized
INFO - 2024-12-11 08:11:29 --> Output Class Initialized
INFO - 2024-12-11 08:11:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:29 --> Input Class Initialized
INFO - 2024-12-11 08:11:29 --> Language Class Initialized
ERROR - 2024-12-11 08:11:29 --> 404 Page Not Found: Wp-admin/jk46yBprNeF.php
INFO - 2024-12-11 08:11:31 --> Config Class Initialized
INFO - 2024-12-11 08:11:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:31 --> URI Class Initialized
INFO - 2024-12-11 08:11:31 --> Router Class Initialized
INFO - 2024-12-11 08:11:31 --> Output Class Initialized
INFO - 2024-12-11 08:11:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:31 --> Input Class Initialized
INFO - 2024-12-11 08:11:31 --> Language Class Initialized
ERROR - 2024-12-11 08:11:31 --> 404 Page Not Found: XVSCEaqQ9p1php/index
INFO - 2024-12-11 08:11:36 --> Config Class Initialized
INFO - 2024-12-11 08:11:36 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:36 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:36 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:36 --> URI Class Initialized
INFO - 2024-12-11 08:11:36 --> Router Class Initialized
INFO - 2024-12-11 08:11:36 --> Output Class Initialized
INFO - 2024-12-11 08:11:36 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:36 --> Input Class Initialized
INFO - 2024-12-11 08:11:36 --> Language Class Initialized
ERROR - 2024-12-11 08:11:36 --> 404 Page Not Found: Wp-admin/47FijhTcb65.php
INFO - 2024-12-11 08:11:38 --> Config Class Initialized
INFO - 2024-12-11 08:11:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:38 --> URI Class Initialized
INFO - 2024-12-11 08:11:38 --> Router Class Initialized
INFO - 2024-12-11 08:11:38 --> Output Class Initialized
INFO - 2024-12-11 08:11:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:38 --> Input Class Initialized
INFO - 2024-12-11 08:11:38 --> Language Class Initialized
ERROR - 2024-12-11 08:11:38 --> 404 Page Not Found: Wp-admin/G2nRFHOfC1r.php
INFO - 2024-12-11 08:11:39 --> Config Class Initialized
INFO - 2024-12-11 08:11:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:39 --> URI Class Initialized
INFO - 2024-12-11 08:11:39 --> Router Class Initialized
INFO - 2024-12-11 08:11:39 --> Output Class Initialized
INFO - 2024-12-11 08:11:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:39 --> Input Class Initialized
INFO - 2024-12-11 08:11:39 --> Language Class Initialized
ERROR - 2024-12-11 08:11:39 --> 404 Page Not Found: DjXAZSd8yMkphp/index
INFO - 2024-12-11 08:11:40 --> Config Class Initialized
INFO - 2024-12-11 08:11:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:40 --> URI Class Initialized
INFO - 2024-12-11 08:11:40 --> Router Class Initialized
INFO - 2024-12-11 08:11:40 --> Output Class Initialized
INFO - 2024-12-11 08:11:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:40 --> Input Class Initialized
INFO - 2024-12-11 08:11:40 --> Language Class Initialized
ERROR - 2024-12-11 08:11:40 --> 404 Page Not Found: Wp-admin/sYpGdXWqfJi.php
INFO - 2024-12-11 08:11:44 --> Config Class Initialized
INFO - 2024-12-11 08:11:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:44 --> URI Class Initialized
INFO - 2024-12-11 08:11:44 --> Router Class Initialized
INFO - 2024-12-11 08:11:44 --> Output Class Initialized
INFO - 2024-12-11 08:11:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:44 --> Input Class Initialized
INFO - 2024-12-11 08:11:44 --> Language Class Initialized
ERROR - 2024-12-11 08:11:44 --> 404 Page Not Found: Wp-admin/q5IOSnlUeVd.php
INFO - 2024-12-11 08:11:45 --> Config Class Initialized
INFO - 2024-12-11 08:11:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:45 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:45 --> URI Class Initialized
INFO - 2024-12-11 08:11:45 --> Router Class Initialized
INFO - 2024-12-11 08:11:45 --> Output Class Initialized
INFO - 2024-12-11 08:11:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:45 --> Input Class Initialized
INFO - 2024-12-11 08:11:45 --> Language Class Initialized
ERROR - 2024-12-11 08:11:45 --> 404 Page Not Found: Ng58Uuvx2TXphp/index
INFO - 2024-12-11 08:11:48 --> Config Class Initialized
INFO - 2024-12-11 08:11:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:48 --> URI Class Initialized
INFO - 2024-12-11 08:11:48 --> Router Class Initialized
INFO - 2024-12-11 08:11:48 --> Output Class Initialized
INFO - 2024-12-11 08:11:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:48 --> Input Class Initialized
INFO - 2024-12-11 08:11:48 --> Language Class Initialized
ERROR - 2024-12-11 08:11:48 --> 404 Page Not Found: Wp-admin/ziQAjy7pnsX.php
INFO - 2024-12-11 08:11:48 --> Config Class Initialized
INFO - 2024-12-11 08:11:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:48 --> URI Class Initialized
INFO - 2024-12-11 08:11:48 --> Router Class Initialized
INFO - 2024-12-11 08:11:48 --> Output Class Initialized
INFO - 2024-12-11 08:11:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:48 --> Input Class Initialized
INFO - 2024-12-11 08:11:48 --> Language Class Initialized
ERROR - 2024-12-11 08:11:48 --> 404 Page Not Found: HMfSZq1DGUzphp/index
INFO - 2024-12-11 08:11:49 --> Config Class Initialized
INFO - 2024-12-11 08:11:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:49 --> URI Class Initialized
INFO - 2024-12-11 08:11:49 --> Router Class Initialized
INFO - 2024-12-11 08:11:49 --> Output Class Initialized
INFO - 2024-12-11 08:11:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:49 --> Input Class Initialized
INFO - 2024-12-11 08:11:49 --> Language Class Initialized
ERROR - 2024-12-11 08:11:49 --> 404 Page Not Found: Pmy9MQrigZBphp/index
INFO - 2024-12-11 08:11:50 --> Config Class Initialized
INFO - 2024-12-11 08:11:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:50 --> URI Class Initialized
INFO - 2024-12-11 08:11:50 --> Router Class Initialized
INFO - 2024-12-11 08:11:50 --> Output Class Initialized
INFO - 2024-12-11 08:11:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:50 --> Input Class Initialized
INFO - 2024-12-11 08:11:50 --> Language Class Initialized
ERROR - 2024-12-11 08:11:50 --> 404 Page Not Found: Wp-admin/PLTbSKmhOI7.php
INFO - 2024-12-11 08:11:52 --> Config Class Initialized
INFO - 2024-12-11 08:11:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:52 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:52 --> URI Class Initialized
INFO - 2024-12-11 08:11:52 --> Router Class Initialized
INFO - 2024-12-11 08:11:52 --> Output Class Initialized
INFO - 2024-12-11 08:11:52 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:52 --> Input Class Initialized
INFO - 2024-12-11 08:11:52 --> Language Class Initialized
ERROR - 2024-12-11 08:11:52 --> 404 Page Not Found: Wp-admin/5d2Npyxrwh3.php
INFO - 2024-12-11 08:11:52 --> Config Class Initialized
INFO - 2024-12-11 08:11:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:52 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:52 --> URI Class Initialized
INFO - 2024-12-11 08:11:52 --> Router Class Initialized
INFO - 2024-12-11 08:11:52 --> Output Class Initialized
INFO - 2024-12-11 08:11:52 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:52 --> Input Class Initialized
INFO - 2024-12-11 08:11:52 --> Language Class Initialized
ERROR - 2024-12-11 08:11:52 --> 404 Page Not Found: Wp-admin/uQMqjdpEGsK.php
INFO - 2024-12-11 08:11:53 --> Config Class Initialized
INFO - 2024-12-11 08:11:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:53 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:53 --> URI Class Initialized
INFO - 2024-12-11 08:11:53 --> Router Class Initialized
INFO - 2024-12-11 08:11:53 --> Output Class Initialized
INFO - 2024-12-11 08:11:53 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:53 --> Input Class Initialized
INFO - 2024-12-11 08:11:53 --> Language Class Initialized
ERROR - 2024-12-11 08:11:53 --> 404 Page Not Found: Wp-admin/mRkfVPMN1d8.php
INFO - 2024-12-11 08:11:56 --> Config Class Initialized
INFO - 2024-12-11 08:11:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:56 --> URI Class Initialized
INFO - 2024-12-11 08:11:56 --> Router Class Initialized
INFO - 2024-12-11 08:11:56 --> Output Class Initialized
INFO - 2024-12-11 08:11:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:56 --> Input Class Initialized
INFO - 2024-12-11 08:11:56 --> Language Class Initialized
ERROR - 2024-12-11 08:11:56 --> 404 Page Not Found: Wp-admin/5nBP4g8lKhy.php
INFO - 2024-12-11 08:11:59 --> Config Class Initialized
INFO - 2024-12-11 08:11:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:11:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:11:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:11:59 --> URI Class Initialized
INFO - 2024-12-11 08:11:59 --> Router Class Initialized
INFO - 2024-12-11 08:11:59 --> Output Class Initialized
INFO - 2024-12-11 08:11:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:11:59 --> Input Class Initialized
INFO - 2024-12-11 08:11:59 --> Language Class Initialized
ERROR - 2024-12-11 08:11:59 --> 404 Page Not Found: Wp-admin/twPzEUSMDN7.php
INFO - 2024-12-11 08:12:02 --> Config Class Initialized
INFO - 2024-12-11 08:12:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:02 --> URI Class Initialized
INFO - 2024-12-11 08:12:02 --> Router Class Initialized
INFO - 2024-12-11 08:12:02 --> Output Class Initialized
INFO - 2024-12-11 08:12:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:02 --> Input Class Initialized
INFO - 2024-12-11 08:12:02 --> Language Class Initialized
ERROR - 2024-12-11 08:12:02 --> 404 Page Not Found: Wp-admin/w6Hte1ZPoDb.php
INFO - 2024-12-11 08:12:03 --> Config Class Initialized
INFO - 2024-12-11 08:12:03 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:03 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:03 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:03 --> URI Class Initialized
INFO - 2024-12-11 08:12:03 --> Router Class Initialized
INFO - 2024-12-11 08:12:03 --> Output Class Initialized
INFO - 2024-12-11 08:12:03 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:03 --> Input Class Initialized
INFO - 2024-12-11 08:12:03 --> Language Class Initialized
ERROR - 2024-12-11 08:12:03 --> 404 Page Not Found: Wp-admin/7Vncwps6JCO.php
INFO - 2024-12-11 08:12:11 --> Config Class Initialized
INFO - 2024-12-11 08:12:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:11 --> URI Class Initialized
INFO - 2024-12-11 08:12:11 --> Router Class Initialized
INFO - 2024-12-11 08:12:11 --> Output Class Initialized
INFO - 2024-12-11 08:12:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:11 --> Input Class Initialized
INFO - 2024-12-11 08:12:11 --> Language Class Initialized
ERROR - 2024-12-11 08:12:11 --> 404 Page Not Found: Wp-admin/eX8ZQ2KBcTp.php
INFO - 2024-12-11 08:12:14 --> Config Class Initialized
INFO - 2024-12-11 08:12:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:14 --> URI Class Initialized
INFO - 2024-12-11 08:12:14 --> Router Class Initialized
INFO - 2024-12-11 08:12:14 --> Output Class Initialized
INFO - 2024-12-11 08:12:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:14 --> Input Class Initialized
INFO - 2024-12-11 08:12:14 --> Language Class Initialized
ERROR - 2024-12-11 08:12:14 --> 404 Page Not Found: Wp-admin/rWfkRJGEj4i.php
INFO - 2024-12-11 08:12:14 --> Config Class Initialized
INFO - 2024-12-11 08:12:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:14 --> URI Class Initialized
INFO - 2024-12-11 08:12:14 --> Router Class Initialized
INFO - 2024-12-11 08:12:14 --> Output Class Initialized
INFO - 2024-12-11 08:12:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:14 --> Input Class Initialized
INFO - 2024-12-11 08:12:14 --> Language Class Initialized
ERROR - 2024-12-11 08:12:14 --> 404 Page Not Found: Wp-admin/XQ3LNmipdVF.php
INFO - 2024-12-11 08:12:16 --> Config Class Initialized
INFO - 2024-12-11 08:12:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:16 --> URI Class Initialized
INFO - 2024-12-11 08:12:16 --> Router Class Initialized
INFO - 2024-12-11 08:12:16 --> Output Class Initialized
INFO - 2024-12-11 08:12:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:16 --> Input Class Initialized
INFO - 2024-12-11 08:12:16 --> Language Class Initialized
ERROR - 2024-12-11 08:12:16 --> 404 Page Not Found: Wp-admin/ZkrwD52GNHE.php
INFO - 2024-12-11 08:12:18 --> Config Class Initialized
INFO - 2024-12-11 08:12:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:18 --> URI Class Initialized
INFO - 2024-12-11 08:12:18 --> Router Class Initialized
INFO - 2024-12-11 08:12:18 --> Output Class Initialized
INFO - 2024-12-11 08:12:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:18 --> Input Class Initialized
INFO - 2024-12-11 08:12:18 --> Language Class Initialized
ERROR - 2024-12-11 08:12:18 --> 404 Page Not Found: Wp-admin/UXp634mrDZs.php
INFO - 2024-12-11 08:12:19 --> Config Class Initialized
INFO - 2024-12-11 08:12:19 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:19 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:19 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:19 --> URI Class Initialized
INFO - 2024-12-11 08:12:19 --> Router Class Initialized
INFO - 2024-12-11 08:12:19 --> Output Class Initialized
INFO - 2024-12-11 08:12:19 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:19 --> Input Class Initialized
INFO - 2024-12-11 08:12:19 --> Language Class Initialized
ERROR - 2024-12-11 08:12:19 --> 404 Page Not Found: Wp-admin/GgThJRea628.php
INFO - 2024-12-11 08:12:33 --> Config Class Initialized
INFO - 2024-12-11 08:12:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:33 --> URI Class Initialized
INFO - 2024-12-11 08:12:33 --> Router Class Initialized
INFO - 2024-12-11 08:12:33 --> Output Class Initialized
INFO - 2024-12-11 08:12:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:33 --> Input Class Initialized
INFO - 2024-12-11 08:12:33 --> Language Class Initialized
ERROR - 2024-12-11 08:12:33 --> 404 Page Not Found: Wp-admin/ArXRH3UkoZS.php
INFO - 2024-12-11 08:12:34 --> Config Class Initialized
INFO - 2024-12-11 08:12:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:34 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:34 --> URI Class Initialized
INFO - 2024-12-11 08:12:34 --> Router Class Initialized
INFO - 2024-12-11 08:12:34 --> Output Class Initialized
INFO - 2024-12-11 08:12:34 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:34 --> Input Class Initialized
INFO - 2024-12-11 08:12:34 --> Language Class Initialized
ERROR - 2024-12-11 08:12:34 --> 404 Page Not Found: Wp-admin/7bJfhoZVHwv.php
INFO - 2024-12-11 08:12:34 --> Config Class Initialized
INFO - 2024-12-11 08:12:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:34 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:34 --> URI Class Initialized
INFO - 2024-12-11 08:12:34 --> Router Class Initialized
INFO - 2024-12-11 08:12:34 --> Output Class Initialized
INFO - 2024-12-11 08:12:34 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:34 --> Input Class Initialized
INFO - 2024-12-11 08:12:34 --> Language Class Initialized
ERROR - 2024-12-11 08:12:34 --> 404 Page Not Found: Wp-admin/Q1ft5xT8OVM.php
INFO - 2024-12-11 08:12:34 --> Config Class Initialized
INFO - 2024-12-11 08:12:34 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:34 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:34 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:34 --> URI Class Initialized
INFO - 2024-12-11 08:12:34 --> Router Class Initialized
INFO - 2024-12-11 08:12:34 --> Output Class Initialized
INFO - 2024-12-11 08:12:34 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:34 --> Input Class Initialized
INFO - 2024-12-11 08:12:34 --> Language Class Initialized
ERROR - 2024-12-11 08:12:34 --> 404 Page Not Found: Wp-admin/JbjnrZsdL3X.php
INFO - 2024-12-11 08:12:35 --> Config Class Initialized
INFO - 2024-12-11 08:12:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:35 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:35 --> URI Class Initialized
INFO - 2024-12-11 08:12:35 --> Router Class Initialized
INFO - 2024-12-11 08:12:35 --> Output Class Initialized
INFO - 2024-12-11 08:12:35 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:35 --> Input Class Initialized
INFO - 2024-12-11 08:12:35 --> Language Class Initialized
ERROR - 2024-12-11 08:12:35 --> 404 Page Not Found: NwHsaGq6yMrphp/index
INFO - 2024-12-11 08:12:35 --> Config Class Initialized
INFO - 2024-12-11 08:12:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:35 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:35 --> URI Class Initialized
INFO - 2024-12-11 08:12:35 --> Router Class Initialized
INFO - 2024-12-11 08:12:35 --> Output Class Initialized
INFO - 2024-12-11 08:12:35 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:35 --> Input Class Initialized
INFO - 2024-12-11 08:12:35 --> Language Class Initialized
ERROR - 2024-12-11 08:12:35 --> 404 Page Not Found: SOUwjQsmMX4php/index
INFO - 2024-12-11 08:12:40 --> Config Class Initialized
INFO - 2024-12-11 08:12:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:40 --> URI Class Initialized
INFO - 2024-12-11 08:12:40 --> Router Class Initialized
INFO - 2024-12-11 08:12:40 --> Output Class Initialized
INFO - 2024-12-11 08:12:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:40 --> Input Class Initialized
INFO - 2024-12-11 08:12:40 --> Language Class Initialized
ERROR - 2024-12-11 08:12:40 --> 404 Page Not Found: Wp-admin/Vply6CqS8I3.php
INFO - 2024-12-11 08:12:45 --> Config Class Initialized
INFO - 2024-12-11 08:12:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:45 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:45 --> URI Class Initialized
INFO - 2024-12-11 08:12:45 --> Router Class Initialized
INFO - 2024-12-11 08:12:45 --> Output Class Initialized
INFO - 2024-12-11 08:12:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:45 --> Input Class Initialized
INFO - 2024-12-11 08:12:45 --> Language Class Initialized
ERROR - 2024-12-11 08:12:45 --> 404 Page Not Found: C4WYUPwIfNJphp/index
INFO - 2024-12-11 08:12:49 --> Config Class Initialized
INFO - 2024-12-11 08:12:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:49 --> URI Class Initialized
INFO - 2024-12-11 08:12:49 --> Router Class Initialized
INFO - 2024-12-11 08:12:49 --> Output Class Initialized
INFO - 2024-12-11 08:12:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:49 --> Input Class Initialized
INFO - 2024-12-11 08:12:49 --> Language Class Initialized
ERROR - 2024-12-11 08:12:49 --> 404 Page Not Found: Wp-admin/jXkqsT8dHYp.php
INFO - 2024-12-11 08:12:50 --> Config Class Initialized
INFO - 2024-12-11 08:12:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:50 --> URI Class Initialized
INFO - 2024-12-11 08:12:50 --> Router Class Initialized
INFO - 2024-12-11 08:12:50 --> Output Class Initialized
INFO - 2024-12-11 08:12:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:50 --> Input Class Initialized
INFO - 2024-12-11 08:12:50 --> Language Class Initialized
ERROR - 2024-12-11 08:12:50 --> 404 Page Not Found: Wp-admin/vzaLd8xeI1h.php
INFO - 2024-12-11 08:12:56 --> Config Class Initialized
INFO - 2024-12-11 08:12:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:56 --> URI Class Initialized
INFO - 2024-12-11 08:12:56 --> Router Class Initialized
INFO - 2024-12-11 08:12:56 --> Output Class Initialized
INFO - 2024-12-11 08:12:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:56 --> Input Class Initialized
INFO - 2024-12-11 08:12:56 --> Language Class Initialized
ERROR - 2024-12-11 08:12:56 --> 404 Page Not Found: Wp-admin/RD5Vth4Cqrj.php
INFO - 2024-12-11 08:12:58 --> Config Class Initialized
INFO - 2024-12-11 08:12:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:12:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:12:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:12:58 --> URI Class Initialized
INFO - 2024-12-11 08:12:58 --> Router Class Initialized
INFO - 2024-12-11 08:12:58 --> Output Class Initialized
INFO - 2024-12-11 08:12:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:12:58 --> Input Class Initialized
INFO - 2024-12-11 08:12:58 --> Language Class Initialized
ERROR - 2024-12-11 08:12:58 --> 404 Page Not Found: Wp-admin/R37YCfIhTnw.php
INFO - 2024-12-11 08:13:01 --> Config Class Initialized
INFO - 2024-12-11 08:13:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:01 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:01 --> URI Class Initialized
INFO - 2024-12-11 08:13:01 --> Router Class Initialized
INFO - 2024-12-11 08:13:01 --> Output Class Initialized
INFO - 2024-12-11 08:13:01 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:01 --> Input Class Initialized
INFO - 2024-12-11 08:13:01 --> Language Class Initialized
ERROR - 2024-12-11 08:13:01 --> 404 Page Not Found: Wp-admin/ZPpKcxDr2eh.php
INFO - 2024-12-11 08:13:08 --> Config Class Initialized
INFO - 2024-12-11 08:13:08 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:08 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:08 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:08 --> URI Class Initialized
INFO - 2024-12-11 08:13:08 --> Router Class Initialized
INFO - 2024-12-11 08:13:08 --> Output Class Initialized
INFO - 2024-12-11 08:13:08 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:08 --> Input Class Initialized
INFO - 2024-12-11 08:13:08 --> Language Class Initialized
ERROR - 2024-12-11 08:13:08 --> 404 Page Not Found: Wp-admin/unSEm8Kf2P6.php
INFO - 2024-12-11 08:13:10 --> Config Class Initialized
INFO - 2024-12-11 08:13:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:10 --> URI Class Initialized
INFO - 2024-12-11 08:13:10 --> Router Class Initialized
INFO - 2024-12-11 08:13:10 --> Output Class Initialized
INFO - 2024-12-11 08:13:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:10 --> Input Class Initialized
INFO - 2024-12-11 08:13:10 --> Language Class Initialized
ERROR - 2024-12-11 08:13:10 --> 404 Page Not Found: Wp-admin/lxKCfkmZiMD.php
INFO - 2024-12-11 08:13:11 --> Config Class Initialized
INFO - 2024-12-11 08:13:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:11 --> URI Class Initialized
INFO - 2024-12-11 08:13:11 --> Router Class Initialized
INFO - 2024-12-11 08:13:11 --> Output Class Initialized
INFO - 2024-12-11 08:13:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:11 --> Input Class Initialized
INFO - 2024-12-11 08:13:11 --> Language Class Initialized
ERROR - 2024-12-11 08:13:11 --> 404 Page Not Found: Wp-admin/Trka3NUxzu6.php
INFO - 2024-12-11 08:13:13 --> Config Class Initialized
INFO - 2024-12-11 08:13:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:13 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:13 --> URI Class Initialized
INFO - 2024-12-11 08:13:13 --> Router Class Initialized
INFO - 2024-12-11 08:13:13 --> Output Class Initialized
INFO - 2024-12-11 08:13:13 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:13 --> Input Class Initialized
INFO - 2024-12-11 08:13:13 --> Language Class Initialized
ERROR - 2024-12-11 08:13:13 --> 404 Page Not Found: Wp-admin/YCIQl6XUkOw.php
INFO - 2024-12-11 08:13:15 --> Config Class Initialized
INFO - 2024-12-11 08:13:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:15 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:15 --> URI Class Initialized
INFO - 2024-12-11 08:13:15 --> Router Class Initialized
INFO - 2024-12-11 08:13:15 --> Output Class Initialized
INFO - 2024-12-11 08:13:15 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:15 --> Input Class Initialized
INFO - 2024-12-11 08:13:15 --> Language Class Initialized
ERROR - 2024-12-11 08:13:15 --> 404 Page Not Found: Wp-admin/iDf7CPEUBdu.php
INFO - 2024-12-11 08:13:26 --> Config Class Initialized
INFO - 2024-12-11 08:13:26 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:26 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:26 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:26 --> URI Class Initialized
INFO - 2024-12-11 08:13:26 --> Router Class Initialized
INFO - 2024-12-11 08:13:26 --> Output Class Initialized
INFO - 2024-12-11 08:13:26 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:26 --> Input Class Initialized
INFO - 2024-12-11 08:13:26 --> Language Class Initialized
ERROR - 2024-12-11 08:13:26 --> 404 Page Not Found: Wp-admin/1NsglpbmihP.php
INFO - 2024-12-11 08:13:31 --> Config Class Initialized
INFO - 2024-12-11 08:13:31 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:31 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:31 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:31 --> URI Class Initialized
INFO - 2024-12-11 08:13:31 --> Router Class Initialized
INFO - 2024-12-11 08:13:31 --> Output Class Initialized
INFO - 2024-12-11 08:13:31 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:31 --> Input Class Initialized
INFO - 2024-12-11 08:13:31 --> Language Class Initialized
ERROR - 2024-12-11 08:13:31 --> 404 Page Not Found: Wp-admin/cA1nd3DPhLx.php
INFO - 2024-12-11 08:13:39 --> Config Class Initialized
INFO - 2024-12-11 08:13:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:39 --> URI Class Initialized
INFO - 2024-12-11 08:13:39 --> Router Class Initialized
INFO - 2024-12-11 08:13:39 --> Output Class Initialized
INFO - 2024-12-11 08:13:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:39 --> Input Class Initialized
INFO - 2024-12-11 08:13:39 --> Language Class Initialized
ERROR - 2024-12-11 08:13:39 --> 404 Page Not Found: QRbsjoCFz9Jphp/index
INFO - 2024-12-11 08:13:40 --> Config Class Initialized
INFO - 2024-12-11 08:13:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:40 --> URI Class Initialized
INFO - 2024-12-11 08:13:40 --> Router Class Initialized
INFO - 2024-12-11 08:13:40 --> Output Class Initialized
INFO - 2024-12-11 08:13:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:40 --> Input Class Initialized
INFO - 2024-12-11 08:13:40 --> Language Class Initialized
ERROR - 2024-12-11 08:13:40 --> 404 Page Not Found: InmN2D5Haolphp/index
INFO - 2024-12-11 08:13:41 --> Config Class Initialized
INFO - 2024-12-11 08:13:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:41 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:41 --> URI Class Initialized
INFO - 2024-12-11 08:13:41 --> Router Class Initialized
INFO - 2024-12-11 08:13:41 --> Output Class Initialized
INFO - 2024-12-11 08:13:41 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:41 --> Input Class Initialized
INFO - 2024-12-11 08:13:41 --> Language Class Initialized
ERROR - 2024-12-11 08:13:41 --> 404 Page Not Found: Wp-admin/H4SEiYmCl7t.php
INFO - 2024-12-11 08:13:42 --> Config Class Initialized
INFO - 2024-12-11 08:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:42 --> URI Class Initialized
INFO - 2024-12-11 08:13:42 --> Router Class Initialized
INFO - 2024-12-11 08:13:42 --> Output Class Initialized
INFO - 2024-12-11 08:13:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:42 --> Input Class Initialized
INFO - 2024-12-11 08:13:42 --> Language Class Initialized
ERROR - 2024-12-11 08:13:42 --> 404 Page Not Found: QPVAHc4eEONphp/index
INFO - 2024-12-11 08:13:43 --> Config Class Initialized
INFO - 2024-12-11 08:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:43 --> URI Class Initialized
INFO - 2024-12-11 08:13:43 --> Router Class Initialized
INFO - 2024-12-11 08:13:43 --> Output Class Initialized
INFO - 2024-12-11 08:13:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:43 --> Input Class Initialized
INFO - 2024-12-11 08:13:43 --> Language Class Initialized
ERROR - 2024-12-11 08:13:43 --> 404 Page Not Found: Wp-admin/SPycWUDsuGr.php
INFO - 2024-12-11 08:13:47 --> Config Class Initialized
INFO - 2024-12-11 08:13:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:47 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:47 --> URI Class Initialized
INFO - 2024-12-11 08:13:47 --> Router Class Initialized
INFO - 2024-12-11 08:13:47 --> Output Class Initialized
INFO - 2024-12-11 08:13:47 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:47 --> Input Class Initialized
INFO - 2024-12-11 08:13:47 --> Language Class Initialized
ERROR - 2024-12-11 08:13:47 --> 404 Page Not Found: NCo53zRutj9php/index
INFO - 2024-12-11 08:13:49 --> Config Class Initialized
INFO - 2024-12-11 08:13:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:49 --> URI Class Initialized
INFO - 2024-12-11 08:13:49 --> Router Class Initialized
INFO - 2024-12-11 08:13:49 --> Output Class Initialized
INFO - 2024-12-11 08:13:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:49 --> Input Class Initialized
INFO - 2024-12-11 08:13:49 --> Language Class Initialized
ERROR - 2024-12-11 08:13:49 --> 404 Page Not Found: Ae2d3Y9PMEZphp/index
INFO - 2024-12-11 08:13:49 --> Config Class Initialized
INFO - 2024-12-11 08:13:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:49 --> URI Class Initialized
INFO - 2024-12-11 08:13:49 --> Router Class Initialized
INFO - 2024-12-11 08:13:49 --> Output Class Initialized
INFO - 2024-12-11 08:13:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:49 --> Input Class Initialized
INFO - 2024-12-11 08:13:49 --> Language Class Initialized
ERROR - 2024-12-11 08:13:49 --> 404 Page Not Found: APsTHSdqGb2php/index
INFO - 2024-12-11 08:13:50 --> Config Class Initialized
INFO - 2024-12-11 08:13:50 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:50 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:50 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:50 --> URI Class Initialized
INFO - 2024-12-11 08:13:50 --> Router Class Initialized
INFO - 2024-12-11 08:13:50 --> Output Class Initialized
INFO - 2024-12-11 08:13:50 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:50 --> Input Class Initialized
INFO - 2024-12-11 08:13:50 --> Language Class Initialized
ERROR - 2024-12-11 08:13:50 --> 404 Page Not Found: RJU8xelhSHEphp/index
INFO - 2024-12-11 08:13:52 --> Config Class Initialized
INFO - 2024-12-11 08:13:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:52 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:52 --> URI Class Initialized
INFO - 2024-12-11 08:13:52 --> Router Class Initialized
INFO - 2024-12-11 08:13:52 --> Output Class Initialized
INFO - 2024-12-11 08:13:52 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:52 --> Input Class Initialized
INFO - 2024-12-11 08:13:52 --> Language Class Initialized
ERROR - 2024-12-11 08:13:52 --> 404 Page Not Found: Wp-admin/zIcBvRxS3PW.php
INFO - 2024-12-11 08:13:55 --> Config Class Initialized
INFO - 2024-12-11 08:13:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:13:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:13:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:13:55 --> URI Class Initialized
INFO - 2024-12-11 08:13:55 --> Router Class Initialized
INFO - 2024-12-11 08:13:55 --> Output Class Initialized
INFO - 2024-12-11 08:13:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:13:55 --> Input Class Initialized
INFO - 2024-12-11 08:13:55 --> Language Class Initialized
ERROR - 2024-12-11 08:13:55 --> 404 Page Not Found: Wp-admin/xBP6GZcW32q.php
INFO - 2024-12-11 08:14:10 --> Config Class Initialized
INFO - 2024-12-11 08:14:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:10 --> URI Class Initialized
INFO - 2024-12-11 08:14:10 --> Router Class Initialized
INFO - 2024-12-11 08:14:10 --> Output Class Initialized
INFO - 2024-12-11 08:14:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:10 --> Input Class Initialized
INFO - 2024-12-11 08:14:10 --> Language Class Initialized
ERROR - 2024-12-11 08:14:10 --> 404 Page Not Found: 6HtUGxR3pDZphp/index
INFO - 2024-12-11 08:14:11 --> Config Class Initialized
INFO - 2024-12-11 08:14:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:11 --> URI Class Initialized
INFO - 2024-12-11 08:14:11 --> Router Class Initialized
INFO - 2024-12-11 08:14:11 --> Output Class Initialized
INFO - 2024-12-11 08:14:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:11 --> Input Class Initialized
INFO - 2024-12-11 08:14:11 --> Language Class Initialized
ERROR - 2024-12-11 08:14:11 --> 404 Page Not Found: Wp-admin/nhfrpG1W48j.php
INFO - 2024-12-11 08:14:16 --> Config Class Initialized
INFO - 2024-12-11 08:14:16 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:16 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:16 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:16 --> URI Class Initialized
INFO - 2024-12-11 08:14:16 --> Router Class Initialized
INFO - 2024-12-11 08:14:16 --> Output Class Initialized
INFO - 2024-12-11 08:14:16 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:16 --> Input Class Initialized
INFO - 2024-12-11 08:14:16 --> Language Class Initialized
ERROR - 2024-12-11 08:14:16 --> 404 Page Not Found: Wp-admin/JQVplhWGEjT.php
INFO - 2024-12-11 08:14:20 --> Config Class Initialized
INFO - 2024-12-11 08:14:20 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:20 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:20 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:20 --> URI Class Initialized
INFO - 2024-12-11 08:14:20 --> Router Class Initialized
INFO - 2024-12-11 08:14:20 --> Output Class Initialized
INFO - 2024-12-11 08:14:20 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:20 --> Input Class Initialized
INFO - 2024-12-11 08:14:20 --> Language Class Initialized
ERROR - 2024-12-11 08:14:20 --> 404 Page Not Found: Wp-admin/a5uPEjzehk1.php
INFO - 2024-12-11 08:14:23 --> Config Class Initialized
INFO - 2024-12-11 08:14:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:23 --> URI Class Initialized
INFO - 2024-12-11 08:14:23 --> Router Class Initialized
INFO - 2024-12-11 08:14:23 --> Output Class Initialized
INFO - 2024-12-11 08:14:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:23 --> Input Class Initialized
INFO - 2024-12-11 08:14:23 --> Language Class Initialized
ERROR - 2024-12-11 08:14:23 --> 404 Page Not Found: Wp-admin/Gu2NdI1gPFL.php
INFO - 2024-12-11 08:14:24 --> Config Class Initialized
INFO - 2024-12-11 08:14:24 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:24 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:24 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:24 --> URI Class Initialized
INFO - 2024-12-11 08:14:24 --> Router Class Initialized
INFO - 2024-12-11 08:14:24 --> Output Class Initialized
INFO - 2024-12-11 08:14:24 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:24 --> Input Class Initialized
INFO - 2024-12-11 08:14:24 --> Language Class Initialized
ERROR - 2024-12-11 08:14:24 --> 404 Page Not Found: Wp-admin/CjJ1wlcvVzU.php
INFO - 2024-12-11 08:14:28 --> Config Class Initialized
INFO - 2024-12-11 08:14:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:28 --> URI Class Initialized
INFO - 2024-12-11 08:14:28 --> Router Class Initialized
INFO - 2024-12-11 08:14:28 --> Output Class Initialized
INFO - 2024-12-11 08:14:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:28 --> Input Class Initialized
INFO - 2024-12-11 08:14:28 --> Language Class Initialized
ERROR - 2024-12-11 08:14:28 --> 404 Page Not Found: Wp-admin/XDKCe7dfgim.php
INFO - 2024-12-11 08:14:37 --> Config Class Initialized
INFO - 2024-12-11 08:14:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:37 --> URI Class Initialized
INFO - 2024-12-11 08:14:37 --> Router Class Initialized
INFO - 2024-12-11 08:14:37 --> Output Class Initialized
INFO - 2024-12-11 08:14:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:37 --> Input Class Initialized
INFO - 2024-12-11 08:14:37 --> Language Class Initialized
ERROR - 2024-12-11 08:14:37 --> 404 Page Not Found: Wp-admin/TqbrGSylIoC.php
INFO - 2024-12-11 08:14:42 --> Config Class Initialized
INFO - 2024-12-11 08:14:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:42 --> URI Class Initialized
INFO - 2024-12-11 08:14:42 --> Router Class Initialized
INFO - 2024-12-11 08:14:42 --> Output Class Initialized
INFO - 2024-12-11 08:14:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:42 --> Input Class Initialized
INFO - 2024-12-11 08:14:42 --> Language Class Initialized
ERROR - 2024-12-11 08:14:42 --> 404 Page Not Found: Wp-admin/lwkpqx1UJ9f.php
INFO - 2024-12-11 08:14:43 --> Config Class Initialized
INFO - 2024-12-11 08:14:43 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:43 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:43 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:43 --> URI Class Initialized
INFO - 2024-12-11 08:14:43 --> Router Class Initialized
INFO - 2024-12-11 08:14:43 --> Output Class Initialized
INFO - 2024-12-11 08:14:43 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:43 --> Input Class Initialized
INFO - 2024-12-11 08:14:43 --> Language Class Initialized
ERROR - 2024-12-11 08:14:43 --> 404 Page Not Found: Wp-admin/vtXe2CGYWo7.php
INFO - 2024-12-11 08:14:45 --> Config Class Initialized
INFO - 2024-12-11 08:14:45 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:45 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:45 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:45 --> URI Class Initialized
INFO - 2024-12-11 08:14:45 --> Router Class Initialized
INFO - 2024-12-11 08:14:45 --> Output Class Initialized
INFO - 2024-12-11 08:14:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:45 --> Input Class Initialized
INFO - 2024-12-11 08:14:45 --> Language Class Initialized
ERROR - 2024-12-11 08:14:45 --> 404 Page Not Found: Wp-admin/3atWH1PVUE5.php
INFO - 2024-12-11 08:14:46 --> Config Class Initialized
INFO - 2024-12-11 08:14:46 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:46 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:46 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:46 --> URI Class Initialized
INFO - 2024-12-11 08:14:46 --> Router Class Initialized
INFO - 2024-12-11 08:14:46 --> Output Class Initialized
INFO - 2024-12-11 08:14:46 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:46 --> Input Class Initialized
INFO - 2024-12-11 08:14:46 --> Language Class Initialized
ERROR - 2024-12-11 08:14:46 --> 404 Page Not Found: Wp-admin/I3UXbCfrRkW.php
INFO - 2024-12-11 08:14:48 --> Config Class Initialized
INFO - 2024-12-11 08:14:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:48 --> URI Class Initialized
INFO - 2024-12-11 08:14:48 --> Router Class Initialized
INFO - 2024-12-11 08:14:48 --> Output Class Initialized
INFO - 2024-12-11 08:14:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:48 --> Input Class Initialized
INFO - 2024-12-11 08:14:48 --> Language Class Initialized
ERROR - 2024-12-11 08:14:48 --> 404 Page Not Found: J2OIxTcQdFJphp/index
INFO - 2024-12-11 08:14:49 --> Config Class Initialized
INFO - 2024-12-11 08:14:49 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:49 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:49 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:49 --> URI Class Initialized
INFO - 2024-12-11 08:14:49 --> Router Class Initialized
INFO - 2024-12-11 08:14:49 --> Output Class Initialized
INFO - 2024-12-11 08:14:49 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:49 --> Input Class Initialized
INFO - 2024-12-11 08:14:49 --> Language Class Initialized
ERROR - 2024-12-11 08:14:49 --> 404 Page Not Found: Wp-admin/ciCtTwgNHKo.php
INFO - 2024-12-11 08:14:51 --> Config Class Initialized
INFO - 2024-12-11 08:14:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:51 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:51 --> URI Class Initialized
INFO - 2024-12-11 08:14:51 --> Router Class Initialized
INFO - 2024-12-11 08:14:51 --> Output Class Initialized
INFO - 2024-12-11 08:14:51 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:51 --> Input Class Initialized
INFO - 2024-12-11 08:14:51 --> Language Class Initialized
ERROR - 2024-12-11 08:14:51 --> 404 Page Not Found: CeDgIsRE2SPphp/index
INFO - 2024-12-11 08:14:55 --> Config Class Initialized
INFO - 2024-12-11 08:14:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:55 --> URI Class Initialized
INFO - 2024-12-11 08:14:55 --> Router Class Initialized
INFO - 2024-12-11 08:14:55 --> Output Class Initialized
INFO - 2024-12-11 08:14:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:55 --> Input Class Initialized
INFO - 2024-12-11 08:14:55 --> Language Class Initialized
ERROR - 2024-12-11 08:14:55 --> 404 Page Not Found: Wp-admin/UpKYHjMPagu.php
INFO - 2024-12-11 08:14:59 --> Config Class Initialized
INFO - 2024-12-11 08:14:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:14:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:14:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:14:59 --> URI Class Initialized
INFO - 2024-12-11 08:14:59 --> Router Class Initialized
INFO - 2024-12-11 08:14:59 --> Output Class Initialized
INFO - 2024-12-11 08:14:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:14:59 --> Input Class Initialized
INFO - 2024-12-11 08:14:59 --> Language Class Initialized
ERROR - 2024-12-11 08:14:59 --> 404 Page Not Found: SwW2oAIqSyrphp/index
INFO - 2024-12-11 08:15:04 --> Config Class Initialized
INFO - 2024-12-11 08:15:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:04 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:04 --> URI Class Initialized
INFO - 2024-12-11 08:15:04 --> Router Class Initialized
INFO - 2024-12-11 08:15:04 --> Output Class Initialized
INFO - 2024-12-11 08:15:04 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:04 --> Input Class Initialized
INFO - 2024-12-11 08:15:04 --> Language Class Initialized
ERROR - 2024-12-11 08:15:04 --> 404 Page Not Found: Wp-admin/E6sDY4FPQJg.php
INFO - 2024-12-11 08:15:11 --> Config Class Initialized
INFO - 2024-12-11 08:15:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:11 --> URI Class Initialized
INFO - 2024-12-11 08:15:11 --> Router Class Initialized
INFO - 2024-12-11 08:15:11 --> Output Class Initialized
INFO - 2024-12-11 08:15:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:11 --> Input Class Initialized
INFO - 2024-12-11 08:15:11 --> Language Class Initialized
ERROR - 2024-12-11 08:15:11 --> 404 Page Not Found: Wp-admin/LsSTylNuZqw.php
INFO - 2024-12-11 08:15:12 --> Config Class Initialized
INFO - 2024-12-11 08:15:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:12 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:12 --> URI Class Initialized
INFO - 2024-12-11 08:15:12 --> Router Class Initialized
INFO - 2024-12-11 08:15:12 --> Output Class Initialized
INFO - 2024-12-11 08:15:12 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:12 --> Input Class Initialized
INFO - 2024-12-11 08:15:12 --> Language Class Initialized
ERROR - 2024-12-11 08:15:12 --> 404 Page Not Found: Wp-admin/muiR6HcIzNG.php
INFO - 2024-12-11 08:15:14 --> Config Class Initialized
INFO - 2024-12-11 08:15:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:14 --> URI Class Initialized
INFO - 2024-12-11 08:15:14 --> Router Class Initialized
INFO - 2024-12-11 08:15:14 --> Output Class Initialized
INFO - 2024-12-11 08:15:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:14 --> Input Class Initialized
INFO - 2024-12-11 08:15:14 --> Language Class Initialized
ERROR - 2024-12-11 08:15:14 --> 404 Page Not Found: Wp-admin/DuG1xUHMwnK.php
INFO - 2024-12-11 08:15:15 --> Config Class Initialized
INFO - 2024-12-11 08:15:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:15 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:15 --> URI Class Initialized
INFO - 2024-12-11 08:15:15 --> Router Class Initialized
INFO - 2024-12-11 08:15:15 --> Output Class Initialized
INFO - 2024-12-11 08:15:15 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:15 --> Input Class Initialized
INFO - 2024-12-11 08:15:15 --> Language Class Initialized
ERROR - 2024-12-11 08:15:15 --> 404 Page Not Found: Fo1t9ewGOZ5php/index
INFO - 2024-12-11 08:15:21 --> Config Class Initialized
INFO - 2024-12-11 08:15:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:21 --> URI Class Initialized
INFO - 2024-12-11 08:15:21 --> Router Class Initialized
INFO - 2024-12-11 08:15:21 --> Output Class Initialized
INFO - 2024-12-11 08:15:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:21 --> Input Class Initialized
INFO - 2024-12-11 08:15:21 --> Language Class Initialized
ERROR - 2024-12-11 08:15:21 --> 404 Page Not Found: Wp-admin/QWKfSgUkrby.php
INFO - 2024-12-11 08:15:21 --> Config Class Initialized
INFO - 2024-12-11 08:15:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:21 --> URI Class Initialized
INFO - 2024-12-11 08:15:21 --> Router Class Initialized
INFO - 2024-12-11 08:15:21 --> Output Class Initialized
INFO - 2024-12-11 08:15:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:21 --> Input Class Initialized
INFO - 2024-12-11 08:15:21 --> Language Class Initialized
ERROR - 2024-12-11 08:15:21 --> 404 Page Not Found: Wp-admin/CwVKpXHxcW8.php
INFO - 2024-12-11 08:15:21 --> Config Class Initialized
INFO - 2024-12-11 08:15:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:21 --> URI Class Initialized
INFO - 2024-12-11 08:15:21 --> Router Class Initialized
INFO - 2024-12-11 08:15:21 --> Output Class Initialized
INFO - 2024-12-11 08:15:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:21 --> Input Class Initialized
INFO - 2024-12-11 08:15:21 --> Language Class Initialized
ERROR - 2024-12-11 08:15:21 --> 404 Page Not Found: Wp-admin/RCPY3HtIQ5a.php
INFO - 2024-12-11 08:15:27 --> Config Class Initialized
INFO - 2024-12-11 08:15:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:27 --> URI Class Initialized
INFO - 2024-12-11 08:15:27 --> Router Class Initialized
INFO - 2024-12-11 08:15:27 --> Output Class Initialized
INFO - 2024-12-11 08:15:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:27 --> Input Class Initialized
INFO - 2024-12-11 08:15:27 --> Language Class Initialized
ERROR - 2024-12-11 08:15:27 --> 404 Page Not Found: Wp-admin/oBndQ2JSH4C.php
INFO - 2024-12-11 08:15:29 --> Config Class Initialized
INFO - 2024-12-11 08:15:29 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:29 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:29 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:29 --> URI Class Initialized
INFO - 2024-12-11 08:15:29 --> Router Class Initialized
INFO - 2024-12-11 08:15:29 --> Output Class Initialized
INFO - 2024-12-11 08:15:29 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:29 --> Input Class Initialized
INFO - 2024-12-11 08:15:29 --> Language Class Initialized
ERROR - 2024-12-11 08:15:29 --> 404 Page Not Found: Wp-admin/CvsmexRHBqU.php
INFO - 2024-12-11 08:15:32 --> Config Class Initialized
INFO - 2024-12-11 08:15:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:32 --> URI Class Initialized
INFO - 2024-12-11 08:15:32 --> Router Class Initialized
INFO - 2024-12-11 08:15:32 --> Output Class Initialized
INFO - 2024-12-11 08:15:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:32 --> Input Class Initialized
INFO - 2024-12-11 08:15:32 --> Language Class Initialized
ERROR - 2024-12-11 08:15:32 --> 404 Page Not Found: XQqloKbZYgCphp/index
INFO - 2024-12-11 08:15:33 --> Config Class Initialized
INFO - 2024-12-11 08:15:33 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:33 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:33 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:33 --> URI Class Initialized
INFO - 2024-12-11 08:15:33 --> Router Class Initialized
INFO - 2024-12-11 08:15:33 --> Output Class Initialized
INFO - 2024-12-11 08:15:33 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:33 --> Input Class Initialized
INFO - 2024-12-11 08:15:33 --> Language Class Initialized
ERROR - 2024-12-11 08:15:33 --> 404 Page Not Found: NL78M4RCWsOphp/index
INFO - 2024-12-11 08:15:35 --> Config Class Initialized
INFO - 2024-12-11 08:15:35 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:35 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:35 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:35 --> URI Class Initialized
INFO - 2024-12-11 08:15:35 --> Router Class Initialized
INFO - 2024-12-11 08:15:35 --> Output Class Initialized
INFO - 2024-12-11 08:15:35 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:35 --> Input Class Initialized
INFO - 2024-12-11 08:15:35 --> Language Class Initialized
ERROR - 2024-12-11 08:15:35 --> 404 Page Not Found: Wp-admin/KlIYHMGVnyc.php
INFO - 2024-12-11 08:15:44 --> Config Class Initialized
INFO - 2024-12-11 08:15:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:44 --> URI Class Initialized
INFO - 2024-12-11 08:15:44 --> Router Class Initialized
INFO - 2024-12-11 08:15:44 --> Output Class Initialized
INFO - 2024-12-11 08:15:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:44 --> Input Class Initialized
INFO - 2024-12-11 08:15:44 --> Language Class Initialized
ERROR - 2024-12-11 08:15:44 --> 404 Page Not Found: Wp-admin/ct7R6lwIh1W.php
INFO - 2024-12-11 08:15:47 --> Config Class Initialized
INFO - 2024-12-11 08:15:47 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:47 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:47 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:47 --> URI Class Initialized
INFO - 2024-12-11 08:15:47 --> Router Class Initialized
INFO - 2024-12-11 08:15:47 --> Output Class Initialized
INFO - 2024-12-11 08:15:47 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:47 --> Input Class Initialized
INFO - 2024-12-11 08:15:47 --> Language Class Initialized
ERROR - 2024-12-11 08:15:47 --> 404 Page Not Found: Wp-admin/SoBThd4g8lZ.php
INFO - 2024-12-11 08:15:48 --> Config Class Initialized
INFO - 2024-12-11 08:15:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:48 --> URI Class Initialized
INFO - 2024-12-11 08:15:48 --> Router Class Initialized
INFO - 2024-12-11 08:15:48 --> Output Class Initialized
INFO - 2024-12-11 08:15:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:48 --> Input Class Initialized
INFO - 2024-12-11 08:15:48 --> Language Class Initialized
ERROR - 2024-12-11 08:15:48 --> 404 Page Not Found: Wp-admin/ot4xuRp8IEL.php
INFO - 2024-12-11 08:15:51 --> Config Class Initialized
INFO - 2024-12-11 08:15:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:51 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:51 --> URI Class Initialized
INFO - 2024-12-11 08:15:51 --> Router Class Initialized
INFO - 2024-12-11 08:15:51 --> Output Class Initialized
INFO - 2024-12-11 08:15:51 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:51 --> Input Class Initialized
INFO - 2024-12-11 08:15:51 --> Language Class Initialized
ERROR - 2024-12-11 08:15:51 --> 404 Page Not Found: Wp-admin/sWryBKJYDPh.php
INFO - 2024-12-11 08:15:55 --> Config Class Initialized
INFO - 2024-12-11 08:15:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:55 --> URI Class Initialized
INFO - 2024-12-11 08:15:55 --> Router Class Initialized
INFO - 2024-12-11 08:15:55 --> Output Class Initialized
INFO - 2024-12-11 08:15:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:55 --> Input Class Initialized
INFO - 2024-12-11 08:15:55 --> Language Class Initialized
ERROR - 2024-12-11 08:15:55 --> 404 Page Not Found: Wp-admin/QFgWt3bwHL8.php
INFO - 2024-12-11 08:15:56 --> Config Class Initialized
INFO - 2024-12-11 08:15:56 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:56 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:56 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:56 --> URI Class Initialized
INFO - 2024-12-11 08:15:56 --> Router Class Initialized
INFO - 2024-12-11 08:15:56 --> Output Class Initialized
INFO - 2024-12-11 08:15:56 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:56 --> Input Class Initialized
INFO - 2024-12-11 08:15:56 --> Language Class Initialized
ERROR - 2024-12-11 08:15:56 --> 404 Page Not Found: Wp-admin/h7cfPADW9op.php
INFO - 2024-12-11 08:15:58 --> Config Class Initialized
INFO - 2024-12-11 08:15:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:58 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:58 --> URI Class Initialized
INFO - 2024-12-11 08:15:58 --> Router Class Initialized
INFO - 2024-12-11 08:15:58 --> Output Class Initialized
INFO - 2024-12-11 08:15:58 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:58 --> Input Class Initialized
INFO - 2024-12-11 08:15:58 --> Language Class Initialized
ERROR - 2024-12-11 08:15:58 --> 404 Page Not Found: Wp-admin/EqdZ37vcxjT.php
INFO - 2024-12-11 08:15:59 --> Config Class Initialized
INFO - 2024-12-11 08:15:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:15:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:15:59 --> Utf8 Class Initialized
INFO - 2024-12-11 08:15:59 --> URI Class Initialized
INFO - 2024-12-11 08:15:59 --> Router Class Initialized
INFO - 2024-12-11 08:15:59 --> Output Class Initialized
INFO - 2024-12-11 08:15:59 --> Security Class Initialized
DEBUG - 2024-12-11 08:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:15:59 --> Input Class Initialized
INFO - 2024-12-11 08:15:59 --> Language Class Initialized
ERROR - 2024-12-11 08:15:59 --> 404 Page Not Found: Wp-admin/Ug2qyA1IcjB.php
INFO - 2024-12-11 08:16:00 --> Config Class Initialized
INFO - 2024-12-11 08:16:00 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:00 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:00 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:00 --> URI Class Initialized
INFO - 2024-12-11 08:16:00 --> Router Class Initialized
INFO - 2024-12-11 08:16:00 --> Output Class Initialized
INFO - 2024-12-11 08:16:00 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:00 --> Input Class Initialized
INFO - 2024-12-11 08:16:00 --> Language Class Initialized
ERROR - 2024-12-11 08:16:00 --> 404 Page Not Found: Wp-admin/dNls67Eq1VP.php
INFO - 2024-12-11 08:16:02 --> Config Class Initialized
INFO - 2024-12-11 08:16:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:02 --> URI Class Initialized
INFO - 2024-12-11 08:16:02 --> Router Class Initialized
INFO - 2024-12-11 08:16:02 --> Output Class Initialized
INFO - 2024-12-11 08:16:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:02 --> Input Class Initialized
INFO - 2024-12-11 08:16:02 --> Language Class Initialized
ERROR - 2024-12-11 08:16:02 --> 404 Page Not Found: Wp-admin/AmRbFD5t8Kk.php
INFO - 2024-12-11 08:16:04 --> Config Class Initialized
INFO - 2024-12-11 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:04 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:04 --> URI Class Initialized
INFO - 2024-12-11 08:16:04 --> Router Class Initialized
INFO - 2024-12-11 08:16:04 --> Output Class Initialized
INFO - 2024-12-11 08:16:04 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:04 --> Input Class Initialized
INFO - 2024-12-11 08:16:04 --> Language Class Initialized
ERROR - 2024-12-11 08:16:04 --> 404 Page Not Found: Wp-admin/DnkMmtzY8Fx.php
INFO - 2024-12-11 08:16:04 --> Config Class Initialized
INFO - 2024-12-11 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:04 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:04 --> URI Class Initialized
INFO - 2024-12-11 08:16:04 --> Router Class Initialized
INFO - 2024-12-11 08:16:04 --> Output Class Initialized
INFO - 2024-12-11 08:16:04 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:04 --> Input Class Initialized
INFO - 2024-12-11 08:16:04 --> Language Class Initialized
ERROR - 2024-12-11 08:16:04 --> 404 Page Not Found: Components/4ewufvIGoqA.php
INFO - 2024-12-11 08:16:06 --> Config Class Initialized
INFO - 2024-12-11 08:16:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:06 --> URI Class Initialized
INFO - 2024-12-11 08:16:06 --> Router Class Initialized
INFO - 2024-12-11 08:16:06 --> Output Class Initialized
INFO - 2024-12-11 08:16:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:06 --> Input Class Initialized
INFO - 2024-12-11 08:16:06 --> Language Class Initialized
ERROR - 2024-12-11 08:16:06 --> 404 Page Not Found: Wp-admin/MtNvAy89hVR.php
INFO - 2024-12-11 08:16:10 --> Config Class Initialized
INFO - 2024-12-11 08:16:10 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:10 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:10 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:10 --> URI Class Initialized
INFO - 2024-12-11 08:16:10 --> Router Class Initialized
INFO - 2024-12-11 08:16:10 --> Output Class Initialized
INFO - 2024-12-11 08:16:10 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:10 --> Input Class Initialized
INFO - 2024-12-11 08:16:10 --> Language Class Initialized
ERROR - 2024-12-11 08:16:10 --> 404 Page Not Found: Wp-admin/bFvanS3Vtil.php
INFO - 2024-12-11 08:16:12 --> Config Class Initialized
INFO - 2024-12-11 08:16:12 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:12 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:12 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:12 --> URI Class Initialized
INFO - 2024-12-11 08:16:12 --> Router Class Initialized
INFO - 2024-12-11 08:16:12 --> Output Class Initialized
INFO - 2024-12-11 08:16:12 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:12 --> Input Class Initialized
INFO - 2024-12-11 08:16:12 --> Language Class Initialized
ERROR - 2024-12-11 08:16:12 --> 404 Page Not Found: PUISoNBaEnKphp/index
INFO - 2024-12-11 08:16:22 --> Config Class Initialized
INFO - 2024-12-11 08:16:22 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:22 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:22 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:22 --> URI Class Initialized
INFO - 2024-12-11 08:16:22 --> Router Class Initialized
INFO - 2024-12-11 08:16:22 --> Output Class Initialized
INFO - 2024-12-11 08:16:22 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:22 --> Input Class Initialized
INFO - 2024-12-11 08:16:22 --> Language Class Initialized
ERROR - 2024-12-11 08:16:22 --> 404 Page Not Found: 5Y9iCD6RXVwphp/index
INFO - 2024-12-11 08:16:30 --> Config Class Initialized
INFO - 2024-12-11 08:16:30 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:30 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:30 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:30 --> URI Class Initialized
INFO - 2024-12-11 08:16:30 --> Router Class Initialized
INFO - 2024-12-11 08:16:30 --> Output Class Initialized
INFO - 2024-12-11 08:16:30 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:30 --> Input Class Initialized
INFO - 2024-12-11 08:16:30 --> Language Class Initialized
ERROR - 2024-12-11 08:16:30 --> 404 Page Not Found: Wp-admin/uzOgHSWiJNe.php
INFO - 2024-12-11 08:16:32 --> Config Class Initialized
INFO - 2024-12-11 08:16:32 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:32 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:32 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:32 --> URI Class Initialized
INFO - 2024-12-11 08:16:32 --> Router Class Initialized
INFO - 2024-12-11 08:16:32 --> Output Class Initialized
INFO - 2024-12-11 08:16:32 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:32 --> Input Class Initialized
INFO - 2024-12-11 08:16:32 --> Language Class Initialized
ERROR - 2024-12-11 08:16:32 --> 404 Page Not Found: Wp-admin/n9GwEV6ietu.php
INFO - 2024-12-11 08:16:38 --> Config Class Initialized
INFO - 2024-12-11 08:16:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:38 --> URI Class Initialized
INFO - 2024-12-11 08:16:38 --> Router Class Initialized
INFO - 2024-12-11 08:16:38 --> Output Class Initialized
INFO - 2024-12-11 08:16:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:38 --> Input Class Initialized
INFO - 2024-12-11 08:16:38 --> Language Class Initialized
ERROR - 2024-12-11 08:16:38 --> 404 Page Not Found: Wp-admin/kASWyg28wTQ.php
INFO - 2024-12-11 08:16:38 --> Config Class Initialized
INFO - 2024-12-11 08:16:38 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:38 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:38 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:38 --> URI Class Initialized
INFO - 2024-12-11 08:16:38 --> Router Class Initialized
INFO - 2024-12-11 08:16:38 --> Output Class Initialized
INFO - 2024-12-11 08:16:38 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:38 --> Input Class Initialized
INFO - 2024-12-11 08:16:38 --> Language Class Initialized
ERROR - 2024-12-11 08:16:38 --> 404 Page Not Found: Wp-admin/QFCW7d1yDqo.php
INFO - 2024-12-11 08:16:42 --> Config Class Initialized
INFO - 2024-12-11 08:16:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:42 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:42 --> URI Class Initialized
INFO - 2024-12-11 08:16:42 --> Router Class Initialized
INFO - 2024-12-11 08:16:42 --> Output Class Initialized
INFO - 2024-12-11 08:16:42 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:42 --> Input Class Initialized
INFO - 2024-12-11 08:16:42 --> Language Class Initialized
ERROR - 2024-12-11 08:16:42 --> 404 Page Not Found: Wp-admin/vHTPBC6cyoL.php
INFO - 2024-12-11 08:16:44 --> Config Class Initialized
INFO - 2024-12-11 08:16:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:44 --> URI Class Initialized
INFO - 2024-12-11 08:16:44 --> Router Class Initialized
INFO - 2024-12-11 08:16:44 --> Output Class Initialized
INFO - 2024-12-11 08:16:44 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:44 --> Input Class Initialized
INFO - 2024-12-11 08:16:44 --> Language Class Initialized
ERROR - 2024-12-11 08:16:44 --> 404 Page Not Found: Wp-admin/uxFcqhjIpzs.php
INFO - 2024-12-11 08:16:44 --> Config Class Initialized
INFO - 2024-12-11 08:16:44 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:44 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:44 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:44 --> URI Class Initialized
INFO - 2024-12-11 08:16:45 --> Router Class Initialized
INFO - 2024-12-11 08:16:45 --> Output Class Initialized
INFO - 2024-12-11 08:16:45 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:45 --> Input Class Initialized
INFO - 2024-12-11 08:16:45 --> Language Class Initialized
ERROR - 2024-12-11 08:16:45 --> 404 Page Not Found: Wp-admin/javQryPZoK8.php
INFO - 2024-12-11 08:16:48 --> Config Class Initialized
INFO - 2024-12-11 08:16:48 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:48 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:48 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:48 --> URI Class Initialized
INFO - 2024-12-11 08:16:48 --> Router Class Initialized
INFO - 2024-12-11 08:16:48 --> Output Class Initialized
INFO - 2024-12-11 08:16:48 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:48 --> Input Class Initialized
INFO - 2024-12-11 08:16:48 --> Language Class Initialized
ERROR - 2024-12-11 08:16:48 --> 404 Page Not Found: Wp-admin/wBq8oXvZr4g.php
INFO - 2024-12-11 08:16:51 --> Config Class Initialized
INFO - 2024-12-11 08:16:51 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:51 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:51 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:51 --> URI Class Initialized
INFO - 2024-12-11 08:16:51 --> Router Class Initialized
INFO - 2024-12-11 08:16:51 --> Output Class Initialized
INFO - 2024-12-11 08:16:51 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:51 --> Input Class Initialized
INFO - 2024-12-11 08:16:51 --> Language Class Initialized
ERROR - 2024-12-11 08:16:51 --> 404 Page Not Found: Hp6TZkc7jsIphp/index
INFO - 2024-12-11 08:16:52 --> Config Class Initialized
INFO - 2024-12-11 08:16:52 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:52 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:52 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:52 --> URI Class Initialized
INFO - 2024-12-11 08:16:52 --> Router Class Initialized
INFO - 2024-12-11 08:16:52 --> Output Class Initialized
INFO - 2024-12-11 08:16:52 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:52 --> Input Class Initialized
INFO - 2024-12-11 08:16:52 --> Language Class Initialized
ERROR - 2024-12-11 08:16:52 --> 404 Page Not Found: Wp-admin/AQ3ZDkzG7Ku.php
INFO - 2024-12-11 08:16:53 --> Config Class Initialized
INFO - 2024-12-11 08:16:53 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:53 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:53 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:53 --> URI Class Initialized
INFO - 2024-12-11 08:16:53 --> Router Class Initialized
INFO - 2024-12-11 08:16:53 --> Output Class Initialized
INFO - 2024-12-11 08:16:53 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:53 --> Input Class Initialized
INFO - 2024-12-11 08:16:53 --> Language Class Initialized
ERROR - 2024-12-11 08:16:53 --> 404 Page Not Found: MgaGjyeHJSDphp/index
INFO - 2024-12-11 08:16:55 --> Config Class Initialized
INFO - 2024-12-11 08:16:55 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:16:55 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:16:55 --> Utf8 Class Initialized
INFO - 2024-12-11 08:16:55 --> URI Class Initialized
INFO - 2024-12-11 08:16:55 --> Router Class Initialized
INFO - 2024-12-11 08:16:55 --> Output Class Initialized
INFO - 2024-12-11 08:16:55 --> Security Class Initialized
DEBUG - 2024-12-11 08:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:16:55 --> Input Class Initialized
INFO - 2024-12-11 08:16:55 --> Language Class Initialized
ERROR - 2024-12-11 08:16:55 --> 404 Page Not Found: VnjNzE7DFQOphp/index
INFO - 2024-12-11 08:17:01 --> Config Class Initialized
INFO - 2024-12-11 08:17:01 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:01 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:01 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:01 --> URI Class Initialized
INFO - 2024-12-11 08:17:01 --> Router Class Initialized
INFO - 2024-12-11 08:17:01 --> Output Class Initialized
INFO - 2024-12-11 08:17:01 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:01 --> Input Class Initialized
INFO - 2024-12-11 08:17:01 --> Language Class Initialized
ERROR - 2024-12-11 08:17:01 --> 404 Page Not Found: FDWm7uVaxT3php/index
INFO - 2024-12-11 08:17:02 --> Config Class Initialized
INFO - 2024-12-11 08:17:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:02 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:02 --> URI Class Initialized
INFO - 2024-12-11 08:17:02 --> Router Class Initialized
INFO - 2024-12-11 08:17:02 --> Output Class Initialized
INFO - 2024-12-11 08:17:02 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:02 --> Input Class Initialized
INFO - 2024-12-11 08:17:02 --> Language Class Initialized
ERROR - 2024-12-11 08:17:02 --> 404 Page Not Found: Wp-admin/DPzMq9R7KAL.php
INFO - 2024-12-11 08:17:05 --> Config Class Initialized
INFO - 2024-12-11 08:17:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:05 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:05 --> URI Class Initialized
INFO - 2024-12-11 08:17:05 --> Router Class Initialized
INFO - 2024-12-11 08:17:05 --> Output Class Initialized
INFO - 2024-12-11 08:17:05 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:05 --> Input Class Initialized
INFO - 2024-12-11 08:17:05 --> Language Class Initialized
ERROR - 2024-12-11 08:17:05 --> 404 Page Not Found: P9BGrEMH2TWphp/index
INFO - 2024-12-11 08:17:06 --> Config Class Initialized
INFO - 2024-12-11 08:17:06 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:06 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:06 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:06 --> URI Class Initialized
INFO - 2024-12-11 08:17:06 --> Router Class Initialized
INFO - 2024-12-11 08:17:06 --> Output Class Initialized
INFO - 2024-12-11 08:17:06 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:06 --> Input Class Initialized
INFO - 2024-12-11 08:17:06 --> Language Class Initialized
ERROR - 2024-12-11 08:17:06 --> 404 Page Not Found: Wp-admin/Lmt9syzj4Sp.php
INFO - 2024-12-11 08:17:11 --> Config Class Initialized
INFO - 2024-12-11 08:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:11 --> URI Class Initialized
INFO - 2024-12-11 08:17:11 --> Router Class Initialized
INFO - 2024-12-11 08:17:11 --> Output Class Initialized
INFO - 2024-12-11 08:17:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:11 --> Input Class Initialized
INFO - 2024-12-11 08:17:11 --> Language Class Initialized
ERROR - 2024-12-11 08:17:11 --> 404 Page Not Found: Wp-admin/3uLQjF76CJx.php
INFO - 2024-12-11 08:17:11 --> Config Class Initialized
INFO - 2024-12-11 08:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:11 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:11 --> URI Class Initialized
INFO - 2024-12-11 08:17:11 --> Router Class Initialized
INFO - 2024-12-11 08:17:11 --> Output Class Initialized
INFO - 2024-12-11 08:17:11 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:11 --> Input Class Initialized
INFO - 2024-12-11 08:17:11 --> Language Class Initialized
ERROR - 2024-12-11 08:17:11 --> 404 Page Not Found: PiRSCMUth2qphp/index
INFO - 2024-12-11 08:17:13 --> Config Class Initialized
INFO - 2024-12-11 08:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:13 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:13 --> URI Class Initialized
INFO - 2024-12-11 08:17:13 --> Router Class Initialized
INFO - 2024-12-11 08:17:13 --> Output Class Initialized
INFO - 2024-12-11 08:17:13 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:13 --> Input Class Initialized
INFO - 2024-12-11 08:17:13 --> Language Class Initialized
ERROR - 2024-12-11 08:17:13 --> 404 Page Not Found: Wp-admin/R6giuh4FSMN.php
INFO - 2024-12-11 08:17:14 --> Config Class Initialized
INFO - 2024-12-11 08:17:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:14 --> URI Class Initialized
INFO - 2024-12-11 08:17:14 --> Router Class Initialized
INFO - 2024-12-11 08:17:14 --> Output Class Initialized
INFO - 2024-12-11 08:17:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:14 --> Input Class Initialized
INFO - 2024-12-11 08:17:14 --> Language Class Initialized
ERROR - 2024-12-11 08:17:14 --> 404 Page Not Found: Wp-admin/Er6huC3n5BU.php
INFO - 2024-12-11 08:17:14 --> Config Class Initialized
INFO - 2024-12-11 08:17:14 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:14 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:14 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:14 --> URI Class Initialized
INFO - 2024-12-11 08:17:14 --> Router Class Initialized
INFO - 2024-12-11 08:17:14 --> Output Class Initialized
INFO - 2024-12-11 08:17:14 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:14 --> Input Class Initialized
INFO - 2024-12-11 08:17:14 --> Language Class Initialized
ERROR - 2024-12-11 08:17:14 --> 404 Page Not Found: JUYDtoWzfLrphp/index
INFO - 2024-12-11 08:17:15 --> Config Class Initialized
INFO - 2024-12-11 08:17:15 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:15 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:15 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:15 --> URI Class Initialized
INFO - 2024-12-11 08:17:15 --> Router Class Initialized
INFO - 2024-12-11 08:17:15 --> Output Class Initialized
INFO - 2024-12-11 08:17:15 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:15 --> Input Class Initialized
INFO - 2024-12-11 08:17:15 --> Language Class Initialized
ERROR - 2024-12-11 08:17:15 --> 404 Page Not Found: WefEZ3MrDipphp/index
INFO - 2024-12-11 08:17:18 --> Config Class Initialized
INFO - 2024-12-11 08:17:18 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:18 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:18 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:18 --> URI Class Initialized
INFO - 2024-12-11 08:17:18 --> Router Class Initialized
INFO - 2024-12-11 08:17:18 --> Output Class Initialized
INFO - 2024-12-11 08:17:18 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:18 --> Input Class Initialized
INFO - 2024-12-11 08:17:18 --> Language Class Initialized
ERROR - 2024-12-11 08:17:18 --> 404 Page Not Found: Wp-admin/X52SkQOCAEb.php
INFO - 2024-12-11 08:17:21 --> Config Class Initialized
INFO - 2024-12-11 08:17:21 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:21 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:21 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:21 --> URI Class Initialized
INFO - 2024-12-11 08:17:21 --> Router Class Initialized
INFO - 2024-12-11 08:17:21 --> Output Class Initialized
INFO - 2024-12-11 08:17:21 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:21 --> Input Class Initialized
INFO - 2024-12-11 08:17:21 --> Language Class Initialized
ERROR - 2024-12-11 08:17:21 --> 404 Page Not Found: Wp-admin/SLnHOVjUmDB.php
INFO - 2024-12-11 08:17:22 --> Config Class Initialized
INFO - 2024-12-11 08:17:22 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:22 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:22 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:22 --> URI Class Initialized
INFO - 2024-12-11 08:17:22 --> Router Class Initialized
INFO - 2024-12-11 08:17:22 --> Output Class Initialized
INFO - 2024-12-11 08:17:22 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:22 --> Input Class Initialized
INFO - 2024-12-11 08:17:22 --> Language Class Initialized
ERROR - 2024-12-11 08:17:22 --> 404 Page Not Found: Wp-admin/xBXtAoNv7G1.php
INFO - 2024-12-11 08:17:23 --> Config Class Initialized
INFO - 2024-12-11 08:17:23 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:23 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:23 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:23 --> URI Class Initialized
INFO - 2024-12-11 08:17:23 --> Router Class Initialized
INFO - 2024-12-11 08:17:23 --> Output Class Initialized
INFO - 2024-12-11 08:17:23 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:23 --> Input Class Initialized
INFO - 2024-12-11 08:17:23 --> Language Class Initialized
ERROR - 2024-12-11 08:17:23 --> 404 Page Not Found: Wp-admin/5t6rFPxbInQ.php
INFO - 2024-12-11 08:17:27 --> Config Class Initialized
INFO - 2024-12-11 08:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:27 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:27 --> URI Class Initialized
INFO - 2024-12-11 08:17:27 --> Router Class Initialized
INFO - 2024-12-11 08:17:27 --> Output Class Initialized
INFO - 2024-12-11 08:17:27 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:27 --> Input Class Initialized
INFO - 2024-12-11 08:17:27 --> Language Class Initialized
ERROR - 2024-12-11 08:17:27 --> 404 Page Not Found: Wp-admin/PoEYHGqahiv.php
INFO - 2024-12-11 08:17:28 --> Config Class Initialized
INFO - 2024-12-11 08:17:28 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:28 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:28 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:28 --> URI Class Initialized
INFO - 2024-12-11 08:17:28 --> Router Class Initialized
INFO - 2024-12-11 08:17:28 --> Output Class Initialized
INFO - 2024-12-11 08:17:28 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:28 --> Input Class Initialized
INFO - 2024-12-11 08:17:28 --> Language Class Initialized
ERROR - 2024-12-11 08:17:28 --> 404 Page Not Found: 3WicLqk8Y5Ophp/index
INFO - 2024-12-11 08:17:39 --> Config Class Initialized
INFO - 2024-12-11 08:17:39 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:17:39 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:17:39 --> Utf8 Class Initialized
INFO - 2024-12-11 08:17:39 --> URI Class Initialized
INFO - 2024-12-11 08:17:39 --> Router Class Initialized
INFO - 2024-12-11 08:17:39 --> Output Class Initialized
INFO - 2024-12-11 08:17:39 --> Security Class Initialized
DEBUG - 2024-12-11 08:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:17:39 --> Input Class Initialized
INFO - 2024-12-11 08:17:39 --> Language Class Initialized
ERROR - 2024-12-11 08:17:39 --> 404 Page Not Found: Wp-admin/XDQ2WV5Gztd.php
INFO - 2024-12-11 08:41:37 --> Config Class Initialized
INFO - 2024-12-11 08:41:37 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:41:37 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:41:37 --> Utf8 Class Initialized
INFO - 2024-12-11 08:41:37 --> URI Class Initialized
INFO - 2024-12-11 08:41:37 --> Router Class Initialized
INFO - 2024-12-11 08:41:37 --> Output Class Initialized
INFO - 2024-12-11 08:41:37 --> Security Class Initialized
DEBUG - 2024-12-11 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:41:37 --> Input Class Initialized
INFO - 2024-12-11 08:41:37 --> Language Class Initialized
ERROR - 2024-12-11 08:41:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-11 08:41:40 --> Config Class Initialized
INFO - 2024-12-11 08:41:40 --> Hooks Class Initialized
DEBUG - 2024-12-11 08:41:40 --> UTF-8 Support Enabled
INFO - 2024-12-11 08:41:40 --> Utf8 Class Initialized
INFO - 2024-12-11 08:41:40 --> URI Class Initialized
DEBUG - 2024-12-11 08:41:40 --> No URI present. Default controller set.
INFO - 2024-12-11 08:41:40 --> Router Class Initialized
INFO - 2024-12-11 08:41:40 --> Output Class Initialized
INFO - 2024-12-11 08:41:40 --> Security Class Initialized
DEBUG - 2024-12-11 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 08:41:40 --> Input Class Initialized
INFO - 2024-12-11 08:41:40 --> Language Class Initialized
INFO - 2024-12-11 08:41:40 --> Loader Class Initialized
INFO - 2024-12-11 08:41:40 --> Helper loaded: url_helper
INFO - 2024-12-11 08:41:40 --> Helper loaded: file_helper
INFO - 2024-12-11 08:41:40 --> Helper loaded: security_helper
INFO - 2024-12-11 08:41:40 --> Helper loaded: wpu_helper
INFO - 2024-12-11 08:41:40 --> Database Driver Class Initialized
INFO - 2024-12-11 08:41:41 --> Email Class Initialized
DEBUG - 2024-12-11 08:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 08:41:41 --> Helper loaded: form_helper
INFO - 2024-12-11 08:41:41 --> Form Validation Class Initialized
INFO - 2024-12-11 08:41:41 --> Controller Class Initialized
DEBUG - 2024-12-11 08:41:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 08:41:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 08:41:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 08:41:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 08:41:41 --> Final output sent to browser
DEBUG - 2024-12-11 08:41:41 --> Total execution time: 0.4582
INFO - 2024-12-11 15:23:02 --> Config Class Initialized
INFO - 2024-12-11 15:23:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 15:23:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 15:23:02 --> Utf8 Class Initialized
INFO - 2024-12-11 15:23:02 --> URI Class Initialized
DEBUG - 2024-12-11 15:23:02 --> No URI present. Default controller set.
INFO - 2024-12-11 15:23:02 --> Router Class Initialized
INFO - 2024-12-11 15:23:02 --> Output Class Initialized
INFO - 2024-12-11 15:23:02 --> Security Class Initialized
DEBUG - 2024-12-11 15:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 15:23:02 --> Input Class Initialized
INFO - 2024-12-11 15:23:02 --> Language Class Initialized
INFO - 2024-12-11 15:23:02 --> Loader Class Initialized
INFO - 2024-12-11 15:23:02 --> Helper loaded: url_helper
INFO - 2024-12-11 15:23:02 --> Helper loaded: file_helper
INFO - 2024-12-11 15:23:02 --> Helper loaded: security_helper
INFO - 2024-12-11 15:23:02 --> Helper loaded: wpu_helper
INFO - 2024-12-11 15:23:02 --> Database Driver Class Initialized
INFO - 2024-12-11 15:23:02 --> Email Class Initialized
DEBUG - 2024-12-11 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 15:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 15:23:02 --> Helper loaded: form_helper
INFO - 2024-12-11 15:23:02 --> Form Validation Class Initialized
INFO - 2024-12-11 15:23:02 --> Controller Class Initialized
DEBUG - 2024-12-11 15:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 15:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 15:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 15:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 15:23:02 --> Final output sent to browser
DEBUG - 2024-12-11 15:23:02 --> Total execution time: 0.4631
INFO - 2024-12-11 16:03:58 --> Config Class Initialized
INFO - 2024-12-11 16:03:58 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:03:58 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:03:58 --> Utf8 Class Initialized
INFO - 2024-12-11 16:03:58 --> URI Class Initialized
INFO - 2024-12-11 16:03:58 --> Router Class Initialized
INFO - 2024-12-11 16:03:58 --> Output Class Initialized
INFO - 2024-12-11 16:03:58 --> Security Class Initialized
DEBUG - 2024-12-11 16:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:03:58 --> Input Class Initialized
INFO - 2024-12-11 16:03:58 --> Language Class Initialized
ERROR - 2024-12-11 16:03:58 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-11 16:03:59 --> Config Class Initialized
INFO - 2024-12-11 16:03:59 --> Hooks Class Initialized
DEBUG - 2024-12-11 16:03:59 --> UTF-8 Support Enabled
INFO - 2024-12-11 16:03:59 --> Utf8 Class Initialized
INFO - 2024-12-11 16:03:59 --> URI Class Initialized
DEBUG - 2024-12-11 16:03:59 --> No URI present. Default controller set.
INFO - 2024-12-11 16:03:59 --> Router Class Initialized
INFO - 2024-12-11 16:03:59 --> Output Class Initialized
INFO - 2024-12-11 16:03:59 --> Security Class Initialized
DEBUG - 2024-12-11 16:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 16:03:59 --> Input Class Initialized
INFO - 2024-12-11 16:03:59 --> Language Class Initialized
INFO - 2024-12-11 16:03:59 --> Loader Class Initialized
INFO - 2024-12-11 16:03:59 --> Helper loaded: url_helper
INFO - 2024-12-11 16:03:59 --> Helper loaded: file_helper
INFO - 2024-12-11 16:03:59 --> Helper loaded: security_helper
INFO - 2024-12-11 16:03:59 --> Helper loaded: wpu_helper
INFO - 2024-12-11 16:03:59 --> Database Driver Class Initialized
INFO - 2024-12-11 16:03:59 --> Email Class Initialized
DEBUG - 2024-12-11 16:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 16:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 16:03:59 --> Helper loaded: form_helper
INFO - 2024-12-11 16:03:59 --> Form Validation Class Initialized
INFO - 2024-12-11 16:03:59 --> Controller Class Initialized
DEBUG - 2024-12-11 16:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 16:03:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 16:03:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 16:03:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 16:03:59 --> Final output sent to browser
DEBUG - 2024-12-11 16:03:59 --> Total execution time: 0.4124
INFO - 2024-12-11 20:36:02 --> Config Class Initialized
INFO - 2024-12-11 20:36:02 --> Hooks Class Initialized
DEBUG - 2024-12-11 20:36:02 --> UTF-8 Support Enabled
INFO - 2024-12-11 20:36:02 --> Utf8 Class Initialized
INFO - 2024-12-11 20:36:02 --> URI Class Initialized
DEBUG - 2024-12-11 20:36:02 --> No URI present. Default controller set.
INFO - 2024-12-11 20:36:02 --> Router Class Initialized
INFO - 2024-12-11 20:36:02 --> Output Class Initialized
INFO - 2024-12-11 20:36:02 --> Security Class Initialized
DEBUG - 2024-12-11 20:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 20:36:02 --> Input Class Initialized
INFO - 2024-12-11 20:36:02 --> Language Class Initialized
INFO - 2024-12-11 20:36:02 --> Loader Class Initialized
INFO - 2024-12-11 20:36:02 --> Helper loaded: url_helper
INFO - 2024-12-11 20:36:02 --> Helper loaded: file_helper
INFO - 2024-12-11 20:36:02 --> Helper loaded: security_helper
INFO - 2024-12-11 20:36:02 --> Helper loaded: wpu_helper
INFO - 2024-12-11 20:36:02 --> Database Driver Class Initialized
INFO - 2024-12-11 20:36:02 --> Email Class Initialized
DEBUG - 2024-12-11 20:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 20:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 20:36:02 --> Helper loaded: form_helper
INFO - 2024-12-11 20:36:02 --> Form Validation Class Initialized
INFO - 2024-12-11 20:36:02 --> Controller Class Initialized
DEBUG - 2024-12-11 20:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 20:36:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 20:36:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 20:36:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 20:36:02 --> Final output sent to browser
DEBUG - 2024-12-11 20:36:02 --> Total execution time: 0.4193
INFO - 2024-12-11 20:36:04 --> Config Class Initialized
INFO - 2024-12-11 20:36:04 --> Hooks Class Initialized
DEBUG - 2024-12-11 20:36:04 --> UTF-8 Support Enabled
INFO - 2024-12-11 20:36:04 --> Utf8 Class Initialized
INFO - 2024-12-11 20:36:04 --> URI Class Initialized
DEBUG - 2024-12-11 20:36:04 --> No URI present. Default controller set.
INFO - 2024-12-11 20:36:04 --> Router Class Initialized
INFO - 2024-12-11 20:36:04 --> Output Class Initialized
INFO - 2024-12-11 20:36:04 --> Security Class Initialized
DEBUG - 2024-12-11 20:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 20:36:04 --> Input Class Initialized
INFO - 2024-12-11 20:36:04 --> Language Class Initialized
INFO - 2024-12-11 20:36:04 --> Loader Class Initialized
INFO - 2024-12-11 20:36:04 --> Helper loaded: url_helper
INFO - 2024-12-11 20:36:04 --> Helper loaded: file_helper
INFO - 2024-12-11 20:36:04 --> Helper loaded: security_helper
INFO - 2024-12-11 20:36:04 --> Helper loaded: wpu_helper
INFO - 2024-12-11 20:36:04 --> Database Driver Class Initialized
INFO - 2024-12-11 20:36:04 --> Email Class Initialized
DEBUG - 2024-12-11 20:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 20:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 20:36:04 --> Helper loaded: form_helper
INFO - 2024-12-11 20:36:04 --> Form Validation Class Initialized
INFO - 2024-12-11 20:36:04 --> Controller Class Initialized
DEBUG - 2024-12-11 20:36:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 20:36:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 20:36:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 20:36:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 20:36:04 --> Final output sent to browser
DEBUG - 2024-12-11 20:36:04 --> Total execution time: 0.4346
INFO - 2024-12-11 20:36:05 --> Config Class Initialized
INFO - 2024-12-11 20:36:05 --> Hooks Class Initialized
DEBUG - 2024-12-11 20:36:05 --> UTF-8 Support Enabled
INFO - 2024-12-11 20:36:05 --> Utf8 Class Initialized
INFO - 2024-12-11 20:36:05 --> URI Class Initialized
DEBUG - 2024-12-11 20:36:05 --> No URI present. Default controller set.
INFO - 2024-12-11 20:36:05 --> Router Class Initialized
INFO - 2024-12-11 20:36:05 --> Output Class Initialized
INFO - 2024-12-11 20:36:05 --> Security Class Initialized
DEBUG - 2024-12-11 20:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 20:36:05 --> Input Class Initialized
INFO - 2024-12-11 20:36:05 --> Language Class Initialized
INFO - 2024-12-11 20:36:05 --> Loader Class Initialized
INFO - 2024-12-11 20:36:05 --> Helper loaded: url_helper
INFO - 2024-12-11 20:36:05 --> Helper loaded: file_helper
INFO - 2024-12-11 20:36:05 --> Helper loaded: security_helper
INFO - 2024-12-11 20:36:05 --> Helper loaded: wpu_helper
INFO - 2024-12-11 20:36:05 --> Database Driver Class Initialized
INFO - 2024-12-11 20:36:06 --> Email Class Initialized
DEBUG - 2024-12-11 20:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-11 20:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 20:36:06 --> Helper loaded: form_helper
INFO - 2024-12-11 20:36:06 --> Form Validation Class Initialized
INFO - 2024-12-11 20:36:06 --> Controller Class Initialized
DEBUG - 2024-12-11 20:36:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-11 20:36:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-11 20:36:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-11 20:36:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-11 20:36:06 --> Final output sent to browser
DEBUG - 2024-12-11 20:36:06 --> Total execution time: 0.4083
