<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-01 23:53:40 --> Config Class Initialized
INFO - 2024-10-01 23:53:40 --> Hooks Class Initialized
INFO - 2024-10-01 23:53:40 --> Config Class Initialized
INFO - 2024-10-01 23:53:40 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:40 --> Utf8 Class Initialized
DEBUG - 2024-10-01 23:53:40 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:40 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:40 --> URI Class Initialized
INFO - 2024-10-01 23:53:40 --> URI Class Initialized
DEBUG - 2024-10-01 23:53:40 --> No URI present. Default controller set.
DEBUG - 2024-10-01 23:53:40 --> No URI present. Default controller set.
INFO - 2024-10-01 23:53:40 --> Router Class Initialized
INFO - 2024-10-01 23:53:40 --> Router Class Initialized
INFO - 2024-10-01 23:53:40 --> Output Class Initialized
INFO - 2024-10-01 23:53:40 --> Output Class Initialized
INFO - 2024-10-01 23:53:40 --> Security Class Initialized
DEBUG - 2024-10-01 23:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:53:40 --> Security Class Initialized
INFO - 2024-10-01 23:53:40 --> Input Class Initialized
INFO - 2024-10-01 23:53:40 --> Language Class Initialized
DEBUG - 2024-10-01 23:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:53:40 --> Input Class Initialized
INFO - 2024-10-01 23:53:40 --> Language Class Initialized
INFO - 2024-10-01 23:53:40 --> Loader Class Initialized
INFO - 2024-10-01 23:53:40 --> Helper loaded: url_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: file_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: security_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:53:40 --> Loader Class Initialized
INFO - 2024-10-01 23:53:40 --> Helper loaded: url_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: file_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: security_helper
INFO - 2024-10-01 23:53:40 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:53:40 --> Database Driver Class Initialized
INFO - 2024-10-01 23:53:40 --> Database Driver Class Initialized
INFO - 2024-10-01 23:53:41 --> Email Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:53:41 --> Helper loaded: form_helper
INFO - 2024-10-01 23:53:41 --> Form Validation Class Initialized
INFO - 2024-10-01 23:53:41 --> Controller Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:53:41 --> Final output sent to browser
DEBUG - 2024-10-01 23:53:41 --> Total execution time: 0.2119
INFO - 2024-10-01 23:53:41 --> Email Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:53:41 --> Helper loaded: form_helper
INFO - 2024-10-01 23:53:41 --> Form Validation Class Initialized
INFO - 2024-10-01 23:53:41 --> Controller Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:53:41 --> Final output sent to browser
DEBUG - 2024-10-01 23:53:41 --> Total execution time: 0.2213
INFO - 2024-10-01 23:53:41 --> Config Class Initialized
INFO - 2024-10-01 23:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:41 --> URI Class Initialized
DEBUG - 2024-10-01 23:53:41 --> No URI present. Default controller set.
INFO - 2024-10-01 23:53:41 --> Router Class Initialized
INFO - 2024-10-01 23:53:41 --> Output Class Initialized
INFO - 2024-10-01 23:53:41 --> Security Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:53:41 --> Input Class Initialized
INFO - 2024-10-01 23:53:41 --> Language Class Initialized
INFO - 2024-10-01 23:53:41 --> Loader Class Initialized
INFO - 2024-10-01 23:53:41 --> Helper loaded: url_helper
INFO - 2024-10-01 23:53:41 --> Helper loaded: file_helper
INFO - 2024-10-01 23:53:41 --> Helper loaded: security_helper
INFO - 2024-10-01 23:53:41 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:53:41 --> Database Driver Class Initialized
INFO - 2024-10-01 23:53:41 --> Email Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:53:41 --> Helper loaded: form_helper
INFO - 2024-10-01 23:53:41 --> Form Validation Class Initialized
INFO - 2024-10-01 23:53:41 --> Controller Class Initialized
DEBUG - 2024-10-01 23:53:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:53:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:53:41 --> Final output sent to browser
DEBUG - 2024-10-01 23:53:41 --> Total execution time: 0.2203
INFO - 2024-10-01 23:53:41 --> Config Class Initialized
INFO - 2024-10-01 23:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:41 --> Config Class Initialized
INFO - 2024-10-01 23:53:41 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:41 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:41 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:42 --> Config Class Initialized
INFO - 2024-10-01 23:53:42 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:42 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:42 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:42 --> URI Class Initialized
INFO - 2024-10-01 23:53:42 --> Router Class Initialized
INFO - 2024-10-01 23:53:42 --> Output Class Initialized
INFO - 2024-10-01 23:53:42 --> Security Class Initialized
DEBUG - 2024-10-01 23:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:53:42 --> Input Class Initialized
INFO - 2024-10-01 23:53:42 --> Language Class Initialized
INFO - 2024-10-01 23:53:42 --> Loader Class Initialized
INFO - 2024-10-01 23:53:42 --> Helper loaded: url_helper
INFO - 2024-10-01 23:53:42 --> Helper loaded: file_helper
INFO - 2024-10-01 23:53:42 --> Helper loaded: security_helper
INFO - 2024-10-01 23:53:42 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:53:42 --> Database Driver Class Initialized
INFO - 2024-10-01 23:53:43 --> Email Class Initialized
DEBUG - 2024-10-01 23:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:53:43 --> Helper loaded: form_helper
INFO - 2024-10-01 23:53:43 --> Form Validation Class Initialized
INFO - 2024-10-01 23:53:43 --> Controller Class Initialized
DEBUG - 2024-10-01 23:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:53:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-01 23:53:43 --> Config Class Initialized
INFO - 2024-10-01 23:53:43 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:53:43 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:53:43 --> Utf8 Class Initialized
INFO - 2024-10-01 23:53:43 --> URI Class Initialized
INFO - 2024-10-01 23:53:43 --> Router Class Initialized
INFO - 2024-10-01 23:53:43 --> Output Class Initialized
INFO - 2024-10-01 23:53:43 --> Security Class Initialized
DEBUG - 2024-10-01 23:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:53:43 --> Input Class Initialized
INFO - 2024-10-01 23:53:43 --> Language Class Initialized
INFO - 2024-10-01 23:53:43 --> Loader Class Initialized
INFO - 2024-10-01 23:53:43 --> Helper loaded: url_helper
INFO - 2024-10-01 23:53:43 --> Helper loaded: file_helper
INFO - 2024-10-01 23:53:43 --> Helper loaded: security_helper
INFO - 2024-10-01 23:53:43 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:53:43 --> Database Driver Class Initialized
INFO - 2024-10-01 23:53:43 --> Email Class Initialized
DEBUG - 2024-10-01 23:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:53:43 --> Helper loaded: form_helper
INFO - 2024-10-01 23:53:43 --> Form Validation Class Initialized
INFO - 2024-10-01 23:53:43 --> Controller Class Initialized
INFO - 2024-10-01 23:53:43 --> Model "Antrol_model" initialized
DEBUG - 2024-10-01 23:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:53:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-01 23:53:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-01 23:53:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-01 23:53:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-01 23:53:44 --> Final output sent to browser
DEBUG - 2024-10-01 23:53:44 --> Total execution time: 0.7948
INFO - 2024-10-01 23:54:04 --> Config Class Initialized
INFO - 2024-10-01 23:54:04 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:54:04 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:54:04 --> Utf8 Class Initialized
INFO - 2024-10-01 23:54:04 --> URI Class Initialized
DEBUG - 2024-10-01 23:54:04 --> No URI present. Default controller set.
INFO - 2024-10-01 23:54:04 --> Router Class Initialized
INFO - 2024-10-01 23:54:04 --> Output Class Initialized
INFO - 2024-10-01 23:54:04 --> Security Class Initialized
DEBUG - 2024-10-01 23:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:54:04 --> Input Class Initialized
INFO - 2024-10-01 23:54:04 --> Language Class Initialized
INFO - 2024-10-01 23:54:04 --> Loader Class Initialized
INFO - 2024-10-01 23:54:04 --> Helper loaded: url_helper
INFO - 2024-10-01 23:54:04 --> Helper loaded: file_helper
INFO - 2024-10-01 23:54:04 --> Helper loaded: security_helper
INFO - 2024-10-01 23:54:04 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:54:04 --> Database Driver Class Initialized
INFO - 2024-10-01 23:54:04 --> Email Class Initialized
DEBUG - 2024-10-01 23:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:54:04 --> Helper loaded: form_helper
INFO - 2024-10-01 23:54:04 --> Form Validation Class Initialized
INFO - 2024-10-01 23:54:04 --> Controller Class Initialized
DEBUG - 2024-10-01 23:54:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:54:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:54:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:54:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:54:04 --> Final output sent to browser
DEBUG - 2024-10-01 23:54:04 --> Total execution time: 0.2320
INFO - 2024-10-01 23:54:08 --> Config Class Initialized
INFO - 2024-10-01 23:54:08 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:54:08 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:54:08 --> Utf8 Class Initialized
INFO - 2024-10-01 23:54:08 --> URI Class Initialized
DEBUG - 2024-10-01 23:54:08 --> No URI present. Default controller set.
INFO - 2024-10-01 23:54:08 --> Router Class Initialized
INFO - 2024-10-01 23:54:08 --> Output Class Initialized
INFO - 2024-10-01 23:54:08 --> Security Class Initialized
DEBUG - 2024-10-01 23:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:54:08 --> Input Class Initialized
INFO - 2024-10-01 23:54:08 --> Language Class Initialized
INFO - 2024-10-01 23:54:08 --> Loader Class Initialized
INFO - 2024-10-01 23:54:08 --> Helper loaded: url_helper
INFO - 2024-10-01 23:54:08 --> Helper loaded: file_helper
INFO - 2024-10-01 23:54:08 --> Helper loaded: security_helper
INFO - 2024-10-01 23:54:08 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:54:08 --> Database Driver Class Initialized
INFO - 2024-10-01 23:54:09 --> Email Class Initialized
DEBUG - 2024-10-01 23:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:54:09 --> Helper loaded: form_helper
INFO - 2024-10-01 23:54:09 --> Form Validation Class Initialized
INFO - 2024-10-01 23:54:09 --> Controller Class Initialized
DEBUG - 2024-10-01 23:54:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:54:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:54:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:54:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:54:09 --> Final output sent to browser
DEBUG - 2024-10-01 23:54:09 --> Total execution time: 0.2313
INFO - 2024-10-01 23:54:28 --> Config Class Initialized
INFO - 2024-10-01 23:54:28 --> Hooks Class Initialized
DEBUG - 2024-10-01 23:54:28 --> UTF-8 Support Enabled
INFO - 2024-10-01 23:54:28 --> Utf8 Class Initialized
INFO - 2024-10-01 23:54:28 --> URI Class Initialized
DEBUG - 2024-10-01 23:54:28 --> No URI present. Default controller set.
INFO - 2024-10-01 23:54:28 --> Router Class Initialized
INFO - 2024-10-01 23:54:28 --> Output Class Initialized
INFO - 2024-10-01 23:54:28 --> Security Class Initialized
DEBUG - 2024-10-01 23:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-01 23:54:28 --> Input Class Initialized
INFO - 2024-10-01 23:54:28 --> Language Class Initialized
INFO - 2024-10-01 23:54:28 --> Loader Class Initialized
INFO - 2024-10-01 23:54:28 --> Helper loaded: url_helper
INFO - 2024-10-01 23:54:28 --> Helper loaded: file_helper
INFO - 2024-10-01 23:54:28 --> Helper loaded: security_helper
INFO - 2024-10-01 23:54:28 --> Helper loaded: wpu_helper
INFO - 2024-10-01 23:54:28 --> Database Driver Class Initialized
INFO - 2024-10-01 23:54:29 --> Email Class Initialized
DEBUG - 2024-10-01 23:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-01 23:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-01 23:54:29 --> Helper loaded: form_helper
INFO - 2024-10-01 23:54:29 --> Form Validation Class Initialized
INFO - 2024-10-01 23:54:29 --> Controller Class Initialized
DEBUG - 2024-10-01 23:54:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-01 23:54:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-01 23:54:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-01 23:54:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-01 23:54:29 --> Final output sent to browser
DEBUG - 2024-10-01 23:54:29 --> Total execution time: 0.2490
