<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-14 02:22:48 --> Config Class Initialized
INFO - 2024-09-14 02:22:48 --> Hooks Class Initialized
DEBUG - 2024-09-14 02:22:48 --> UTF-8 Support Enabled
INFO - 2024-09-14 02:22:48 --> Utf8 Class Initialized
INFO - 2024-09-14 02:22:48 --> URI Class Initialized
DEBUG - 2024-09-14 02:22:48 --> No URI present. Default controller set.
INFO - 2024-09-14 02:22:48 --> Router Class Initialized
INFO - 2024-09-14 02:22:48 --> Output Class Initialized
INFO - 2024-09-14 02:22:48 --> Security Class Initialized
DEBUG - 2024-09-14 02:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 02:22:48 --> Input Class Initialized
INFO - 2024-09-14 02:22:48 --> Language Class Initialized
INFO - 2024-09-14 02:22:48 --> Loader Class Initialized
INFO - 2024-09-14 02:22:48 --> Helper loaded: url_helper
INFO - 2024-09-14 02:22:48 --> Helper loaded: file_helper
INFO - 2024-09-14 02:22:48 --> Helper loaded: security_helper
INFO - 2024-09-14 02:22:48 --> Helper loaded: wpu_helper
INFO - 2024-09-14 02:22:48 --> Database Driver Class Initialized
INFO - 2024-09-14 02:22:49 --> Email Class Initialized
DEBUG - 2024-09-14 02:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 02:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 02:22:49 --> Helper loaded: form_helper
INFO - 2024-09-14 02:22:49 --> Form Validation Class Initialized
INFO - 2024-09-14 02:22:49 --> Controller Class Initialized
DEBUG - 2024-09-14 02:22:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 02:22:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 02:22:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 02:22:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 02:22:49 --> Final output sent to browser
DEBUG - 2024-09-14 02:22:49 --> Total execution time: 0.5797
INFO - 2024-09-14 05:02:32 --> Config Class Initialized
INFO - 2024-09-14 05:02:32 --> Hooks Class Initialized
DEBUG - 2024-09-14 05:02:32 --> UTF-8 Support Enabled
INFO - 2024-09-14 05:02:32 --> Utf8 Class Initialized
INFO - 2024-09-14 05:02:32 --> Config Class Initialized
INFO - 2024-09-14 05:02:32 --> Hooks Class Initialized
INFO - 2024-09-14 05:02:32 --> URI Class Initialized
DEBUG - 2024-09-14 05:02:32 --> No URI present. Default controller set.
INFO - 2024-09-14 05:02:32 --> Router Class Initialized
DEBUG - 2024-09-14 05:02:32 --> UTF-8 Support Enabled
INFO - 2024-09-14 05:02:32 --> Utf8 Class Initialized
INFO - 2024-09-14 05:02:32 --> URI Class Initialized
INFO - 2024-09-14 05:02:32 --> Output Class Initialized
DEBUG - 2024-09-14 05:02:32 --> No URI present. Default controller set.
INFO - 2024-09-14 05:02:32 --> Router Class Initialized
INFO - 2024-09-14 05:02:32 --> Security Class Initialized
INFO - 2024-09-14 05:02:32 --> Output Class Initialized
DEBUG - 2024-09-14 05:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 05:02:32 --> Input Class Initialized
INFO - 2024-09-14 05:02:32 --> Language Class Initialized
INFO - 2024-09-14 05:02:32 --> Security Class Initialized
DEBUG - 2024-09-14 05:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 05:02:32 --> Input Class Initialized
INFO - 2024-09-14 05:02:32 --> Loader Class Initialized
INFO - 2024-09-14 05:02:32 --> Language Class Initialized
INFO - 2024-09-14 05:02:32 --> Helper loaded: url_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: file_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: security_helper
INFO - 2024-09-14 05:02:32 --> Loader Class Initialized
INFO - 2024-09-14 05:02:32 --> Helper loaded: wpu_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: url_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: file_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: security_helper
INFO - 2024-09-14 05:02:32 --> Helper loaded: wpu_helper
INFO - 2024-09-14 05:02:32 --> Database Driver Class Initialized
INFO - 2024-09-14 05:02:32 --> Database Driver Class Initialized
INFO - 2024-09-14 05:02:32 --> Email Class Initialized
DEBUG - 2024-09-14 05:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 05:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 05:02:32 --> Helper loaded: form_helper
INFO - 2024-09-14 05:02:32 --> Form Validation Class Initialized
INFO - 2024-09-14 05:02:32 --> Controller Class Initialized
DEBUG - 2024-09-14 05:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 05:02:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 05:02:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 05:02:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 05:02:32 --> Final output sent to browser
DEBUG - 2024-09-14 05:02:32 --> Total execution time: 0.2093
INFO - 2024-09-14 05:02:33 --> Email Class Initialized
DEBUG - 2024-09-14 05:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 05:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 05:02:33 --> Helper loaded: form_helper
INFO - 2024-09-14 05:02:33 --> Form Validation Class Initialized
INFO - 2024-09-14 05:02:33 --> Controller Class Initialized
DEBUG - 2024-09-14 05:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 05:02:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 05:02:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 05:02:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 05:02:33 --> Final output sent to browser
DEBUG - 2024-09-14 05:02:33 --> Total execution time: 1.4747
INFO - 2024-09-14 05:07:39 --> Config Class Initialized
INFO - 2024-09-14 05:07:39 --> Hooks Class Initialized
DEBUG - 2024-09-14 05:07:39 --> UTF-8 Support Enabled
INFO - 2024-09-14 05:07:39 --> Utf8 Class Initialized
INFO - 2024-09-14 05:07:39 --> URI Class Initialized
DEBUG - 2024-09-14 05:07:39 --> No URI present. Default controller set.
INFO - 2024-09-14 05:07:39 --> Router Class Initialized
INFO - 2024-09-14 05:07:39 --> Output Class Initialized
INFO - 2024-09-14 05:07:39 --> Security Class Initialized
DEBUG - 2024-09-14 05:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 05:07:39 --> Input Class Initialized
INFO - 2024-09-14 05:07:39 --> Language Class Initialized
INFO - 2024-09-14 05:07:39 --> Loader Class Initialized
INFO - 2024-09-14 05:07:39 --> Helper loaded: url_helper
INFO - 2024-09-14 05:07:39 --> Helper loaded: file_helper
INFO - 2024-09-14 05:07:39 --> Helper loaded: security_helper
INFO - 2024-09-14 05:07:39 --> Helper loaded: wpu_helper
INFO - 2024-09-14 05:07:39 --> Database Driver Class Initialized
INFO - 2024-09-14 05:07:39 --> Email Class Initialized
DEBUG - 2024-09-14 05:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 05:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 05:07:39 --> Helper loaded: form_helper
INFO - 2024-09-14 05:07:39 --> Form Validation Class Initialized
INFO - 2024-09-14 05:07:39 --> Controller Class Initialized
DEBUG - 2024-09-14 05:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 05:07:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 05:07:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 05:07:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 05:07:39 --> Final output sent to browser
DEBUG - 2024-09-14 05:07:39 --> Total execution time: 0.2082
INFO - 2024-09-14 07:34:49 --> Config Class Initialized
INFO - 2024-09-14 07:34:49 --> Hooks Class Initialized
DEBUG - 2024-09-14 07:34:49 --> UTF-8 Support Enabled
INFO - 2024-09-14 07:34:49 --> Utf8 Class Initialized
INFO - 2024-09-14 07:34:49 --> URI Class Initialized
DEBUG - 2024-09-14 07:34:49 --> No URI present. Default controller set.
INFO - 2024-09-14 07:34:49 --> Router Class Initialized
INFO - 2024-09-14 07:34:49 --> Output Class Initialized
INFO - 2024-09-14 07:34:49 --> Security Class Initialized
DEBUG - 2024-09-14 07:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 07:34:49 --> Input Class Initialized
INFO - 2024-09-14 07:34:49 --> Language Class Initialized
INFO - 2024-09-14 07:34:49 --> Loader Class Initialized
INFO - 2024-09-14 07:34:49 --> Helper loaded: url_helper
INFO - 2024-09-14 07:34:49 --> Helper loaded: file_helper
INFO - 2024-09-14 07:34:49 --> Helper loaded: security_helper
INFO - 2024-09-14 07:34:49 --> Helper loaded: wpu_helper
INFO - 2024-09-14 07:34:49 --> Database Driver Class Initialized
INFO - 2024-09-14 07:34:50 --> Email Class Initialized
DEBUG - 2024-09-14 07:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 07:34:50 --> Helper loaded: form_helper
INFO - 2024-09-14 07:34:50 --> Form Validation Class Initialized
INFO - 2024-09-14 07:34:50 --> Controller Class Initialized
DEBUG - 2024-09-14 07:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 07:34:50 --> Final output sent to browser
DEBUG - 2024-09-14 07:34:50 --> Total execution time: 0.2145
INFO - 2024-09-14 07:34:50 --> Config Class Initialized
INFO - 2024-09-14 07:34:50 --> Hooks Class Initialized
DEBUG - 2024-09-14 07:34:50 --> UTF-8 Support Enabled
INFO - 2024-09-14 07:34:50 --> Utf8 Class Initialized
INFO - 2024-09-14 07:34:50 --> URI Class Initialized
DEBUG - 2024-09-14 07:34:50 --> No URI present. Default controller set.
INFO - 2024-09-14 07:34:50 --> Router Class Initialized
INFO - 2024-09-14 07:34:50 --> Output Class Initialized
INFO - 2024-09-14 07:34:50 --> Security Class Initialized
DEBUG - 2024-09-14 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 07:34:50 --> Input Class Initialized
INFO - 2024-09-14 07:34:50 --> Language Class Initialized
INFO - 2024-09-14 07:34:50 --> Loader Class Initialized
INFO - 2024-09-14 07:34:50 --> Helper loaded: url_helper
INFO - 2024-09-14 07:34:50 --> Helper loaded: file_helper
INFO - 2024-09-14 07:34:50 --> Helper loaded: security_helper
INFO - 2024-09-14 07:34:50 --> Helper loaded: wpu_helper
INFO - 2024-09-14 07:34:50 --> Database Driver Class Initialized
INFO - 2024-09-14 07:34:50 --> Email Class Initialized
DEBUG - 2024-09-14 07:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 07:34:50 --> Helper loaded: form_helper
INFO - 2024-09-14 07:34:50 --> Form Validation Class Initialized
INFO - 2024-09-14 07:34:50 --> Controller Class Initialized
DEBUG - 2024-09-14 07:34:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 07:34:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 07:34:50 --> Final output sent to browser
DEBUG - 2024-09-14 07:34:50 --> Total execution time: 0.2105
INFO - 2024-09-14 12:31:18 --> Config Class Initialized
INFO - 2024-09-14 12:31:18 --> Hooks Class Initialized
DEBUG - 2024-09-14 12:31:18 --> UTF-8 Support Enabled
INFO - 2024-09-14 12:31:18 --> Utf8 Class Initialized
INFO - 2024-09-14 12:31:18 --> URI Class Initialized
DEBUG - 2024-09-14 12:31:18 --> No URI present. Default controller set.
INFO - 2024-09-14 12:31:18 --> Router Class Initialized
INFO - 2024-09-14 12:31:18 --> Output Class Initialized
INFO - 2024-09-14 12:31:18 --> Security Class Initialized
DEBUG - 2024-09-14 12:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 12:31:18 --> Input Class Initialized
INFO - 2024-09-14 12:31:18 --> Language Class Initialized
INFO - 2024-09-14 12:31:18 --> Loader Class Initialized
INFO - 2024-09-14 12:31:18 --> Helper loaded: url_helper
INFO - 2024-09-14 12:31:18 --> Helper loaded: file_helper
INFO - 2024-09-14 12:31:18 --> Helper loaded: security_helper
INFO - 2024-09-14 12:31:18 --> Helper loaded: wpu_helper
INFO - 2024-09-14 12:31:18 --> Database Driver Class Initialized
INFO - 2024-09-14 12:31:19 --> Email Class Initialized
DEBUG - 2024-09-14 12:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 12:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 12:31:19 --> Helper loaded: form_helper
INFO - 2024-09-14 12:31:19 --> Form Validation Class Initialized
INFO - 2024-09-14 12:31:19 --> Controller Class Initialized
DEBUG - 2024-09-14 12:31:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 12:31:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 12:31:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 12:31:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 12:31:19 --> Final output sent to browser
DEBUG - 2024-09-14 12:31:19 --> Total execution time: 0.2161
INFO - 2024-09-14 14:21:10 --> Config Class Initialized
INFO - 2024-09-14 14:21:10 --> Hooks Class Initialized
DEBUG - 2024-09-14 14:21:10 --> UTF-8 Support Enabled
INFO - 2024-09-14 14:21:10 --> Utf8 Class Initialized
INFO - 2024-09-14 14:21:10 --> URI Class Initialized
DEBUG - 2024-09-14 14:21:10 --> No URI present. Default controller set.
INFO - 2024-09-14 14:21:10 --> Router Class Initialized
INFO - 2024-09-14 14:21:10 --> Output Class Initialized
INFO - 2024-09-14 14:21:10 --> Security Class Initialized
DEBUG - 2024-09-14 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 14:21:10 --> Input Class Initialized
INFO - 2024-09-14 14:21:10 --> Language Class Initialized
INFO - 2024-09-14 14:21:10 --> Loader Class Initialized
INFO - 2024-09-14 14:21:10 --> Helper loaded: url_helper
INFO - 2024-09-14 14:21:10 --> Helper loaded: file_helper
INFO - 2024-09-14 14:21:10 --> Helper loaded: security_helper
INFO - 2024-09-14 14:21:10 --> Helper loaded: wpu_helper
INFO - 2024-09-14 14:21:10 --> Database Driver Class Initialized
INFO - 2024-09-14 14:21:11 --> Email Class Initialized
DEBUG - 2024-09-14 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 14:21:11 --> Helper loaded: form_helper
INFO - 2024-09-14 14:21:11 --> Form Validation Class Initialized
INFO - 2024-09-14 14:21:11 --> Controller Class Initialized
DEBUG - 2024-09-14 14:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 14:21:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 14:21:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 14:21:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 14:21:11 --> Final output sent to browser
DEBUG - 2024-09-14 14:21:11 --> Total execution time: 0.2421
INFO - 2024-09-14 18:51:19 --> Config Class Initialized
INFO - 2024-09-14 18:51:19 --> Hooks Class Initialized
DEBUG - 2024-09-14 18:51:19 --> UTF-8 Support Enabled
INFO - 2024-09-14 18:51:19 --> Utf8 Class Initialized
INFO - 2024-09-14 18:51:19 --> URI Class Initialized
DEBUG - 2024-09-14 18:51:19 --> No URI present. Default controller set.
INFO - 2024-09-14 18:51:19 --> Router Class Initialized
INFO - 2024-09-14 18:51:19 --> Output Class Initialized
INFO - 2024-09-14 18:51:19 --> Security Class Initialized
DEBUG - 2024-09-14 18:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 18:51:19 --> Input Class Initialized
INFO - 2024-09-14 18:51:19 --> Language Class Initialized
INFO - 2024-09-14 18:51:19 --> Loader Class Initialized
INFO - 2024-09-14 18:51:19 --> Helper loaded: url_helper
INFO - 2024-09-14 18:51:19 --> Helper loaded: file_helper
INFO - 2024-09-14 18:51:19 --> Helper loaded: security_helper
INFO - 2024-09-14 18:51:19 --> Helper loaded: wpu_helper
INFO - 2024-09-14 18:51:19 --> Database Driver Class Initialized
INFO - 2024-09-14 18:51:19 --> Email Class Initialized
DEBUG - 2024-09-14 18:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 18:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 18:51:19 --> Helper loaded: form_helper
INFO - 2024-09-14 18:51:19 --> Form Validation Class Initialized
INFO - 2024-09-14 18:51:19 --> Controller Class Initialized
DEBUG - 2024-09-14 18:51:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 18:51:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 18:51:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 18:51:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 18:51:19 --> Final output sent to browser
DEBUG - 2024-09-14 18:51:19 --> Total execution time: 0.2206
INFO - 2024-09-14 18:51:57 --> Config Class Initialized
INFO - 2024-09-14 18:51:57 --> Hooks Class Initialized
DEBUG - 2024-09-14 18:51:57 --> UTF-8 Support Enabled
INFO - 2024-09-14 18:51:57 --> Utf8 Class Initialized
INFO - 2024-09-14 18:51:57 --> URI Class Initialized
DEBUG - 2024-09-14 18:51:57 --> No URI present. Default controller set.
INFO - 2024-09-14 18:51:57 --> Router Class Initialized
INFO - 2024-09-14 18:51:57 --> Output Class Initialized
INFO - 2024-09-14 18:51:57 --> Security Class Initialized
DEBUG - 2024-09-14 18:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 18:51:57 --> Input Class Initialized
INFO - 2024-09-14 18:51:57 --> Language Class Initialized
INFO - 2024-09-14 18:51:57 --> Loader Class Initialized
INFO - 2024-09-14 18:51:57 --> Helper loaded: url_helper
INFO - 2024-09-14 18:51:57 --> Helper loaded: file_helper
INFO - 2024-09-14 18:51:57 --> Helper loaded: security_helper
INFO - 2024-09-14 18:51:57 --> Helper loaded: wpu_helper
INFO - 2024-09-14 18:51:57 --> Database Driver Class Initialized
INFO - 2024-09-14 18:51:57 --> Email Class Initialized
DEBUG - 2024-09-14 18:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 18:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 18:51:57 --> Helper loaded: form_helper
INFO - 2024-09-14 18:51:57 --> Form Validation Class Initialized
INFO - 2024-09-14 18:51:57 --> Controller Class Initialized
DEBUG - 2024-09-14 18:51:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 18:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 18:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 18:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 18:51:57 --> Final output sent to browser
DEBUG - 2024-09-14 18:51:57 --> Total execution time: 0.2089
INFO - 2024-09-14 21:47:54 --> Config Class Initialized
INFO - 2024-09-14 21:47:54 --> Hooks Class Initialized
DEBUG - 2024-09-14 21:47:54 --> UTF-8 Support Enabled
INFO - 2024-09-14 21:47:54 --> Utf8 Class Initialized
INFO - 2024-09-14 21:47:54 --> URI Class Initialized
DEBUG - 2024-09-14 21:47:54 --> No URI present. Default controller set.
INFO - 2024-09-14 21:47:54 --> Router Class Initialized
INFO - 2024-09-14 21:47:54 --> Output Class Initialized
INFO - 2024-09-14 21:47:54 --> Security Class Initialized
DEBUG - 2024-09-14 21:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 21:47:54 --> Input Class Initialized
INFO - 2024-09-14 21:47:54 --> Language Class Initialized
INFO - 2024-09-14 21:47:54 --> Loader Class Initialized
INFO - 2024-09-14 21:47:54 --> Helper loaded: url_helper
INFO - 2024-09-14 21:47:54 --> Helper loaded: file_helper
INFO - 2024-09-14 21:47:54 --> Helper loaded: security_helper
INFO - 2024-09-14 21:47:54 --> Helper loaded: wpu_helper
INFO - 2024-09-14 21:47:54 --> Database Driver Class Initialized
INFO - 2024-09-14 21:47:55 --> Email Class Initialized
DEBUG - 2024-09-14 21:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 21:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 21:47:55 --> Helper loaded: form_helper
INFO - 2024-09-14 21:47:55 --> Form Validation Class Initialized
INFO - 2024-09-14 21:47:55 --> Controller Class Initialized
DEBUG - 2024-09-14 21:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 21:47:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 21:47:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 21:47:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 21:47:55 --> Final output sent to browser
DEBUG - 2024-09-14 21:47:55 --> Total execution time: 0.4915
INFO - 2024-09-14 21:47:56 --> Config Class Initialized
INFO - 2024-09-14 21:47:56 --> Hooks Class Initialized
DEBUG - 2024-09-14 21:47:56 --> UTF-8 Support Enabled
INFO - 2024-09-14 21:47:56 --> Utf8 Class Initialized
INFO - 2024-09-14 21:47:56 --> URI Class Initialized
DEBUG - 2024-09-14 21:47:56 --> No URI present. Default controller set.
INFO - 2024-09-14 21:47:56 --> Router Class Initialized
INFO - 2024-09-14 21:47:56 --> Output Class Initialized
INFO - 2024-09-14 21:47:56 --> Security Class Initialized
DEBUG - 2024-09-14 21:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 21:47:56 --> Input Class Initialized
INFO - 2024-09-14 21:47:56 --> Language Class Initialized
INFO - 2024-09-14 21:47:56 --> Loader Class Initialized
INFO - 2024-09-14 21:47:56 --> Helper loaded: url_helper
INFO - 2024-09-14 21:47:56 --> Helper loaded: file_helper
INFO - 2024-09-14 21:47:56 --> Helper loaded: security_helper
INFO - 2024-09-14 21:47:56 --> Helper loaded: wpu_helper
INFO - 2024-09-14 21:47:56 --> Database Driver Class Initialized
INFO - 2024-09-14 21:47:56 --> Email Class Initialized
DEBUG - 2024-09-14 21:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 21:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 21:47:56 --> Helper loaded: form_helper
INFO - 2024-09-14 21:47:56 --> Form Validation Class Initialized
INFO - 2024-09-14 21:47:56 --> Controller Class Initialized
DEBUG - 2024-09-14 21:47:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 21:47:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 21:47:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 21:47:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 21:47:56 --> Final output sent to browser
DEBUG - 2024-09-14 21:47:56 --> Total execution time: 0.4618
INFO - 2024-09-14 21:55:51 --> Config Class Initialized
INFO - 2024-09-14 21:55:51 --> Hooks Class Initialized
DEBUG - 2024-09-14 21:55:51 --> UTF-8 Support Enabled
INFO - 2024-09-14 21:55:51 --> Utf8 Class Initialized
INFO - 2024-09-14 21:55:51 --> URI Class Initialized
DEBUG - 2024-09-14 21:55:51 --> No URI present. Default controller set.
INFO - 2024-09-14 21:55:51 --> Router Class Initialized
INFO - 2024-09-14 21:55:51 --> Output Class Initialized
INFO - 2024-09-14 21:55:51 --> Security Class Initialized
DEBUG - 2024-09-14 21:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 21:55:51 --> Input Class Initialized
INFO - 2024-09-14 21:55:51 --> Language Class Initialized
INFO - 2024-09-14 21:55:51 --> Loader Class Initialized
INFO - 2024-09-14 21:55:51 --> Helper loaded: url_helper
INFO - 2024-09-14 21:55:51 --> Helper loaded: file_helper
INFO - 2024-09-14 21:55:51 --> Helper loaded: security_helper
INFO - 2024-09-14 21:55:51 --> Helper loaded: wpu_helper
INFO - 2024-09-14 21:55:51 --> Database Driver Class Initialized
INFO - 2024-09-14 21:55:51 --> Email Class Initialized
DEBUG - 2024-09-14 21:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 21:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 21:55:51 --> Helper loaded: form_helper
INFO - 2024-09-14 21:55:51 --> Form Validation Class Initialized
INFO - 2024-09-14 21:55:51 --> Controller Class Initialized
DEBUG - 2024-09-14 21:55:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 21:55:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 21:55:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 21:55:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 21:55:51 --> Final output sent to browser
DEBUG - 2024-09-14 21:55:51 --> Total execution time: 0.2093
INFO - 2024-09-14 21:55:52 --> Config Class Initialized
INFO - 2024-09-14 21:55:52 --> Hooks Class Initialized
DEBUG - 2024-09-14 21:55:52 --> UTF-8 Support Enabled
INFO - 2024-09-14 21:55:52 --> Utf8 Class Initialized
INFO - 2024-09-14 21:55:52 --> URI Class Initialized
DEBUG - 2024-09-14 21:55:52 --> No URI present. Default controller set.
INFO - 2024-09-14 21:55:52 --> Router Class Initialized
INFO - 2024-09-14 21:55:52 --> Output Class Initialized
INFO - 2024-09-14 21:55:52 --> Security Class Initialized
DEBUG - 2024-09-14 21:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-14 21:55:52 --> Input Class Initialized
INFO - 2024-09-14 21:55:52 --> Language Class Initialized
INFO - 2024-09-14 21:55:52 --> Loader Class Initialized
INFO - 2024-09-14 21:55:52 --> Helper loaded: url_helper
INFO - 2024-09-14 21:55:52 --> Helper loaded: file_helper
INFO - 2024-09-14 21:55:52 --> Helper loaded: security_helper
INFO - 2024-09-14 21:55:52 --> Helper loaded: wpu_helper
INFO - 2024-09-14 21:55:52 --> Database Driver Class Initialized
INFO - 2024-09-14 21:55:52 --> Email Class Initialized
DEBUG - 2024-09-14 21:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-14 21:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-14 21:55:52 --> Helper loaded: form_helper
INFO - 2024-09-14 21:55:52 --> Form Validation Class Initialized
INFO - 2024-09-14 21:55:52 --> Controller Class Initialized
DEBUG - 2024-09-14 21:55:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-14 21:55:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-14 21:55:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-14 21:55:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-14 21:55:52 --> Final output sent to browser
DEBUG - 2024-09-14 21:55:52 --> Total execution time: 0.2072
