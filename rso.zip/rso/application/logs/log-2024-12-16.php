<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-16 17:12:53 --> Config Class Initialized
INFO - 2024-12-16 17:12:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:12:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:12:53 --> Utf8 Class Initialized
INFO - 2024-12-16 17:12:53 --> URI Class Initialized
DEBUG - 2024-12-16 17:12:53 --> No URI present. Default controller set.
INFO - 2024-12-16 17:12:53 --> Router Class Initialized
INFO - 2024-12-16 17:12:53 --> Output Class Initialized
INFO - 2024-12-16 17:12:53 --> Security Class Initialized
DEBUG - 2024-12-16 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:12:53 --> Input Class Initialized
INFO - 2024-12-16 17:12:53 --> Language Class Initialized
INFO - 2024-12-16 17:12:53 --> Loader Class Initialized
INFO - 2024-12-16 17:12:53 --> Helper loaded: url_helper
INFO - 2024-12-16 17:12:53 --> Helper loaded: file_helper
INFO - 2024-12-16 17:12:53 --> Helper loaded: security_helper
INFO - 2024-12-16 17:12:53 --> Helper loaded: wpu_helper
INFO - 2024-12-16 17:12:53 --> Database Driver Class Initialized
INFO - 2024-12-16 17:12:53 --> Email Class Initialized
DEBUG - 2024-12-16 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-16 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:12:53 --> Helper loaded: form_helper
INFO - 2024-12-16 17:12:53 --> Form Validation Class Initialized
INFO - 2024-12-16 17:12:53 --> Controller Class Initialized
DEBUG - 2024-12-16 17:12:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-16 17:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-16 17:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-16 17:12:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-16 17:12:53 --> Final output sent to browser
DEBUG - 2024-12-16 17:12:53 --> Total execution time: 0.4153
INFO - 2024-12-16 22:38:12 --> Config Class Initialized
INFO - 2024-12-16 22:38:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:38:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:38:12 --> Utf8 Class Initialized
INFO - 2024-12-16 22:38:12 --> URI Class Initialized
DEBUG - 2024-12-16 22:38:12 --> No URI present. Default controller set.
INFO - 2024-12-16 22:38:12 --> Router Class Initialized
INFO - 2024-12-16 22:38:12 --> Output Class Initialized
INFO - 2024-12-16 22:38:12 --> Security Class Initialized
DEBUG - 2024-12-16 22:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:38:12 --> Input Class Initialized
INFO - 2024-12-16 22:38:12 --> Language Class Initialized
INFO - 2024-12-16 22:38:12 --> Loader Class Initialized
INFO - 2024-12-16 22:38:12 --> Helper loaded: url_helper
INFO - 2024-12-16 22:38:12 --> Helper loaded: file_helper
INFO - 2024-12-16 22:38:12 --> Helper loaded: security_helper
INFO - 2024-12-16 22:38:12 --> Helper loaded: wpu_helper
INFO - 2024-12-16 22:38:12 --> Database Driver Class Initialized
INFO - 2024-12-16 22:38:13 --> Email Class Initialized
DEBUG - 2024-12-16 22:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-16 22:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:38:13 --> Helper loaded: form_helper
INFO - 2024-12-16 22:38:13 --> Form Validation Class Initialized
INFO - 2024-12-16 22:38:13 --> Controller Class Initialized
DEBUG - 2024-12-16 22:38:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-16 22:38:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-16 22:38:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-16 22:38:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-16 22:38:13 --> Final output sent to browser
DEBUG - 2024-12-16 22:38:13 --> Total execution time: 0.4534
INFO - 2024-12-16 22:38:15 --> Config Class Initialized
INFO - 2024-12-16 22:38:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:38:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:38:15 --> Utf8 Class Initialized
INFO - 2024-12-16 22:38:15 --> URI Class Initialized
INFO - 2024-12-16 22:38:15 --> Router Class Initialized
INFO - 2024-12-16 22:38:15 --> Output Class Initialized
INFO - 2024-12-16 22:38:15 --> Security Class Initialized
DEBUG - 2024-12-16 22:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:38:15 --> Input Class Initialized
INFO - 2024-12-16 22:38:15 --> Language Class Initialized
INFO - 2024-12-16 22:38:15 --> Loader Class Initialized
INFO - 2024-12-16 22:38:15 --> Helper loaded: url_helper
INFO - 2024-12-16 22:38:15 --> Helper loaded: file_helper
INFO - 2024-12-16 22:38:15 --> Helper loaded: security_helper
INFO - 2024-12-16 22:38:15 --> Helper loaded: wpu_helper
INFO - 2024-12-16 22:38:15 --> Database Driver Class Initialized
INFO - 2024-12-16 22:38:15 --> Email Class Initialized
DEBUG - 2024-12-16 22:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-16 22:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:38:15 --> Helper loaded: form_helper
INFO - 2024-12-16 22:38:15 --> Form Validation Class Initialized
INFO - 2024-12-16 22:38:15 --> Controller Class Initialized
DEBUG - 2024-12-16 22:38:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-16 22:38:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-16 22:38:16 --> Config Class Initialized
INFO - 2024-12-16 22:38:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:38:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:38:16 --> Utf8 Class Initialized
INFO - 2024-12-16 22:38:16 --> URI Class Initialized
INFO - 2024-12-16 22:38:16 --> Router Class Initialized
INFO - 2024-12-16 22:38:16 --> Output Class Initialized
INFO - 2024-12-16 22:38:16 --> Security Class Initialized
DEBUG - 2024-12-16 22:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:38:16 --> Input Class Initialized
INFO - 2024-12-16 22:38:16 --> Language Class Initialized
INFO - 2024-12-16 22:38:16 --> Loader Class Initialized
INFO - 2024-12-16 22:38:16 --> Helper loaded: url_helper
INFO - 2024-12-16 22:38:16 --> Helper loaded: file_helper
INFO - 2024-12-16 22:38:16 --> Helper loaded: security_helper
INFO - 2024-12-16 22:38:16 --> Helper loaded: wpu_helper
INFO - 2024-12-16 22:38:16 --> Database Driver Class Initialized
INFO - 2024-12-16 22:38:16 --> Email Class Initialized
DEBUG - 2024-12-16 22:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-16 22:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:38:16 --> Helper loaded: form_helper
INFO - 2024-12-16 22:38:16 --> Form Validation Class Initialized
INFO - 2024-12-16 22:38:16 --> Controller Class Initialized
INFO - 2024-12-16 22:38:16 --> Model "Antrol_model" initialized
DEBUG - 2024-12-16 22:38:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-16 22:38:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-16 22:38:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-16 22:38:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-16 22:38:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-16 22:38:17 --> Final output sent to browser
DEBUG - 2024-12-16 22:38:17 --> Total execution time: 1.1037
INFO - 2024-12-16 22:49:24 --> Config Class Initialized
INFO - 2024-12-16 22:49:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:49:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:49:24 --> Utf8 Class Initialized
INFO - 2024-12-16 22:49:24 --> URI Class Initialized
INFO - 2024-12-16 22:49:24 --> Router Class Initialized
INFO - 2024-12-16 22:49:24 --> Output Class Initialized
INFO - 2024-12-16 22:49:24 --> Security Class Initialized
DEBUG - 2024-12-16 22:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:49:24 --> Input Class Initialized
INFO - 2024-12-16 22:49:24 --> Language Class Initialized
ERROR - 2024-12-16 22:49:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-16 22:49:36 --> Config Class Initialized
INFO - 2024-12-16 22:49:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:49:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:49:36 --> Utf8 Class Initialized
INFO - 2024-12-16 22:49:36 --> URI Class Initialized
DEBUG - 2024-12-16 22:49:36 --> No URI present. Default controller set.
INFO - 2024-12-16 22:49:36 --> Router Class Initialized
INFO - 2024-12-16 22:49:36 --> Output Class Initialized
INFO - 2024-12-16 22:49:36 --> Security Class Initialized
DEBUG - 2024-12-16 22:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:49:36 --> Input Class Initialized
INFO - 2024-12-16 22:49:36 --> Language Class Initialized
INFO - 2024-12-16 22:49:36 --> Loader Class Initialized
INFO - 2024-12-16 22:49:36 --> Helper loaded: url_helper
INFO - 2024-12-16 22:49:36 --> Helper loaded: file_helper
INFO - 2024-12-16 22:49:36 --> Helper loaded: security_helper
INFO - 2024-12-16 22:49:36 --> Helper loaded: wpu_helper
INFO - 2024-12-16 22:49:36 --> Database Driver Class Initialized
INFO - 2024-12-16 22:49:36 --> Email Class Initialized
DEBUG - 2024-12-16 22:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-16 22:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:49:36 --> Helper loaded: form_helper
INFO - 2024-12-16 22:49:36 --> Form Validation Class Initialized
INFO - 2024-12-16 22:49:36 --> Controller Class Initialized
DEBUG - 2024-12-16 22:49:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-16 22:49:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-16 22:49:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-16 22:49:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-16 22:49:36 --> Final output sent to browser
DEBUG - 2024-12-16 22:49:36 --> Total execution time: 0.4318
