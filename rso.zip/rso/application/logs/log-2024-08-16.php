<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-16 07:13:23 --> Config Class Initialized
INFO - 2024-08-16 07:13:23 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:23 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:23 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:23 --> URI Class Initialized
DEBUG - 2024-08-16 07:13:23 --> No URI present. Default controller set.
INFO - 2024-08-16 07:13:23 --> Router Class Initialized
INFO - 2024-08-16 07:13:23 --> Output Class Initialized
INFO - 2024-08-16 07:13:23 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:23 --> Input Class Initialized
INFO - 2024-08-16 07:13:23 --> Language Class Initialized
INFO - 2024-08-16 07:13:23 --> Loader Class Initialized
INFO - 2024-08-16 07:13:23 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:23 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:23 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:23 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:24 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:24 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:24 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:24 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:24 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-16 07:13:24 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-16 07:13:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-16 07:13:24 --> Final output sent to browser
DEBUG - 2024-08-16 07:13:24 --> Total execution time: 0.6557
INFO - 2024-08-16 07:13:33 --> Config Class Initialized
INFO - 2024-08-16 07:13:33 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:33 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:33 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:33 --> URI Class Initialized
INFO - 2024-08-16 07:13:33 --> Router Class Initialized
INFO - 2024-08-16 07:13:33 --> Output Class Initialized
INFO - 2024-08-16 07:13:33 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:33 --> Input Class Initialized
INFO - 2024-08-16 07:13:33 --> Language Class Initialized
INFO - 2024-08-16 07:13:33 --> Loader Class Initialized
INFO - 2024-08-16 07:13:33 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:33 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:33 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:33 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:33 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:33 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:13:33 --> Config Class Initialized
INFO - 2024-08-16 07:13:33 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:33 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:33 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:33 --> URI Class Initialized
INFO - 2024-08-16 07:13:33 --> Router Class Initialized
INFO - 2024-08-16 07:13:33 --> Output Class Initialized
INFO - 2024-08-16 07:13:33 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:33 --> Input Class Initialized
INFO - 2024-08-16 07:13:33 --> Language Class Initialized
INFO - 2024-08-16 07:13:33 --> Loader Class Initialized
INFO - 2024-08-16 07:13:33 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:33 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:33 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:33 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:33 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:33 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:33 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-16 07:13:33 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-16 07:13:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-16 07:13:33 --> Final output sent to browser
DEBUG - 2024-08-16 07:13:33 --> Total execution time: 0.0567
INFO - 2024-08-16 07:13:38 --> Config Class Initialized
INFO - 2024-08-16 07:13:38 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:38 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:38 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:38 --> URI Class Initialized
INFO - 2024-08-16 07:13:38 --> Router Class Initialized
INFO - 2024-08-16 07:13:38 --> Output Class Initialized
INFO - 2024-08-16 07:13:38 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:38 --> Input Class Initialized
INFO - 2024-08-16 07:13:38 --> Language Class Initialized
INFO - 2024-08-16 07:13:38 --> Loader Class Initialized
INFO - 2024-08-16 07:13:38 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:38 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:38 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:38 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:38 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:38 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:13:38 --> Config Class Initialized
INFO - 2024-08-16 07:13:38 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:38 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:38 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:38 --> URI Class Initialized
INFO - 2024-08-16 07:13:38 --> Router Class Initialized
INFO - 2024-08-16 07:13:38 --> Output Class Initialized
INFO - 2024-08-16 07:13:38 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:38 --> Input Class Initialized
INFO - 2024-08-16 07:13:38 --> Language Class Initialized
INFO - 2024-08-16 07:13:38 --> Loader Class Initialized
INFO - 2024-08-16 07:13:38 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:38 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:38 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:38 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:38 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:38 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:38 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-16 07:13:38 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-16 07:13:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-16 07:13:38 --> Final output sent to browser
DEBUG - 2024-08-16 07:13:38 --> Total execution time: 0.0458
INFO - 2024-08-16 07:13:46 --> Config Class Initialized
INFO - 2024-08-16 07:13:46 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:46 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:46 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:46 --> URI Class Initialized
INFO - 2024-08-16 07:13:46 --> Router Class Initialized
INFO - 2024-08-16 07:13:46 --> Output Class Initialized
INFO - 2024-08-16 07:13:46 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:46 --> Input Class Initialized
INFO - 2024-08-16 07:13:46 --> Language Class Initialized
INFO - 2024-08-16 07:13:46 --> Loader Class Initialized
INFO - 2024-08-16 07:13:46 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:46 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:46 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:46 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:46 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:46 --> Controller Class Initialized
DEBUG - 2024-08-16 07:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:13:46 --> Config Class Initialized
INFO - 2024-08-16 07:13:46 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:13:46 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:13:46 --> Utf8 Class Initialized
INFO - 2024-08-16 07:13:46 --> URI Class Initialized
INFO - 2024-08-16 07:13:46 --> Router Class Initialized
INFO - 2024-08-16 07:13:46 --> Output Class Initialized
INFO - 2024-08-16 07:13:46 --> Security Class Initialized
DEBUG - 2024-08-16 07:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:13:46 --> Input Class Initialized
INFO - 2024-08-16 07:13:46 --> Language Class Initialized
INFO - 2024-08-16 07:13:46 --> Loader Class Initialized
INFO - 2024-08-16 07:13:46 --> Helper loaded: url_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: file_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: security_helper
INFO - 2024-08-16 07:13:46 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:13:46 --> Database Driver Class Initialized
INFO - 2024-08-16 07:13:46 --> Email Class Initialized
DEBUG - 2024-08-16 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:13:46 --> Helper loaded: form_helper
INFO - 2024-08-16 07:13:46 --> Form Validation Class Initialized
INFO - 2024-08-16 07:13:46 --> Controller Class Initialized
INFO - 2024-08-16 07:13:46 --> Model "User_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:13:46 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:13:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:13:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:13:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:13:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-16 07:13:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:13:46 --> Final output sent to browser
DEBUG - 2024-08-16 07:13:46 --> Total execution time: 0.6441
INFO - 2024-08-16 07:14:25 --> Config Class Initialized
INFO - 2024-08-16 07:14:25 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:14:25 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:14:25 --> Utf8 Class Initialized
INFO - 2024-08-16 07:14:25 --> URI Class Initialized
INFO - 2024-08-16 07:14:25 --> Router Class Initialized
INFO - 2024-08-16 07:14:25 --> Output Class Initialized
INFO - 2024-08-16 07:14:25 --> Security Class Initialized
DEBUG - 2024-08-16 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:14:25 --> Input Class Initialized
INFO - 2024-08-16 07:14:25 --> Language Class Initialized
INFO - 2024-08-16 07:14:25 --> Loader Class Initialized
INFO - 2024-08-16 07:14:25 --> Helper loaded: url_helper
INFO - 2024-08-16 07:14:25 --> Helper loaded: file_helper
INFO - 2024-08-16 07:14:25 --> Helper loaded: security_helper
INFO - 2024-08-16 07:14:25 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:14:25 --> Database Driver Class Initialized
INFO - 2024-08-16 07:14:25 --> Email Class Initialized
DEBUG - 2024-08-16 07:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:14:25 --> Helper loaded: form_helper
INFO - 2024-08-16 07:14:25 --> Form Validation Class Initialized
INFO - 2024-08-16 07:14:25 --> Controller Class Initialized
INFO - 2024-08-16 07:14:25 --> Model "User_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:14:25 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:14:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:14:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:14:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:14:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:14:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-16 07:14:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:14:25 --> Final output sent to browser
DEBUG - 2024-08-16 07:14:25 --> Total execution time: 0.1078
INFO - 2024-08-16 07:14:44 --> Config Class Initialized
INFO - 2024-08-16 07:14:44 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:14:44 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:14:44 --> Utf8 Class Initialized
INFO - 2024-08-16 07:14:44 --> URI Class Initialized
INFO - 2024-08-16 07:14:44 --> Router Class Initialized
INFO - 2024-08-16 07:14:44 --> Output Class Initialized
INFO - 2024-08-16 07:14:44 --> Security Class Initialized
DEBUG - 2024-08-16 07:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:14:44 --> Input Class Initialized
INFO - 2024-08-16 07:14:44 --> Language Class Initialized
INFO - 2024-08-16 07:14:44 --> Loader Class Initialized
INFO - 2024-08-16 07:14:44 --> Helper loaded: url_helper
INFO - 2024-08-16 07:14:44 --> Helper loaded: file_helper
INFO - 2024-08-16 07:14:44 --> Helper loaded: security_helper
INFO - 2024-08-16 07:14:44 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:14:44 --> Database Driver Class Initialized
INFO - 2024-08-16 07:14:44 --> Email Class Initialized
DEBUG - 2024-08-16 07:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:14:44 --> Helper loaded: form_helper
INFO - 2024-08-16 07:14:44 --> Form Validation Class Initialized
INFO - 2024-08-16 07:14:44 --> Controller Class Initialized
INFO - 2024-08-16 07:14:44 --> Model "User_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:14:44 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:14:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:14:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:14:45 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:14:45 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:14:45 --> Final output sent to browser
DEBUG - 2024-08-16 07:14:45 --> Total execution time: 0.1726
INFO - 2024-08-16 07:14:48 --> Config Class Initialized
INFO - 2024-08-16 07:14:48 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:14:48 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:14:48 --> Utf8 Class Initialized
INFO - 2024-08-16 07:14:48 --> URI Class Initialized
INFO - 2024-08-16 07:14:48 --> Router Class Initialized
INFO - 2024-08-16 07:14:48 --> Output Class Initialized
INFO - 2024-08-16 07:14:48 --> Security Class Initialized
DEBUG - 2024-08-16 07:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:14:48 --> Input Class Initialized
INFO - 2024-08-16 07:14:48 --> Language Class Initialized
INFO - 2024-08-16 07:14:48 --> Loader Class Initialized
INFO - 2024-08-16 07:14:48 --> Helper loaded: url_helper
INFO - 2024-08-16 07:14:48 --> Helper loaded: file_helper
INFO - 2024-08-16 07:14:48 --> Helper loaded: security_helper
INFO - 2024-08-16 07:14:48 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:14:48 --> Database Driver Class Initialized
INFO - 2024-08-16 07:14:48 --> Email Class Initialized
DEBUG - 2024-08-16 07:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:14:48 --> Helper loaded: form_helper
INFO - 2024-08-16 07:14:48 --> Form Validation Class Initialized
INFO - 2024-08-16 07:14:48 --> Controller Class Initialized
INFO - 2024-08-16 07:14:48 --> Model "User_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:14:48 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:14:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:14:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:14:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:14:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:14:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/barang.php
INFO - 2024-08-16 07:14:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:14:48 --> Final output sent to browser
DEBUG - 2024-08-16 07:14:48 --> Total execution time: 0.0937
INFO - 2024-08-16 07:14:51 --> Config Class Initialized
INFO - 2024-08-16 07:14:51 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:14:51 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:14:51 --> Utf8 Class Initialized
INFO - 2024-08-16 07:14:51 --> URI Class Initialized
INFO - 2024-08-16 07:14:51 --> Router Class Initialized
INFO - 2024-08-16 07:14:51 --> Output Class Initialized
INFO - 2024-08-16 07:14:51 --> Security Class Initialized
DEBUG - 2024-08-16 07:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:14:51 --> Input Class Initialized
INFO - 2024-08-16 07:14:51 --> Language Class Initialized
INFO - 2024-08-16 07:14:51 --> Loader Class Initialized
INFO - 2024-08-16 07:14:51 --> Helper loaded: url_helper
INFO - 2024-08-16 07:14:51 --> Helper loaded: file_helper
INFO - 2024-08-16 07:14:51 --> Helper loaded: security_helper
INFO - 2024-08-16 07:14:51 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:14:51 --> Database Driver Class Initialized
INFO - 2024-08-16 07:14:51 --> Email Class Initialized
DEBUG - 2024-08-16 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:14:51 --> Helper loaded: form_helper
INFO - 2024-08-16 07:14:51 --> Form Validation Class Initialized
INFO - 2024-08-16 07:14:51 --> Controller Class Initialized
INFO - 2024-08-16 07:14:51 --> Model "User_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:14:51 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:14:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:14:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:14:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:14:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:14:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_barang.php
INFO - 2024-08-16 07:14:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:14:51 --> Final output sent to browser
DEBUG - 2024-08-16 07:14:51 --> Total execution time: 0.1089
INFO - 2024-08-16 07:16:52 --> Config Class Initialized
INFO - 2024-08-16 07:16:52 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:16:52 --> Utf8 Class Initialized
INFO - 2024-08-16 07:16:52 --> URI Class Initialized
INFO - 2024-08-16 07:16:52 --> Router Class Initialized
INFO - 2024-08-16 07:16:52 --> Output Class Initialized
INFO - 2024-08-16 07:16:52 --> Security Class Initialized
DEBUG - 2024-08-16 07:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:16:52 --> Input Class Initialized
INFO - 2024-08-16 07:16:52 --> Language Class Initialized
INFO - 2024-08-16 07:16:52 --> Loader Class Initialized
INFO - 2024-08-16 07:16:52 --> Helper loaded: url_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: file_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: security_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:16:52 --> Database Driver Class Initialized
INFO - 2024-08-16 07:16:52 --> Email Class Initialized
DEBUG - 2024-08-16 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:16:52 --> Helper loaded: form_helper
INFO - 2024-08-16 07:16:52 --> Form Validation Class Initialized
INFO - 2024-08-16 07:16:52 --> Controller Class Initialized
INFO - 2024-08-16 07:16:52 --> Model "User_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:16:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:16:52 --> Helper loaded: inflector_helper
INFO - 2024-08-16 07:16:52 --> Upload Class Initialized
INFO - 2024-08-16 07:16:52 --> Config Class Initialized
INFO - 2024-08-16 07:16:52 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:16:52 --> Utf8 Class Initialized
INFO - 2024-08-16 07:16:52 --> URI Class Initialized
INFO - 2024-08-16 07:16:52 --> Router Class Initialized
INFO - 2024-08-16 07:16:52 --> Output Class Initialized
INFO - 2024-08-16 07:16:52 --> Security Class Initialized
DEBUG - 2024-08-16 07:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:16:52 --> Input Class Initialized
INFO - 2024-08-16 07:16:52 --> Language Class Initialized
INFO - 2024-08-16 07:16:52 --> Loader Class Initialized
INFO - 2024-08-16 07:16:52 --> Helper loaded: url_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: file_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: security_helper
INFO - 2024-08-16 07:16:52 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:16:52 --> Database Driver Class Initialized
INFO - 2024-08-16 07:16:52 --> Email Class Initialized
DEBUG - 2024-08-16 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:16:52 --> Helper loaded: form_helper
INFO - 2024-08-16 07:16:52 --> Form Validation Class Initialized
INFO - 2024-08-16 07:16:52 --> Controller Class Initialized
INFO - 2024-08-16 07:16:52 --> Model "User_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:16:52 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:16:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:16:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:16:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:16:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/barang.php
INFO - 2024-08-16 07:16:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:16:52 --> Final output sent to browser
DEBUG - 2024-08-16 07:16:52 --> Total execution time: 0.0793
INFO - 2024-08-16 07:17:06 --> Config Class Initialized
INFO - 2024-08-16 07:17:06 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:06 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:06 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:06 --> URI Class Initialized
INFO - 2024-08-16 07:17:06 --> Router Class Initialized
INFO - 2024-08-16 07:17:06 --> Output Class Initialized
INFO - 2024-08-16 07:17:06 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:06 --> Input Class Initialized
INFO - 2024-08-16 07:17:06 --> Language Class Initialized
INFO - 2024-08-16 07:17:06 --> Loader Class Initialized
INFO - 2024-08-16 07:17:06 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:06 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:06 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:06 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:06 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:06 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:06 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:06 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:06 --> Controller Class Initialized
INFO - 2024-08-16 07:17:06 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:06 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:17:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:17:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:17:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_barang.php
INFO - 2024-08-16 07:17:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:17:06 --> Final output sent to browser
DEBUG - 2024-08-16 07:17:06 --> Total execution time: 0.1400
INFO - 2024-08-16 07:17:37 --> Config Class Initialized
INFO - 2024-08-16 07:17:37 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:37 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:37 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:37 --> URI Class Initialized
INFO - 2024-08-16 07:17:37 --> Router Class Initialized
INFO - 2024-08-16 07:17:37 --> Output Class Initialized
INFO - 2024-08-16 07:17:37 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:37 --> Input Class Initialized
INFO - 2024-08-16 07:17:37 --> Language Class Initialized
INFO - 2024-08-16 07:17:37 --> Loader Class Initialized
INFO - 2024-08-16 07:17:37 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:37 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:37 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:37 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:37 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:37 --> Controller Class Initialized
INFO - 2024-08-16 07:17:37 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:17:37 --> Config Class Initialized
INFO - 2024-08-16 07:17:37 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:37 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:37 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:37 --> URI Class Initialized
INFO - 2024-08-16 07:17:37 --> Router Class Initialized
INFO - 2024-08-16 07:17:37 --> Output Class Initialized
INFO - 2024-08-16 07:17:37 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:37 --> Input Class Initialized
INFO - 2024-08-16 07:17:37 --> Language Class Initialized
INFO - 2024-08-16 07:17:37 --> Loader Class Initialized
INFO - 2024-08-16 07:17:37 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:37 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:37 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:37 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:37 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:37 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:37 --> Controller Class Initialized
INFO - 2024-08-16 07:17:37 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:37 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:17:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:17:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:17:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/barang.php
INFO - 2024-08-16 07:17:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:17:37 --> Final output sent to browser
DEBUG - 2024-08-16 07:17:37 --> Total execution time: 0.0786
INFO - 2024-08-16 07:17:51 --> Config Class Initialized
INFO - 2024-08-16 07:17:51 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:51 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:51 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:51 --> URI Class Initialized
INFO - 2024-08-16 07:17:51 --> Router Class Initialized
INFO - 2024-08-16 07:17:51 --> Output Class Initialized
INFO - 2024-08-16 07:17:51 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:51 --> Input Class Initialized
INFO - 2024-08-16 07:17:51 --> Language Class Initialized
INFO - 2024-08-16 07:17:51 --> Loader Class Initialized
INFO - 2024-08-16 07:17:51 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:51 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:51 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:51 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:51 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:51 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:51 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:51 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:51 --> Controller Class Initialized
INFO - 2024-08-16 07:17:51 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:51 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:17:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:17:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:17:51 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:17:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:17:51 --> Final output sent to browser
DEBUG - 2024-08-16 07:17:51 --> Total execution time: 0.0847
INFO - 2024-08-16 07:17:53 --> Config Class Initialized
INFO - 2024-08-16 07:17:53 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:53 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:53 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:53 --> URI Class Initialized
INFO - 2024-08-16 07:17:53 --> Router Class Initialized
INFO - 2024-08-16 07:17:53 --> Output Class Initialized
INFO - 2024-08-16 07:17:53 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:53 --> Input Class Initialized
INFO - 2024-08-16 07:17:53 --> Language Class Initialized
INFO - 2024-08-16 07:17:53 --> Loader Class Initialized
INFO - 2024-08-16 07:17:53 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:53 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:53 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:53 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:53 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:53 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:53 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:53 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:53 --> Controller Class Initialized
INFO - 2024-08-16 07:17:53 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:53 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:17:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:17:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:17:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:17:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:17:53 --> Final output sent to browser
DEBUG - 2024-08-16 07:17:53 --> Total execution time: 0.1031
INFO - 2024-08-16 07:17:55 --> Config Class Initialized
INFO - 2024-08-16 07:17:55 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:17:55 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:17:55 --> Utf8 Class Initialized
INFO - 2024-08-16 07:17:55 --> URI Class Initialized
INFO - 2024-08-16 07:17:55 --> Router Class Initialized
INFO - 2024-08-16 07:17:55 --> Output Class Initialized
INFO - 2024-08-16 07:17:55 --> Security Class Initialized
DEBUG - 2024-08-16 07:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:17:55 --> Input Class Initialized
INFO - 2024-08-16 07:17:55 --> Language Class Initialized
INFO - 2024-08-16 07:17:55 --> Loader Class Initialized
INFO - 2024-08-16 07:17:55 --> Helper loaded: url_helper
INFO - 2024-08-16 07:17:55 --> Helper loaded: file_helper
INFO - 2024-08-16 07:17:55 --> Helper loaded: security_helper
INFO - 2024-08-16 07:17:55 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:17:55 --> Database Driver Class Initialized
INFO - 2024-08-16 07:17:55 --> Email Class Initialized
DEBUG - 2024-08-16 07:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:17:55 --> Helper loaded: form_helper
INFO - 2024-08-16 07:17:55 --> Form Validation Class Initialized
INFO - 2024-08-16 07:17:55 --> Controller Class Initialized
INFO - 2024-08-16 07:17:55 --> Model "User_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:17:55 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:17:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:17:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:17:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:17:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:17:55 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_inventaris.php
INFO - 2024-08-16 07:17:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:17:55 --> Final output sent to browser
DEBUG - 2024-08-16 07:17:55 --> Total execution time: 0.1006
INFO - 2024-08-16 07:18:30 --> Config Class Initialized
INFO - 2024-08-16 07:18:30 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:30 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:30 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:30 --> URI Class Initialized
INFO - 2024-08-16 07:18:30 --> Router Class Initialized
INFO - 2024-08-16 07:18:30 --> Output Class Initialized
INFO - 2024-08-16 07:18:30 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:30 --> Input Class Initialized
INFO - 2024-08-16 07:18:30 --> Language Class Initialized
INFO - 2024-08-16 07:18:30 --> Loader Class Initialized
INFO - 2024-08-16 07:18:30 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:30 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:30 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:30 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:30 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:30 --> Controller Class Initialized
INFO - 2024-08-16 07:18:30 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:18:30 --> Helper loaded: inflector_helper
INFO - 2024-08-16 07:18:30 --> Upload Class Initialized
INFO - 2024-08-16 07:18:30 --> Config Class Initialized
INFO - 2024-08-16 07:18:30 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:30 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:30 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:30 --> URI Class Initialized
INFO - 2024-08-16 07:18:30 --> Router Class Initialized
INFO - 2024-08-16 07:18:30 --> Output Class Initialized
INFO - 2024-08-16 07:18:30 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:30 --> Input Class Initialized
INFO - 2024-08-16 07:18:30 --> Language Class Initialized
INFO - 2024-08-16 07:18:30 --> Loader Class Initialized
INFO - 2024-08-16 07:18:30 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:30 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:30 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:30 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:30 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:30 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:30 --> Controller Class Initialized
INFO - 2024-08-16 07:18:30 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:30 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:18:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:18:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:18:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:18:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:18:30 --> Final output sent to browser
DEBUG - 2024-08-16 07:18:30 --> Total execution time: 0.0790
INFO - 2024-08-16 07:18:37 --> Config Class Initialized
INFO - 2024-08-16 07:18:37 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:37 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:37 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:37 --> URI Class Initialized
INFO - 2024-08-16 07:18:37 --> Router Class Initialized
INFO - 2024-08-16 07:18:37 --> Output Class Initialized
INFO - 2024-08-16 07:18:37 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:37 --> Input Class Initialized
INFO - 2024-08-16 07:18:37 --> Language Class Initialized
INFO - 2024-08-16 07:18:37 --> Loader Class Initialized
INFO - 2024-08-16 07:18:37 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:37 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:37 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:37 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:37 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:37 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:37 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:37 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:37 --> Controller Class Initialized
INFO - 2024-08-16 07:18:37 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:37 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:18:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:18:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:18:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_inventaris.php
INFO - 2024-08-16 07:18:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:18:37 --> Final output sent to browser
DEBUG - 2024-08-16 07:18:37 --> Total execution time: 0.1096
INFO - 2024-08-16 07:18:47 --> Config Class Initialized
INFO - 2024-08-16 07:18:47 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:47 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:47 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:47 --> URI Class Initialized
INFO - 2024-08-16 07:18:47 --> Router Class Initialized
INFO - 2024-08-16 07:18:47 --> Output Class Initialized
INFO - 2024-08-16 07:18:47 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:47 --> Input Class Initialized
INFO - 2024-08-16 07:18:47 --> Language Class Initialized
INFO - 2024-08-16 07:18:47 --> Loader Class Initialized
INFO - 2024-08-16 07:18:47 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:47 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:47 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:47 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:47 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:47 --> Controller Class Initialized
INFO - 2024-08-16 07:18:47 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:18:47 --> Config Class Initialized
INFO - 2024-08-16 07:18:47 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:47 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:47 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:47 --> URI Class Initialized
INFO - 2024-08-16 07:18:47 --> Router Class Initialized
INFO - 2024-08-16 07:18:47 --> Output Class Initialized
INFO - 2024-08-16 07:18:47 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:47 --> Input Class Initialized
INFO - 2024-08-16 07:18:47 --> Language Class Initialized
INFO - 2024-08-16 07:18:47 --> Loader Class Initialized
INFO - 2024-08-16 07:18:47 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:47 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:47 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:47 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:47 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:47 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:47 --> Controller Class Initialized
INFO - 2024-08-16 07:18:47 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:18:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:18:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:18:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:18:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:18:47 --> Final output sent to browser
DEBUG - 2024-08-16 07:18:47 --> Total execution time: 0.0568
INFO - 2024-08-16 07:18:53 --> Config Class Initialized
INFO - 2024-08-16 07:18:53 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:53 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:53 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:53 --> URI Class Initialized
INFO - 2024-08-16 07:18:53 --> Router Class Initialized
INFO - 2024-08-16 07:18:53 --> Output Class Initialized
INFO - 2024-08-16 07:18:53 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:53 --> Input Class Initialized
INFO - 2024-08-16 07:18:53 --> Language Class Initialized
INFO - 2024-08-16 07:18:53 --> Loader Class Initialized
INFO - 2024-08-16 07:18:53 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:53 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:53 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:53 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:53 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:53 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:53 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:53 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:53 --> Controller Class Initialized
INFO - 2024-08-16 07:18:53 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:53 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:18:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:18:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:18:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_inventaris.php
INFO - 2024-08-16 07:18:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:18:53 --> Final output sent to browser
DEBUG - 2024-08-16 07:18:53 --> Total execution time: 0.0778
INFO - 2024-08-16 07:18:56 --> Config Class Initialized
INFO - 2024-08-16 07:18:56 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:56 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:56 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:56 --> URI Class Initialized
INFO - 2024-08-16 07:18:56 --> Router Class Initialized
INFO - 2024-08-16 07:18:56 --> Output Class Initialized
INFO - 2024-08-16 07:18:56 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:56 --> Input Class Initialized
INFO - 2024-08-16 07:18:56 --> Language Class Initialized
INFO - 2024-08-16 07:18:56 --> Loader Class Initialized
INFO - 2024-08-16 07:18:56 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:56 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:56 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:56 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:56 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:56 --> Controller Class Initialized
INFO - 2024-08-16 07:18:56 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 07:18:56 --> Config Class Initialized
INFO - 2024-08-16 07:18:56 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:18:56 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:18:56 --> Utf8 Class Initialized
INFO - 2024-08-16 07:18:56 --> URI Class Initialized
INFO - 2024-08-16 07:18:56 --> Router Class Initialized
INFO - 2024-08-16 07:18:56 --> Output Class Initialized
INFO - 2024-08-16 07:18:56 --> Security Class Initialized
DEBUG - 2024-08-16 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:18:56 --> Input Class Initialized
INFO - 2024-08-16 07:18:56 --> Language Class Initialized
INFO - 2024-08-16 07:18:56 --> Loader Class Initialized
INFO - 2024-08-16 07:18:56 --> Helper loaded: url_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: file_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: security_helper
INFO - 2024-08-16 07:18:56 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:18:56 --> Database Driver Class Initialized
INFO - 2024-08-16 07:18:56 --> Email Class Initialized
DEBUG - 2024-08-16 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:18:56 --> Helper loaded: form_helper
INFO - 2024-08-16 07:18:56 --> Form Validation Class Initialized
INFO - 2024-08-16 07:18:56 --> Controller Class Initialized
INFO - 2024-08-16 07:18:56 --> Model "User_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:18:56 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:18:56 --> Final output sent to browser
DEBUG - 2024-08-16 07:18:56 --> Total execution time: 0.0756
INFO - 2024-08-16 07:19:07 --> Config Class Initialized
INFO - 2024-08-16 07:19:07 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:07 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:07 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:07 --> URI Class Initialized
INFO - 2024-08-16 07:19:07 --> Router Class Initialized
INFO - 2024-08-16 07:19:07 --> Output Class Initialized
INFO - 2024-08-16 07:19:07 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:07 --> Input Class Initialized
INFO - 2024-08-16 07:19:07 --> Language Class Initialized
INFO - 2024-08-16 07:19:07 --> Loader Class Initialized
INFO - 2024-08-16 07:19:07 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:07 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:07 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:07 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:07 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:07 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:07 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:07 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:07 --> Controller Class Initialized
INFO - 2024-08-16 07:19:07 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:07 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:07 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:19:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:07 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:07 --> Total execution time: 0.0858
INFO - 2024-08-16 07:19:09 --> Config Class Initialized
INFO - 2024-08-16 07:19:09 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:09 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:09 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:09 --> URI Class Initialized
INFO - 2024-08-16 07:19:09 --> Router Class Initialized
INFO - 2024-08-16 07:19:09 --> Output Class Initialized
INFO - 2024-08-16 07:19:09 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:09 --> Input Class Initialized
INFO - 2024-08-16 07:19:09 --> Language Class Initialized
INFO - 2024-08-16 07:19:09 --> Loader Class Initialized
INFO - 2024-08-16 07:19:09 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:09 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:09 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:09 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:09 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:09 --> Controller Class Initialized
INFO - 2024-08-16 07:19:09 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:09 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:09 --> Total execution time: 0.0703
INFO - 2024-08-16 07:19:09 --> Config Class Initialized
INFO - 2024-08-16 07:19:09 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:09 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:09 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:09 --> URI Class Initialized
INFO - 2024-08-16 07:19:09 --> Router Class Initialized
INFO - 2024-08-16 07:19:09 --> Output Class Initialized
INFO - 2024-08-16 07:19:09 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:09 --> Input Class Initialized
INFO - 2024-08-16 07:19:09 --> Language Class Initialized
INFO - 2024-08-16 07:19:09 --> Loader Class Initialized
INFO - 2024-08-16 07:19:09 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:09 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:09 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:09 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:09 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:09 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:09 --> Controller Class Initialized
INFO - 2024-08-16 07:19:09 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:09 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:19:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:09 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:09 --> Total execution time: 0.0766
INFO - 2024-08-16 07:19:15 --> Config Class Initialized
INFO - 2024-08-16 07:19:15 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:15 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:15 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:15 --> URI Class Initialized
INFO - 2024-08-16 07:19:15 --> Router Class Initialized
INFO - 2024-08-16 07:19:15 --> Output Class Initialized
INFO - 2024-08-16 07:19:15 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:15 --> Input Class Initialized
INFO - 2024-08-16 07:19:15 --> Language Class Initialized
INFO - 2024-08-16 07:19:15 --> Loader Class Initialized
INFO - 2024-08-16 07:19:15 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:15 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:15 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:15 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:15 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:15 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:15 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:15 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:15 --> Controller Class Initialized
INFO - 2024-08-16 07:19:15 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:15 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-08-16 07:19:15 --> Ciqrcode class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/qrcode_view.php
INFO - 2024-08-16 07:19:15 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:15 --> Total execution time: 0.1371
INFO - 2024-08-16 07:19:15 --> Config Class Initialized
INFO - 2024-08-16 07:19:15 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:15 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:15 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:15 --> URI Class Initialized
INFO - 2024-08-16 07:19:15 --> Router Class Initialized
INFO - 2024-08-16 07:19:15 --> Output Class Initialized
INFO - 2024-08-16 07:19:15 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:15 --> Input Class Initialized
INFO - 2024-08-16 07:19:15 --> Language Class Initialized
ERROR - 2024-08-16 07:19:15 --> 404 Page Not Found: Assets/css
INFO - 2024-08-16 07:19:37 --> Config Class Initialized
INFO - 2024-08-16 07:19:37 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:37 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:37 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:37 --> URI Class Initialized
INFO - 2024-08-16 07:19:37 --> Router Class Initialized
INFO - 2024-08-16 07:19:37 --> Output Class Initialized
INFO - 2024-08-16 07:19:37 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:37 --> Input Class Initialized
INFO - 2024-08-16 07:19:37 --> Language Class Initialized
INFO - 2024-08-16 07:19:37 --> Loader Class Initialized
INFO - 2024-08-16 07:19:37 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:37 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:37 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:37 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:37 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:37 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:37 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:37 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:37 --> Controller Class Initialized
INFO - 2024-08-16 07:19:37 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:37 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/v_inventaris.php
INFO - 2024-08-16 07:19:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:37 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:37 --> Total execution time: 0.0809
INFO - 2024-08-16 07:19:44 --> Config Class Initialized
INFO - 2024-08-16 07:19:44 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:44 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:44 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:44 --> URI Class Initialized
INFO - 2024-08-16 07:19:44 --> Router Class Initialized
INFO - 2024-08-16 07:19:44 --> Output Class Initialized
INFO - 2024-08-16 07:19:44 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:44 --> Input Class Initialized
INFO - 2024-08-16 07:19:44 --> Language Class Initialized
INFO - 2024-08-16 07:19:44 --> Loader Class Initialized
INFO - 2024-08-16 07:19:44 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:44 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:44 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:44 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:44 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:44 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:44 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:44 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:44 --> Controller Class Initialized
INFO - 2024-08-16 07:19:44 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:44 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:19:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:44 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:44 --> Total execution time: 0.0710
INFO - 2024-08-16 07:19:47 --> Config Class Initialized
INFO - 2024-08-16 07:19:47 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:47 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:47 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:47 --> URI Class Initialized
INFO - 2024-08-16 07:19:47 --> Router Class Initialized
INFO - 2024-08-16 07:19:47 --> Output Class Initialized
INFO - 2024-08-16 07:19:47 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:47 --> Input Class Initialized
INFO - 2024-08-16 07:19:47 --> Language Class Initialized
INFO - 2024-08-16 07:19:47 --> Loader Class Initialized
INFO - 2024-08-16 07:19:47 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:47 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:47 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:47 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:47 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:47 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:47 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:47 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:47 --> Controller Class Initialized
INFO - 2024-08-16 07:19:47 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/penghapusan.php
INFO - 2024-08-16 07:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:47 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:47 --> Total execution time: 0.1079
INFO - 2024-08-16 07:19:51 --> Config Class Initialized
INFO - 2024-08-16 07:19:51 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:51 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:51 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:51 --> URI Class Initialized
INFO - 2024-08-16 07:19:51 --> Router Class Initialized
INFO - 2024-08-16 07:19:51 --> Output Class Initialized
INFO - 2024-08-16 07:19:51 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:51 --> Input Class Initialized
INFO - 2024-08-16 07:19:51 --> Language Class Initialized
INFO - 2024-08-16 07:19:51 --> Loader Class Initialized
INFO - 2024-08-16 07:19:51 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:51 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:51 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:51 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:51 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:51 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:51 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:51 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:51 --> Controller Class Initialized
INFO - 2024-08-16 07:19:51 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:51 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-08-16 07:19:51 --> 404 Page Not Found: 
INFO - 2024-08-16 07:19:53 --> Config Class Initialized
INFO - 2024-08-16 07:19:53 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:53 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:53 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:53 --> URI Class Initialized
INFO - 2024-08-16 07:19:53 --> Router Class Initialized
INFO - 2024-08-16 07:19:53 --> Output Class Initialized
INFO - 2024-08-16 07:19:53 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:53 --> Input Class Initialized
INFO - 2024-08-16 07:19:53 --> Language Class Initialized
INFO - 2024-08-16 07:19:53 --> Loader Class Initialized
INFO - 2024-08-16 07:19:53 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:53 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:53 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:53 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:53 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:53 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:53 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:53 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:53 --> Controller Class Initialized
INFO - 2024-08-16 07:19:53 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:53 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/penghapusan.php
INFO - 2024-08-16 07:19:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:53 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:53 --> Total execution time: 0.0778
INFO - 2024-08-16 07:19:55 --> Config Class Initialized
INFO - 2024-08-16 07:19:55 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:55 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:55 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:55 --> URI Class Initialized
INFO - 2024-08-16 07:19:55 --> Router Class Initialized
INFO - 2024-08-16 07:19:55 --> Output Class Initialized
INFO - 2024-08-16 07:19:55 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:55 --> Input Class Initialized
INFO - 2024-08-16 07:19:55 --> Language Class Initialized
INFO - 2024-08-16 07:19:55 --> Loader Class Initialized
INFO - 2024-08-16 07:19:55 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:55 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:55 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:55 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:55 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:55 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:55 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:55 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:55 --> Controller Class Initialized
INFO - 2024-08-16 07:19:55 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:55 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:19:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:19:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:19:55 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_penghapusan.php
INFO - 2024-08-16 07:19:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:19:55 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:55 --> Total execution time: 0.1034
INFO - 2024-08-16 07:19:58 --> Config Class Initialized
INFO - 2024-08-16 07:19:58 --> Hooks Class Initialized
INFO - 2024-08-16 07:19:58 --> Config Class Initialized
INFO - 2024-08-16 07:19:58 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:19:58 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:58 --> Utf8 Class Initialized
DEBUG - 2024-08-16 07:19:58 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:19:58 --> Utf8 Class Initialized
INFO - 2024-08-16 07:19:58 --> URI Class Initialized
INFO - 2024-08-16 07:19:58 --> URI Class Initialized
INFO - 2024-08-16 07:19:58 --> Router Class Initialized
INFO - 2024-08-16 07:19:58 --> Router Class Initialized
INFO - 2024-08-16 07:19:58 --> Output Class Initialized
INFO - 2024-08-16 07:19:58 --> Output Class Initialized
INFO - 2024-08-16 07:19:58 --> Security Class Initialized
INFO - 2024-08-16 07:19:58 --> Security Class Initialized
DEBUG - 2024-08-16 07:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-16 07:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:19:58 --> Input Class Initialized
INFO - 2024-08-16 07:19:58 --> Input Class Initialized
INFO - 2024-08-16 07:19:58 --> Language Class Initialized
INFO - 2024-08-16 07:19:58 --> Language Class Initialized
INFO - 2024-08-16 07:19:58 --> Loader Class Initialized
INFO - 2024-08-16 07:19:58 --> Loader Class Initialized
INFO - 2024-08-16 07:19:58 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: url_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: file_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: security_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:58 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:19:58 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:58 --> Database Driver Class Initialized
INFO - 2024-08-16 07:19:58 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:58 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:58 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:58 --> Controller Class Initialized
INFO - 2024-08-16 07:19:58 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Mutasi_model" initialized
INFO - 2024-08-16 07:19:58 --> Email Class Initialized
DEBUG - 2024-08-16 07:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-16 07:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:58 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:58 --> Total execution time: 0.0535
INFO - 2024-08-16 07:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:19:58 --> Helper loaded: form_helper
INFO - 2024-08-16 07:19:58 --> Form Validation Class Initialized
INFO - 2024-08-16 07:19:58 --> Controller Class Initialized
INFO - 2024-08-16 07:19:58 --> Model "User_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:19:58 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:19:58 --> Final output sent to browser
DEBUG - 2024-08-16 07:19:58 --> Total execution time: 0.0795
INFO - 2024-08-16 07:20:02 --> Config Class Initialized
INFO - 2024-08-16 07:20:02 --> Hooks Class Initialized
DEBUG - 2024-08-16 07:20:02 --> UTF-8 Support Enabled
INFO - 2024-08-16 07:20:02 --> Utf8 Class Initialized
INFO - 2024-08-16 07:20:02 --> URI Class Initialized
INFO - 2024-08-16 07:20:02 --> Router Class Initialized
INFO - 2024-08-16 07:20:02 --> Output Class Initialized
INFO - 2024-08-16 07:20:02 --> Security Class Initialized
DEBUG - 2024-08-16 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 07:20:02 --> Input Class Initialized
INFO - 2024-08-16 07:20:02 --> Language Class Initialized
INFO - 2024-08-16 07:20:02 --> Loader Class Initialized
INFO - 2024-08-16 07:20:02 --> Helper loaded: url_helper
INFO - 2024-08-16 07:20:02 --> Helper loaded: file_helper
INFO - 2024-08-16 07:20:02 --> Helper loaded: security_helper
INFO - 2024-08-16 07:20:02 --> Helper loaded: wpu_helper
INFO - 2024-08-16 07:20:02 --> Database Driver Class Initialized
INFO - 2024-08-16 07:20:02 --> Email Class Initialized
DEBUG - 2024-08-16 07:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 07:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 07:20:02 --> Helper loaded: form_helper
INFO - 2024-08-16 07:20:02 --> Form Validation Class Initialized
INFO - 2024-08-16 07:20:02 --> Controller Class Initialized
INFO - 2024-08-16 07:20:02 --> Model "User_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Faktur_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Supplier_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Jenis_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Barang_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 07:20:02 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 07:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 07:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 07:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 07:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 07:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 07:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 07:20:02 --> Final output sent to browser
DEBUG - 2024-08-16 07:20:02 --> Total execution time: 0.0845
INFO - 2024-08-16 23:53:27 --> Config Class Initialized
INFO - 2024-08-16 23:53:27 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:27 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:27 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:27 --> URI Class Initialized
DEBUG - 2024-08-16 23:53:27 --> No URI present. Default controller set.
INFO - 2024-08-16 23:53:27 --> Router Class Initialized
INFO - 2024-08-16 23:53:27 --> Output Class Initialized
INFO - 2024-08-16 23:53:27 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:27 --> Input Class Initialized
INFO - 2024-08-16 23:53:27 --> Language Class Initialized
INFO - 2024-08-16 23:53:27 --> Loader Class Initialized
INFO - 2024-08-16 23:53:28 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:28 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:28 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:28 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:28 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:28 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:28 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:28 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:28 --> Controller Class Initialized
DEBUG - 2024-08-16 23:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-16 23:53:28 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-16 23:53:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-16 23:53:28 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:28 --> Total execution time: 0.6974
INFO - 2024-08-16 23:53:33 --> Config Class Initialized
INFO - 2024-08-16 23:53:33 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:33 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:33 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:33 --> URI Class Initialized
INFO - 2024-08-16 23:53:33 --> Router Class Initialized
INFO - 2024-08-16 23:53:33 --> Output Class Initialized
INFO - 2024-08-16 23:53:33 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:33 --> Input Class Initialized
INFO - 2024-08-16 23:53:33 --> Language Class Initialized
INFO - 2024-08-16 23:53:33 --> Loader Class Initialized
INFO - 2024-08-16 23:53:33 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:33 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:33 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:33 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:33 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:33 --> Controller Class Initialized
DEBUG - 2024-08-16 23:53:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-16 23:53:33 --> Config Class Initialized
INFO - 2024-08-16 23:53:33 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:33 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:33 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:33 --> URI Class Initialized
INFO - 2024-08-16 23:53:33 --> Router Class Initialized
INFO - 2024-08-16 23:53:33 --> Output Class Initialized
INFO - 2024-08-16 23:53:33 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:33 --> Input Class Initialized
INFO - 2024-08-16 23:53:33 --> Language Class Initialized
INFO - 2024-08-16 23:53:33 --> Loader Class Initialized
INFO - 2024-08-16 23:53:33 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:33 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:33 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:33 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:33 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:33 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:33 --> Controller Class Initialized
INFO - 2024-08-16 23:53:33 --> Model "User_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:53:33 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:53:34 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:53:34 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 23:53:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 23:53:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 23:53:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-16 23:53:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 23:53:34 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:34 --> Total execution time: 0.6864
INFO - 2024-08-16 23:53:36 --> Config Class Initialized
INFO - 2024-08-16 23:53:36 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:36 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:36 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:36 --> URI Class Initialized
INFO - 2024-08-16 23:53:36 --> Router Class Initialized
INFO - 2024-08-16 23:53:36 --> Output Class Initialized
INFO - 2024-08-16 23:53:36 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:36 --> Input Class Initialized
INFO - 2024-08-16 23:53:36 --> Language Class Initialized
INFO - 2024-08-16 23:53:36 --> Loader Class Initialized
INFO - 2024-08-16 23:53:36 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:36 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:36 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:36 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:36 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:36 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:36 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:36 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:36 --> Controller Class Initialized
INFO - 2024-08-16 23:53:36 --> Model "User_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:53:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-16 23:53:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 23:53:36 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:36 --> Total execution time: 0.1921
INFO - 2024-08-16 23:53:37 --> Config Class Initialized
INFO - 2024-08-16 23:53:37 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:37 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:37 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:37 --> URI Class Initialized
INFO - 2024-08-16 23:53:37 --> Router Class Initialized
INFO - 2024-08-16 23:53:37 --> Output Class Initialized
INFO - 2024-08-16 23:53:37 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:37 --> Input Class Initialized
INFO - 2024-08-16 23:53:37 --> Language Class Initialized
INFO - 2024-08-16 23:53:37 --> Loader Class Initialized
INFO - 2024-08-16 23:53:37 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:37 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:37 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:37 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:37 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:37 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:37 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:37 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:37 --> Controller Class Initialized
INFO - 2024-08-16 23:53:37 --> Model "User_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:53:37 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:53:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 23:53:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
ERROR - 2024-08-16 23:53:37 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 23
ERROR - 2024-08-16 23:53:37 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\simba\application\views\templates\topbar.php 30
INFO - 2024-08-16 23:53:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 23:53:37 --> File loaded: C:\xampp\htdocs\simba\application\views\report/reportinventaris.php
INFO - 2024-08-16 23:53:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 23:53:37 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:37 --> Total execution time: 0.1334
INFO - 2024-08-16 23:53:38 --> Config Class Initialized
INFO - 2024-08-16 23:53:38 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:38 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:38 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:38 --> URI Class Initialized
INFO - 2024-08-16 23:53:38 --> Router Class Initialized
INFO - 2024-08-16 23:53:38 --> Output Class Initialized
INFO - 2024-08-16 23:53:38 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:38 --> Input Class Initialized
INFO - 2024-08-16 23:53:38 --> Language Class Initialized
INFO - 2024-08-16 23:53:38 --> Loader Class Initialized
INFO - 2024-08-16 23:53:38 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:38 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:38 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:38 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:38 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:38 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:38 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:38 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:38 --> Controller Class Initialized
INFO - 2024-08-16 23:53:38 --> Model "User_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:53:38 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:53:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 23:53:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 23:53:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 23:53:38 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-16 23:53:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 23:53:38 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:38 --> Total execution time: 0.1213
INFO - 2024-08-16 23:53:40 --> Config Class Initialized
INFO - 2024-08-16 23:53:40 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:53:40 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:53:40 --> Utf8 Class Initialized
INFO - 2024-08-16 23:53:40 --> URI Class Initialized
INFO - 2024-08-16 23:53:40 --> Router Class Initialized
INFO - 2024-08-16 23:53:40 --> Output Class Initialized
INFO - 2024-08-16 23:53:40 --> Security Class Initialized
DEBUG - 2024-08-16 23:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:53:40 --> Input Class Initialized
INFO - 2024-08-16 23:53:40 --> Language Class Initialized
INFO - 2024-08-16 23:53:40 --> Loader Class Initialized
INFO - 2024-08-16 23:53:40 --> Helper loaded: url_helper
INFO - 2024-08-16 23:53:40 --> Helper loaded: file_helper
INFO - 2024-08-16 23:53:40 --> Helper loaded: security_helper
INFO - 2024-08-16 23:53:40 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:53:40 --> Database Driver Class Initialized
INFO - 2024-08-16 23:53:40 --> Email Class Initialized
DEBUG - 2024-08-16 23:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:53:40 --> Helper loaded: form_helper
INFO - 2024-08-16 23:53:40 --> Form Validation Class Initialized
INFO - 2024-08-16 23:53:40 --> Controller Class Initialized
INFO - 2024-08-16 23:53:40 --> Model "User_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:53:40 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:53:42 --> Final output sent to browser
DEBUG - 2024-08-16 23:53:42 --> Total execution time: 1.8329
INFO - 2024-08-16 23:56:07 --> Config Class Initialized
INFO - 2024-08-16 23:56:07 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:56:07 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:56:07 --> Utf8 Class Initialized
INFO - 2024-08-16 23:56:07 --> URI Class Initialized
INFO - 2024-08-16 23:56:07 --> Router Class Initialized
INFO - 2024-08-16 23:56:07 --> Output Class Initialized
INFO - 2024-08-16 23:56:07 --> Security Class Initialized
DEBUG - 2024-08-16 23:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:56:07 --> Input Class Initialized
INFO - 2024-08-16 23:56:07 --> Language Class Initialized
INFO - 2024-08-16 23:56:07 --> Loader Class Initialized
INFO - 2024-08-16 23:56:07 --> Helper loaded: url_helper
INFO - 2024-08-16 23:56:07 --> Helper loaded: file_helper
INFO - 2024-08-16 23:56:07 --> Helper loaded: security_helper
INFO - 2024-08-16 23:56:07 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:56:07 --> Database Driver Class Initialized
INFO - 2024-08-16 23:56:07 --> Email Class Initialized
DEBUG - 2024-08-16 23:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:56:07 --> Helper loaded: form_helper
INFO - 2024-08-16 23:56:07 --> Form Validation Class Initialized
INFO - 2024-08-16 23:56:07 --> Controller Class Initialized
INFO - 2024-08-16 23:56:07 --> Model "User_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:56:07 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:56:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:56:07 --> Final output sent to browser
DEBUG - 2024-08-16 23:56:07 --> Total execution time: 0.1422
INFO - 2024-08-16 23:56:40 --> Config Class Initialized
INFO - 2024-08-16 23:56:40 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:56:40 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:56:40 --> Utf8 Class Initialized
INFO - 2024-08-16 23:56:40 --> URI Class Initialized
INFO - 2024-08-16 23:56:40 --> Router Class Initialized
INFO - 2024-08-16 23:56:40 --> Output Class Initialized
INFO - 2024-08-16 23:56:40 --> Security Class Initialized
DEBUG - 2024-08-16 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:56:40 --> Input Class Initialized
INFO - 2024-08-16 23:56:40 --> Language Class Initialized
INFO - 2024-08-16 23:56:40 --> Loader Class Initialized
INFO - 2024-08-16 23:56:40 --> Helper loaded: url_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: file_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: security_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:56:40 --> Database Driver Class Initialized
INFO - 2024-08-16 23:56:40 --> Email Class Initialized
DEBUG - 2024-08-16 23:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:56:40 --> Helper loaded: form_helper
INFO - 2024-08-16 23:56:40 --> Form Validation Class Initialized
INFO - 2024-08-16 23:56:40 --> Controller Class Initialized
INFO - 2024-08-16 23:56:40 --> Model "User_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:56:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:56:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-16 23:56:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-16 23:56:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-16 23:56:40 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakinventaris.php
INFO - 2024-08-16 23:56:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-16 23:56:40 --> Final output sent to browser
DEBUG - 2024-08-16 23:56:40 --> Total execution time: 0.0847
INFO - 2024-08-16 23:56:40 --> Config Class Initialized
INFO - 2024-08-16 23:56:40 --> Hooks Class Initialized
DEBUG - 2024-08-16 23:56:40 --> UTF-8 Support Enabled
INFO - 2024-08-16 23:56:40 --> Utf8 Class Initialized
INFO - 2024-08-16 23:56:40 --> URI Class Initialized
INFO - 2024-08-16 23:56:40 --> Router Class Initialized
INFO - 2024-08-16 23:56:40 --> Output Class Initialized
INFO - 2024-08-16 23:56:40 --> Security Class Initialized
DEBUG - 2024-08-16 23:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-16 23:56:40 --> Input Class Initialized
INFO - 2024-08-16 23:56:40 --> Language Class Initialized
INFO - 2024-08-16 23:56:40 --> Loader Class Initialized
INFO - 2024-08-16 23:56:40 --> Helper loaded: url_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: file_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: security_helper
INFO - 2024-08-16 23:56:40 --> Helper loaded: wpu_helper
INFO - 2024-08-16 23:56:40 --> Database Driver Class Initialized
INFO - 2024-08-16 23:56:40 --> Email Class Initialized
DEBUG - 2024-08-16 23:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-16 23:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-16 23:56:40 --> Helper loaded: form_helper
INFO - 2024-08-16 23:56:40 --> Form Validation Class Initialized
INFO - 2024-08-16 23:56:40 --> Controller Class Initialized
INFO - 2024-08-16 23:56:40 --> Model "User_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Permintaan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Faktur_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Pesanan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Supplier_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Jenis_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Inventaris_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Barang_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Perbaikan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Penghapusan_model" initialized
INFO - 2024-08-16 23:56:40 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-16 23:56:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-16 23:56:41 --> Final output sent to browser
DEBUG - 2024-08-16 23:56:41 --> Total execution time: 0.1455
