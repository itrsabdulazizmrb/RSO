<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-16 03:19:29 --> Config Class Initialized
INFO - 2024-11-16 03:19:29 --> Hooks Class Initialized
DEBUG - 2024-11-16 03:19:29 --> UTF-8 Support Enabled
INFO - 2024-11-16 03:19:29 --> Utf8 Class Initialized
INFO - 2024-11-16 03:19:29 --> URI Class Initialized
DEBUG - 2024-11-16 03:19:29 --> No URI present. Default controller set.
INFO - 2024-11-16 03:19:29 --> Router Class Initialized
INFO - 2024-11-16 03:19:29 --> Output Class Initialized
INFO - 2024-11-16 03:19:29 --> Security Class Initialized
DEBUG - 2024-11-16 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-16 03:19:29 --> Input Class Initialized
INFO - 2024-11-16 03:19:29 --> Language Class Initialized
INFO - 2024-11-16 03:19:29 --> Loader Class Initialized
INFO - 2024-11-16 03:19:29 --> Helper loaded: url_helper
INFO - 2024-11-16 03:19:29 --> Helper loaded: file_helper
INFO - 2024-11-16 03:19:29 --> Helper loaded: security_helper
INFO - 2024-11-16 03:19:29 --> Helper loaded: wpu_helper
INFO - 2024-11-16 03:19:29 --> Database Driver Class Initialized
INFO - 2024-11-16 03:19:29 --> Email Class Initialized
DEBUG - 2024-11-16 03:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-16 03:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-16 03:19:29 --> Helper loaded: form_helper
INFO - 2024-11-16 03:19:29 --> Form Validation Class Initialized
INFO - 2024-11-16 03:19:29 --> Controller Class Initialized
DEBUG - 2024-11-16 03:19:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-16 03:19:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-16 03:19:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-16 03:19:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-16 03:19:29 --> Final output sent to browser
DEBUG - 2024-11-16 03:19:29 --> Total execution time: 0.4337
INFO - 2024-11-16 08:11:34 --> Config Class Initialized
INFO - 2024-11-16 08:11:34 --> Hooks Class Initialized
DEBUG - 2024-11-16 08:11:34 --> UTF-8 Support Enabled
INFO - 2024-11-16 08:11:34 --> Utf8 Class Initialized
INFO - 2024-11-16 08:11:34 --> URI Class Initialized
DEBUG - 2024-11-16 08:11:34 --> No URI present. Default controller set.
INFO - 2024-11-16 08:11:34 --> Router Class Initialized
INFO - 2024-11-16 08:11:34 --> Output Class Initialized
INFO - 2024-11-16 08:11:34 --> Security Class Initialized
DEBUG - 2024-11-16 08:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-16 08:11:34 --> Input Class Initialized
INFO - 2024-11-16 08:11:34 --> Language Class Initialized
INFO - 2024-11-16 08:11:34 --> Loader Class Initialized
INFO - 2024-11-16 08:11:34 --> Helper loaded: url_helper
INFO - 2024-11-16 08:11:34 --> Helper loaded: file_helper
INFO - 2024-11-16 08:11:34 --> Helper loaded: security_helper
INFO - 2024-11-16 08:11:34 --> Helper loaded: wpu_helper
INFO - 2024-11-16 08:11:34 --> Database Driver Class Initialized
INFO - 2024-11-16 08:11:35 --> Email Class Initialized
DEBUG - 2024-11-16 08:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-16 08:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-16 08:11:35 --> Helper loaded: form_helper
INFO - 2024-11-16 08:11:35 --> Form Validation Class Initialized
INFO - 2024-11-16 08:11:35 --> Controller Class Initialized
DEBUG - 2024-11-16 08:11:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-16 08:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-16 08:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-16 08:11:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-16 08:11:35 --> Final output sent to browser
DEBUG - 2024-11-16 08:11:35 --> Total execution time: 0.4348
INFO - 2024-11-16 10:45:03 --> Config Class Initialized
INFO - 2024-11-16 10:45:03 --> Hooks Class Initialized
DEBUG - 2024-11-16 10:45:03 --> UTF-8 Support Enabled
INFO - 2024-11-16 10:45:03 --> Utf8 Class Initialized
INFO - 2024-11-16 10:45:03 --> URI Class Initialized
DEBUG - 2024-11-16 10:45:03 --> No URI present. Default controller set.
INFO - 2024-11-16 10:45:03 --> Router Class Initialized
INFO - 2024-11-16 10:45:03 --> Output Class Initialized
INFO - 2024-11-16 10:45:03 --> Security Class Initialized
DEBUG - 2024-11-16 10:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-16 10:45:03 --> Input Class Initialized
INFO - 2024-11-16 10:45:03 --> Language Class Initialized
INFO - 2024-11-16 10:45:03 --> Loader Class Initialized
INFO - 2024-11-16 10:45:03 --> Helper loaded: url_helper
INFO - 2024-11-16 10:45:03 --> Helper loaded: file_helper
INFO - 2024-11-16 10:45:03 --> Helper loaded: security_helper
INFO - 2024-11-16 10:45:03 --> Helper loaded: wpu_helper
INFO - 2024-11-16 10:45:03 --> Database Driver Class Initialized
INFO - 2024-11-16 10:45:04 --> Email Class Initialized
DEBUG - 2024-11-16 10:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-16 10:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-16 10:45:04 --> Helper loaded: form_helper
INFO - 2024-11-16 10:45:04 --> Form Validation Class Initialized
INFO - 2024-11-16 10:45:04 --> Controller Class Initialized
DEBUG - 2024-11-16 10:45:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-16 10:45:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-16 10:45:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-16 10:45:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-16 10:45:04 --> Final output sent to browser
DEBUG - 2024-11-16 10:45:04 --> Total execution time: 0.4233
