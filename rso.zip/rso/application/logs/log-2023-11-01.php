<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-01 00:18:58 --> 404 Page Not Found: Path-to-your-imagejpg/index
ERROR - 2023-11-01 00:25:02 --> 404 Page Not Found: Path-to-your-imagejpg/index
ERROR - 2023-11-01 00:25:24 --> 404 Page Not Found: Path-to-your-imagejpg/index
ERROR - 2023-11-01 00:25:31 --> 404 Page Not Found: Path-to-your-imagejpg/index
ERROR - 2023-11-01 00:31:58 --> Query error: Unknown column 'Sudah' in 'where clause' - Invalid query: SELECT COUNT(*) as total_status FROM tbl_faktur WHERE status = Sudah
ERROR - 2023-11-01 00:32:58 --> Query error: Unknown column 'sudah' in 'where clause' - Invalid query: SELECT COUNT(*) as total_status FROM tbl_faktur WHERE status = sudah
ERROR - 2023-11-01 00:32:59 --> Query error: Unknown column 'sudah' in 'where clause' - Invalid query: SELECT COUNT(*) as total_status FROM tbl_faktur WHERE status = sudah
ERROR - 2023-11-01 00:34:26 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 00:35:46 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 00:37:27 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 01:41:25 --> 404 Page Not Found: Admin/updateTotalBayar
ERROR - 2023-11-01 01:41:38 --> 404 Page Not Found: Faktur/index
ERROR - 2023-11-01 01:41:41 --> 404 Page Not Found: Faktur/index
ERROR - 2023-11-01 01:43:24 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 04:05:17 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:05:42 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:05:43 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:05:43 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:05:43 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:05:43 --> Severity: Compile Error --> Cannot redeclare Admin::faktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 561
ERROR - 2023-11-01 04:08:05 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\simba\application\views\admin\dashboard.php 269
ERROR - 2023-11-01 05:16:00 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 05:30:31 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\simba\application\controllers\Admin.php 648
ERROR - 2023-11-01 05:30:33 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\simba\application\controllers\Admin.php 648
ERROR - 2023-11-01 05:31:04 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 648
ERROR - 2023-11-01 05:31:19 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\simba\application\controllers\Admin.php 648
ERROR - 2023-11-01 05:49:33 --> Severity: error --> Exception: Call to undefined method Faktur_model::updateFaktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 639
ERROR - 2023-11-01 05:57:20 --> 404 Page Not Found: Assets/Monitoring.png
ERROR - 2023-11-01 05:57:28 --> 404 Page Not Found: Assets/monitoring.png
ERROR - 2023-11-01 05:57:30 --> 404 Page Not Found: Assets/monitoring.png
ERROR - 2023-11-01 05:57:47 --> 404 Page Not Found: Assets/monitor.png
ERROR - 2023-11-01 06:31:19 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 06:45:46 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 06:46:29 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 06:46:31 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-11-01 06:54:05 --> 404 Page Not Found: Assets/login.jpg
