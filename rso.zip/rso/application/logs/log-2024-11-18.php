<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-18 02:33:40 --> Config Class Initialized
INFO - 2024-11-18 02:33:40 --> Hooks Class Initialized
DEBUG - 2024-11-18 02:33:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 02:33:40 --> Utf8 Class Initialized
INFO - 2024-11-18 02:33:40 --> URI Class Initialized
DEBUG - 2024-11-18 02:33:40 --> No URI present. Default controller set.
INFO - 2024-11-18 02:33:40 --> Router Class Initialized
INFO - 2024-11-18 02:33:40 --> Output Class Initialized
INFO - 2024-11-18 02:33:40 --> Security Class Initialized
DEBUG - 2024-11-18 02:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 02:33:40 --> Input Class Initialized
INFO - 2024-11-18 02:33:40 --> Language Class Initialized
INFO - 2024-11-18 02:33:40 --> Loader Class Initialized
INFO - 2024-11-18 02:33:40 --> Helper loaded: url_helper
INFO - 2024-11-18 02:33:40 --> Helper loaded: file_helper
INFO - 2024-11-18 02:33:40 --> Helper loaded: security_helper
INFO - 2024-11-18 02:33:40 --> Helper loaded: wpu_helper
INFO - 2024-11-18 02:33:40 --> Database Driver Class Initialized
INFO - 2024-11-18 03:26:07 --> Config Class Initialized
INFO - 2024-11-18 03:26:07 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:07 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:07 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:07 --> URI Class Initialized
INFO - 2024-11-18 03:26:07 --> Router Class Initialized
INFO - 2024-11-18 03:26:07 --> Output Class Initialized
INFO - 2024-11-18 03:26:07 --> Config Class Initialized
INFO - 2024-11-18 03:26:07 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:07 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:07 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:07 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:07 --> Input Class Initialized
INFO - 2024-11-18 03:26:07 --> Language Class Initialized
INFO - 2024-11-18 03:26:07 --> Config Class Initialized
INFO - 2024-11-18 03:26:07 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:07 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:07 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:07 --> URI Class Initialized
INFO - 2024-11-18 03:26:07 --> Router Class Initialized
INFO - 2024-11-18 03:26:07 --> Output Class Initialized
INFO - 2024-11-18 03:26:07 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:07 --> Input Class Initialized
INFO - 2024-11-18 03:26:07 --> Language Class Initialized
ERROR - 2024-11-18 03:26:07 --> 404 Page Not Found: Installation/configuration.php.backup
ERROR - 2024-11-18 03:26:07 --> 404 Page Not Found: Envexample/index
INFO - 2024-11-18 03:26:07 --> URI Class Initialized
INFO - 2024-11-18 03:26:07 --> Router Class Initialized
INFO - 2024-11-18 03:26:07 --> Output Class Initialized
INFO - 2024-11-18 03:26:07 --> Config Class Initialized
INFO - 2024-11-18 03:26:07 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:07 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:07 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:07 --> URI Class Initialized
INFO - 2024-11-18 03:26:07 --> Router Class Initialized
INFO - 2024-11-18 03:26:07 --> Output Class Initialized
INFO - 2024-11-18 03:26:07 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:07 --> Input Class Initialized
INFO - 2024-11-18 03:26:07 --> Language Class Initialized
ERROR - 2024-11-18 03:26:07 --> 404 Page Not Found: Db/config.json.bak
INFO - 2024-11-18 03:26:07 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:07 --> Input Class Initialized
INFO - 2024-11-18 03:26:07 --> Language Class Initialized
ERROR - 2024-11-18 03:26:07 --> 404 Page Not Found: Common/config
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envbak/index
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Configphpbak/index
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Htdocs/config.php.disabled
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Resources/config.json
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Tmp/config.php.bak
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Awsenv/index
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
DEBUG - 2024-11-18 03:26:08 --> No URI present. Default controller set.
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envbackup/index
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Old/config.php
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Caches/configs
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Site/default
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Application/Common
INFO - 2024-11-18 03:26:08 --> Loader Class Initialized
INFO - 2024-11-18 03:26:08 --> Helper loaded: url_helper
INFO - 2024-11-18 03:26:08 --> Helper loaded: file_helper
INFO - 2024-11-18 03:26:08 --> Helper loaded: security_helper
INFO - 2024-11-18 03:26:08 --> Helper loaded: wpu_helper
INFO - 2024-11-18 03:26:08 --> Database Driver Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Textpattern/config.php.bkp
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: App/etc
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Webroot/config.php.old
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Database/config.php.orig
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Config/production.config.php
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: App/settings
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Backup/settings.php.bak
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envstage/index
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envdev/index
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envwww/index
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envlive/index
INFO - 2024-11-18 03:26:08 --> Config Class Initialized
INFO - 2024-11-18 03:26:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:08 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:08 --> URI Class Initialized
INFO - 2024-11-18 03:26:08 --> Router Class Initialized
INFO - 2024-11-18 03:26:08 --> Output Class Initialized
INFO - 2024-11-18 03:26:08 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:08 --> Input Class Initialized
INFO - 2024-11-18 03:26:08 --> Language Class Initialized
ERROR - 2024-11-18 03:26:08 --> 404 Page Not Found: Envprod/index
INFO - 2024-11-18 03:26:09 --> Config Class Initialized
INFO - 2024-11-18 03:26:09 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:09 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:09 --> URI Class Initialized
INFO - 2024-11-18 03:26:09 --> Router Class Initialized
INFO - 2024-11-18 03:26:09 --> Output Class Initialized
INFO - 2024-11-18 03:26:09 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:09 --> Input Class Initialized
INFO - 2024-11-18 03:26:09 --> Language Class Initialized
ERROR - 2024-11-18 03:26:09 --> 404 Page Not Found: App/etc
INFO - 2024-11-18 03:26:09 --> Config Class Initialized
INFO - 2024-11-18 03:26:09 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:09 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:09 --> URI Class Initialized
INFO - 2024-11-18 03:26:09 --> Router Class Initialized
INFO - 2024-11-18 03:26:09 --> Output Class Initialized
INFO - 2024-11-18 03:26:09 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:09 --> Input Class Initialized
INFO - 2024-11-18 03:26:09 --> Language Class Initialized
ERROR - 2024-11-18 03:26:09 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:26:09 --> Config Class Initialized
INFO - 2024-11-18 03:26:09 --> Hooks Class Initialized
INFO - 2024-11-18 03:26:09 --> Config Class Initialized
INFO - 2024-11-18 03:26:09 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:09 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:09 --> URI Class Initialized
DEBUG - 2024-11-18 03:26:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:09 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:09 --> Router Class Initialized
INFO - 2024-11-18 03:26:09 --> URI Class Initialized
INFO - 2024-11-18 03:26:09 --> Router Class Initialized
INFO - 2024-11-18 03:26:09 --> Output Class Initialized
INFO - 2024-11-18 03:26:09 --> Output Class Initialized
INFO - 2024-11-18 03:26:09 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:09 --> Input Class Initialized
INFO - 2024-11-18 03:26:09 --> Language Class Initialized
INFO - 2024-11-18 03:26:09 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:09 --> Input Class Initialized
INFO - 2024-11-18 03:26:09 --> Language Class Initialized
ERROR - 2024-11-18 03:26:09 --> 404 Page Not Found: Typo3conf/localconf.php.orig
ERROR - 2024-11-18 03:26:09 --> 404 Page Not Found: Envproductionlocal/index
INFO - 2024-11-18 03:26:10 --> Config Class Initialized
INFO - 2024-11-18 03:26:10 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:26:10 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:26:10 --> Utf8 Class Initialized
INFO - 2024-11-18 03:26:10 --> URI Class Initialized
INFO - 2024-11-18 03:26:10 --> Router Class Initialized
INFO - 2024-11-18 03:26:10 --> Output Class Initialized
INFO - 2024-11-18 03:26:10 --> Security Class Initialized
DEBUG - 2024-11-18 03:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:26:10 --> Input Class Initialized
INFO - 2024-11-18 03:26:10 --> Language Class Initialized
ERROR - 2024-11-18 03:26:10 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Sendgridenv/index
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Envsave/index
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Common/config
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Envproduction/index
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Backup/config.php.bak
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Envlive/index
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Envold/index
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Config/config_global.php.save
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> Config Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Config/settings.inc.php.backup
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Db/config.json.bak
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:40 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:40 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Backup/db.php.bak
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> URI Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Configphpbak/index
INFO - 2024-11-18 03:28:40 --> Router Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Caches/configs
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Security Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Database/config.php.orig
DEBUG - 2024-11-18 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:40 --> Input Class Initialized
INFO - 2024-11-18 03:28:40 --> Language Class Initialized
ERROR - 2024-11-18 03:28:40 --> 404 Page Not Found: Common/config
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
INFO - 2024-11-18 03:28:41 --> Config Class Initialized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
INFO - 2024-11-18 03:28:41 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: App/etc
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: App/etc
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: Envdevlocal/index
DEBUG - 2024-11-18 03:28:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:41 --> Utf8 Class Initialized
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: Envprodlocal/index
INFO - 2024-11-18 03:28:41 --> URI Class Initialized
INFO - 2024-11-18 03:28:41 --> Router Class Initialized
INFO - 2024-11-18 03:28:41 --> Output Class Initialized
INFO - 2024-11-18 03:28:41 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:41 --> Input Class Initialized
INFO - 2024-11-18 03:28:41 --> Language Class Initialized
ERROR - 2024-11-18 03:28:41 --> 404 Page Not Found: Envlocal/index
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: App/settings
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Application/Common
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Envdev/index
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Env_sample/index
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Envprod/index
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Envbak/index
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Backup/settings.php.bak
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Backup/database.php.bak
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Envdevelopmentlocal/index
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Config Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Hooks Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:44 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:44 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> URI Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: App/etc
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Router Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Envbackup/index
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Output Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-18 03:28:44 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:44 --> Input Class Initialized
INFO - 2024-11-18 03:28:44 --> Language Class Initialized
ERROR - 2024-11-18 03:28:44 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:28:45 --> Config Class Initialized
INFO - 2024-11-18 03:28:45 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:45 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:45 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:45 --> URI Class Initialized
INFO - 2024-11-18 03:28:45 --> Router Class Initialized
INFO - 2024-11-18 03:28:45 --> Output Class Initialized
INFO - 2024-11-18 03:28:45 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:45 --> Input Class Initialized
INFO - 2024-11-18 03:28:45 --> Language Class Initialized
ERROR - 2024-11-18 03:28:45 --> 404 Page Not Found: Configphp~/index
INFO - 2024-11-18 03:28:45 --> Config Class Initialized
INFO - 2024-11-18 03:28:45 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:45 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:45 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:45 --> Config Class Initialized
INFO - 2024-11-18 03:28:45 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:45 --> URI Class Initialized
INFO - 2024-11-18 03:28:45 --> Router Class Initialized
DEBUG - 2024-11-18 03:28:45 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:45 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:45 --> URI Class Initialized
INFO - 2024-11-18 03:28:45 --> Output Class Initialized
INFO - 2024-11-18 03:28:45 --> Router Class Initialized
INFO - 2024-11-18 03:28:45 --> Security Class Initialized
INFO - 2024-11-18 03:28:45 --> Output Class Initialized
DEBUG - 2024-11-18 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:45 --> Input Class Initialized
INFO - 2024-11-18 03:28:45 --> Language Class Initialized
INFO - 2024-11-18 03:28:45 --> Security Class Initialized
ERROR - 2024-11-18 03:28:45 --> 404 Page Not Found: App/config
DEBUG - 2024-11-18 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:45 --> Input Class Initialized
INFO - 2024-11-18 03:28:45 --> Language Class Initialized
ERROR - 2024-11-18 03:28:45 --> 404 Page Not Found: App/etc
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: App/config
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: Configoldphp/index
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: Backup/database.php.bak
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: Application/Common
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Config Class Initialized
INFO - 2024-11-18 03:28:46 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:46 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:46 --> URI Class Initialized
INFO - 2024-11-18 03:28:46 --> Router Class Initialized
INFO - 2024-11-18 03:28:46 --> Output Class Initialized
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: App/settings
INFO - 2024-11-18 03:28:46 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:46 --> Input Class Initialized
INFO - 2024-11-18 03:28:46 --> Language Class Initialized
ERROR - 2024-11-18 03:28:46 --> 404 Page Not Found: Backup/settings.php.bak
INFO - 2024-11-18 03:28:47 --> Config Class Initialized
INFO - 2024-11-18 03:28:47 --> Hooks Class Initialized
DEBUG - 2024-11-18 03:28:47 --> UTF-8 Support Enabled
INFO - 2024-11-18 03:28:47 --> Utf8 Class Initialized
INFO - 2024-11-18 03:28:47 --> URI Class Initialized
INFO - 2024-11-18 03:28:47 --> Router Class Initialized
INFO - 2024-11-18 03:28:47 --> Output Class Initialized
INFO - 2024-11-18 03:28:47 --> Security Class Initialized
DEBUG - 2024-11-18 03:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 03:28:47 --> Input Class Initialized
INFO - 2024-11-18 03:28:47 --> Language Class Initialized
ERROR - 2024-11-18 03:28:47 --> 404 Page Not Found: App/config
INFO - 2024-11-18 06:40:56 --> Config Class Initialized
INFO - 2024-11-18 06:40:56 --> Hooks Class Initialized
DEBUG - 2024-11-18 06:40:56 --> UTF-8 Support Enabled
INFO - 2024-11-18 06:40:56 --> Utf8 Class Initialized
INFO - 2024-11-18 06:40:56 --> URI Class Initialized
DEBUG - 2024-11-18 06:40:56 --> No URI present. Default controller set.
INFO - 2024-11-18 06:40:56 --> Router Class Initialized
INFO - 2024-11-18 06:40:56 --> Output Class Initialized
INFO - 2024-11-18 06:40:56 --> Security Class Initialized
DEBUG - 2024-11-18 06:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 06:40:56 --> Input Class Initialized
INFO - 2024-11-18 06:40:56 --> Language Class Initialized
INFO - 2024-11-18 06:40:56 --> Loader Class Initialized
INFO - 2024-11-18 06:40:56 --> Helper loaded: url_helper
INFO - 2024-11-18 06:40:56 --> Helper loaded: file_helper
INFO - 2024-11-18 06:40:56 --> Helper loaded: security_helper
INFO - 2024-11-18 06:40:56 --> Helper loaded: wpu_helper
INFO - 2024-11-18 06:40:56 --> Database Driver Class Initialized
INFO - 2024-11-18 08:08:33 --> Config Class Initialized
INFO - 2024-11-18 08:08:33 --> Hooks Class Initialized
DEBUG - 2024-11-18 08:08:33 --> UTF-8 Support Enabled
INFO - 2024-11-18 08:08:33 --> Utf8 Class Initialized
INFO - 2024-11-18 08:08:33 --> URI Class Initialized
DEBUG - 2024-11-18 08:08:33 --> No URI present. Default controller set.
INFO - 2024-11-18 08:08:33 --> Router Class Initialized
INFO - 2024-11-18 08:08:33 --> Output Class Initialized
INFO - 2024-11-18 08:08:33 --> Security Class Initialized
DEBUG - 2024-11-18 08:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 08:08:33 --> Input Class Initialized
INFO - 2024-11-18 08:08:33 --> Language Class Initialized
INFO - 2024-11-18 08:08:33 --> Loader Class Initialized
INFO - 2024-11-18 08:08:33 --> Helper loaded: url_helper
INFO - 2024-11-18 08:08:33 --> Helper loaded: file_helper
INFO - 2024-11-18 08:08:33 --> Helper loaded: security_helper
INFO - 2024-11-18 08:08:33 --> Helper loaded: wpu_helper
INFO - 2024-11-18 08:08:33 --> Database Driver Class Initialized
INFO - 2024-11-18 08:09:12 --> Config Class Initialized
INFO - 2024-11-18 08:09:12 --> Hooks Class Initialized
DEBUG - 2024-11-18 08:09:12 --> UTF-8 Support Enabled
INFO - 2024-11-18 08:09:12 --> Utf8 Class Initialized
INFO - 2024-11-18 08:09:12 --> URI Class Initialized
DEBUG - 2024-11-18 08:09:12 --> No URI present. Default controller set.
INFO - 2024-11-18 08:09:12 --> Router Class Initialized
INFO - 2024-11-18 08:09:12 --> Output Class Initialized
INFO - 2024-11-18 08:09:12 --> Security Class Initialized
DEBUG - 2024-11-18 08:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 08:09:12 --> Input Class Initialized
INFO - 2024-11-18 08:09:12 --> Language Class Initialized
INFO - 2024-11-18 08:09:12 --> Loader Class Initialized
INFO - 2024-11-18 08:09:12 --> Helper loaded: url_helper
INFO - 2024-11-18 08:09:12 --> Helper loaded: file_helper
INFO - 2024-11-18 08:09:12 --> Helper loaded: security_helper
INFO - 2024-11-18 08:09:12 --> Helper loaded: wpu_helper
INFO - 2024-11-18 08:09:12 --> Database Driver Class Initialized
