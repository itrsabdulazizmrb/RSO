<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-24 08:05:40 --> Config Class Initialized
INFO - 2024-11-24 08:05:40 --> Hooks Class Initialized
DEBUG - 2024-11-24 08:05:40 --> UTF-8 Support Enabled
INFO - 2024-11-24 08:05:40 --> Utf8 Class Initialized
INFO - 2024-11-24 08:05:40 --> URI Class Initialized
DEBUG - 2024-11-24 08:05:40 --> No URI present. Default controller set.
INFO - 2024-11-24 08:05:40 --> Router Class Initialized
INFO - 2024-11-24 08:05:40 --> Output Class Initialized
INFO - 2024-11-24 08:05:40 --> Security Class Initialized
DEBUG - 2024-11-24 08:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 08:05:40 --> Input Class Initialized
INFO - 2024-11-24 08:05:40 --> Language Class Initialized
INFO - 2024-11-24 08:05:40 --> Loader Class Initialized
INFO - 2024-11-24 08:05:40 --> Helper loaded: url_helper
INFO - 2024-11-24 08:05:40 --> Helper loaded: file_helper
INFO - 2024-11-24 08:05:40 --> Helper loaded: security_helper
INFO - 2024-11-24 08:05:40 --> Helper loaded: wpu_helper
INFO - 2024-11-24 08:05:40 --> Database Driver Class Initialized
INFO - 2024-11-24 08:05:41 --> Email Class Initialized
DEBUG - 2024-11-24 08:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-24 08:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-24 08:05:41 --> Helper loaded: form_helper
INFO - 2024-11-24 08:05:41 --> Form Validation Class Initialized
INFO - 2024-11-24 08:05:41 --> Controller Class Initialized
DEBUG - 2024-11-24 08:05:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-24 08:05:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-24 08:05:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-24 08:05:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-24 08:05:41 --> Final output sent to browser
DEBUG - 2024-11-24 08:05:41 --> Total execution time: 0.3995
INFO - 2024-11-24 13:10:29 --> Config Class Initialized
INFO - 2024-11-24 13:10:29 --> Hooks Class Initialized
DEBUG - 2024-11-24 13:10:29 --> UTF-8 Support Enabled
INFO - 2024-11-24 13:10:29 --> Utf8 Class Initialized
INFO - 2024-11-24 13:10:29 --> URI Class Initialized
DEBUG - 2024-11-24 13:10:29 --> No URI present. Default controller set.
INFO - 2024-11-24 13:10:29 --> Router Class Initialized
INFO - 2024-11-24 13:10:29 --> Output Class Initialized
INFO - 2024-11-24 13:10:29 --> Security Class Initialized
DEBUG - 2024-11-24 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 13:10:29 --> Input Class Initialized
INFO - 2024-11-24 13:10:29 --> Language Class Initialized
INFO - 2024-11-24 13:10:29 --> Loader Class Initialized
INFO - 2024-11-24 13:10:29 --> Helper loaded: url_helper
INFO - 2024-11-24 13:10:29 --> Helper loaded: file_helper
INFO - 2024-11-24 13:10:29 --> Helper loaded: security_helper
INFO - 2024-11-24 13:10:29 --> Helper loaded: wpu_helper
INFO - 2024-11-24 13:10:29 --> Database Driver Class Initialized
INFO - 2024-11-24 13:10:30 --> Email Class Initialized
DEBUG - 2024-11-24 13:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-24 13:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-24 13:10:30 --> Helper loaded: form_helper
INFO - 2024-11-24 13:10:30 --> Form Validation Class Initialized
INFO - 2024-11-24 13:10:30 --> Controller Class Initialized
DEBUG - 2024-11-24 13:10:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-24 13:10:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-24 13:10:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-24 13:10:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-24 13:10:30 --> Final output sent to browser
DEBUG - 2024-11-24 13:10:30 --> Total execution time: 0.4153
INFO - 2024-11-24 22:57:21 --> Config Class Initialized
INFO - 2024-11-24 22:57:21 --> Hooks Class Initialized
DEBUG - 2024-11-24 22:57:21 --> UTF-8 Support Enabled
INFO - 2024-11-24 22:57:21 --> Utf8 Class Initialized
INFO - 2024-11-24 22:57:21 --> URI Class Initialized
DEBUG - 2024-11-24 22:57:21 --> No URI present. Default controller set.
INFO - 2024-11-24 22:57:21 --> Router Class Initialized
INFO - 2024-11-24 22:57:21 --> Output Class Initialized
INFO - 2024-11-24 22:57:21 --> Security Class Initialized
DEBUG - 2024-11-24 22:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 22:57:21 --> Input Class Initialized
INFO - 2024-11-24 22:57:21 --> Language Class Initialized
INFO - 2024-11-24 22:57:21 --> Loader Class Initialized
INFO - 2024-11-24 22:57:21 --> Helper loaded: url_helper
INFO - 2024-11-24 22:57:21 --> Helper loaded: file_helper
INFO - 2024-11-24 22:57:21 --> Helper loaded: security_helper
INFO - 2024-11-24 22:57:21 --> Helper loaded: wpu_helper
INFO - 2024-11-24 22:57:21 --> Database Driver Class Initialized
INFO - 2024-11-24 23:01:13 --> Config Class Initialized
INFO - 2024-11-24 23:01:13 --> Hooks Class Initialized
DEBUG - 2024-11-24 23:01:13 --> UTF-8 Support Enabled
INFO - 2024-11-24 23:01:13 --> Utf8 Class Initialized
INFO - 2024-11-24 23:01:13 --> URI Class Initialized
DEBUG - 2024-11-24 23:01:13 --> No URI present. Default controller set.
INFO - 2024-11-24 23:01:13 --> Router Class Initialized
INFO - 2024-11-24 23:01:13 --> Output Class Initialized
INFO - 2024-11-24 23:01:13 --> Security Class Initialized
DEBUG - 2024-11-24 23:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 23:01:13 --> Input Class Initialized
INFO - 2024-11-24 23:01:13 --> Language Class Initialized
INFO - 2024-11-24 23:01:13 --> Loader Class Initialized
INFO - 2024-11-24 23:01:13 --> Helper loaded: url_helper
INFO - 2024-11-24 23:01:13 --> Helper loaded: file_helper
INFO - 2024-11-24 23:01:13 --> Helper loaded: security_helper
INFO - 2024-11-24 23:01:13 --> Helper loaded: wpu_helper
INFO - 2024-11-24 23:01:13 --> Database Driver Class Initialized
INFO - 2024-11-24 23:05:26 --> Config Class Initialized
INFO - 2024-11-24 23:05:26 --> Hooks Class Initialized
DEBUG - 2024-11-24 23:05:26 --> UTF-8 Support Enabled
INFO - 2024-11-24 23:05:26 --> Utf8 Class Initialized
INFO - 2024-11-24 23:05:26 --> URI Class Initialized
DEBUG - 2024-11-24 23:05:26 --> No URI present. Default controller set.
INFO - 2024-11-24 23:05:26 --> Router Class Initialized
INFO - 2024-11-24 23:05:26 --> Output Class Initialized
INFO - 2024-11-24 23:05:26 --> Security Class Initialized
DEBUG - 2024-11-24 23:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 23:05:26 --> Input Class Initialized
INFO - 2024-11-24 23:05:26 --> Language Class Initialized
INFO - 2024-11-24 23:05:26 --> Loader Class Initialized
INFO - 2024-11-24 23:05:26 --> Helper loaded: url_helper
INFO - 2024-11-24 23:05:26 --> Helper loaded: file_helper
INFO - 2024-11-24 23:05:26 --> Helper loaded: security_helper
INFO - 2024-11-24 23:05:26 --> Helper loaded: wpu_helper
INFO - 2024-11-24 23:05:26 --> Database Driver Class Initialized
ERROR - 2024-11-24 23:05:33 --> Unable to connect to the database
INFO - 2024-11-24 23:05:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-24 23:06:12 --> Config Class Initialized
INFO - 2024-11-24 23:06:12 --> Hooks Class Initialized
DEBUG - 2024-11-24 23:06:12 --> UTF-8 Support Enabled
INFO - 2024-11-24 23:06:12 --> Utf8 Class Initialized
INFO - 2024-11-24 23:06:12 --> URI Class Initialized
DEBUG - 2024-11-24 23:06:12 --> No URI present. Default controller set.
INFO - 2024-11-24 23:06:12 --> Router Class Initialized
INFO - 2024-11-24 23:06:12 --> Output Class Initialized
INFO - 2024-11-24 23:06:12 --> Security Class Initialized
DEBUG - 2024-11-24 23:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 23:06:12 --> Input Class Initialized
INFO - 2024-11-24 23:06:12 --> Language Class Initialized
INFO - 2024-11-24 23:06:12 --> Loader Class Initialized
INFO - 2024-11-24 23:06:12 --> Helper loaded: url_helper
INFO - 2024-11-24 23:06:12 --> Helper loaded: file_helper
INFO - 2024-11-24 23:06:12 --> Helper loaded: security_helper
INFO - 2024-11-24 23:06:12 --> Helper loaded: wpu_helper
INFO - 2024-11-24 23:06:12 --> Database Driver Class Initialized
ERROR - 2024-11-24 23:06:14 --> Unable to connect to the database
INFO - 2024-11-24 23:06:14 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-24 23:06:15 --> Config Class Initialized
INFO - 2024-11-24 23:06:15 --> Hooks Class Initialized
DEBUG - 2024-11-24 23:06:15 --> UTF-8 Support Enabled
INFO - 2024-11-24 23:06:15 --> Utf8 Class Initialized
INFO - 2024-11-24 23:06:15 --> URI Class Initialized
DEBUG - 2024-11-24 23:06:15 --> No URI present. Default controller set.
INFO - 2024-11-24 23:06:15 --> Router Class Initialized
INFO - 2024-11-24 23:06:15 --> Output Class Initialized
INFO - 2024-11-24 23:06:15 --> Security Class Initialized
DEBUG - 2024-11-24 23:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-24 23:06:15 --> Input Class Initialized
INFO - 2024-11-24 23:06:15 --> Language Class Initialized
INFO - 2024-11-24 23:06:15 --> Loader Class Initialized
INFO - 2024-11-24 23:06:15 --> Helper loaded: url_helper
INFO - 2024-11-24 23:06:15 --> Helper loaded: file_helper
INFO - 2024-11-24 23:06:15 --> Helper loaded: security_helper
INFO - 2024-11-24 23:06:15 --> Helper loaded: wpu_helper
INFO - 2024-11-24 23:06:15 --> Database Driver Class Initialized
ERROR - 2024-11-24 23:06:18 --> Unable to connect to the database
INFO - 2024-11-24 23:06:18 --> Language file loaded: language/english/db_lang.php
