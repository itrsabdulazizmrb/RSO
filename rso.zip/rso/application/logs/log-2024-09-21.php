<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-21 01:11:12 --> Config Class Initialized
INFO - 2024-09-21 01:11:12 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:11:12 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:11:12 --> Utf8 Class Initialized
INFO - 2024-09-21 01:11:12 --> URI Class Initialized
DEBUG - 2024-09-21 01:11:12 --> No URI present. Default controller set.
INFO - 2024-09-21 01:11:12 --> Router Class Initialized
INFO - 2024-09-21 01:11:12 --> Output Class Initialized
INFO - 2024-09-21 01:11:12 --> Security Class Initialized
DEBUG - 2024-09-21 01:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:11:12 --> Input Class Initialized
INFO - 2024-09-21 01:11:12 --> Language Class Initialized
INFO - 2024-09-21 01:11:12 --> Loader Class Initialized
INFO - 2024-09-21 01:11:12 --> Helper loaded: url_helper
INFO - 2024-09-21 01:11:12 --> Helper loaded: file_helper
INFO - 2024-09-21 01:11:12 --> Helper loaded: security_helper
INFO - 2024-09-21 01:11:12 --> Helper loaded: wpu_helper
INFO - 2024-09-21 01:11:12 --> Database Driver Class Initialized
ERROR - 2024-09-21 01:11:43 --> Unable to connect to the database
INFO - 2024-09-21 01:11:43 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 01:57:42 --> Config Class Initialized
INFO - 2024-09-21 01:57:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:42 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:42 --> URI Class Initialized
INFO - 2024-09-21 01:57:42 --> Router Class Initialized
INFO - 2024-09-21 01:57:42 --> Output Class Initialized
INFO - 2024-09-21 01:57:42 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:42 --> Input Class Initialized
INFO - 2024-09-21 01:57:42 --> Language Class Initialized
ERROR - 2024-09-21 01:57:42 --> 404 Page Not Found: 2017zip/index
INFO - 2024-09-21 01:57:42 --> Config Class Initialized
INFO - 2024-09-21 01:57:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:42 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:42 --> URI Class Initialized
INFO - 2024-09-21 01:57:42 --> Router Class Initialized
INFO - 2024-09-21 01:57:42 --> Output Class Initialized
INFO - 2024-09-21 01:57:42 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:42 --> Input Class Initialized
INFO - 2024-09-21 01:57:42 --> Language Class Initialized
ERROR - 2024-09-21 01:57:42 --> 404 Page Not Found: 2022zip/index
INFO - 2024-09-21 01:57:43 --> Config Class Initialized
INFO - 2024-09-21 01:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:43 --> URI Class Initialized
INFO - 2024-09-21 01:57:43 --> Router Class Initialized
INFO - 2024-09-21 01:57:43 --> Output Class Initialized
INFO - 2024-09-21 01:57:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:43 --> Input Class Initialized
INFO - 2024-09-21 01:57:43 --> Language Class Initialized
ERROR - 2024-09-21 01:57:43 --> 404 Page Not Found: Azip/index
INFO - 2024-09-21 01:57:43 --> Config Class Initialized
INFO - 2024-09-21 01:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:43 --> URI Class Initialized
INFO - 2024-09-21 01:57:43 --> Router Class Initialized
INFO - 2024-09-21 01:57:43 --> Output Class Initialized
INFO - 2024-09-21 01:57:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:43 --> Input Class Initialized
INFO - 2024-09-21 01:57:43 --> Language Class Initialized
ERROR - 2024-09-21 01:57:43 --> 404 Page Not Found: Wwwzip/index
INFO - 2024-09-21 01:57:43 --> Config Class Initialized
INFO - 2024-09-21 01:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:43 --> URI Class Initialized
INFO - 2024-09-21 01:57:43 --> Router Class Initialized
INFO - 2024-09-21 01:57:43 --> Output Class Initialized
INFO - 2024-09-21 01:57:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:43 --> Input Class Initialized
INFO - 2024-09-21 01:57:43 --> Language Class Initialized
ERROR - 2024-09-21 01:57:43 --> 404 Page Not Found: Backupzip/index
INFO - 2024-09-21 01:57:44 --> Config Class Initialized
INFO - 2024-09-21 01:57:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:44 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:44 --> URI Class Initialized
INFO - 2024-09-21 01:57:44 --> Router Class Initialized
INFO - 2024-09-21 01:57:44 --> Output Class Initialized
INFO - 2024-09-21 01:57:44 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:44 --> Input Class Initialized
INFO - 2024-09-21 01:57:44 --> Language Class Initialized
ERROR - 2024-09-21 01:57:44 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomzip/index
INFO - 2024-09-21 01:57:44 --> Config Class Initialized
INFO - 2024-09-21 01:57:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:44 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:44 --> URI Class Initialized
INFO - 2024-09-21 01:57:44 --> Router Class Initialized
INFO - 2024-09-21 01:57:44 --> Output Class Initialized
INFO - 2024-09-21 01:57:44 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:44 --> Input Class Initialized
INFO - 2024-09-21 01:57:44 --> Language Class Initialized
ERROR - 2024-09-21 01:57:44 --> 404 Page Not Found: 2019zip/index
INFO - 2024-09-21 01:57:45 --> Config Class Initialized
INFO - 2024-09-21 01:57:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:45 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:45 --> URI Class Initialized
INFO - 2024-09-21 01:57:45 --> Router Class Initialized
INFO - 2024-09-21 01:57:45 --> Output Class Initialized
INFO - 2024-09-21 01:57:45 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:45 --> Input Class Initialized
INFO - 2024-09-21 01:57:45 --> Language Class Initialized
ERROR - 2024-09-21 01:57:45 --> 404 Page Not Found: Storezip/index
INFO - 2024-09-21 01:57:45 --> Config Class Initialized
INFO - 2024-09-21 01:57:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:45 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:45 --> URI Class Initialized
INFO - 2024-09-21 01:57:45 --> Router Class Initialized
INFO - 2024-09-21 01:57:45 --> Output Class Initialized
INFO - 2024-09-21 01:57:45 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:45 --> Input Class Initialized
INFO - 2024-09-21 01:57:45 --> Language Class Initialized
ERROR - 2024-09-21 01:57:45 --> 404 Page Not Found: Sitezip/index
INFO - 2024-09-21 01:57:46 --> Config Class Initialized
INFO - 2024-09-21 01:57:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:46 --> URI Class Initialized
INFO - 2024-09-21 01:57:46 --> Router Class Initialized
INFO - 2024-09-21 01:57:46 --> Output Class Initialized
INFO - 2024-09-21 01:57:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:46 --> Input Class Initialized
INFO - 2024-09-21 01:57:46 --> Language Class Initialized
ERROR - 2024-09-21 01:57:46 --> 404 Page Not Found: 1zip/index
INFO - 2024-09-21 01:57:46 --> Config Class Initialized
INFO - 2024-09-21 01:57:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:46 --> URI Class Initialized
INFO - 2024-09-21 01:57:46 --> Router Class Initialized
INFO - 2024-09-21 01:57:46 --> Output Class Initialized
INFO - 2024-09-21 01:57:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:46 --> Input Class Initialized
INFO - 2024-09-21 01:57:46 --> Language Class Initialized
ERROR - 2024-09-21 01:57:46 --> 404 Page Not Found: 2024zip/index
INFO - 2024-09-21 01:57:47 --> Config Class Initialized
INFO - 2024-09-21 01:57:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:47 --> URI Class Initialized
INFO - 2024-09-21 01:57:47 --> Router Class Initialized
INFO - 2024-09-21 01:57:47 --> Output Class Initialized
INFO - 2024-09-21 01:57:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:47 --> Input Class Initialized
INFO - 2024-09-21 01:57:47 --> Language Class Initialized
ERROR - 2024-09-21 01:57:47 --> 404 Page Not Found: 2016zip/index
INFO - 2024-09-21 01:57:47 --> Config Class Initialized
INFO - 2024-09-21 01:57:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:57:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:57:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:57:47 --> URI Class Initialized
INFO - 2024-09-21 01:57:47 --> Router Class Initialized
INFO - 2024-09-21 01:57:47 --> Output Class Initialized
INFO - 2024-09-21 01:57:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:57:47 --> Input Class Initialized
INFO - 2024-09-21 01:57:47 --> Language Class Initialized
ERROR - 2024-09-21 01:57:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomzip/index
INFO - 2024-09-21 01:58:39 --> Config Class Initialized
INFO - 2024-09-21 01:58:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:39 --> URI Class Initialized
INFO - 2024-09-21 01:58:39 --> Router Class Initialized
INFO - 2024-09-21 01:58:39 --> Output Class Initialized
INFO - 2024-09-21 01:58:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:39 --> Input Class Initialized
INFO - 2024-09-21 01:58:39 --> Language Class Initialized
ERROR - 2024-09-21 01:58:39 --> 404 Page Not Found: 2017rar/index
INFO - 2024-09-21 01:58:39 --> Config Class Initialized
INFO - 2024-09-21 01:58:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:39 --> URI Class Initialized
INFO - 2024-09-21 01:58:39 --> Router Class Initialized
INFO - 2024-09-21 01:58:39 --> Output Class Initialized
INFO - 2024-09-21 01:58:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:39 --> Input Class Initialized
INFO - 2024-09-21 01:58:39 --> Language Class Initialized
ERROR - 2024-09-21 01:58:39 --> 404 Page Not Found: 2022rar/index
INFO - 2024-09-21 01:58:39 --> Config Class Initialized
INFO - 2024-09-21 01:58:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:39 --> URI Class Initialized
INFO - 2024-09-21 01:58:39 --> Router Class Initialized
INFO - 2024-09-21 01:58:39 --> Output Class Initialized
INFO - 2024-09-21 01:58:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:39 --> Input Class Initialized
INFO - 2024-09-21 01:58:39 --> Language Class Initialized
ERROR - 2024-09-21 01:58:39 --> 404 Page Not Found: Arar/index
INFO - 2024-09-21 01:58:40 --> Config Class Initialized
INFO - 2024-09-21 01:58:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:40 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:40 --> URI Class Initialized
INFO - 2024-09-21 01:58:40 --> Router Class Initialized
INFO - 2024-09-21 01:58:40 --> Output Class Initialized
INFO - 2024-09-21 01:58:40 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:40 --> Input Class Initialized
INFO - 2024-09-21 01:58:40 --> Language Class Initialized
ERROR - 2024-09-21 01:58:40 --> 404 Page Not Found: Wwwrar/index
INFO - 2024-09-21 01:58:40 --> Config Class Initialized
INFO - 2024-09-21 01:58:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:40 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:40 --> URI Class Initialized
INFO - 2024-09-21 01:58:40 --> Router Class Initialized
INFO - 2024-09-21 01:58:40 --> Output Class Initialized
INFO - 2024-09-21 01:58:40 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:40 --> Input Class Initialized
INFO - 2024-09-21 01:58:40 --> Language Class Initialized
ERROR - 2024-09-21 01:58:40 --> 404 Page Not Found: Backuprar/index
INFO - 2024-09-21 01:58:41 --> Config Class Initialized
INFO - 2024-09-21 01:58:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:41 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:41 --> URI Class Initialized
INFO - 2024-09-21 01:58:41 --> Router Class Initialized
INFO - 2024-09-21 01:58:41 --> Output Class Initialized
INFO - 2024-09-21 01:58:41 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:41 --> Input Class Initialized
INFO - 2024-09-21 01:58:41 --> Language Class Initialized
ERROR - 2024-09-21 01:58:41 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 01:58:45 --> Config Class Initialized
INFO - 2024-09-21 01:58:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:45 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:45 --> URI Class Initialized
INFO - 2024-09-21 01:58:45 --> Router Class Initialized
INFO - 2024-09-21 01:58:45 --> Output Class Initialized
INFO - 2024-09-21 01:58:45 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:45 --> Input Class Initialized
INFO - 2024-09-21 01:58:45 --> Language Class Initialized
ERROR - 2024-09-21 01:58:45 --> 404 Page Not Found: 2019rar/index
INFO - 2024-09-21 01:58:46 --> Config Class Initialized
INFO - 2024-09-21 01:58:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:46 --> URI Class Initialized
INFO - 2024-09-21 01:58:46 --> Router Class Initialized
INFO - 2024-09-21 01:58:46 --> Output Class Initialized
INFO - 2024-09-21 01:58:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:46 --> Input Class Initialized
INFO - 2024-09-21 01:58:46 --> Language Class Initialized
ERROR - 2024-09-21 01:58:46 --> 404 Page Not Found: Storerar/index
INFO - 2024-09-21 01:58:46 --> Config Class Initialized
INFO - 2024-09-21 01:58:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:46 --> URI Class Initialized
INFO - 2024-09-21 01:58:46 --> Router Class Initialized
INFO - 2024-09-21 01:58:46 --> Output Class Initialized
INFO - 2024-09-21 01:58:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:46 --> Input Class Initialized
INFO - 2024-09-21 01:58:46 --> Language Class Initialized
ERROR - 2024-09-21 01:58:46 --> 404 Page Not Found: Siterar/index
INFO - 2024-09-21 01:58:47 --> Config Class Initialized
INFO - 2024-09-21 01:58:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:47 --> URI Class Initialized
INFO - 2024-09-21 01:58:47 --> Router Class Initialized
INFO - 2024-09-21 01:58:47 --> Output Class Initialized
INFO - 2024-09-21 01:58:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:47 --> Input Class Initialized
INFO - 2024-09-21 01:58:47 --> Language Class Initialized
ERROR - 2024-09-21 01:58:47 --> 404 Page Not Found: 1rar/index
INFO - 2024-09-21 01:58:47 --> Config Class Initialized
INFO - 2024-09-21 01:58:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:47 --> URI Class Initialized
INFO - 2024-09-21 01:58:47 --> Router Class Initialized
INFO - 2024-09-21 01:58:47 --> Output Class Initialized
INFO - 2024-09-21 01:58:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:47 --> Input Class Initialized
INFO - 2024-09-21 01:58:47 --> Language Class Initialized
ERROR - 2024-09-21 01:58:47 --> 404 Page Not Found: 2024rar/index
INFO - 2024-09-21 01:58:47 --> Config Class Initialized
INFO - 2024-09-21 01:58:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:47 --> URI Class Initialized
INFO - 2024-09-21 01:58:47 --> Router Class Initialized
INFO - 2024-09-21 01:58:47 --> Output Class Initialized
INFO - 2024-09-21 01:58:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:47 --> Input Class Initialized
INFO - 2024-09-21 01:58:47 --> Language Class Initialized
ERROR - 2024-09-21 01:58:47 --> 404 Page Not Found: 2016rar/index
INFO - 2024-09-21 01:58:48 --> Config Class Initialized
INFO - 2024-09-21 01:58:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:48 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:48 --> URI Class Initialized
INFO - 2024-09-21 01:58:48 --> Router Class Initialized
INFO - 2024-09-21 01:58:48 --> Output Class Initialized
INFO - 2024-09-21 01:58:48 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:48 --> Input Class Initialized
INFO - 2024-09-21 01:58:48 --> Language Class Initialized
ERROR - 2024-09-21 01:58:48 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 01:58:48 --> Config Class Initialized
INFO - 2024-09-21 01:58:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:48 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:48 --> URI Class Initialized
INFO - 2024-09-21 01:58:48 --> Router Class Initialized
INFO - 2024-09-21 01:58:48 --> Output Class Initialized
INFO - 2024-09-21 01:58:48 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:48 --> Input Class Initialized
INFO - 2024-09-21 01:58:48 --> Language Class Initialized
ERROR - 2024-09-21 01:58:48 --> 404 Page Not Found: Antrolrar/index
INFO - 2024-09-21 01:58:49 --> Config Class Initialized
INFO - 2024-09-21 01:58:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:49 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:49 --> URI Class Initialized
INFO - 2024-09-21 01:58:49 --> Router Class Initialized
INFO - 2024-09-21 01:58:49 --> Output Class Initialized
INFO - 2024-09-21 01:58:49 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:49 --> Input Class Initialized
INFO - 2024-09-21 01:58:49 --> Language Class Initialized
ERROR - 2024-09-21 01:58:49 --> 404 Page Not Found: 2023rar/index
INFO - 2024-09-21 01:58:49 --> Config Class Initialized
INFO - 2024-09-21 01:58:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:49 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:49 --> URI Class Initialized
INFO - 2024-09-21 01:58:49 --> Router Class Initialized
INFO - 2024-09-21 01:58:49 --> Output Class Initialized
INFO - 2024-09-21 01:58:49 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:49 --> Input Class Initialized
INFO - 2024-09-21 01:58:49 --> Language Class Initialized
ERROR - 2024-09-21 01:58:49 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comrar/index
INFO - 2024-09-21 01:58:50 --> Config Class Initialized
INFO - 2024-09-21 01:58:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:50 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:50 --> URI Class Initialized
INFO - 2024-09-21 01:58:50 --> Router Class Initialized
INFO - 2024-09-21 01:58:50 --> Output Class Initialized
INFO - 2024-09-21 01:58:50 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:50 --> Input Class Initialized
INFO - 2024-09-21 01:58:50 --> Language Class Initialized
ERROR - 2024-09-21 01:58:50 --> 404 Page Not Found: 2021rar/index
INFO - 2024-09-21 01:58:50 --> Config Class Initialized
INFO - 2024-09-21 01:58:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:50 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:50 --> URI Class Initialized
INFO - 2024-09-21 01:58:50 --> Router Class Initialized
INFO - 2024-09-21 01:58:50 --> Output Class Initialized
INFO - 2024-09-21 01:58:50 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:50 --> Input Class Initialized
INFO - 2024-09-21 01:58:50 --> Language Class Initialized
ERROR - 2024-09-21 01:58:50 --> 404 Page Not Found: Public_htmlrar/index
INFO - 2024-09-21 01:58:51 --> Config Class Initialized
INFO - 2024-09-21 01:58:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:51 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:51 --> URI Class Initialized
INFO - 2024-09-21 01:58:51 --> Router Class Initialized
INFO - 2024-09-21 01:58:51 --> Output Class Initialized
INFO - 2024-09-21 01:58:51 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:51 --> Input Class Initialized
INFO - 2024-09-21 01:58:51 --> Language Class Initialized
ERROR - 2024-09-21 01:58:51 --> 404 Page Not Found: 2018rar/index
INFO - 2024-09-21 01:58:51 --> Config Class Initialized
INFO - 2024-09-21 01:58:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:51 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:51 --> URI Class Initialized
INFO - 2024-09-21 01:58:51 --> Router Class Initialized
INFO - 2024-09-21 01:58:51 --> Output Class Initialized
INFO - 2024-09-21 01:58:51 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:51 --> Input Class Initialized
INFO - 2024-09-21 01:58:51 --> Language Class Initialized
ERROR - 2024-09-21 01:58:51 --> 404 Page Not Found: Webrar/index
INFO - 2024-09-21 01:58:52 --> Config Class Initialized
INFO - 2024-09-21 01:58:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:52 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:52 --> URI Class Initialized
INFO - 2024-09-21 01:58:52 --> Router Class Initialized
INFO - 2024-09-21 01:58:52 --> Output Class Initialized
INFO - 2024-09-21 01:58:52 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:52 --> Input Class Initialized
INFO - 2024-09-21 01:58:52 --> Language Class Initialized
ERROR - 2024-09-21 01:58:52 --> 404 Page Not Found: Backrar/index
INFO - 2024-09-21 01:58:52 --> Config Class Initialized
INFO - 2024-09-21 01:58:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:52 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:52 --> URI Class Initialized
INFO - 2024-09-21 01:58:52 --> Router Class Initialized
INFO - 2024-09-21 01:58:52 --> Output Class Initialized
INFO - 2024-09-21 01:58:52 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:52 --> Input Class Initialized
INFO - 2024-09-21 01:58:52 --> Language Class Initialized
ERROR - 2024-09-21 01:58:52 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 01:58:53 --> Config Class Initialized
INFO - 2024-09-21 01:58:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:53 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:53 --> URI Class Initialized
INFO - 2024-09-21 01:58:53 --> Router Class Initialized
INFO - 2024-09-21 01:58:53 --> Output Class Initialized
INFO - 2024-09-21 01:58:53 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:53 --> Input Class Initialized
INFO - 2024-09-21 01:58:53 --> Language Class Initialized
ERROR - 2024-09-21 01:58:53 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 01:58:53 --> Config Class Initialized
INFO - 2024-09-21 01:58:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:53 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:53 --> URI Class Initialized
INFO - 2024-09-21 01:58:53 --> Router Class Initialized
INFO - 2024-09-21 01:58:53 --> Output Class Initialized
INFO - 2024-09-21 01:58:53 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:53 --> Input Class Initialized
INFO - 2024-09-21 01:58:53 --> Language Class Initialized
ERROR - 2024-09-21 01:58:53 --> 404 Page Not Found: 2020rar/index
INFO - 2024-09-21 01:58:53 --> Config Class Initialized
INFO - 2024-09-21 01:58:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:53 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:53 --> URI Class Initialized
INFO - 2024-09-21 01:58:53 --> Router Class Initialized
INFO - 2024-09-21 01:58:53 --> Output Class Initialized
INFO - 2024-09-21 01:58:53 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:53 --> Input Class Initialized
INFO - 2024-09-21 01:58:53 --> Language Class Initialized
ERROR - 2024-09-21 01:58:53 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_comrar/index
INFO - 2024-09-21 01:58:54 --> Config Class Initialized
INFO - 2024-09-21 01:58:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:54 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:54 --> URI Class Initialized
INFO - 2024-09-21 01:58:54 --> Router Class Initialized
INFO - 2024-09-21 01:58:54 --> Output Class Initialized
INFO - 2024-09-21 01:58:54 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:54 --> Input Class Initialized
INFO - 2024-09-21 01:58:54 --> Language Class Initialized
ERROR - 2024-09-21 01:58:54 --> 404 Page Not Found: Rsudhabdulazizmarabahanrar/index
INFO - 2024-09-21 01:58:54 --> Config Class Initialized
INFO - 2024-09-21 01:58:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:54 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:54 --> URI Class Initialized
INFO - 2024-09-21 01:58:54 --> Router Class Initialized
INFO - 2024-09-21 01:58:54 --> Output Class Initialized
INFO - 2024-09-21 01:58:54 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:54 --> Input Class Initialized
INFO - 2024-09-21 01:58:54 --> Language Class Initialized
ERROR - 2024-09-21 01:58:54 --> 404 Page Not Found: Siterar/index
INFO - 2024-09-21 01:58:55 --> Config Class Initialized
INFO - 2024-09-21 01:58:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:55 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:55 --> URI Class Initialized
INFO - 2024-09-21 01:58:55 --> Router Class Initialized
INFO - 2024-09-21 01:58:55 --> Output Class Initialized
INFO - 2024-09-21 01:58:55 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:55 --> Input Class Initialized
INFO - 2024-09-21 01:58:55 --> Language Class Initialized
ERROR - 2024-09-21 01:58:55 --> 404 Page Not Found: 2017tar/index
INFO - 2024-09-21 01:58:55 --> Config Class Initialized
INFO - 2024-09-21 01:58:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:55 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:55 --> URI Class Initialized
INFO - 2024-09-21 01:58:55 --> Router Class Initialized
INFO - 2024-09-21 01:58:55 --> Output Class Initialized
INFO - 2024-09-21 01:58:55 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:55 --> Input Class Initialized
INFO - 2024-09-21 01:58:55 --> Language Class Initialized
ERROR - 2024-09-21 01:58:55 --> 404 Page Not Found: 2022tar/index
INFO - 2024-09-21 01:58:56 --> Config Class Initialized
INFO - 2024-09-21 01:58:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:56 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:56 --> URI Class Initialized
INFO - 2024-09-21 01:58:56 --> Router Class Initialized
INFO - 2024-09-21 01:58:56 --> Output Class Initialized
INFO - 2024-09-21 01:58:56 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:56 --> Input Class Initialized
INFO - 2024-09-21 01:58:56 --> Language Class Initialized
ERROR - 2024-09-21 01:58:56 --> 404 Page Not Found: Atar/index
INFO - 2024-09-21 01:58:56 --> Config Class Initialized
INFO - 2024-09-21 01:58:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:56 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:56 --> URI Class Initialized
INFO - 2024-09-21 01:58:56 --> Router Class Initialized
INFO - 2024-09-21 01:58:56 --> Output Class Initialized
INFO - 2024-09-21 01:58:56 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:56 --> Input Class Initialized
INFO - 2024-09-21 01:58:56 --> Language Class Initialized
ERROR - 2024-09-21 01:58:56 --> 404 Page Not Found: Wwwtar/index
INFO - 2024-09-21 01:58:57 --> Config Class Initialized
INFO - 2024-09-21 01:58:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:57 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:57 --> URI Class Initialized
INFO - 2024-09-21 01:58:57 --> Router Class Initialized
INFO - 2024-09-21 01:58:57 --> Output Class Initialized
INFO - 2024-09-21 01:58:57 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:57 --> Input Class Initialized
INFO - 2024-09-21 01:58:57 --> Language Class Initialized
ERROR - 2024-09-21 01:58:57 --> 404 Page Not Found: Backuptar/index
INFO - 2024-09-21 01:58:57 --> Config Class Initialized
INFO - 2024-09-21 01:58:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:57 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:57 --> URI Class Initialized
INFO - 2024-09-21 01:58:57 --> Router Class Initialized
INFO - 2024-09-21 01:58:57 --> Output Class Initialized
INFO - 2024-09-21 01:58:57 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:57 --> Input Class Initialized
INFO - 2024-09-21 01:58:57 --> Language Class Initialized
ERROR - 2024-09-21 01:58:57 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 01:58:58 --> Config Class Initialized
INFO - 2024-09-21 01:58:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:58 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:58 --> URI Class Initialized
INFO - 2024-09-21 01:58:58 --> Router Class Initialized
INFO - 2024-09-21 01:58:58 --> Output Class Initialized
INFO - 2024-09-21 01:58:58 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:58 --> Input Class Initialized
INFO - 2024-09-21 01:58:58 --> Language Class Initialized
ERROR - 2024-09-21 01:58:58 --> 404 Page Not Found: 2019tar/index
INFO - 2024-09-21 01:58:58 --> Config Class Initialized
INFO - 2024-09-21 01:58:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:58 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:58 --> URI Class Initialized
INFO - 2024-09-21 01:58:58 --> Router Class Initialized
INFO - 2024-09-21 01:58:58 --> Output Class Initialized
INFO - 2024-09-21 01:58:58 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:58 --> Input Class Initialized
INFO - 2024-09-21 01:58:58 --> Language Class Initialized
ERROR - 2024-09-21 01:58:58 --> 404 Page Not Found: Storetar/index
INFO - 2024-09-21 01:58:59 --> Config Class Initialized
INFO - 2024-09-21 01:58:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:59 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:59 --> URI Class Initialized
INFO - 2024-09-21 01:58:59 --> Router Class Initialized
INFO - 2024-09-21 01:58:59 --> Output Class Initialized
INFO - 2024-09-21 01:58:59 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:59 --> Input Class Initialized
INFO - 2024-09-21 01:58:59 --> Language Class Initialized
ERROR - 2024-09-21 01:58:59 --> 404 Page Not Found: Sitetar/index
INFO - 2024-09-21 01:58:59 --> Config Class Initialized
INFO - 2024-09-21 01:58:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:59 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:59 --> URI Class Initialized
INFO - 2024-09-21 01:58:59 --> Router Class Initialized
INFO - 2024-09-21 01:58:59 --> Output Class Initialized
INFO - 2024-09-21 01:58:59 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:59 --> Input Class Initialized
INFO - 2024-09-21 01:58:59 --> Language Class Initialized
ERROR - 2024-09-21 01:58:59 --> 404 Page Not Found: 1tar/index
INFO - 2024-09-21 01:58:59 --> Config Class Initialized
INFO - 2024-09-21 01:58:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:58:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:58:59 --> Utf8 Class Initialized
INFO - 2024-09-21 01:58:59 --> URI Class Initialized
INFO - 2024-09-21 01:58:59 --> Router Class Initialized
INFO - 2024-09-21 01:58:59 --> Output Class Initialized
INFO - 2024-09-21 01:58:59 --> Security Class Initialized
DEBUG - 2024-09-21 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:58:59 --> Input Class Initialized
INFO - 2024-09-21 01:58:59 --> Language Class Initialized
ERROR - 2024-09-21 01:58:59 --> 404 Page Not Found: 2024tar/index
INFO - 2024-09-21 01:59:00 --> Config Class Initialized
INFO - 2024-09-21 01:59:00 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:00 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:00 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:00 --> URI Class Initialized
INFO - 2024-09-21 01:59:00 --> Router Class Initialized
INFO - 2024-09-21 01:59:00 --> Output Class Initialized
INFO - 2024-09-21 01:59:00 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:00 --> Input Class Initialized
INFO - 2024-09-21 01:59:00 --> Language Class Initialized
ERROR - 2024-09-21 01:59:00 --> 404 Page Not Found: 2016tar/index
INFO - 2024-09-21 01:59:00 --> Config Class Initialized
INFO - 2024-09-21 01:59:00 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:00 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:00 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:00 --> URI Class Initialized
INFO - 2024-09-21 01:59:00 --> Router Class Initialized
INFO - 2024-09-21 01:59:00 --> Output Class Initialized
INFO - 2024-09-21 01:59:00 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:00 --> Input Class Initialized
INFO - 2024-09-21 01:59:00 --> Language Class Initialized
ERROR - 2024-09-21 01:59:00 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 01:59:01 --> Config Class Initialized
INFO - 2024-09-21 01:59:01 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:01 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:01 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:01 --> URI Class Initialized
INFO - 2024-09-21 01:59:01 --> Router Class Initialized
INFO - 2024-09-21 01:59:01 --> Output Class Initialized
INFO - 2024-09-21 01:59:01 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:01 --> Input Class Initialized
INFO - 2024-09-21 01:59:01 --> Language Class Initialized
ERROR - 2024-09-21 01:59:01 --> 404 Page Not Found: Antroltar/index
INFO - 2024-09-21 01:59:01 --> Config Class Initialized
INFO - 2024-09-21 01:59:01 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:01 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:01 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:01 --> URI Class Initialized
INFO - 2024-09-21 01:59:01 --> Router Class Initialized
INFO - 2024-09-21 01:59:01 --> Output Class Initialized
INFO - 2024-09-21 01:59:01 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:01 --> Input Class Initialized
INFO - 2024-09-21 01:59:01 --> Language Class Initialized
ERROR - 2024-09-21 01:59:01 --> 404 Page Not Found: 2023tar/index
INFO - 2024-09-21 01:59:02 --> Config Class Initialized
INFO - 2024-09-21 01:59:02 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:02 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:02 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:02 --> URI Class Initialized
INFO - 2024-09-21 01:59:02 --> Router Class Initialized
INFO - 2024-09-21 01:59:02 --> Output Class Initialized
INFO - 2024-09-21 01:59:02 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:02 --> Input Class Initialized
INFO - 2024-09-21 01:59:02 --> Language Class Initialized
ERROR - 2024-09-21 01:59:02 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comtar/index
INFO - 2024-09-21 01:59:03 --> Config Class Initialized
INFO - 2024-09-21 01:59:03 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:03 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:03 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:03 --> URI Class Initialized
INFO - 2024-09-21 01:59:03 --> Router Class Initialized
INFO - 2024-09-21 01:59:03 --> Output Class Initialized
INFO - 2024-09-21 01:59:03 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:03 --> Input Class Initialized
INFO - 2024-09-21 01:59:03 --> Language Class Initialized
ERROR - 2024-09-21 01:59:03 --> 404 Page Not Found: 2021tar/index
INFO - 2024-09-21 01:59:03 --> Config Class Initialized
INFO - 2024-09-21 01:59:03 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:03 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:03 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:03 --> URI Class Initialized
INFO - 2024-09-21 01:59:03 --> Router Class Initialized
INFO - 2024-09-21 01:59:03 --> Output Class Initialized
INFO - 2024-09-21 01:59:03 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:03 --> Input Class Initialized
INFO - 2024-09-21 01:59:03 --> Language Class Initialized
ERROR - 2024-09-21 01:59:03 --> 404 Page Not Found: Public_htmltar/index
INFO - 2024-09-21 01:59:04 --> Config Class Initialized
INFO - 2024-09-21 01:59:04 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:04 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:04 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:04 --> URI Class Initialized
INFO - 2024-09-21 01:59:04 --> Router Class Initialized
INFO - 2024-09-21 01:59:04 --> Output Class Initialized
INFO - 2024-09-21 01:59:04 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:04 --> Input Class Initialized
INFO - 2024-09-21 01:59:04 --> Language Class Initialized
ERROR - 2024-09-21 01:59:04 --> 404 Page Not Found: 2018tar/index
INFO - 2024-09-21 01:59:04 --> Config Class Initialized
INFO - 2024-09-21 01:59:04 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:04 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:04 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:04 --> URI Class Initialized
INFO - 2024-09-21 01:59:04 --> Router Class Initialized
INFO - 2024-09-21 01:59:04 --> Output Class Initialized
INFO - 2024-09-21 01:59:04 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:04 --> Input Class Initialized
INFO - 2024-09-21 01:59:04 --> Language Class Initialized
ERROR - 2024-09-21 01:59:04 --> 404 Page Not Found: Webtar/index
INFO - 2024-09-21 01:59:04 --> Config Class Initialized
INFO - 2024-09-21 01:59:04 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:04 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:04 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:04 --> URI Class Initialized
INFO - 2024-09-21 01:59:04 --> Router Class Initialized
INFO - 2024-09-21 01:59:04 --> Output Class Initialized
INFO - 2024-09-21 01:59:04 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:04 --> Input Class Initialized
INFO - 2024-09-21 01:59:04 --> Language Class Initialized
ERROR - 2024-09-21 01:59:04 --> 404 Page Not Found: Backtar/index
INFO - 2024-09-21 01:59:05 --> Config Class Initialized
INFO - 2024-09-21 01:59:05 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:05 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:05 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:05 --> URI Class Initialized
INFO - 2024-09-21 01:59:05 --> Router Class Initialized
INFO - 2024-09-21 01:59:05 --> Output Class Initialized
INFO - 2024-09-21 01:59:05 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:05 --> Input Class Initialized
INFO - 2024-09-21 01:59:05 --> Language Class Initialized
ERROR - 2024-09-21 01:59:05 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 01:59:05 --> Config Class Initialized
INFO - 2024-09-21 01:59:05 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:05 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:05 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:05 --> URI Class Initialized
INFO - 2024-09-21 01:59:05 --> Router Class Initialized
INFO - 2024-09-21 01:59:05 --> Output Class Initialized
INFO - 2024-09-21 01:59:05 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:05 --> Input Class Initialized
INFO - 2024-09-21 01:59:05 --> Language Class Initialized
ERROR - 2024-09-21 01:59:05 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 01:59:06 --> Config Class Initialized
INFO - 2024-09-21 01:59:06 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:06 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:06 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:06 --> URI Class Initialized
INFO - 2024-09-21 01:59:06 --> Router Class Initialized
INFO - 2024-09-21 01:59:06 --> Output Class Initialized
INFO - 2024-09-21 01:59:06 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:06 --> Input Class Initialized
INFO - 2024-09-21 01:59:06 --> Language Class Initialized
ERROR - 2024-09-21 01:59:06 --> 404 Page Not Found: 2020tar/index
INFO - 2024-09-21 01:59:06 --> Config Class Initialized
INFO - 2024-09-21 01:59:06 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:06 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:06 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:06 --> URI Class Initialized
INFO - 2024-09-21 01:59:06 --> Router Class Initialized
INFO - 2024-09-21 01:59:06 --> Output Class Initialized
INFO - 2024-09-21 01:59:06 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:06 --> Input Class Initialized
INFO - 2024-09-21 01:59:06 --> Language Class Initialized
ERROR - 2024-09-21 01:59:06 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_comtar/index
INFO - 2024-09-21 01:59:07 --> Config Class Initialized
INFO - 2024-09-21 01:59:07 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:07 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:07 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:07 --> URI Class Initialized
INFO - 2024-09-21 01:59:07 --> Router Class Initialized
INFO - 2024-09-21 01:59:07 --> Output Class Initialized
INFO - 2024-09-21 01:59:07 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:07 --> Input Class Initialized
INFO - 2024-09-21 01:59:07 --> Language Class Initialized
ERROR - 2024-09-21 01:59:07 --> 404 Page Not Found: Rsudhabdulazizmarabahantar/index
INFO - 2024-09-21 01:59:07 --> Config Class Initialized
INFO - 2024-09-21 01:59:07 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:07 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:07 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:07 --> URI Class Initialized
INFO - 2024-09-21 01:59:07 --> Router Class Initialized
INFO - 2024-09-21 01:59:07 --> Output Class Initialized
INFO - 2024-09-21 01:59:07 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:07 --> Input Class Initialized
INFO - 2024-09-21 01:59:07 --> Language Class Initialized
ERROR - 2024-09-21 01:59:07 --> 404 Page Not Found: Sitetar/index
INFO - 2024-09-21 01:59:07 --> Config Class Initialized
INFO - 2024-09-21 01:59:07 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:07 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:07 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:07 --> URI Class Initialized
INFO - 2024-09-21 01:59:07 --> Router Class Initialized
INFO - 2024-09-21 01:59:07 --> Output Class Initialized
INFO - 2024-09-21 01:59:07 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:07 --> Input Class Initialized
INFO - 2024-09-21 01:59:07 --> Language Class Initialized
ERROR - 2024-09-21 01:59:07 --> 404 Page Not Found: 2017targz/index
INFO - 2024-09-21 01:59:08 --> Config Class Initialized
INFO - 2024-09-21 01:59:08 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:08 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:08 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:08 --> URI Class Initialized
INFO - 2024-09-21 01:59:08 --> Router Class Initialized
INFO - 2024-09-21 01:59:08 --> Output Class Initialized
INFO - 2024-09-21 01:59:08 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:08 --> Input Class Initialized
INFO - 2024-09-21 01:59:08 --> Language Class Initialized
ERROR - 2024-09-21 01:59:08 --> 404 Page Not Found: 2022targz/index
INFO - 2024-09-21 01:59:08 --> Config Class Initialized
INFO - 2024-09-21 01:59:08 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:08 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:08 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:08 --> URI Class Initialized
INFO - 2024-09-21 01:59:08 --> Router Class Initialized
INFO - 2024-09-21 01:59:08 --> Output Class Initialized
INFO - 2024-09-21 01:59:08 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:08 --> Input Class Initialized
INFO - 2024-09-21 01:59:08 --> Language Class Initialized
ERROR - 2024-09-21 01:59:08 --> 404 Page Not Found: Atargz/index
INFO - 2024-09-21 01:59:09 --> Config Class Initialized
INFO - 2024-09-21 01:59:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:09 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:09 --> URI Class Initialized
INFO - 2024-09-21 01:59:09 --> Router Class Initialized
INFO - 2024-09-21 01:59:09 --> Output Class Initialized
INFO - 2024-09-21 01:59:09 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:09 --> Input Class Initialized
INFO - 2024-09-21 01:59:09 --> Language Class Initialized
ERROR - 2024-09-21 01:59:09 --> 404 Page Not Found: Wwwtargz/index
INFO - 2024-09-21 01:59:09 --> Config Class Initialized
INFO - 2024-09-21 01:59:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:09 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:09 --> URI Class Initialized
INFO - 2024-09-21 01:59:09 --> Router Class Initialized
INFO - 2024-09-21 01:59:09 --> Output Class Initialized
INFO - 2024-09-21 01:59:09 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:09 --> Input Class Initialized
INFO - 2024-09-21 01:59:09 --> Language Class Initialized
ERROR - 2024-09-21 01:59:09 --> 404 Page Not Found: Backuptargz/index
INFO - 2024-09-21 01:59:10 --> Config Class Initialized
INFO - 2024-09-21 01:59:10 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:10 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:10 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:10 --> URI Class Initialized
INFO - 2024-09-21 01:59:10 --> Router Class Initialized
INFO - 2024-09-21 01:59:10 --> Output Class Initialized
INFO - 2024-09-21 01:59:10 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:10 --> Input Class Initialized
INFO - 2024-09-21 01:59:10 --> Language Class Initialized
ERROR - 2024-09-21 01:59:10 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 01:59:10 --> Config Class Initialized
INFO - 2024-09-21 01:59:10 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:10 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:10 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:10 --> URI Class Initialized
INFO - 2024-09-21 01:59:10 --> Router Class Initialized
INFO - 2024-09-21 01:59:10 --> Output Class Initialized
INFO - 2024-09-21 01:59:10 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:10 --> Input Class Initialized
INFO - 2024-09-21 01:59:10 --> Language Class Initialized
ERROR - 2024-09-21 01:59:10 --> 404 Page Not Found: 2019targz/index
INFO - 2024-09-21 01:59:11 --> Config Class Initialized
INFO - 2024-09-21 01:59:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:11 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:11 --> URI Class Initialized
INFO - 2024-09-21 01:59:11 --> Router Class Initialized
INFO - 2024-09-21 01:59:11 --> Output Class Initialized
INFO - 2024-09-21 01:59:11 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:11 --> Input Class Initialized
INFO - 2024-09-21 01:59:11 --> Language Class Initialized
ERROR - 2024-09-21 01:59:11 --> 404 Page Not Found: Storetargz/index
INFO - 2024-09-21 01:59:11 --> Config Class Initialized
INFO - 2024-09-21 01:59:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:11 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:11 --> URI Class Initialized
INFO - 2024-09-21 01:59:11 --> Router Class Initialized
INFO - 2024-09-21 01:59:11 --> Output Class Initialized
INFO - 2024-09-21 01:59:11 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:11 --> Input Class Initialized
INFO - 2024-09-21 01:59:11 --> Language Class Initialized
ERROR - 2024-09-21 01:59:11 --> 404 Page Not Found: Sitetargz/index
INFO - 2024-09-21 01:59:11 --> Config Class Initialized
INFO - 2024-09-21 01:59:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:11 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:11 --> URI Class Initialized
INFO - 2024-09-21 01:59:11 --> Router Class Initialized
INFO - 2024-09-21 01:59:11 --> Output Class Initialized
INFO - 2024-09-21 01:59:11 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:11 --> Input Class Initialized
INFO - 2024-09-21 01:59:11 --> Language Class Initialized
ERROR - 2024-09-21 01:59:11 --> 404 Page Not Found: 1targz/index
INFO - 2024-09-21 01:59:12 --> Config Class Initialized
INFO - 2024-09-21 01:59:12 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:12 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:12 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:12 --> URI Class Initialized
INFO - 2024-09-21 01:59:12 --> Router Class Initialized
INFO - 2024-09-21 01:59:12 --> Output Class Initialized
INFO - 2024-09-21 01:59:12 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:12 --> Input Class Initialized
INFO - 2024-09-21 01:59:12 --> Language Class Initialized
ERROR - 2024-09-21 01:59:12 --> 404 Page Not Found: 2024targz/index
INFO - 2024-09-21 01:59:12 --> Config Class Initialized
INFO - 2024-09-21 01:59:12 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:12 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:12 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:12 --> URI Class Initialized
INFO - 2024-09-21 01:59:12 --> Router Class Initialized
INFO - 2024-09-21 01:59:12 --> Output Class Initialized
INFO - 2024-09-21 01:59:12 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:12 --> Input Class Initialized
INFO - 2024-09-21 01:59:12 --> Language Class Initialized
ERROR - 2024-09-21 01:59:12 --> 404 Page Not Found: 2016targz/index
INFO - 2024-09-21 01:59:13 --> Config Class Initialized
INFO - 2024-09-21 01:59:13 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:13 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:13 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:13 --> URI Class Initialized
INFO - 2024-09-21 01:59:13 --> Router Class Initialized
INFO - 2024-09-21 01:59:13 --> Output Class Initialized
INFO - 2024-09-21 01:59:13 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:13 --> Input Class Initialized
INFO - 2024-09-21 01:59:13 --> Language Class Initialized
ERROR - 2024-09-21 01:59:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 01:59:13 --> Config Class Initialized
INFO - 2024-09-21 01:59:13 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:13 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:13 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:13 --> URI Class Initialized
INFO - 2024-09-21 01:59:13 --> Router Class Initialized
INFO - 2024-09-21 01:59:13 --> Output Class Initialized
INFO - 2024-09-21 01:59:13 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:13 --> Input Class Initialized
INFO - 2024-09-21 01:59:13 --> Language Class Initialized
ERROR - 2024-09-21 01:59:13 --> 404 Page Not Found: Antroltargz/index
INFO - 2024-09-21 01:59:14 --> Config Class Initialized
INFO - 2024-09-21 01:59:14 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:14 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:14 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:14 --> URI Class Initialized
INFO - 2024-09-21 01:59:14 --> Router Class Initialized
INFO - 2024-09-21 01:59:14 --> Output Class Initialized
INFO - 2024-09-21 01:59:14 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:14 --> Input Class Initialized
INFO - 2024-09-21 01:59:14 --> Language Class Initialized
ERROR - 2024-09-21 01:59:14 --> 404 Page Not Found: 2023targz/index
INFO - 2024-09-21 01:59:14 --> Config Class Initialized
INFO - 2024-09-21 01:59:14 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:14 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:14 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:14 --> URI Class Initialized
INFO - 2024-09-21 01:59:14 --> Router Class Initialized
INFO - 2024-09-21 01:59:14 --> Output Class Initialized
INFO - 2024-09-21 01:59:14 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:14 --> Input Class Initialized
INFO - 2024-09-21 01:59:14 --> Language Class Initialized
ERROR - 2024-09-21 01:59:14 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comtargz/index
INFO - 2024-09-21 01:59:15 --> Config Class Initialized
INFO - 2024-09-21 01:59:15 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:15 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:15 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:15 --> URI Class Initialized
INFO - 2024-09-21 01:59:15 --> Router Class Initialized
INFO - 2024-09-21 01:59:15 --> Output Class Initialized
INFO - 2024-09-21 01:59:15 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:15 --> Input Class Initialized
INFO - 2024-09-21 01:59:15 --> Language Class Initialized
ERROR - 2024-09-21 01:59:15 --> 404 Page Not Found: 2021targz/index
INFO - 2024-09-21 01:59:15 --> Config Class Initialized
INFO - 2024-09-21 01:59:15 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:15 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:15 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:15 --> URI Class Initialized
INFO - 2024-09-21 01:59:15 --> Router Class Initialized
INFO - 2024-09-21 01:59:15 --> Output Class Initialized
INFO - 2024-09-21 01:59:15 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:15 --> Input Class Initialized
INFO - 2024-09-21 01:59:15 --> Language Class Initialized
ERROR - 2024-09-21 01:59:15 --> 404 Page Not Found: Public_htmltargz/index
INFO - 2024-09-21 01:59:16 --> Config Class Initialized
INFO - 2024-09-21 01:59:16 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:16 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:16 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:16 --> URI Class Initialized
INFO - 2024-09-21 01:59:16 --> Router Class Initialized
INFO - 2024-09-21 01:59:16 --> Output Class Initialized
INFO - 2024-09-21 01:59:16 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:16 --> Input Class Initialized
INFO - 2024-09-21 01:59:16 --> Language Class Initialized
ERROR - 2024-09-21 01:59:16 --> 404 Page Not Found: 2018targz/index
INFO - 2024-09-21 01:59:16 --> Config Class Initialized
INFO - 2024-09-21 01:59:16 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:16 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:16 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:16 --> URI Class Initialized
INFO - 2024-09-21 01:59:16 --> Router Class Initialized
INFO - 2024-09-21 01:59:16 --> Output Class Initialized
INFO - 2024-09-21 01:59:16 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:16 --> Input Class Initialized
INFO - 2024-09-21 01:59:16 --> Language Class Initialized
ERROR - 2024-09-21 01:59:16 --> 404 Page Not Found: Webtargz/index
INFO - 2024-09-21 01:59:17 --> Config Class Initialized
INFO - 2024-09-21 01:59:17 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:17 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:17 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:17 --> URI Class Initialized
INFO - 2024-09-21 01:59:17 --> Router Class Initialized
INFO - 2024-09-21 01:59:17 --> Output Class Initialized
INFO - 2024-09-21 01:59:17 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:17 --> Input Class Initialized
INFO - 2024-09-21 01:59:17 --> Language Class Initialized
ERROR - 2024-09-21 01:59:17 --> 404 Page Not Found: Backtargz/index
INFO - 2024-09-21 01:59:17 --> Config Class Initialized
INFO - 2024-09-21 01:59:17 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:17 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:17 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:17 --> URI Class Initialized
INFO - 2024-09-21 01:59:17 --> Router Class Initialized
INFO - 2024-09-21 01:59:17 --> Output Class Initialized
INFO - 2024-09-21 01:59:17 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:17 --> Input Class Initialized
INFO - 2024-09-21 01:59:17 --> Language Class Initialized
ERROR - 2024-09-21 01:59:17 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 01:59:17 --> Config Class Initialized
INFO - 2024-09-21 01:59:17 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:17 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:17 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:17 --> URI Class Initialized
INFO - 2024-09-21 01:59:17 --> Router Class Initialized
INFO - 2024-09-21 01:59:17 --> Output Class Initialized
INFO - 2024-09-21 01:59:17 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:17 --> Input Class Initialized
INFO - 2024-09-21 01:59:17 --> Language Class Initialized
ERROR - 2024-09-21 01:59:17 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 01:59:18 --> Config Class Initialized
INFO - 2024-09-21 01:59:18 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:18 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:18 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:18 --> URI Class Initialized
INFO - 2024-09-21 01:59:18 --> Router Class Initialized
INFO - 2024-09-21 01:59:18 --> Output Class Initialized
INFO - 2024-09-21 01:59:18 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:18 --> Input Class Initialized
INFO - 2024-09-21 01:59:18 --> Language Class Initialized
ERROR - 2024-09-21 01:59:18 --> 404 Page Not Found: 2020targz/index
INFO - 2024-09-21 01:59:18 --> Config Class Initialized
INFO - 2024-09-21 01:59:18 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:18 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:18 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:18 --> URI Class Initialized
INFO - 2024-09-21 01:59:18 --> Router Class Initialized
INFO - 2024-09-21 01:59:18 --> Output Class Initialized
INFO - 2024-09-21 01:59:18 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:18 --> Input Class Initialized
INFO - 2024-09-21 01:59:18 --> Language Class Initialized
ERROR - 2024-09-21 01:59:18 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_comtargz/index
INFO - 2024-09-21 01:59:19 --> Config Class Initialized
INFO - 2024-09-21 01:59:19 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:19 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:19 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:19 --> URI Class Initialized
INFO - 2024-09-21 01:59:19 --> Router Class Initialized
INFO - 2024-09-21 01:59:19 --> Output Class Initialized
INFO - 2024-09-21 01:59:19 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:19 --> Input Class Initialized
INFO - 2024-09-21 01:59:19 --> Language Class Initialized
ERROR - 2024-09-21 01:59:19 --> 404 Page Not Found: Rsudhabdulazizmarabahantargz/index
INFO - 2024-09-21 01:59:19 --> Config Class Initialized
INFO - 2024-09-21 01:59:19 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:19 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:19 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:19 --> URI Class Initialized
INFO - 2024-09-21 01:59:19 --> Router Class Initialized
INFO - 2024-09-21 01:59:19 --> Output Class Initialized
INFO - 2024-09-21 01:59:19 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:19 --> Input Class Initialized
INFO - 2024-09-21 01:59:19 --> Language Class Initialized
ERROR - 2024-09-21 01:59:19 --> 404 Page Not Found: Sitetargz/index
INFO - 2024-09-21 01:59:20 --> Config Class Initialized
INFO - 2024-09-21 01:59:20 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:20 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:20 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:20 --> URI Class Initialized
INFO - 2024-09-21 01:59:20 --> Router Class Initialized
INFO - 2024-09-21 01:59:20 --> Output Class Initialized
INFO - 2024-09-21 01:59:20 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:20 --> Input Class Initialized
INFO - 2024-09-21 01:59:20 --> Language Class Initialized
ERROR - 2024-09-21 01:59:20 --> 404 Page Not Found: 2017gz/index
INFO - 2024-09-21 01:59:20 --> Config Class Initialized
INFO - 2024-09-21 01:59:20 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:20 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:20 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:20 --> URI Class Initialized
INFO - 2024-09-21 01:59:20 --> Router Class Initialized
INFO - 2024-09-21 01:59:20 --> Output Class Initialized
INFO - 2024-09-21 01:59:20 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:20 --> Input Class Initialized
INFO - 2024-09-21 01:59:20 --> Language Class Initialized
ERROR - 2024-09-21 01:59:20 --> 404 Page Not Found: 2022gz/index
INFO - 2024-09-21 01:59:21 --> Config Class Initialized
INFO - 2024-09-21 01:59:21 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:21 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:21 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:21 --> URI Class Initialized
INFO - 2024-09-21 01:59:21 --> Router Class Initialized
INFO - 2024-09-21 01:59:21 --> Output Class Initialized
INFO - 2024-09-21 01:59:21 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:21 --> Input Class Initialized
INFO - 2024-09-21 01:59:21 --> Language Class Initialized
ERROR - 2024-09-21 01:59:21 --> 404 Page Not Found: Agz/index
INFO - 2024-09-21 01:59:21 --> Config Class Initialized
INFO - 2024-09-21 01:59:21 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:21 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:21 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:21 --> URI Class Initialized
INFO - 2024-09-21 01:59:21 --> Router Class Initialized
INFO - 2024-09-21 01:59:21 --> Output Class Initialized
INFO - 2024-09-21 01:59:21 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:21 --> Input Class Initialized
INFO - 2024-09-21 01:59:21 --> Language Class Initialized
ERROR - 2024-09-21 01:59:21 --> 404 Page Not Found: Wwwgz/index
INFO - 2024-09-21 01:59:22 --> Config Class Initialized
INFO - 2024-09-21 01:59:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:22 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:22 --> URI Class Initialized
INFO - 2024-09-21 01:59:22 --> Router Class Initialized
INFO - 2024-09-21 01:59:22 --> Output Class Initialized
INFO - 2024-09-21 01:59:22 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:22 --> Input Class Initialized
INFO - 2024-09-21 01:59:22 --> Language Class Initialized
ERROR - 2024-09-21 01:59:22 --> 404 Page Not Found: Backupgz/index
INFO - 2024-09-21 01:59:22 --> Config Class Initialized
INFO - 2024-09-21 01:59:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:22 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:22 --> URI Class Initialized
INFO - 2024-09-21 01:59:22 --> Router Class Initialized
INFO - 2024-09-21 01:59:22 --> Output Class Initialized
INFO - 2024-09-21 01:59:22 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:22 --> Input Class Initialized
INFO - 2024-09-21 01:59:22 --> Language Class Initialized
ERROR - 2024-09-21 01:59:22 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 01:59:22 --> Config Class Initialized
INFO - 2024-09-21 01:59:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:22 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:22 --> URI Class Initialized
INFO - 2024-09-21 01:59:22 --> Router Class Initialized
INFO - 2024-09-21 01:59:22 --> Output Class Initialized
INFO - 2024-09-21 01:59:22 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:22 --> Input Class Initialized
INFO - 2024-09-21 01:59:22 --> Language Class Initialized
ERROR - 2024-09-21 01:59:22 --> 404 Page Not Found: 2019gz/index
INFO - 2024-09-21 01:59:23 --> Config Class Initialized
INFO - 2024-09-21 01:59:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:23 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:23 --> URI Class Initialized
INFO - 2024-09-21 01:59:23 --> Router Class Initialized
INFO - 2024-09-21 01:59:23 --> Output Class Initialized
INFO - 2024-09-21 01:59:23 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:23 --> Input Class Initialized
INFO - 2024-09-21 01:59:23 --> Language Class Initialized
ERROR - 2024-09-21 01:59:23 --> 404 Page Not Found: Storegz/index
INFO - 2024-09-21 01:59:23 --> Config Class Initialized
INFO - 2024-09-21 01:59:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:23 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:23 --> URI Class Initialized
INFO - 2024-09-21 01:59:23 --> Router Class Initialized
INFO - 2024-09-21 01:59:23 --> Output Class Initialized
INFO - 2024-09-21 01:59:23 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:23 --> Input Class Initialized
INFO - 2024-09-21 01:59:23 --> Language Class Initialized
ERROR - 2024-09-21 01:59:23 --> 404 Page Not Found: Sitegz/index
INFO - 2024-09-21 01:59:24 --> Config Class Initialized
INFO - 2024-09-21 01:59:24 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:24 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:24 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:24 --> URI Class Initialized
INFO - 2024-09-21 01:59:24 --> Router Class Initialized
INFO - 2024-09-21 01:59:24 --> Output Class Initialized
INFO - 2024-09-21 01:59:24 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:24 --> Input Class Initialized
INFO - 2024-09-21 01:59:24 --> Language Class Initialized
ERROR - 2024-09-21 01:59:24 --> 404 Page Not Found: 1gz/index
INFO - 2024-09-21 01:59:24 --> Config Class Initialized
INFO - 2024-09-21 01:59:24 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:24 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:24 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:24 --> URI Class Initialized
INFO - 2024-09-21 01:59:24 --> Router Class Initialized
INFO - 2024-09-21 01:59:24 --> Output Class Initialized
INFO - 2024-09-21 01:59:24 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:24 --> Input Class Initialized
INFO - 2024-09-21 01:59:24 --> Language Class Initialized
ERROR - 2024-09-21 01:59:24 --> 404 Page Not Found: 2024gz/index
INFO - 2024-09-21 01:59:25 --> Config Class Initialized
INFO - 2024-09-21 01:59:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:25 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:25 --> URI Class Initialized
INFO - 2024-09-21 01:59:25 --> Router Class Initialized
INFO - 2024-09-21 01:59:25 --> Output Class Initialized
INFO - 2024-09-21 01:59:25 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:25 --> Input Class Initialized
INFO - 2024-09-21 01:59:25 --> Language Class Initialized
ERROR - 2024-09-21 01:59:25 --> 404 Page Not Found: 2016gz/index
INFO - 2024-09-21 01:59:25 --> Config Class Initialized
INFO - 2024-09-21 01:59:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:25 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:25 --> URI Class Initialized
INFO - 2024-09-21 01:59:25 --> Router Class Initialized
INFO - 2024-09-21 01:59:25 --> Output Class Initialized
INFO - 2024-09-21 01:59:25 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:25 --> Input Class Initialized
INFO - 2024-09-21 01:59:25 --> Language Class Initialized
ERROR - 2024-09-21 01:59:25 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 01:59:26 --> Config Class Initialized
INFO - 2024-09-21 01:59:26 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:26 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:26 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:26 --> URI Class Initialized
INFO - 2024-09-21 01:59:26 --> Router Class Initialized
INFO - 2024-09-21 01:59:26 --> Output Class Initialized
INFO - 2024-09-21 01:59:26 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:26 --> Input Class Initialized
INFO - 2024-09-21 01:59:26 --> Language Class Initialized
ERROR - 2024-09-21 01:59:26 --> 404 Page Not Found: Antrolgz/index
INFO - 2024-09-21 01:59:26 --> Config Class Initialized
INFO - 2024-09-21 01:59:26 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:26 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:26 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:26 --> URI Class Initialized
INFO - 2024-09-21 01:59:26 --> Router Class Initialized
INFO - 2024-09-21 01:59:26 --> Output Class Initialized
INFO - 2024-09-21 01:59:26 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:26 --> Input Class Initialized
INFO - 2024-09-21 01:59:26 --> Language Class Initialized
ERROR - 2024-09-21 01:59:26 --> 404 Page Not Found: 2023gz/index
INFO - 2024-09-21 01:59:27 --> Config Class Initialized
INFO - 2024-09-21 01:59:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:27 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:27 --> URI Class Initialized
INFO - 2024-09-21 01:59:27 --> Router Class Initialized
INFO - 2024-09-21 01:59:27 --> Output Class Initialized
INFO - 2024-09-21 01:59:27 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:27 --> Input Class Initialized
INFO - 2024-09-21 01:59:27 --> Language Class Initialized
ERROR - 2024-09-21 01:59:27 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comgz/index
INFO - 2024-09-21 01:59:27 --> Config Class Initialized
INFO - 2024-09-21 01:59:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:27 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:27 --> URI Class Initialized
INFO - 2024-09-21 01:59:27 --> Router Class Initialized
INFO - 2024-09-21 01:59:27 --> Output Class Initialized
INFO - 2024-09-21 01:59:27 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:27 --> Input Class Initialized
INFO - 2024-09-21 01:59:27 --> Language Class Initialized
ERROR - 2024-09-21 01:59:27 --> 404 Page Not Found: 2021gz/index
INFO - 2024-09-21 01:59:28 --> Config Class Initialized
INFO - 2024-09-21 01:59:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:28 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:28 --> URI Class Initialized
INFO - 2024-09-21 01:59:28 --> Router Class Initialized
INFO - 2024-09-21 01:59:28 --> Output Class Initialized
INFO - 2024-09-21 01:59:28 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:28 --> Input Class Initialized
INFO - 2024-09-21 01:59:28 --> Language Class Initialized
ERROR - 2024-09-21 01:59:28 --> 404 Page Not Found: Public_htmlgz/index
INFO - 2024-09-21 01:59:28 --> Config Class Initialized
INFO - 2024-09-21 01:59:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:28 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:28 --> URI Class Initialized
INFO - 2024-09-21 01:59:28 --> Router Class Initialized
INFO - 2024-09-21 01:59:28 --> Output Class Initialized
INFO - 2024-09-21 01:59:28 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:28 --> Input Class Initialized
INFO - 2024-09-21 01:59:28 --> Language Class Initialized
ERROR - 2024-09-21 01:59:28 --> 404 Page Not Found: 2018gz/index
INFO - 2024-09-21 01:59:28 --> Config Class Initialized
INFO - 2024-09-21 01:59:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:28 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:28 --> URI Class Initialized
INFO - 2024-09-21 01:59:28 --> Router Class Initialized
INFO - 2024-09-21 01:59:28 --> Output Class Initialized
INFO - 2024-09-21 01:59:28 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:28 --> Input Class Initialized
INFO - 2024-09-21 01:59:28 --> Language Class Initialized
ERROR - 2024-09-21 01:59:28 --> 404 Page Not Found: Webgz/index
INFO - 2024-09-21 01:59:29 --> Config Class Initialized
INFO - 2024-09-21 01:59:29 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:29 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:29 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:29 --> URI Class Initialized
INFO - 2024-09-21 01:59:29 --> Router Class Initialized
INFO - 2024-09-21 01:59:29 --> Output Class Initialized
INFO - 2024-09-21 01:59:29 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:29 --> Input Class Initialized
INFO - 2024-09-21 01:59:29 --> Language Class Initialized
ERROR - 2024-09-21 01:59:29 --> 404 Page Not Found: Backgz/index
INFO - 2024-09-21 01:59:29 --> Config Class Initialized
INFO - 2024-09-21 01:59:29 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:29 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:29 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:29 --> URI Class Initialized
INFO - 2024-09-21 01:59:29 --> Router Class Initialized
INFO - 2024-09-21 01:59:29 --> Output Class Initialized
INFO - 2024-09-21 01:59:29 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:29 --> Input Class Initialized
INFO - 2024-09-21 01:59:29 --> Language Class Initialized
ERROR - 2024-09-21 01:59:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 01:59:30 --> Config Class Initialized
INFO - 2024-09-21 01:59:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:30 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:30 --> URI Class Initialized
INFO - 2024-09-21 01:59:30 --> Router Class Initialized
INFO - 2024-09-21 01:59:30 --> Output Class Initialized
INFO - 2024-09-21 01:59:30 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:30 --> Input Class Initialized
INFO - 2024-09-21 01:59:30 --> Language Class Initialized
ERROR - 2024-09-21 01:59:30 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 01:59:30 --> Config Class Initialized
INFO - 2024-09-21 01:59:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:30 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:30 --> URI Class Initialized
INFO - 2024-09-21 01:59:30 --> Router Class Initialized
INFO - 2024-09-21 01:59:30 --> Output Class Initialized
INFO - 2024-09-21 01:59:30 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:30 --> Input Class Initialized
INFO - 2024-09-21 01:59:30 --> Language Class Initialized
ERROR - 2024-09-21 01:59:30 --> 404 Page Not Found: 2020gz/index
INFO - 2024-09-21 01:59:31 --> Config Class Initialized
INFO - 2024-09-21 01:59:31 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:31 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:31 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:31 --> URI Class Initialized
INFO - 2024-09-21 01:59:31 --> Router Class Initialized
INFO - 2024-09-21 01:59:31 --> Output Class Initialized
INFO - 2024-09-21 01:59:31 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:31 --> Input Class Initialized
INFO - 2024-09-21 01:59:31 --> Language Class Initialized
ERROR - 2024-09-21 01:59:31 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_comgz/index
INFO - 2024-09-21 01:59:31 --> Config Class Initialized
INFO - 2024-09-21 01:59:31 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:31 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:31 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:31 --> URI Class Initialized
INFO - 2024-09-21 01:59:31 --> Router Class Initialized
INFO - 2024-09-21 01:59:31 --> Output Class Initialized
INFO - 2024-09-21 01:59:31 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:31 --> Input Class Initialized
INFO - 2024-09-21 01:59:31 --> Language Class Initialized
ERROR - 2024-09-21 01:59:31 --> 404 Page Not Found: Rsudhabdulazizmarabahangz/index
INFO - 2024-09-21 01:59:32 --> Config Class Initialized
INFO - 2024-09-21 01:59:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:32 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:32 --> URI Class Initialized
INFO - 2024-09-21 01:59:32 --> Router Class Initialized
INFO - 2024-09-21 01:59:32 --> Output Class Initialized
INFO - 2024-09-21 01:59:32 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:32 --> Input Class Initialized
INFO - 2024-09-21 01:59:32 --> Language Class Initialized
ERROR - 2024-09-21 01:59:32 --> 404 Page Not Found: Sitegz/index
INFO - 2024-09-21 01:59:32 --> Config Class Initialized
INFO - 2024-09-21 01:59:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:32 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:32 --> URI Class Initialized
INFO - 2024-09-21 01:59:32 --> Router Class Initialized
INFO - 2024-09-21 01:59:32 --> Output Class Initialized
INFO - 2024-09-21 01:59:32 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:32 --> Input Class Initialized
INFO - 2024-09-21 01:59:32 --> Language Class Initialized
ERROR - 2024-09-21 01:59:32 --> 404 Page Not Found: 20177z/index
INFO - 2024-09-21 01:59:33 --> Config Class Initialized
INFO - 2024-09-21 01:59:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:33 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:33 --> URI Class Initialized
INFO - 2024-09-21 01:59:33 --> Router Class Initialized
INFO - 2024-09-21 01:59:33 --> Output Class Initialized
INFO - 2024-09-21 01:59:33 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:33 --> Input Class Initialized
INFO - 2024-09-21 01:59:33 --> Language Class Initialized
ERROR - 2024-09-21 01:59:33 --> 404 Page Not Found: 20227z/index
INFO - 2024-09-21 01:59:33 --> Config Class Initialized
INFO - 2024-09-21 01:59:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:33 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:33 --> URI Class Initialized
INFO - 2024-09-21 01:59:33 --> Router Class Initialized
INFO - 2024-09-21 01:59:33 --> Output Class Initialized
INFO - 2024-09-21 01:59:33 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:33 --> Input Class Initialized
INFO - 2024-09-21 01:59:33 --> Language Class Initialized
ERROR - 2024-09-21 01:59:33 --> 404 Page Not Found: A7z/index
INFO - 2024-09-21 01:59:33 --> Config Class Initialized
INFO - 2024-09-21 01:59:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:33 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:33 --> URI Class Initialized
INFO - 2024-09-21 01:59:33 --> Router Class Initialized
INFO - 2024-09-21 01:59:33 --> Output Class Initialized
INFO - 2024-09-21 01:59:33 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:33 --> Input Class Initialized
INFO - 2024-09-21 01:59:33 --> Language Class Initialized
ERROR - 2024-09-21 01:59:33 --> 404 Page Not Found: Www7z/index
INFO - 2024-09-21 01:59:34 --> Config Class Initialized
INFO - 2024-09-21 01:59:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:34 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:34 --> URI Class Initialized
INFO - 2024-09-21 01:59:34 --> Router Class Initialized
INFO - 2024-09-21 01:59:34 --> Output Class Initialized
INFO - 2024-09-21 01:59:34 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:34 --> Input Class Initialized
INFO - 2024-09-21 01:59:34 --> Language Class Initialized
ERROR - 2024-09-21 01:59:34 --> 404 Page Not Found: Backup7z/index
INFO - 2024-09-21 01:59:34 --> Config Class Initialized
INFO - 2024-09-21 01:59:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:34 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:34 --> URI Class Initialized
INFO - 2024-09-21 01:59:34 --> Router Class Initialized
INFO - 2024-09-21 01:59:34 --> Output Class Initialized
INFO - 2024-09-21 01:59:34 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:34 --> Input Class Initialized
INFO - 2024-09-21 01:59:34 --> Language Class Initialized
ERROR - 2024-09-21 01:59:34 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 01:59:35 --> Config Class Initialized
INFO - 2024-09-21 01:59:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:35 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:35 --> URI Class Initialized
INFO - 2024-09-21 01:59:35 --> Router Class Initialized
INFO - 2024-09-21 01:59:35 --> Output Class Initialized
INFO - 2024-09-21 01:59:35 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:35 --> Input Class Initialized
INFO - 2024-09-21 01:59:35 --> Language Class Initialized
ERROR - 2024-09-21 01:59:35 --> 404 Page Not Found: 20197z/index
INFO - 2024-09-21 01:59:35 --> Config Class Initialized
INFO - 2024-09-21 01:59:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:35 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:35 --> URI Class Initialized
INFO - 2024-09-21 01:59:35 --> Router Class Initialized
INFO - 2024-09-21 01:59:35 --> Output Class Initialized
INFO - 2024-09-21 01:59:35 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:35 --> Input Class Initialized
INFO - 2024-09-21 01:59:35 --> Language Class Initialized
ERROR - 2024-09-21 01:59:35 --> 404 Page Not Found: Store7z/index
INFO - 2024-09-21 01:59:36 --> Config Class Initialized
INFO - 2024-09-21 01:59:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:36 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:36 --> URI Class Initialized
INFO - 2024-09-21 01:59:36 --> Router Class Initialized
INFO - 2024-09-21 01:59:36 --> Output Class Initialized
INFO - 2024-09-21 01:59:36 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:36 --> Input Class Initialized
INFO - 2024-09-21 01:59:36 --> Language Class Initialized
ERROR - 2024-09-21 01:59:36 --> 404 Page Not Found: Site7z/index
INFO - 2024-09-21 01:59:36 --> Config Class Initialized
INFO - 2024-09-21 01:59:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:36 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:36 --> URI Class Initialized
INFO - 2024-09-21 01:59:36 --> Router Class Initialized
INFO - 2024-09-21 01:59:36 --> Output Class Initialized
INFO - 2024-09-21 01:59:36 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:36 --> Input Class Initialized
INFO - 2024-09-21 01:59:36 --> Language Class Initialized
ERROR - 2024-09-21 01:59:36 --> 404 Page Not Found: 17z/index
INFO - 2024-09-21 01:59:37 --> Config Class Initialized
INFO - 2024-09-21 01:59:37 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:37 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:37 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:37 --> URI Class Initialized
INFO - 2024-09-21 01:59:37 --> Router Class Initialized
INFO - 2024-09-21 01:59:37 --> Output Class Initialized
INFO - 2024-09-21 01:59:37 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:37 --> Input Class Initialized
INFO - 2024-09-21 01:59:37 --> Language Class Initialized
ERROR - 2024-09-21 01:59:37 --> 404 Page Not Found: 20247z/index
INFO - 2024-09-21 01:59:37 --> Config Class Initialized
INFO - 2024-09-21 01:59:37 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:37 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:37 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:37 --> URI Class Initialized
INFO - 2024-09-21 01:59:37 --> Router Class Initialized
INFO - 2024-09-21 01:59:37 --> Output Class Initialized
INFO - 2024-09-21 01:59:37 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:37 --> Input Class Initialized
INFO - 2024-09-21 01:59:37 --> Language Class Initialized
ERROR - 2024-09-21 01:59:37 --> 404 Page Not Found: 20167z/index
INFO - 2024-09-21 01:59:38 --> Config Class Initialized
INFO - 2024-09-21 01:59:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:38 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:38 --> URI Class Initialized
INFO - 2024-09-21 01:59:38 --> Router Class Initialized
INFO - 2024-09-21 01:59:38 --> Output Class Initialized
INFO - 2024-09-21 01:59:38 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:38 --> Input Class Initialized
INFO - 2024-09-21 01:59:38 --> Language Class Initialized
ERROR - 2024-09-21 01:59:38 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 01:59:38 --> Config Class Initialized
INFO - 2024-09-21 01:59:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:38 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:38 --> URI Class Initialized
INFO - 2024-09-21 01:59:38 --> Router Class Initialized
INFO - 2024-09-21 01:59:38 --> Output Class Initialized
INFO - 2024-09-21 01:59:38 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:38 --> Input Class Initialized
INFO - 2024-09-21 01:59:38 --> Language Class Initialized
ERROR - 2024-09-21 01:59:38 --> 404 Page Not Found: Antrol7z/index
INFO - 2024-09-21 01:59:39 --> Config Class Initialized
INFO - 2024-09-21 01:59:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:39 --> URI Class Initialized
INFO - 2024-09-21 01:59:39 --> Router Class Initialized
INFO - 2024-09-21 01:59:39 --> Output Class Initialized
INFO - 2024-09-21 01:59:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:39 --> Input Class Initialized
INFO - 2024-09-21 01:59:39 --> Language Class Initialized
ERROR - 2024-09-21 01:59:39 --> 404 Page Not Found: 20237z/index
INFO - 2024-09-21 01:59:39 --> Config Class Initialized
INFO - 2024-09-21 01:59:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:39 --> URI Class Initialized
INFO - 2024-09-21 01:59:39 --> Router Class Initialized
INFO - 2024-09-21 01:59:39 --> Output Class Initialized
INFO - 2024-09-21 01:59:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:39 --> Input Class Initialized
INFO - 2024-09-21 01:59:39 --> Language Class Initialized
ERROR - 2024-09-21 01:59:39 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_com7z/index
INFO - 2024-09-21 01:59:39 --> Config Class Initialized
INFO - 2024-09-21 01:59:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:39 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:39 --> URI Class Initialized
INFO - 2024-09-21 01:59:39 --> Router Class Initialized
INFO - 2024-09-21 01:59:39 --> Output Class Initialized
INFO - 2024-09-21 01:59:39 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:39 --> Input Class Initialized
INFO - 2024-09-21 01:59:39 --> Language Class Initialized
ERROR - 2024-09-21 01:59:39 --> 404 Page Not Found: 20217z/index
INFO - 2024-09-21 01:59:40 --> Config Class Initialized
INFO - 2024-09-21 01:59:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:40 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:40 --> URI Class Initialized
INFO - 2024-09-21 01:59:40 --> Router Class Initialized
INFO - 2024-09-21 01:59:40 --> Output Class Initialized
INFO - 2024-09-21 01:59:40 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:40 --> Input Class Initialized
INFO - 2024-09-21 01:59:40 --> Language Class Initialized
ERROR - 2024-09-21 01:59:40 --> 404 Page Not Found: Public_html7z/index
INFO - 2024-09-21 01:59:40 --> Config Class Initialized
INFO - 2024-09-21 01:59:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:40 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:40 --> URI Class Initialized
INFO - 2024-09-21 01:59:40 --> Router Class Initialized
INFO - 2024-09-21 01:59:40 --> Output Class Initialized
INFO - 2024-09-21 01:59:40 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:40 --> Input Class Initialized
INFO - 2024-09-21 01:59:40 --> Language Class Initialized
ERROR - 2024-09-21 01:59:40 --> 404 Page Not Found: 20187z/index
INFO - 2024-09-21 01:59:41 --> Config Class Initialized
INFO - 2024-09-21 01:59:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:41 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:41 --> URI Class Initialized
INFO - 2024-09-21 01:59:41 --> Router Class Initialized
INFO - 2024-09-21 01:59:41 --> Output Class Initialized
INFO - 2024-09-21 01:59:41 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:41 --> Input Class Initialized
INFO - 2024-09-21 01:59:41 --> Language Class Initialized
ERROR - 2024-09-21 01:59:41 --> 404 Page Not Found: Web7z/index
INFO - 2024-09-21 01:59:41 --> Config Class Initialized
INFO - 2024-09-21 01:59:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:41 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:41 --> URI Class Initialized
INFO - 2024-09-21 01:59:41 --> Router Class Initialized
INFO - 2024-09-21 01:59:41 --> Output Class Initialized
INFO - 2024-09-21 01:59:41 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:41 --> Input Class Initialized
INFO - 2024-09-21 01:59:41 --> Language Class Initialized
ERROR - 2024-09-21 01:59:41 --> 404 Page Not Found: Back7z/index
INFO - 2024-09-21 01:59:42 --> Config Class Initialized
INFO - 2024-09-21 01:59:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:42 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:42 --> URI Class Initialized
INFO - 2024-09-21 01:59:42 --> Router Class Initialized
INFO - 2024-09-21 01:59:42 --> Output Class Initialized
INFO - 2024-09-21 01:59:42 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:42 --> Input Class Initialized
INFO - 2024-09-21 01:59:42 --> Language Class Initialized
ERROR - 2024-09-21 01:59:42 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 01:59:42 --> Config Class Initialized
INFO - 2024-09-21 01:59:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:42 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:42 --> URI Class Initialized
INFO - 2024-09-21 01:59:42 --> Router Class Initialized
INFO - 2024-09-21 01:59:42 --> Output Class Initialized
INFO - 2024-09-21 01:59:42 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:42 --> Input Class Initialized
INFO - 2024-09-21 01:59:42 --> Language Class Initialized
ERROR - 2024-09-21 01:59:42 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 01:59:43 --> Config Class Initialized
INFO - 2024-09-21 01:59:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:43 --> URI Class Initialized
INFO - 2024-09-21 01:59:43 --> Router Class Initialized
INFO - 2024-09-21 01:59:43 --> Output Class Initialized
INFO - 2024-09-21 01:59:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:43 --> Input Class Initialized
INFO - 2024-09-21 01:59:43 --> Language Class Initialized
ERROR - 2024-09-21 01:59:43 --> 404 Page Not Found: 20207z/index
INFO - 2024-09-21 01:59:43 --> Config Class Initialized
INFO - 2024-09-21 01:59:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:43 --> URI Class Initialized
INFO - 2024-09-21 01:59:43 --> Router Class Initialized
INFO - 2024-09-21 01:59:43 --> Output Class Initialized
INFO - 2024-09-21 01:59:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:43 --> Input Class Initialized
INFO - 2024-09-21 01:59:43 --> Language Class Initialized
ERROR - 2024-09-21 01:59:43 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_com7z/index
INFO - 2024-09-21 01:59:43 --> Config Class Initialized
INFO - 2024-09-21 01:59:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:43 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:43 --> URI Class Initialized
INFO - 2024-09-21 01:59:43 --> Router Class Initialized
INFO - 2024-09-21 01:59:43 --> Output Class Initialized
INFO - 2024-09-21 01:59:43 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:43 --> Input Class Initialized
INFO - 2024-09-21 01:59:43 --> Language Class Initialized
ERROR - 2024-09-21 01:59:43 --> 404 Page Not Found: Rsudhabdulazizmarabahan7z/index
INFO - 2024-09-21 01:59:44 --> Config Class Initialized
INFO - 2024-09-21 01:59:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:44 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:44 --> URI Class Initialized
INFO - 2024-09-21 01:59:44 --> Router Class Initialized
INFO - 2024-09-21 01:59:44 --> Output Class Initialized
INFO - 2024-09-21 01:59:44 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:44 --> Input Class Initialized
INFO - 2024-09-21 01:59:44 --> Language Class Initialized
ERROR - 2024-09-21 01:59:44 --> 404 Page Not Found: Site7z/index
INFO - 2024-09-21 01:59:44 --> Config Class Initialized
INFO - 2024-09-21 01:59:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:44 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:44 --> URI Class Initialized
INFO - 2024-09-21 01:59:44 --> Router Class Initialized
INFO - 2024-09-21 01:59:44 --> Output Class Initialized
INFO - 2024-09-21 01:59:44 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:44 --> Input Class Initialized
INFO - 2024-09-21 01:59:44 --> Language Class Initialized
ERROR - 2024-09-21 01:59:44 --> 404 Page Not Found: 2017backup/index
INFO - 2024-09-21 01:59:45 --> Config Class Initialized
INFO - 2024-09-21 01:59:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:45 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:45 --> URI Class Initialized
INFO - 2024-09-21 01:59:45 --> Router Class Initialized
INFO - 2024-09-21 01:59:45 --> Output Class Initialized
INFO - 2024-09-21 01:59:45 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:45 --> Input Class Initialized
INFO - 2024-09-21 01:59:45 --> Language Class Initialized
ERROR - 2024-09-21 01:59:45 --> 404 Page Not Found: 2022backup/index
INFO - 2024-09-21 01:59:45 --> Config Class Initialized
INFO - 2024-09-21 01:59:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:45 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:45 --> URI Class Initialized
INFO - 2024-09-21 01:59:45 --> Router Class Initialized
INFO - 2024-09-21 01:59:45 --> Output Class Initialized
INFO - 2024-09-21 01:59:45 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:45 --> Input Class Initialized
INFO - 2024-09-21 01:59:45 --> Language Class Initialized
ERROR - 2024-09-21 01:59:45 --> 404 Page Not Found: Abackup/index
INFO - 2024-09-21 01:59:46 --> Config Class Initialized
INFO - 2024-09-21 01:59:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:46 --> URI Class Initialized
INFO - 2024-09-21 01:59:46 --> Router Class Initialized
INFO - 2024-09-21 01:59:46 --> Output Class Initialized
INFO - 2024-09-21 01:59:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:46 --> Input Class Initialized
INFO - 2024-09-21 01:59:46 --> Language Class Initialized
ERROR - 2024-09-21 01:59:46 --> 404 Page Not Found: Wwwbackup/index
INFO - 2024-09-21 01:59:46 --> Config Class Initialized
INFO - 2024-09-21 01:59:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:46 --> URI Class Initialized
INFO - 2024-09-21 01:59:46 --> Router Class Initialized
INFO - 2024-09-21 01:59:46 --> Output Class Initialized
INFO - 2024-09-21 01:59:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:46 --> Input Class Initialized
INFO - 2024-09-21 01:59:46 --> Language Class Initialized
ERROR - 2024-09-21 01:59:46 --> 404 Page Not Found: Backupbackup/index
INFO - 2024-09-21 01:59:46 --> Config Class Initialized
INFO - 2024-09-21 01:59:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:46 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:46 --> URI Class Initialized
INFO - 2024-09-21 01:59:46 --> Router Class Initialized
INFO - 2024-09-21 01:59:46 --> Output Class Initialized
INFO - 2024-09-21 01:59:46 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:46 --> Input Class Initialized
INFO - 2024-09-21 01:59:46 --> Language Class Initialized
ERROR - 2024-09-21 01:59:46 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 01:59:47 --> Config Class Initialized
INFO - 2024-09-21 01:59:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:47 --> URI Class Initialized
INFO - 2024-09-21 01:59:47 --> Router Class Initialized
INFO - 2024-09-21 01:59:47 --> Output Class Initialized
INFO - 2024-09-21 01:59:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:47 --> Input Class Initialized
INFO - 2024-09-21 01:59:47 --> Language Class Initialized
ERROR - 2024-09-21 01:59:47 --> 404 Page Not Found: 2019backup/index
INFO - 2024-09-21 01:59:47 --> Config Class Initialized
INFO - 2024-09-21 01:59:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:47 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:47 --> URI Class Initialized
INFO - 2024-09-21 01:59:47 --> Router Class Initialized
INFO - 2024-09-21 01:59:47 --> Output Class Initialized
INFO - 2024-09-21 01:59:47 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:47 --> Input Class Initialized
INFO - 2024-09-21 01:59:47 --> Language Class Initialized
ERROR - 2024-09-21 01:59:47 --> 404 Page Not Found: Storebackup/index
INFO - 2024-09-21 01:59:48 --> Config Class Initialized
INFO - 2024-09-21 01:59:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:48 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:48 --> URI Class Initialized
INFO - 2024-09-21 01:59:48 --> Router Class Initialized
INFO - 2024-09-21 01:59:48 --> Output Class Initialized
INFO - 2024-09-21 01:59:48 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:48 --> Input Class Initialized
INFO - 2024-09-21 01:59:48 --> Language Class Initialized
ERROR - 2024-09-21 01:59:48 --> 404 Page Not Found: Sitebackup/index
INFO - 2024-09-21 01:59:48 --> Config Class Initialized
INFO - 2024-09-21 01:59:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:48 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:48 --> URI Class Initialized
INFO - 2024-09-21 01:59:48 --> Router Class Initialized
INFO - 2024-09-21 01:59:48 --> Output Class Initialized
INFO - 2024-09-21 01:59:48 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:48 --> Input Class Initialized
INFO - 2024-09-21 01:59:48 --> Language Class Initialized
ERROR - 2024-09-21 01:59:48 --> 404 Page Not Found: 1backup/index
INFO - 2024-09-21 01:59:48 --> Config Class Initialized
INFO - 2024-09-21 01:59:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:48 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:48 --> URI Class Initialized
INFO - 2024-09-21 01:59:48 --> Router Class Initialized
INFO - 2024-09-21 01:59:48 --> Output Class Initialized
INFO - 2024-09-21 01:59:48 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:48 --> Input Class Initialized
INFO - 2024-09-21 01:59:48 --> Language Class Initialized
ERROR - 2024-09-21 01:59:48 --> 404 Page Not Found: 2024backup/index
INFO - 2024-09-21 01:59:49 --> Config Class Initialized
INFO - 2024-09-21 01:59:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:49 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:49 --> URI Class Initialized
INFO - 2024-09-21 01:59:49 --> Router Class Initialized
INFO - 2024-09-21 01:59:49 --> Output Class Initialized
INFO - 2024-09-21 01:59:49 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:49 --> Input Class Initialized
INFO - 2024-09-21 01:59:49 --> Language Class Initialized
ERROR - 2024-09-21 01:59:49 --> 404 Page Not Found: 2016backup/index
INFO - 2024-09-21 01:59:49 --> Config Class Initialized
INFO - 2024-09-21 01:59:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:49 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:49 --> URI Class Initialized
INFO - 2024-09-21 01:59:49 --> Router Class Initialized
INFO - 2024-09-21 01:59:49 --> Output Class Initialized
INFO - 2024-09-21 01:59:49 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:49 --> Input Class Initialized
INFO - 2024-09-21 01:59:49 --> Language Class Initialized
ERROR - 2024-09-21 01:59:49 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 01:59:50 --> Config Class Initialized
INFO - 2024-09-21 01:59:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:50 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:50 --> URI Class Initialized
INFO - 2024-09-21 01:59:50 --> Router Class Initialized
INFO - 2024-09-21 01:59:50 --> Output Class Initialized
INFO - 2024-09-21 01:59:50 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:50 --> Input Class Initialized
INFO - 2024-09-21 01:59:50 --> Language Class Initialized
ERROR - 2024-09-21 01:59:50 --> 404 Page Not Found: Antrolbackup/index
INFO - 2024-09-21 01:59:50 --> Config Class Initialized
INFO - 2024-09-21 01:59:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:50 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:50 --> URI Class Initialized
INFO - 2024-09-21 01:59:50 --> Router Class Initialized
INFO - 2024-09-21 01:59:50 --> Output Class Initialized
INFO - 2024-09-21 01:59:50 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:50 --> Input Class Initialized
INFO - 2024-09-21 01:59:50 --> Language Class Initialized
ERROR - 2024-09-21 01:59:50 --> 404 Page Not Found: 2023backup/index
INFO - 2024-09-21 01:59:50 --> Config Class Initialized
INFO - 2024-09-21 01:59:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:50 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:50 --> URI Class Initialized
INFO - 2024-09-21 01:59:50 --> Router Class Initialized
INFO - 2024-09-21 01:59:50 --> Output Class Initialized
INFO - 2024-09-21 01:59:50 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:50 --> Input Class Initialized
INFO - 2024-09-21 01:59:50 --> Language Class Initialized
ERROR - 2024-09-21 01:59:50 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_combackup/index
INFO - 2024-09-21 01:59:51 --> Config Class Initialized
INFO - 2024-09-21 01:59:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:51 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:51 --> URI Class Initialized
INFO - 2024-09-21 01:59:51 --> Router Class Initialized
INFO - 2024-09-21 01:59:51 --> Output Class Initialized
INFO - 2024-09-21 01:59:51 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:51 --> Input Class Initialized
INFO - 2024-09-21 01:59:51 --> Language Class Initialized
ERROR - 2024-09-21 01:59:51 --> 404 Page Not Found: 2021backup/index
INFO - 2024-09-21 01:59:51 --> Config Class Initialized
INFO - 2024-09-21 01:59:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:51 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:51 --> URI Class Initialized
INFO - 2024-09-21 01:59:51 --> Router Class Initialized
INFO - 2024-09-21 01:59:51 --> Output Class Initialized
INFO - 2024-09-21 01:59:51 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:51 --> Input Class Initialized
INFO - 2024-09-21 01:59:51 --> Language Class Initialized
ERROR - 2024-09-21 01:59:51 --> 404 Page Not Found: Public_htmlbackup/index
INFO - 2024-09-21 01:59:52 --> Config Class Initialized
INFO - 2024-09-21 01:59:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:52 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:52 --> URI Class Initialized
INFO - 2024-09-21 01:59:52 --> Router Class Initialized
INFO - 2024-09-21 01:59:52 --> Output Class Initialized
INFO - 2024-09-21 01:59:52 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:52 --> Input Class Initialized
INFO - 2024-09-21 01:59:52 --> Language Class Initialized
ERROR - 2024-09-21 01:59:52 --> 404 Page Not Found: 2018backup/index
INFO - 2024-09-21 01:59:52 --> Config Class Initialized
INFO - 2024-09-21 01:59:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:52 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:52 --> URI Class Initialized
INFO - 2024-09-21 01:59:52 --> Router Class Initialized
INFO - 2024-09-21 01:59:52 --> Output Class Initialized
INFO - 2024-09-21 01:59:52 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:52 --> Input Class Initialized
INFO - 2024-09-21 01:59:52 --> Language Class Initialized
ERROR - 2024-09-21 01:59:52 --> 404 Page Not Found: Webbackup/index
INFO - 2024-09-21 01:59:52 --> Config Class Initialized
INFO - 2024-09-21 01:59:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:52 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:52 --> URI Class Initialized
INFO - 2024-09-21 01:59:52 --> Router Class Initialized
INFO - 2024-09-21 01:59:52 --> Output Class Initialized
INFO - 2024-09-21 01:59:52 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:52 --> Input Class Initialized
INFO - 2024-09-21 01:59:52 --> Language Class Initialized
ERROR - 2024-09-21 01:59:52 --> 404 Page Not Found: Backbackup/index
INFO - 2024-09-21 01:59:53 --> Config Class Initialized
INFO - 2024-09-21 01:59:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:53 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:53 --> URI Class Initialized
INFO - 2024-09-21 01:59:53 --> Router Class Initialized
INFO - 2024-09-21 01:59:53 --> Output Class Initialized
INFO - 2024-09-21 01:59:53 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:53 --> Input Class Initialized
INFO - 2024-09-21 01:59:53 --> Language Class Initialized
ERROR - 2024-09-21 01:59:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 01:59:53 --> Config Class Initialized
INFO - 2024-09-21 01:59:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:53 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:53 --> URI Class Initialized
INFO - 2024-09-21 01:59:53 --> Router Class Initialized
INFO - 2024-09-21 01:59:53 --> Output Class Initialized
INFO - 2024-09-21 01:59:53 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:53 --> Input Class Initialized
INFO - 2024-09-21 01:59:53 --> Language Class Initialized
ERROR - 2024-09-21 01:59:53 --> 404 Page Not Found: Wwwantrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 01:59:54 --> Config Class Initialized
INFO - 2024-09-21 01:59:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:54 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:54 --> URI Class Initialized
INFO - 2024-09-21 01:59:54 --> Router Class Initialized
INFO - 2024-09-21 01:59:54 --> Output Class Initialized
INFO - 2024-09-21 01:59:54 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:54 --> Input Class Initialized
INFO - 2024-09-21 01:59:54 --> Language Class Initialized
ERROR - 2024-09-21 01:59:54 --> 404 Page Not Found: 2020backup/index
INFO - 2024-09-21 01:59:54 --> Config Class Initialized
INFO - 2024-09-21 01:59:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:54 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:54 --> URI Class Initialized
INFO - 2024-09-21 01:59:54 --> Router Class Initialized
INFO - 2024-09-21 01:59:54 --> Output Class Initialized
INFO - 2024-09-21 01:59:54 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:54 --> Input Class Initialized
INFO - 2024-09-21 01:59:54 --> Language Class Initialized
ERROR - 2024-09-21 01:59:54 --> 404 Page Not Found: Www_antrol_rsudhabdulazizmarabahan_combackup/index
INFO - 2024-09-21 01:59:55 --> Config Class Initialized
INFO - 2024-09-21 01:59:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:55 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:55 --> URI Class Initialized
INFO - 2024-09-21 01:59:55 --> Router Class Initialized
INFO - 2024-09-21 01:59:55 --> Output Class Initialized
INFO - 2024-09-21 01:59:55 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:55 --> Input Class Initialized
INFO - 2024-09-21 01:59:55 --> Language Class Initialized
ERROR - 2024-09-21 01:59:55 --> 404 Page Not Found: Rsudhabdulazizmarabahanbackup/index
INFO - 2024-09-21 01:59:55 --> Config Class Initialized
INFO - 2024-09-21 01:59:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 01:59:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 01:59:55 --> Utf8 Class Initialized
INFO - 2024-09-21 01:59:55 --> URI Class Initialized
INFO - 2024-09-21 01:59:55 --> Router Class Initialized
INFO - 2024-09-21 01:59:55 --> Output Class Initialized
INFO - 2024-09-21 01:59:55 --> Security Class Initialized
DEBUG - 2024-09-21 01:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 01:59:55 --> Input Class Initialized
INFO - 2024-09-21 01:59:55 --> Language Class Initialized
ERROR - 2024-09-21 01:59:55 --> 404 Page Not Found: Sitebackup/index
INFO - 2024-09-21 03:09:51 --> Config Class Initialized
INFO - 2024-09-21 03:09:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:51 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:51 --> URI Class Initialized
INFO - 2024-09-21 03:09:51 --> Router Class Initialized
INFO - 2024-09-21 03:09:51 --> Output Class Initialized
INFO - 2024-09-21 03:09:51 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:51 --> Input Class Initialized
INFO - 2024-09-21 03:09:51 --> Language Class Initialized
ERROR - 2024-09-21 03:09:51 --> 404 Page Not Found: 2017zip/index
INFO - 2024-09-21 03:09:53 --> Config Class Initialized
INFO - 2024-09-21 03:09:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:53 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:53 --> URI Class Initialized
INFO - 2024-09-21 03:09:53 --> Router Class Initialized
INFO - 2024-09-21 03:09:53 --> Output Class Initialized
INFO - 2024-09-21 03:09:53 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:53 --> Input Class Initialized
INFO - 2024-09-21 03:09:53 --> Language Class Initialized
ERROR - 2024-09-21 03:09:53 --> 404 Page Not Found: 2022zip/index
INFO - 2024-09-21 03:09:54 --> Config Class Initialized
INFO - 2024-09-21 03:09:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:54 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:54 --> URI Class Initialized
INFO - 2024-09-21 03:09:54 --> Router Class Initialized
INFO - 2024-09-21 03:09:54 --> Output Class Initialized
INFO - 2024-09-21 03:09:54 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:54 --> Input Class Initialized
INFO - 2024-09-21 03:09:54 --> Language Class Initialized
ERROR - 2024-09-21 03:09:54 --> 404 Page Not Found: Azip/index
INFO - 2024-09-21 03:09:56 --> Config Class Initialized
INFO - 2024-09-21 03:09:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:56 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:56 --> URI Class Initialized
INFO - 2024-09-21 03:09:56 --> Router Class Initialized
INFO - 2024-09-21 03:09:56 --> Output Class Initialized
INFO - 2024-09-21 03:09:56 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:56 --> Input Class Initialized
INFO - 2024-09-21 03:09:56 --> Language Class Initialized
ERROR - 2024-09-21 03:09:56 --> 404 Page Not Found: Wwwzip/index
INFO - 2024-09-21 03:09:56 --> Config Class Initialized
INFO - 2024-09-21 03:09:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:56 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:56 --> URI Class Initialized
INFO - 2024-09-21 03:09:56 --> Router Class Initialized
INFO - 2024-09-21 03:09:56 --> Output Class Initialized
INFO - 2024-09-21 03:09:56 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:56 --> Input Class Initialized
INFO - 2024-09-21 03:09:56 --> Language Class Initialized
ERROR - 2024-09-21 03:09:56 --> 404 Page Not Found: Backupzip/index
INFO - 2024-09-21 03:09:58 --> Config Class Initialized
INFO - 2024-09-21 03:09:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:09:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:09:58 --> Utf8 Class Initialized
INFO - 2024-09-21 03:09:58 --> URI Class Initialized
INFO - 2024-09-21 03:09:58 --> Router Class Initialized
INFO - 2024-09-21 03:09:58 --> Output Class Initialized
INFO - 2024-09-21 03:09:58 --> Security Class Initialized
DEBUG - 2024-09-21 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:09:58 --> Input Class Initialized
INFO - 2024-09-21 03:09:58 --> Language Class Initialized
ERROR - 2024-09-21 03:09:58 --> 404 Page Not Found: 2019zip/index
INFO - 2024-09-21 03:10:00 --> Config Class Initialized
INFO - 2024-09-21 03:10:00 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:00 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:00 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:00 --> URI Class Initialized
INFO - 2024-09-21 03:10:00 --> Router Class Initialized
INFO - 2024-09-21 03:10:00 --> Output Class Initialized
INFO - 2024-09-21 03:10:00 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:00 --> Input Class Initialized
INFO - 2024-09-21 03:10:00 --> Language Class Initialized
ERROR - 2024-09-21 03:10:00 --> 404 Page Not Found: Storezip/index
INFO - 2024-09-21 03:10:01 --> Config Class Initialized
INFO - 2024-09-21 03:10:01 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:01 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:01 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:01 --> URI Class Initialized
INFO - 2024-09-21 03:10:01 --> Router Class Initialized
INFO - 2024-09-21 03:10:01 --> Output Class Initialized
INFO - 2024-09-21 03:10:01 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:01 --> Input Class Initialized
INFO - 2024-09-21 03:10:01 --> Language Class Initialized
ERROR - 2024-09-21 03:10:01 --> 404 Page Not Found: Sitezip/index
INFO - 2024-09-21 03:10:03 --> Config Class Initialized
INFO - 2024-09-21 03:10:03 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:03 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:03 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:03 --> URI Class Initialized
INFO - 2024-09-21 03:10:03 --> Router Class Initialized
INFO - 2024-09-21 03:10:03 --> Output Class Initialized
INFO - 2024-09-21 03:10:03 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:03 --> Input Class Initialized
INFO - 2024-09-21 03:10:03 --> Language Class Initialized
ERROR - 2024-09-21 03:10:03 --> 404 Page Not Found: 1zip/index
INFO - 2024-09-21 03:10:06 --> Config Class Initialized
INFO - 2024-09-21 03:10:06 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:06 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:06 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:06 --> URI Class Initialized
INFO - 2024-09-21 03:10:06 --> Router Class Initialized
INFO - 2024-09-21 03:10:06 --> Output Class Initialized
INFO - 2024-09-21 03:10:06 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:06 --> Input Class Initialized
INFO - 2024-09-21 03:10:06 --> Language Class Initialized
ERROR - 2024-09-21 03:10:06 --> 404 Page Not Found: 2024zip/index
INFO - 2024-09-21 03:10:09 --> Config Class Initialized
INFO - 2024-09-21 03:10:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:09 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:09 --> URI Class Initialized
INFO - 2024-09-21 03:10:09 --> Router Class Initialized
INFO - 2024-09-21 03:10:09 --> Output Class Initialized
INFO - 2024-09-21 03:10:09 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:09 --> Input Class Initialized
INFO - 2024-09-21 03:10:09 --> Language Class Initialized
ERROR - 2024-09-21 03:10:09 --> 404 Page Not Found: 2016zip/index
INFO - 2024-09-21 03:10:11 --> Config Class Initialized
INFO - 2024-09-21 03:10:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:10:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:10:11 --> Utf8 Class Initialized
INFO - 2024-09-21 03:10:11 --> URI Class Initialized
INFO - 2024-09-21 03:10:11 --> Router Class Initialized
INFO - 2024-09-21 03:10:11 --> Output Class Initialized
INFO - 2024-09-21 03:10:11 --> Security Class Initialized
DEBUG - 2024-09-21 03:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:10:11 --> Input Class Initialized
INFO - 2024-09-21 03:10:11 --> Language Class Initialized
ERROR - 2024-09-21 03:10:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomzip/index
INFO - 2024-09-21 03:12:21 --> Config Class Initialized
INFO - 2024-09-21 03:12:21 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:21 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:21 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:21 --> URI Class Initialized
INFO - 2024-09-21 03:12:21 --> Router Class Initialized
INFO - 2024-09-21 03:12:21 --> Output Class Initialized
INFO - 2024-09-21 03:12:21 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:21 --> Input Class Initialized
INFO - 2024-09-21 03:12:21 --> Language Class Initialized
ERROR - 2024-09-21 03:12:21 --> 404 Page Not Found: 2017rar/index
INFO - 2024-09-21 03:12:22 --> Config Class Initialized
INFO - 2024-09-21 03:12:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:22 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:22 --> URI Class Initialized
INFO - 2024-09-21 03:12:22 --> Router Class Initialized
INFO - 2024-09-21 03:12:22 --> Output Class Initialized
INFO - 2024-09-21 03:12:22 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:22 --> Input Class Initialized
INFO - 2024-09-21 03:12:22 --> Language Class Initialized
ERROR - 2024-09-21 03:12:22 --> 404 Page Not Found: 2022rar/index
INFO - 2024-09-21 03:12:23 --> Config Class Initialized
INFO - 2024-09-21 03:12:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:23 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:23 --> URI Class Initialized
INFO - 2024-09-21 03:12:23 --> Router Class Initialized
INFO - 2024-09-21 03:12:23 --> Output Class Initialized
INFO - 2024-09-21 03:12:23 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:23 --> Input Class Initialized
INFO - 2024-09-21 03:12:23 --> Language Class Initialized
ERROR - 2024-09-21 03:12:23 --> 404 Page Not Found: Arar/index
INFO - 2024-09-21 03:12:24 --> Config Class Initialized
INFO - 2024-09-21 03:12:24 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:24 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:24 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:24 --> URI Class Initialized
INFO - 2024-09-21 03:12:24 --> Router Class Initialized
INFO - 2024-09-21 03:12:24 --> Output Class Initialized
INFO - 2024-09-21 03:12:24 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:24 --> Input Class Initialized
INFO - 2024-09-21 03:12:24 --> Language Class Initialized
ERROR - 2024-09-21 03:12:24 --> 404 Page Not Found: Wwwrar/index
INFO - 2024-09-21 03:12:25 --> Config Class Initialized
INFO - 2024-09-21 03:12:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:25 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:25 --> URI Class Initialized
INFO - 2024-09-21 03:12:25 --> Router Class Initialized
INFO - 2024-09-21 03:12:25 --> Output Class Initialized
INFO - 2024-09-21 03:12:25 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:25 --> Input Class Initialized
INFO - 2024-09-21 03:12:25 --> Language Class Initialized
ERROR - 2024-09-21 03:12:25 --> 404 Page Not Found: Backuprar/index
INFO - 2024-09-21 03:12:26 --> Config Class Initialized
INFO - 2024-09-21 03:12:26 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:26 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:26 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:26 --> URI Class Initialized
INFO - 2024-09-21 03:12:26 --> Router Class Initialized
INFO - 2024-09-21 03:12:26 --> Output Class Initialized
INFO - 2024-09-21 03:12:26 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:26 --> Input Class Initialized
INFO - 2024-09-21 03:12:26 --> Language Class Initialized
ERROR - 2024-09-21 03:12:26 --> 404 Page Not Found: 2019rar/index
INFO - 2024-09-21 03:12:26 --> Config Class Initialized
INFO - 2024-09-21 03:12:26 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:26 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:26 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:26 --> URI Class Initialized
INFO - 2024-09-21 03:12:26 --> Router Class Initialized
INFO - 2024-09-21 03:12:26 --> Output Class Initialized
INFO - 2024-09-21 03:12:26 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:26 --> Input Class Initialized
INFO - 2024-09-21 03:12:26 --> Language Class Initialized
ERROR - 2024-09-21 03:12:26 --> 404 Page Not Found: Storerar/index
INFO - 2024-09-21 03:12:27 --> Config Class Initialized
INFO - 2024-09-21 03:12:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:27 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:27 --> URI Class Initialized
INFO - 2024-09-21 03:12:27 --> Router Class Initialized
INFO - 2024-09-21 03:12:27 --> Output Class Initialized
INFO - 2024-09-21 03:12:27 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:27 --> Input Class Initialized
INFO - 2024-09-21 03:12:27 --> Language Class Initialized
ERROR - 2024-09-21 03:12:27 --> 404 Page Not Found: Siterar/index
INFO - 2024-09-21 03:12:27 --> Config Class Initialized
INFO - 2024-09-21 03:12:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:27 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:27 --> URI Class Initialized
INFO - 2024-09-21 03:12:27 --> Router Class Initialized
INFO - 2024-09-21 03:12:27 --> Output Class Initialized
INFO - 2024-09-21 03:12:27 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:27 --> Input Class Initialized
INFO - 2024-09-21 03:12:27 --> Language Class Initialized
ERROR - 2024-09-21 03:12:27 --> 404 Page Not Found: 1rar/index
INFO - 2024-09-21 03:12:29 --> Config Class Initialized
INFO - 2024-09-21 03:12:29 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:29 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:29 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:29 --> URI Class Initialized
INFO - 2024-09-21 03:12:29 --> Router Class Initialized
INFO - 2024-09-21 03:12:29 --> Output Class Initialized
INFO - 2024-09-21 03:12:29 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:29 --> Input Class Initialized
INFO - 2024-09-21 03:12:29 --> Language Class Initialized
ERROR - 2024-09-21 03:12:29 --> 404 Page Not Found: 2024rar/index
INFO - 2024-09-21 03:12:30 --> Config Class Initialized
INFO - 2024-09-21 03:12:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:30 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:30 --> URI Class Initialized
INFO - 2024-09-21 03:12:30 --> Router Class Initialized
INFO - 2024-09-21 03:12:30 --> Output Class Initialized
INFO - 2024-09-21 03:12:30 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:30 --> Input Class Initialized
INFO - 2024-09-21 03:12:30 --> Language Class Initialized
ERROR - 2024-09-21 03:12:30 --> 404 Page Not Found: 2016rar/index
INFO - 2024-09-21 03:12:30 --> Config Class Initialized
INFO - 2024-09-21 03:12:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:30 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:30 --> URI Class Initialized
INFO - 2024-09-21 03:12:30 --> Router Class Initialized
INFO - 2024-09-21 03:12:30 --> Output Class Initialized
INFO - 2024-09-21 03:12:30 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:30 --> Input Class Initialized
INFO - 2024-09-21 03:12:30 --> Language Class Initialized
ERROR - 2024-09-21 03:12:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 03:12:31 --> Config Class Initialized
INFO - 2024-09-21 03:12:31 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:31 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:31 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:31 --> URI Class Initialized
INFO - 2024-09-21 03:12:31 --> Router Class Initialized
INFO - 2024-09-21 03:12:31 --> Output Class Initialized
INFO - 2024-09-21 03:12:31 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:31 --> Input Class Initialized
INFO - 2024-09-21 03:12:31 --> Language Class Initialized
ERROR - 2024-09-21 03:12:31 --> 404 Page Not Found: Antrolrar/index
INFO - 2024-09-21 03:12:32 --> Config Class Initialized
INFO - 2024-09-21 03:12:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:32 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:32 --> URI Class Initialized
INFO - 2024-09-21 03:12:32 --> Router Class Initialized
INFO - 2024-09-21 03:12:32 --> Output Class Initialized
INFO - 2024-09-21 03:12:32 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:32 --> Input Class Initialized
INFO - 2024-09-21 03:12:32 --> Language Class Initialized
ERROR - 2024-09-21 03:12:32 --> 404 Page Not Found: 2023rar/index
INFO - 2024-09-21 03:12:32 --> Config Class Initialized
INFO - 2024-09-21 03:12:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:32 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:32 --> URI Class Initialized
INFO - 2024-09-21 03:12:32 --> Router Class Initialized
INFO - 2024-09-21 03:12:32 --> Output Class Initialized
INFO - 2024-09-21 03:12:32 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:32 --> Input Class Initialized
INFO - 2024-09-21 03:12:32 --> Language Class Initialized
ERROR - 2024-09-21 03:12:32 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comrar/index
INFO - 2024-09-21 03:12:33 --> Config Class Initialized
INFO - 2024-09-21 03:12:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:33 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:33 --> URI Class Initialized
INFO - 2024-09-21 03:12:33 --> Router Class Initialized
INFO - 2024-09-21 03:12:33 --> Output Class Initialized
INFO - 2024-09-21 03:12:33 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:33 --> Input Class Initialized
INFO - 2024-09-21 03:12:33 --> Language Class Initialized
ERROR - 2024-09-21 03:12:33 --> 404 Page Not Found: 2021rar/index
INFO - 2024-09-21 03:12:34 --> Config Class Initialized
INFO - 2024-09-21 03:12:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:34 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:34 --> URI Class Initialized
INFO - 2024-09-21 03:12:34 --> Router Class Initialized
INFO - 2024-09-21 03:12:34 --> Output Class Initialized
INFO - 2024-09-21 03:12:34 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:34 --> Input Class Initialized
INFO - 2024-09-21 03:12:34 --> Language Class Initialized
ERROR - 2024-09-21 03:12:34 --> 404 Page Not Found: Public_htmlrar/index
INFO - 2024-09-21 03:12:35 --> Config Class Initialized
INFO - 2024-09-21 03:12:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:35 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:35 --> URI Class Initialized
INFO - 2024-09-21 03:12:35 --> Router Class Initialized
INFO - 2024-09-21 03:12:35 --> Output Class Initialized
INFO - 2024-09-21 03:12:35 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:35 --> Input Class Initialized
INFO - 2024-09-21 03:12:35 --> Language Class Initialized
ERROR - 2024-09-21 03:12:35 --> 404 Page Not Found: 2018rar/index
INFO - 2024-09-21 03:12:35 --> Config Class Initialized
INFO - 2024-09-21 03:12:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:35 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:35 --> URI Class Initialized
INFO - 2024-09-21 03:12:35 --> Router Class Initialized
INFO - 2024-09-21 03:12:35 --> Output Class Initialized
INFO - 2024-09-21 03:12:35 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:35 --> Input Class Initialized
INFO - 2024-09-21 03:12:35 --> Language Class Initialized
ERROR - 2024-09-21 03:12:35 --> 404 Page Not Found: Webrar/index
INFO - 2024-09-21 03:12:36 --> Config Class Initialized
INFO - 2024-09-21 03:12:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:36 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:36 --> URI Class Initialized
INFO - 2024-09-21 03:12:36 --> Router Class Initialized
INFO - 2024-09-21 03:12:36 --> Output Class Initialized
INFO - 2024-09-21 03:12:36 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:36 --> Input Class Initialized
INFO - 2024-09-21 03:12:36 --> Language Class Initialized
ERROR - 2024-09-21 03:12:36 --> 404 Page Not Found: Backrar/index
INFO - 2024-09-21 03:12:36 --> Config Class Initialized
INFO - 2024-09-21 03:12:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:36 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:36 --> URI Class Initialized
INFO - 2024-09-21 03:12:36 --> Router Class Initialized
INFO - 2024-09-21 03:12:36 --> Output Class Initialized
INFO - 2024-09-21 03:12:36 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:36 --> Input Class Initialized
INFO - 2024-09-21 03:12:36 --> Language Class Initialized
ERROR - 2024-09-21 03:12:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomrar/index
INFO - 2024-09-21 03:12:37 --> Config Class Initialized
INFO - 2024-09-21 03:12:37 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:37 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:37 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:37 --> URI Class Initialized
INFO - 2024-09-21 03:12:37 --> Router Class Initialized
INFO - 2024-09-21 03:12:37 --> Output Class Initialized
INFO - 2024-09-21 03:12:37 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:37 --> Input Class Initialized
INFO - 2024-09-21 03:12:37 --> Language Class Initialized
ERROR - 2024-09-21 03:12:37 --> 404 Page Not Found: 2020rar/index
INFO - 2024-09-21 03:12:38 --> Config Class Initialized
INFO - 2024-09-21 03:12:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:38 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:38 --> URI Class Initialized
INFO - 2024-09-21 03:12:38 --> Router Class Initialized
INFO - 2024-09-21 03:12:38 --> Output Class Initialized
INFO - 2024-09-21 03:12:38 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:38 --> Input Class Initialized
INFO - 2024-09-21 03:12:38 --> Language Class Initialized
ERROR - 2024-09-21 03:12:38 --> 404 Page Not Found: Rsudhabdulazizmarabahanrar/index
INFO - 2024-09-21 03:12:38 --> Config Class Initialized
INFO - 2024-09-21 03:12:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:38 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:38 --> URI Class Initialized
INFO - 2024-09-21 03:12:38 --> Router Class Initialized
INFO - 2024-09-21 03:12:38 --> Output Class Initialized
INFO - 2024-09-21 03:12:38 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:38 --> Input Class Initialized
INFO - 2024-09-21 03:12:38 --> Language Class Initialized
ERROR - 2024-09-21 03:12:38 --> 404 Page Not Found: Siterar/index
INFO - 2024-09-21 03:12:39 --> Config Class Initialized
INFO - 2024-09-21 03:12:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:39 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:39 --> URI Class Initialized
INFO - 2024-09-21 03:12:39 --> Router Class Initialized
INFO - 2024-09-21 03:12:39 --> Output Class Initialized
INFO - 2024-09-21 03:12:39 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:39 --> Input Class Initialized
INFO - 2024-09-21 03:12:39 --> Language Class Initialized
ERROR - 2024-09-21 03:12:39 --> 404 Page Not Found: 2017tar/index
INFO - 2024-09-21 03:12:39 --> Config Class Initialized
INFO - 2024-09-21 03:12:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:39 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:39 --> URI Class Initialized
INFO - 2024-09-21 03:12:39 --> Router Class Initialized
INFO - 2024-09-21 03:12:39 --> Output Class Initialized
INFO - 2024-09-21 03:12:39 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:39 --> Input Class Initialized
INFO - 2024-09-21 03:12:39 --> Language Class Initialized
ERROR - 2024-09-21 03:12:39 --> 404 Page Not Found: 2022tar/index
INFO - 2024-09-21 03:12:41 --> Config Class Initialized
INFO - 2024-09-21 03:12:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:41 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:41 --> URI Class Initialized
INFO - 2024-09-21 03:12:41 --> Router Class Initialized
INFO - 2024-09-21 03:12:41 --> Output Class Initialized
INFO - 2024-09-21 03:12:41 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:41 --> Input Class Initialized
INFO - 2024-09-21 03:12:41 --> Language Class Initialized
ERROR - 2024-09-21 03:12:41 --> 404 Page Not Found: Atar/index
INFO - 2024-09-21 03:12:41 --> Config Class Initialized
INFO - 2024-09-21 03:12:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:41 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:41 --> URI Class Initialized
INFO - 2024-09-21 03:12:41 --> Router Class Initialized
INFO - 2024-09-21 03:12:41 --> Output Class Initialized
INFO - 2024-09-21 03:12:41 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:41 --> Input Class Initialized
INFO - 2024-09-21 03:12:41 --> Language Class Initialized
ERROR - 2024-09-21 03:12:41 --> 404 Page Not Found: Wwwtar/index
INFO - 2024-09-21 03:12:42 --> Config Class Initialized
INFO - 2024-09-21 03:12:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:42 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:42 --> URI Class Initialized
INFO - 2024-09-21 03:12:42 --> Router Class Initialized
INFO - 2024-09-21 03:12:42 --> Output Class Initialized
INFO - 2024-09-21 03:12:42 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:42 --> Input Class Initialized
INFO - 2024-09-21 03:12:42 --> Language Class Initialized
ERROR - 2024-09-21 03:12:42 --> 404 Page Not Found: Backuptar/index
INFO - 2024-09-21 03:12:42 --> Config Class Initialized
INFO - 2024-09-21 03:12:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:42 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:42 --> URI Class Initialized
INFO - 2024-09-21 03:12:42 --> Router Class Initialized
INFO - 2024-09-21 03:12:42 --> Output Class Initialized
INFO - 2024-09-21 03:12:42 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:42 --> Input Class Initialized
INFO - 2024-09-21 03:12:42 --> Language Class Initialized
ERROR - 2024-09-21 03:12:42 --> 404 Page Not Found: 2019tar/index
INFO - 2024-09-21 03:12:43 --> Config Class Initialized
INFO - 2024-09-21 03:12:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:43 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:43 --> URI Class Initialized
INFO - 2024-09-21 03:12:43 --> Router Class Initialized
INFO - 2024-09-21 03:12:43 --> Output Class Initialized
INFO - 2024-09-21 03:12:43 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:43 --> Input Class Initialized
INFO - 2024-09-21 03:12:43 --> Language Class Initialized
ERROR - 2024-09-21 03:12:43 --> 404 Page Not Found: Storetar/index
INFO - 2024-09-21 03:12:44 --> Config Class Initialized
INFO - 2024-09-21 03:12:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:44 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:44 --> URI Class Initialized
INFO - 2024-09-21 03:12:44 --> Router Class Initialized
INFO - 2024-09-21 03:12:44 --> Output Class Initialized
INFO - 2024-09-21 03:12:44 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:44 --> Input Class Initialized
INFO - 2024-09-21 03:12:44 --> Language Class Initialized
ERROR - 2024-09-21 03:12:44 --> 404 Page Not Found: Sitetar/index
INFO - 2024-09-21 03:12:45 --> Config Class Initialized
INFO - 2024-09-21 03:12:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:45 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:45 --> URI Class Initialized
INFO - 2024-09-21 03:12:45 --> Router Class Initialized
INFO - 2024-09-21 03:12:45 --> Output Class Initialized
INFO - 2024-09-21 03:12:45 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:45 --> Input Class Initialized
INFO - 2024-09-21 03:12:45 --> Language Class Initialized
ERROR - 2024-09-21 03:12:45 --> 404 Page Not Found: 1tar/index
INFO - 2024-09-21 03:12:46 --> Config Class Initialized
INFO - 2024-09-21 03:12:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:46 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:46 --> URI Class Initialized
INFO - 2024-09-21 03:12:46 --> Router Class Initialized
INFO - 2024-09-21 03:12:46 --> Output Class Initialized
INFO - 2024-09-21 03:12:46 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:46 --> Input Class Initialized
INFO - 2024-09-21 03:12:46 --> Language Class Initialized
ERROR - 2024-09-21 03:12:46 --> 404 Page Not Found: 2024tar/index
INFO - 2024-09-21 03:12:47 --> Config Class Initialized
INFO - 2024-09-21 03:12:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:47 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:47 --> URI Class Initialized
INFO - 2024-09-21 03:12:47 --> Router Class Initialized
INFO - 2024-09-21 03:12:47 --> Output Class Initialized
INFO - 2024-09-21 03:12:47 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:47 --> Input Class Initialized
INFO - 2024-09-21 03:12:47 --> Language Class Initialized
ERROR - 2024-09-21 03:12:47 --> 404 Page Not Found: 2016tar/index
INFO - 2024-09-21 03:12:47 --> Config Class Initialized
INFO - 2024-09-21 03:12:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:47 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:47 --> URI Class Initialized
INFO - 2024-09-21 03:12:47 --> Router Class Initialized
INFO - 2024-09-21 03:12:47 --> Output Class Initialized
INFO - 2024-09-21 03:12:47 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:47 --> Input Class Initialized
INFO - 2024-09-21 03:12:47 --> Language Class Initialized
ERROR - 2024-09-21 03:12:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 03:12:48 --> Config Class Initialized
INFO - 2024-09-21 03:12:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:48 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:48 --> URI Class Initialized
INFO - 2024-09-21 03:12:48 --> Router Class Initialized
INFO - 2024-09-21 03:12:48 --> Output Class Initialized
INFO - 2024-09-21 03:12:48 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:48 --> Input Class Initialized
INFO - 2024-09-21 03:12:48 --> Language Class Initialized
ERROR - 2024-09-21 03:12:48 --> 404 Page Not Found: Antroltar/index
INFO - 2024-09-21 03:12:49 --> Config Class Initialized
INFO - 2024-09-21 03:12:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:49 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:49 --> URI Class Initialized
INFO - 2024-09-21 03:12:49 --> Router Class Initialized
INFO - 2024-09-21 03:12:49 --> Output Class Initialized
INFO - 2024-09-21 03:12:49 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:49 --> Input Class Initialized
INFO - 2024-09-21 03:12:49 --> Language Class Initialized
ERROR - 2024-09-21 03:12:49 --> 404 Page Not Found: 2023tar/index
INFO - 2024-09-21 03:12:49 --> Config Class Initialized
INFO - 2024-09-21 03:12:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:49 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:49 --> URI Class Initialized
INFO - 2024-09-21 03:12:49 --> Router Class Initialized
INFO - 2024-09-21 03:12:49 --> Output Class Initialized
INFO - 2024-09-21 03:12:49 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:49 --> Input Class Initialized
INFO - 2024-09-21 03:12:49 --> Language Class Initialized
ERROR - 2024-09-21 03:12:49 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comtar/index
INFO - 2024-09-21 03:12:50 --> Config Class Initialized
INFO - 2024-09-21 03:12:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:50 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:50 --> URI Class Initialized
INFO - 2024-09-21 03:12:50 --> Router Class Initialized
INFO - 2024-09-21 03:12:50 --> Output Class Initialized
INFO - 2024-09-21 03:12:50 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:50 --> Input Class Initialized
INFO - 2024-09-21 03:12:50 --> Language Class Initialized
ERROR - 2024-09-21 03:12:50 --> 404 Page Not Found: 2021tar/index
INFO - 2024-09-21 03:12:51 --> Config Class Initialized
INFO - 2024-09-21 03:12:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:51 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:51 --> URI Class Initialized
INFO - 2024-09-21 03:12:51 --> Router Class Initialized
INFO - 2024-09-21 03:12:51 --> Output Class Initialized
INFO - 2024-09-21 03:12:51 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:51 --> Input Class Initialized
INFO - 2024-09-21 03:12:51 --> Language Class Initialized
ERROR - 2024-09-21 03:12:51 --> 404 Page Not Found: Public_htmltar/index
INFO - 2024-09-21 03:12:51 --> Config Class Initialized
INFO - 2024-09-21 03:12:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:51 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:51 --> URI Class Initialized
INFO - 2024-09-21 03:12:51 --> Router Class Initialized
INFO - 2024-09-21 03:12:51 --> Output Class Initialized
INFO - 2024-09-21 03:12:51 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:51 --> Input Class Initialized
INFO - 2024-09-21 03:12:51 --> Language Class Initialized
ERROR - 2024-09-21 03:12:51 --> 404 Page Not Found: 2018tar/index
INFO - 2024-09-21 03:12:52 --> Config Class Initialized
INFO - 2024-09-21 03:12:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:52 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:52 --> URI Class Initialized
INFO - 2024-09-21 03:12:52 --> Router Class Initialized
INFO - 2024-09-21 03:12:52 --> Output Class Initialized
INFO - 2024-09-21 03:12:52 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:52 --> Input Class Initialized
INFO - 2024-09-21 03:12:52 --> Language Class Initialized
ERROR - 2024-09-21 03:12:52 --> 404 Page Not Found: Webtar/index
INFO - 2024-09-21 03:12:52 --> Config Class Initialized
INFO - 2024-09-21 03:12:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:52 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:52 --> URI Class Initialized
INFO - 2024-09-21 03:12:52 --> Router Class Initialized
INFO - 2024-09-21 03:12:52 --> Output Class Initialized
INFO - 2024-09-21 03:12:52 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:52 --> Input Class Initialized
INFO - 2024-09-21 03:12:52 --> Language Class Initialized
ERROR - 2024-09-21 03:12:52 --> 404 Page Not Found: Backtar/index
INFO - 2024-09-21 03:12:53 --> Config Class Initialized
INFO - 2024-09-21 03:12:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:53 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:53 --> URI Class Initialized
INFO - 2024-09-21 03:12:53 --> Router Class Initialized
INFO - 2024-09-21 03:12:53 --> Output Class Initialized
INFO - 2024-09-21 03:12:53 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:53 --> Input Class Initialized
INFO - 2024-09-21 03:12:53 --> Language Class Initialized
ERROR - 2024-09-21 03:12:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtar/index
INFO - 2024-09-21 03:12:54 --> Config Class Initialized
INFO - 2024-09-21 03:12:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:54 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:54 --> URI Class Initialized
INFO - 2024-09-21 03:12:54 --> Router Class Initialized
INFO - 2024-09-21 03:12:54 --> Output Class Initialized
INFO - 2024-09-21 03:12:54 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:54 --> Input Class Initialized
INFO - 2024-09-21 03:12:54 --> Language Class Initialized
ERROR - 2024-09-21 03:12:54 --> 404 Page Not Found: 2020tar/index
INFO - 2024-09-21 03:12:54 --> Config Class Initialized
INFO - 2024-09-21 03:12:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:54 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:54 --> URI Class Initialized
INFO - 2024-09-21 03:12:54 --> Router Class Initialized
INFO - 2024-09-21 03:12:54 --> Output Class Initialized
INFO - 2024-09-21 03:12:54 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:54 --> Input Class Initialized
INFO - 2024-09-21 03:12:54 --> Language Class Initialized
ERROR - 2024-09-21 03:12:54 --> 404 Page Not Found: Rsudhabdulazizmarabahantar/index
INFO - 2024-09-21 03:12:55 --> Config Class Initialized
INFO - 2024-09-21 03:12:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:55 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:55 --> URI Class Initialized
INFO - 2024-09-21 03:12:55 --> Router Class Initialized
INFO - 2024-09-21 03:12:55 --> Output Class Initialized
INFO - 2024-09-21 03:12:55 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:55 --> Input Class Initialized
INFO - 2024-09-21 03:12:55 --> Language Class Initialized
ERROR - 2024-09-21 03:12:55 --> 404 Page Not Found: Sitetar/index
INFO - 2024-09-21 03:12:55 --> Config Class Initialized
INFO - 2024-09-21 03:12:55 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:55 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:55 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:55 --> URI Class Initialized
INFO - 2024-09-21 03:12:55 --> Router Class Initialized
INFO - 2024-09-21 03:12:55 --> Output Class Initialized
INFO - 2024-09-21 03:12:55 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:55 --> Input Class Initialized
INFO - 2024-09-21 03:12:55 --> Language Class Initialized
ERROR - 2024-09-21 03:12:55 --> 404 Page Not Found: 2017targz/index
INFO - 2024-09-21 03:12:56 --> Config Class Initialized
INFO - 2024-09-21 03:12:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:56 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:56 --> URI Class Initialized
INFO - 2024-09-21 03:12:56 --> Router Class Initialized
INFO - 2024-09-21 03:12:56 --> Output Class Initialized
INFO - 2024-09-21 03:12:56 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:56 --> Input Class Initialized
INFO - 2024-09-21 03:12:56 --> Language Class Initialized
ERROR - 2024-09-21 03:12:56 --> 404 Page Not Found: 2022targz/index
INFO - 2024-09-21 03:12:56 --> Config Class Initialized
INFO - 2024-09-21 03:12:56 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:56 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:56 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:56 --> URI Class Initialized
INFO - 2024-09-21 03:12:56 --> Router Class Initialized
INFO - 2024-09-21 03:12:56 --> Output Class Initialized
INFO - 2024-09-21 03:12:56 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:56 --> Input Class Initialized
INFO - 2024-09-21 03:12:56 --> Language Class Initialized
ERROR - 2024-09-21 03:12:56 --> 404 Page Not Found: Atargz/index
INFO - 2024-09-21 03:12:57 --> Config Class Initialized
INFO - 2024-09-21 03:12:57 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:57 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:57 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:57 --> URI Class Initialized
INFO - 2024-09-21 03:12:57 --> Router Class Initialized
INFO - 2024-09-21 03:12:57 --> Output Class Initialized
INFO - 2024-09-21 03:12:57 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:57 --> Input Class Initialized
INFO - 2024-09-21 03:12:57 --> Language Class Initialized
ERROR - 2024-09-21 03:12:57 --> 404 Page Not Found: Wwwtargz/index
INFO - 2024-09-21 03:12:58 --> Config Class Initialized
INFO - 2024-09-21 03:12:58 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:58 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:58 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:58 --> URI Class Initialized
INFO - 2024-09-21 03:12:58 --> Router Class Initialized
INFO - 2024-09-21 03:12:58 --> Output Class Initialized
INFO - 2024-09-21 03:12:58 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:58 --> Input Class Initialized
INFO - 2024-09-21 03:12:58 --> Language Class Initialized
ERROR - 2024-09-21 03:12:58 --> 404 Page Not Found: Backuptargz/index
INFO - 2024-09-21 03:12:59 --> Config Class Initialized
INFO - 2024-09-21 03:12:59 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:12:59 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:12:59 --> Utf8 Class Initialized
INFO - 2024-09-21 03:12:59 --> URI Class Initialized
INFO - 2024-09-21 03:12:59 --> Router Class Initialized
INFO - 2024-09-21 03:12:59 --> Output Class Initialized
INFO - 2024-09-21 03:12:59 --> Security Class Initialized
DEBUG - 2024-09-21 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:12:59 --> Input Class Initialized
INFO - 2024-09-21 03:12:59 --> Language Class Initialized
ERROR - 2024-09-21 03:12:59 --> 404 Page Not Found: 2019targz/index
INFO - 2024-09-21 03:13:00 --> Config Class Initialized
INFO - 2024-09-21 03:13:00 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:00 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:00 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:00 --> URI Class Initialized
INFO - 2024-09-21 03:13:00 --> Router Class Initialized
INFO - 2024-09-21 03:13:00 --> Output Class Initialized
INFO - 2024-09-21 03:13:00 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:00 --> Input Class Initialized
INFO - 2024-09-21 03:13:00 --> Language Class Initialized
ERROR - 2024-09-21 03:13:00 --> 404 Page Not Found: Storetargz/index
INFO - 2024-09-21 03:13:01 --> Config Class Initialized
INFO - 2024-09-21 03:13:01 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:01 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:01 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:01 --> URI Class Initialized
INFO - 2024-09-21 03:13:01 --> Router Class Initialized
INFO - 2024-09-21 03:13:01 --> Output Class Initialized
INFO - 2024-09-21 03:13:01 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:01 --> Input Class Initialized
INFO - 2024-09-21 03:13:01 --> Language Class Initialized
ERROR - 2024-09-21 03:13:01 --> 404 Page Not Found: Sitetargz/index
INFO - 2024-09-21 03:13:01 --> Config Class Initialized
INFO - 2024-09-21 03:13:01 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:01 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:01 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:01 --> URI Class Initialized
INFO - 2024-09-21 03:13:01 --> Router Class Initialized
INFO - 2024-09-21 03:13:01 --> Output Class Initialized
INFO - 2024-09-21 03:13:01 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:01 --> Input Class Initialized
INFO - 2024-09-21 03:13:01 --> Language Class Initialized
ERROR - 2024-09-21 03:13:01 --> 404 Page Not Found: 1targz/index
INFO - 2024-09-21 03:13:02 --> Config Class Initialized
INFO - 2024-09-21 03:13:02 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:02 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:02 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:02 --> URI Class Initialized
INFO - 2024-09-21 03:13:02 --> Router Class Initialized
INFO - 2024-09-21 03:13:02 --> Output Class Initialized
INFO - 2024-09-21 03:13:02 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:02 --> Input Class Initialized
INFO - 2024-09-21 03:13:02 --> Language Class Initialized
ERROR - 2024-09-21 03:13:02 --> 404 Page Not Found: 2024targz/index
INFO - 2024-09-21 03:13:02 --> Config Class Initialized
INFO - 2024-09-21 03:13:02 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:02 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:02 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:02 --> URI Class Initialized
INFO - 2024-09-21 03:13:02 --> Router Class Initialized
INFO - 2024-09-21 03:13:02 --> Output Class Initialized
INFO - 2024-09-21 03:13:02 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:02 --> Input Class Initialized
INFO - 2024-09-21 03:13:02 --> Language Class Initialized
ERROR - 2024-09-21 03:13:02 --> 404 Page Not Found: 2016targz/index
INFO - 2024-09-21 03:13:03 --> Config Class Initialized
INFO - 2024-09-21 03:13:03 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:03 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:03 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:03 --> URI Class Initialized
INFO - 2024-09-21 03:13:03 --> Router Class Initialized
INFO - 2024-09-21 03:13:03 --> Output Class Initialized
INFO - 2024-09-21 03:13:03 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:03 --> Input Class Initialized
INFO - 2024-09-21 03:13:03 --> Language Class Initialized
ERROR - 2024-09-21 03:13:03 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 03:13:04 --> Config Class Initialized
INFO - 2024-09-21 03:13:04 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:04 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:04 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:04 --> URI Class Initialized
INFO - 2024-09-21 03:13:04 --> Router Class Initialized
INFO - 2024-09-21 03:13:04 --> Output Class Initialized
INFO - 2024-09-21 03:13:04 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:04 --> Input Class Initialized
INFO - 2024-09-21 03:13:04 --> Language Class Initialized
ERROR - 2024-09-21 03:13:04 --> 404 Page Not Found: Antroltargz/index
INFO - 2024-09-21 03:13:05 --> Config Class Initialized
INFO - 2024-09-21 03:13:05 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:05 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:05 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:05 --> URI Class Initialized
INFO - 2024-09-21 03:13:05 --> Router Class Initialized
INFO - 2024-09-21 03:13:05 --> Output Class Initialized
INFO - 2024-09-21 03:13:05 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:05 --> Input Class Initialized
INFO - 2024-09-21 03:13:05 --> Language Class Initialized
ERROR - 2024-09-21 03:13:05 --> 404 Page Not Found: 2023targz/index
INFO - 2024-09-21 03:13:06 --> Config Class Initialized
INFO - 2024-09-21 03:13:06 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:06 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:06 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:06 --> URI Class Initialized
INFO - 2024-09-21 03:13:06 --> Router Class Initialized
INFO - 2024-09-21 03:13:06 --> Output Class Initialized
INFO - 2024-09-21 03:13:06 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:06 --> Input Class Initialized
INFO - 2024-09-21 03:13:06 --> Language Class Initialized
ERROR - 2024-09-21 03:13:06 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comtargz/index
INFO - 2024-09-21 03:13:06 --> Config Class Initialized
INFO - 2024-09-21 03:13:06 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:06 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:06 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:06 --> URI Class Initialized
INFO - 2024-09-21 03:13:06 --> Router Class Initialized
INFO - 2024-09-21 03:13:06 --> Output Class Initialized
INFO - 2024-09-21 03:13:06 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:06 --> Input Class Initialized
INFO - 2024-09-21 03:13:06 --> Language Class Initialized
ERROR - 2024-09-21 03:13:06 --> 404 Page Not Found: 2021targz/index
INFO - 2024-09-21 03:13:07 --> Config Class Initialized
INFO - 2024-09-21 03:13:07 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:07 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:07 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:07 --> URI Class Initialized
INFO - 2024-09-21 03:13:07 --> Router Class Initialized
INFO - 2024-09-21 03:13:07 --> Output Class Initialized
INFO - 2024-09-21 03:13:07 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:07 --> Input Class Initialized
INFO - 2024-09-21 03:13:07 --> Language Class Initialized
ERROR - 2024-09-21 03:13:07 --> 404 Page Not Found: Public_htmltargz/index
INFO - 2024-09-21 03:13:08 --> Config Class Initialized
INFO - 2024-09-21 03:13:08 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:08 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:08 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:08 --> URI Class Initialized
INFO - 2024-09-21 03:13:08 --> Router Class Initialized
INFO - 2024-09-21 03:13:08 --> Output Class Initialized
INFO - 2024-09-21 03:13:08 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:08 --> Input Class Initialized
INFO - 2024-09-21 03:13:08 --> Language Class Initialized
ERROR - 2024-09-21 03:13:08 --> 404 Page Not Found: 2018targz/index
INFO - 2024-09-21 03:13:09 --> Config Class Initialized
INFO - 2024-09-21 03:13:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:09 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:09 --> URI Class Initialized
INFO - 2024-09-21 03:13:09 --> Router Class Initialized
INFO - 2024-09-21 03:13:09 --> Output Class Initialized
INFO - 2024-09-21 03:13:09 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:09 --> Input Class Initialized
INFO - 2024-09-21 03:13:09 --> Language Class Initialized
ERROR - 2024-09-21 03:13:09 --> 404 Page Not Found: Webtargz/index
INFO - 2024-09-21 03:13:10 --> Config Class Initialized
INFO - 2024-09-21 03:13:10 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:10 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:10 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:10 --> URI Class Initialized
INFO - 2024-09-21 03:13:10 --> Router Class Initialized
INFO - 2024-09-21 03:13:10 --> Output Class Initialized
INFO - 2024-09-21 03:13:10 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:10 --> Input Class Initialized
INFO - 2024-09-21 03:13:10 --> Language Class Initialized
ERROR - 2024-09-21 03:13:10 --> 404 Page Not Found: Backtargz/index
INFO - 2024-09-21 03:13:10 --> Config Class Initialized
INFO - 2024-09-21 03:13:10 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:10 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:10 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:10 --> URI Class Initialized
INFO - 2024-09-21 03:13:10 --> Router Class Initialized
INFO - 2024-09-21 03:13:10 --> Output Class Initialized
INFO - 2024-09-21 03:13:10 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:10 --> Input Class Initialized
INFO - 2024-09-21 03:13:10 --> Language Class Initialized
ERROR - 2024-09-21 03:13:10 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomtargz/index
INFO - 2024-09-21 03:13:11 --> Config Class Initialized
INFO - 2024-09-21 03:13:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:11 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:11 --> URI Class Initialized
INFO - 2024-09-21 03:13:11 --> Router Class Initialized
INFO - 2024-09-21 03:13:11 --> Output Class Initialized
INFO - 2024-09-21 03:13:11 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:11 --> Input Class Initialized
INFO - 2024-09-21 03:13:11 --> Language Class Initialized
ERROR - 2024-09-21 03:13:11 --> 404 Page Not Found: 2020targz/index
INFO - 2024-09-21 03:13:12 --> Config Class Initialized
INFO - 2024-09-21 03:13:12 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:12 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:12 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:12 --> URI Class Initialized
INFO - 2024-09-21 03:13:12 --> Router Class Initialized
INFO - 2024-09-21 03:13:12 --> Output Class Initialized
INFO - 2024-09-21 03:13:12 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:12 --> Input Class Initialized
INFO - 2024-09-21 03:13:12 --> Language Class Initialized
ERROR - 2024-09-21 03:13:12 --> 404 Page Not Found: Rsudhabdulazizmarabahantargz/index
INFO - 2024-09-21 03:13:13 --> Config Class Initialized
INFO - 2024-09-21 03:13:13 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:13 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:13 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:13 --> URI Class Initialized
INFO - 2024-09-21 03:13:13 --> Router Class Initialized
INFO - 2024-09-21 03:13:13 --> Output Class Initialized
INFO - 2024-09-21 03:13:13 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:13 --> Input Class Initialized
INFO - 2024-09-21 03:13:13 --> Language Class Initialized
ERROR - 2024-09-21 03:13:13 --> 404 Page Not Found: Sitetargz/index
INFO - 2024-09-21 03:13:14 --> Config Class Initialized
INFO - 2024-09-21 03:13:14 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:14 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:14 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:14 --> URI Class Initialized
INFO - 2024-09-21 03:13:14 --> Router Class Initialized
INFO - 2024-09-21 03:13:14 --> Output Class Initialized
INFO - 2024-09-21 03:13:14 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:14 --> Input Class Initialized
INFO - 2024-09-21 03:13:14 --> Language Class Initialized
ERROR - 2024-09-21 03:13:14 --> 404 Page Not Found: 2017gz/index
INFO - 2024-09-21 03:13:15 --> Config Class Initialized
INFO - 2024-09-21 03:13:15 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:15 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:15 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:15 --> URI Class Initialized
INFO - 2024-09-21 03:13:15 --> Router Class Initialized
INFO - 2024-09-21 03:13:15 --> Output Class Initialized
INFO - 2024-09-21 03:13:15 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:15 --> Input Class Initialized
INFO - 2024-09-21 03:13:15 --> Language Class Initialized
ERROR - 2024-09-21 03:13:15 --> 404 Page Not Found: 2022gz/index
INFO - 2024-09-21 03:13:15 --> Config Class Initialized
INFO - 2024-09-21 03:13:15 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:15 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:15 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:15 --> URI Class Initialized
INFO - 2024-09-21 03:13:15 --> Router Class Initialized
INFO - 2024-09-21 03:13:15 --> Output Class Initialized
INFO - 2024-09-21 03:13:15 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:15 --> Input Class Initialized
INFO - 2024-09-21 03:13:15 --> Language Class Initialized
ERROR - 2024-09-21 03:13:15 --> 404 Page Not Found: Agz/index
INFO - 2024-09-21 03:13:16 --> Config Class Initialized
INFO - 2024-09-21 03:13:16 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:16 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:16 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:16 --> URI Class Initialized
INFO - 2024-09-21 03:13:16 --> Router Class Initialized
INFO - 2024-09-21 03:13:16 --> Output Class Initialized
INFO - 2024-09-21 03:13:16 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:16 --> Input Class Initialized
INFO - 2024-09-21 03:13:16 --> Language Class Initialized
ERROR - 2024-09-21 03:13:16 --> 404 Page Not Found: Wwwgz/index
INFO - 2024-09-21 03:13:17 --> Config Class Initialized
INFO - 2024-09-21 03:13:17 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:17 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:17 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:17 --> URI Class Initialized
INFO - 2024-09-21 03:13:17 --> Router Class Initialized
INFO - 2024-09-21 03:13:17 --> Output Class Initialized
INFO - 2024-09-21 03:13:17 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:17 --> Input Class Initialized
INFO - 2024-09-21 03:13:17 --> Language Class Initialized
ERROR - 2024-09-21 03:13:17 --> 404 Page Not Found: Backupgz/index
INFO - 2024-09-21 03:13:18 --> Config Class Initialized
INFO - 2024-09-21 03:13:18 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:18 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:18 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:18 --> URI Class Initialized
INFO - 2024-09-21 03:13:18 --> Router Class Initialized
INFO - 2024-09-21 03:13:18 --> Output Class Initialized
INFO - 2024-09-21 03:13:18 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:18 --> Input Class Initialized
INFO - 2024-09-21 03:13:18 --> Language Class Initialized
ERROR - 2024-09-21 03:13:18 --> 404 Page Not Found: 2019gz/index
INFO - 2024-09-21 03:13:18 --> Config Class Initialized
INFO - 2024-09-21 03:13:18 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:18 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:18 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:18 --> URI Class Initialized
INFO - 2024-09-21 03:13:18 --> Router Class Initialized
INFO - 2024-09-21 03:13:18 --> Output Class Initialized
INFO - 2024-09-21 03:13:18 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:18 --> Input Class Initialized
INFO - 2024-09-21 03:13:18 --> Language Class Initialized
ERROR - 2024-09-21 03:13:18 --> 404 Page Not Found: Storegz/index
INFO - 2024-09-21 03:13:19 --> Config Class Initialized
INFO - 2024-09-21 03:13:19 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:19 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:19 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:19 --> URI Class Initialized
INFO - 2024-09-21 03:13:19 --> Router Class Initialized
INFO - 2024-09-21 03:13:19 --> Output Class Initialized
INFO - 2024-09-21 03:13:19 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:19 --> Input Class Initialized
INFO - 2024-09-21 03:13:19 --> Language Class Initialized
ERROR - 2024-09-21 03:13:19 --> 404 Page Not Found: Sitegz/index
INFO - 2024-09-21 03:13:20 --> Config Class Initialized
INFO - 2024-09-21 03:13:20 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:20 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:20 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:20 --> URI Class Initialized
INFO - 2024-09-21 03:13:20 --> Router Class Initialized
INFO - 2024-09-21 03:13:20 --> Output Class Initialized
INFO - 2024-09-21 03:13:20 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:20 --> Input Class Initialized
INFO - 2024-09-21 03:13:20 --> Language Class Initialized
ERROR - 2024-09-21 03:13:20 --> 404 Page Not Found: 1gz/index
INFO - 2024-09-21 03:13:20 --> Config Class Initialized
INFO - 2024-09-21 03:13:20 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:20 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:20 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:20 --> URI Class Initialized
INFO - 2024-09-21 03:13:20 --> Router Class Initialized
INFO - 2024-09-21 03:13:20 --> Output Class Initialized
INFO - 2024-09-21 03:13:20 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:20 --> Input Class Initialized
INFO - 2024-09-21 03:13:20 --> Language Class Initialized
ERROR - 2024-09-21 03:13:20 --> 404 Page Not Found: 2024gz/index
INFO - 2024-09-21 03:13:21 --> Config Class Initialized
INFO - 2024-09-21 03:13:21 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:21 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:21 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:21 --> URI Class Initialized
INFO - 2024-09-21 03:13:21 --> Router Class Initialized
INFO - 2024-09-21 03:13:21 --> Output Class Initialized
INFO - 2024-09-21 03:13:21 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:21 --> Input Class Initialized
INFO - 2024-09-21 03:13:21 --> Language Class Initialized
ERROR - 2024-09-21 03:13:21 --> 404 Page Not Found: 2016gz/index
INFO - 2024-09-21 03:13:22 --> Config Class Initialized
INFO - 2024-09-21 03:13:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:22 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:22 --> URI Class Initialized
INFO - 2024-09-21 03:13:22 --> Router Class Initialized
INFO - 2024-09-21 03:13:22 --> Output Class Initialized
INFO - 2024-09-21 03:13:22 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:22 --> Input Class Initialized
INFO - 2024-09-21 03:13:22 --> Language Class Initialized
ERROR - 2024-09-21 03:13:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 03:13:22 --> Config Class Initialized
INFO - 2024-09-21 03:13:22 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:22 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:22 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:22 --> URI Class Initialized
INFO - 2024-09-21 03:13:22 --> Router Class Initialized
INFO - 2024-09-21 03:13:22 --> Output Class Initialized
INFO - 2024-09-21 03:13:22 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:22 --> Input Class Initialized
INFO - 2024-09-21 03:13:22 --> Language Class Initialized
ERROR - 2024-09-21 03:13:22 --> 404 Page Not Found: Antrolgz/index
INFO - 2024-09-21 03:13:23 --> Config Class Initialized
INFO - 2024-09-21 03:13:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:23 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:23 --> URI Class Initialized
INFO - 2024-09-21 03:13:23 --> Router Class Initialized
INFO - 2024-09-21 03:13:23 --> Output Class Initialized
INFO - 2024-09-21 03:13:23 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:23 --> Input Class Initialized
INFO - 2024-09-21 03:13:23 --> Language Class Initialized
ERROR - 2024-09-21 03:13:23 --> 404 Page Not Found: 2023gz/index
INFO - 2024-09-21 03:13:23 --> Config Class Initialized
INFO - 2024-09-21 03:13:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:23 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:23 --> URI Class Initialized
INFO - 2024-09-21 03:13:23 --> Router Class Initialized
INFO - 2024-09-21 03:13:23 --> Output Class Initialized
INFO - 2024-09-21 03:13:23 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:23 --> Input Class Initialized
INFO - 2024-09-21 03:13:23 --> Language Class Initialized
ERROR - 2024-09-21 03:13:23 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_comgz/index
INFO - 2024-09-21 03:13:24 --> Config Class Initialized
INFO - 2024-09-21 03:13:24 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:24 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:24 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:24 --> URI Class Initialized
INFO - 2024-09-21 03:13:24 --> Router Class Initialized
INFO - 2024-09-21 03:13:24 --> Output Class Initialized
INFO - 2024-09-21 03:13:24 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:24 --> Input Class Initialized
INFO - 2024-09-21 03:13:24 --> Language Class Initialized
ERROR - 2024-09-21 03:13:24 --> 404 Page Not Found: 2021gz/index
INFO - 2024-09-21 03:13:25 --> Config Class Initialized
INFO - 2024-09-21 03:13:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:25 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:25 --> URI Class Initialized
INFO - 2024-09-21 03:13:25 --> Router Class Initialized
INFO - 2024-09-21 03:13:25 --> Output Class Initialized
INFO - 2024-09-21 03:13:25 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:25 --> Input Class Initialized
INFO - 2024-09-21 03:13:25 --> Language Class Initialized
ERROR - 2024-09-21 03:13:25 --> 404 Page Not Found: Public_htmlgz/index
INFO - 2024-09-21 03:13:25 --> Config Class Initialized
INFO - 2024-09-21 03:13:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:25 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:25 --> URI Class Initialized
INFO - 2024-09-21 03:13:25 --> Router Class Initialized
INFO - 2024-09-21 03:13:25 --> Output Class Initialized
INFO - 2024-09-21 03:13:25 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:25 --> Input Class Initialized
INFO - 2024-09-21 03:13:25 --> Language Class Initialized
ERROR - 2024-09-21 03:13:25 --> 404 Page Not Found: 2018gz/index
INFO - 2024-09-21 03:13:25 --> Config Class Initialized
INFO - 2024-09-21 03:13:25 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:25 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:25 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:25 --> URI Class Initialized
INFO - 2024-09-21 03:13:25 --> Router Class Initialized
INFO - 2024-09-21 03:13:25 --> Output Class Initialized
INFO - 2024-09-21 03:13:25 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:25 --> Input Class Initialized
INFO - 2024-09-21 03:13:25 --> Language Class Initialized
ERROR - 2024-09-21 03:13:25 --> 404 Page Not Found: Webgz/index
INFO - 2024-09-21 03:13:26 --> Config Class Initialized
INFO - 2024-09-21 03:13:26 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:26 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:26 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:26 --> URI Class Initialized
INFO - 2024-09-21 03:13:26 --> Router Class Initialized
INFO - 2024-09-21 03:13:26 --> Output Class Initialized
INFO - 2024-09-21 03:13:26 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:26 --> Input Class Initialized
INFO - 2024-09-21 03:13:26 --> Language Class Initialized
ERROR - 2024-09-21 03:13:26 --> 404 Page Not Found: Backgz/index
INFO - 2024-09-21 03:13:27 --> Config Class Initialized
INFO - 2024-09-21 03:13:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:27 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:27 --> URI Class Initialized
INFO - 2024-09-21 03:13:27 --> Router Class Initialized
INFO - 2024-09-21 03:13:27 --> Output Class Initialized
INFO - 2024-09-21 03:13:27 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:27 --> Input Class Initialized
INFO - 2024-09-21 03:13:27 --> Language Class Initialized
ERROR - 2024-09-21 03:13:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancomgz/index
INFO - 2024-09-21 03:13:27 --> Config Class Initialized
INFO - 2024-09-21 03:13:27 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:27 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:27 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:27 --> URI Class Initialized
INFO - 2024-09-21 03:13:27 --> Router Class Initialized
INFO - 2024-09-21 03:13:27 --> Output Class Initialized
INFO - 2024-09-21 03:13:27 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:27 --> Input Class Initialized
INFO - 2024-09-21 03:13:27 --> Language Class Initialized
ERROR - 2024-09-21 03:13:27 --> 404 Page Not Found: 2020gz/index
INFO - 2024-09-21 03:13:28 --> Config Class Initialized
INFO - 2024-09-21 03:13:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:28 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:28 --> URI Class Initialized
INFO - 2024-09-21 03:13:28 --> Router Class Initialized
INFO - 2024-09-21 03:13:28 --> Output Class Initialized
INFO - 2024-09-21 03:13:28 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:28 --> Input Class Initialized
INFO - 2024-09-21 03:13:28 --> Language Class Initialized
ERROR - 2024-09-21 03:13:28 --> 404 Page Not Found: Rsudhabdulazizmarabahangz/index
INFO - 2024-09-21 03:13:28 --> Config Class Initialized
INFO - 2024-09-21 03:13:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:28 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:28 --> URI Class Initialized
INFO - 2024-09-21 03:13:28 --> Router Class Initialized
INFO - 2024-09-21 03:13:28 --> Output Class Initialized
INFO - 2024-09-21 03:13:28 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:28 --> Input Class Initialized
INFO - 2024-09-21 03:13:28 --> Language Class Initialized
ERROR - 2024-09-21 03:13:28 --> 404 Page Not Found: Sitegz/index
INFO - 2024-09-21 03:13:29 --> Config Class Initialized
INFO - 2024-09-21 03:13:29 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:29 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:29 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:29 --> URI Class Initialized
INFO - 2024-09-21 03:13:29 --> Router Class Initialized
INFO - 2024-09-21 03:13:29 --> Output Class Initialized
INFO - 2024-09-21 03:13:29 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:29 --> Input Class Initialized
INFO - 2024-09-21 03:13:29 --> Language Class Initialized
ERROR - 2024-09-21 03:13:29 --> 404 Page Not Found: 20177z/index
INFO - 2024-09-21 03:13:29 --> Config Class Initialized
INFO - 2024-09-21 03:13:29 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:29 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:29 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:29 --> URI Class Initialized
INFO - 2024-09-21 03:13:29 --> Router Class Initialized
INFO - 2024-09-21 03:13:29 --> Output Class Initialized
INFO - 2024-09-21 03:13:29 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:29 --> Input Class Initialized
INFO - 2024-09-21 03:13:29 --> Language Class Initialized
ERROR - 2024-09-21 03:13:29 --> 404 Page Not Found: 20227z/index
INFO - 2024-09-21 03:13:30 --> Config Class Initialized
INFO - 2024-09-21 03:13:30 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:30 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:30 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:30 --> URI Class Initialized
INFO - 2024-09-21 03:13:30 --> Router Class Initialized
INFO - 2024-09-21 03:13:30 --> Output Class Initialized
INFO - 2024-09-21 03:13:30 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:30 --> Input Class Initialized
INFO - 2024-09-21 03:13:30 --> Language Class Initialized
ERROR - 2024-09-21 03:13:30 --> 404 Page Not Found: A7z/index
INFO - 2024-09-21 03:13:31 --> Config Class Initialized
INFO - 2024-09-21 03:13:31 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:31 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:31 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:31 --> URI Class Initialized
INFO - 2024-09-21 03:13:31 --> Router Class Initialized
INFO - 2024-09-21 03:13:31 --> Output Class Initialized
INFO - 2024-09-21 03:13:31 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:31 --> Input Class Initialized
INFO - 2024-09-21 03:13:31 --> Language Class Initialized
ERROR - 2024-09-21 03:13:31 --> 404 Page Not Found: Www7z/index
INFO - 2024-09-21 03:13:31 --> Config Class Initialized
INFO - 2024-09-21 03:13:31 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:31 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:31 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:31 --> URI Class Initialized
INFO - 2024-09-21 03:13:31 --> Router Class Initialized
INFO - 2024-09-21 03:13:31 --> Output Class Initialized
INFO - 2024-09-21 03:13:31 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:31 --> Input Class Initialized
INFO - 2024-09-21 03:13:31 --> Language Class Initialized
ERROR - 2024-09-21 03:13:31 --> 404 Page Not Found: Backup7z/index
INFO - 2024-09-21 03:13:32 --> Config Class Initialized
INFO - 2024-09-21 03:13:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:32 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:32 --> URI Class Initialized
INFO - 2024-09-21 03:13:32 --> Router Class Initialized
INFO - 2024-09-21 03:13:32 --> Output Class Initialized
INFO - 2024-09-21 03:13:32 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:32 --> Input Class Initialized
INFO - 2024-09-21 03:13:32 --> Language Class Initialized
ERROR - 2024-09-21 03:13:32 --> 404 Page Not Found: 20197z/index
INFO - 2024-09-21 03:13:32 --> Config Class Initialized
INFO - 2024-09-21 03:13:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:32 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:32 --> URI Class Initialized
INFO - 2024-09-21 03:13:32 --> Router Class Initialized
INFO - 2024-09-21 03:13:32 --> Output Class Initialized
INFO - 2024-09-21 03:13:32 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:32 --> Input Class Initialized
INFO - 2024-09-21 03:13:32 --> Language Class Initialized
ERROR - 2024-09-21 03:13:32 --> 404 Page Not Found: Store7z/index
INFO - 2024-09-21 03:13:33 --> Config Class Initialized
INFO - 2024-09-21 03:13:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:33 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:33 --> URI Class Initialized
INFO - 2024-09-21 03:13:33 --> Router Class Initialized
INFO - 2024-09-21 03:13:33 --> Output Class Initialized
INFO - 2024-09-21 03:13:33 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:33 --> Input Class Initialized
INFO - 2024-09-21 03:13:33 --> Language Class Initialized
ERROR - 2024-09-21 03:13:33 --> 404 Page Not Found: Site7z/index
INFO - 2024-09-21 03:13:33 --> Config Class Initialized
INFO - 2024-09-21 03:13:33 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:33 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:33 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:33 --> URI Class Initialized
INFO - 2024-09-21 03:13:33 --> Router Class Initialized
INFO - 2024-09-21 03:13:33 --> Output Class Initialized
INFO - 2024-09-21 03:13:33 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:33 --> Input Class Initialized
INFO - 2024-09-21 03:13:33 --> Language Class Initialized
ERROR - 2024-09-21 03:13:33 --> 404 Page Not Found: 17z/index
INFO - 2024-09-21 03:13:34 --> Config Class Initialized
INFO - 2024-09-21 03:13:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:34 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:34 --> URI Class Initialized
INFO - 2024-09-21 03:13:34 --> Router Class Initialized
INFO - 2024-09-21 03:13:34 --> Output Class Initialized
INFO - 2024-09-21 03:13:34 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:34 --> Input Class Initialized
INFO - 2024-09-21 03:13:34 --> Language Class Initialized
ERROR - 2024-09-21 03:13:34 --> 404 Page Not Found: 20247z/index
INFO - 2024-09-21 03:13:34 --> Config Class Initialized
INFO - 2024-09-21 03:13:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:34 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:34 --> URI Class Initialized
INFO - 2024-09-21 03:13:34 --> Router Class Initialized
INFO - 2024-09-21 03:13:34 --> Output Class Initialized
INFO - 2024-09-21 03:13:34 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:34 --> Input Class Initialized
INFO - 2024-09-21 03:13:34 --> Language Class Initialized
ERROR - 2024-09-21 03:13:34 --> 404 Page Not Found: 20167z/index
INFO - 2024-09-21 03:13:34 --> Config Class Initialized
INFO - 2024-09-21 03:13:34 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:34 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:34 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:34 --> URI Class Initialized
INFO - 2024-09-21 03:13:34 --> Router Class Initialized
INFO - 2024-09-21 03:13:34 --> Output Class Initialized
INFO - 2024-09-21 03:13:34 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:34 --> Input Class Initialized
INFO - 2024-09-21 03:13:34 --> Language Class Initialized
ERROR - 2024-09-21 03:13:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 03:13:35 --> Config Class Initialized
INFO - 2024-09-21 03:13:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:35 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:35 --> URI Class Initialized
INFO - 2024-09-21 03:13:35 --> Router Class Initialized
INFO - 2024-09-21 03:13:35 --> Output Class Initialized
INFO - 2024-09-21 03:13:35 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:35 --> Input Class Initialized
INFO - 2024-09-21 03:13:35 --> Language Class Initialized
ERROR - 2024-09-21 03:13:35 --> 404 Page Not Found: Antrol7z/index
INFO - 2024-09-21 03:13:35 --> Config Class Initialized
INFO - 2024-09-21 03:13:35 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:35 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:35 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:35 --> URI Class Initialized
INFO - 2024-09-21 03:13:35 --> Router Class Initialized
INFO - 2024-09-21 03:13:35 --> Output Class Initialized
INFO - 2024-09-21 03:13:35 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:35 --> Input Class Initialized
INFO - 2024-09-21 03:13:35 --> Language Class Initialized
ERROR - 2024-09-21 03:13:35 --> 404 Page Not Found: 20237z/index
INFO - 2024-09-21 03:13:36 --> Config Class Initialized
INFO - 2024-09-21 03:13:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:36 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:36 --> URI Class Initialized
INFO - 2024-09-21 03:13:36 --> Router Class Initialized
INFO - 2024-09-21 03:13:36 --> Output Class Initialized
INFO - 2024-09-21 03:13:36 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:36 --> Input Class Initialized
INFO - 2024-09-21 03:13:36 --> Language Class Initialized
ERROR - 2024-09-21 03:13:36 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_com7z/index
INFO - 2024-09-21 03:13:36 --> Config Class Initialized
INFO - 2024-09-21 03:13:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:36 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:36 --> URI Class Initialized
INFO - 2024-09-21 03:13:36 --> Router Class Initialized
INFO - 2024-09-21 03:13:36 --> Output Class Initialized
INFO - 2024-09-21 03:13:36 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:36 --> Input Class Initialized
INFO - 2024-09-21 03:13:36 --> Language Class Initialized
ERROR - 2024-09-21 03:13:36 --> 404 Page Not Found: 20217z/index
INFO - 2024-09-21 03:13:36 --> Config Class Initialized
INFO - 2024-09-21 03:13:36 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:36 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:36 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:36 --> URI Class Initialized
INFO - 2024-09-21 03:13:36 --> Router Class Initialized
INFO - 2024-09-21 03:13:36 --> Output Class Initialized
INFO - 2024-09-21 03:13:36 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:36 --> Input Class Initialized
INFO - 2024-09-21 03:13:36 --> Language Class Initialized
ERROR - 2024-09-21 03:13:36 --> 404 Page Not Found: Public_html7z/index
INFO - 2024-09-21 03:13:37 --> Config Class Initialized
INFO - 2024-09-21 03:13:37 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:37 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:37 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:37 --> URI Class Initialized
INFO - 2024-09-21 03:13:37 --> Router Class Initialized
INFO - 2024-09-21 03:13:37 --> Output Class Initialized
INFO - 2024-09-21 03:13:37 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:37 --> Input Class Initialized
INFO - 2024-09-21 03:13:37 --> Language Class Initialized
ERROR - 2024-09-21 03:13:37 --> 404 Page Not Found: 20187z/index
INFO - 2024-09-21 03:13:37 --> Config Class Initialized
INFO - 2024-09-21 03:13:37 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:37 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:37 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:37 --> URI Class Initialized
INFO - 2024-09-21 03:13:37 --> Router Class Initialized
INFO - 2024-09-21 03:13:37 --> Output Class Initialized
INFO - 2024-09-21 03:13:37 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:37 --> Input Class Initialized
INFO - 2024-09-21 03:13:37 --> Language Class Initialized
ERROR - 2024-09-21 03:13:37 --> 404 Page Not Found: Web7z/index
INFO - 2024-09-21 03:13:38 --> Config Class Initialized
INFO - 2024-09-21 03:13:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:38 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:38 --> URI Class Initialized
INFO - 2024-09-21 03:13:38 --> Router Class Initialized
INFO - 2024-09-21 03:13:38 --> Output Class Initialized
INFO - 2024-09-21 03:13:38 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:38 --> Input Class Initialized
INFO - 2024-09-21 03:13:38 --> Language Class Initialized
ERROR - 2024-09-21 03:13:38 --> 404 Page Not Found: Back7z/index
INFO - 2024-09-21 03:13:38 --> Config Class Initialized
INFO - 2024-09-21 03:13:38 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:38 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:38 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:38 --> URI Class Initialized
INFO - 2024-09-21 03:13:38 --> Router Class Initialized
INFO - 2024-09-21 03:13:38 --> Output Class Initialized
INFO - 2024-09-21 03:13:38 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:38 --> Input Class Initialized
INFO - 2024-09-21 03:13:38 --> Language Class Initialized
ERROR - 2024-09-21 03:13:38 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom7z/index
INFO - 2024-09-21 03:13:39 --> Config Class Initialized
INFO - 2024-09-21 03:13:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:39 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:39 --> URI Class Initialized
INFO - 2024-09-21 03:13:39 --> Router Class Initialized
INFO - 2024-09-21 03:13:39 --> Output Class Initialized
INFO - 2024-09-21 03:13:39 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:39 --> Input Class Initialized
INFO - 2024-09-21 03:13:39 --> Language Class Initialized
ERROR - 2024-09-21 03:13:39 --> 404 Page Not Found: 20207z/index
INFO - 2024-09-21 03:13:39 --> Config Class Initialized
INFO - 2024-09-21 03:13:39 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:39 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:39 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:39 --> URI Class Initialized
INFO - 2024-09-21 03:13:39 --> Router Class Initialized
INFO - 2024-09-21 03:13:39 --> Output Class Initialized
INFO - 2024-09-21 03:13:39 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:39 --> Input Class Initialized
INFO - 2024-09-21 03:13:39 --> Language Class Initialized
ERROR - 2024-09-21 03:13:39 --> 404 Page Not Found: Rsudhabdulazizmarabahan7z/index
INFO - 2024-09-21 03:13:40 --> Config Class Initialized
INFO - 2024-09-21 03:13:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:40 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:40 --> URI Class Initialized
INFO - 2024-09-21 03:13:40 --> Router Class Initialized
INFO - 2024-09-21 03:13:40 --> Output Class Initialized
INFO - 2024-09-21 03:13:40 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:40 --> Input Class Initialized
INFO - 2024-09-21 03:13:40 --> Language Class Initialized
ERROR - 2024-09-21 03:13:40 --> 404 Page Not Found: Site7z/index
INFO - 2024-09-21 03:13:40 --> Config Class Initialized
INFO - 2024-09-21 03:13:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:40 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:40 --> URI Class Initialized
INFO - 2024-09-21 03:13:40 --> Router Class Initialized
INFO - 2024-09-21 03:13:40 --> Output Class Initialized
INFO - 2024-09-21 03:13:40 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:40 --> Input Class Initialized
INFO - 2024-09-21 03:13:40 --> Language Class Initialized
ERROR - 2024-09-21 03:13:40 --> 404 Page Not Found: 2017backup/index
INFO - 2024-09-21 03:13:40 --> Config Class Initialized
INFO - 2024-09-21 03:13:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:40 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:40 --> URI Class Initialized
INFO - 2024-09-21 03:13:40 --> Router Class Initialized
INFO - 2024-09-21 03:13:40 --> Output Class Initialized
INFO - 2024-09-21 03:13:40 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:40 --> Input Class Initialized
INFO - 2024-09-21 03:13:40 --> Language Class Initialized
ERROR - 2024-09-21 03:13:40 --> 404 Page Not Found: 2022backup/index
INFO - 2024-09-21 03:13:41 --> Config Class Initialized
INFO - 2024-09-21 03:13:41 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:41 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:41 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:41 --> URI Class Initialized
INFO - 2024-09-21 03:13:41 --> Router Class Initialized
INFO - 2024-09-21 03:13:41 --> Output Class Initialized
INFO - 2024-09-21 03:13:41 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:41 --> Input Class Initialized
INFO - 2024-09-21 03:13:41 --> Language Class Initialized
ERROR - 2024-09-21 03:13:41 --> 404 Page Not Found: Abackup/index
INFO - 2024-09-21 03:13:42 --> Config Class Initialized
INFO - 2024-09-21 03:13:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:42 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:42 --> URI Class Initialized
INFO - 2024-09-21 03:13:42 --> Router Class Initialized
INFO - 2024-09-21 03:13:42 --> Output Class Initialized
INFO - 2024-09-21 03:13:42 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:42 --> Input Class Initialized
INFO - 2024-09-21 03:13:42 --> Language Class Initialized
ERROR - 2024-09-21 03:13:42 --> 404 Page Not Found: Wwwbackup/index
INFO - 2024-09-21 03:13:43 --> Config Class Initialized
INFO - 2024-09-21 03:13:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:43 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:43 --> URI Class Initialized
INFO - 2024-09-21 03:13:43 --> Router Class Initialized
INFO - 2024-09-21 03:13:43 --> Output Class Initialized
INFO - 2024-09-21 03:13:43 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:43 --> Input Class Initialized
INFO - 2024-09-21 03:13:43 --> Language Class Initialized
ERROR - 2024-09-21 03:13:43 --> 404 Page Not Found: Backupbackup/index
INFO - 2024-09-21 03:13:43 --> Config Class Initialized
INFO - 2024-09-21 03:13:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:43 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:43 --> URI Class Initialized
INFO - 2024-09-21 03:13:43 --> Router Class Initialized
INFO - 2024-09-21 03:13:43 --> Output Class Initialized
INFO - 2024-09-21 03:13:43 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:43 --> Input Class Initialized
INFO - 2024-09-21 03:13:43 --> Language Class Initialized
ERROR - 2024-09-21 03:13:43 --> 404 Page Not Found: 2019backup/index
INFO - 2024-09-21 03:13:44 --> Config Class Initialized
INFO - 2024-09-21 03:13:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:44 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:44 --> URI Class Initialized
INFO - 2024-09-21 03:13:44 --> Router Class Initialized
INFO - 2024-09-21 03:13:44 --> Output Class Initialized
INFO - 2024-09-21 03:13:44 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:44 --> Input Class Initialized
INFO - 2024-09-21 03:13:44 --> Language Class Initialized
ERROR - 2024-09-21 03:13:44 --> 404 Page Not Found: Storebackup/index
INFO - 2024-09-21 03:13:45 --> Config Class Initialized
INFO - 2024-09-21 03:13:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:45 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:45 --> URI Class Initialized
INFO - 2024-09-21 03:13:45 --> Router Class Initialized
INFO - 2024-09-21 03:13:45 --> Output Class Initialized
INFO - 2024-09-21 03:13:45 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:45 --> Input Class Initialized
INFO - 2024-09-21 03:13:45 --> Language Class Initialized
ERROR - 2024-09-21 03:13:45 --> 404 Page Not Found: Sitebackup/index
INFO - 2024-09-21 03:13:45 --> Config Class Initialized
INFO - 2024-09-21 03:13:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:45 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:45 --> URI Class Initialized
INFO - 2024-09-21 03:13:45 --> Router Class Initialized
INFO - 2024-09-21 03:13:45 --> Output Class Initialized
INFO - 2024-09-21 03:13:45 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:45 --> Input Class Initialized
INFO - 2024-09-21 03:13:45 --> Language Class Initialized
ERROR - 2024-09-21 03:13:45 --> 404 Page Not Found: 1backup/index
INFO - 2024-09-21 03:13:46 --> Config Class Initialized
INFO - 2024-09-21 03:13:46 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:46 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:46 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:46 --> URI Class Initialized
INFO - 2024-09-21 03:13:46 --> Router Class Initialized
INFO - 2024-09-21 03:13:46 --> Output Class Initialized
INFO - 2024-09-21 03:13:46 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:46 --> Input Class Initialized
INFO - 2024-09-21 03:13:46 --> Language Class Initialized
ERROR - 2024-09-21 03:13:46 --> 404 Page Not Found: 2024backup/index
INFO - 2024-09-21 03:13:47 --> Config Class Initialized
INFO - 2024-09-21 03:13:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:47 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:47 --> URI Class Initialized
INFO - 2024-09-21 03:13:47 --> Router Class Initialized
INFO - 2024-09-21 03:13:47 --> Output Class Initialized
INFO - 2024-09-21 03:13:47 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:47 --> Input Class Initialized
INFO - 2024-09-21 03:13:47 --> Language Class Initialized
ERROR - 2024-09-21 03:13:47 --> 404 Page Not Found: 2016backup/index
INFO - 2024-09-21 03:13:47 --> Config Class Initialized
INFO - 2024-09-21 03:13:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:47 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:47 --> URI Class Initialized
INFO - 2024-09-21 03:13:47 --> Router Class Initialized
INFO - 2024-09-21 03:13:47 --> Output Class Initialized
INFO - 2024-09-21 03:13:47 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:47 --> Input Class Initialized
INFO - 2024-09-21 03:13:47 --> Language Class Initialized
ERROR - 2024-09-21 03:13:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 03:13:48 --> Config Class Initialized
INFO - 2024-09-21 03:13:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:48 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:48 --> URI Class Initialized
INFO - 2024-09-21 03:13:48 --> Router Class Initialized
INFO - 2024-09-21 03:13:48 --> Output Class Initialized
INFO - 2024-09-21 03:13:48 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:48 --> Input Class Initialized
INFO - 2024-09-21 03:13:48 --> Language Class Initialized
ERROR - 2024-09-21 03:13:48 --> 404 Page Not Found: Antrolbackup/index
INFO - 2024-09-21 03:13:49 --> Config Class Initialized
INFO - 2024-09-21 03:13:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:49 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:49 --> URI Class Initialized
INFO - 2024-09-21 03:13:49 --> Router Class Initialized
INFO - 2024-09-21 03:13:49 --> Output Class Initialized
INFO - 2024-09-21 03:13:49 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:49 --> Input Class Initialized
INFO - 2024-09-21 03:13:49 --> Language Class Initialized
ERROR - 2024-09-21 03:13:49 --> 404 Page Not Found: 2023backup/index
INFO - 2024-09-21 03:13:49 --> Config Class Initialized
INFO - 2024-09-21 03:13:49 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:49 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:49 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:49 --> URI Class Initialized
INFO - 2024-09-21 03:13:49 --> Router Class Initialized
INFO - 2024-09-21 03:13:49 --> Output Class Initialized
INFO - 2024-09-21 03:13:49 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:49 --> Input Class Initialized
INFO - 2024-09-21 03:13:49 --> Language Class Initialized
ERROR - 2024-09-21 03:13:49 --> 404 Page Not Found: Antrol_rsudhabdulazizmarabahan_combackup/index
INFO - 2024-09-21 03:13:50 --> Config Class Initialized
INFO - 2024-09-21 03:13:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:50 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:50 --> URI Class Initialized
INFO - 2024-09-21 03:13:50 --> Router Class Initialized
INFO - 2024-09-21 03:13:50 --> Output Class Initialized
INFO - 2024-09-21 03:13:50 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:50 --> Input Class Initialized
INFO - 2024-09-21 03:13:50 --> Language Class Initialized
ERROR - 2024-09-21 03:13:50 --> 404 Page Not Found: 2021backup/index
INFO - 2024-09-21 03:13:50 --> Config Class Initialized
INFO - 2024-09-21 03:13:50 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:50 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:50 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:50 --> URI Class Initialized
INFO - 2024-09-21 03:13:50 --> Router Class Initialized
INFO - 2024-09-21 03:13:50 --> Output Class Initialized
INFO - 2024-09-21 03:13:50 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:50 --> Input Class Initialized
INFO - 2024-09-21 03:13:50 --> Language Class Initialized
ERROR - 2024-09-21 03:13:50 --> 404 Page Not Found: Public_htmlbackup/index
INFO - 2024-09-21 03:13:51 --> Config Class Initialized
INFO - 2024-09-21 03:13:51 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:51 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:51 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:51 --> URI Class Initialized
INFO - 2024-09-21 03:13:51 --> Router Class Initialized
INFO - 2024-09-21 03:13:51 --> Output Class Initialized
INFO - 2024-09-21 03:13:51 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:51 --> Input Class Initialized
INFO - 2024-09-21 03:13:51 --> Language Class Initialized
ERROR - 2024-09-21 03:13:51 --> 404 Page Not Found: 2018backup/index
INFO - 2024-09-21 03:13:52 --> Config Class Initialized
INFO - 2024-09-21 03:13:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:52 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:52 --> URI Class Initialized
INFO - 2024-09-21 03:13:52 --> Router Class Initialized
INFO - 2024-09-21 03:13:52 --> Output Class Initialized
INFO - 2024-09-21 03:13:52 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:52 --> Input Class Initialized
INFO - 2024-09-21 03:13:52 --> Language Class Initialized
ERROR - 2024-09-21 03:13:52 --> 404 Page Not Found: Webbackup/index
INFO - 2024-09-21 03:13:52 --> Config Class Initialized
INFO - 2024-09-21 03:13:52 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:52 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:52 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:52 --> URI Class Initialized
INFO - 2024-09-21 03:13:52 --> Router Class Initialized
INFO - 2024-09-21 03:13:52 --> Output Class Initialized
INFO - 2024-09-21 03:13:52 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:52 --> Input Class Initialized
INFO - 2024-09-21 03:13:52 --> Language Class Initialized
ERROR - 2024-09-21 03:13:52 --> 404 Page Not Found: Backbackup/index
INFO - 2024-09-21 03:13:53 --> Config Class Initialized
INFO - 2024-09-21 03:13:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:53 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:53 --> URI Class Initialized
INFO - 2024-09-21 03:13:53 --> Router Class Initialized
INFO - 2024-09-21 03:13:53 --> Output Class Initialized
INFO - 2024-09-21 03:13:53 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:53 --> Input Class Initialized
INFO - 2024-09-21 03:13:53 --> Language Class Initialized
ERROR - 2024-09-21 03:13:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancombackup/index
INFO - 2024-09-21 03:13:53 --> Config Class Initialized
INFO - 2024-09-21 03:13:53 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:53 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:53 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:53 --> URI Class Initialized
INFO - 2024-09-21 03:13:53 --> Router Class Initialized
INFO - 2024-09-21 03:13:53 --> Output Class Initialized
INFO - 2024-09-21 03:13:53 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:53 --> Input Class Initialized
INFO - 2024-09-21 03:13:53 --> Language Class Initialized
ERROR - 2024-09-21 03:13:53 --> 404 Page Not Found: 2020backup/index
INFO - 2024-09-21 03:13:54 --> Config Class Initialized
INFO - 2024-09-21 03:13:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:54 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:54 --> URI Class Initialized
INFO - 2024-09-21 03:13:54 --> Router Class Initialized
INFO - 2024-09-21 03:13:54 --> Output Class Initialized
INFO - 2024-09-21 03:13:54 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:54 --> Input Class Initialized
INFO - 2024-09-21 03:13:54 --> Language Class Initialized
ERROR - 2024-09-21 03:13:54 --> 404 Page Not Found: Rsudhabdulazizmarabahanbackup/index
INFO - 2024-09-21 03:13:54 --> Config Class Initialized
INFO - 2024-09-21 03:13:54 --> Hooks Class Initialized
DEBUG - 2024-09-21 03:13:54 --> UTF-8 Support Enabled
INFO - 2024-09-21 03:13:54 --> Utf8 Class Initialized
INFO - 2024-09-21 03:13:54 --> URI Class Initialized
INFO - 2024-09-21 03:13:54 --> Router Class Initialized
INFO - 2024-09-21 03:13:54 --> Output Class Initialized
INFO - 2024-09-21 03:13:54 --> Security Class Initialized
DEBUG - 2024-09-21 03:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 03:13:54 --> Input Class Initialized
INFO - 2024-09-21 03:13:54 --> Language Class Initialized
ERROR - 2024-09-21 03:13:54 --> 404 Page Not Found: Sitebackup/index
INFO - 2024-09-21 15:07:10 --> Config Class Initialized
INFO - 2024-09-21 15:07:10 --> Hooks Class Initialized
DEBUG - 2024-09-21 15:07:10 --> UTF-8 Support Enabled
INFO - 2024-09-21 15:07:10 --> Utf8 Class Initialized
INFO - 2024-09-21 15:07:10 --> URI Class Initialized
DEBUG - 2024-09-21 15:07:10 --> No URI present. Default controller set.
INFO - 2024-09-21 15:07:10 --> Router Class Initialized
INFO - 2024-09-21 15:07:10 --> Output Class Initialized
INFO - 2024-09-21 15:07:10 --> Security Class Initialized
DEBUG - 2024-09-21 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 15:07:10 --> Input Class Initialized
INFO - 2024-09-21 15:07:10 --> Language Class Initialized
INFO - 2024-09-21 15:07:10 --> Loader Class Initialized
INFO - 2024-09-21 15:07:10 --> Helper loaded: url_helper
INFO - 2024-09-21 15:07:10 --> Helper loaded: file_helper
INFO - 2024-09-21 15:07:10 --> Helper loaded: security_helper
INFO - 2024-09-21 15:07:10 --> Helper loaded: wpu_helper
INFO - 2024-09-21 15:07:10 --> Database Driver Class Initialized
ERROR - 2024-09-21 15:07:10 --> Unable to connect to the database
INFO - 2024-09-21 15:07:10 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 15:07:11 --> Config Class Initialized
INFO - 2024-09-21 15:07:11 --> Hooks Class Initialized
DEBUG - 2024-09-21 15:07:11 --> UTF-8 Support Enabled
INFO - 2024-09-21 15:07:11 --> Utf8 Class Initialized
INFO - 2024-09-21 15:07:11 --> URI Class Initialized
DEBUG - 2024-09-21 15:07:11 --> No URI present. Default controller set.
INFO - 2024-09-21 15:07:11 --> Router Class Initialized
INFO - 2024-09-21 15:07:11 --> Output Class Initialized
INFO - 2024-09-21 15:07:11 --> Security Class Initialized
DEBUG - 2024-09-21 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 15:07:11 --> Input Class Initialized
INFO - 2024-09-21 15:07:11 --> Language Class Initialized
INFO - 2024-09-21 15:07:11 --> Loader Class Initialized
INFO - 2024-09-21 15:07:11 --> Helper loaded: url_helper
INFO - 2024-09-21 15:07:11 --> Helper loaded: file_helper
INFO - 2024-09-21 15:07:11 --> Helper loaded: security_helper
INFO - 2024-09-21 15:07:11 --> Helper loaded: wpu_helper
INFO - 2024-09-21 15:07:11 --> Database Driver Class Initialized
ERROR - 2024-09-21 15:07:12 --> Unable to connect to the database
INFO - 2024-09-21 15:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 15:07:12 --> Config Class Initialized
INFO - 2024-09-21 15:07:12 --> Hooks Class Initialized
DEBUG - 2024-09-21 15:07:12 --> UTF-8 Support Enabled
INFO - 2024-09-21 15:07:12 --> Utf8 Class Initialized
INFO - 2024-09-21 15:07:12 --> URI Class Initialized
DEBUG - 2024-09-21 15:07:12 --> No URI present. Default controller set.
INFO - 2024-09-21 15:07:12 --> Router Class Initialized
INFO - 2024-09-21 15:07:12 --> Output Class Initialized
INFO - 2024-09-21 15:07:12 --> Security Class Initialized
DEBUG - 2024-09-21 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 15:07:12 --> Input Class Initialized
INFO - 2024-09-21 15:07:12 --> Language Class Initialized
INFO - 2024-09-21 15:07:12 --> Loader Class Initialized
INFO - 2024-09-21 15:07:12 --> Helper loaded: url_helper
INFO - 2024-09-21 15:07:12 --> Helper loaded: file_helper
INFO - 2024-09-21 15:07:12 --> Helper loaded: security_helper
INFO - 2024-09-21 15:07:12 --> Helper loaded: wpu_helper
INFO - 2024-09-21 15:07:12 --> Database Driver Class Initialized
ERROR - 2024-09-21 15:07:12 --> Unable to connect to the database
INFO - 2024-09-21 15:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 15:08:23 --> Config Class Initialized
INFO - 2024-09-21 15:08:23 --> Hooks Class Initialized
DEBUG - 2024-09-21 15:08:23 --> UTF-8 Support Enabled
INFO - 2024-09-21 15:08:23 --> Utf8 Class Initialized
INFO - 2024-09-21 15:08:23 --> URI Class Initialized
DEBUG - 2024-09-21 15:08:23 --> No URI present. Default controller set.
INFO - 2024-09-21 15:08:23 --> Router Class Initialized
INFO - 2024-09-21 15:08:23 --> Output Class Initialized
INFO - 2024-09-21 15:08:23 --> Security Class Initialized
DEBUG - 2024-09-21 15:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 15:08:23 --> Input Class Initialized
INFO - 2024-09-21 15:08:23 --> Language Class Initialized
INFO - 2024-09-21 15:08:23 --> Loader Class Initialized
INFO - 2024-09-21 15:08:23 --> Helper loaded: url_helper
INFO - 2024-09-21 15:08:23 --> Helper loaded: file_helper
INFO - 2024-09-21 15:08:23 --> Helper loaded: security_helper
INFO - 2024-09-21 15:08:23 --> Helper loaded: wpu_helper
INFO - 2024-09-21 15:08:23 --> Database Driver Class Initialized
ERROR - 2024-09-21 15:08:23 --> Unable to connect to the database
INFO - 2024-09-21 15:08:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 21:30:40 --> Config Class Initialized
INFO - 2024-09-21 21:30:40 --> Hooks Class Initialized
DEBUG - 2024-09-21 21:30:40 --> UTF-8 Support Enabled
INFO - 2024-09-21 21:30:40 --> Utf8 Class Initialized
INFO - 2024-09-21 21:30:40 --> URI Class Initialized
DEBUG - 2024-09-21 21:30:40 --> No URI present. Default controller set.
INFO - 2024-09-21 21:30:40 --> Router Class Initialized
INFO - 2024-09-21 21:30:40 --> Output Class Initialized
INFO - 2024-09-21 21:30:40 --> Security Class Initialized
DEBUG - 2024-09-21 21:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 21:30:40 --> Input Class Initialized
INFO - 2024-09-21 21:30:40 --> Language Class Initialized
INFO - 2024-09-21 21:30:40 --> Loader Class Initialized
INFO - 2024-09-21 21:30:40 --> Helper loaded: url_helper
INFO - 2024-09-21 21:30:40 --> Helper loaded: file_helper
INFO - 2024-09-21 21:30:40 --> Helper loaded: security_helper
INFO - 2024-09-21 21:30:40 --> Helper loaded: wpu_helper
INFO - 2024-09-21 21:30:40 --> Database Driver Class Initialized
INFO - 2024-09-21 21:30:40 --> Email Class Initialized
DEBUG - 2024-09-21 21:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 21:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 21:30:40 --> Helper loaded: form_helper
INFO - 2024-09-21 21:30:40 --> Form Validation Class Initialized
INFO - 2024-09-21 21:30:40 --> Controller Class Initialized
DEBUG - 2024-09-21 21:30:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 21:30:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-21 21:30:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-21 21:30:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-21 21:30:40 --> Final output sent to browser
DEBUG - 2024-09-21 21:30:40 --> Total execution time: 0.2200
INFO - 2024-09-21 21:32:32 --> Config Class Initialized
INFO - 2024-09-21 21:32:32 --> Hooks Class Initialized
DEBUG - 2024-09-21 21:32:32 --> UTF-8 Support Enabled
INFO - 2024-09-21 21:32:32 --> Utf8 Class Initialized
INFO - 2024-09-21 21:32:32 --> URI Class Initialized
DEBUG - 2024-09-21 21:32:32 --> No URI present. Default controller set.
INFO - 2024-09-21 21:32:32 --> Router Class Initialized
INFO - 2024-09-21 21:32:32 --> Output Class Initialized
INFO - 2024-09-21 21:32:32 --> Security Class Initialized
DEBUG - 2024-09-21 21:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 21:32:32 --> Input Class Initialized
INFO - 2024-09-21 21:32:32 --> Language Class Initialized
INFO - 2024-09-21 21:32:32 --> Loader Class Initialized
INFO - 2024-09-21 21:32:32 --> Helper loaded: url_helper
INFO - 2024-09-21 21:32:32 --> Helper loaded: file_helper
INFO - 2024-09-21 21:32:32 --> Helper loaded: security_helper
INFO - 2024-09-21 21:32:32 --> Helper loaded: wpu_helper
INFO - 2024-09-21 21:32:32 --> Database Driver Class Initialized
INFO - 2024-09-21 21:32:32 --> Email Class Initialized
DEBUG - 2024-09-21 21:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 21:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 21:32:32 --> Helper loaded: form_helper
INFO - 2024-09-21 21:32:32 --> Form Validation Class Initialized
INFO - 2024-09-21 21:32:32 --> Controller Class Initialized
DEBUG - 2024-09-21 21:32:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 21:32:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-21 21:32:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-21 21:32:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-21 21:32:32 --> Final output sent to browser
DEBUG - 2024-09-21 21:32:32 --> Total execution time: 0.2127
INFO - 2024-09-21 23:38:28 --> Config Class Initialized
INFO - 2024-09-21 23:38:28 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:38:28 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:38:28 --> Utf8 Class Initialized
INFO - 2024-09-21 23:38:28 --> URI Class Initialized
DEBUG - 2024-09-21 23:38:28 --> No URI present. Default controller set.
INFO - 2024-09-21 23:38:28 --> Router Class Initialized
INFO - 2024-09-21 23:38:28 --> Output Class Initialized
INFO - 2024-09-21 23:38:28 --> Security Class Initialized
DEBUG - 2024-09-21 23:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:38:28 --> Input Class Initialized
INFO - 2024-09-21 23:38:28 --> Language Class Initialized
INFO - 2024-09-21 23:38:28 --> Loader Class Initialized
INFO - 2024-09-21 23:38:28 --> Helper loaded: url_helper
INFO - 2024-09-21 23:38:28 --> Helper loaded: file_helper
INFO - 2024-09-21 23:38:28 --> Helper loaded: security_helper
INFO - 2024-09-21 23:38:28 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:38:28 --> Database Driver Class Initialized
INFO - 2024-09-21 23:38:43 --> Config Class Initialized
INFO - 2024-09-21 23:38:43 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:38:43 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:38:43 --> Utf8 Class Initialized
INFO - 2024-09-21 23:38:43 --> URI Class Initialized
DEBUG - 2024-09-21 23:38:43 --> No URI present. Default controller set.
INFO - 2024-09-21 23:38:43 --> Router Class Initialized
INFO - 2024-09-21 23:38:43 --> Output Class Initialized
INFO - 2024-09-21 23:38:43 --> Security Class Initialized
DEBUG - 2024-09-21 23:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:38:43 --> Input Class Initialized
INFO - 2024-09-21 23:38:43 --> Language Class Initialized
INFO - 2024-09-21 23:38:43 --> Loader Class Initialized
INFO - 2024-09-21 23:38:43 --> Helper loaded: url_helper
INFO - 2024-09-21 23:38:43 --> Helper loaded: file_helper
INFO - 2024-09-21 23:38:43 --> Helper loaded: security_helper
INFO - 2024-09-21 23:38:43 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:38:43 --> Database Driver Class Initialized
ERROR - 2024-09-21 23:38:59 --> Unable to connect to the database
INFO - 2024-09-21 23:38:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-09-21 23:39:14 --> Unable to connect to the database
INFO - 2024-09-21 23:39:14 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-21 23:39:48 --> Config Class Initialized
INFO - 2024-09-21 23:39:48 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:39:48 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:39:48 --> Utf8 Class Initialized
INFO - 2024-09-21 23:39:48 --> URI Class Initialized
DEBUG - 2024-09-21 23:39:48 --> No URI present. Default controller set.
INFO - 2024-09-21 23:39:48 --> Router Class Initialized
INFO - 2024-09-21 23:39:48 --> Output Class Initialized
INFO - 2024-09-21 23:39:48 --> Security Class Initialized
DEBUG - 2024-09-21 23:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:39:48 --> Input Class Initialized
INFO - 2024-09-21 23:39:48 --> Language Class Initialized
INFO - 2024-09-21 23:39:48 --> Loader Class Initialized
INFO - 2024-09-21 23:39:48 --> Helper loaded: url_helper
INFO - 2024-09-21 23:39:48 --> Helper loaded: file_helper
INFO - 2024-09-21 23:39:48 --> Helper loaded: security_helper
INFO - 2024-09-21 23:39:48 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:39:48 --> Database Driver Class Initialized
INFO - 2024-09-21 23:40:09 --> Config Class Initialized
INFO - 2024-09-21 23:40:09 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:40:09 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:40:09 --> Utf8 Class Initialized
INFO - 2024-09-21 23:40:09 --> URI Class Initialized
DEBUG - 2024-09-21 23:40:09 --> No URI present. Default controller set.
INFO - 2024-09-21 23:40:09 --> Router Class Initialized
INFO - 2024-09-21 23:40:09 --> Output Class Initialized
INFO - 2024-09-21 23:40:09 --> Security Class Initialized
DEBUG - 2024-09-21 23:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:40:09 --> Input Class Initialized
INFO - 2024-09-21 23:40:09 --> Language Class Initialized
INFO - 2024-09-21 23:40:09 --> Loader Class Initialized
INFO - 2024-09-21 23:40:09 --> Helper loaded: url_helper
INFO - 2024-09-21 23:40:09 --> Helper loaded: file_helper
INFO - 2024-09-21 23:40:09 --> Helper loaded: security_helper
INFO - 2024-09-21 23:40:09 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:40:09 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:04 --> Config Class Initialized
INFO - 2024-09-21 23:41:04 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:41:04 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:41:04 --> Utf8 Class Initialized
INFO - 2024-09-21 23:41:04 --> URI Class Initialized
DEBUG - 2024-09-21 23:41:04 --> No URI present. Default controller set.
INFO - 2024-09-21 23:41:04 --> Router Class Initialized
INFO - 2024-09-21 23:41:04 --> Output Class Initialized
INFO - 2024-09-21 23:41:04 --> Security Class Initialized
DEBUG - 2024-09-21 23:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:41:04 --> Input Class Initialized
INFO - 2024-09-21 23:41:04 --> Language Class Initialized
INFO - 2024-09-21 23:41:04 --> Loader Class Initialized
INFO - 2024-09-21 23:41:04 --> Helper loaded: url_helper
INFO - 2024-09-21 23:41:04 --> Helper loaded: file_helper
INFO - 2024-09-21 23:41:04 --> Helper loaded: security_helper
INFO - 2024-09-21 23:41:04 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:41:04 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:04 --> Email Class Initialized
DEBUG - 2024-09-21 23:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:41:04 --> Helper loaded: form_helper
INFO - 2024-09-21 23:41:04 --> Form Validation Class Initialized
INFO - 2024-09-21 23:41:04 --> Controller Class Initialized
DEBUG - 2024-09-21 23:41:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-21 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-21 23:41:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-21 23:41:04 --> Final output sent to browser
DEBUG - 2024-09-21 23:41:04 --> Total execution time: 0.2294
INFO - 2024-09-21 23:41:05 --> Config Class Initialized
INFO - 2024-09-21 23:41:05 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:41:05 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:41:05 --> Utf8 Class Initialized
INFO - 2024-09-21 23:41:05 --> URI Class Initialized
DEBUG - 2024-09-21 23:41:05 --> No URI present. Default controller set.
INFO - 2024-09-21 23:41:05 --> Router Class Initialized
INFO - 2024-09-21 23:41:05 --> Output Class Initialized
INFO - 2024-09-21 23:41:05 --> Security Class Initialized
DEBUG - 2024-09-21 23:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:41:05 --> Input Class Initialized
INFO - 2024-09-21 23:41:05 --> Language Class Initialized
INFO - 2024-09-21 23:41:05 --> Loader Class Initialized
INFO - 2024-09-21 23:41:05 --> Helper loaded: url_helper
INFO - 2024-09-21 23:41:05 --> Helper loaded: file_helper
INFO - 2024-09-21 23:41:05 --> Helper loaded: security_helper
INFO - 2024-09-21 23:41:05 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:41:05 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:06 --> Email Class Initialized
DEBUG - 2024-09-21 23:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:41:06 --> Helper loaded: form_helper
INFO - 2024-09-21 23:41:06 --> Form Validation Class Initialized
INFO - 2024-09-21 23:41:06 --> Controller Class Initialized
DEBUG - 2024-09-21 23:41:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:41:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-21 23:41:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-21 23:41:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-21 23:41:06 --> Final output sent to browser
DEBUG - 2024-09-21 23:41:06 --> Total execution time: 0.2143
INFO - 2024-09-21 23:41:42 --> Config Class Initialized
INFO - 2024-09-21 23:41:42 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:41:42 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:41:42 --> Utf8 Class Initialized
INFO - 2024-09-21 23:41:42 --> URI Class Initialized
DEBUG - 2024-09-21 23:41:42 --> No URI present. Default controller set.
INFO - 2024-09-21 23:41:42 --> Router Class Initialized
INFO - 2024-09-21 23:41:42 --> Output Class Initialized
INFO - 2024-09-21 23:41:42 --> Security Class Initialized
DEBUG - 2024-09-21 23:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:41:42 --> Input Class Initialized
INFO - 2024-09-21 23:41:42 --> Language Class Initialized
INFO - 2024-09-21 23:41:42 --> Loader Class Initialized
INFO - 2024-09-21 23:41:42 --> Helper loaded: url_helper
INFO - 2024-09-21 23:41:42 --> Helper loaded: file_helper
INFO - 2024-09-21 23:41:42 --> Helper loaded: security_helper
INFO - 2024-09-21 23:41:42 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:41:42 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:42 --> Email Class Initialized
DEBUG - 2024-09-21 23:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:41:42 --> Helper loaded: form_helper
INFO - 2024-09-21 23:41:42 --> Form Validation Class Initialized
INFO - 2024-09-21 23:41:42 --> Controller Class Initialized
DEBUG - 2024-09-21 23:41:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:41:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-21 23:41:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-21 23:41:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-21 23:41:42 --> Final output sent to browser
DEBUG - 2024-09-21 23:41:42 --> Total execution time: 0.2117
INFO - 2024-09-21 23:41:44 --> Config Class Initialized
INFO - 2024-09-21 23:41:44 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:41:44 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:41:44 --> Utf8 Class Initialized
INFO - 2024-09-21 23:41:44 --> URI Class Initialized
INFO - 2024-09-21 23:41:44 --> Router Class Initialized
INFO - 2024-09-21 23:41:44 --> Output Class Initialized
INFO - 2024-09-21 23:41:44 --> Security Class Initialized
DEBUG - 2024-09-21 23:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:41:44 --> Input Class Initialized
INFO - 2024-09-21 23:41:44 --> Language Class Initialized
INFO - 2024-09-21 23:41:44 --> Loader Class Initialized
INFO - 2024-09-21 23:41:44 --> Helper loaded: url_helper
INFO - 2024-09-21 23:41:44 --> Helper loaded: file_helper
INFO - 2024-09-21 23:41:44 --> Helper loaded: security_helper
INFO - 2024-09-21 23:41:44 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:41:44 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:44 --> Email Class Initialized
DEBUG - 2024-09-21 23:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:41:44 --> Helper loaded: form_helper
INFO - 2024-09-21 23:41:44 --> Form Validation Class Initialized
INFO - 2024-09-21 23:41:44 --> Controller Class Initialized
DEBUG - 2024-09-21 23:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:41:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-21 23:41:45 --> Config Class Initialized
INFO - 2024-09-21 23:41:45 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:41:45 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:41:45 --> Utf8 Class Initialized
INFO - 2024-09-21 23:41:45 --> URI Class Initialized
INFO - 2024-09-21 23:41:45 --> Router Class Initialized
INFO - 2024-09-21 23:41:45 --> Output Class Initialized
INFO - 2024-09-21 23:41:45 --> Security Class Initialized
DEBUG - 2024-09-21 23:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:41:45 --> Input Class Initialized
INFO - 2024-09-21 23:41:45 --> Language Class Initialized
INFO - 2024-09-21 23:41:45 --> Loader Class Initialized
INFO - 2024-09-21 23:41:45 --> Helper loaded: url_helper
INFO - 2024-09-21 23:41:45 --> Helper loaded: file_helper
INFO - 2024-09-21 23:41:45 --> Helper loaded: security_helper
INFO - 2024-09-21 23:41:45 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:41:45 --> Database Driver Class Initialized
INFO - 2024-09-21 23:41:45 --> Email Class Initialized
DEBUG - 2024-09-21 23:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:41:45 --> Helper loaded: form_helper
INFO - 2024-09-21 23:41:45 --> Form Validation Class Initialized
INFO - 2024-09-21 23:41:45 --> Controller Class Initialized
INFO - 2024-09-21 23:41:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-21 23:41:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:41:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-21 23:41:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-21 23:41:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-21 23:41:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-21 23:41:45 --> Final output sent to browser
DEBUG - 2024-09-21 23:41:45 --> Total execution time: 0.6059
INFO - 2024-09-21 23:42:47 --> Config Class Initialized
INFO - 2024-09-21 23:42:47 --> Hooks Class Initialized
DEBUG - 2024-09-21 23:42:47 --> UTF-8 Support Enabled
INFO - 2024-09-21 23:42:47 --> Utf8 Class Initialized
INFO - 2024-09-21 23:42:47 --> URI Class Initialized
INFO - 2024-09-21 23:42:47 --> Router Class Initialized
INFO - 2024-09-21 23:42:47 --> Output Class Initialized
INFO - 2024-09-21 23:42:47 --> Security Class Initialized
DEBUG - 2024-09-21 23:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-21 23:42:47 --> Input Class Initialized
INFO - 2024-09-21 23:42:47 --> Language Class Initialized
INFO - 2024-09-21 23:42:47 --> Loader Class Initialized
INFO - 2024-09-21 23:42:47 --> Helper loaded: url_helper
INFO - 2024-09-21 23:42:47 --> Helper loaded: file_helper
INFO - 2024-09-21 23:42:47 --> Helper loaded: security_helper
INFO - 2024-09-21 23:42:47 --> Helper loaded: wpu_helper
INFO - 2024-09-21 23:42:47 --> Database Driver Class Initialized
INFO - 2024-09-21 23:42:47 --> Email Class Initialized
DEBUG - 2024-09-21 23:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-21 23:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-21 23:42:47 --> Helper loaded: form_helper
INFO - 2024-09-21 23:42:47 --> Form Validation Class Initialized
INFO - 2024-09-21 23:42:47 --> Controller Class Initialized
INFO - 2024-09-21 23:42:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-21 23:42:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-21 23:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-21 23:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-21 23:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-21 23:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-21 23:42:48 --> Final output sent to browser
DEBUG - 2024-09-21 23:42:48 --> Total execution time: 0.5985
