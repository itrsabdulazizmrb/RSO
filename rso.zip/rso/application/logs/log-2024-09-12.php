<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-12 00:16:51 --> Config Class Initialized
INFO - 2024-09-12 00:16:51 --> Hooks Class Initialized
DEBUG - 2024-09-12 00:16:51 --> UTF-8 Support Enabled
INFO - 2024-09-12 00:16:51 --> Utf8 Class Initialized
INFO - 2024-09-12 00:16:51 --> URI Class Initialized
DEBUG - 2024-09-12 00:16:51 --> No URI present. Default controller set.
INFO - 2024-09-12 00:16:51 --> Router Class Initialized
INFO - 2024-09-12 00:16:51 --> Output Class Initialized
INFO - 2024-09-12 00:16:51 --> Security Class Initialized
DEBUG - 2024-09-12 00:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 00:16:51 --> Input Class Initialized
INFO - 2024-09-12 00:16:51 --> Language Class Initialized
INFO - 2024-09-12 00:16:51 --> Loader Class Initialized
INFO - 2024-09-12 00:16:51 --> Helper loaded: url_helper
INFO - 2024-09-12 00:16:51 --> Helper loaded: file_helper
INFO - 2024-09-12 00:16:51 --> Helper loaded: security_helper
INFO - 2024-09-12 00:16:51 --> Helper loaded: wpu_helper
INFO - 2024-09-12 00:16:51 --> Database Driver Class Initialized
INFO - 2024-09-12 00:49:46 --> Config Class Initialized
INFO - 2024-09-12 00:49:46 --> Hooks Class Initialized
DEBUG - 2024-09-12 00:49:46 --> UTF-8 Support Enabled
INFO - 2024-09-12 00:49:46 --> Utf8 Class Initialized
INFO - 2024-09-12 00:49:46 --> URI Class Initialized
DEBUG - 2024-09-12 00:49:46 --> No URI present. Default controller set.
INFO - 2024-09-12 00:49:46 --> Router Class Initialized
INFO - 2024-09-12 00:49:46 --> Output Class Initialized
INFO - 2024-09-12 00:49:46 --> Security Class Initialized
DEBUG - 2024-09-12 00:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 00:49:46 --> Input Class Initialized
INFO - 2024-09-12 00:49:46 --> Language Class Initialized
INFO - 2024-09-12 00:49:46 --> Loader Class Initialized
INFO - 2024-09-12 00:49:46 --> Helper loaded: url_helper
INFO - 2024-09-12 00:49:46 --> Helper loaded: file_helper
INFO - 2024-09-12 00:49:46 --> Helper loaded: security_helper
INFO - 2024-09-12 00:49:46 --> Helper loaded: wpu_helper
INFO - 2024-09-12 00:49:46 --> Database Driver Class Initialized
INFO - 2024-09-12 01:17:24 --> Config Class Initialized
INFO - 2024-09-12 01:17:24 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:17:24 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:17:24 --> Utf8 Class Initialized
INFO - 2024-09-12 01:17:24 --> URI Class Initialized
DEBUG - 2024-09-12 01:17:24 --> No URI present. Default controller set.
INFO - 2024-09-12 01:17:24 --> Router Class Initialized
INFO - 2024-09-12 01:17:24 --> Output Class Initialized
INFO - 2024-09-12 01:17:24 --> Security Class Initialized
DEBUG - 2024-09-12 01:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:17:24 --> Input Class Initialized
INFO - 2024-09-12 01:17:24 --> Language Class Initialized
INFO - 2024-09-12 01:17:24 --> Loader Class Initialized
INFO - 2024-09-12 01:17:24 --> Helper loaded: url_helper
INFO - 2024-09-12 01:17:24 --> Helper loaded: file_helper
INFO - 2024-09-12 01:17:24 --> Helper loaded: security_helper
INFO - 2024-09-12 01:17:24 --> Helper loaded: wpu_helper
INFO - 2024-09-12 01:17:24 --> Database Driver Class Initialized
INFO - 2024-09-12 01:50:59 --> Config Class Initialized
INFO - 2024-09-12 01:50:59 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:50:59 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:50:59 --> Utf8 Class Initialized
INFO - 2024-09-12 01:50:59 --> URI Class Initialized
DEBUG - 2024-09-12 01:50:59 --> No URI present. Default controller set.
INFO - 2024-09-12 01:50:59 --> Router Class Initialized
INFO - 2024-09-12 01:50:59 --> Output Class Initialized
INFO - 2024-09-12 01:50:59 --> Security Class Initialized
DEBUG - 2024-09-12 01:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:50:59 --> Input Class Initialized
INFO - 2024-09-12 01:50:59 --> Language Class Initialized
INFO - 2024-09-12 01:50:59 --> Loader Class Initialized
INFO - 2024-09-12 01:50:59 --> Helper loaded: url_helper
INFO - 2024-09-12 01:50:59 --> Helper loaded: file_helper
INFO - 2024-09-12 01:50:59 --> Helper loaded: security_helper
INFO - 2024-09-12 01:50:59 --> Helper loaded: wpu_helper
INFO - 2024-09-12 01:50:59 --> Database Driver Class Initialized
INFO - 2024-09-12 01:50:59 --> Email Class Initialized
DEBUG - 2024-09-12 01:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 01:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 01:50:59 --> Helper loaded: form_helper
INFO - 2024-09-12 01:50:59 --> Form Validation Class Initialized
INFO - 2024-09-12 01:50:59 --> Controller Class Initialized
DEBUG - 2024-09-12 01:50:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 01:50:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 01:50:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 01:50:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 01:50:59 --> Final output sent to browser
DEBUG - 2024-09-12 01:50:59 --> Total execution time: 0.2279
INFO - 2024-09-12 01:53:11 --> Config Class Initialized
INFO - 2024-09-12 01:53:11 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:53:11 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:53:11 --> Utf8 Class Initialized
INFO - 2024-09-12 01:53:11 --> URI Class Initialized
DEBUG - 2024-09-12 01:53:11 --> No URI present. Default controller set.
INFO - 2024-09-12 01:53:11 --> Router Class Initialized
INFO - 2024-09-12 01:53:11 --> Output Class Initialized
INFO - 2024-09-12 01:53:11 --> Security Class Initialized
DEBUG - 2024-09-12 01:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:53:11 --> Input Class Initialized
INFO - 2024-09-12 01:53:11 --> Language Class Initialized
INFO - 2024-09-12 01:53:11 --> Loader Class Initialized
INFO - 2024-09-12 01:53:11 --> Helper loaded: url_helper
INFO - 2024-09-12 01:53:11 --> Helper loaded: file_helper
INFO - 2024-09-12 01:53:11 --> Helper loaded: security_helper
INFO - 2024-09-12 01:53:11 --> Helper loaded: wpu_helper
INFO - 2024-09-12 01:53:11 --> Database Driver Class Initialized
INFO - 2024-09-12 01:53:11 --> Email Class Initialized
DEBUG - 2024-09-12 01:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 01:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 01:53:11 --> Helper loaded: form_helper
INFO - 2024-09-12 01:53:11 --> Form Validation Class Initialized
INFO - 2024-09-12 01:53:11 --> Controller Class Initialized
DEBUG - 2024-09-12 01:53:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 01:53:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 01:53:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 01:53:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 01:53:11 --> Final output sent to browser
DEBUG - 2024-09-12 01:53:11 --> Total execution time: 0.2794
INFO - 2024-09-12 01:53:20 --> Config Class Initialized
INFO - 2024-09-12 01:53:20 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:53:20 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:53:20 --> Utf8 Class Initialized
INFO - 2024-09-12 01:53:20 --> URI Class Initialized
INFO - 2024-09-12 01:53:20 --> Router Class Initialized
INFO - 2024-09-12 01:53:20 --> Output Class Initialized
INFO - 2024-09-12 01:53:20 --> Security Class Initialized
DEBUG - 2024-09-12 01:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:53:20 --> Input Class Initialized
INFO - 2024-09-12 01:53:20 --> Language Class Initialized
ERROR - 2024-09-12 01:53:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-09-12 01:53:21 --> Config Class Initialized
INFO - 2024-09-12 01:53:21 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:53:21 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:53:21 --> Utf8 Class Initialized
INFO - 2024-09-12 01:53:21 --> URI Class Initialized
INFO - 2024-09-12 01:53:21 --> Router Class Initialized
INFO - 2024-09-12 01:53:21 --> Output Class Initialized
INFO - 2024-09-12 01:53:21 --> Security Class Initialized
DEBUG - 2024-09-12 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:53:21 --> Input Class Initialized
INFO - 2024-09-12 01:53:21 --> Language Class Initialized
ERROR - 2024-09-12 01:53:21 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-09-12 01:53:21 --> Config Class Initialized
INFO - 2024-09-12 01:53:21 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:53:21 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:53:21 --> Utf8 Class Initialized
INFO - 2024-09-12 01:53:21 --> URI Class Initialized
INFO - 2024-09-12 01:53:21 --> Router Class Initialized
INFO - 2024-09-12 01:53:21 --> Output Class Initialized
INFO - 2024-09-12 01:53:21 --> Security Class Initialized
DEBUG - 2024-09-12 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:53:21 --> Input Class Initialized
INFO - 2024-09-12 01:53:21 --> Language Class Initialized
ERROR - 2024-09-12 01:53:21 --> 404 Page Not Found: Configjson/index
INFO - 2024-09-12 01:55:37 --> Config Class Initialized
INFO - 2024-09-12 01:55:37 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:55:37 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:55:37 --> Utf8 Class Initialized
INFO - 2024-09-12 01:55:37 --> URI Class Initialized
DEBUG - 2024-09-12 01:55:37 --> No URI present. Default controller set.
INFO - 2024-09-12 01:55:37 --> Router Class Initialized
INFO - 2024-09-12 01:55:37 --> Output Class Initialized
INFO - 2024-09-12 01:55:37 --> Security Class Initialized
DEBUG - 2024-09-12 01:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:55:37 --> Input Class Initialized
INFO - 2024-09-12 01:55:37 --> Language Class Initialized
INFO - 2024-09-12 01:55:37 --> Loader Class Initialized
INFO - 2024-09-12 01:55:37 --> Helper loaded: url_helper
INFO - 2024-09-12 01:55:37 --> Helper loaded: file_helper
INFO - 2024-09-12 01:55:37 --> Helper loaded: security_helper
INFO - 2024-09-12 01:55:37 --> Helper loaded: wpu_helper
INFO - 2024-09-12 01:55:37 --> Database Driver Class Initialized
INFO - 2024-09-12 01:55:37 --> Email Class Initialized
DEBUG - 2024-09-12 01:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 01:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 01:55:37 --> Helper loaded: form_helper
INFO - 2024-09-12 01:55:37 --> Form Validation Class Initialized
INFO - 2024-09-12 01:55:37 --> Controller Class Initialized
DEBUG - 2024-09-12 01:55:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 01:55:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 01:55:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 01:55:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 01:55:37 --> Final output sent to browser
DEBUG - 2024-09-12 01:55:37 --> Total execution time: 0.4602
INFO - 2024-09-12 01:55:44 --> Config Class Initialized
INFO - 2024-09-12 01:55:44 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:55:44 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:55:44 --> Utf8 Class Initialized
INFO - 2024-09-12 01:55:44 --> URI Class Initialized
INFO - 2024-09-12 01:55:44 --> Router Class Initialized
INFO - 2024-09-12 01:55:44 --> Output Class Initialized
INFO - 2024-09-12 01:55:44 --> Security Class Initialized
DEBUG - 2024-09-12 01:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:55:44 --> Input Class Initialized
INFO - 2024-09-12 01:55:44 --> Language Class Initialized
ERROR - 2024-09-12 01:55:44 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-09-12 01:55:46 --> Config Class Initialized
INFO - 2024-09-12 01:55:46 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:55:46 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:55:46 --> Utf8 Class Initialized
INFO - 2024-09-12 01:55:46 --> URI Class Initialized
INFO - 2024-09-12 01:55:46 --> Router Class Initialized
INFO - 2024-09-12 01:55:46 --> Output Class Initialized
INFO - 2024-09-12 01:55:46 --> Security Class Initialized
DEBUG - 2024-09-12 01:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:55:46 --> Input Class Initialized
INFO - 2024-09-12 01:55:46 --> Language Class Initialized
ERROR - 2024-09-12 01:55:46 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-09-12 01:55:52 --> Config Class Initialized
INFO - 2024-09-12 01:55:52 --> Hooks Class Initialized
DEBUG - 2024-09-12 01:55:52 --> UTF-8 Support Enabled
INFO - 2024-09-12 01:55:52 --> Utf8 Class Initialized
INFO - 2024-09-12 01:55:52 --> URI Class Initialized
INFO - 2024-09-12 01:55:52 --> Router Class Initialized
INFO - 2024-09-12 01:55:52 --> Output Class Initialized
INFO - 2024-09-12 01:55:52 --> Security Class Initialized
DEBUG - 2024-09-12 01:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 01:55:52 --> Input Class Initialized
INFO - 2024-09-12 01:55:52 --> Language Class Initialized
ERROR - 2024-09-12 01:55:52 --> 404 Page Not Found: Configjson/index
INFO - 2024-09-12 02:18:16 --> Config Class Initialized
INFO - 2024-09-12 02:18:16 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:18:16 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:18:16 --> Utf8 Class Initialized
INFO - 2024-09-12 02:18:16 --> URI Class Initialized
DEBUG - 2024-09-12 02:18:16 --> No URI present. Default controller set.
INFO - 2024-09-12 02:18:16 --> Router Class Initialized
INFO - 2024-09-12 02:18:16 --> Output Class Initialized
INFO - 2024-09-12 02:18:16 --> Security Class Initialized
DEBUG - 2024-09-12 02:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:18:16 --> Input Class Initialized
INFO - 2024-09-12 02:18:16 --> Language Class Initialized
INFO - 2024-09-12 02:18:16 --> Loader Class Initialized
INFO - 2024-09-12 02:18:16 --> Helper loaded: url_helper
INFO - 2024-09-12 02:18:16 --> Helper loaded: file_helper
INFO - 2024-09-12 02:18:16 --> Helper loaded: security_helper
INFO - 2024-09-12 02:18:16 --> Helper loaded: wpu_helper
INFO - 2024-09-12 02:18:16 --> Database Driver Class Initialized
INFO - 2024-09-12 02:18:17 --> Email Class Initialized
DEBUG - 2024-09-12 02:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 02:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 02:18:17 --> Helper loaded: form_helper
INFO - 2024-09-12 02:18:17 --> Form Validation Class Initialized
INFO - 2024-09-12 02:18:17 --> Controller Class Initialized
DEBUG - 2024-09-12 02:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 02:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 02:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 02:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 02:18:17 --> Final output sent to browser
DEBUG - 2024-09-12 02:18:17 --> Total execution time: 1.5010
INFO - 2024-09-12 02:18:27 --> Config Class Initialized
INFO - 2024-09-12 02:18:27 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:18:27 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:18:27 --> Utf8 Class Initialized
INFO - 2024-09-12 02:18:27 --> URI Class Initialized
DEBUG - 2024-09-12 02:18:27 --> No URI present. Default controller set.
INFO - 2024-09-12 02:18:27 --> Router Class Initialized
INFO - 2024-09-12 02:18:27 --> Output Class Initialized
INFO - 2024-09-12 02:18:27 --> Security Class Initialized
DEBUG - 2024-09-12 02:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:18:27 --> Input Class Initialized
INFO - 2024-09-12 02:18:27 --> Language Class Initialized
INFO - 2024-09-12 02:18:27 --> Loader Class Initialized
INFO - 2024-09-12 02:18:27 --> Helper loaded: url_helper
INFO - 2024-09-12 02:18:27 --> Helper loaded: file_helper
INFO - 2024-09-12 02:18:27 --> Helper loaded: security_helper
INFO - 2024-09-12 02:18:27 --> Helper loaded: wpu_helper
INFO - 2024-09-12 02:18:27 --> Database Driver Class Initialized
INFO - 2024-09-12 02:18:28 --> Email Class Initialized
DEBUG - 2024-09-12 02:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 02:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 02:18:28 --> Helper loaded: form_helper
INFO - 2024-09-12 02:18:28 --> Form Validation Class Initialized
INFO - 2024-09-12 02:18:28 --> Controller Class Initialized
DEBUG - 2024-09-12 02:18:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 02:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 02:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 02:18:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 02:18:28 --> Final output sent to browser
DEBUG - 2024-09-12 02:18:28 --> Total execution time: 1.2512
INFO - 2024-09-12 02:18:35 --> Config Class Initialized
INFO - 2024-09-12 02:18:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:18:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:18:35 --> Utf8 Class Initialized
INFO - 2024-09-12 02:18:35 --> URI Class Initialized
INFO - 2024-09-12 02:18:35 --> Router Class Initialized
INFO - 2024-09-12 02:18:35 --> Output Class Initialized
INFO - 2024-09-12 02:18:35 --> Security Class Initialized
DEBUG - 2024-09-12 02:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:18:35 --> Input Class Initialized
INFO - 2024-09-12 02:18:35 --> Language Class Initialized
ERROR - 2024-09-12 02:18:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-09-12 02:18:35 --> Config Class Initialized
INFO - 2024-09-12 02:18:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:18:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:18:35 --> Utf8 Class Initialized
INFO - 2024-09-12 02:18:35 --> URI Class Initialized
INFO - 2024-09-12 02:18:35 --> Router Class Initialized
INFO - 2024-09-12 02:18:35 --> Output Class Initialized
INFO - 2024-09-12 02:18:35 --> Security Class Initialized
DEBUG - 2024-09-12 02:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:18:35 --> Input Class Initialized
INFO - 2024-09-12 02:18:35 --> Language Class Initialized
ERROR - 2024-09-12 02:18:35 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-09-12 02:18:36 --> Config Class Initialized
INFO - 2024-09-12 02:18:36 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:18:36 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:18:36 --> Utf8 Class Initialized
INFO - 2024-09-12 02:18:36 --> URI Class Initialized
INFO - 2024-09-12 02:18:36 --> Router Class Initialized
INFO - 2024-09-12 02:18:36 --> Output Class Initialized
INFO - 2024-09-12 02:18:36 --> Security Class Initialized
DEBUG - 2024-09-12 02:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:18:36 --> Input Class Initialized
INFO - 2024-09-12 02:18:36 --> Language Class Initialized
ERROR - 2024-09-12 02:18:36 --> 404 Page Not Found: Configjson/index
INFO - 2024-09-12 02:20:32 --> Config Class Initialized
INFO - 2024-09-12 02:20:32 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:20:32 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:20:32 --> Utf8 Class Initialized
INFO - 2024-09-12 02:20:32 --> URI Class Initialized
DEBUG - 2024-09-12 02:20:32 --> No URI present. Default controller set.
INFO - 2024-09-12 02:20:32 --> Router Class Initialized
INFO - 2024-09-12 02:20:32 --> Output Class Initialized
INFO - 2024-09-12 02:20:32 --> Security Class Initialized
DEBUG - 2024-09-12 02:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:20:32 --> Input Class Initialized
INFO - 2024-09-12 02:20:32 --> Language Class Initialized
INFO - 2024-09-12 02:20:32 --> Loader Class Initialized
INFO - 2024-09-12 02:20:32 --> Helper loaded: url_helper
INFO - 2024-09-12 02:20:32 --> Helper loaded: file_helper
INFO - 2024-09-12 02:20:32 --> Helper loaded: security_helper
INFO - 2024-09-12 02:20:32 --> Helper loaded: wpu_helper
INFO - 2024-09-12 02:20:32 --> Database Driver Class Initialized
INFO - 2024-09-12 02:20:32 --> Email Class Initialized
DEBUG - 2024-09-12 02:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 02:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 02:20:32 --> Helper loaded: form_helper
INFO - 2024-09-12 02:20:32 --> Form Validation Class Initialized
INFO - 2024-09-12 02:20:32 --> Controller Class Initialized
DEBUG - 2024-09-12 02:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 02:20:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 02:20:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 02:20:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 02:20:32 --> Final output sent to browser
DEBUG - 2024-09-12 02:20:32 --> Total execution time: 0.2338
INFO - 2024-09-12 02:20:40 --> Config Class Initialized
INFO - 2024-09-12 02:20:40 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:20:40 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:20:40 --> Utf8 Class Initialized
INFO - 2024-09-12 02:20:40 --> URI Class Initialized
INFO - 2024-09-12 02:20:40 --> Router Class Initialized
INFO - 2024-09-12 02:20:40 --> Output Class Initialized
INFO - 2024-09-12 02:20:40 --> Security Class Initialized
DEBUG - 2024-09-12 02:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:20:40 --> Input Class Initialized
INFO - 2024-09-12 02:20:40 --> Language Class Initialized
ERROR - 2024-09-12 02:20:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-09-12 02:20:42 --> Config Class Initialized
INFO - 2024-09-12 02:20:42 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:20:42 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:20:42 --> Utf8 Class Initialized
INFO - 2024-09-12 02:20:42 --> URI Class Initialized
INFO - 2024-09-12 02:20:42 --> Router Class Initialized
INFO - 2024-09-12 02:20:42 --> Output Class Initialized
INFO - 2024-09-12 02:20:42 --> Security Class Initialized
DEBUG - 2024-09-12 02:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:20:42 --> Input Class Initialized
INFO - 2024-09-12 02:20:42 --> Language Class Initialized
ERROR - 2024-09-12 02:20:42 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-09-12 02:20:48 --> Config Class Initialized
INFO - 2024-09-12 02:20:48 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:20:48 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:20:48 --> Utf8 Class Initialized
INFO - 2024-09-12 02:20:48 --> URI Class Initialized
INFO - 2024-09-12 02:20:48 --> Router Class Initialized
INFO - 2024-09-12 02:20:48 --> Output Class Initialized
INFO - 2024-09-12 02:20:48 --> Security Class Initialized
DEBUG - 2024-09-12 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:20:48 --> Input Class Initialized
INFO - 2024-09-12 02:20:48 --> Language Class Initialized
ERROR - 2024-09-12 02:20:48 --> 404 Page Not Found: Configjson/index
INFO - 2024-09-12 02:32:37 --> Config Class Initialized
INFO - 2024-09-12 02:32:37 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:32:37 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:32:37 --> Utf8 Class Initialized
INFO - 2024-09-12 02:32:37 --> URI Class Initialized
DEBUG - 2024-09-12 02:32:37 --> No URI present. Default controller set.
INFO - 2024-09-12 02:32:37 --> Router Class Initialized
INFO - 2024-09-12 02:32:37 --> Output Class Initialized
INFO - 2024-09-12 02:32:37 --> Security Class Initialized
DEBUG - 2024-09-12 02:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:32:37 --> Input Class Initialized
INFO - 2024-09-12 02:32:37 --> Language Class Initialized
INFO - 2024-09-12 02:32:37 --> Loader Class Initialized
INFO - 2024-09-12 02:32:37 --> Helper loaded: url_helper
INFO - 2024-09-12 02:32:37 --> Helper loaded: file_helper
INFO - 2024-09-12 02:32:37 --> Helper loaded: security_helper
INFO - 2024-09-12 02:32:37 --> Helper loaded: wpu_helper
INFO - 2024-09-12 02:32:37 --> Database Driver Class Initialized
INFO - 2024-09-12 02:32:37 --> Email Class Initialized
DEBUG - 2024-09-12 02:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 02:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 02:32:37 --> Helper loaded: form_helper
INFO - 2024-09-12 02:32:37 --> Form Validation Class Initialized
INFO - 2024-09-12 02:32:37 --> Controller Class Initialized
DEBUG - 2024-09-12 02:32:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 02:32:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 02:32:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 02:32:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 02:32:37 --> Final output sent to browser
DEBUG - 2024-09-12 02:32:37 --> Total execution time: 0.2395
INFO - 2024-09-12 02:50:28 --> Config Class Initialized
INFO - 2024-09-12 02:50:28 --> Hooks Class Initialized
DEBUG - 2024-09-12 02:50:28 --> UTF-8 Support Enabled
INFO - 2024-09-12 02:50:28 --> Utf8 Class Initialized
INFO - 2024-09-12 02:50:29 --> URI Class Initialized
DEBUG - 2024-09-12 02:50:29 --> No URI present. Default controller set.
INFO - 2024-09-12 02:50:29 --> Router Class Initialized
INFO - 2024-09-12 02:50:29 --> Output Class Initialized
INFO - 2024-09-12 02:50:29 --> Security Class Initialized
DEBUG - 2024-09-12 02:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 02:50:29 --> Input Class Initialized
INFO - 2024-09-12 02:50:29 --> Language Class Initialized
INFO - 2024-09-12 02:50:29 --> Loader Class Initialized
INFO - 2024-09-12 02:50:29 --> Helper loaded: url_helper
INFO - 2024-09-12 02:50:29 --> Helper loaded: file_helper
INFO - 2024-09-12 02:50:29 --> Helper loaded: security_helper
INFO - 2024-09-12 02:50:29 --> Helper loaded: wpu_helper
INFO - 2024-09-12 02:50:29 --> Database Driver Class Initialized
INFO - 2024-09-12 02:50:29 --> Email Class Initialized
DEBUG - 2024-09-12 02:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 02:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 02:50:29 --> Helper loaded: form_helper
INFO - 2024-09-12 02:50:29 --> Form Validation Class Initialized
INFO - 2024-09-12 02:50:29 --> Controller Class Initialized
DEBUG - 2024-09-12 02:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 02:50:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 02:50:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 02:50:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 02:50:29 --> Final output sent to browser
DEBUG - 2024-09-12 02:50:29 --> Total execution time: 0.4797
INFO - 2024-09-12 03:25:45 --> Config Class Initialized
INFO - 2024-09-12 03:25:45 --> Hooks Class Initialized
DEBUG - 2024-09-12 03:25:45 --> UTF-8 Support Enabled
INFO - 2024-09-12 03:25:45 --> Utf8 Class Initialized
INFO - 2024-09-12 03:25:45 --> URI Class Initialized
DEBUG - 2024-09-12 03:25:45 --> No URI present. Default controller set.
INFO - 2024-09-12 03:25:45 --> Router Class Initialized
INFO - 2024-09-12 03:25:45 --> Output Class Initialized
INFO - 2024-09-12 03:25:45 --> Security Class Initialized
DEBUG - 2024-09-12 03:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 03:25:45 --> Input Class Initialized
INFO - 2024-09-12 03:25:45 --> Language Class Initialized
INFO - 2024-09-12 03:25:45 --> Loader Class Initialized
INFO - 2024-09-12 03:25:45 --> Helper loaded: url_helper
INFO - 2024-09-12 03:25:45 --> Helper loaded: file_helper
INFO - 2024-09-12 03:25:45 --> Helper loaded: security_helper
INFO - 2024-09-12 03:25:45 --> Helper loaded: wpu_helper
INFO - 2024-09-12 03:25:45 --> Database Driver Class Initialized
INFO - 2024-09-12 03:25:50 --> Email Class Initialized
DEBUG - 2024-09-12 03:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 03:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 03:25:50 --> Helper loaded: form_helper
INFO - 2024-09-12 03:25:50 --> Form Validation Class Initialized
INFO - 2024-09-12 03:25:50 --> Controller Class Initialized
DEBUG - 2024-09-12 03:25:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 03:25:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 03:25:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 03:25:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 03:25:50 --> Final output sent to browser
DEBUG - 2024-09-12 03:25:50 --> Total execution time: 4.7728
INFO - 2024-09-12 03:54:32 --> Config Class Initialized
INFO - 2024-09-12 03:54:32 --> Hooks Class Initialized
DEBUG - 2024-09-12 03:54:32 --> UTF-8 Support Enabled
INFO - 2024-09-12 03:54:32 --> Utf8 Class Initialized
INFO - 2024-09-12 03:54:32 --> URI Class Initialized
DEBUG - 2024-09-12 03:54:32 --> No URI present. Default controller set.
INFO - 2024-09-12 03:54:32 --> Router Class Initialized
INFO - 2024-09-12 03:54:32 --> Output Class Initialized
INFO - 2024-09-12 03:54:32 --> Security Class Initialized
DEBUG - 2024-09-12 03:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 03:54:32 --> Input Class Initialized
INFO - 2024-09-12 03:54:32 --> Language Class Initialized
INFO - 2024-09-12 03:54:32 --> Loader Class Initialized
INFO - 2024-09-12 03:54:32 --> Helper loaded: url_helper
INFO - 2024-09-12 03:54:32 --> Helper loaded: file_helper
INFO - 2024-09-12 03:54:32 --> Helper loaded: security_helper
INFO - 2024-09-12 03:54:32 --> Helper loaded: wpu_helper
INFO - 2024-09-12 03:54:32 --> Database Driver Class Initialized
INFO - 2024-09-12 03:54:33 --> Email Class Initialized
DEBUG - 2024-09-12 03:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 03:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 03:54:33 --> Helper loaded: form_helper
INFO - 2024-09-12 03:54:33 --> Form Validation Class Initialized
INFO - 2024-09-12 03:54:33 --> Controller Class Initialized
DEBUG - 2024-09-12 03:54:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 03:54:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 03:54:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 03:54:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 03:54:33 --> Final output sent to browser
DEBUG - 2024-09-12 03:54:33 --> Total execution time: 0.4765
INFO - 2024-09-12 04:26:57 --> Config Class Initialized
INFO - 2024-09-12 04:26:57 --> Hooks Class Initialized
DEBUG - 2024-09-12 04:26:57 --> UTF-8 Support Enabled
INFO - 2024-09-12 04:26:57 --> Utf8 Class Initialized
INFO - 2024-09-12 04:26:57 --> URI Class Initialized
DEBUG - 2024-09-12 04:26:57 --> No URI present. Default controller set.
INFO - 2024-09-12 04:26:57 --> Router Class Initialized
INFO - 2024-09-12 04:26:57 --> Output Class Initialized
INFO - 2024-09-12 04:26:57 --> Security Class Initialized
DEBUG - 2024-09-12 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 04:26:57 --> Input Class Initialized
INFO - 2024-09-12 04:26:57 --> Language Class Initialized
INFO - 2024-09-12 04:26:57 --> Loader Class Initialized
INFO - 2024-09-12 04:26:57 --> Helper loaded: url_helper
INFO - 2024-09-12 04:26:57 --> Helper loaded: file_helper
INFO - 2024-09-12 04:26:57 --> Helper loaded: security_helper
INFO - 2024-09-12 04:26:57 --> Helper loaded: wpu_helper
INFO - 2024-09-12 04:26:57 --> Database Driver Class Initialized
INFO - 2024-09-12 04:26:59 --> Email Class Initialized
DEBUG - 2024-09-12 04:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 04:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 04:26:59 --> Helper loaded: form_helper
INFO - 2024-09-12 04:26:59 --> Form Validation Class Initialized
INFO - 2024-09-12 04:26:59 --> Controller Class Initialized
DEBUG - 2024-09-12 04:26:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 04:26:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 04:26:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 04:26:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 04:26:59 --> Final output sent to browser
DEBUG - 2024-09-12 04:26:59 --> Total execution time: 1.5285
INFO - 2024-09-12 04:51:55 --> Config Class Initialized
INFO - 2024-09-12 04:51:55 --> Hooks Class Initialized
DEBUG - 2024-09-12 04:51:55 --> UTF-8 Support Enabled
INFO - 2024-09-12 04:51:55 --> Utf8 Class Initialized
INFO - 2024-09-12 04:51:55 --> URI Class Initialized
DEBUG - 2024-09-12 04:51:55 --> No URI present. Default controller set.
INFO - 2024-09-12 04:51:55 --> Router Class Initialized
INFO - 2024-09-12 04:51:55 --> Output Class Initialized
INFO - 2024-09-12 04:51:55 --> Security Class Initialized
DEBUG - 2024-09-12 04:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 04:51:55 --> Input Class Initialized
INFO - 2024-09-12 04:51:55 --> Language Class Initialized
INFO - 2024-09-12 04:51:55 --> Loader Class Initialized
INFO - 2024-09-12 04:51:55 --> Helper loaded: url_helper
INFO - 2024-09-12 04:51:55 --> Helper loaded: file_helper
INFO - 2024-09-12 04:51:55 --> Helper loaded: security_helper
INFO - 2024-09-12 04:51:55 --> Helper loaded: wpu_helper
INFO - 2024-09-12 04:51:55 --> Database Driver Class Initialized
INFO - 2024-09-12 04:51:57 --> Email Class Initialized
DEBUG - 2024-09-12 04:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 04:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 04:51:57 --> Helper loaded: form_helper
INFO - 2024-09-12 04:51:57 --> Form Validation Class Initialized
INFO - 2024-09-12 04:51:57 --> Controller Class Initialized
DEBUG - 2024-09-12 04:51:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 04:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 04:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 04:51:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 04:51:57 --> Final output sent to browser
DEBUG - 2024-09-12 04:51:57 --> Total execution time: 1.4516
INFO - 2024-09-12 05:10:39 --> Config Class Initialized
INFO - 2024-09-12 05:10:39 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:10:39 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:10:39 --> Utf8 Class Initialized
INFO - 2024-09-12 05:10:39 --> URI Class Initialized
DEBUG - 2024-09-12 05:10:39 --> No URI present. Default controller set.
INFO - 2024-09-12 05:10:39 --> Router Class Initialized
INFO - 2024-09-12 05:10:39 --> Output Class Initialized
INFO - 2024-09-12 05:10:39 --> Security Class Initialized
DEBUG - 2024-09-12 05:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:10:39 --> Input Class Initialized
INFO - 2024-09-12 05:10:39 --> Language Class Initialized
INFO - 2024-09-12 05:10:39 --> Loader Class Initialized
INFO - 2024-09-12 05:10:39 --> Helper loaded: url_helper
INFO - 2024-09-12 05:10:39 --> Helper loaded: file_helper
INFO - 2024-09-12 05:10:39 --> Helper loaded: security_helper
INFO - 2024-09-12 05:10:39 --> Helper loaded: wpu_helper
INFO - 2024-09-12 05:10:39 --> Database Driver Class Initialized
INFO - 2024-09-12 05:10:40 --> Email Class Initialized
DEBUG - 2024-09-12 05:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 05:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:10:40 --> Helper loaded: form_helper
INFO - 2024-09-12 05:10:40 --> Form Validation Class Initialized
INFO - 2024-09-12 05:10:40 --> Controller Class Initialized
DEBUG - 2024-09-12 05:10:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 05:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 05:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 05:10:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 05:10:40 --> Final output sent to browser
DEBUG - 2024-09-12 05:10:40 --> Total execution time: 0.2432
INFO - 2024-09-12 05:20:26 --> Config Class Initialized
INFO - 2024-09-12 05:20:26 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:20:26 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:20:26 --> Utf8 Class Initialized
INFO - 2024-09-12 05:20:26 --> URI Class Initialized
DEBUG - 2024-09-12 05:20:26 --> No URI present. Default controller set.
INFO - 2024-09-12 05:20:26 --> Router Class Initialized
INFO - 2024-09-12 05:20:26 --> Output Class Initialized
INFO - 2024-09-12 05:20:26 --> Security Class Initialized
DEBUG - 2024-09-12 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:20:26 --> Input Class Initialized
INFO - 2024-09-12 05:20:26 --> Language Class Initialized
INFO - 2024-09-12 05:20:26 --> Loader Class Initialized
INFO - 2024-09-12 05:20:26 --> Helper loaded: url_helper
INFO - 2024-09-12 05:20:26 --> Helper loaded: file_helper
INFO - 2024-09-12 05:20:26 --> Helper loaded: security_helper
INFO - 2024-09-12 05:20:26 --> Helper loaded: wpu_helper
INFO - 2024-09-12 05:20:26 --> Database Driver Class Initialized
INFO - 2024-09-12 05:20:26 --> Email Class Initialized
DEBUG - 2024-09-12 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 05:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:20:26 --> Helper loaded: form_helper
INFO - 2024-09-12 05:20:26 --> Form Validation Class Initialized
INFO - 2024-09-12 05:20:26 --> Controller Class Initialized
DEBUG - 2024-09-12 05:20:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 05:20:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 05:20:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 05:20:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 05:20:26 --> Final output sent to browser
DEBUG - 2024-09-12 05:20:26 --> Total execution time: 0.2448
INFO - 2024-09-12 05:47:27 --> Config Class Initialized
INFO - 2024-09-12 05:47:27 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:47:27 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:47:27 --> Utf8 Class Initialized
INFO - 2024-09-12 05:47:27 --> URI Class Initialized
DEBUG - 2024-09-12 05:47:27 --> No URI present. Default controller set.
INFO - 2024-09-12 05:47:27 --> Router Class Initialized
INFO - 2024-09-12 05:47:27 --> Output Class Initialized
INFO - 2024-09-12 05:47:27 --> Security Class Initialized
DEBUG - 2024-09-12 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:47:27 --> Input Class Initialized
INFO - 2024-09-12 05:47:27 --> Language Class Initialized
INFO - 2024-09-12 05:47:27 --> Loader Class Initialized
INFO - 2024-09-12 05:47:27 --> Helper loaded: url_helper
INFO - 2024-09-12 05:47:27 --> Helper loaded: file_helper
INFO - 2024-09-12 05:47:27 --> Helper loaded: security_helper
INFO - 2024-09-12 05:47:27 --> Helper loaded: wpu_helper
INFO - 2024-09-12 05:47:27 --> Database Driver Class Initialized
INFO - 2024-09-12 05:47:27 --> Email Class Initialized
DEBUG - 2024-09-12 05:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:47:27 --> Helper loaded: form_helper
INFO - 2024-09-12 05:47:27 --> Form Validation Class Initialized
INFO - 2024-09-12 05:47:27 --> Controller Class Initialized
DEBUG - 2024-09-12 05:47:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 05:47:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 05:47:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 05:47:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 05:47:27 --> Final output sent to browser
DEBUG - 2024-09-12 05:47:27 --> Total execution time: 0.2288
INFO - 2024-09-12 06:21:07 --> Config Class Initialized
INFO - 2024-09-12 06:21:07 --> Hooks Class Initialized
DEBUG - 2024-09-12 06:21:07 --> UTF-8 Support Enabled
INFO - 2024-09-12 06:21:07 --> Utf8 Class Initialized
INFO - 2024-09-12 06:21:07 --> URI Class Initialized
DEBUG - 2024-09-12 06:21:07 --> No URI present. Default controller set.
INFO - 2024-09-12 06:21:07 --> Router Class Initialized
INFO - 2024-09-12 06:21:07 --> Output Class Initialized
INFO - 2024-09-12 06:21:07 --> Security Class Initialized
DEBUG - 2024-09-12 06:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 06:21:07 --> Input Class Initialized
INFO - 2024-09-12 06:21:07 --> Language Class Initialized
INFO - 2024-09-12 06:21:07 --> Loader Class Initialized
INFO - 2024-09-12 06:21:07 --> Helper loaded: url_helper
INFO - 2024-09-12 06:21:07 --> Helper loaded: file_helper
INFO - 2024-09-12 06:21:07 --> Helper loaded: security_helper
INFO - 2024-09-12 06:21:07 --> Helper loaded: wpu_helper
INFO - 2024-09-12 06:21:07 --> Database Driver Class Initialized
INFO - 2024-09-12 06:21:08 --> Email Class Initialized
DEBUG - 2024-09-12 06:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 06:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 06:21:08 --> Helper loaded: form_helper
INFO - 2024-09-12 06:21:08 --> Form Validation Class Initialized
INFO - 2024-09-12 06:21:08 --> Controller Class Initialized
DEBUG - 2024-09-12 06:21:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 06:21:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 06:21:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 06:21:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 06:21:08 --> Final output sent to browser
DEBUG - 2024-09-12 06:21:08 --> Total execution time: 1.2396
INFO - 2024-09-12 06:54:29 --> Config Class Initialized
INFO - 2024-09-12 06:54:29 --> Hooks Class Initialized
DEBUG - 2024-09-12 06:54:29 --> UTF-8 Support Enabled
INFO - 2024-09-12 06:54:29 --> Utf8 Class Initialized
INFO - 2024-09-12 06:54:29 --> URI Class Initialized
DEBUG - 2024-09-12 06:54:29 --> No URI present. Default controller set.
INFO - 2024-09-12 06:54:29 --> Router Class Initialized
INFO - 2024-09-12 06:54:29 --> Output Class Initialized
INFO - 2024-09-12 06:54:29 --> Security Class Initialized
DEBUG - 2024-09-12 06:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 06:54:29 --> Input Class Initialized
INFO - 2024-09-12 06:54:29 --> Language Class Initialized
INFO - 2024-09-12 06:54:29 --> Loader Class Initialized
INFO - 2024-09-12 06:54:29 --> Helper loaded: url_helper
INFO - 2024-09-12 06:54:29 --> Helper loaded: file_helper
INFO - 2024-09-12 06:54:29 --> Helper loaded: security_helper
INFO - 2024-09-12 06:54:29 --> Helper loaded: wpu_helper
INFO - 2024-09-12 06:54:29 --> Database Driver Class Initialized
INFO - 2024-09-12 06:54:30 --> Email Class Initialized
DEBUG - 2024-09-12 06:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 06:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 06:54:30 --> Helper loaded: form_helper
INFO - 2024-09-12 06:54:30 --> Form Validation Class Initialized
INFO - 2024-09-12 06:54:30 --> Controller Class Initialized
DEBUG - 2024-09-12 06:54:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 06:54:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 06:54:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 06:54:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 06:54:30 --> Final output sent to browser
DEBUG - 2024-09-12 06:54:30 --> Total execution time: 1.2467
INFO - 2024-09-12 07:11:29 --> Config Class Initialized
INFO - 2024-09-12 07:11:29 --> Hooks Class Initialized
DEBUG - 2024-09-12 07:11:29 --> UTF-8 Support Enabled
INFO - 2024-09-12 07:11:29 --> Utf8 Class Initialized
INFO - 2024-09-12 07:11:29 --> URI Class Initialized
DEBUG - 2024-09-12 07:11:29 --> No URI present. Default controller set.
INFO - 2024-09-12 07:11:29 --> Router Class Initialized
INFO - 2024-09-12 07:11:29 --> Output Class Initialized
INFO - 2024-09-12 07:11:29 --> Security Class Initialized
DEBUG - 2024-09-12 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 07:11:29 --> Input Class Initialized
INFO - 2024-09-12 07:11:29 --> Language Class Initialized
INFO - 2024-09-12 07:11:29 --> Loader Class Initialized
INFO - 2024-09-12 07:11:29 --> Helper loaded: url_helper
INFO - 2024-09-12 07:11:29 --> Helper loaded: file_helper
INFO - 2024-09-12 07:11:29 --> Helper loaded: security_helper
INFO - 2024-09-12 07:11:29 --> Helper loaded: wpu_helper
INFO - 2024-09-12 07:11:29 --> Database Driver Class Initialized
INFO - 2024-09-12 07:11:31 --> Email Class Initialized
DEBUG - 2024-09-12 07:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 07:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 07:11:31 --> Helper loaded: form_helper
INFO - 2024-09-12 07:11:31 --> Form Validation Class Initialized
INFO - 2024-09-12 07:11:31 --> Controller Class Initialized
DEBUG - 2024-09-12 07:11:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 07:11:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 07:11:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 07:11:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 07:11:31 --> Final output sent to browser
DEBUG - 2024-09-12 07:11:31 --> Total execution time: 2.7330
INFO - 2024-09-12 07:11:33 --> Config Class Initialized
INFO - 2024-09-12 07:11:33 --> Hooks Class Initialized
DEBUG - 2024-09-12 07:11:33 --> UTF-8 Support Enabled
INFO - 2024-09-12 07:11:33 --> Utf8 Class Initialized
INFO - 2024-09-12 07:11:33 --> URI Class Initialized
DEBUG - 2024-09-12 07:11:33 --> No URI present. Default controller set.
INFO - 2024-09-12 07:11:33 --> Router Class Initialized
INFO - 2024-09-12 07:11:33 --> Output Class Initialized
INFO - 2024-09-12 07:11:33 --> Security Class Initialized
DEBUG - 2024-09-12 07:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 07:11:33 --> Input Class Initialized
INFO - 2024-09-12 07:11:33 --> Language Class Initialized
INFO - 2024-09-12 07:11:33 --> Loader Class Initialized
INFO - 2024-09-12 07:11:33 --> Helper loaded: url_helper
INFO - 2024-09-12 07:11:33 --> Helper loaded: file_helper
INFO - 2024-09-12 07:11:33 --> Helper loaded: security_helper
INFO - 2024-09-12 07:11:33 --> Helper loaded: wpu_helper
INFO - 2024-09-12 07:11:33 --> Database Driver Class Initialized
INFO - 2024-09-12 07:11:34 --> Email Class Initialized
DEBUG - 2024-09-12 07:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 07:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 07:11:34 --> Helper loaded: form_helper
INFO - 2024-09-12 07:11:34 --> Form Validation Class Initialized
INFO - 2024-09-12 07:11:34 --> Controller Class Initialized
DEBUG - 2024-09-12 07:11:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 07:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 07:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 07:11:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 07:11:34 --> Final output sent to browser
DEBUG - 2024-09-12 07:11:34 --> Total execution time: 1.2608
INFO - 2024-09-12 07:24:08 --> Config Class Initialized
INFO - 2024-09-12 07:24:08 --> Hooks Class Initialized
DEBUG - 2024-09-12 07:24:08 --> UTF-8 Support Enabled
INFO - 2024-09-12 07:24:08 --> Utf8 Class Initialized
INFO - 2024-09-12 07:24:08 --> URI Class Initialized
DEBUG - 2024-09-12 07:24:08 --> No URI present. Default controller set.
INFO - 2024-09-12 07:24:08 --> Router Class Initialized
INFO - 2024-09-12 07:24:08 --> Output Class Initialized
INFO - 2024-09-12 07:24:08 --> Security Class Initialized
DEBUG - 2024-09-12 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 07:24:08 --> Input Class Initialized
INFO - 2024-09-12 07:24:08 --> Language Class Initialized
INFO - 2024-09-12 07:24:08 --> Loader Class Initialized
INFO - 2024-09-12 07:24:08 --> Helper loaded: url_helper
INFO - 2024-09-12 07:24:08 --> Helper loaded: file_helper
INFO - 2024-09-12 07:24:08 --> Helper loaded: security_helper
INFO - 2024-09-12 07:24:08 --> Helper loaded: wpu_helper
INFO - 2024-09-12 07:24:08 --> Database Driver Class Initialized
INFO - 2024-09-12 07:24:08 --> Email Class Initialized
DEBUG - 2024-09-12 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 07:24:08 --> Helper loaded: form_helper
INFO - 2024-09-12 07:24:08 --> Form Validation Class Initialized
INFO - 2024-09-12 07:24:08 --> Controller Class Initialized
DEBUG - 2024-09-12 07:24:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 07:24:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 07:24:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 07:24:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 07:24:08 --> Final output sent to browser
DEBUG - 2024-09-12 07:24:08 --> Total execution time: 0.2486
INFO - 2024-09-12 07:54:18 --> Config Class Initialized
INFO - 2024-09-12 07:54:18 --> Hooks Class Initialized
DEBUG - 2024-09-12 07:54:18 --> UTF-8 Support Enabled
INFO - 2024-09-12 07:54:18 --> Utf8 Class Initialized
INFO - 2024-09-12 07:54:18 --> URI Class Initialized
DEBUG - 2024-09-12 07:54:18 --> No URI present. Default controller set.
INFO - 2024-09-12 07:54:18 --> Router Class Initialized
INFO - 2024-09-12 07:54:18 --> Output Class Initialized
INFO - 2024-09-12 07:54:18 --> Security Class Initialized
DEBUG - 2024-09-12 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 07:54:18 --> Input Class Initialized
INFO - 2024-09-12 07:54:18 --> Language Class Initialized
INFO - 2024-09-12 07:54:18 --> Loader Class Initialized
INFO - 2024-09-12 07:54:18 --> Helper loaded: url_helper
INFO - 2024-09-12 07:54:18 --> Helper loaded: file_helper
INFO - 2024-09-12 07:54:18 --> Helper loaded: security_helper
INFO - 2024-09-12 07:54:18 --> Helper loaded: wpu_helper
INFO - 2024-09-12 07:54:18 --> Database Driver Class Initialized
INFO - 2024-09-12 07:54:18 --> Email Class Initialized
DEBUG - 2024-09-12 07:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 07:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 07:54:18 --> Helper loaded: form_helper
INFO - 2024-09-12 07:54:18 --> Form Validation Class Initialized
INFO - 2024-09-12 07:54:18 --> Controller Class Initialized
DEBUG - 2024-09-12 07:54:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 07:54:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 07:54:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 07:54:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 07:54:18 --> Final output sent to browser
DEBUG - 2024-09-12 07:54:18 --> Total execution time: 0.2256
INFO - 2024-09-12 08:17:58 --> Config Class Initialized
INFO - 2024-09-12 08:17:58 --> Hooks Class Initialized
DEBUG - 2024-09-12 08:17:58 --> UTF-8 Support Enabled
INFO - 2024-09-12 08:17:58 --> Utf8 Class Initialized
INFO - 2024-09-12 08:17:58 --> URI Class Initialized
DEBUG - 2024-09-12 08:17:58 --> No URI present. Default controller set.
INFO - 2024-09-12 08:17:58 --> Router Class Initialized
INFO - 2024-09-12 08:17:58 --> Output Class Initialized
INFO - 2024-09-12 08:17:58 --> Security Class Initialized
DEBUG - 2024-09-12 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 08:17:58 --> Input Class Initialized
INFO - 2024-09-12 08:17:58 --> Language Class Initialized
INFO - 2024-09-12 08:17:58 --> Loader Class Initialized
INFO - 2024-09-12 08:17:58 --> Helper loaded: url_helper
INFO - 2024-09-12 08:17:58 --> Helper loaded: file_helper
INFO - 2024-09-12 08:17:58 --> Helper loaded: security_helper
INFO - 2024-09-12 08:17:58 --> Helper loaded: wpu_helper
INFO - 2024-09-12 08:17:58 --> Database Driver Class Initialized
INFO - 2024-09-12 08:17:58 --> Email Class Initialized
DEBUG - 2024-09-12 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 08:17:58 --> Helper loaded: form_helper
INFO - 2024-09-12 08:17:58 --> Form Validation Class Initialized
INFO - 2024-09-12 08:17:58 --> Controller Class Initialized
DEBUG - 2024-09-12 08:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 08:17:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 08:17:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 08:17:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 08:17:58 --> Final output sent to browser
DEBUG - 2024-09-12 08:17:58 --> Total execution time: 0.2506
INFO - 2024-09-12 08:53:17 --> Config Class Initialized
INFO - 2024-09-12 08:53:17 --> Hooks Class Initialized
DEBUG - 2024-09-12 08:53:17 --> UTF-8 Support Enabled
INFO - 2024-09-12 08:53:17 --> Utf8 Class Initialized
INFO - 2024-09-12 08:53:17 --> URI Class Initialized
DEBUG - 2024-09-12 08:53:17 --> No URI present. Default controller set.
INFO - 2024-09-12 08:53:17 --> Router Class Initialized
INFO - 2024-09-12 08:53:17 --> Output Class Initialized
INFO - 2024-09-12 08:53:17 --> Security Class Initialized
DEBUG - 2024-09-12 08:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 08:53:17 --> Input Class Initialized
INFO - 2024-09-12 08:53:17 --> Language Class Initialized
INFO - 2024-09-12 08:53:17 --> Loader Class Initialized
INFO - 2024-09-12 08:53:17 --> Helper loaded: url_helper
INFO - 2024-09-12 08:53:17 --> Helper loaded: file_helper
INFO - 2024-09-12 08:53:17 --> Helper loaded: security_helper
INFO - 2024-09-12 08:53:17 --> Helper loaded: wpu_helper
INFO - 2024-09-12 08:53:17 --> Database Driver Class Initialized
INFO - 2024-09-12 08:53:18 --> Email Class Initialized
DEBUG - 2024-09-12 08:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 08:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 08:53:18 --> Helper loaded: form_helper
INFO - 2024-09-12 08:53:18 --> Form Validation Class Initialized
INFO - 2024-09-12 08:53:18 --> Controller Class Initialized
DEBUG - 2024-09-12 08:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 08:53:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 08:53:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 08:53:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 08:53:18 --> Final output sent to browser
DEBUG - 2024-09-12 08:53:18 --> Total execution time: 1.2264
INFO - 2024-09-12 09:21:28 --> Config Class Initialized
INFO - 2024-09-12 09:21:28 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:28 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:28 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:28 --> URI Class Initialized
DEBUG - 2024-09-12 09:21:28 --> No URI present. Default controller set.
INFO - 2024-09-12 09:21:28 --> Router Class Initialized
INFO - 2024-09-12 09:21:28 --> Output Class Initialized
INFO - 2024-09-12 09:21:28 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:28 --> Input Class Initialized
INFO - 2024-09-12 09:21:28 --> Language Class Initialized
INFO - 2024-09-12 09:21:28 --> Loader Class Initialized
INFO - 2024-09-12 09:21:28 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:28 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:28 --> Helper loaded: security_helper
INFO - 2024-09-12 09:21:28 --> Helper loaded: wpu_helper
INFO - 2024-09-12 09:21:28 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:28 --> Email Class Initialized
DEBUG - 2024-09-12 09:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 09:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:28 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:28 --> Form Validation Class Initialized
INFO - 2024-09-12 09:21:28 --> Controller Class Initialized
DEBUG - 2024-09-12 09:21:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 09:21:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 09:21:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 09:21:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 09:21:28 --> Final output sent to browser
DEBUG - 2024-09-12 09:21:28 --> Total execution time: 0.2737
INFO - 2024-09-12 09:54:06 --> Config Class Initialized
INFO - 2024-09-12 09:54:06 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:54:06 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:54:06 --> Utf8 Class Initialized
INFO - 2024-09-12 09:54:06 --> URI Class Initialized
DEBUG - 2024-09-12 09:54:06 --> No URI present. Default controller set.
INFO - 2024-09-12 09:54:06 --> Router Class Initialized
INFO - 2024-09-12 09:54:06 --> Output Class Initialized
INFO - 2024-09-12 09:54:06 --> Security Class Initialized
DEBUG - 2024-09-12 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:54:06 --> Input Class Initialized
INFO - 2024-09-12 09:54:06 --> Language Class Initialized
INFO - 2024-09-12 09:54:06 --> Loader Class Initialized
INFO - 2024-09-12 09:54:06 --> Helper loaded: url_helper
INFO - 2024-09-12 09:54:06 --> Helper loaded: file_helper
INFO - 2024-09-12 09:54:06 --> Helper loaded: security_helper
INFO - 2024-09-12 09:54:06 --> Helper loaded: wpu_helper
INFO - 2024-09-12 09:54:06 --> Database Driver Class Initialized
INFO - 2024-09-12 09:54:08 --> Email Class Initialized
DEBUG - 2024-09-12 09:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 09:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:54:08 --> Helper loaded: form_helper
INFO - 2024-09-12 09:54:08 --> Form Validation Class Initialized
INFO - 2024-09-12 09:54:08 --> Controller Class Initialized
DEBUG - 2024-09-12 09:54:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 09:54:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 09:54:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 09:54:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 09:54:08 --> Final output sent to browser
DEBUG - 2024-09-12 09:54:08 --> Total execution time: 1.4519
INFO - 2024-09-12 10:26:52 --> Config Class Initialized
INFO - 2024-09-12 10:26:52 --> Hooks Class Initialized
DEBUG - 2024-09-12 10:26:52 --> UTF-8 Support Enabled
INFO - 2024-09-12 10:26:52 --> Utf8 Class Initialized
INFO - 2024-09-12 10:26:52 --> URI Class Initialized
DEBUG - 2024-09-12 10:26:52 --> No URI present. Default controller set.
INFO - 2024-09-12 10:26:52 --> Router Class Initialized
INFO - 2024-09-12 10:26:52 --> Output Class Initialized
INFO - 2024-09-12 10:26:52 --> Security Class Initialized
DEBUG - 2024-09-12 10:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 10:26:52 --> Input Class Initialized
INFO - 2024-09-12 10:26:52 --> Language Class Initialized
INFO - 2024-09-12 10:26:52 --> Loader Class Initialized
INFO - 2024-09-12 10:26:52 --> Helper loaded: url_helper
INFO - 2024-09-12 10:26:52 --> Helper loaded: file_helper
INFO - 2024-09-12 10:26:52 --> Helper loaded: security_helper
INFO - 2024-09-12 10:26:52 --> Helper loaded: wpu_helper
INFO - 2024-09-12 10:26:52 --> Database Driver Class Initialized
INFO - 2024-09-12 10:26:52 --> Email Class Initialized
DEBUG - 2024-09-12 10:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 10:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 10:26:52 --> Helper loaded: form_helper
INFO - 2024-09-12 10:26:52 --> Form Validation Class Initialized
INFO - 2024-09-12 10:26:52 --> Controller Class Initialized
DEBUG - 2024-09-12 10:26:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 10:26:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 10:26:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 10:26:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 10:26:52 --> Final output sent to browser
DEBUG - 2024-09-12 10:26:52 --> Total execution time: 0.4330
INFO - 2024-09-12 10:50:17 --> Config Class Initialized
INFO - 2024-09-12 10:50:17 --> Hooks Class Initialized
DEBUG - 2024-09-12 10:50:17 --> UTF-8 Support Enabled
INFO - 2024-09-12 10:50:17 --> Utf8 Class Initialized
INFO - 2024-09-12 10:50:17 --> URI Class Initialized
DEBUG - 2024-09-12 10:50:17 --> No URI present. Default controller set.
INFO - 2024-09-12 10:50:17 --> Router Class Initialized
INFO - 2024-09-12 10:50:17 --> Output Class Initialized
INFO - 2024-09-12 10:50:17 --> Security Class Initialized
DEBUG - 2024-09-12 10:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 10:50:17 --> Input Class Initialized
INFO - 2024-09-12 10:50:17 --> Language Class Initialized
INFO - 2024-09-12 10:50:17 --> Loader Class Initialized
INFO - 2024-09-12 10:50:17 --> Helper loaded: url_helper
INFO - 2024-09-12 10:50:17 --> Helper loaded: file_helper
INFO - 2024-09-12 10:50:17 --> Helper loaded: security_helper
INFO - 2024-09-12 10:50:17 --> Helper loaded: wpu_helper
INFO - 2024-09-12 10:50:17 --> Database Driver Class Initialized
INFO - 2024-09-12 10:50:18 --> Email Class Initialized
DEBUG - 2024-09-12 10:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 10:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 10:50:18 --> Helper loaded: form_helper
INFO - 2024-09-12 10:50:18 --> Form Validation Class Initialized
INFO - 2024-09-12 10:50:18 --> Controller Class Initialized
DEBUG - 2024-09-12 10:50:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 10:50:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 10:50:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 10:50:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 10:50:18 --> Final output sent to browser
DEBUG - 2024-09-12 10:50:18 --> Total execution time: 0.2547
INFO - 2024-09-12 11:21:11 --> Config Class Initialized
INFO - 2024-09-12 11:21:11 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:21:11 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:21:11 --> Utf8 Class Initialized
INFO - 2024-09-12 11:21:11 --> URI Class Initialized
DEBUG - 2024-09-12 11:21:11 --> No URI present. Default controller set.
INFO - 2024-09-12 11:21:11 --> Router Class Initialized
INFO - 2024-09-12 11:21:11 --> Output Class Initialized
INFO - 2024-09-12 11:21:11 --> Security Class Initialized
DEBUG - 2024-09-12 11:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:21:11 --> Input Class Initialized
INFO - 2024-09-12 11:21:11 --> Language Class Initialized
INFO - 2024-09-12 11:21:11 --> Loader Class Initialized
INFO - 2024-09-12 11:21:11 --> Helper loaded: url_helper
INFO - 2024-09-12 11:21:11 --> Helper loaded: file_helper
INFO - 2024-09-12 11:21:11 --> Helper loaded: security_helper
INFO - 2024-09-12 11:21:11 --> Helper loaded: wpu_helper
INFO - 2024-09-12 11:21:11 --> Database Driver Class Initialized
INFO - 2024-09-12 11:21:13 --> Email Class Initialized
DEBUG - 2024-09-12 11:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 11:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:21:13 --> Helper loaded: form_helper
INFO - 2024-09-12 11:21:13 --> Form Validation Class Initialized
INFO - 2024-09-12 11:21:13 --> Controller Class Initialized
DEBUG - 2024-09-12 11:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 11:21:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 11:21:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 11:21:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 11:21:13 --> Final output sent to browser
DEBUG - 2024-09-12 11:21:13 --> Total execution time: 1.2935
INFO - 2024-09-12 11:53:34 --> Config Class Initialized
INFO - 2024-09-12 11:53:34 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:53:34 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:53:34 --> Utf8 Class Initialized
INFO - 2024-09-12 11:53:34 --> URI Class Initialized
DEBUG - 2024-09-12 11:53:34 --> No URI present. Default controller set.
INFO - 2024-09-12 11:53:34 --> Router Class Initialized
INFO - 2024-09-12 11:53:34 --> Output Class Initialized
INFO - 2024-09-12 11:53:34 --> Security Class Initialized
DEBUG - 2024-09-12 11:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:53:34 --> Input Class Initialized
INFO - 2024-09-12 11:53:34 --> Language Class Initialized
INFO - 2024-09-12 11:53:34 --> Loader Class Initialized
INFO - 2024-09-12 11:53:34 --> Helper loaded: url_helper
INFO - 2024-09-12 11:53:34 --> Helper loaded: file_helper
INFO - 2024-09-12 11:53:34 --> Helper loaded: security_helper
INFO - 2024-09-12 11:53:34 --> Helper loaded: wpu_helper
INFO - 2024-09-12 11:53:34 --> Database Driver Class Initialized
INFO - 2024-09-12 11:53:34 --> Email Class Initialized
DEBUG - 2024-09-12 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 11:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:53:34 --> Helper loaded: form_helper
INFO - 2024-09-12 11:53:34 --> Form Validation Class Initialized
INFO - 2024-09-12 11:53:34 --> Controller Class Initialized
DEBUG - 2024-09-12 11:53:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 11:53:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 11:53:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 11:53:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 11:53:34 --> Final output sent to browser
DEBUG - 2024-09-12 11:53:34 --> Total execution time: 0.2450
INFO - 2024-09-12 12:19:38 --> Config Class Initialized
INFO - 2024-09-12 12:19:38 --> Hooks Class Initialized
DEBUG - 2024-09-12 12:19:38 --> UTF-8 Support Enabled
INFO - 2024-09-12 12:19:38 --> Utf8 Class Initialized
INFO - 2024-09-12 12:19:38 --> URI Class Initialized
DEBUG - 2024-09-12 12:19:38 --> No URI present. Default controller set.
INFO - 2024-09-12 12:19:38 --> Router Class Initialized
INFO - 2024-09-12 12:19:38 --> Output Class Initialized
INFO - 2024-09-12 12:19:38 --> Security Class Initialized
DEBUG - 2024-09-12 12:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 12:19:38 --> Input Class Initialized
INFO - 2024-09-12 12:19:38 --> Language Class Initialized
INFO - 2024-09-12 12:19:38 --> Loader Class Initialized
INFO - 2024-09-12 12:19:38 --> Helper loaded: url_helper
INFO - 2024-09-12 12:19:38 --> Helper loaded: file_helper
INFO - 2024-09-12 12:19:38 --> Helper loaded: security_helper
INFO - 2024-09-12 12:19:38 --> Helper loaded: wpu_helper
INFO - 2024-09-12 12:19:38 --> Database Driver Class Initialized
INFO - 2024-09-12 12:19:41 --> Email Class Initialized
DEBUG - 2024-09-12 12:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-12 12:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 12:19:41 --> Helper loaded: form_helper
INFO - 2024-09-12 12:19:41 --> Form Validation Class Initialized
INFO - 2024-09-12 12:19:41 --> Controller Class Initialized
DEBUG - 2024-09-12 12:19:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-12 12:19:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-12 12:19:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-12 12:19:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-12 12:19:41 --> Final output sent to browser
DEBUG - 2024-09-12 12:19:41 --> Total execution time: 3.1933
INFO - 2024-09-12 12:50:53 --> Config Class Initialized
INFO - 2024-09-12 12:50:53 --> Hooks Class Initialized
DEBUG - 2024-09-12 12:50:53 --> UTF-8 Support Enabled
INFO - 2024-09-12 12:50:53 --> Utf8 Class Initialized
INFO - 2024-09-12 12:50:53 --> URI Class Initialized
DEBUG - 2024-09-12 12:50:53 --> No URI present. Default controller set.
INFO - 2024-09-12 12:50:53 --> Router Class Initialized
INFO - 2024-09-12 12:50:53 --> Output Class Initialized
INFO - 2024-09-12 12:50:53 --> Security Class Initialized
DEBUG - 2024-09-12 12:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 12:50:53 --> Input Class Initialized
INFO - 2024-09-12 12:50:53 --> Language Class Initialized
INFO - 2024-09-12 12:50:53 --> Loader Class Initialized
INFO - 2024-09-12 12:50:53 --> Helper loaded: url_helper
INFO - 2024-09-12 12:50:53 --> Helper loaded: file_helper
INFO - 2024-09-12 12:50:53 --> Helper loaded: security_helper
INFO - 2024-09-12 12:50:53 --> Helper loaded: wpu_helper
INFO - 2024-09-12 12:50:53 --> Database Driver Class Initialized
ERROR - 2024-09-12 12:51:00 --> Unable to connect to the database
INFO - 2024-09-12 12:51:00 --> Language file loaded: language/english/db_lang.php
