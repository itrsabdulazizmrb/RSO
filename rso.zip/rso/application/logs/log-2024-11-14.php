<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-14 08:14:07 --> Config Class Initialized
INFO - 2024-11-14 08:14:07 --> Hooks Class Initialized
DEBUG - 2024-11-14 08:14:07 --> UTF-8 Support Enabled
INFO - 2024-11-14 08:14:07 --> Utf8 Class Initialized
INFO - 2024-11-14 08:14:07 --> URI Class Initialized
DEBUG - 2024-11-14 08:14:07 --> No URI present. Default controller set.
INFO - 2024-11-14 08:14:07 --> Router Class Initialized
INFO - 2024-11-14 08:14:07 --> Output Class Initialized
INFO - 2024-11-14 08:14:07 --> Security Class Initialized
DEBUG - 2024-11-14 08:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 08:14:07 --> Input Class Initialized
INFO - 2024-11-14 08:14:07 --> Language Class Initialized
INFO - 2024-11-14 08:14:07 --> Loader Class Initialized
INFO - 2024-11-14 08:14:07 --> Helper loaded: url_helper
INFO - 2024-11-14 08:14:07 --> Helper loaded: file_helper
INFO - 2024-11-14 08:14:07 --> Helper loaded: security_helper
INFO - 2024-11-14 08:14:07 --> Helper loaded: wpu_helper
INFO - 2024-11-14 08:14:07 --> Database Driver Class Initialized
INFO - 2024-11-14 08:14:08 --> Email Class Initialized
DEBUG - 2024-11-14 08:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-14 08:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 08:14:08 --> Helper loaded: form_helper
INFO - 2024-11-14 08:14:08 --> Form Validation Class Initialized
INFO - 2024-11-14 08:14:08 --> Controller Class Initialized
DEBUG - 2024-11-14 08:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-14 08:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-14 08:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-14 08:14:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-14 08:14:08 --> Final output sent to browser
DEBUG - 2024-11-14 08:14:08 --> Total execution time: 0.4711
INFO - 2024-11-14 22:44:10 --> Config Class Initialized
INFO - 2024-11-14 22:44:10 --> Hooks Class Initialized
DEBUG - 2024-11-14 22:44:10 --> UTF-8 Support Enabled
INFO - 2024-11-14 22:44:10 --> Utf8 Class Initialized
INFO - 2024-11-14 22:44:10 --> URI Class Initialized
DEBUG - 2024-11-14 22:44:10 --> No URI present. Default controller set.
INFO - 2024-11-14 22:44:10 --> Router Class Initialized
INFO - 2024-11-14 22:44:10 --> Output Class Initialized
INFO - 2024-11-14 22:44:10 --> Security Class Initialized
DEBUG - 2024-11-14 22:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 22:44:10 --> Input Class Initialized
INFO - 2024-11-14 22:44:10 --> Language Class Initialized
INFO - 2024-11-14 22:44:10 --> Loader Class Initialized
INFO - 2024-11-14 22:44:10 --> Helper loaded: url_helper
INFO - 2024-11-14 22:44:10 --> Helper loaded: file_helper
INFO - 2024-11-14 22:44:10 --> Helper loaded: security_helper
INFO - 2024-11-14 22:44:10 --> Helper loaded: wpu_helper
INFO - 2024-11-14 22:44:10 --> Database Driver Class Initialized
INFO - 2024-11-14 22:44:11 --> Email Class Initialized
DEBUG - 2024-11-14 22:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-14 22:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 22:44:11 --> Helper loaded: form_helper
INFO - 2024-11-14 22:44:11 --> Form Validation Class Initialized
INFO - 2024-11-14 22:44:11 --> Controller Class Initialized
DEBUG - 2024-11-14 22:44:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-14 22:44:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-14 22:44:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-14 22:44:11 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-14 22:44:11 --> Final output sent to browser
DEBUG - 2024-11-14 22:44:11 --> Total execution time: 0.4164
INFO - 2024-11-14 22:50:22 --> Config Class Initialized
INFO - 2024-11-14 22:50:22 --> Hooks Class Initialized
DEBUG - 2024-11-14 22:50:22 --> UTF-8 Support Enabled
INFO - 2024-11-14 22:50:22 --> Utf8 Class Initialized
INFO - 2024-11-14 22:50:22 --> URI Class Initialized
DEBUG - 2024-11-14 22:50:22 --> No URI present. Default controller set.
INFO - 2024-11-14 22:50:22 --> Router Class Initialized
INFO - 2024-11-14 22:50:22 --> Output Class Initialized
INFO - 2024-11-14 22:50:22 --> Security Class Initialized
DEBUG - 2024-11-14 22:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 22:50:22 --> Input Class Initialized
INFO - 2024-11-14 22:50:22 --> Language Class Initialized
INFO - 2024-11-14 22:50:22 --> Loader Class Initialized
INFO - 2024-11-14 22:50:22 --> Helper loaded: url_helper
INFO - 2024-11-14 22:50:22 --> Helper loaded: file_helper
INFO - 2024-11-14 22:50:22 --> Helper loaded: security_helper
INFO - 2024-11-14 22:50:22 --> Helper loaded: wpu_helper
INFO - 2024-11-14 22:50:22 --> Database Driver Class Initialized
INFO - 2024-11-14 22:50:23 --> Email Class Initialized
DEBUG - 2024-11-14 22:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-14 22:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 22:50:23 --> Helper loaded: form_helper
INFO - 2024-11-14 22:50:23 --> Form Validation Class Initialized
INFO - 2024-11-14 22:50:23 --> Controller Class Initialized
DEBUG - 2024-11-14 22:50:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-14 22:50:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-14 22:50:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-14 22:50:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-14 22:50:23 --> Final output sent to browser
DEBUG - 2024-11-14 22:50:23 --> Total execution time: 0.4413
INFO - 2024-11-14 22:50:24 --> Config Class Initialized
INFO - 2024-11-14 22:50:24 --> Hooks Class Initialized
DEBUG - 2024-11-14 22:50:24 --> UTF-8 Support Enabled
INFO - 2024-11-14 22:50:24 --> Utf8 Class Initialized
INFO - 2024-11-14 22:50:24 --> URI Class Initialized
INFO - 2024-11-14 22:50:24 --> Router Class Initialized
INFO - 2024-11-14 22:50:24 --> Output Class Initialized
INFO - 2024-11-14 22:50:24 --> Security Class Initialized
DEBUG - 2024-11-14 22:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 22:50:24 --> Input Class Initialized
INFO - 2024-11-14 22:50:24 --> Language Class Initialized
INFO - 2024-11-14 22:50:24 --> Loader Class Initialized
INFO - 2024-11-14 22:50:24 --> Helper loaded: url_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: file_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: security_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: wpu_helper
INFO - 2024-11-14 22:50:24 --> Database Driver Class Initialized
INFO - 2024-11-14 22:50:24 --> Email Class Initialized
DEBUG - 2024-11-14 22:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-14 22:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 22:50:24 --> Helper loaded: form_helper
INFO - 2024-11-14 22:50:24 --> Form Validation Class Initialized
INFO - 2024-11-14 22:50:24 --> Controller Class Initialized
DEBUG - 2024-11-14 22:50:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-14 22:50:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-11-14 22:50:24 --> Config Class Initialized
INFO - 2024-11-14 22:50:24 --> Hooks Class Initialized
DEBUG - 2024-11-14 22:50:24 --> UTF-8 Support Enabled
INFO - 2024-11-14 22:50:24 --> Utf8 Class Initialized
INFO - 2024-11-14 22:50:24 --> URI Class Initialized
INFO - 2024-11-14 22:50:24 --> Router Class Initialized
INFO - 2024-11-14 22:50:24 --> Output Class Initialized
INFO - 2024-11-14 22:50:24 --> Security Class Initialized
DEBUG - 2024-11-14 22:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 22:50:24 --> Input Class Initialized
INFO - 2024-11-14 22:50:24 --> Language Class Initialized
INFO - 2024-11-14 22:50:24 --> Loader Class Initialized
INFO - 2024-11-14 22:50:24 --> Helper loaded: url_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: file_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: security_helper
INFO - 2024-11-14 22:50:24 --> Helper loaded: wpu_helper
INFO - 2024-11-14 22:50:24 --> Database Driver Class Initialized
INFO - 2024-11-14 22:50:25 --> Email Class Initialized
DEBUG - 2024-11-14 22:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-14 22:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 22:50:25 --> Helper loaded: form_helper
INFO - 2024-11-14 22:50:25 --> Form Validation Class Initialized
INFO - 2024-11-14 22:50:25 --> Controller Class Initialized
INFO - 2024-11-14 22:50:25 --> Model "Antrol_model" initialized
DEBUG - 2024-11-14 22:50:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-14 22:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-11-14 22:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-11-14 22:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-11-14 22:50:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-11-14 22:50:25 --> Final output sent to browser
DEBUG - 2024-11-14 22:50:25 --> Total execution time: 1.0838
