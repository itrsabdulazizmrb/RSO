<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-02 00:23:21 --> Config Class Initialized
INFO - 2024-11-02 00:23:21 --> Hooks Class Initialized
DEBUG - 2024-11-02 00:23:21 --> UTF-8 Support Enabled
INFO - 2024-11-02 00:23:21 --> Utf8 Class Initialized
INFO - 2024-11-02 00:23:21 --> URI Class Initialized
DEBUG - 2024-11-02 00:23:21 --> No URI present. Default controller set.
INFO - 2024-11-02 00:23:21 --> Router Class Initialized
INFO - 2024-11-02 00:23:21 --> Output Class Initialized
INFO - 2024-11-02 00:23:21 --> Security Class Initialized
DEBUG - 2024-11-02 00:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 00:23:21 --> Input Class Initialized
INFO - 2024-11-02 00:23:21 --> Language Class Initialized
INFO - 2024-11-02 00:23:21 --> Loader Class Initialized
INFO - 2024-11-02 00:23:21 --> Helper loaded: url_helper
INFO - 2024-11-02 00:23:21 --> Helper loaded: file_helper
INFO - 2024-11-02 00:23:21 --> Helper loaded: security_helper
INFO - 2024-11-02 00:23:21 --> Helper loaded: wpu_helper
INFO - 2024-11-02 00:23:21 --> Database Driver Class Initialized
ERROR - 2024-11-02 00:23:28 --> Unable to connect to the database
INFO - 2024-11-02 00:23:28 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-02 00:23:37 --> Config Class Initialized
INFO - 2024-11-02 00:23:37 --> Hooks Class Initialized
DEBUG - 2024-11-02 00:23:37 --> UTF-8 Support Enabled
INFO - 2024-11-02 00:23:37 --> Utf8 Class Initialized
INFO - 2024-11-02 00:23:37 --> URI Class Initialized
INFO - 2024-11-02 00:23:37 --> Router Class Initialized
INFO - 2024-11-02 00:23:37 --> Output Class Initialized
INFO - 2024-11-02 00:23:37 --> Security Class Initialized
DEBUG - 2024-11-02 00:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 00:23:37 --> Input Class Initialized
INFO - 2024-11-02 00:23:37 --> Language Class Initialized
ERROR - 2024-11-02 00:23:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-02 00:23:38 --> Config Class Initialized
INFO - 2024-11-02 00:23:38 --> Hooks Class Initialized
DEBUG - 2024-11-02 00:23:38 --> UTF-8 Support Enabled
INFO - 2024-11-02 00:23:38 --> Utf8 Class Initialized
INFO - 2024-11-02 00:23:38 --> URI Class Initialized
INFO - 2024-11-02 00:23:38 --> Router Class Initialized
INFO - 2024-11-02 00:23:38 --> Output Class Initialized
INFO - 2024-11-02 00:23:38 --> Security Class Initialized
DEBUG - 2024-11-02 00:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 00:23:38 --> Input Class Initialized
INFO - 2024-11-02 00:23:38 --> Language Class Initialized
ERROR - 2024-11-02 00:23:38 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-11-02 08:29:54 --> Config Class Initialized
INFO - 2024-11-02 08:29:54 --> Hooks Class Initialized
DEBUG - 2024-11-02 08:29:54 --> UTF-8 Support Enabled
INFO - 2024-11-02 08:29:54 --> Utf8 Class Initialized
INFO - 2024-11-02 08:29:54 --> URI Class Initialized
DEBUG - 2024-11-02 08:29:54 --> No URI present. Default controller set.
INFO - 2024-11-02 08:29:54 --> Router Class Initialized
INFO - 2024-11-02 08:29:54 --> Output Class Initialized
INFO - 2024-11-02 08:29:54 --> Security Class Initialized
DEBUG - 2024-11-02 08:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 08:29:54 --> Input Class Initialized
INFO - 2024-11-02 08:29:54 --> Language Class Initialized
INFO - 2024-11-02 08:29:54 --> Loader Class Initialized
INFO - 2024-11-02 08:29:54 --> Helper loaded: url_helper
INFO - 2024-11-02 08:29:54 --> Helper loaded: file_helper
INFO - 2024-11-02 08:29:54 --> Helper loaded: security_helper
INFO - 2024-11-02 08:29:54 --> Helper loaded: wpu_helper
INFO - 2024-11-02 08:29:54 --> Database Driver Class Initialized
ERROR - 2024-11-02 08:30:01 --> Unable to connect to the database
INFO - 2024-11-02 08:30:01 --> Language file loaded: language/english/db_lang.php
