<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-07 05:36:42 --> Config Class Initialized
INFO - 2024-12-07 05:36:42 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:36:42 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:36:42 --> Utf8 Class Initialized
INFO - 2024-12-07 05:36:42 --> URI Class Initialized
DEBUG - 2024-12-07 05:36:42 --> No URI present. Default controller set.
INFO - 2024-12-07 05:36:42 --> Router Class Initialized
INFO - 2024-12-07 05:36:42 --> Output Class Initialized
INFO - 2024-12-07 05:36:42 --> Security Class Initialized
DEBUG - 2024-12-07 05:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:36:42 --> Input Class Initialized
INFO - 2024-12-07 05:36:42 --> Language Class Initialized
INFO - 2024-12-07 05:36:42 --> Loader Class Initialized
INFO - 2024-12-07 05:36:42 --> Helper loaded: url_helper
INFO - 2024-12-07 05:36:42 --> Helper loaded: file_helper
INFO - 2024-12-07 05:36:42 --> Helper loaded: security_helper
INFO - 2024-12-07 05:36:42 --> Helper loaded: wpu_helper
INFO - 2024-12-07 05:36:42 --> Database Driver Class Initialized
INFO - 2024-12-07 05:36:42 --> Email Class Initialized
DEBUG - 2024-12-07 05:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 05:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 05:36:42 --> Helper loaded: form_helper
INFO - 2024-12-07 05:36:42 --> Form Validation Class Initialized
INFO - 2024-12-07 05:36:42 --> Controller Class Initialized
DEBUG - 2024-12-07 05:36:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-07 05:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-07 05:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-07 05:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-07 05:36:42 --> Final output sent to browser
DEBUG - 2024-12-07 05:36:42 --> Total execution time: 0.4353
INFO - 2024-12-07 06:29:48 --> Config Class Initialized
INFO - 2024-12-07 06:29:48 --> Hooks Class Initialized
DEBUG - 2024-12-07 06:29:48 --> UTF-8 Support Enabled
INFO - 2024-12-07 06:29:48 --> Utf8 Class Initialized
INFO - 2024-12-07 06:29:48 --> URI Class Initialized
DEBUG - 2024-12-07 06:29:48 --> No URI present. Default controller set.
INFO - 2024-12-07 06:29:48 --> Router Class Initialized
INFO - 2024-12-07 06:29:48 --> Output Class Initialized
INFO - 2024-12-07 06:29:48 --> Security Class Initialized
DEBUG - 2024-12-07 06:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 06:29:48 --> Input Class Initialized
INFO - 2024-12-07 06:29:48 --> Language Class Initialized
INFO - 2024-12-07 06:29:48 --> Loader Class Initialized
INFO - 2024-12-07 06:29:48 --> Helper loaded: url_helper
INFO - 2024-12-07 06:29:48 --> Helper loaded: file_helper
INFO - 2024-12-07 06:29:48 --> Helper loaded: security_helper
INFO - 2024-12-07 06:29:48 --> Helper loaded: wpu_helper
INFO - 2024-12-07 06:29:48 --> Database Driver Class Initialized
INFO - 2024-12-07 06:29:48 --> Email Class Initialized
DEBUG - 2024-12-07 06:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 06:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 06:29:48 --> Helper loaded: form_helper
INFO - 2024-12-07 06:29:48 --> Form Validation Class Initialized
INFO - 2024-12-07 06:29:48 --> Controller Class Initialized
DEBUG - 2024-12-07 06:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-07 06:29:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-07 06:29:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-07 06:29:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-07 06:29:48 --> Final output sent to browser
DEBUG - 2024-12-07 06:29:48 --> Total execution time: 0.4140
INFO - 2024-12-07 06:29:49 --> Config Class Initialized
INFO - 2024-12-07 06:29:49 --> Hooks Class Initialized
DEBUG - 2024-12-07 06:29:49 --> UTF-8 Support Enabled
INFO - 2024-12-07 06:29:49 --> Utf8 Class Initialized
INFO - 2024-12-07 06:29:49 --> URI Class Initialized
DEBUG - 2024-12-07 06:29:49 --> No URI present. Default controller set.
INFO - 2024-12-07 06:29:49 --> Router Class Initialized
INFO - 2024-12-07 06:29:49 --> Output Class Initialized
INFO - 2024-12-07 06:29:49 --> Security Class Initialized
DEBUG - 2024-12-07 06:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 06:29:49 --> Input Class Initialized
INFO - 2024-12-07 06:29:49 --> Language Class Initialized
INFO - 2024-12-07 06:29:49 --> Loader Class Initialized
INFO - 2024-12-07 06:29:49 --> Helper loaded: url_helper
INFO - 2024-12-07 06:29:49 --> Helper loaded: file_helper
INFO - 2024-12-07 06:29:49 --> Helper loaded: security_helper
INFO - 2024-12-07 06:29:49 --> Helper loaded: wpu_helper
INFO - 2024-12-07 06:29:49 --> Database Driver Class Initialized
INFO - 2024-12-07 06:29:50 --> Email Class Initialized
DEBUG - 2024-12-07 06:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 06:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 06:29:50 --> Helper loaded: form_helper
INFO - 2024-12-07 06:29:50 --> Form Validation Class Initialized
INFO - 2024-12-07 06:29:50 --> Controller Class Initialized
DEBUG - 2024-12-07 06:29:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-07 06:29:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-07 06:29:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-07 06:29:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-07 06:29:50 --> Final output sent to browser
DEBUG - 2024-12-07 06:29:50 --> Total execution time: 0.4317
INFO - 2024-12-07 12:46:06 --> Config Class Initialized
INFO - 2024-12-07 12:46:06 --> Hooks Class Initialized
DEBUG - 2024-12-07 12:46:06 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:06 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:06 --> Config Class Initialized
INFO - 2024-12-07 12:46:06 --> Hooks Class Initialized
INFO - 2024-12-07 12:46:06 --> URI Class Initialized
INFO - 2024-12-07 12:46:06 --> Router Class Initialized
DEBUG - 2024-12-07 12:46:06 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:06 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:06 --> URI Class Initialized
INFO - 2024-12-07 12:46:06 --> Router Class Initialized
INFO - 2024-12-07 12:46:06 --> Output Class Initialized
INFO - 2024-12-07 12:46:06 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:06 --> Input Class Initialized
INFO - 2024-12-07 12:46:06 --> Language Class Initialized
ERROR - 2024-12-07 12:46:06 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-12-07 12:46:06 --> Output Class Initialized
INFO - 2024-12-07 12:46:06 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:06 --> Input Class Initialized
INFO - 2024-12-07 12:46:06 --> Language Class Initialized
ERROR - 2024-12-07 12:46:06 --> 404 Page Not Found: Sitemapsxml/index
INFO - 2024-12-07 12:46:07 --> Config Class Initialized
INFO - 2024-12-07 12:46:07 --> Hooks Class Initialized
DEBUG - 2024-12-07 12:46:07 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:07 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:07 --> URI Class Initialized
INFO - 2024-12-07 12:46:07 --> Router Class Initialized
INFO - 2024-12-07 12:46:07 --> Output Class Initialized
INFO - 2024-12-07 12:46:07 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:07 --> Input Class Initialized
INFO - 2024-12-07 12:46:07 --> Language Class Initialized
ERROR - 2024-12-07 12:46:07 --> 404 Page Not Found: Sitemapxmlgz/index
INFO - 2024-12-07 12:46:09 --> Config Class Initialized
INFO - 2024-12-07 12:46:09 --> Hooks Class Initialized
DEBUG - 2024-12-07 12:46:09 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:09 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:09 --> URI Class Initialized
INFO - 2024-12-07 12:46:09 --> Router Class Initialized
INFO - 2024-12-07 12:46:09 --> Output Class Initialized
INFO - 2024-12-07 12:46:09 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:09 --> Input Class Initialized
INFO - 2024-12-07 12:46:09 --> Language Class Initialized
ERROR - 2024-12-07 12:46:09 --> 404 Page Not Found: Sitemaptxt/index
INFO - 2024-12-07 12:46:10 --> Config Class Initialized
INFO - 2024-12-07 12:46:10 --> Hooks Class Initialized
DEBUG - 2024-12-07 12:46:10 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:10 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:10 --> URI Class Initialized
INFO - 2024-12-07 12:46:10 --> Router Class Initialized
INFO - 2024-12-07 12:46:10 --> Output Class Initialized
INFO - 2024-12-07 12:46:10 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:10 --> Input Class Initialized
INFO - 2024-12-07 12:46:10 --> Language Class Initialized
ERROR - 2024-12-07 12:46:10 --> 404 Page Not Found: Sitemap_indexxml/index
INFO - 2024-12-07 12:46:11 --> Config Class Initialized
INFO - 2024-12-07 12:46:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 12:46:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 12:46:11 --> Utf8 Class Initialized
INFO - 2024-12-07 12:46:11 --> URI Class Initialized
INFO - 2024-12-07 12:46:11 --> Router Class Initialized
INFO - 2024-12-07 12:46:11 --> Output Class Initialized
INFO - 2024-12-07 12:46:11 --> Security Class Initialized
DEBUG - 2024-12-07 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 12:46:11 --> Input Class Initialized
INFO - 2024-12-07 12:46:11 --> Language Class Initialized
ERROR - 2024-12-07 12:46:11 --> 404 Page Not Found: Atomxml/index
INFO - 2024-12-07 15:03:49 --> Config Class Initialized
INFO - 2024-12-07 15:03:49 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:03:49 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:03:49 --> Utf8 Class Initialized
INFO - 2024-12-07 15:03:49 --> URI Class Initialized
DEBUG - 2024-12-07 15:03:49 --> No URI present. Default controller set.
INFO - 2024-12-07 15:03:49 --> Router Class Initialized
INFO - 2024-12-07 15:03:49 --> Output Class Initialized
INFO - 2024-12-07 15:03:49 --> Security Class Initialized
DEBUG - 2024-12-07 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:03:49 --> Input Class Initialized
INFO - 2024-12-07 15:03:49 --> Language Class Initialized
INFO - 2024-12-07 15:03:49 --> Loader Class Initialized
INFO - 2024-12-07 15:03:49 --> Helper loaded: url_helper
INFO - 2024-12-07 15:03:49 --> Helper loaded: file_helper
INFO - 2024-12-07 15:03:49 --> Helper loaded: security_helper
INFO - 2024-12-07 15:03:49 --> Helper loaded: wpu_helper
INFO - 2024-12-07 15:03:49 --> Database Driver Class Initialized
INFO - 2024-12-07 15:03:49 --> Email Class Initialized
DEBUG - 2024-12-07 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:03:49 --> Helper loaded: form_helper
INFO - 2024-12-07 15:03:49 --> Form Validation Class Initialized
INFO - 2024-12-07 15:03:49 --> Controller Class Initialized
DEBUG - 2024-12-07 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:03:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-07 15:03:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-07 15:03:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-07 15:03:49 --> Final output sent to browser
DEBUG - 2024-12-07 15:03:49 --> Total execution time: 0.4512
INFO - 2024-12-07 15:29:31 --> Config Class Initialized
INFO - 2024-12-07 15:29:31 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:31 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:31 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:31 --> URI Class Initialized
DEBUG - 2024-12-07 15:29:31 --> No URI present. Default controller set.
INFO - 2024-12-07 15:29:31 --> Router Class Initialized
INFO - 2024-12-07 15:29:31 --> Output Class Initialized
INFO - 2024-12-07 15:29:31 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:31 --> Input Class Initialized
INFO - 2024-12-07 15:29:31 --> Language Class Initialized
INFO - 2024-12-07 15:29:31 --> Loader Class Initialized
INFO - 2024-12-07 15:29:31 --> Helper loaded: url_helper
INFO - 2024-12-07 15:29:31 --> Helper loaded: file_helper
INFO - 2024-12-07 15:29:31 --> Helper loaded: security_helper
INFO - 2024-12-07 15:29:31 --> Helper loaded: wpu_helper
INFO - 2024-12-07 15:29:31 --> Database Driver Class Initialized
INFO - 2024-12-07 15:29:31 --> Email Class Initialized
DEBUG - 2024-12-07 15:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-07 15:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 15:29:31 --> Helper loaded: form_helper
INFO - 2024-12-07 15:29:31 --> Form Validation Class Initialized
INFO - 2024-12-07 15:29:31 --> Controller Class Initialized
DEBUG - 2024-12-07 15:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-07 15:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-07 15:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-07 15:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-07 15:29:31 --> Final output sent to browser
DEBUG - 2024-12-07 15:29:31 --> Total execution time: 0.4714
INFO - 2024-12-07 15:29:50 --> Config Class Initialized
INFO - 2024-12-07 15:29:50 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:50 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:50 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:50 --> URI Class Initialized
INFO - 2024-12-07 15:29:50 --> Router Class Initialized
INFO - 2024-12-07 15:29:50 --> Output Class Initialized
INFO - 2024-12-07 15:29:50 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:50 --> Input Class Initialized
INFO - 2024-12-07 15:29:50 --> Language Class Initialized
ERROR - 2024-12-07 15:29:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:29:50 --> Config Class Initialized
INFO - 2024-12-07 15:29:50 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:50 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:50 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:50 --> URI Class Initialized
INFO - 2024-12-07 15:29:50 --> Router Class Initialized
INFO - 2024-12-07 15:29:50 --> Output Class Initialized
INFO - 2024-12-07 15:29:50 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:50 --> Input Class Initialized
INFO - 2024-12-07 15:29:50 --> Language Class Initialized
ERROR - 2024-12-07 15:29:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:29:50 --> Config Class Initialized
INFO - 2024-12-07 15:29:50 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:50 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:50 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:50 --> URI Class Initialized
INFO - 2024-12-07 15:29:50 --> Router Class Initialized
INFO - 2024-12-07 15:29:50 --> Output Class Initialized
INFO - 2024-12-07 15:29:50 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:50 --> Input Class Initialized
INFO - 2024-12-07 15:29:50 --> Language Class Initialized
ERROR - 2024-12-07 15:29:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:29:50 --> Config Class Initialized
INFO - 2024-12-07 15:29:50 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:50 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:50 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:50 --> URI Class Initialized
INFO - 2024-12-07 15:29:50 --> Router Class Initialized
INFO - 2024-12-07 15:29:50 --> Output Class Initialized
INFO - 2024-12-07 15:29:50 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:50 --> Input Class Initialized
INFO - 2024-12-07 15:29:50 --> Language Class Initialized
ERROR - 2024-12-07 15:29:50 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:29:50 --> Config Class Initialized
INFO - 2024-12-07 15:29:50 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:29:50 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:29:50 --> Utf8 Class Initialized
INFO - 2024-12-07 15:29:50 --> URI Class Initialized
INFO - 2024-12-07 15:29:50 --> Router Class Initialized
INFO - 2024-12-07 15:29:50 --> Output Class Initialized
INFO - 2024-12-07 15:29:50 --> Security Class Initialized
DEBUG - 2024-12-07 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:29:50 --> Input Class Initialized
INFO - 2024-12-07 15:29:50 --> Language Class Initialized
ERROR - 2024-12-07 15:29:50 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:30:30 --> Config Class Initialized
INFO - 2024-12-07 15:30:30 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:30 --> URI Class Initialized
INFO - 2024-12-07 15:30:30 --> Router Class Initialized
INFO - 2024-12-07 15:30:30 --> Output Class Initialized
INFO - 2024-12-07 15:30:30 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:30 --> Input Class Initialized
INFO - 2024-12-07 15:30:30 --> Language Class Initialized
ERROR - 2024-12-07 15:30:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:30:30 --> Config Class Initialized
INFO - 2024-12-07 15:30:30 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:30 --> URI Class Initialized
INFO - 2024-12-07 15:30:30 --> Router Class Initialized
INFO - 2024-12-07 15:30:30 --> Output Class Initialized
INFO - 2024-12-07 15:30:30 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:30 --> Input Class Initialized
INFO - 2024-12-07 15:30:30 --> Language Class Initialized
ERROR - 2024-12-07 15:30:30 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:30:30 --> Config Class Initialized
INFO - 2024-12-07 15:30:30 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:30 --> URI Class Initialized
INFO - 2024-12-07 15:30:30 --> Router Class Initialized
INFO - 2024-12-07 15:30:30 --> Output Class Initialized
INFO - 2024-12-07 15:30:30 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:30 --> Input Class Initialized
INFO - 2024-12-07 15:30:30 --> Language Class Initialized
ERROR - 2024-12-07 15:30:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:30:30 --> Config Class Initialized
INFO - 2024-12-07 15:30:30 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:30 --> URI Class Initialized
INFO - 2024-12-07 15:30:30 --> Router Class Initialized
INFO - 2024-12-07 15:30:30 --> Config Class Initialized
INFO - 2024-12-07 15:30:30 --> Hooks Class Initialized
INFO - 2024-12-07 15:30:30 --> Output Class Initialized
DEBUG - 2024-12-07 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-07 15:30:30 --> Security Class Initialized
INFO - 2024-12-07 15:30:30 --> URI Class Initialized
DEBUG - 2024-12-07 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:30 --> Router Class Initialized
INFO - 2024-12-07 15:30:30 --> Input Class Initialized
INFO - 2024-12-07 15:30:30 --> Language Class Initialized
ERROR - 2024-12-07 15:30:30 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:30:30 --> Output Class Initialized
INFO - 2024-12-07 15:30:30 --> Security Class Initialized
DEBUG - 2024-12-07 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:30:30 --> Input Class Initialized
INFO - 2024-12-07 15:30:30 --> Language Class Initialized
ERROR - 2024-12-07 15:30:31 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:16 --> Config Class Initialized
INFO - 2024-12-07 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:16 --> URI Class Initialized
INFO - 2024-12-07 15:31:16 --> Router Class Initialized
INFO - 2024-12-07 15:31:16 --> Output Class Initialized
INFO - 2024-12-07 15:31:16 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:16 --> Input Class Initialized
INFO - 2024-12-07 15:31:16 --> Language Class Initialized
ERROR - 2024-12-07 15:31:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:31:16 --> Config Class Initialized
INFO - 2024-12-07 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:16 --> URI Class Initialized
INFO - 2024-12-07 15:31:16 --> Config Class Initialized
INFO - 2024-12-07 15:31:16 --> Hooks Class Initialized
INFO - 2024-12-07 15:31:16 --> Config Class Initialized
INFO - 2024-12-07 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:16 --> Utf8 Class Initialized
DEBUG - 2024-12-07 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:16 --> Router Class Initialized
INFO - 2024-12-07 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:16 --> URI Class Initialized
INFO - 2024-12-07 15:31:16 --> URI Class Initialized
INFO - 2024-12-07 15:31:16 --> Output Class Initialized
INFO - 2024-12-07 15:31:16 --> Router Class Initialized
INFO - 2024-12-07 15:31:16 --> Router Class Initialized
INFO - 2024-12-07 15:31:16 --> Security Class Initialized
INFO - 2024-12-07 15:31:16 --> Output Class Initialized
INFO - 2024-12-07 15:31:16 --> Output Class Initialized
DEBUG - 2024-12-07 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:16 --> Input Class Initialized
INFO - 2024-12-07 15:31:16 --> Language Class Initialized
INFO - 2024-12-07 15:31:16 --> Security Class Initialized
ERROR - 2024-12-07 15:31:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-07 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:16 --> Input Class Initialized
INFO - 2024-12-07 15:31:16 --> Security Class Initialized
INFO - 2024-12-07 15:31:16 --> Language Class Initialized
ERROR - 2024-12-07 15:31:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-07 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:16 --> Input Class Initialized
INFO - 2024-12-07 15:31:16 --> Language Class Initialized
ERROR - 2024-12-07 15:31:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:16 --> Config Class Initialized
INFO - 2024-12-07 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:16 --> URI Class Initialized
INFO - 2024-12-07 15:31:16 --> Router Class Initialized
INFO - 2024-12-07 15:31:16 --> Output Class Initialized
INFO - 2024-12-07 15:31:16 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:16 --> Input Class Initialized
INFO - 2024-12-07 15:31:16 --> Language Class Initialized
ERROR - 2024-12-07 15:31:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:55 --> Config Class Initialized
INFO - 2024-12-07 15:31:55 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:55 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:55 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:55 --> URI Class Initialized
INFO - 2024-12-07 15:31:55 --> Router Class Initialized
INFO - 2024-12-07 15:31:55 --> Config Class Initialized
INFO - 2024-12-07 15:31:55 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:55 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:55 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:55 --> URI Class Initialized
INFO - 2024-12-07 15:31:55 --> Router Class Initialized
INFO - 2024-12-07 15:31:55 --> Output Class Initialized
INFO - 2024-12-07 15:31:55 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:55 --> Input Class Initialized
INFO - 2024-12-07 15:31:55 --> Language Class Initialized
ERROR - 2024-12-07 15:31:55 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:31:55 --> Output Class Initialized
INFO - 2024-12-07 15:31:55 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:55 --> Input Class Initialized
INFO - 2024-12-07 15:31:55 --> Language Class Initialized
ERROR - 2024-12-07 15:31:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:55 --> Config Class Initialized
INFO - 2024-12-07 15:31:55 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:55 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:55 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:55 --> URI Class Initialized
INFO - 2024-12-07 15:31:55 --> Router Class Initialized
INFO - 2024-12-07 15:31:55 --> Output Class Initialized
INFO - 2024-12-07 15:31:55 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:55 --> Input Class Initialized
INFO - 2024-12-07 15:31:55 --> Language Class Initialized
ERROR - 2024-12-07 15:31:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:55 --> Config Class Initialized
INFO - 2024-12-07 15:31:55 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:55 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:55 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:55 --> URI Class Initialized
INFO - 2024-12-07 15:31:55 --> Router Class Initialized
INFO - 2024-12-07 15:31:55 --> Output Class Initialized
INFO - 2024-12-07 15:31:55 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:55 --> Input Class Initialized
INFO - 2024-12-07 15:31:55 --> Language Class Initialized
ERROR - 2024-12-07 15:31:55 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:31:57 --> Config Class Initialized
INFO - 2024-12-07 15:31:57 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:31:57 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:31:57 --> Utf8 Class Initialized
INFO - 2024-12-07 15:31:57 --> URI Class Initialized
INFO - 2024-12-07 15:31:57 --> Router Class Initialized
INFO - 2024-12-07 15:31:57 --> Output Class Initialized
INFO - 2024-12-07 15:31:57 --> Security Class Initialized
DEBUG - 2024-12-07 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:31:57 --> Input Class Initialized
INFO - 2024-12-07 15:31:57 --> Language Class Initialized
ERROR - 2024-12-07 15:31:57 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:32:34 --> Config Class Initialized
INFO - 2024-12-07 15:32:34 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:32:34 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:32:34 --> Utf8 Class Initialized
INFO - 2024-12-07 15:32:34 --> Config Class Initialized
INFO - 2024-12-07 15:32:34 --> Hooks Class Initialized
INFO - 2024-12-07 15:32:34 --> URI Class Initialized
DEBUG - 2024-12-07 15:32:34 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:32:34 --> Utf8 Class Initialized
INFO - 2024-12-07 15:32:34 --> Router Class Initialized
INFO - 2024-12-07 15:32:34 --> URI Class Initialized
INFO - 2024-12-07 15:32:34 --> Router Class Initialized
INFO - 2024-12-07 15:32:34 --> Output Class Initialized
INFO - 2024-12-07 15:32:34 --> Security Class Initialized
DEBUG - 2024-12-07 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:32:34 --> Input Class Initialized
INFO - 2024-12-07 15:32:34 --> Language Class Initialized
ERROR - 2024-12-07 15:32:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:32:34 --> Config Class Initialized
INFO - 2024-12-07 15:32:34 --> Hooks Class Initialized
INFO - 2024-12-07 15:32:34 --> Output Class Initialized
DEBUG - 2024-12-07 15:32:34 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:32:34 --> Security Class Initialized
INFO - 2024-12-07 15:32:34 --> Utf8 Class Initialized
DEBUG - 2024-12-07 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:32:34 --> Input Class Initialized
INFO - 2024-12-07 15:32:34 --> Language Class Initialized
ERROR - 2024-12-07 15:32:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:32:34 --> URI Class Initialized
INFO - 2024-12-07 15:32:34 --> Router Class Initialized
INFO - 2024-12-07 15:32:34 --> Config Class Initialized
INFO - 2024-12-07 15:32:34 --> Hooks Class Initialized
INFO - 2024-12-07 15:32:34 --> Output Class Initialized
DEBUG - 2024-12-07 15:32:34 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:32:34 --> Utf8 Class Initialized
INFO - 2024-12-07 15:32:34 --> Security Class Initialized
DEBUG - 2024-12-07 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:32:34 --> Input Class Initialized
INFO - 2024-12-07 15:32:34 --> Language Class Initialized
ERROR - 2024-12-07 15:32:34 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:32:34 --> URI Class Initialized
INFO - 2024-12-07 15:32:34 --> Router Class Initialized
INFO - 2024-12-07 15:32:34 --> Output Class Initialized
INFO - 2024-12-07 15:32:34 --> Security Class Initialized
DEBUG - 2024-12-07 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:32:34 --> Input Class Initialized
INFO - 2024-12-07 15:32:34 --> Language Class Initialized
ERROR - 2024-12-07 15:32:34 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:32:35 --> Config Class Initialized
INFO - 2024-12-07 15:32:35 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:32:35 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:32:35 --> Utf8 Class Initialized
INFO - 2024-12-07 15:32:35 --> URI Class Initialized
INFO - 2024-12-07 15:32:35 --> Router Class Initialized
INFO - 2024-12-07 15:32:35 --> Output Class Initialized
INFO - 2024-12-07 15:32:35 --> Security Class Initialized
DEBUG - 2024-12-07 15:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:32:35 --> Input Class Initialized
INFO - 2024-12-07 15:32:35 --> Language Class Initialized
ERROR - 2024-12-07 15:32:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:11 --> Config Class Initialized
INFO - 2024-12-07 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:11 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:11 --> URI Class Initialized
INFO - 2024-12-07 15:33:11 --> Router Class Initialized
INFO - 2024-12-07 15:33:11 --> Output Class Initialized
INFO - 2024-12-07 15:33:11 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:11 --> Input Class Initialized
INFO - 2024-12-07 15:33:11 --> Language Class Initialized
ERROR - 2024-12-07 15:33:11 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:33:11 --> Config Class Initialized
INFO - 2024-12-07 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:11 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:11 --> URI Class Initialized
INFO - 2024-12-07 15:33:11 --> Router Class Initialized
INFO - 2024-12-07 15:33:11 --> Output Class Initialized
INFO - 2024-12-07 15:33:11 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:11 --> Input Class Initialized
INFO - 2024-12-07 15:33:11 --> Language Class Initialized
ERROR - 2024-12-07 15:33:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:11 --> Config Class Initialized
INFO - 2024-12-07 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:11 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:11 --> URI Class Initialized
INFO - 2024-12-07 15:33:11 --> Router Class Initialized
INFO - 2024-12-07 15:33:11 --> Output Class Initialized
INFO - 2024-12-07 15:33:11 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:11 --> Input Class Initialized
INFO - 2024-12-07 15:33:11 --> Language Class Initialized
ERROR - 2024-12-07 15:33:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:11 --> Config Class Initialized
INFO - 2024-12-07 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:11 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:11 --> URI Class Initialized
INFO - 2024-12-07 15:33:11 --> Router Class Initialized
INFO - 2024-12-07 15:33:11 --> Output Class Initialized
INFO - 2024-12-07 15:33:11 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:11 --> Input Class Initialized
INFO - 2024-12-07 15:33:11 --> Language Class Initialized
ERROR - 2024-12-07 15:33:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:11 --> Config Class Initialized
INFO - 2024-12-07 15:33:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:11 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:11 --> URI Class Initialized
INFO - 2024-12-07 15:33:11 --> Router Class Initialized
INFO - 2024-12-07 15:33:11 --> Output Class Initialized
INFO - 2024-12-07 15:33:11 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:11 --> Input Class Initialized
INFO - 2024-12-07 15:33:11 --> Language Class Initialized
ERROR - 2024-12-07 15:33:11 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:52 --> Config Class Initialized
INFO - 2024-12-07 15:33:52 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:52 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:52 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:52 --> URI Class Initialized
INFO - 2024-12-07 15:33:52 --> Router Class Initialized
INFO - 2024-12-07 15:33:52 --> Output Class Initialized
INFO - 2024-12-07 15:33:52 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:52 --> Input Class Initialized
INFO - 2024-12-07 15:33:52 --> Language Class Initialized
ERROR - 2024-12-07 15:33:52 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:52 --> Config Class Initialized
INFO - 2024-12-07 15:33:52 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:52 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:52 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:52 --> URI Class Initialized
INFO - 2024-12-07 15:33:52 --> Router Class Initialized
INFO - 2024-12-07 15:33:52 --> Output Class Initialized
INFO - 2024-12-07 15:33:52 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:52 --> Input Class Initialized
INFO - 2024-12-07 15:33:52 --> Language Class Initialized
ERROR - 2024-12-07 15:33:52 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:52 --> Config Class Initialized
INFO - 2024-12-07 15:33:52 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:52 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:52 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:52 --> URI Class Initialized
INFO - 2024-12-07 15:33:52 --> Router Class Initialized
INFO - 2024-12-07 15:33:52 --> Output Class Initialized
INFO - 2024-12-07 15:33:52 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:52 --> Input Class Initialized
INFO - 2024-12-07 15:33:52 --> Language Class Initialized
ERROR - 2024-12-07 15:33:52 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:33:53 --> Config Class Initialized
INFO - 2024-12-07 15:33:53 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:53 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:53 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:53 --> URI Class Initialized
INFO - 2024-12-07 15:33:53 --> Router Class Initialized
INFO - 2024-12-07 15:33:53 --> Output Class Initialized
INFO - 2024-12-07 15:33:53 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:53 --> Input Class Initialized
INFO - 2024-12-07 15:33:53 --> Language Class Initialized
ERROR - 2024-12-07 15:33:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:33:53 --> Config Class Initialized
INFO - 2024-12-07 15:33:53 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:33:53 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:33:53 --> Utf8 Class Initialized
INFO - 2024-12-07 15:33:53 --> URI Class Initialized
INFO - 2024-12-07 15:33:53 --> Router Class Initialized
INFO - 2024-12-07 15:33:53 --> Output Class Initialized
INFO - 2024-12-07 15:33:53 --> Security Class Initialized
DEBUG - 2024-12-07 15:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:33:53 --> Input Class Initialized
INFO - 2024-12-07 15:33:53 --> Language Class Initialized
ERROR - 2024-12-07 15:33:53 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:15 --> Config Class Initialized
INFO - 2024-12-07 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:15 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:15 --> URI Class Initialized
INFO - 2024-12-07 15:34:15 --> Router Class Initialized
INFO - 2024-12-07 15:34:15 --> Output Class Initialized
INFO - 2024-12-07 15:34:15 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:15 --> Input Class Initialized
INFO - 2024-12-07 15:34:15 --> Language Class Initialized
ERROR - 2024-12-07 15:34:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:15 --> Config Class Initialized
INFO - 2024-12-07 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:15 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:15 --> URI Class Initialized
INFO - 2024-12-07 15:34:15 --> Router Class Initialized
INFO - 2024-12-07 15:34:15 --> Output Class Initialized
INFO - 2024-12-07 15:34:15 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:15 --> Input Class Initialized
INFO - 2024-12-07 15:34:15 --> Language Class Initialized
ERROR - 2024-12-07 15:34:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:15 --> Config Class Initialized
INFO - 2024-12-07 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:15 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:15 --> URI Class Initialized
INFO - 2024-12-07 15:34:15 --> Config Class Initialized
INFO - 2024-12-07 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:15 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:15 --> URI Class Initialized
INFO - 2024-12-07 15:34:15 --> Router Class Initialized
INFO - 2024-12-07 15:34:15 --> Output Class Initialized
INFO - 2024-12-07 15:34:15 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:15 --> Input Class Initialized
INFO - 2024-12-07 15:34:15 --> Language Class Initialized
ERROR - 2024-12-07 15:34:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:15 --> Router Class Initialized
INFO - 2024-12-07 15:34:15 --> Output Class Initialized
INFO - 2024-12-07 15:34:15 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:15 --> Input Class Initialized
INFO - 2024-12-07 15:34:15 --> Language Class Initialized
ERROR - 2024-12-07 15:34:15 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:16 --> Config Class Initialized
INFO - 2024-12-07 15:34:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:16 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:16 --> URI Class Initialized
INFO - 2024-12-07 15:34:16 --> Router Class Initialized
INFO - 2024-12-07 15:34:16 --> Output Class Initialized
INFO - 2024-12-07 15:34:16 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:16 --> Input Class Initialized
INFO - 2024-12-07 15:34:16 --> Language Class Initialized
ERROR - 2024-12-07 15:34:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-07 15:34:46 --> Config Class Initialized
INFO - 2024-12-07 15:34:46 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:46 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:46 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:46 --> URI Class Initialized
INFO - 2024-12-07 15:34:46 --> Router Class Initialized
INFO - 2024-12-07 15:34:46 --> Output Class Initialized
INFO - 2024-12-07 15:34:46 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:46 --> Input Class Initialized
INFO - 2024-12-07 15:34:46 --> Language Class Initialized
ERROR - 2024-12-07 15:34:46 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:46 --> Config Class Initialized
INFO - 2024-12-07 15:34:46 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:46 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:46 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:46 --> URI Class Initialized
INFO - 2024-12-07 15:34:46 --> Router Class Initialized
INFO - 2024-12-07 15:34:46 --> Output Class Initialized
INFO - 2024-12-07 15:34:46 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:46 --> Input Class Initialized
INFO - 2024-12-07 15:34:46 --> Language Class Initialized
ERROR - 2024-12-07 15:34:46 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:46 --> Config Class Initialized
INFO - 2024-12-07 15:34:46 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:46 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:46 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:46 --> URI Class Initialized
INFO - 2024-12-07 15:34:46 --> Router Class Initialized
INFO - 2024-12-07 15:34:46 --> Output Class Initialized
INFO - 2024-12-07 15:34:46 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:46 --> Input Class Initialized
INFO - 2024-12-07 15:34:46 --> Language Class Initialized
ERROR - 2024-12-07 15:34:46 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-07 15:34:47 --> Config Class Initialized
INFO - 2024-12-07 15:34:47 --> Config Class Initialized
INFO - 2024-12-07 15:34:47 --> Hooks Class Initialized
INFO - 2024-12-07 15:34:47 --> Hooks Class Initialized
DEBUG - 2024-12-07 15:34:47 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:47 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:47 --> URI Class Initialized
DEBUG - 2024-12-07 15:34:47 --> UTF-8 Support Enabled
INFO - 2024-12-07 15:34:47 --> Utf8 Class Initialized
INFO - 2024-12-07 15:34:47 --> Router Class Initialized
INFO - 2024-12-07 15:34:47 --> URI Class Initialized
INFO - 2024-12-07 15:34:47 --> Router Class Initialized
INFO - 2024-12-07 15:34:47 --> Output Class Initialized
INFO - 2024-12-07 15:34:47 --> Output Class Initialized
INFO - 2024-12-07 15:34:47 --> Security Class Initialized
INFO - 2024-12-07 15:34:47 --> Security Class Initialized
DEBUG - 2024-12-07 15:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-07 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 15:34:47 --> Input Class Initialized
INFO - 2024-12-07 15:34:47 --> Input Class Initialized
INFO - 2024-12-07 15:34:47 --> Language Class Initialized
INFO - 2024-12-07 15:34:47 --> Language Class Initialized
ERROR - 2024-12-07 15:34:47 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
ERROR - 2024-12-07 15:34:47 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
