<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-10 08:59:07 --> Config Class Initialized
INFO - 2024-10-10 08:59:07 --> Hooks Class Initialized
DEBUG - 2024-10-10 08:59:07 --> UTF-8 Support Enabled
INFO - 2024-10-10 08:59:07 --> Utf8 Class Initialized
INFO - 2024-10-10 08:59:07 --> URI Class Initialized
DEBUG - 2024-10-10 08:59:07 --> No URI present. Default controller set.
INFO - 2024-10-10 08:59:07 --> Router Class Initialized
INFO - 2024-10-10 08:59:07 --> Output Class Initialized
INFO - 2024-10-10 08:59:07 --> Security Class Initialized
DEBUG - 2024-10-10 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 08:59:07 --> Input Class Initialized
INFO - 2024-10-10 08:59:07 --> Language Class Initialized
INFO - 2024-10-10 08:59:07 --> Loader Class Initialized
INFO - 2024-10-10 08:59:07 --> Helper loaded: url_helper
INFO - 2024-10-10 08:59:07 --> Helper loaded: file_helper
INFO - 2024-10-10 08:59:07 --> Helper loaded: security_helper
INFO - 2024-10-10 08:59:07 --> Helper loaded: wpu_helper
INFO - 2024-10-10 08:59:07 --> Database Driver Class Initialized
INFO - 2024-10-10 08:59:46 --> Config Class Initialized
INFO - 2024-10-10 08:59:46 --> Hooks Class Initialized
DEBUG - 2024-10-10 08:59:46 --> UTF-8 Support Enabled
INFO - 2024-10-10 08:59:46 --> Utf8 Class Initialized
INFO - 2024-10-10 08:59:46 --> URI Class Initialized
DEBUG - 2024-10-10 08:59:46 --> No URI present. Default controller set.
INFO - 2024-10-10 08:59:46 --> Router Class Initialized
INFO - 2024-10-10 08:59:46 --> Output Class Initialized
INFO - 2024-10-10 08:59:46 --> Security Class Initialized
DEBUG - 2024-10-10 08:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 08:59:46 --> Input Class Initialized
INFO - 2024-10-10 08:59:46 --> Language Class Initialized
INFO - 2024-10-10 08:59:46 --> Loader Class Initialized
INFO - 2024-10-10 08:59:46 --> Helper loaded: url_helper
INFO - 2024-10-10 08:59:46 --> Helper loaded: file_helper
INFO - 2024-10-10 08:59:46 --> Helper loaded: security_helper
INFO - 2024-10-10 08:59:46 --> Helper loaded: wpu_helper
INFO - 2024-10-10 08:59:47 --> Database Driver Class Initialized
INFO - 2024-10-10 18:13:43 --> Config Class Initialized
INFO - 2024-10-10 18:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-10 18:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-10 18:13:43 --> Utf8 Class Initialized
INFO - 2024-10-10 18:13:43 --> URI Class Initialized
DEBUG - 2024-10-10 18:13:43 --> No URI present. Default controller set.
INFO - 2024-10-10 18:13:43 --> Router Class Initialized
INFO - 2024-10-10 18:13:43 --> Output Class Initialized
INFO - 2024-10-10 18:13:43 --> Security Class Initialized
DEBUG - 2024-10-10 18:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 18:13:43 --> Input Class Initialized
INFO - 2024-10-10 18:13:43 --> Language Class Initialized
INFO - 2024-10-10 18:13:43 --> Loader Class Initialized
INFO - 2024-10-10 18:13:43 --> Helper loaded: url_helper
INFO - 2024-10-10 18:13:43 --> Helper loaded: file_helper
INFO - 2024-10-10 18:13:43 --> Helper loaded: security_helper
INFO - 2024-10-10 18:13:43 --> Helper loaded: wpu_helper
INFO - 2024-10-10 18:13:43 --> Database Driver Class Initialized
INFO - 2024-10-10 18:15:00 --> Config Class Initialized
INFO - 2024-10-10 18:15:00 --> Hooks Class Initialized
DEBUG - 2024-10-10 18:15:00 --> UTF-8 Support Enabled
INFO - 2024-10-10 18:15:00 --> Utf8 Class Initialized
INFO - 2024-10-10 18:15:00 --> URI Class Initialized
DEBUG - 2024-10-10 18:15:00 --> No URI present. Default controller set.
INFO - 2024-10-10 18:15:00 --> Router Class Initialized
INFO - 2024-10-10 18:15:00 --> Output Class Initialized
INFO - 2024-10-10 18:15:00 --> Security Class Initialized
DEBUG - 2024-10-10 18:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-10 18:15:00 --> Input Class Initialized
INFO - 2024-10-10 18:15:00 --> Language Class Initialized
INFO - 2024-10-10 18:15:00 --> Loader Class Initialized
INFO - 2024-10-10 18:15:00 --> Helper loaded: url_helper
INFO - 2024-10-10 18:15:00 --> Helper loaded: file_helper
INFO - 2024-10-10 18:15:00 --> Helper loaded: security_helper
INFO - 2024-10-10 18:15:00 --> Helper loaded: wpu_helper
INFO - 2024-10-10 18:15:00 --> Database Driver Class Initialized
