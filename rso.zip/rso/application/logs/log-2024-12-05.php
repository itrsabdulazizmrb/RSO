<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-05 01:46:56 --> Config Class Initialized
INFO - 2024-12-05 01:46:56 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:46:56 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:46:56 --> Utf8 Class Initialized
INFO - 2024-12-05 01:46:56 --> URI Class Initialized
DEBUG - 2024-12-05 01:46:56 --> No URI present. Default controller set.
INFO - 2024-12-05 01:46:56 --> Router Class Initialized
INFO - 2024-12-05 01:46:56 --> Output Class Initialized
INFO - 2024-12-05 01:46:56 --> Security Class Initialized
DEBUG - 2024-12-05 01:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:46:56 --> Input Class Initialized
INFO - 2024-12-05 01:46:56 --> Language Class Initialized
INFO - 2024-12-05 01:46:56 --> Loader Class Initialized
INFO - 2024-12-05 01:46:56 --> Helper loaded: url_helper
INFO - 2024-12-05 01:46:56 --> Helper loaded: file_helper
INFO - 2024-12-05 01:46:56 --> Helper loaded: security_helper
INFO - 2024-12-05 01:46:56 --> Helper loaded: wpu_helper
INFO - 2024-12-05 01:46:56 --> Database Driver Class Initialized
INFO - 2024-12-05 01:46:57 --> Email Class Initialized
DEBUG - 2024-12-05 01:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 01:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 01:46:57 --> Helper loaded: form_helper
INFO - 2024-12-05 01:46:57 --> Form Validation Class Initialized
INFO - 2024-12-05 01:46:57 --> Controller Class Initialized
DEBUG - 2024-12-05 01:46:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 01:46:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 01:46:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 01:46:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 01:46:57 --> Final output sent to browser
DEBUG - 2024-12-05 01:46:57 --> Total execution time: 0.4301
INFO - 2024-12-05 01:47:41 --> Config Class Initialized
INFO - 2024-12-05 01:47:41 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:47:41 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:47:41 --> Utf8 Class Initialized
INFO - 2024-12-05 01:47:41 --> URI Class Initialized
INFO - 2024-12-05 01:47:41 --> Router Class Initialized
INFO - 2024-12-05 01:47:41 --> Output Class Initialized
INFO - 2024-12-05 01:47:41 --> Security Class Initialized
DEBUG - 2024-12-05 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:47:41 --> Input Class Initialized
INFO - 2024-12-05 01:47:41 --> Language Class Initialized
ERROR - 2024-12-05 01:47:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:47:41 --> Config Class Initialized
INFO - 2024-12-05 01:47:41 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:47:41 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:47:41 --> Utf8 Class Initialized
INFO - 2024-12-05 01:47:41 --> URI Class Initialized
INFO - 2024-12-05 01:47:41 --> Router Class Initialized
INFO - 2024-12-05 01:47:41 --> Output Class Initialized
INFO - 2024-12-05 01:47:41 --> Security Class Initialized
DEBUG - 2024-12-05 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:47:41 --> Input Class Initialized
INFO - 2024-12-05 01:47:41 --> Config Class Initialized
INFO - 2024-12-05 01:47:41 --> Language Class Initialized
INFO - 2024-12-05 01:47:41 --> Hooks Class Initialized
ERROR - 2024-12-05 01:47:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-05 01:47:41 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:47:41 --> Utf8 Class Initialized
INFO - 2024-12-05 01:47:41 --> URI Class Initialized
INFO - 2024-12-05 01:47:41 --> Config Class Initialized
INFO - 2024-12-05 01:47:41 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:47:41 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:47:41 --> Utf8 Class Initialized
INFO - 2024-12-05 01:47:41 --> URI Class Initialized
INFO - 2024-12-05 01:47:41 --> Router Class Initialized
INFO - 2024-12-05 01:47:41 --> Router Class Initialized
INFO - 2024-12-05 01:47:41 --> Output Class Initialized
INFO - 2024-12-05 01:47:41 --> Output Class Initialized
INFO - 2024-12-05 01:47:41 --> Security Class Initialized
DEBUG - 2024-12-05 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:47:41 --> Input Class Initialized
INFO - 2024-12-05 01:47:41 --> Security Class Initialized
INFO - 2024-12-05 01:47:41 --> Language Class Initialized
ERROR - 2024-12-05 01:47:41 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
DEBUG - 2024-12-05 01:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:47:41 --> Input Class Initialized
INFO - 2024-12-05 01:47:41 --> Language Class Initialized
ERROR - 2024-12-05 01:47:41 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:48:24 --> Config Class Initialized
INFO - 2024-12-05 01:48:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:48:24 --> Utf8 Class Initialized
INFO - 2024-12-05 01:48:24 --> Config Class Initialized
INFO - 2024-12-05 01:48:24 --> Hooks Class Initialized
INFO - 2024-12-05 01:48:24 --> URI Class Initialized
INFO - 2024-12-05 01:48:24 --> Router Class Initialized
DEBUG - 2024-12-05 01:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:48:24 --> Utf8 Class Initialized
INFO - 2024-12-05 01:48:24 --> Output Class Initialized
INFO - 2024-12-05 01:48:24 --> URI Class Initialized
INFO - 2024-12-05 01:48:24 --> Security Class Initialized
INFO - 2024-12-05 01:48:24 --> Router Class Initialized
INFO - 2024-12-05 01:48:24 --> Config Class Initialized
INFO - 2024-12-05 01:48:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:48:24 --> Input Class Initialized
INFO - 2024-12-05 01:48:24 --> Output Class Initialized
INFO - 2024-12-05 01:48:24 --> Language Class Initialized
ERROR - 2024-12-05 01:48:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-05 01:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:48:24 --> Utf8 Class Initialized
INFO - 2024-12-05 01:48:24 --> Config Class Initialized
INFO - 2024-12-05 01:48:24 --> Hooks Class Initialized
INFO - 2024-12-05 01:48:24 --> Security Class Initialized
INFO - 2024-12-05 01:48:24 --> URI Class Initialized
DEBUG - 2024-12-05 01:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:48:24 --> Input Class Initialized
INFO - 2024-12-05 01:48:24 --> Language Class Initialized
DEBUG - 2024-12-05 01:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:48:24 --> Router Class Initialized
INFO - 2024-12-05 01:48:24 --> Utf8 Class Initialized
ERROR - 2024-12-05 01:48:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:48:24 --> URI Class Initialized
INFO - 2024-12-05 01:48:24 --> Output Class Initialized
INFO - 2024-12-05 01:48:24 --> Router Class Initialized
INFO - 2024-12-05 01:48:24 --> Security Class Initialized
INFO - 2024-12-05 01:48:24 --> Output Class Initialized
DEBUG - 2024-12-05 01:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:48:24 --> Input Class Initialized
INFO - 2024-12-05 01:48:24 --> Language Class Initialized
INFO - 2024-12-05 01:48:24 --> Config Class Initialized
ERROR - 2024-12-05 01:48:24 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 01:48:24 --> Security Class Initialized
INFO - 2024-12-05 01:48:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-05 01:48:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:48:24 --> Input Class Initialized
INFO - 2024-12-05 01:48:24 --> Utf8 Class Initialized
INFO - 2024-12-05 01:48:24 --> Language Class Initialized
INFO - 2024-12-05 01:48:24 --> URI Class Initialized
ERROR - 2024-12-05 01:48:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:48:24 --> Router Class Initialized
INFO - 2024-12-05 01:48:24 --> Output Class Initialized
INFO - 2024-12-05 01:48:24 --> Security Class Initialized
DEBUG - 2024-12-05 01:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:48:24 --> Input Class Initialized
INFO - 2024-12-05 01:48:24 --> Language Class Initialized
ERROR - 2024-12-05 01:48:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:49:21 --> Config Class Initialized
INFO - 2024-12-05 01:49:21 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:49:21 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:49:21 --> Utf8 Class Initialized
INFO - 2024-12-05 01:49:21 --> URI Class Initialized
INFO - 2024-12-05 01:49:21 --> Router Class Initialized
INFO - 2024-12-05 01:49:21 --> Output Class Initialized
INFO - 2024-12-05 01:49:21 --> Security Class Initialized
DEBUG - 2024-12-05 01:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:49:21 --> Input Class Initialized
INFO - 2024-12-05 01:49:21 --> Language Class Initialized
ERROR - 2024-12-05 01:49:21 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 01:49:21 --> Config Class Initialized
INFO - 2024-12-05 01:49:21 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:49:21 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:49:21 --> Utf8 Class Initialized
INFO - 2024-12-05 01:49:21 --> URI Class Initialized
INFO - 2024-12-05 01:49:21 --> Router Class Initialized
INFO - 2024-12-05 01:49:21 --> Output Class Initialized
INFO - 2024-12-05 01:49:21 --> Security Class Initialized
DEBUG - 2024-12-05 01:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:49:21 --> Input Class Initialized
INFO - 2024-12-05 01:49:21 --> Language Class Initialized
ERROR - 2024-12-05 01:49:21 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:49:22 --> Config Class Initialized
INFO - 2024-12-05 01:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:49:22 --> Utf8 Class Initialized
INFO - 2024-12-05 01:49:22 --> URI Class Initialized
INFO - 2024-12-05 01:49:22 --> Router Class Initialized
INFO - 2024-12-05 01:49:22 --> Output Class Initialized
INFO - 2024-12-05 01:49:22 --> Security Class Initialized
DEBUG - 2024-12-05 01:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:49:22 --> Input Class Initialized
INFO - 2024-12-05 01:49:22 --> Language Class Initialized
ERROR - 2024-12-05 01:49:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:49:22 --> Config Class Initialized
INFO - 2024-12-05 01:49:22 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:49:22 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:49:22 --> Utf8 Class Initialized
INFO - 2024-12-05 01:49:22 --> URI Class Initialized
INFO - 2024-12-05 01:49:22 --> Router Class Initialized
INFO - 2024-12-05 01:49:22 --> Output Class Initialized
INFO - 2024-12-05 01:49:22 --> Security Class Initialized
DEBUG - 2024-12-05 01:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:49:22 --> Input Class Initialized
INFO - 2024-12-05 01:49:22 --> Language Class Initialized
ERROR - 2024-12-05 01:49:22 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:12 --> Config Class Initialized
INFO - 2024-12-05 01:50:12 --> Hooks Class Initialized
INFO - 2024-12-05 01:50:12 --> Config Class Initialized
DEBUG - 2024-12-05 01:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:12 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:12 --> URI Class Initialized
INFO - 2024-12-05 01:50:12 --> Router Class Initialized
INFO - 2024-12-05 01:50:12 --> Hooks Class Initialized
INFO - 2024-12-05 01:50:12 --> Output Class Initialized
DEBUG - 2024-12-05 01:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:12 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:12 --> Security Class Initialized
INFO - 2024-12-05 01:50:12 --> URI Class Initialized
INFO - 2024-12-05 01:50:12 --> Router Class Initialized
DEBUG - 2024-12-05 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:12 --> Input Class Initialized
INFO - 2024-12-05 01:50:12 --> Language Class Initialized
ERROR - 2024-12-05 01:50:12 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:12 --> Output Class Initialized
INFO - 2024-12-05 01:50:12 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:12 --> Input Class Initialized
INFO - 2024-12-05 01:50:12 --> Language Class Initialized
ERROR - 2024-12-05 01:50:12 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:12 --> Config Class Initialized
INFO - 2024-12-05 01:50:12 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:12 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:12 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:12 --> URI Class Initialized
INFO - 2024-12-05 01:50:12 --> Router Class Initialized
INFO - 2024-12-05 01:50:12 --> Output Class Initialized
INFO - 2024-12-05 01:50:12 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:12 --> Input Class Initialized
INFO - 2024-12-05 01:50:12 --> Language Class Initialized
ERROR - 2024-12-05 01:50:12 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 01:50:13 --> Config Class Initialized
INFO - 2024-12-05 01:50:13 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:13 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:13 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:13 --> URI Class Initialized
INFO - 2024-12-05 01:50:13 --> Router Class Initialized
INFO - 2024-12-05 01:50:13 --> Output Class Initialized
INFO - 2024-12-05 01:50:13 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:13 --> Input Class Initialized
INFO - 2024-12-05 01:50:13 --> Language Class Initialized
ERROR - 2024-12-05 01:50:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:13 --> Config Class Initialized
INFO - 2024-12-05 01:50:13 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:13 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:13 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:13 --> URI Class Initialized
INFO - 2024-12-05 01:50:13 --> Router Class Initialized
INFO - 2024-12-05 01:50:13 --> Output Class Initialized
INFO - 2024-12-05 01:50:13 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:13 --> Input Class Initialized
INFO - 2024-12-05 01:50:13 --> Language Class Initialized
ERROR - 2024-12-05 01:50:13 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:58 --> Config Class Initialized
INFO - 2024-12-05 01:50:58 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:58 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:58 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:58 --> URI Class Initialized
INFO - 2024-12-05 01:50:58 --> Router Class Initialized
INFO - 2024-12-05 01:50:58 --> Output Class Initialized
INFO - 2024-12-05 01:50:58 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:58 --> Input Class Initialized
INFO - 2024-12-05 01:50:58 --> Language Class Initialized
ERROR - 2024-12-05 01:50:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:58 --> Config Class Initialized
INFO - 2024-12-05 01:50:58 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:58 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:58 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:58 --> URI Class Initialized
INFO - 2024-12-05 01:50:58 --> Router Class Initialized
INFO - 2024-12-05 01:50:58 --> Output Class Initialized
INFO - 2024-12-05 01:50:58 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:58 --> Input Class Initialized
INFO - 2024-12-05 01:50:58 --> Language Class Initialized
ERROR - 2024-12-05 01:50:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:58 --> Config Class Initialized
INFO - 2024-12-05 01:50:58 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:58 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:58 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:58 --> URI Class Initialized
INFO - 2024-12-05 01:50:58 --> Router Class Initialized
INFO - 2024-12-05 01:50:58 --> Output Class Initialized
INFO - 2024-12-05 01:50:58 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:58 --> Input Class Initialized
INFO - 2024-12-05 01:50:58 --> Language Class Initialized
ERROR - 2024-12-05 01:50:58 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 01:50:58 --> Config Class Initialized
INFO - 2024-12-05 01:50:58 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:58 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:58 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:58 --> URI Class Initialized
INFO - 2024-12-05 01:50:58 --> Router Class Initialized
INFO - 2024-12-05 01:50:58 --> Output Class Initialized
INFO - 2024-12-05 01:50:58 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:58 --> Input Class Initialized
INFO - 2024-12-05 01:50:58 --> Language Class Initialized
ERROR - 2024-12-05 01:50:58 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:50:59 --> Config Class Initialized
INFO - 2024-12-05 01:50:59 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:50:59 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:50:59 --> Utf8 Class Initialized
INFO - 2024-12-05 01:50:59 --> URI Class Initialized
INFO - 2024-12-05 01:50:59 --> Router Class Initialized
INFO - 2024-12-05 01:50:59 --> Output Class Initialized
INFO - 2024-12-05 01:50:59 --> Security Class Initialized
DEBUG - 2024-12-05 01:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:50:59 --> Input Class Initialized
INFO - 2024-12-05 01:50:59 --> Language Class Initialized
ERROR - 2024-12-05 01:50:59 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:51:43 --> Config Class Initialized
INFO - 2024-12-05 01:51:43 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:51:43 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:51:43 --> Utf8 Class Initialized
INFO - 2024-12-05 01:51:43 --> URI Class Initialized
INFO - 2024-12-05 01:51:43 --> Router Class Initialized
INFO - 2024-12-05 01:51:43 --> Output Class Initialized
INFO - 2024-12-05 01:51:43 --> Security Class Initialized
INFO - 2024-12-05 01:51:43 --> Config Class Initialized
INFO - 2024-12-05 01:51:43 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:51:43 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:51:43 --> Utf8 Class Initialized
INFO - 2024-12-05 01:51:43 --> URI Class Initialized
INFO - 2024-12-05 01:51:43 --> Router Class Initialized
INFO - 2024-12-05 01:51:43 --> Output Class Initialized
INFO - 2024-12-05 01:51:43 --> Security Class Initialized
DEBUG - 2024-12-05 01:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:51:43 --> Input Class Initialized
INFO - 2024-12-05 01:51:43 --> Language Class Initialized
ERROR - 2024-12-05 01:51:43 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-05 01:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:51:43 --> Input Class Initialized
INFO - 2024-12-05 01:51:43 --> Language Class Initialized
ERROR - 2024-12-05 01:51:43 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 01:51:45 --> Config Class Initialized
INFO - 2024-12-05 01:51:45 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:51:45 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:51:45 --> Utf8 Class Initialized
INFO - 2024-12-05 01:51:45 --> URI Class Initialized
INFO - 2024-12-05 01:51:45 --> Router Class Initialized
INFO - 2024-12-05 01:51:45 --> Output Class Initialized
INFO - 2024-12-05 01:51:45 --> Security Class Initialized
DEBUG - 2024-12-05 01:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:51:45 --> Input Class Initialized
INFO - 2024-12-05 01:51:45 --> Language Class Initialized
ERROR - 2024-12-05 01:51:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:51:45 --> Config Class Initialized
INFO - 2024-12-05 01:51:45 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:51:45 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:51:45 --> Utf8 Class Initialized
INFO - 2024-12-05 01:51:45 --> URI Class Initialized
INFO - 2024-12-05 01:51:45 --> Router Class Initialized
INFO - 2024-12-05 01:51:45 --> Output Class Initialized
INFO - 2024-12-05 01:51:45 --> Security Class Initialized
DEBUG - 2024-12-05 01:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:51:45 --> Input Class Initialized
INFO - 2024-12-05 01:51:45 --> Language Class Initialized
ERROR - 2024-12-05 01:51:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 01:51:45 --> Config Class Initialized
INFO - 2024-12-05 01:51:45 --> Hooks Class Initialized
DEBUG - 2024-12-05 01:51:45 --> UTF-8 Support Enabled
INFO - 2024-12-05 01:51:45 --> Utf8 Class Initialized
INFO - 2024-12-05 01:51:45 --> URI Class Initialized
INFO - 2024-12-05 01:51:45 --> Router Class Initialized
INFO - 2024-12-05 01:51:45 --> Output Class Initialized
INFO - 2024-12-05 01:51:45 --> Security Class Initialized
DEBUG - 2024-12-05 01:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 01:51:45 --> Input Class Initialized
INFO - 2024-12-05 01:51:45 --> Language Class Initialized
ERROR - 2024-12-05 01:51:45 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:43:30 --> Config Class Initialized
INFO - 2024-12-05 02:43:30 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:43:30 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:43:30 --> Utf8 Class Initialized
INFO - 2024-12-05 02:43:30 --> URI Class Initialized
DEBUG - 2024-12-05 02:43:30 --> No URI present. Default controller set.
INFO - 2024-12-05 02:43:30 --> Router Class Initialized
INFO - 2024-12-05 02:43:30 --> Output Class Initialized
INFO - 2024-12-05 02:43:30 --> Security Class Initialized
DEBUG - 2024-12-05 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:43:30 --> Input Class Initialized
INFO - 2024-12-05 02:43:30 --> Language Class Initialized
INFO - 2024-12-05 02:43:30 --> Loader Class Initialized
INFO - 2024-12-05 02:43:30 --> Helper loaded: url_helper
INFO - 2024-12-05 02:43:30 --> Helper loaded: file_helper
INFO - 2024-12-05 02:43:30 --> Helper loaded: security_helper
INFO - 2024-12-05 02:43:30 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:43:30 --> Database Driver Class Initialized
INFO - 2024-12-05 02:43:31 --> Email Class Initialized
DEBUG - 2024-12-05 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:43:31 --> Helper loaded: form_helper
INFO - 2024-12-05 02:43:31 --> Form Validation Class Initialized
INFO - 2024-12-05 02:43:31 --> Controller Class Initialized
DEBUG - 2024-12-05 02:43:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 02:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 02:43:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 02:43:31 --> Final output sent to browser
DEBUG - 2024-12-05 02:43:31 --> Total execution time: 0.4374
INFO - 2024-12-05 02:44:06 --> Config Class Initialized
INFO - 2024-12-05 02:44:06 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:06 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:06 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:06 --> URI Class Initialized
INFO - 2024-12-05 02:44:06 --> Router Class Initialized
INFO - 2024-12-05 02:44:06 --> Output Class Initialized
INFO - 2024-12-05 02:44:06 --> Config Class Initialized
INFO - 2024-12-05 02:44:06 --> Hooks Class Initialized
INFO - 2024-12-05 02:44:06 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:06 --> UTF-8 Support Enabled
DEBUG - 2024-12-05 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:06 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:06 --> Input Class Initialized
INFO - 2024-12-05 02:44:06 --> URI Class Initialized
INFO - 2024-12-05 02:44:06 --> Language Class Initialized
INFO - 2024-12-05 02:44:06 --> Router Class Initialized
ERROR - 2024-12-05 02:44:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:06 --> Output Class Initialized
INFO - 2024-12-05 02:44:06 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:06 --> Input Class Initialized
INFO - 2024-12-05 02:44:06 --> Language Class Initialized
ERROR - 2024-12-05 02:44:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:06 --> Config Class Initialized
INFO - 2024-12-05 02:44:06 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:06 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:06 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:06 --> URI Class Initialized
INFO - 2024-12-05 02:44:06 --> Router Class Initialized
INFO - 2024-12-05 02:44:06 --> Output Class Initialized
INFO - 2024-12-05 02:44:06 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:06 --> Input Class Initialized
INFO - 2024-12-05 02:44:06 --> Language Class Initialized
ERROR - 2024-12-05 02:44:06 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:06 --> Config Class Initialized
INFO - 2024-12-05 02:44:06 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:06 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:06 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:06 --> URI Class Initialized
INFO - 2024-12-05 02:44:06 --> Router Class Initialized
INFO - 2024-12-05 02:44:06 --> Output Class Initialized
INFO - 2024-12-05 02:44:06 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:06 --> Input Class Initialized
INFO - 2024-12-05 02:44:06 --> Language Class Initialized
ERROR - 2024-12-05 02:44:06 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:44:07 --> Config Class Initialized
INFO - 2024-12-05 02:44:07 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:07 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:07 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:07 --> URI Class Initialized
INFO - 2024-12-05 02:44:07 --> Router Class Initialized
INFO - 2024-12-05 02:44:07 --> Output Class Initialized
INFO - 2024-12-05 02:44:07 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:07 --> Input Class Initialized
INFO - 2024-12-05 02:44:07 --> Language Class Initialized
ERROR - 2024-12-05 02:44:07 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:54 --> Config Class Initialized
INFO - 2024-12-05 02:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:54 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:54 --> URI Class Initialized
INFO - 2024-12-05 02:44:54 --> Router Class Initialized
INFO - 2024-12-05 02:44:54 --> Config Class Initialized
INFO - 2024-12-05 02:44:54 --> Hooks Class Initialized
INFO - 2024-12-05 02:44:54 --> Output Class Initialized
DEBUG - 2024-12-05 02:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:54 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:54 --> Security Class Initialized
INFO - 2024-12-05 02:44:54 --> URI Class Initialized
INFO - 2024-12-05 02:44:54 --> Router Class Initialized
INFO - 2024-12-05 02:44:54 --> Output Class Initialized
INFO - 2024-12-05 02:44:54 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:54 --> Input Class Initialized
DEBUG - 2024-12-05 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:54 --> Input Class Initialized
INFO - 2024-12-05 02:44:54 --> Language Class Initialized
INFO - 2024-12-05 02:44:54 --> Language Class Initialized
ERROR - 2024-12-05 02:44:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-05 02:44:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:54 --> Config Class Initialized
INFO - 2024-12-05 02:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:54 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:54 --> URI Class Initialized
INFO - 2024-12-05 02:44:54 --> Router Class Initialized
INFO - 2024-12-05 02:44:54 --> Output Class Initialized
INFO - 2024-12-05 02:44:54 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:54 --> Input Class Initialized
INFO - 2024-12-05 02:44:54 --> Language Class Initialized
ERROR - 2024-12-05 02:44:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:54 --> Config Class Initialized
INFO - 2024-12-05 02:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:54 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:54 --> URI Class Initialized
INFO - 2024-12-05 02:44:54 --> Router Class Initialized
INFO - 2024-12-05 02:44:54 --> Output Class Initialized
INFO - 2024-12-05 02:44:54 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:54 --> Input Class Initialized
INFO - 2024-12-05 02:44:54 --> Language Class Initialized
ERROR - 2024-12-05 02:44:54 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:44:54 --> Config Class Initialized
INFO - 2024-12-05 02:44:54 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:44:54 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:44:54 --> Utf8 Class Initialized
INFO - 2024-12-05 02:44:54 --> URI Class Initialized
INFO - 2024-12-05 02:44:54 --> Router Class Initialized
INFO - 2024-12-05 02:44:54 --> Output Class Initialized
INFO - 2024-12-05 02:44:54 --> Security Class Initialized
DEBUG - 2024-12-05 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:44:54 --> Input Class Initialized
INFO - 2024-12-05 02:44:54 --> Language Class Initialized
ERROR - 2024-12-05 02:44:54 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:45:35 --> Config Class Initialized
INFO - 2024-12-05 02:45:35 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:45:35 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:45:35 --> Utf8 Class Initialized
INFO - 2024-12-05 02:45:35 --> URI Class Initialized
INFO - 2024-12-05 02:45:35 --> Router Class Initialized
INFO - 2024-12-05 02:45:35 --> Output Class Initialized
INFO - 2024-12-05 02:45:35 --> Security Class Initialized
DEBUG - 2024-12-05 02:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:45:35 --> Input Class Initialized
INFO - 2024-12-05 02:45:35 --> Language Class Initialized
ERROR - 2024-12-05 02:45:35 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:45:36 --> Config Class Initialized
INFO - 2024-12-05 02:45:36 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:45:36 --> Utf8 Class Initialized
INFO - 2024-12-05 02:45:36 --> URI Class Initialized
INFO - 2024-12-05 02:45:36 --> Router Class Initialized
INFO - 2024-12-05 02:45:36 --> Config Class Initialized
INFO - 2024-12-05 02:45:36 --> Hooks Class Initialized
INFO - 2024-12-05 02:45:36 --> Output Class Initialized
DEBUG - 2024-12-05 02:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:45:36 --> Utf8 Class Initialized
INFO - 2024-12-05 02:45:36 --> URI Class Initialized
INFO - 2024-12-05 02:45:36 --> Router Class Initialized
INFO - 2024-12-05 02:45:36 --> Security Class Initialized
INFO - 2024-12-05 02:45:36 --> Config Class Initialized
DEBUG - 2024-12-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:45:36 --> Hooks Class Initialized
INFO - 2024-12-05 02:45:36 --> Input Class Initialized
INFO - 2024-12-05 02:45:36 --> Output Class Initialized
INFO - 2024-12-05 02:45:36 --> Language Class Initialized
ERROR - 2024-12-05 02:45:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
DEBUG - 2024-12-05 02:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:45:36 --> Utf8 Class Initialized
INFO - 2024-12-05 02:45:36 --> Security Class Initialized
DEBUG - 2024-12-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:45:36 --> Input Class Initialized
INFO - 2024-12-05 02:45:36 --> Language Class Initialized
ERROR - 2024-12-05 02:45:36 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:45:36 --> URI Class Initialized
INFO - 2024-12-05 02:45:36 --> Router Class Initialized
INFO - 2024-12-05 02:45:36 --> Output Class Initialized
INFO - 2024-12-05 02:45:36 --> Security Class Initialized
DEBUG - 2024-12-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:45:36 --> Input Class Initialized
INFO - 2024-12-05 02:45:36 --> Language Class Initialized
ERROR - 2024-12-05 02:45:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:45:36 --> Config Class Initialized
INFO - 2024-12-05 02:45:36 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:45:36 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:45:36 --> Utf8 Class Initialized
INFO - 2024-12-05 02:45:36 --> URI Class Initialized
INFO - 2024-12-05 02:45:36 --> Router Class Initialized
INFO - 2024-12-05 02:45:36 --> Output Class Initialized
INFO - 2024-12-05 02:45:36 --> Security Class Initialized
DEBUG - 2024-12-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:45:36 --> Input Class Initialized
INFO - 2024-12-05 02:45:36 --> Language Class Initialized
ERROR - 2024-12-05 02:45:36 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:46:28 --> Config Class Initialized
INFO - 2024-12-05 02:46:28 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:46:28 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:46:28 --> Utf8 Class Initialized
INFO - 2024-12-05 02:46:28 --> URI Class Initialized
INFO - 2024-12-05 02:46:28 --> Router Class Initialized
INFO - 2024-12-05 02:46:28 --> Output Class Initialized
INFO - 2024-12-05 02:46:28 --> Security Class Initialized
DEBUG - 2024-12-05 02:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:46:28 --> Input Class Initialized
INFO - 2024-12-05 02:46:28 --> Language Class Initialized
ERROR - 2024-12-05 02:46:28 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:46:28 --> Config Class Initialized
INFO - 2024-12-05 02:46:28 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:46:28 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:46:28 --> Utf8 Class Initialized
INFO - 2024-12-05 02:46:28 --> URI Class Initialized
INFO - 2024-12-05 02:46:28 --> Router Class Initialized
INFO - 2024-12-05 02:46:28 --> Output Class Initialized
INFO - 2024-12-05 02:46:28 --> Security Class Initialized
DEBUG - 2024-12-05 02:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:46:28 --> Input Class Initialized
INFO - 2024-12-05 02:46:28 --> Language Class Initialized
ERROR - 2024-12-05 02:46:28 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:46:29 --> Config Class Initialized
INFO - 2024-12-05 02:46:29 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:46:29 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:46:29 --> Utf8 Class Initialized
INFO - 2024-12-05 02:46:29 --> URI Class Initialized
INFO - 2024-12-05 02:46:29 --> Router Class Initialized
INFO - 2024-12-05 02:46:29 --> Output Class Initialized
INFO - 2024-12-05 02:46:29 --> Security Class Initialized
DEBUG - 2024-12-05 02:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:46:29 --> Input Class Initialized
INFO - 2024-12-05 02:46:29 --> Language Class Initialized
ERROR - 2024-12-05 02:46:29 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:46:29 --> Config Class Initialized
INFO - 2024-12-05 02:46:29 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:46:29 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:46:29 --> Utf8 Class Initialized
INFO - 2024-12-05 02:46:29 --> URI Class Initialized
INFO - 2024-12-05 02:46:29 --> Router Class Initialized
INFO - 2024-12-05 02:46:29 --> Output Class Initialized
INFO - 2024-12-05 02:46:29 --> Security Class Initialized
DEBUG - 2024-12-05 02:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:46:29 --> Input Class Initialized
INFO - 2024-12-05 02:46:29 --> Language Class Initialized
ERROR - 2024-12-05 02:46:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:46:29 --> Config Class Initialized
INFO - 2024-12-05 02:46:29 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:46:29 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:46:29 --> Utf8 Class Initialized
INFO - 2024-12-05 02:46:29 --> URI Class Initialized
INFO - 2024-12-05 02:46:29 --> Router Class Initialized
INFO - 2024-12-05 02:46:29 --> Output Class Initialized
INFO - 2024-12-05 02:46:29 --> Security Class Initialized
DEBUG - 2024-12-05 02:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:46:29 --> Input Class Initialized
INFO - 2024-12-05 02:46:29 --> Language Class Initialized
ERROR - 2024-12-05 02:46:29 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:47:24 --> Config Class Initialized
INFO - 2024-12-05 02:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:47:24 --> Utf8 Class Initialized
INFO - 2024-12-05 02:47:24 --> URI Class Initialized
INFO - 2024-12-05 02:47:24 --> Router Class Initialized
INFO - 2024-12-05 02:47:24 --> Output Class Initialized
INFO - 2024-12-05 02:47:24 --> Security Class Initialized
DEBUG - 2024-12-05 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:47:24 --> Input Class Initialized
INFO - 2024-12-05 02:47:24 --> Language Class Initialized
ERROR - 2024-12-05 02:47:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:47:24 --> Config Class Initialized
INFO - 2024-12-05 02:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:47:24 --> Utf8 Class Initialized
INFO - 2024-12-05 02:47:24 --> Config Class Initialized
INFO - 2024-12-05 02:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:47:24 --> Utf8 Class Initialized
INFO - 2024-12-05 02:47:24 --> URI Class Initialized
INFO - 2024-12-05 02:47:24 --> Router Class Initialized
INFO - 2024-12-05 02:47:24 --> Output Class Initialized
INFO - 2024-12-05 02:47:24 --> Config Class Initialized
INFO - 2024-12-05 02:47:24 --> Hooks Class Initialized
INFO - 2024-12-05 02:47:24 --> Security Class Initialized
DEBUG - 2024-12-05 02:47:24 --> UTF-8 Support Enabled
DEBUG - 2024-12-05 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:47:24 --> Utf8 Class Initialized
INFO - 2024-12-05 02:47:24 --> Input Class Initialized
INFO - 2024-12-05 02:47:24 --> Language Class Initialized
ERROR - 2024-12-05 02:47:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:47:24 --> URI Class Initialized
INFO - 2024-12-05 02:47:24 --> URI Class Initialized
INFO - 2024-12-05 02:47:24 --> Router Class Initialized
INFO - 2024-12-05 02:47:24 --> Router Class Initialized
INFO - 2024-12-05 02:47:24 --> Output Class Initialized
INFO - 2024-12-05 02:47:24 --> Output Class Initialized
INFO - 2024-12-05 02:47:24 --> Security Class Initialized
INFO - 2024-12-05 02:47:24 --> Security Class Initialized
DEBUG - 2024-12-05 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:47:24 --> Input Class Initialized
INFO - 2024-12-05 02:47:24 --> Language Class Initialized
DEBUG - 2024-12-05 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:47:24 --> Input Class Initialized
ERROR - 2024-12-05 02:47:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:47:24 --> Language Class Initialized
ERROR - 2024-12-05 02:47:24 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:47:24 --> Config Class Initialized
INFO - 2024-12-05 02:47:24 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:47:24 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:47:24 --> Utf8 Class Initialized
INFO - 2024-12-05 02:47:24 --> URI Class Initialized
INFO - 2024-12-05 02:47:24 --> Router Class Initialized
INFO - 2024-12-05 02:47:24 --> Output Class Initialized
INFO - 2024-12-05 02:47:24 --> Security Class Initialized
DEBUG - 2024-12-05 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:47:24 --> Input Class Initialized
INFO - 2024-12-05 02:47:24 --> Language Class Initialized
ERROR - 2024-12-05 02:47:24 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:48:16 --> Config Class Initialized
INFO - 2024-12-05 02:48:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:48:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:48:16 --> Utf8 Class Initialized
INFO - 2024-12-05 02:48:16 --> URI Class Initialized
INFO - 2024-12-05 02:48:16 --> Router Class Initialized
INFO - 2024-12-05 02:48:16 --> Output Class Initialized
INFO - 2024-12-05 02:48:16 --> Security Class Initialized
DEBUG - 2024-12-05 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:48:16 --> Input Class Initialized
INFO - 2024-12-05 02:48:16 --> Language Class Initialized
ERROR - 2024-12-05 02:48:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:48:16 --> Config Class Initialized
INFO - 2024-12-05 02:48:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:48:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:48:16 --> Utf8 Class Initialized
INFO - 2024-12-05 02:48:16 --> URI Class Initialized
INFO - 2024-12-05 02:48:16 --> Router Class Initialized
INFO - 2024-12-05 02:48:16 --> Config Class Initialized
INFO - 2024-12-05 02:48:16 --> Hooks Class Initialized
INFO - 2024-12-05 02:48:16 --> Output Class Initialized
INFO - 2024-12-05 02:48:16 --> Security Class Initialized
INFO - 2024-12-05 02:48:16 --> Config Class Initialized
INFO - 2024-12-05 02:48:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-05 02:48:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:48:16 --> Utf8 Class Initialized
INFO - 2024-12-05 02:48:16 --> Config Class Initialized
DEBUG - 2024-12-05 02:48:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:48:16 --> Utf8 Class Initialized
INFO - 2024-12-05 02:48:16 --> URI Class Initialized
INFO - 2024-12-05 02:48:16 --> Input Class Initialized
INFO - 2024-12-05 02:48:16 --> Language Class Initialized
INFO - 2024-12-05 02:48:16 --> URI Class Initialized
INFO - 2024-12-05 02:48:16 --> Router Class Initialized
ERROR - 2024-12-05 02:48:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:48:16 --> Router Class Initialized
INFO - 2024-12-05 02:48:16 --> Output Class Initialized
INFO - 2024-12-05 02:48:16 --> Hooks Class Initialized
INFO - 2024-12-05 02:48:16 --> Output Class Initialized
INFO - 2024-12-05 02:48:16 --> Security Class Initialized
INFO - 2024-12-05 02:48:16 --> Security Class Initialized
DEBUG - 2024-12-05 02:48:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:48:16 --> Utf8 Class Initialized
DEBUG - 2024-12-05 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:48:16 --> Input Class Initialized
DEBUG - 2024-12-05 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:48:16 --> Input Class Initialized
INFO - 2024-12-05 02:48:16 --> Language Class Initialized
INFO - 2024-12-05 02:48:16 --> Language Class Initialized
INFO - 2024-12-05 02:48:16 --> URI Class Initialized
ERROR - 2024-12-05 02:48:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
ERROR - 2024-12-05 02:48:16 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 02:48:16 --> Router Class Initialized
INFO - 2024-12-05 02:48:16 --> Output Class Initialized
INFO - 2024-12-05 02:48:16 --> Security Class Initialized
DEBUG - 2024-12-05 02:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:48:16 --> Input Class Initialized
INFO - 2024-12-05 02:48:16 --> Language Class Initialized
ERROR - 2024-12-05 02:48:16 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 02:51:58 --> Config Class Initialized
INFO - 2024-12-05 02:51:58 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:51:58 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:51:58 --> Utf8 Class Initialized
INFO - 2024-12-05 02:51:58 --> URI Class Initialized
DEBUG - 2024-12-05 02:51:58 --> No URI present. Default controller set.
INFO - 2024-12-05 02:51:58 --> Router Class Initialized
INFO - 2024-12-05 02:51:58 --> Output Class Initialized
INFO - 2024-12-05 02:51:58 --> Security Class Initialized
DEBUG - 2024-12-05 02:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:51:58 --> Input Class Initialized
INFO - 2024-12-05 02:51:58 --> Language Class Initialized
INFO - 2024-12-05 02:51:58 --> Loader Class Initialized
INFO - 2024-12-05 02:51:58 --> Helper loaded: url_helper
INFO - 2024-12-05 02:51:58 --> Helper loaded: file_helper
INFO - 2024-12-05 02:51:58 --> Helper loaded: security_helper
INFO - 2024-12-05 02:51:58 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:51:58 --> Database Driver Class Initialized
INFO - 2024-12-05 02:51:58 --> Email Class Initialized
DEBUG - 2024-12-05 02:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:51:58 --> Helper loaded: form_helper
INFO - 2024-12-05 02:51:58 --> Form Validation Class Initialized
INFO - 2024-12-05 02:51:58 --> Controller Class Initialized
DEBUG - 2024-12-05 02:51:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 02:51:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 02:51:58 --> Final output sent to browser
DEBUG - 2024-12-05 02:51:58 --> Total execution time: 0.4094
INFO - 2024-12-05 02:52:03 --> Config Class Initialized
INFO - 2024-12-05 02:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:03 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:03 --> URI Class Initialized
INFO - 2024-12-05 02:52:03 --> Router Class Initialized
INFO - 2024-12-05 02:52:03 --> Output Class Initialized
INFO - 2024-12-05 02:52:03 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:03 --> Input Class Initialized
INFO - 2024-12-05 02:52:03 --> Language Class Initialized
INFO - 2024-12-05 02:52:03 --> Loader Class Initialized
INFO - 2024-12-05 02:52:03 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:03 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:03 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:03 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:03 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:03 --> Controller Class Initialized
DEBUG - 2024-12-05 02:52:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-05 02:52:03 --> Config Class Initialized
INFO - 2024-12-05 02:52:03 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:03 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:03 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:03 --> URI Class Initialized
INFO - 2024-12-05 02:52:03 --> Router Class Initialized
INFO - 2024-12-05 02:52:03 --> Output Class Initialized
INFO - 2024-12-05 02:52:03 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:03 --> Input Class Initialized
INFO - 2024-12-05 02:52:03 --> Language Class Initialized
INFO - 2024-12-05 02:52:03 --> Loader Class Initialized
INFO - 2024-12-05 02:52:03 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:03 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:03 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:04 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:04 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:04 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:04 --> Controller Class Initialized
DEBUG - 2024-12-05 02:52:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 02:52:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 02:52:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 02:52:04 --> Final output sent to browser
DEBUG - 2024-12-05 02:52:04 --> Total execution time: 0.4263
INFO - 2024-12-05 02:52:10 --> Config Class Initialized
INFO - 2024-12-05 02:52:10 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:10 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:10 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:10 --> URI Class Initialized
INFO - 2024-12-05 02:52:10 --> Router Class Initialized
INFO - 2024-12-05 02:52:10 --> Output Class Initialized
INFO - 2024-12-05 02:52:10 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:10 --> Input Class Initialized
INFO - 2024-12-05 02:52:10 --> Language Class Initialized
INFO - 2024-12-05 02:52:10 --> Loader Class Initialized
INFO - 2024-12-05 02:52:10 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:10 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:10 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:10 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:10 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:10 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:10 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:10 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:10 --> Controller Class Initialized
DEBUG - 2024-12-05 02:52:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-05 02:52:11 --> Config Class Initialized
INFO - 2024-12-05 02:52:11 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:11 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:11 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:11 --> URI Class Initialized
INFO - 2024-12-05 02:52:11 --> Router Class Initialized
INFO - 2024-12-05 02:52:11 --> Output Class Initialized
INFO - 2024-12-05 02:52:11 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:11 --> Input Class Initialized
INFO - 2024-12-05 02:52:11 --> Language Class Initialized
INFO - 2024-12-05 02:52:11 --> Loader Class Initialized
INFO - 2024-12-05 02:52:11 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:11 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:11 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:11 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:11 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:12 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:12 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:12 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:12 --> Controller Class Initialized
DEBUG - 2024-12-05 02:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 02:52:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 02:52:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 02:52:12 --> Final output sent to browser
DEBUG - 2024-12-05 02:52:12 --> Total execution time: 0.4177
INFO - 2024-12-05 02:52:16 --> Config Class Initialized
INFO - 2024-12-05 02:52:16 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:16 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:16 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:16 --> URI Class Initialized
INFO - 2024-12-05 02:52:16 --> Router Class Initialized
INFO - 2024-12-05 02:52:16 --> Output Class Initialized
INFO - 2024-12-05 02:52:16 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:16 --> Input Class Initialized
INFO - 2024-12-05 02:52:16 --> Language Class Initialized
INFO - 2024-12-05 02:52:16 --> Loader Class Initialized
INFO - 2024-12-05 02:52:16 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:16 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:16 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:16 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:16 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:17 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:17 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:17 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:17 --> Controller Class Initialized
DEBUG - 2024-12-05 02:52:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-05 02:52:18 --> Config Class Initialized
INFO - 2024-12-05 02:52:18 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:18 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:18 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:18 --> URI Class Initialized
INFO - 2024-12-05 02:52:18 --> Router Class Initialized
INFO - 2024-12-05 02:52:18 --> Output Class Initialized
INFO - 2024-12-05 02:52:18 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:18 --> Input Class Initialized
INFO - 2024-12-05 02:52:18 --> Language Class Initialized
INFO - 2024-12-05 02:52:18 --> Loader Class Initialized
INFO - 2024-12-05 02:52:18 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:18 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:18 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:18 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:18 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:18 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:18 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:18 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:18 --> Controller Class Initialized
INFO - 2024-12-05 02:52:18 --> Model "Antrol_model" initialized
DEBUG - 2024-12-05 02:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-05 02:52:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-05 02:52:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-05 02:52:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-05 02:52:19 --> Final output sent to browser
DEBUG - 2024-12-05 02:52:19 --> Total execution time: 0.9830
INFO - 2024-12-05 02:52:30 --> Config Class Initialized
INFO - 2024-12-05 02:52:30 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:30 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:30 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:30 --> URI Class Initialized
INFO - 2024-12-05 02:52:30 --> Router Class Initialized
INFO - 2024-12-05 02:52:30 --> Output Class Initialized
INFO - 2024-12-05 02:52:30 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:30 --> Input Class Initialized
INFO - 2024-12-05 02:52:30 --> Language Class Initialized
INFO - 2024-12-05 02:52:30 --> Loader Class Initialized
INFO - 2024-12-05 02:52:30 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:30 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:30 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:30 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:30 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:31 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:31 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:31 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:31 --> Controller Class Initialized
INFO - 2024-12-05 02:52:31 --> Model "Antrol_model" initialized
DEBUG - 2024-12-05 02:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-05 02:52:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-05 02:52:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-05 02:52:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-05 02:52:31 --> Final output sent to browser
DEBUG - 2024-12-05 02:52:31 --> Total execution time: 0.9409
INFO - 2024-12-05 02:52:42 --> Config Class Initialized
INFO - 2024-12-05 02:52:42 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:52:42 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:52:42 --> Utf8 Class Initialized
INFO - 2024-12-05 02:52:42 --> URI Class Initialized
INFO - 2024-12-05 02:52:42 --> Router Class Initialized
INFO - 2024-12-05 02:52:42 --> Output Class Initialized
INFO - 2024-12-05 02:52:42 --> Security Class Initialized
DEBUG - 2024-12-05 02:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:52:42 --> Input Class Initialized
INFO - 2024-12-05 02:52:42 --> Language Class Initialized
INFO - 2024-12-05 02:52:42 --> Loader Class Initialized
INFO - 2024-12-05 02:52:42 --> Helper loaded: url_helper
INFO - 2024-12-05 02:52:42 --> Helper loaded: file_helper
INFO - 2024-12-05 02:52:42 --> Helper loaded: security_helper
INFO - 2024-12-05 02:52:42 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:52:42 --> Database Driver Class Initialized
INFO - 2024-12-05 02:52:42 --> Email Class Initialized
DEBUG - 2024-12-05 02:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:52:42 --> Helper loaded: form_helper
INFO - 2024-12-05 02:52:42 --> Form Validation Class Initialized
INFO - 2024-12-05 02:52:42 --> Controller Class Initialized
INFO - 2024-12-05 02:52:42 --> Model "Antrol_model" initialized
DEBUG - 2024-12-05 02:52:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-05 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-05 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-05 02:52:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-05 02:52:43 --> Final output sent to browser
DEBUG - 2024-12-05 02:52:43 --> Total execution time: 0.8936
INFO - 2024-12-05 02:59:51 --> Config Class Initialized
INFO - 2024-12-05 02:59:51 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:59:51 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:59:51 --> Utf8 Class Initialized
INFO - 2024-12-05 02:59:51 --> URI Class Initialized
INFO - 2024-12-05 02:59:51 --> Router Class Initialized
INFO - 2024-12-05 02:59:51 --> Output Class Initialized
INFO - 2024-12-05 02:59:51 --> Security Class Initialized
DEBUG - 2024-12-05 02:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:59:51 --> Input Class Initialized
INFO - 2024-12-05 02:59:51 --> Language Class Initialized
INFO - 2024-12-05 02:59:51 --> Loader Class Initialized
INFO - 2024-12-05 02:59:51 --> Helper loaded: url_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: file_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: security_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:59:51 --> Database Driver Class Initialized
INFO - 2024-12-05 02:59:51 --> Config Class Initialized
INFO - 2024-12-05 02:59:51 --> Hooks Class Initialized
DEBUG - 2024-12-05 02:59:51 --> UTF-8 Support Enabled
INFO - 2024-12-05 02:59:51 --> Utf8 Class Initialized
INFO - 2024-12-05 02:59:51 --> URI Class Initialized
INFO - 2024-12-05 02:59:51 --> Router Class Initialized
INFO - 2024-12-05 02:59:51 --> Output Class Initialized
INFO - 2024-12-05 02:59:51 --> Security Class Initialized
DEBUG - 2024-12-05 02:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 02:59:51 --> Input Class Initialized
INFO - 2024-12-05 02:59:51 --> Language Class Initialized
INFO - 2024-12-05 02:59:51 --> Loader Class Initialized
INFO - 2024-12-05 02:59:51 --> Helper loaded: url_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: file_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: security_helper
INFO - 2024-12-05 02:59:51 --> Helper loaded: wpu_helper
INFO - 2024-12-05 02:59:51 --> Database Driver Class Initialized
INFO - 2024-12-05 02:59:52 --> Email Class Initialized
DEBUG - 2024-12-05 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 02:59:52 --> Helper loaded: form_helper
INFO - 2024-12-05 02:59:52 --> Form Validation Class Initialized
INFO - 2024-12-05 02:59:52 --> Controller Class Initialized
INFO - 2024-12-05 02:59:52 --> Model "Antrol_model" initialized
DEBUG - 2024-12-05 02:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 02:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-05 02:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-05 02:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-05 02:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-05 02:59:52 --> Final output sent to browser
DEBUG - 2024-12-05 02:59:52 --> Total execution time: 1.0718
INFO - 2024-12-05 04:23:55 --> Config Class Initialized
INFO - 2024-12-05 04:23:55 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:23:55 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:23:55 --> Utf8 Class Initialized
INFO - 2024-12-05 04:23:55 --> URI Class Initialized
DEBUG - 2024-12-05 04:23:55 --> No URI present. Default controller set.
INFO - 2024-12-05 04:23:55 --> Router Class Initialized
INFO - 2024-12-05 04:23:55 --> Output Class Initialized
INFO - 2024-12-05 04:23:55 --> Security Class Initialized
DEBUG - 2024-12-05 04:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:23:55 --> Input Class Initialized
INFO - 2024-12-05 04:23:55 --> Language Class Initialized
INFO - 2024-12-05 04:23:55 --> Loader Class Initialized
INFO - 2024-12-05 04:23:55 --> Helper loaded: url_helper
INFO - 2024-12-05 04:23:55 --> Helper loaded: file_helper
INFO - 2024-12-05 04:23:55 --> Helper loaded: security_helper
INFO - 2024-12-05 04:23:55 --> Helper loaded: wpu_helper
INFO - 2024-12-05 04:23:55 --> Database Driver Class Initialized
INFO - 2024-12-05 04:23:55 --> Email Class Initialized
DEBUG - 2024-12-05 04:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 04:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 04:23:55 --> Helper loaded: form_helper
INFO - 2024-12-05 04:23:55 --> Form Validation Class Initialized
INFO - 2024-12-05 04:23:55 --> Controller Class Initialized
DEBUG - 2024-12-05 04:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 04:23:56 --> Config Class Initialized
INFO - 2024-12-05 04:23:56 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:23:56 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:23:56 --> Utf8 Class Initialized
INFO - 2024-12-05 04:23:56 --> URI Class Initialized
INFO - 2024-12-05 04:23:56 --> Router Class Initialized
INFO - 2024-12-05 04:23:56 --> Output Class Initialized
INFO - 2024-12-05 04:23:56 --> Security Class Initialized
DEBUG - 2024-12-05 04:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:23:56 --> Input Class Initialized
INFO - 2024-12-05 04:23:56 --> Language Class Initialized
ERROR - 2024-12-05 04:23:56 --> 404 Page Not Found: User/index
INFO - 2024-12-05 04:23:59 --> Config Class Initialized
INFO - 2024-12-05 04:23:59 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:23:59 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:23:59 --> Utf8 Class Initialized
INFO - 2024-12-05 04:23:59 --> URI Class Initialized
DEBUG - 2024-12-05 04:23:59 --> No URI present. Default controller set.
INFO - 2024-12-05 04:23:59 --> Router Class Initialized
INFO - 2024-12-05 04:23:59 --> Output Class Initialized
INFO - 2024-12-05 04:23:59 --> Security Class Initialized
DEBUG - 2024-12-05 04:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:23:59 --> Input Class Initialized
INFO - 2024-12-05 04:23:59 --> Language Class Initialized
INFO - 2024-12-05 04:23:59 --> Loader Class Initialized
INFO - 2024-12-05 04:23:59 --> Helper loaded: url_helper
INFO - 2024-12-05 04:23:59 --> Helper loaded: file_helper
INFO - 2024-12-05 04:23:59 --> Helper loaded: security_helper
INFO - 2024-12-05 04:23:59 --> Helper loaded: wpu_helper
INFO - 2024-12-05 04:23:59 --> Database Driver Class Initialized
INFO - 2024-12-05 04:23:59 --> Email Class Initialized
DEBUG - 2024-12-05 04:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 04:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 04:23:59 --> Helper loaded: form_helper
INFO - 2024-12-05 04:23:59 --> Form Validation Class Initialized
INFO - 2024-12-05 04:23:59 --> Controller Class Initialized
DEBUG - 2024-12-05 04:23:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 04:23:59 --> Config Class Initialized
INFO - 2024-12-05 04:23:59 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:23:59 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:23:59 --> Utf8 Class Initialized
INFO - 2024-12-05 04:23:59 --> URI Class Initialized
INFO - 2024-12-05 04:23:59 --> Router Class Initialized
INFO - 2024-12-05 04:23:59 --> Output Class Initialized
INFO - 2024-12-05 04:23:59 --> Security Class Initialized
DEBUG - 2024-12-05 04:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:23:59 --> Input Class Initialized
INFO - 2024-12-05 04:23:59 --> Language Class Initialized
ERROR - 2024-12-05 04:23:59 --> 404 Page Not Found: User/index
INFO - 2024-12-05 04:44:55 --> Config Class Initialized
INFO - 2024-12-05 04:44:55 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:44:55 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:44:55 --> Utf8 Class Initialized
INFO - 2024-12-05 04:44:55 --> URI Class Initialized
DEBUG - 2024-12-05 04:44:55 --> No URI present. Default controller set.
INFO - 2024-12-05 04:44:55 --> Router Class Initialized
INFO - 2024-12-05 04:44:55 --> Output Class Initialized
INFO - 2024-12-05 04:44:55 --> Security Class Initialized
DEBUG - 2024-12-05 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:44:55 --> Input Class Initialized
INFO - 2024-12-05 04:44:55 --> Language Class Initialized
INFO - 2024-12-05 04:44:55 --> Loader Class Initialized
INFO - 2024-12-05 04:44:55 --> Helper loaded: url_helper
INFO - 2024-12-05 04:44:55 --> Helper loaded: file_helper
INFO - 2024-12-05 04:44:55 --> Helper loaded: security_helper
INFO - 2024-12-05 04:44:55 --> Helper loaded: wpu_helper
INFO - 2024-12-05 04:44:55 --> Database Driver Class Initialized
INFO - 2024-12-05 04:44:55 --> Email Class Initialized
DEBUG - 2024-12-05 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 04:44:55 --> Helper loaded: form_helper
INFO - 2024-12-05 04:44:55 --> Form Validation Class Initialized
INFO - 2024-12-05 04:44:55 --> Controller Class Initialized
DEBUG - 2024-12-05 04:44:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 04:44:55 --> Config Class Initialized
INFO - 2024-12-05 04:44:55 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:44:55 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:44:55 --> Utf8 Class Initialized
INFO - 2024-12-05 04:44:55 --> URI Class Initialized
INFO - 2024-12-05 04:44:55 --> Router Class Initialized
INFO - 2024-12-05 04:44:55 --> Output Class Initialized
INFO - 2024-12-05 04:44:55 --> Security Class Initialized
DEBUG - 2024-12-05 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:44:55 --> Input Class Initialized
INFO - 2024-12-05 04:44:55 --> Language Class Initialized
ERROR - 2024-12-05 04:44:55 --> 404 Page Not Found: User/index
INFO - 2024-12-05 04:45:00 --> Config Class Initialized
INFO - 2024-12-05 04:45:00 --> Hooks Class Initialized
DEBUG - 2024-12-05 04:45:00 --> UTF-8 Support Enabled
INFO - 2024-12-05 04:45:00 --> Utf8 Class Initialized
INFO - 2024-12-05 04:45:00 --> URI Class Initialized
INFO - 2024-12-05 04:45:00 --> Router Class Initialized
INFO - 2024-12-05 04:45:00 --> Output Class Initialized
INFO - 2024-12-05 04:45:00 --> Security Class Initialized
DEBUG - 2024-12-05 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 04:45:00 --> Input Class Initialized
INFO - 2024-12-05 04:45:00 --> Language Class Initialized
ERROR - 2024-12-05 04:45:00 --> 404 Page Not Found: Login/index
INFO - 2024-12-05 06:08:12 --> Config Class Initialized
INFO - 2024-12-05 06:08:12 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:12 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:12 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:12 --> URI Class Initialized
DEBUG - 2024-12-05 06:08:12 --> No URI present. Default controller set.
INFO - 2024-12-05 06:08:12 --> Router Class Initialized
INFO - 2024-12-05 06:08:12 --> Output Class Initialized
INFO - 2024-12-05 06:08:12 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:12 --> Input Class Initialized
INFO - 2024-12-05 06:08:12 --> Language Class Initialized
INFO - 2024-12-05 06:08:12 --> Loader Class Initialized
INFO - 2024-12-05 06:08:12 --> Helper loaded: url_helper
INFO - 2024-12-05 06:08:12 --> Helper loaded: file_helper
INFO - 2024-12-05 06:08:12 --> Helper loaded: security_helper
INFO - 2024-12-05 06:08:12 --> Helper loaded: wpu_helper
INFO - 2024-12-05 06:08:12 --> Database Driver Class Initialized
INFO - 2024-12-05 06:08:13 --> Email Class Initialized
DEBUG - 2024-12-05 06:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 06:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 06:08:13 --> Helper loaded: form_helper
INFO - 2024-12-05 06:08:13 --> Form Validation Class Initialized
INFO - 2024-12-05 06:08:13 --> Controller Class Initialized
DEBUG - 2024-12-05 06:08:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 06:08:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 06:08:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 06:08:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 06:08:13 --> Final output sent to browser
DEBUG - 2024-12-05 06:08:13 --> Total execution time: 0.3832
INFO - 2024-12-05 06:08:14 --> Config Class Initialized
INFO - 2024-12-05 06:08:14 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:14 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:14 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:14 --> URI Class Initialized
DEBUG - 2024-12-05 06:08:14 --> No URI present. Default controller set.
INFO - 2024-12-05 06:08:14 --> Router Class Initialized
INFO - 2024-12-05 06:08:14 --> Output Class Initialized
INFO - 2024-12-05 06:08:14 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:14 --> Input Class Initialized
INFO - 2024-12-05 06:08:14 --> Language Class Initialized
INFO - 2024-12-05 06:08:14 --> Loader Class Initialized
INFO - 2024-12-05 06:08:14 --> Helper loaded: url_helper
INFO - 2024-12-05 06:08:14 --> Helper loaded: file_helper
INFO - 2024-12-05 06:08:14 --> Helper loaded: security_helper
INFO - 2024-12-05 06:08:14 --> Helper loaded: wpu_helper
INFO - 2024-12-05 06:08:14 --> Database Driver Class Initialized
INFO - 2024-12-05 06:08:14 --> Email Class Initialized
DEBUG - 2024-12-05 06:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 06:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 06:08:14 --> Helper loaded: form_helper
INFO - 2024-12-05 06:08:14 --> Form Validation Class Initialized
INFO - 2024-12-05 06:08:14 --> Controller Class Initialized
DEBUG - 2024-12-05 06:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 06:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 06:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 06:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 06:08:14 --> Final output sent to browser
DEBUG - 2024-12-05 06:08:14 --> Total execution time: 0.3977
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:26 --> Config Class Initialized
INFO - 2024-12-05 06:08:26 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:26 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:26 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:26 --> URI Class Initialized
INFO - 2024-12-05 06:08:26 --> Router Class Initialized
INFO - 2024-12-05 06:08:26 --> Output Class Initialized
INFO - 2024-12-05 06:08:26 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:26 --> Input Class Initialized
INFO - 2024-12-05 06:08:26 --> Language Class Initialized
ERROR - 2024-12-05 06:08:26 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:27 --> Config Class Initialized
INFO - 2024-12-05 06:08:27 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:27 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:27 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:27 --> URI Class Initialized
INFO - 2024-12-05 06:08:27 --> Router Class Initialized
INFO - 2024-12-05 06:08:27 --> Output Class Initialized
INFO - 2024-12-05 06:08:27 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:27 --> Input Class Initialized
INFO - 2024-12-05 06:08:27 --> Language Class Initialized
ERROR - 2024-12-05 06:08:27 --> 404 Page Not Found: Lottiehost/beaefe39-0ca5-485e-8d39-33659a1f5c5c
INFO - 2024-12-05 06:08:27 --> Config Class Initialized
INFO - 2024-12-05 06:08:27 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:27 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:27 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:27 --> URI Class Initialized
INFO - 2024-12-05 06:08:27 --> Router Class Initialized
INFO - 2024-12-05 06:08:27 --> Output Class Initialized
INFO - 2024-12-05 06:08:27 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:27 --> Input Class Initialized
INFO - 2024-12-05 06:08:27 --> Language Class Initialized
ERROR - 2024-12-05 06:08:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 06:08:27 --> Config Class Initialized
INFO - 2024-12-05 06:08:27 --> Hooks Class Initialized
DEBUG - 2024-12-05 06:08:27 --> UTF-8 Support Enabled
INFO - 2024-12-05 06:08:27 --> Utf8 Class Initialized
INFO - 2024-12-05 06:08:27 --> URI Class Initialized
INFO - 2024-12-05 06:08:27 --> Router Class Initialized
INFO - 2024-12-05 06:08:27 --> Output Class Initialized
INFO - 2024-12-05 06:08:27 --> Security Class Initialized
DEBUG - 2024-12-05 06:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 06:08:27 --> Input Class Initialized
INFO - 2024-12-05 06:08:27 --> Language Class Initialized
ERROR - 2024-12-05 06:08:27 --> 404 Page Not Found: Antrolrsudhabdulazizmarabahancom/assets
INFO - 2024-12-05 07:22:44 --> Config Class Initialized
INFO - 2024-12-05 07:22:44 --> Hooks Class Initialized
DEBUG - 2024-12-05 07:22:44 --> UTF-8 Support Enabled
INFO - 2024-12-05 07:22:44 --> Utf8 Class Initialized
INFO - 2024-12-05 07:22:44 --> URI Class Initialized
DEBUG - 2024-12-05 07:22:44 --> No URI present. Default controller set.
INFO - 2024-12-05 07:22:44 --> Router Class Initialized
INFO - 2024-12-05 07:22:44 --> Output Class Initialized
INFO - 2024-12-05 07:22:44 --> Security Class Initialized
DEBUG - 2024-12-05 07:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 07:22:44 --> Input Class Initialized
INFO - 2024-12-05 07:22:44 --> Language Class Initialized
INFO - 2024-12-05 07:22:44 --> Loader Class Initialized
INFO - 2024-12-05 07:22:44 --> Helper loaded: url_helper
INFO - 2024-12-05 07:22:44 --> Helper loaded: file_helper
INFO - 2024-12-05 07:22:44 --> Helper loaded: security_helper
INFO - 2024-12-05 07:22:44 --> Helper loaded: wpu_helper
INFO - 2024-12-05 07:22:44 --> Database Driver Class Initialized
INFO - 2024-12-05 07:22:44 --> Email Class Initialized
DEBUG - 2024-12-05 07:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 07:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 07:22:44 --> Helper loaded: form_helper
INFO - 2024-12-05 07:22:44 --> Form Validation Class Initialized
INFO - 2024-12-05 07:22:44 --> Controller Class Initialized
DEBUG - 2024-12-05 07:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 07:22:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 07:22:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 07:22:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 07:22:44 --> Final output sent to browser
DEBUG - 2024-12-05 07:22:44 --> Total execution time: 0.4307
INFO - 2024-12-05 07:22:45 --> Config Class Initialized
INFO - 2024-12-05 07:22:45 --> Hooks Class Initialized
DEBUG - 2024-12-05 07:22:45 --> UTF-8 Support Enabled
INFO - 2024-12-05 07:22:45 --> Utf8 Class Initialized
INFO - 2024-12-05 07:22:45 --> URI Class Initialized
DEBUG - 2024-12-05 07:22:45 --> No URI present. Default controller set.
INFO - 2024-12-05 07:22:45 --> Router Class Initialized
INFO - 2024-12-05 07:22:45 --> Output Class Initialized
INFO - 2024-12-05 07:22:45 --> Security Class Initialized
DEBUG - 2024-12-05 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 07:22:45 --> Input Class Initialized
INFO - 2024-12-05 07:22:45 --> Language Class Initialized
INFO - 2024-12-05 07:22:45 --> Loader Class Initialized
INFO - 2024-12-05 07:22:45 --> Helper loaded: url_helper
INFO - 2024-12-05 07:22:45 --> Helper loaded: file_helper
INFO - 2024-12-05 07:22:45 --> Helper loaded: security_helper
INFO - 2024-12-05 07:22:45 --> Helper loaded: wpu_helper
INFO - 2024-12-05 07:22:45 --> Database Driver Class Initialized
INFO - 2024-12-05 07:22:46 --> Email Class Initialized
DEBUG - 2024-12-05 07:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 07:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 07:22:46 --> Helper loaded: form_helper
INFO - 2024-12-05 07:22:46 --> Form Validation Class Initialized
INFO - 2024-12-05 07:22:46 --> Controller Class Initialized
DEBUG - 2024-12-05 07:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 07:22:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 07:22:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 07:22:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 07:22:46 --> Final output sent to browser
DEBUG - 2024-12-05 07:22:46 --> Total execution time: 0.4222
INFO - 2024-12-05 13:40:50 --> Config Class Initialized
INFO - 2024-12-05 13:40:50 --> Hooks Class Initialized
DEBUG - 2024-12-05 13:40:50 --> UTF-8 Support Enabled
INFO - 2024-12-05 13:40:50 --> Utf8 Class Initialized
INFO - 2024-12-05 13:40:50 --> URI Class Initialized
DEBUG - 2024-12-05 13:40:50 --> No URI present. Default controller set.
INFO - 2024-12-05 13:40:50 --> Router Class Initialized
INFO - 2024-12-05 13:40:50 --> Output Class Initialized
INFO - 2024-12-05 13:40:50 --> Security Class Initialized
DEBUG - 2024-12-05 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 13:40:50 --> Input Class Initialized
INFO - 2024-12-05 13:40:50 --> Language Class Initialized
INFO - 2024-12-05 13:40:50 --> Loader Class Initialized
INFO - 2024-12-05 13:40:50 --> Helper loaded: url_helper
INFO - 2024-12-05 13:40:50 --> Helper loaded: file_helper
INFO - 2024-12-05 13:40:50 --> Helper loaded: security_helper
INFO - 2024-12-05 13:40:50 --> Helper loaded: wpu_helper
INFO - 2024-12-05 13:40:50 --> Database Driver Class Initialized
INFO - 2024-12-05 13:40:50 --> Email Class Initialized
DEBUG - 2024-12-05 13:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 13:40:51 --> Helper loaded: form_helper
INFO - 2024-12-05 13:40:51 --> Form Validation Class Initialized
INFO - 2024-12-05 13:40:51 --> Controller Class Initialized
DEBUG - 2024-12-05 13:40:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 13:40:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 13:40:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 13:40:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 13:40:51 --> Final output sent to browser
DEBUG - 2024-12-05 13:40:51 --> Total execution time: 0.4113
INFO - 2024-12-05 15:06:47 --> Config Class Initialized
INFO - 2024-12-05 15:06:47 --> Hooks Class Initialized
DEBUG - 2024-12-05 15:06:47 --> UTF-8 Support Enabled
INFO - 2024-12-05 15:06:47 --> Utf8 Class Initialized
INFO - 2024-12-05 15:06:47 --> URI Class Initialized
INFO - 2024-12-05 15:06:47 --> Router Class Initialized
INFO - 2024-12-05 15:06:47 --> Output Class Initialized
INFO - 2024-12-05 15:06:47 --> Security Class Initialized
DEBUG - 2024-12-05 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 15:06:47 --> Input Class Initialized
INFO - 2024-12-05 15:06:47 --> Language Class Initialized
ERROR - 2024-12-05 15:06:47 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-05 15:06:56 --> Config Class Initialized
INFO - 2024-12-05 15:06:56 --> Hooks Class Initialized
DEBUG - 2024-12-05 15:06:56 --> UTF-8 Support Enabled
INFO - 2024-12-05 15:06:56 --> Utf8 Class Initialized
INFO - 2024-12-05 15:06:56 --> URI Class Initialized
DEBUG - 2024-12-05 15:06:56 --> No URI present. Default controller set.
INFO - 2024-12-05 15:06:56 --> Router Class Initialized
INFO - 2024-12-05 15:06:56 --> Output Class Initialized
INFO - 2024-12-05 15:06:56 --> Security Class Initialized
DEBUG - 2024-12-05 15:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 15:06:56 --> Input Class Initialized
INFO - 2024-12-05 15:06:56 --> Language Class Initialized
INFO - 2024-12-05 15:06:56 --> Loader Class Initialized
INFO - 2024-12-05 15:06:56 --> Helper loaded: url_helper
INFO - 2024-12-05 15:06:56 --> Helper loaded: file_helper
INFO - 2024-12-05 15:06:56 --> Helper loaded: security_helper
INFO - 2024-12-05 15:06:56 --> Helper loaded: wpu_helper
INFO - 2024-12-05 15:06:56 --> Database Driver Class Initialized
INFO - 2024-12-05 15:06:56 --> Email Class Initialized
DEBUG - 2024-12-05 15:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-05 15:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 15:06:56 --> Helper loaded: form_helper
INFO - 2024-12-05 15:06:56 --> Form Validation Class Initialized
INFO - 2024-12-05 15:06:56 --> Controller Class Initialized
DEBUG - 2024-12-05 15:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-05 15:06:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-05 15:06:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-05 15:06:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-05 15:06:56 --> Final output sent to browser
DEBUG - 2024-12-05 15:06:56 --> Total execution time: 0.4163
