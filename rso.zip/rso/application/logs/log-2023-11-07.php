<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-07 03:06:51 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 03:59:59 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 04:45:55 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:46:05 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:46:06 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:46:06 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:46:06 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:48:16 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:48:26 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:48:27 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:48:57 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:55:02 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:55:06 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:57:02 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:57:57 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:58:10 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:58:17 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 04:59:15 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:03:00 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:03:31 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:03:42 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:06:33 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:07:00 --> Severity: Compile Error --> Cannot redeclare Admin::adddetailfaktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 722
ERROR - 2023-11-07 05:07:01 --> Severity: Compile Error --> Cannot redeclare Admin::adddetailfaktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 722
ERROR - 2023-11-07 05:07:03 --> Severity: Compile Error --> Cannot redeclare Admin::adddetailfaktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 722
ERROR - 2023-11-07 05:07:09 --> Severity: Compile Error --> Cannot redeclare Admin::adddetailfaktur() C:\xampp\htdocs\simba\application\controllers\Admin.php 722
ERROR - 2023-11-07 05:07:35 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:10:17 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:13:40 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:14:41 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:14:43 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:15:28 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:17:21 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:17:44 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:18:02 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:21:11 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:22:18 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:24:27 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:25:23 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:28:42 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:29:50 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:31:28 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:38:54 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:39:52 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:40:55 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:44:40 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:46:10 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 703
ERROR - 2023-11-07 05:46:25 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:46:25 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 703
ERROR - 2023-11-07 05:49:27 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 703
ERROR - 2023-11-07 05:49:35 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:49:35 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 703
ERROR - 2023-11-07 05:50:09 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:50:40 --> Severity: error --> Exception: syntax error, unexpected '$back_uri' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\simba\application\controllers\Admin.php 729
ERROR - 2023-11-07 05:50:43 --> Severity: error --> Exception: syntax error, unexpected '$back_uri' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\simba\application\controllers\Admin.php 729
ERROR - 2023-11-07 05:50:50 --> Severity: error --> Exception: syntax error, unexpected '$back_uri' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\simba\application\controllers\Admin.php 728
ERROR - 2023-11-07 05:51:23 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:51:28 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:51:43 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:52:13 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:52:55 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:53:14 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:55:19 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:55:19 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:55:51 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:55:51 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:56:09 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:56:10 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 678
ERROR - 2023-11-07 05:56:34 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:57:12 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 708
ERROR - 2023-11-07 05:57:20 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 708
ERROR - 2023-11-07 05:57:38 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 708
ERROR - 2023-11-07 05:57:39 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 708
ERROR - 2023-11-07 05:58:34 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:59:35 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 05:59:52 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:00:47 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 745
ERROR - 2023-11-07 06:01:07 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 745
ERROR - 2023-11-07 06:02:58 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 743
ERROR - 2023-11-07 06:03:05 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 743
ERROR - 2023-11-07 06:03:20 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 755
ERROR - 2023-11-07 06:03:42 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 755
ERROR - 2023-11-07 06:05:04 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:06:02 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:06:50 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 757
ERROR - 2023-11-07 06:07:13 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:09:12 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\simba\application\controllers\Admin.php 748
ERROR - 2023-11-07 06:10:29 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:10:29 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 737
ERROR - 2023-11-07 06:10:52 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:11:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\controllers\Admin.php 755
ERROR - 2023-11-07 06:11:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\controllers\Admin.php 755
ERROR - 2023-11-07 06:14:01 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:14:15 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:16:36 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:17:07 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:21:22 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:21:38 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:21:40 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:22:30 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:22:38 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:23:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\simba\application\controllers\Admin.php 763
ERROR - 2023-11-07 06:24:19 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:26:48 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:27:33 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:28:29 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:28:43 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:29:00 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:30:58 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:31:38 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:33:33 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:35:07 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:36:37 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:36:37 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 727
ERROR - 2023-11-07 06:37:01 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 727
ERROR - 2023-11-07 06:37:06 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 727
ERROR - 2023-11-07 06:37:20 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:37:50 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:40:13 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:40:13 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 727
ERROR - 2023-11-07 06:40:26 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:43:52 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:44:18 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:45:09 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT * FROM `tbl_detail_faktur` WHERE `no_faktur` = admin
ERROR - 2023-11-07 06:46:24 --> 404 Page Not Found: Detailfaktur/saveDetailFaktur
ERROR - 2023-11-07 06:46:25 --> 404 Page Not Found: Detailfaktur/saveDetailFaktur
ERROR - 2023-11-07 06:49:41 --> 404 Page Not Found: 
