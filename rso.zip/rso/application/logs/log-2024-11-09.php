<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-09 02:24:05 --> Config Class Initialized
INFO - 2024-11-09 02:24:05 --> Hooks Class Initialized
DEBUG - 2024-11-09 02:24:05 --> UTF-8 Support Enabled
INFO - 2024-11-09 02:24:05 --> Utf8 Class Initialized
INFO - 2024-11-09 02:24:05 --> URI Class Initialized
DEBUG - 2024-11-09 02:24:05 --> No URI present. Default controller set.
INFO - 2024-11-09 02:24:05 --> Router Class Initialized
INFO - 2024-11-09 02:24:05 --> Output Class Initialized
INFO - 2024-11-09 02:24:05 --> Security Class Initialized
DEBUG - 2024-11-09 02:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 02:24:05 --> Input Class Initialized
INFO - 2024-11-09 02:24:05 --> Language Class Initialized
INFO - 2024-11-09 02:24:05 --> Loader Class Initialized
INFO - 2024-11-09 02:24:05 --> Helper loaded: url_helper
INFO - 2024-11-09 02:24:05 --> Helper loaded: file_helper
INFO - 2024-11-09 02:24:05 --> Helper loaded: security_helper
INFO - 2024-11-09 02:24:05 --> Helper loaded: wpu_helper
INFO - 2024-11-09 02:24:05 --> Database Driver Class Initialized
ERROR - 2024-11-09 02:24:05 --> Unable to connect to the database
INFO - 2024-11-09 02:24:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-09 02:42:57 --> Config Class Initialized
INFO - 2024-11-09 02:42:57 --> Hooks Class Initialized
DEBUG - 2024-11-09 02:42:57 --> UTF-8 Support Enabled
INFO - 2024-11-09 02:42:57 --> Utf8 Class Initialized
INFO - 2024-11-09 02:42:57 --> URI Class Initialized
DEBUG - 2024-11-09 02:42:57 --> No URI present. Default controller set.
INFO - 2024-11-09 02:42:57 --> Router Class Initialized
INFO - 2024-11-09 02:42:57 --> Output Class Initialized
INFO - 2024-11-09 02:42:57 --> Security Class Initialized
DEBUG - 2024-11-09 02:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 02:42:57 --> Input Class Initialized
INFO - 2024-11-09 02:42:57 --> Language Class Initialized
INFO - 2024-11-09 02:42:57 --> Loader Class Initialized
INFO - 2024-11-09 02:42:57 --> Helper loaded: url_helper
INFO - 2024-11-09 02:42:57 --> Helper loaded: file_helper
INFO - 2024-11-09 02:42:57 --> Helper loaded: security_helper
INFO - 2024-11-09 02:42:57 --> Helper loaded: wpu_helper
INFO - 2024-11-09 02:42:57 --> Database Driver Class Initialized
ERROR - 2024-11-09 02:42:57 --> Unable to connect to the database
INFO - 2024-11-09 02:42:57 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-09 07:57:09 --> Config Class Initialized
INFO - 2024-11-09 07:57:09 --> Hooks Class Initialized
DEBUG - 2024-11-09 07:57:09 --> UTF-8 Support Enabled
INFO - 2024-11-09 07:57:09 --> Utf8 Class Initialized
INFO - 2024-11-09 07:57:09 --> URI Class Initialized
INFO - 2024-11-09 07:57:09 --> Router Class Initialized
INFO - 2024-11-09 07:57:09 --> Output Class Initialized
INFO - 2024-11-09 07:57:09 --> Security Class Initialized
DEBUG - 2024-11-09 07:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 07:57:09 --> Input Class Initialized
INFO - 2024-11-09 07:57:09 --> Language Class Initialized
INFO - 2024-11-09 07:57:09 --> Loader Class Initialized
INFO - 2024-11-09 07:57:09 --> Helper loaded: url_helper
INFO - 2024-11-09 07:57:09 --> Helper loaded: file_helper
INFO - 2024-11-09 07:57:09 --> Helper loaded: security_helper
INFO - 2024-11-09 07:57:09 --> Helper loaded: wpu_helper
INFO - 2024-11-09 07:57:09 --> Database Driver Class Initialized
INFO - 2024-11-09 07:59:31 --> Config Class Initialized
INFO - 2024-11-09 07:59:31 --> Hooks Class Initialized
DEBUG - 2024-11-09 07:59:31 --> UTF-8 Support Enabled
INFO - 2024-11-09 07:59:31 --> Utf8 Class Initialized
INFO - 2024-11-09 07:59:31 --> URI Class Initialized
INFO - 2024-11-09 07:59:31 --> Router Class Initialized
INFO - 2024-11-09 07:59:31 --> Output Class Initialized
INFO - 2024-11-09 07:59:31 --> Security Class Initialized
DEBUG - 2024-11-09 07:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 07:59:31 --> Input Class Initialized
INFO - 2024-11-09 07:59:31 --> Language Class Initialized
INFO - 2024-11-09 07:59:31 --> Loader Class Initialized
INFO - 2024-11-09 07:59:31 --> Helper loaded: url_helper
INFO - 2024-11-09 07:59:31 --> Helper loaded: file_helper
INFO - 2024-11-09 07:59:31 --> Helper loaded: security_helper
INFO - 2024-11-09 07:59:31 --> Helper loaded: wpu_helper
INFO - 2024-11-09 07:59:31 --> Database Driver Class Initialized
INFO - 2024-11-09 07:59:53 --> Config Class Initialized
INFO - 2024-11-09 07:59:53 --> Hooks Class Initialized
DEBUG - 2024-11-09 07:59:53 --> UTF-8 Support Enabled
INFO - 2024-11-09 07:59:53 --> Utf8 Class Initialized
INFO - 2024-11-09 07:59:53 --> URI Class Initialized
INFO - 2024-11-09 07:59:53 --> Router Class Initialized
INFO - 2024-11-09 07:59:53 --> Output Class Initialized
INFO - 2024-11-09 07:59:53 --> Security Class Initialized
DEBUG - 2024-11-09 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 07:59:53 --> Input Class Initialized
INFO - 2024-11-09 07:59:53 --> Language Class Initialized
INFO - 2024-11-09 07:59:53 --> Loader Class Initialized
INFO - 2024-11-09 07:59:53 --> Helper loaded: url_helper
INFO - 2024-11-09 07:59:53 --> Helper loaded: file_helper
INFO - 2024-11-09 07:59:53 --> Helper loaded: security_helper
INFO - 2024-11-09 07:59:53 --> Helper loaded: wpu_helper
INFO - 2024-11-09 07:59:53 --> Database Driver Class Initialized
INFO - 2024-11-09 07:59:55 --> Config Class Initialized
INFO - 2024-11-09 07:59:55 --> Hooks Class Initialized
DEBUG - 2024-11-09 07:59:55 --> UTF-8 Support Enabled
INFO - 2024-11-09 07:59:55 --> Utf8 Class Initialized
INFO - 2024-11-09 07:59:55 --> URI Class Initialized
DEBUG - 2024-11-09 07:59:55 --> No URI present. Default controller set.
INFO - 2024-11-09 07:59:55 --> Router Class Initialized
INFO - 2024-11-09 07:59:55 --> Output Class Initialized
INFO - 2024-11-09 07:59:55 --> Security Class Initialized
DEBUG - 2024-11-09 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 07:59:55 --> Input Class Initialized
INFO - 2024-11-09 07:59:55 --> Language Class Initialized
INFO - 2024-11-09 07:59:55 --> Loader Class Initialized
INFO - 2024-11-09 07:59:55 --> Helper loaded: url_helper
INFO - 2024-11-09 07:59:55 --> Helper loaded: file_helper
INFO - 2024-11-09 07:59:55 --> Helper loaded: security_helper
INFO - 2024-11-09 07:59:55 --> Helper loaded: wpu_helper
INFO - 2024-11-09 07:59:55 --> Database Driver Class Initialized
INFO - 2024-11-09 08:00:05 --> Config Class Initialized
INFO - 2024-11-09 08:00:05 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:00:05 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:00:05 --> Utf8 Class Initialized
INFO - 2024-11-09 08:00:05 --> URI Class Initialized
INFO - 2024-11-09 08:00:05 --> Router Class Initialized
INFO - 2024-11-09 08:00:05 --> Output Class Initialized
INFO - 2024-11-09 08:00:05 --> Security Class Initialized
DEBUG - 2024-11-09 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:00:05 --> Input Class Initialized
INFO - 2024-11-09 08:00:05 --> Language Class Initialized
INFO - 2024-11-09 08:00:05 --> Loader Class Initialized
INFO - 2024-11-09 08:00:05 --> Helper loaded: url_helper
INFO - 2024-11-09 08:00:05 --> Helper loaded: file_helper
INFO - 2024-11-09 08:00:05 --> Helper loaded: security_helper
INFO - 2024-11-09 08:00:05 --> Helper loaded: wpu_helper
INFO - 2024-11-09 08:00:05 --> Database Driver Class Initialized
INFO - 2024-11-09 08:03:10 --> Config Class Initialized
INFO - 2024-11-09 08:03:10 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:03:10 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:03:10 --> Utf8 Class Initialized
INFO - 2024-11-09 08:03:10 --> URI Class Initialized
INFO - 2024-11-09 08:03:10 --> Router Class Initialized
INFO - 2024-11-09 08:03:10 --> Output Class Initialized
INFO - 2024-11-09 08:03:10 --> Security Class Initialized
DEBUG - 2024-11-09 08:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:03:10 --> Input Class Initialized
INFO - 2024-11-09 08:03:10 --> Language Class Initialized
INFO - 2024-11-09 08:03:10 --> Loader Class Initialized
INFO - 2024-11-09 08:03:10 --> Helper loaded: url_helper
INFO - 2024-11-09 08:03:10 --> Helper loaded: file_helper
INFO - 2024-11-09 08:03:10 --> Helper loaded: security_helper
INFO - 2024-11-09 08:03:10 --> Helper loaded: wpu_helper
INFO - 2024-11-09 08:03:10 --> Database Driver Class Initialized
INFO - 2024-11-09 08:20:13 --> Config Class Initialized
INFO - 2024-11-09 08:20:13 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:20:13 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:20:13 --> Utf8 Class Initialized
INFO - 2024-11-09 08:20:13 --> URI Class Initialized
DEBUG - 2024-11-09 08:20:13 --> No URI present. Default controller set.
INFO - 2024-11-09 08:20:13 --> Router Class Initialized
INFO - 2024-11-09 08:20:14 --> Output Class Initialized
INFO - 2024-11-09 08:20:14 --> Security Class Initialized
DEBUG - 2024-11-09 08:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:20:14 --> Input Class Initialized
INFO - 2024-11-09 08:20:14 --> Language Class Initialized
INFO - 2024-11-09 08:20:14 --> Loader Class Initialized
INFO - 2024-11-09 08:20:14 --> Helper loaded: url_helper
INFO - 2024-11-09 08:20:14 --> Helper loaded: file_helper
INFO - 2024-11-09 08:20:14 --> Helper loaded: security_helper
INFO - 2024-11-09 08:20:14 --> Helper loaded: wpu_helper
INFO - 2024-11-09 08:20:14 --> Database Driver Class Initialized
INFO - 2024-11-09 08:20:53 --> Config Class Initialized
INFO - 2024-11-09 08:20:53 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:20:53 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:20:53 --> Utf8 Class Initialized
INFO - 2024-11-09 08:20:53 --> URI Class Initialized
DEBUG - 2024-11-09 08:20:53 --> No URI present. Default controller set.
INFO - 2024-11-09 08:20:53 --> Router Class Initialized
INFO - 2024-11-09 08:20:53 --> Output Class Initialized
INFO - 2024-11-09 08:20:53 --> Security Class Initialized
DEBUG - 2024-11-09 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:20:53 --> Input Class Initialized
INFO - 2024-11-09 08:20:53 --> Language Class Initialized
INFO - 2024-11-09 08:20:53 --> Loader Class Initialized
INFO - 2024-11-09 08:20:53 --> Helper loaded: url_helper
INFO - 2024-11-09 08:20:53 --> Helper loaded: file_helper
INFO - 2024-11-09 08:20:53 --> Helper loaded: security_helper
INFO - 2024-11-09 08:20:53 --> Helper loaded: wpu_helper
INFO - 2024-11-09 08:20:53 --> Database Driver Class Initialized
INFO - 2024-11-09 19:10:32 --> Config Class Initialized
INFO - 2024-11-09 19:10:32 --> Hooks Class Initialized
DEBUG - 2024-11-09 19:10:32 --> UTF-8 Support Enabled
INFO - 2024-11-09 19:10:32 --> Utf8 Class Initialized
INFO - 2024-11-09 19:10:32 --> URI Class Initialized
INFO - 2024-11-09 19:10:32 --> Router Class Initialized
INFO - 2024-11-09 19:10:32 --> Output Class Initialized
INFO - 2024-11-09 19:10:32 --> Security Class Initialized
DEBUG - 2024-11-09 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 19:10:32 --> Input Class Initialized
INFO - 2024-11-09 19:10:32 --> Language Class Initialized
INFO - 2024-11-09 19:10:32 --> Loader Class Initialized
INFO - 2024-11-09 19:10:32 --> Helper loaded: url_helper
INFO - 2024-11-09 19:10:32 --> Helper loaded: file_helper
INFO - 2024-11-09 19:10:32 --> Helper loaded: security_helper
INFO - 2024-11-09 19:10:32 --> Helper loaded: wpu_helper
INFO - 2024-11-09 19:10:32 --> Database Driver Class Initialized
