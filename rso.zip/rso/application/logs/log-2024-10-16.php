<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-16 00:13:41 --> Config Class Initialized
INFO - 2024-10-16 00:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-16 00:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-16 00:13:41 --> Utf8 Class Initialized
INFO - 2024-10-16 00:13:41 --> URI Class Initialized
DEBUG - 2024-10-16 00:13:41 --> No URI present. Default controller set.
INFO - 2024-10-16 00:13:41 --> Router Class Initialized
INFO - 2024-10-16 00:13:41 --> Output Class Initialized
INFO - 2024-10-16 00:13:41 --> Security Class Initialized
DEBUG - 2024-10-16 00:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 00:13:41 --> Input Class Initialized
INFO - 2024-10-16 00:13:41 --> Language Class Initialized
INFO - 2024-10-16 00:13:41 --> Loader Class Initialized
INFO - 2024-10-16 00:13:41 --> Helper loaded: url_helper
INFO - 2024-10-16 00:13:41 --> Helper loaded: file_helper
INFO - 2024-10-16 00:13:41 --> Helper loaded: security_helper
INFO - 2024-10-16 00:13:41 --> Helper loaded: wpu_helper
INFO - 2024-10-16 00:13:41 --> Database Driver Class Initialized
ERROR - 2024-10-16 00:13:48 --> Unable to connect to the database
INFO - 2024-10-16 00:13:48 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-16 08:51:31 --> Config Class Initialized
INFO - 2024-10-16 08:51:31 --> Hooks Class Initialized
DEBUG - 2024-10-16 08:51:31 --> UTF-8 Support Enabled
INFO - 2024-10-16 08:51:31 --> Utf8 Class Initialized
INFO - 2024-10-16 08:51:31 --> URI Class Initialized
DEBUG - 2024-10-16 08:51:31 --> No URI present. Default controller set.
INFO - 2024-10-16 08:51:31 --> Router Class Initialized
INFO - 2024-10-16 08:51:31 --> Output Class Initialized
INFO - 2024-10-16 08:51:31 --> Security Class Initialized
DEBUG - 2024-10-16 08:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 08:51:31 --> Input Class Initialized
INFO - 2024-10-16 08:51:31 --> Language Class Initialized
INFO - 2024-10-16 08:51:31 --> Loader Class Initialized
INFO - 2024-10-16 08:51:31 --> Helper loaded: url_helper
INFO - 2024-10-16 08:51:31 --> Helper loaded: file_helper
INFO - 2024-10-16 08:51:31 --> Helper loaded: security_helper
INFO - 2024-10-16 08:51:31 --> Helper loaded: wpu_helper
INFO - 2024-10-16 08:51:31 --> Database Driver Class Initialized
INFO - 2024-10-16 08:51:31 --> Email Class Initialized
DEBUG - 2024-10-16 08:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-16 08:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-16 08:51:31 --> Helper loaded: form_helper
INFO - 2024-10-16 08:51:31 --> Form Validation Class Initialized
INFO - 2024-10-16 08:51:31 --> Controller Class Initialized
DEBUG - 2024-10-16 08:51:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-16 08:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-16 08:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-16 08:51:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-16 08:51:31 --> Final output sent to browser
DEBUG - 2024-10-16 08:51:31 --> Total execution time: 0.2270
INFO - 2024-10-16 17:02:40 --> Config Class Initialized
INFO - 2024-10-16 17:02:40 --> Hooks Class Initialized
DEBUG - 2024-10-16 17:02:40 --> UTF-8 Support Enabled
INFO - 2024-10-16 17:02:40 --> Utf8 Class Initialized
INFO - 2024-10-16 17:02:40 --> URI Class Initialized
DEBUG - 2024-10-16 17:02:40 --> No URI present. Default controller set.
INFO - 2024-10-16 17:02:40 --> Router Class Initialized
INFO - 2024-10-16 17:02:40 --> Output Class Initialized
INFO - 2024-10-16 17:02:40 --> Security Class Initialized
DEBUG - 2024-10-16 17:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 17:02:40 --> Input Class Initialized
INFO - 2024-10-16 17:02:40 --> Language Class Initialized
INFO - 2024-10-16 17:02:40 --> Loader Class Initialized
INFO - 2024-10-16 17:02:40 --> Helper loaded: url_helper
INFO - 2024-10-16 17:02:40 --> Helper loaded: file_helper
INFO - 2024-10-16 17:02:40 --> Helper loaded: security_helper
INFO - 2024-10-16 17:02:40 --> Helper loaded: wpu_helper
INFO - 2024-10-16 17:02:40 --> Database Driver Class Initialized
INFO - 2024-10-16 17:02:40 --> Email Class Initialized
DEBUG - 2024-10-16 17:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-16 17:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-16 17:02:40 --> Helper loaded: form_helper
INFO - 2024-10-16 17:02:40 --> Form Validation Class Initialized
INFO - 2024-10-16 17:02:40 --> Controller Class Initialized
DEBUG - 2024-10-16 17:02:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-16 17:02:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-16 17:02:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-16 17:02:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-16 17:02:40 --> Final output sent to browser
DEBUG - 2024-10-16 17:02:40 --> Total execution time: 0.2164
INFO - 2024-10-16 17:02:41 --> Config Class Initialized
INFO - 2024-10-16 17:02:41 --> Hooks Class Initialized
DEBUG - 2024-10-16 17:02:41 --> UTF-8 Support Enabled
INFO - 2024-10-16 17:02:41 --> Utf8 Class Initialized
INFO - 2024-10-16 17:02:41 --> URI Class Initialized
INFO - 2024-10-16 17:02:41 --> Router Class Initialized
INFO - 2024-10-16 17:02:41 --> Output Class Initialized
INFO - 2024-10-16 17:02:41 --> Security Class Initialized
DEBUG - 2024-10-16 17:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 17:02:41 --> Input Class Initialized
INFO - 2024-10-16 17:02:41 --> Language Class Initialized
ERROR - 2024-10-16 17:02:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-16 23:12:41 --> Config Class Initialized
INFO - 2024-10-16 23:12:41 --> Hooks Class Initialized
DEBUG - 2024-10-16 23:12:41 --> UTF-8 Support Enabled
INFO - 2024-10-16 23:12:41 --> Utf8 Class Initialized
INFO - 2024-10-16 23:12:41 --> URI Class Initialized
DEBUG - 2024-10-16 23:12:41 --> No URI present. Default controller set.
INFO - 2024-10-16 23:12:41 --> Router Class Initialized
INFO - 2024-10-16 23:12:41 --> Output Class Initialized
INFO - 2024-10-16 23:12:41 --> Security Class Initialized
DEBUG - 2024-10-16 23:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 23:12:41 --> Input Class Initialized
INFO - 2024-10-16 23:12:41 --> Language Class Initialized
INFO - 2024-10-16 23:12:41 --> Loader Class Initialized
INFO - 2024-10-16 23:12:41 --> Helper loaded: url_helper
INFO - 2024-10-16 23:12:41 --> Helper loaded: file_helper
INFO - 2024-10-16 23:12:41 --> Helper loaded: security_helper
INFO - 2024-10-16 23:12:41 --> Helper loaded: wpu_helper
INFO - 2024-10-16 23:12:41 --> Database Driver Class Initialized
INFO - 2024-10-16 23:12:42 --> Email Class Initialized
DEBUG - 2024-10-16 23:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-16 23:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-16 23:12:42 --> Helper loaded: form_helper
INFO - 2024-10-16 23:12:42 --> Form Validation Class Initialized
INFO - 2024-10-16 23:12:42 --> Controller Class Initialized
DEBUG - 2024-10-16 23:12:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-16 23:12:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-16 23:12:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-16 23:12:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-16 23:12:42 --> Final output sent to browser
DEBUG - 2024-10-16 23:12:42 --> Total execution time: 0.2324
INFO - 2024-10-16 23:26:36 --> Config Class Initialized
INFO - 2024-10-16 23:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-16 23:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-16 23:26:36 --> Utf8 Class Initialized
INFO - 2024-10-16 23:26:36 --> URI Class Initialized
DEBUG - 2024-10-16 23:26:36 --> No URI present. Default controller set.
INFO - 2024-10-16 23:26:36 --> Router Class Initialized
INFO - 2024-10-16 23:26:36 --> Output Class Initialized
INFO - 2024-10-16 23:26:36 --> Security Class Initialized
DEBUG - 2024-10-16 23:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-16 23:26:36 --> Input Class Initialized
INFO - 2024-10-16 23:26:36 --> Language Class Initialized
INFO - 2024-10-16 23:26:36 --> Loader Class Initialized
INFO - 2024-10-16 23:26:36 --> Helper loaded: url_helper
INFO - 2024-10-16 23:26:36 --> Helper loaded: file_helper
INFO - 2024-10-16 23:26:36 --> Helper loaded: security_helper
INFO - 2024-10-16 23:26:36 --> Helper loaded: wpu_helper
INFO - 2024-10-16 23:26:36 --> Database Driver Class Initialized
INFO - 2024-10-16 23:26:36 --> Email Class Initialized
DEBUG - 2024-10-16 23:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-16 23:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-16 23:26:36 --> Helper loaded: form_helper
INFO - 2024-10-16 23:26:36 --> Form Validation Class Initialized
INFO - 2024-10-16 23:26:36 --> Controller Class Initialized
DEBUG - 2024-10-16 23:26:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-16 23:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-16 23:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-16 23:26:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-16 23:26:36 --> Final output sent to browser
DEBUG - 2024-10-16 23:26:36 --> Total execution time: 0.2428
