<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-06 06:37:48 --> Config Class Initialized
INFO - 2024-10-06 06:37:48 --> Hooks Class Initialized
DEBUG - 2024-10-06 06:37:48 --> UTF-8 Support Enabled
INFO - 2024-10-06 06:37:48 --> Utf8 Class Initialized
INFO - 2024-10-06 06:37:48 --> URI Class Initialized
DEBUG - 2024-10-06 06:37:48 --> No URI present. Default controller set.
INFO - 2024-10-06 06:37:48 --> Router Class Initialized
INFO - 2024-10-06 06:37:48 --> Output Class Initialized
INFO - 2024-10-06 06:37:48 --> Security Class Initialized
DEBUG - 2024-10-06 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 06:37:48 --> Input Class Initialized
INFO - 2024-10-06 06:37:48 --> Language Class Initialized
INFO - 2024-10-06 06:37:48 --> Loader Class Initialized
INFO - 2024-10-06 06:37:48 --> Helper loaded: url_helper
INFO - 2024-10-06 06:37:48 --> Helper loaded: file_helper
INFO - 2024-10-06 06:37:48 --> Helper loaded: security_helper
INFO - 2024-10-06 06:37:48 --> Helper loaded: wpu_helper
INFO - 2024-10-06 06:37:48 --> Database Driver Class Initialized
INFO - 2024-10-06 06:37:49 --> Email Class Initialized
DEBUG - 2024-10-06 06:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 06:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 06:37:49 --> Helper loaded: form_helper
INFO - 2024-10-06 06:37:49 --> Form Validation Class Initialized
INFO - 2024-10-06 06:37:49 --> Controller Class Initialized
DEBUG - 2024-10-06 06:37:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 06:37:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-06 06:37:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-06 06:37:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-06 06:37:49 --> Final output sent to browser
DEBUG - 2024-10-06 06:37:49 --> Total execution time: 0.2202
INFO - 2024-10-06 06:37:53 --> Config Class Initialized
INFO - 2024-10-06 06:37:53 --> Hooks Class Initialized
DEBUG - 2024-10-06 06:37:53 --> UTF-8 Support Enabled
INFO - 2024-10-06 06:37:53 --> Utf8 Class Initialized
INFO - 2024-10-06 06:37:53 --> URI Class Initialized
DEBUG - 2024-10-06 06:37:53 --> No URI present. Default controller set.
INFO - 2024-10-06 06:37:53 --> Router Class Initialized
INFO - 2024-10-06 06:37:53 --> Output Class Initialized
INFO - 2024-10-06 06:37:53 --> Security Class Initialized
DEBUG - 2024-10-06 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 06:37:53 --> Input Class Initialized
INFO - 2024-10-06 06:37:53 --> Language Class Initialized
INFO - 2024-10-06 06:37:53 --> Loader Class Initialized
INFO - 2024-10-06 06:37:53 --> Helper loaded: url_helper
INFO - 2024-10-06 06:37:53 --> Helper loaded: file_helper
INFO - 2024-10-06 06:37:53 --> Helper loaded: security_helper
INFO - 2024-10-06 06:37:53 --> Helper loaded: wpu_helper
INFO - 2024-10-06 06:37:53 --> Database Driver Class Initialized
INFO - 2024-10-06 06:37:53 --> Email Class Initialized
DEBUG - 2024-10-06 06:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 06:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 06:37:53 --> Helper loaded: form_helper
INFO - 2024-10-06 06:37:53 --> Form Validation Class Initialized
INFO - 2024-10-06 06:37:53 --> Controller Class Initialized
DEBUG - 2024-10-06 06:37:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 06:37:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-06 06:37:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-06 06:37:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-06 06:37:53 --> Final output sent to browser
DEBUG - 2024-10-06 06:37:53 --> Total execution time: 0.2181
INFO - 2024-10-06 09:22:45 --> Config Class Initialized
INFO - 2024-10-06 09:22:45 --> Hooks Class Initialized
DEBUG - 2024-10-06 09:22:45 --> UTF-8 Support Enabled
INFO - 2024-10-06 09:22:45 --> Utf8 Class Initialized
INFO - 2024-10-06 09:22:45 --> URI Class Initialized
DEBUG - 2024-10-06 09:22:45 --> No URI present. Default controller set.
INFO - 2024-10-06 09:22:45 --> Router Class Initialized
INFO - 2024-10-06 09:22:45 --> Output Class Initialized
INFO - 2024-10-06 09:22:45 --> Security Class Initialized
DEBUG - 2024-10-06 09:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 09:22:45 --> Input Class Initialized
INFO - 2024-10-06 09:22:45 --> Language Class Initialized
INFO - 2024-10-06 09:22:45 --> Loader Class Initialized
INFO - 2024-10-06 09:22:45 --> Helper loaded: url_helper
INFO - 2024-10-06 09:22:45 --> Helper loaded: file_helper
INFO - 2024-10-06 09:22:45 --> Helper loaded: security_helper
INFO - 2024-10-06 09:22:45 --> Helper loaded: wpu_helper
INFO - 2024-10-06 09:22:45 --> Database Driver Class Initialized
ERROR - 2024-10-06 09:22:52 --> Unable to connect to the database
INFO - 2024-10-06 09:22:52 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-06 18:33:58 --> Config Class Initialized
INFO - 2024-10-06 18:33:58 --> Hooks Class Initialized
DEBUG - 2024-10-06 18:33:58 --> UTF-8 Support Enabled
INFO - 2024-10-06 18:33:58 --> Utf8 Class Initialized
INFO - 2024-10-06 18:33:58 --> URI Class Initialized
DEBUG - 2024-10-06 18:33:58 --> No URI present. Default controller set.
INFO - 2024-10-06 18:33:58 --> Router Class Initialized
INFO - 2024-10-06 18:33:58 --> Output Class Initialized
INFO - 2024-10-06 18:33:58 --> Security Class Initialized
DEBUG - 2024-10-06 18:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 18:33:58 --> Input Class Initialized
INFO - 2024-10-06 18:33:58 --> Language Class Initialized
INFO - 2024-10-06 18:33:58 --> Loader Class Initialized
INFO - 2024-10-06 18:33:58 --> Helper loaded: url_helper
INFO - 2024-10-06 18:33:58 --> Helper loaded: file_helper
INFO - 2024-10-06 18:33:58 --> Helper loaded: security_helper
INFO - 2024-10-06 18:33:58 --> Helper loaded: wpu_helper
INFO - 2024-10-06 18:33:58 --> Database Driver Class Initialized
INFO - 2024-10-06 18:33:59 --> Email Class Initialized
DEBUG - 2024-10-06 18:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 18:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 18:33:59 --> Helper loaded: form_helper
INFO - 2024-10-06 18:33:59 --> Form Validation Class Initialized
INFO - 2024-10-06 18:33:59 --> Controller Class Initialized
DEBUG - 2024-10-06 18:33:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 18:33:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-06 18:33:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-06 18:33:59 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-06 18:33:59 --> Final output sent to browser
DEBUG - 2024-10-06 18:33:59 --> Total execution time: 0.2247
INFO - 2024-10-06 18:41:47 --> Config Class Initialized
INFO - 2024-10-06 18:41:47 --> Hooks Class Initialized
DEBUG - 2024-10-06 18:41:47 --> UTF-8 Support Enabled
INFO - 2024-10-06 18:41:47 --> Utf8 Class Initialized
INFO - 2024-10-06 18:41:47 --> URI Class Initialized
DEBUG - 2024-10-06 18:41:47 --> No URI present. Default controller set.
INFO - 2024-10-06 18:41:47 --> Router Class Initialized
INFO - 2024-10-06 18:41:47 --> Output Class Initialized
INFO - 2024-10-06 18:41:47 --> Security Class Initialized
DEBUG - 2024-10-06 18:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 18:41:47 --> Input Class Initialized
INFO - 2024-10-06 18:41:47 --> Language Class Initialized
INFO - 2024-10-06 18:41:47 --> Loader Class Initialized
INFO - 2024-10-06 18:41:47 --> Helper loaded: url_helper
INFO - 2024-10-06 18:41:47 --> Helper loaded: file_helper
INFO - 2024-10-06 18:41:47 --> Helper loaded: security_helper
INFO - 2024-10-06 18:41:47 --> Helper loaded: wpu_helper
INFO - 2024-10-06 18:41:47 --> Database Driver Class Initialized
INFO - 2024-10-06 18:41:47 --> Email Class Initialized
DEBUG - 2024-10-06 18:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 18:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 18:41:47 --> Helper loaded: form_helper
INFO - 2024-10-06 18:41:47 --> Form Validation Class Initialized
INFO - 2024-10-06 18:41:47 --> Controller Class Initialized
DEBUG - 2024-10-06 18:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 18:41:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-06 18:41:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-06 18:41:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-06 18:41:47 --> Final output sent to browser
DEBUG - 2024-10-06 18:41:47 --> Total execution time: 0.2377
INFO - 2024-10-06 21:33:23 --> Config Class Initialized
INFO - 2024-10-06 21:33:23 --> Hooks Class Initialized
DEBUG - 2024-10-06 21:33:23 --> UTF-8 Support Enabled
INFO - 2024-10-06 21:33:23 --> Utf8 Class Initialized
INFO - 2024-10-06 21:33:23 --> URI Class Initialized
DEBUG - 2024-10-06 21:33:23 --> No URI present. Default controller set.
INFO - 2024-10-06 21:33:23 --> Router Class Initialized
INFO - 2024-10-06 21:33:23 --> Output Class Initialized
INFO - 2024-10-06 21:33:23 --> Security Class Initialized
DEBUG - 2024-10-06 21:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 21:33:23 --> Input Class Initialized
INFO - 2024-10-06 21:33:23 --> Language Class Initialized
INFO - 2024-10-06 21:33:23 --> Loader Class Initialized
INFO - 2024-10-06 21:33:23 --> Helper loaded: url_helper
INFO - 2024-10-06 21:33:23 --> Helper loaded: file_helper
INFO - 2024-10-06 21:33:23 --> Helper loaded: security_helper
INFO - 2024-10-06 21:33:23 --> Helper loaded: wpu_helper
INFO - 2024-10-06 21:33:23 --> Database Driver Class Initialized
INFO - 2024-10-06 21:33:24 --> Config Class Initialized
INFO - 2024-10-06 21:33:24 --> Hooks Class Initialized
DEBUG - 2024-10-06 21:33:24 --> UTF-8 Support Enabled
INFO - 2024-10-06 21:33:24 --> Utf8 Class Initialized
INFO - 2024-10-06 21:33:24 --> URI Class Initialized
DEBUG - 2024-10-06 21:33:24 --> No URI present. Default controller set.
INFO - 2024-10-06 21:33:24 --> Router Class Initialized
INFO - 2024-10-06 21:33:24 --> Output Class Initialized
INFO - 2024-10-06 21:33:24 --> Security Class Initialized
DEBUG - 2024-10-06 21:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 21:33:24 --> Input Class Initialized
INFO - 2024-10-06 21:33:24 --> Language Class Initialized
INFO - 2024-10-06 21:33:24 --> Loader Class Initialized
INFO - 2024-10-06 21:33:24 --> Helper loaded: url_helper
INFO - 2024-10-06 21:33:24 --> Helper loaded: file_helper
INFO - 2024-10-06 21:33:24 --> Helper loaded: security_helper
INFO - 2024-10-06 21:33:24 --> Helper loaded: wpu_helper
INFO - 2024-10-06 21:33:24 --> Database Driver Class Initialized
ERROR - 2024-10-06 21:33:26 --> Unable to connect to the database
ERROR - 2024-10-06 21:33:26 --> Unable to connect to the database
INFO - 2024-10-06 21:33:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-06 21:33:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-06 22:30:51 --> Config Class Initialized
INFO - 2024-10-06 22:30:51 --> Hooks Class Initialized
DEBUG - 2024-10-06 22:30:51 --> UTF-8 Support Enabled
INFO - 2024-10-06 22:30:51 --> Utf8 Class Initialized
INFO - 2024-10-06 22:30:51 --> URI Class Initialized
DEBUG - 2024-10-06 22:30:51 --> No URI present. Default controller set.
INFO - 2024-10-06 22:30:51 --> Router Class Initialized
INFO - 2024-10-06 22:30:51 --> Output Class Initialized
INFO - 2024-10-06 22:30:51 --> Security Class Initialized
DEBUG - 2024-10-06 22:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 22:30:51 --> Input Class Initialized
INFO - 2024-10-06 22:30:51 --> Language Class Initialized
INFO - 2024-10-06 22:30:51 --> Loader Class Initialized
INFO - 2024-10-06 22:30:51 --> Helper loaded: url_helper
INFO - 2024-10-06 22:30:51 --> Helper loaded: file_helper
INFO - 2024-10-06 22:30:51 --> Helper loaded: security_helper
INFO - 2024-10-06 22:30:51 --> Helper loaded: wpu_helper
INFO - 2024-10-06 22:30:51 --> Database Driver Class Initialized
INFO - 2024-10-06 22:30:51 --> Email Class Initialized
DEBUG - 2024-10-06 22:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 22:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 22:30:51 --> Helper loaded: form_helper
INFO - 2024-10-06 22:30:51 --> Form Validation Class Initialized
INFO - 2024-10-06 22:30:51 --> Controller Class Initialized
DEBUG - 2024-10-06 22:30:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 22:30:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-06 22:30:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-06 22:30:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-06 22:30:51 --> Final output sent to browser
DEBUG - 2024-10-06 22:30:51 --> Total execution time: 0.2424
INFO - 2024-10-06 22:30:53 --> Config Class Initialized
INFO - 2024-10-06 22:30:53 --> Hooks Class Initialized
DEBUG - 2024-10-06 22:30:53 --> UTF-8 Support Enabled
INFO - 2024-10-06 22:30:53 --> Utf8 Class Initialized
INFO - 2024-10-06 22:30:53 --> URI Class Initialized
INFO - 2024-10-06 22:30:53 --> Router Class Initialized
INFO - 2024-10-06 22:30:53 --> Output Class Initialized
INFO - 2024-10-06 22:30:53 --> Security Class Initialized
DEBUG - 2024-10-06 22:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 22:30:53 --> Input Class Initialized
INFO - 2024-10-06 22:30:53 --> Language Class Initialized
INFO - 2024-10-06 22:30:53 --> Loader Class Initialized
INFO - 2024-10-06 22:30:53 --> Helper loaded: url_helper
INFO - 2024-10-06 22:30:53 --> Helper loaded: file_helper
INFO - 2024-10-06 22:30:53 --> Helper loaded: security_helper
INFO - 2024-10-06 22:30:53 --> Helper loaded: wpu_helper
INFO - 2024-10-06 22:30:53 --> Database Driver Class Initialized
INFO - 2024-10-06 22:30:53 --> Email Class Initialized
DEBUG - 2024-10-06 22:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 22:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 22:30:53 --> Helper loaded: form_helper
INFO - 2024-10-06 22:30:53 --> Form Validation Class Initialized
INFO - 2024-10-06 22:30:53 --> Controller Class Initialized
DEBUG - 2024-10-06 22:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 22:30:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-06 22:30:54 --> Config Class Initialized
INFO - 2024-10-06 22:30:54 --> Hooks Class Initialized
DEBUG - 2024-10-06 22:30:54 --> UTF-8 Support Enabled
INFO - 2024-10-06 22:30:54 --> Utf8 Class Initialized
INFO - 2024-10-06 22:30:54 --> URI Class Initialized
INFO - 2024-10-06 22:30:54 --> Router Class Initialized
INFO - 2024-10-06 22:30:54 --> Output Class Initialized
INFO - 2024-10-06 22:30:54 --> Security Class Initialized
DEBUG - 2024-10-06 22:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-06 22:30:54 --> Input Class Initialized
INFO - 2024-10-06 22:30:54 --> Language Class Initialized
INFO - 2024-10-06 22:30:54 --> Loader Class Initialized
INFO - 2024-10-06 22:30:54 --> Helper loaded: url_helper
INFO - 2024-10-06 22:30:54 --> Helper loaded: file_helper
INFO - 2024-10-06 22:30:54 --> Helper loaded: security_helper
INFO - 2024-10-06 22:30:54 --> Helper loaded: wpu_helper
INFO - 2024-10-06 22:30:54 --> Database Driver Class Initialized
INFO - 2024-10-06 22:30:54 --> Email Class Initialized
DEBUG - 2024-10-06 22:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-06 22:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-06 22:30:54 --> Helper loaded: form_helper
INFO - 2024-10-06 22:30:54 --> Form Validation Class Initialized
INFO - 2024-10-06 22:30:54 --> Controller Class Initialized
INFO - 2024-10-06 22:30:54 --> Model "Antrol_model" initialized
DEBUG - 2024-10-06 22:30:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-06 22:30:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-10-06 22:30:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-10-06 22:30:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-10-06 22:30:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-10-06 22:30:55 --> Final output sent to browser
DEBUG - 2024-10-06 22:30:55 --> Total execution time: 0.5748
