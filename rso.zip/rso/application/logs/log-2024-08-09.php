<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-09 09:48:09 --> Config Class Initialized
INFO - 2024-08-09 09:48:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:09 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:09 --> URI Class Initialized
DEBUG - 2024-08-09 09:48:09 --> No URI present. Default controller set.
INFO - 2024-08-09 09:48:09 --> Router Class Initialized
INFO - 2024-08-09 09:48:09 --> Output Class Initialized
INFO - 2024-08-09 09:48:09 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:09 --> Input Class Initialized
INFO - 2024-08-09 09:48:09 --> Language Class Initialized
INFO - 2024-08-09 09:48:09 --> Loader Class Initialized
INFO - 2024-08-09 09:48:09 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:09 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:09 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:09 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:09 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:09 --> Controller Class Initialized
DEBUG - 2024-08-09 09:48:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:09 --> Config Class Initialized
INFO - 2024-08-09 09:48:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:09 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:09 --> URI Class Initialized
INFO - 2024-08-09 09:48:09 --> Router Class Initialized
INFO - 2024-08-09 09:48:09 --> Output Class Initialized
INFO - 2024-08-09 09:48:09 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:09 --> Input Class Initialized
INFO - 2024-08-09 09:48:09 --> Language Class Initialized
INFO - 2024-08-09 09:48:09 --> Loader Class Initialized
INFO - 2024-08-09 09:48:09 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:09 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:09 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:09 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:09 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:09 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:09 --> Controller Class Initialized
INFO - 2024-08-09 09:48:09 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:09 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:09 --> File loaded: C:\xampp\htdocs\simba\application\views\user/dashboard.php
INFO - 2024-08-09 09:48:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:09 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:09 --> Total execution time: 0.2483
INFO - 2024-08-09 09:48:15 --> Config Class Initialized
INFO - 2024-08-09 09:48:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:15 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:15 --> URI Class Initialized
INFO - 2024-08-09 09:48:15 --> Router Class Initialized
INFO - 2024-08-09 09:48:15 --> Output Class Initialized
INFO - 2024-08-09 09:48:15 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:15 --> Input Class Initialized
INFO - 2024-08-09 09:48:15 --> Language Class Initialized
INFO - 2024-08-09 09:48:15 --> Loader Class Initialized
INFO - 2024-08-09 09:48:15 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:15 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:15 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:15 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:15 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:15 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:15 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:15 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:15 --> Controller Class Initialized
INFO - 2024-08-09 09:48:15 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:15 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-09 09:48:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:15 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:15 --> Total execution time: 0.0697
INFO - 2024-08-09 09:48:16 --> Config Class Initialized
INFO - 2024-08-09 09:48:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:16 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:16 --> URI Class Initialized
INFO - 2024-08-09 09:48:16 --> Router Class Initialized
INFO - 2024-08-09 09:48:16 --> Output Class Initialized
INFO - 2024-08-09 09:48:16 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:16 --> Input Class Initialized
INFO - 2024-08-09 09:48:16 --> Language Class Initialized
INFO - 2024-08-09 09:48:16 --> Loader Class Initialized
INFO - 2024-08-09 09:48:16 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:16 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:16 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:16 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:16 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:16 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:16 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:16 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:16 --> Controller Class Initialized
INFO - 2024-08-09 09:48:16 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:16 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:16 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 09:48:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:16 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:16 --> Total execution time: 0.0941
INFO - 2024-08-09 09:48:17 --> Config Class Initialized
INFO - 2024-08-09 09:48:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:17 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:17 --> URI Class Initialized
INFO - 2024-08-09 09:48:17 --> Router Class Initialized
INFO - 2024-08-09 09:48:17 --> Output Class Initialized
INFO - 2024-08-09 09:48:17 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:17 --> Input Class Initialized
INFO - 2024-08-09 09:48:17 --> Language Class Initialized
INFO - 2024-08-09 09:48:17 --> Loader Class Initialized
INFO - 2024-08-09 09:48:17 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:17 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:17 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:17 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:17 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:17 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:17 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:17 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:17 --> Controller Class Initialized
INFO - 2024-08-09 09:48:17 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:17 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:17 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/role.php
INFO - 2024-08-09 09:48:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:17 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:17 --> Total execution time: 0.0644
INFO - 2024-08-09 09:48:18 --> Config Class Initialized
INFO - 2024-08-09 09:48:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:18 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:18 --> URI Class Initialized
INFO - 2024-08-09 09:48:18 --> Router Class Initialized
INFO - 2024-08-09 09:48:18 --> Output Class Initialized
INFO - 2024-08-09 09:48:18 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:18 --> Input Class Initialized
INFO - 2024-08-09 09:48:18 --> Language Class Initialized
INFO - 2024-08-09 09:48:18 --> Loader Class Initialized
INFO - 2024-08-09 09:48:18 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:18 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:18 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:18 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:18 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:18 --> Controller Class Initialized
INFO - 2024-08-09 09:48:18 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/user.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:18 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:18 --> Total execution time: 0.0762
INFO - 2024-08-09 09:48:18 --> Config Class Initialized
INFO - 2024-08-09 09:48:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:18 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:18 --> URI Class Initialized
INFO - 2024-08-09 09:48:18 --> Router Class Initialized
INFO - 2024-08-09 09:48:18 --> Output Class Initialized
INFO - 2024-08-09 09:48:18 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:18 --> Input Class Initialized
INFO - 2024-08-09 09:48:18 --> Language Class Initialized
INFO - 2024-08-09 09:48:18 --> Loader Class Initialized
INFO - 2024-08-09 09:48:18 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:18 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:18 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:18 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:18 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:18 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:18 --> Controller Class Initialized
INFO - 2024-08-09 09:48:18 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:18 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-09 09:48:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:18 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:18 --> Total execution time: 0.0567
INFO - 2024-08-09 09:48:19 --> Config Class Initialized
INFO - 2024-08-09 09:48:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:19 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:19 --> URI Class Initialized
INFO - 2024-08-09 09:48:19 --> Router Class Initialized
INFO - 2024-08-09 09:48:19 --> Output Class Initialized
INFO - 2024-08-09 09:48:19 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:19 --> Input Class Initialized
INFO - 2024-08-09 09:48:19 --> Language Class Initialized
INFO - 2024-08-09 09:48:19 --> Loader Class Initialized
INFO - 2024-08-09 09:48:19 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:19 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:19 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:19 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:19 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:19 --> Controller Class Initialized
INFO - 2024-08-09 09:48:19 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:19 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:19 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 09:48:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:19 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:19 --> Total execution time: 0.0654
INFO - 2024-08-09 09:48:19 --> Config Class Initialized
INFO - 2024-08-09 09:48:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:19 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:19 --> URI Class Initialized
INFO - 2024-08-09 09:48:19 --> Router Class Initialized
INFO - 2024-08-09 09:48:19 --> Output Class Initialized
INFO - 2024-08-09 09:48:19 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:19 --> Input Class Initialized
INFO - 2024-08-09 09:48:19 --> Language Class Initialized
INFO - 2024-08-09 09:48:19 --> Loader Class Initialized
INFO - 2024-08-09 09:48:19 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:19 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:19 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:20 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:20 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:20 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:20 --> Controller Class Initialized
INFO - 2024-08-09 09:48:20 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:20 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:20 --> Total execution time: 0.0674
INFO - 2024-08-09 09:48:20 --> Config Class Initialized
INFO - 2024-08-09 09:48:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:20 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:20 --> URI Class Initialized
INFO - 2024-08-09 09:48:20 --> Router Class Initialized
INFO - 2024-08-09 09:48:20 --> Output Class Initialized
INFO - 2024-08-09 09:48:20 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:20 --> Input Class Initialized
INFO - 2024-08-09 09:48:20 --> Language Class Initialized
INFO - 2024-08-09 09:48:20 --> Loader Class Initialized
INFO - 2024-08-09 09:48:20 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:20 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:20 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:20 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:20 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:20 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:20 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:20 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:20 --> Controller Class Initialized
INFO - 2024-08-09 09:48:20 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:20 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-08-09 09:48:20 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:20 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:20 --> Total execution time: 0.0894
INFO - 2024-08-09 09:48:21 --> Config Class Initialized
INFO - 2024-08-09 09:48:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:21 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:21 --> URI Class Initialized
INFO - 2024-08-09 09:48:21 --> Router Class Initialized
INFO - 2024-08-09 09:48:21 --> Output Class Initialized
INFO - 2024-08-09 09:48:21 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:21 --> Input Class Initialized
INFO - 2024-08-09 09:48:21 --> Language Class Initialized
ERROR - 2024-08-09 09:48:21 --> 404 Page Not Found: Admin/anggaran
INFO - 2024-08-09 09:48:23 --> Config Class Initialized
INFO - 2024-08-09 09:48:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:23 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:23 --> URI Class Initialized
INFO - 2024-08-09 09:48:23 --> Router Class Initialized
INFO - 2024-08-09 09:48:23 --> Output Class Initialized
INFO - 2024-08-09 09:48:23 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:23 --> Input Class Initialized
INFO - 2024-08-09 09:48:23 --> Language Class Initialized
INFO - 2024-08-09 09:48:23 --> Loader Class Initialized
INFO - 2024-08-09 09:48:23 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:23 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:23 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:23 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:23 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:23 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:23 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:23 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:23 --> Controller Class Initialized
INFO - 2024-08-09 09:48:23 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:23 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:23 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-08-09 09:48:23 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:23 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:23 --> Total execution time: 0.0678
INFO - 2024-08-09 09:48:24 --> Config Class Initialized
INFO - 2024-08-09 09:48:24 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:24 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:24 --> URI Class Initialized
INFO - 2024-08-09 09:48:24 --> Router Class Initialized
INFO - 2024-08-09 09:48:24 --> Output Class Initialized
INFO - 2024-08-09 09:48:24 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:24 --> Input Class Initialized
INFO - 2024-08-09 09:48:24 --> Language Class Initialized
ERROR - 2024-08-09 09:48:24 --> 404 Page Not Found: Admin/kwitansi
INFO - 2024-08-09 09:48:25 --> Config Class Initialized
INFO - 2024-08-09 09:48:25 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:25 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:25 --> URI Class Initialized
INFO - 2024-08-09 09:48:25 --> Router Class Initialized
INFO - 2024-08-09 09:48:25 --> Output Class Initialized
INFO - 2024-08-09 09:48:25 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:25 --> Input Class Initialized
INFO - 2024-08-09 09:48:25 --> Language Class Initialized
INFO - 2024-08-09 09:48:25 --> Loader Class Initialized
INFO - 2024-08-09 09:48:25 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:25 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:25 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:25 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:25 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:25 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:25 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:25 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:25 --> Controller Class Initialized
INFO - 2024-08-09 09:48:25 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:25 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:26 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:26 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:26 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:26 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/jenisfaktur.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:26 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:26 --> Total execution time: 0.0619
INFO - 2024-08-09 09:48:26 --> Config Class Initialized
INFO - 2024-08-09 09:48:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:26 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:26 --> URI Class Initialized
INFO - 2024-08-09 09:48:26 --> Router Class Initialized
INFO - 2024-08-09 09:48:26 --> Output Class Initialized
INFO - 2024-08-09 09:48:26 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:26 --> Input Class Initialized
INFO - 2024-08-09 09:48:26 --> Language Class Initialized
INFO - 2024-08-09 09:48:26 --> Loader Class Initialized
INFO - 2024-08-09 09:48:26 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:26 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:26 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:26 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:26 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:26 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:26 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:26 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:26 --> Controller Class Initialized
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/index.php
INFO - 2024-08-09 09:48:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:26 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:26 --> Total execution time: 0.0750
INFO - 2024-08-09 09:48:28 --> Config Class Initialized
INFO - 2024-08-09 09:48:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:28 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:28 --> URI Class Initialized
INFO - 2024-08-09 09:48:28 --> Router Class Initialized
INFO - 2024-08-09 09:48:28 --> Output Class Initialized
INFO - 2024-08-09 09:48:28 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:28 --> Input Class Initialized
INFO - 2024-08-09 09:48:28 --> Language Class Initialized
INFO - 2024-08-09 09:48:28 --> Loader Class Initialized
INFO - 2024-08-09 09:48:28 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:28 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:28 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:28 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:28 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:28 --> Controller Class Initialized
INFO - 2024-08-09 09:48:28 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:28 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:28 --> Total execution time: 0.0698
INFO - 2024-08-09 09:48:28 --> Config Class Initialized
INFO - 2024-08-09 09:48:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:28 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:28 --> URI Class Initialized
INFO - 2024-08-09 09:48:28 --> Router Class Initialized
INFO - 2024-08-09 09:48:28 --> Output Class Initialized
INFO - 2024-08-09 09:48:28 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:28 --> Input Class Initialized
INFO - 2024-08-09 09:48:28 --> Language Class Initialized
INFO - 2024-08-09 09:48:28 --> Loader Class Initialized
INFO - 2024-08-09 09:48:28 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:28 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:28 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:28 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:28 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:28 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:28 --> Controller Class Initialized
INFO - 2024-08-09 09:48:28 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:28 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 09:48:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:28 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:28 --> Total execution time: 0.0759
INFO - 2024-08-09 09:48:29 --> Config Class Initialized
INFO - 2024-08-09 09:48:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:29 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:29 --> URI Class Initialized
INFO - 2024-08-09 09:48:29 --> Router Class Initialized
INFO - 2024-08-09 09:48:29 --> Output Class Initialized
INFO - 2024-08-09 09:48:29 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:29 --> Input Class Initialized
INFO - 2024-08-09 09:48:29 --> Language Class Initialized
INFO - 2024-08-09 09:48:29 --> Loader Class Initialized
INFO - 2024-08-09 09:48:29 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:29 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:29 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:29 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:29 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:29 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:29 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:29 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:29 --> Controller Class Initialized
INFO - 2024-08-09 09:48:29 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:29 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:29 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-09 09:48:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:29 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:29 --> Total execution time: 0.0733
INFO - 2024-08-09 09:48:31 --> Config Class Initialized
INFO - 2024-08-09 09:48:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:31 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:31 --> URI Class Initialized
INFO - 2024-08-09 09:48:31 --> Router Class Initialized
INFO - 2024-08-09 09:48:31 --> Output Class Initialized
INFO - 2024-08-09 09:48:31 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:31 --> Input Class Initialized
INFO - 2024-08-09 09:48:31 --> Language Class Initialized
INFO - 2024-08-09 09:48:31 --> Loader Class Initialized
INFO - 2024-08-09 09:48:31 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:31 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:31 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:31 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:31 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:31 --> Controller Class Initialized
INFO - 2024-08-09 09:48:31 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:31 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:31 --> Total execution time: 0.0817
INFO - 2024-08-09 09:48:31 --> Config Class Initialized
INFO - 2024-08-09 09:48:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:31 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:31 --> URI Class Initialized
INFO - 2024-08-09 09:48:31 --> Router Class Initialized
INFO - 2024-08-09 09:48:31 --> Output Class Initialized
INFO - 2024-08-09 09:48:31 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:31 --> Input Class Initialized
INFO - 2024-08-09 09:48:31 --> Language Class Initialized
INFO - 2024-08-09 09:48:31 --> Loader Class Initialized
INFO - 2024-08-09 09:48:31 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:31 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:31 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:31 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:31 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:31 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:31 --> Controller Class Initialized
INFO - 2024-08-09 09:48:31 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:31 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-09 09:48:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:31 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:31 --> Total execution time: 0.0613
INFO - 2024-08-09 09:48:32 --> Config Class Initialized
INFO - 2024-08-09 09:48:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:32 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:32 --> URI Class Initialized
INFO - 2024-08-09 09:48:32 --> Router Class Initialized
INFO - 2024-08-09 09:48:32 --> Output Class Initialized
INFO - 2024-08-09 09:48:32 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:32 --> Input Class Initialized
INFO - 2024-08-09 09:48:32 --> Language Class Initialized
INFO - 2024-08-09 09:48:32 --> Loader Class Initialized
INFO - 2024-08-09 09:48:32 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:32 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:32 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:32 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:32 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:32 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:32 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:32 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:32 --> Controller Class Initialized
INFO - 2024-08-09 09:48:32 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:32 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 09:48:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:32 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:32 --> Total execution time: 0.0507
INFO - 2024-08-09 09:48:34 --> Config Class Initialized
INFO - 2024-08-09 09:48:34 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:34 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:34 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:34 --> URI Class Initialized
INFO - 2024-08-09 09:48:34 --> Router Class Initialized
INFO - 2024-08-09 09:48:34 --> Output Class Initialized
INFO - 2024-08-09 09:48:34 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:34 --> Input Class Initialized
INFO - 2024-08-09 09:48:34 --> Language Class Initialized
INFO - 2024-08-09 09:48:34 --> Loader Class Initialized
INFO - 2024-08-09 09:48:34 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:34 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:34 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:34 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:34 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:34 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:34 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:34 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:34 --> Controller Class Initialized
INFO - 2024-08-09 09:48:34 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:34 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:34 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-08-09 09:48:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:34 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:34 --> Total execution time: 0.0901
INFO - 2024-08-09 09:48:36 --> Config Class Initialized
INFO - 2024-08-09 09:48:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:36 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:36 --> URI Class Initialized
INFO - 2024-08-09 09:48:36 --> Router Class Initialized
INFO - 2024-08-09 09:48:36 --> Output Class Initialized
INFO - 2024-08-09 09:48:36 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:36 --> Input Class Initialized
INFO - 2024-08-09 09:48:36 --> Language Class Initialized
INFO - 2024-08-09 09:48:36 --> Loader Class Initialized
INFO - 2024-08-09 09:48:36 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:36 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:36 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:36 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:36 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:36 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:36 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:36 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:36 --> Controller Class Initialized
INFO - 2024-08-09 09:48:36 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:36 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 09:48:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 09:48:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 09:48:36 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-09 09:48:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 09:48:36 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:36 --> Total execution time: 0.0986
INFO - 2024-08-09 09:48:37 --> Config Class Initialized
INFO - 2024-08-09 09:48:37 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:48:37 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:48:37 --> Utf8 Class Initialized
INFO - 2024-08-09 09:48:37 --> URI Class Initialized
INFO - 2024-08-09 09:48:37 --> Router Class Initialized
INFO - 2024-08-09 09:48:37 --> Output Class Initialized
INFO - 2024-08-09 09:48:37 --> Security Class Initialized
DEBUG - 2024-08-09 09:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:48:37 --> Input Class Initialized
INFO - 2024-08-09 09:48:37 --> Language Class Initialized
INFO - 2024-08-09 09:48:37 --> Loader Class Initialized
INFO - 2024-08-09 09:48:37 --> Helper loaded: url_helper
INFO - 2024-08-09 09:48:37 --> Helper loaded: file_helper
INFO - 2024-08-09 09:48:37 --> Helper loaded: security_helper
INFO - 2024-08-09 09:48:37 --> Helper loaded: wpu_helper
INFO - 2024-08-09 09:48:37 --> Database Driver Class Initialized
INFO - 2024-08-09 09:48:37 --> Email Class Initialized
DEBUG - 2024-08-09 09:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:48:37 --> Helper loaded: form_helper
INFO - 2024-08-09 09:48:37 --> Form Validation Class Initialized
INFO - 2024-08-09 09:48:37 --> Controller Class Initialized
INFO - 2024-08-09 09:48:37 --> Model "User_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Faktur_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Supplier_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 09:48:37 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 09:48:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 09:48:38 --> Final output sent to browser
DEBUG - 2024-08-09 09:48:38 --> Total execution time: 1.3708
INFO - 2024-08-09 10:55:57 --> Config Class Initialized
INFO - 2024-08-09 10:55:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:57 --> URI Class Initialized
INFO - 2024-08-09 10:55:57 --> Router Class Initialized
INFO - 2024-08-09 10:55:57 --> Output Class Initialized
INFO - 2024-08-09 10:55:57 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:57 --> Input Class Initialized
INFO - 2024-08-09 10:55:57 --> Language Class Initialized
INFO - 2024-08-09 10:55:57 --> Loader Class Initialized
INFO - 2024-08-09 10:55:57 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:57 --> Helper loaded: file_helper
INFO - 2024-08-09 10:55:57 --> Helper loaded: security_helper
INFO - 2024-08-09 10:55:57 --> Helper loaded: wpu_helper
INFO - 2024-08-09 10:55:57 --> Database Driver Class Initialized
INFO - 2024-08-09 10:55:57 --> Email Class Initialized
DEBUG - 2024-08-09 10:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:57 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:57 --> Form Validation Class Initialized
INFO - 2024-08-09 10:55:57 --> Controller Class Initialized
INFO - 2024-08-09 10:55:57 --> Model "User_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Faktur_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Supplier_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 10:55:57 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 10:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 10:55:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 10:55:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 10:55:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 10:55:57 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakpesanan.php
INFO - 2024-08-09 10:55:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 10:55:57 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:57 --> Total execution time: 0.0826
INFO - 2024-08-09 10:55:59 --> Config Class Initialized
INFO - 2024-08-09 10:55:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:59 --> URI Class Initialized
INFO - 2024-08-09 10:55:59 --> Router Class Initialized
INFO - 2024-08-09 10:55:59 --> Output Class Initialized
INFO - 2024-08-09 10:55:59 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:59 --> Input Class Initialized
INFO - 2024-08-09 10:55:59 --> Language Class Initialized
INFO - 2024-08-09 10:55:59 --> Loader Class Initialized
INFO - 2024-08-09 10:55:59 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: file_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: security_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: wpu_helper
INFO - 2024-08-09 10:55:59 --> Database Driver Class Initialized
INFO - 2024-08-09 10:55:59 --> Email Class Initialized
DEBUG - 2024-08-09 10:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:59 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:59 --> Form Validation Class Initialized
INFO - 2024-08-09 10:55:59 --> Controller Class Initialized
INFO - 2024-08-09 10:55:59 --> Model "User_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Faktur_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Supplier_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 10:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 10:55:59 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:59 --> Total execution time: 0.0703
INFO - 2024-08-09 10:55:59 --> Config Class Initialized
INFO - 2024-08-09 10:55:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:59 --> URI Class Initialized
INFO - 2024-08-09 10:55:59 --> Router Class Initialized
INFO - 2024-08-09 10:55:59 --> Output Class Initialized
INFO - 2024-08-09 10:55:59 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:59 --> Input Class Initialized
INFO - 2024-08-09 10:55:59 --> Language Class Initialized
INFO - 2024-08-09 10:55:59 --> Loader Class Initialized
INFO - 2024-08-09 10:55:59 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: file_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: security_helper
INFO - 2024-08-09 10:55:59 --> Helper loaded: wpu_helper
INFO - 2024-08-09 10:55:59 --> Database Driver Class Initialized
INFO - 2024-08-09 10:55:59 --> Email Class Initialized
DEBUG - 2024-08-09 10:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:59 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:59 --> Form Validation Class Initialized
INFO - 2024-08-09 10:55:59 --> Controller Class Initialized
INFO - 2024-08-09 10:55:59 --> Model "User_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Faktur_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Supplier_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 10:55:59 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 10:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-09 10:55:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 10:55:59 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:59 --> Total execution time: 0.0735
INFO - 2024-08-09 11:44:08 --> Config Class Initialized
INFO - 2024-08-09 11:44:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:44:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:44:08 --> Utf8 Class Initialized
INFO - 2024-08-09 11:44:08 --> URI Class Initialized
INFO - 2024-08-09 11:44:08 --> Router Class Initialized
INFO - 2024-08-09 11:44:08 --> Output Class Initialized
INFO - 2024-08-09 11:44:08 --> Security Class Initialized
DEBUG - 2024-08-09 11:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:44:08 --> Input Class Initialized
INFO - 2024-08-09 11:44:08 --> Language Class Initialized
INFO - 2024-08-09 11:44:08 --> Loader Class Initialized
INFO - 2024-08-09 11:44:08 --> Helper loaded: url_helper
INFO - 2024-08-09 11:44:08 --> Helper loaded: file_helper
INFO - 2024-08-09 11:44:08 --> Helper loaded: security_helper
INFO - 2024-08-09 11:44:08 --> Helper loaded: wpu_helper
INFO - 2024-08-09 11:44:08 --> Database Driver Class Initialized
INFO - 2024-08-09 11:44:08 --> Email Class Initialized
DEBUG - 2024-08-09 11:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:44:08 --> Helper loaded: form_helper
INFO - 2024-08-09 11:44:08 --> Form Validation Class Initialized
INFO - 2024-08-09 11:44:08 --> Controller Class Initialized
INFO - 2024-08-09 11:44:08 --> Model "User_model" initialized
INFO - 2024-08-09 11:44:08 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 11:44:08 --> Model "Faktur_model" initialized
INFO - 2024-08-09 11:44:08 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 11:44:08 --> Model "Supplier_model" initialized
INFO - 2024-08-09 11:44:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 11:44:09 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 11:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 11:44:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 11:44:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 11:44:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 11:44:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-09 11:44:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 11:44:09 --> Final output sent to browser
DEBUG - 2024-08-09 11:44:09 --> Total execution time: 0.1023
INFO - 2024-08-09 11:44:11 --> Config Class Initialized
INFO - 2024-08-09 11:44:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:44:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:44:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:44:11 --> URI Class Initialized
INFO - 2024-08-09 11:44:11 --> Router Class Initialized
INFO - 2024-08-09 11:44:11 --> Output Class Initialized
INFO - 2024-08-09 11:44:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:44:11 --> Input Class Initialized
INFO - 2024-08-09 11:44:11 --> Language Class Initialized
INFO - 2024-08-09 11:44:11 --> Loader Class Initialized
INFO - 2024-08-09 11:44:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:44:11 --> Helper loaded: file_helper
INFO - 2024-08-09 11:44:11 --> Helper loaded: security_helper
INFO - 2024-08-09 11:44:11 --> Helper loaded: wpu_helper
INFO - 2024-08-09 11:44:11 --> Database Driver Class Initialized
INFO - 2024-08-09 11:44:11 --> Email Class Initialized
DEBUG - 2024-08-09 11:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:44:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:44:11 --> Form Validation Class Initialized
INFO - 2024-08-09 11:44:11 --> Controller Class Initialized
INFO - 2024-08-09 11:44:11 --> Model "User_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Faktur_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Supplier_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 11:44:11 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 11:44:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 11:44:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 11:44:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 11:44:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 11:44:11 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-09 11:44:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 11:44:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:44:11 --> Total execution time: 0.0768
INFO - 2024-08-09 11:44:12 --> Config Class Initialized
INFO - 2024-08-09 11:44:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:44:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:44:12 --> Utf8 Class Initialized
INFO - 2024-08-09 11:44:12 --> URI Class Initialized
INFO - 2024-08-09 11:44:12 --> Router Class Initialized
INFO - 2024-08-09 11:44:12 --> Output Class Initialized
INFO - 2024-08-09 11:44:12 --> Security Class Initialized
DEBUG - 2024-08-09 11:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:44:12 --> Input Class Initialized
INFO - 2024-08-09 11:44:12 --> Language Class Initialized
INFO - 2024-08-09 11:44:12 --> Loader Class Initialized
INFO - 2024-08-09 11:44:12 --> Helper loaded: url_helper
INFO - 2024-08-09 11:44:12 --> Helper loaded: file_helper
INFO - 2024-08-09 11:44:12 --> Helper loaded: security_helper
INFO - 2024-08-09 11:44:12 --> Helper loaded: wpu_helper
INFO - 2024-08-09 11:44:12 --> Database Driver Class Initialized
INFO - 2024-08-09 11:44:12 --> Email Class Initialized
DEBUG - 2024-08-09 11:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:44:12 --> Helper loaded: form_helper
INFO - 2024-08-09 11:44:12 --> Form Validation Class Initialized
INFO - 2024-08-09 11:44:12 --> Controller Class Initialized
INFO - 2024-08-09 11:44:12 --> Model "User_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Faktur_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Supplier_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 11:44:12 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 11:44:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 11:44:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 11:44:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 11:44:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 11:44:12 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-09 11:44:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 11:44:12 --> Final output sent to browser
DEBUG - 2024-08-09 11:44:12 --> Total execution time: 0.0634
INFO - 2024-08-09 11:44:13 --> Config Class Initialized
INFO - 2024-08-09 11:44:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:44:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:44:13 --> Utf8 Class Initialized
INFO - 2024-08-09 11:44:13 --> URI Class Initialized
INFO - 2024-08-09 11:44:13 --> Router Class Initialized
INFO - 2024-08-09 11:44:13 --> Output Class Initialized
INFO - 2024-08-09 11:44:13 --> Security Class Initialized
DEBUG - 2024-08-09 11:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:44:13 --> Input Class Initialized
INFO - 2024-08-09 11:44:13 --> Language Class Initialized
INFO - 2024-08-09 11:44:13 --> Loader Class Initialized
INFO - 2024-08-09 11:44:13 --> Helper loaded: url_helper
INFO - 2024-08-09 11:44:13 --> Helper loaded: file_helper
INFO - 2024-08-09 11:44:13 --> Helper loaded: security_helper
INFO - 2024-08-09 11:44:13 --> Helper loaded: wpu_helper
INFO - 2024-08-09 11:44:13 --> Database Driver Class Initialized
INFO - 2024-08-09 11:44:13 --> Email Class Initialized
DEBUG - 2024-08-09 11:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:44:13 --> Helper loaded: form_helper
INFO - 2024-08-09 11:44:13 --> Form Validation Class Initialized
INFO - 2024-08-09 11:44:13 --> Controller Class Initialized
INFO - 2024-08-09 11:44:13 --> Model "User_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Faktur_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Supplier_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 11:44:13 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 11:44:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 11:44:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 11:44:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 11:44:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 11:44:13 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-09 11:44:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 11:44:13 --> Final output sent to browser
DEBUG - 2024-08-09 11:44:13 --> Total execution time: 0.0761
INFO - 2024-08-09 17:43:43 --> Config Class Initialized
INFO - 2024-08-09 17:43:43 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:43 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:43 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:43 --> URI Class Initialized
INFO - 2024-08-09 17:43:43 --> Router Class Initialized
INFO - 2024-08-09 17:43:43 --> Output Class Initialized
INFO - 2024-08-09 17:43:43 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:44 --> Input Class Initialized
INFO - 2024-08-09 17:43:44 --> Language Class Initialized
INFO - 2024-08-09 17:43:44 --> Loader Class Initialized
INFO - 2024-08-09 17:43:44 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:44 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:44 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:44 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:44 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:44 --> Controller Class Initialized
INFO - 2024-08-09 17:43:44 --> Config Class Initialized
INFO - 2024-08-09 17:43:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:44 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:44 --> URI Class Initialized
INFO - 2024-08-09 17:43:44 --> Router Class Initialized
INFO - 2024-08-09 17:43:44 --> Output Class Initialized
INFO - 2024-08-09 17:43:44 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:44 --> Input Class Initialized
INFO - 2024-08-09 17:43:44 --> Language Class Initialized
INFO - 2024-08-09 17:43:44 --> Loader Class Initialized
INFO - 2024-08-09 17:43:44 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:44 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:44 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:44 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:44 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:44 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:44 --> Controller Class Initialized
DEBUG - 2024-08-09 17:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-09 17:43:44 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-09 17:43:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-09 17:43:44 --> Final output sent to browser
DEBUG - 2024-08-09 17:43:44 --> Total execution time: 0.1145
INFO - 2024-08-09 17:43:48 --> Config Class Initialized
INFO - 2024-08-09 17:43:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:48 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:48 --> URI Class Initialized
INFO - 2024-08-09 17:43:48 --> Router Class Initialized
INFO - 2024-08-09 17:43:48 --> Output Class Initialized
INFO - 2024-08-09 17:43:48 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:48 --> Input Class Initialized
INFO - 2024-08-09 17:43:48 --> Language Class Initialized
INFO - 2024-08-09 17:43:48 --> Loader Class Initialized
INFO - 2024-08-09 17:43:48 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:48 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:48 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:48 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:48 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:48 --> Controller Class Initialized
DEBUG - 2024-08-09 17:43:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-09 17:43:48 --> Config Class Initialized
INFO - 2024-08-09 17:43:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:48 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:48 --> URI Class Initialized
INFO - 2024-08-09 17:43:48 --> Router Class Initialized
INFO - 2024-08-09 17:43:48 --> Output Class Initialized
INFO - 2024-08-09 17:43:48 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:48 --> Input Class Initialized
INFO - 2024-08-09 17:43:48 --> Language Class Initialized
INFO - 2024-08-09 17:43:48 --> Loader Class Initialized
INFO - 2024-08-09 17:43:48 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:48 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:48 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:48 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:48 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:48 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:48 --> Controller Class Initialized
INFO - 2024-08-09 17:43:49 --> Model "User_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Faktur_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Supplier_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 17:43:49 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 17:43:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 17:43:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 17:43:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 17:43:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 17:43:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 17:43:49 --> Final output sent to browser
DEBUG - 2024-08-09 17:43:49 --> Total execution time: 0.3573
INFO - 2024-08-09 17:43:50 --> Config Class Initialized
INFO - 2024-08-09 17:43:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:50 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:50 --> URI Class Initialized
INFO - 2024-08-09 17:43:50 --> Router Class Initialized
INFO - 2024-08-09 17:43:50 --> Output Class Initialized
INFO - 2024-08-09 17:43:50 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:50 --> Input Class Initialized
INFO - 2024-08-09 17:43:50 --> Language Class Initialized
INFO - 2024-08-09 17:43:50 --> Loader Class Initialized
INFO - 2024-08-09 17:43:50 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:50 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:50 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:50 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:50 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:50 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:50 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:50 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:50 --> Controller Class Initialized
INFO - 2024-08-09 17:43:50 --> Model "User_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Faktur_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Supplier_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 17:43:50 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 17:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 17:43:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 17:43:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 17:43:50 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-08-09 17:43:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 17:43:50 --> Final output sent to browser
DEBUG - 2024-08-09 17:43:50 --> Total execution time: 0.0989
INFO - 2024-08-09 17:43:51 --> Config Class Initialized
INFO - 2024-08-09 17:43:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:51 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:51 --> URI Class Initialized
INFO - 2024-08-09 17:43:51 --> Router Class Initialized
INFO - 2024-08-09 17:43:51 --> Output Class Initialized
INFO - 2024-08-09 17:43:51 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:51 --> Input Class Initialized
INFO - 2024-08-09 17:43:51 --> Language Class Initialized
INFO - 2024-08-09 17:43:52 --> Loader Class Initialized
INFO - 2024-08-09 17:43:52 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:52 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:52 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:52 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:52 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:52 --> Controller Class Initialized
INFO - 2024-08-09 17:43:52 --> Model "User_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Faktur_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Supplier_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 17:43:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/supplier.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 17:43:52 --> Final output sent to browser
DEBUG - 2024-08-09 17:43:52 --> Total execution time: 0.0961
INFO - 2024-08-09 17:43:52 --> Config Class Initialized
INFO - 2024-08-09 17:43:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 17:43:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 17:43:52 --> Utf8 Class Initialized
INFO - 2024-08-09 17:43:52 --> URI Class Initialized
INFO - 2024-08-09 17:43:52 --> Router Class Initialized
INFO - 2024-08-09 17:43:52 --> Output Class Initialized
INFO - 2024-08-09 17:43:52 --> Security Class Initialized
DEBUG - 2024-08-09 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 17:43:52 --> Input Class Initialized
INFO - 2024-08-09 17:43:52 --> Language Class Initialized
INFO - 2024-08-09 17:43:52 --> Loader Class Initialized
INFO - 2024-08-09 17:43:52 --> Helper loaded: url_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: file_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: security_helper
INFO - 2024-08-09 17:43:52 --> Helper loaded: wpu_helper
INFO - 2024-08-09 17:43:52 --> Database Driver Class Initialized
INFO - 2024-08-09 17:43:52 --> Email Class Initialized
DEBUG - 2024-08-09 17:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 17:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 17:43:52 --> Helper loaded: form_helper
INFO - 2024-08-09 17:43:52 --> Form Validation Class Initialized
INFO - 2024-08-09 17:43:52 --> Controller Class Initialized
INFO - 2024-08-09 17:43:52 --> Model "User_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Permintaan_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Faktur_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Pesanan_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Supplier_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-09 17:43:52 --> Model "Jenis_model" initialized
DEBUG - 2024-08-09 17:43:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-09 17:43:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-09 17:43:52 --> Final output sent to browser
DEBUG - 2024-08-09 17:43:52 --> Total execution time: 0.0784
