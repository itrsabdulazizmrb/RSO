<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-17 05:07:43 --> Config Class Initialized
INFO - 2024-11-17 05:07:43 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:07:43 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:07:43 --> Utf8 Class Initialized
INFO - 2024-11-17 05:07:43 --> URI Class Initialized
DEBUG - 2024-11-17 05:07:43 --> No URI present. Default controller set.
INFO - 2024-11-17 05:07:43 --> Router Class Initialized
INFO - 2024-11-17 05:07:43 --> Output Class Initialized
INFO - 2024-11-17 05:07:43 --> Security Class Initialized
DEBUG - 2024-11-17 05:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:07:43 --> Input Class Initialized
INFO - 2024-11-17 05:07:43 --> Language Class Initialized
INFO - 2024-11-17 05:07:43 --> Loader Class Initialized
INFO - 2024-11-17 05:07:43 --> Helper loaded: url_helper
INFO - 2024-11-17 05:07:43 --> Helper loaded: file_helper
INFO - 2024-11-17 05:07:43 --> Helper loaded: security_helper
INFO - 2024-11-17 05:07:43 --> Helper loaded: wpu_helper
INFO - 2024-11-17 05:07:43 --> Database Driver Class Initialized
INFO - 2024-11-17 05:07:44 --> Email Class Initialized
DEBUG - 2024-11-17 05:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 05:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 05:07:44 --> Helper loaded: form_helper
INFO - 2024-11-17 05:07:44 --> Form Validation Class Initialized
INFO - 2024-11-17 05:07:44 --> Controller Class Initialized
DEBUG - 2024-11-17 05:07:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 05:07:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 05:07:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 05:07:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 05:07:44 --> Final output sent to browser
DEBUG - 2024-11-17 05:07:44 --> Total execution time: 0.4222
INFO - 2024-11-17 05:07:44 --> Config Class Initialized
INFO - 2024-11-17 05:07:44 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:07:44 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:07:44 --> Utf8 Class Initialized
INFO - 2024-11-17 05:07:44 --> URI Class Initialized
INFO - 2024-11-17 05:07:44 --> Router Class Initialized
INFO - 2024-11-17 05:07:44 --> Output Class Initialized
INFO - 2024-11-17 05:07:44 --> Security Class Initialized
DEBUG - 2024-11-17 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:07:44 --> Input Class Initialized
INFO - 2024-11-17 05:07:44 --> Language Class Initialized
ERROR - 2024-11-17 05:07:44 --> 404 Page Not Found: App/index
INFO - 2024-11-17 05:07:44 --> Config Class Initialized
INFO - 2024-11-17 05:07:44 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:07:44 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:07:44 --> Utf8 Class Initialized
INFO - 2024-11-17 05:07:44 --> URI Class Initialized
INFO - 2024-11-17 05:07:44 --> Router Class Initialized
INFO - 2024-11-17 05:07:44 --> Output Class Initialized
INFO - 2024-11-17 05:07:44 --> Security Class Initialized
DEBUG - 2024-11-17 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:07:44 --> Input Class Initialized
INFO - 2024-11-17 05:07:44 --> Language Class Initialized
ERROR - 2024-11-17 05:07:44 --> 404 Page Not Found: Login/index
INFO - 2024-11-17 05:37:07 --> Config Class Initialized
INFO - 2024-11-17 05:37:07 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:37:07 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:37:07 --> Utf8 Class Initialized
INFO - 2024-11-17 05:37:07 --> URI Class Initialized
DEBUG - 2024-11-17 05:37:07 --> No URI present. Default controller set.
INFO - 2024-11-17 05:37:07 --> Router Class Initialized
INFO - 2024-11-17 05:37:07 --> Output Class Initialized
INFO - 2024-11-17 05:37:07 --> Security Class Initialized
DEBUG - 2024-11-17 05:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:37:07 --> Input Class Initialized
INFO - 2024-11-17 05:37:07 --> Language Class Initialized
INFO - 2024-11-17 05:37:07 --> Loader Class Initialized
INFO - 2024-11-17 05:37:07 --> Helper loaded: url_helper
INFO - 2024-11-17 05:37:07 --> Helper loaded: file_helper
INFO - 2024-11-17 05:37:07 --> Helper loaded: security_helper
INFO - 2024-11-17 05:37:07 --> Helper loaded: wpu_helper
INFO - 2024-11-17 05:37:07 --> Database Driver Class Initialized
INFO - 2024-11-17 05:37:07 --> Email Class Initialized
DEBUG - 2024-11-17 05:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 05:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 05:37:07 --> Helper loaded: form_helper
INFO - 2024-11-17 05:37:07 --> Form Validation Class Initialized
INFO - 2024-11-17 05:37:07 --> Controller Class Initialized
DEBUG - 2024-11-17 05:37:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 05:37:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 05:37:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 05:37:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 05:37:07 --> Final output sent to browser
DEBUG - 2024-11-17 05:37:07 --> Total execution time: 0.4141
INFO - 2024-11-17 05:37:07 --> Config Class Initialized
INFO - 2024-11-17 05:37:07 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:37:07 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:37:07 --> Utf8 Class Initialized
INFO - 2024-11-17 05:37:07 --> URI Class Initialized
INFO - 2024-11-17 05:37:07 --> Router Class Initialized
INFO - 2024-11-17 05:37:07 --> Output Class Initialized
INFO - 2024-11-17 05:37:07 --> Security Class Initialized
DEBUG - 2024-11-17 05:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:37:07 --> Input Class Initialized
INFO - 2024-11-17 05:37:07 --> Language Class Initialized
ERROR - 2024-11-17 05:37:07 --> 404 Page Not Found: App/index
INFO - 2024-11-17 05:37:08 --> Config Class Initialized
INFO - 2024-11-17 05:37:08 --> Hooks Class Initialized
DEBUG - 2024-11-17 05:37:08 --> UTF-8 Support Enabled
INFO - 2024-11-17 05:37:08 --> Utf8 Class Initialized
INFO - 2024-11-17 05:37:08 --> URI Class Initialized
INFO - 2024-11-17 05:37:08 --> Router Class Initialized
INFO - 2024-11-17 05:37:08 --> Output Class Initialized
INFO - 2024-11-17 05:37:08 --> Security Class Initialized
DEBUG - 2024-11-17 05:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 05:37:08 --> Input Class Initialized
INFO - 2024-11-17 05:37:08 --> Language Class Initialized
ERROR - 2024-11-17 05:37:08 --> 404 Page Not Found: Login/index
INFO - 2024-11-17 08:04:28 --> Config Class Initialized
INFO - 2024-11-17 08:04:28 --> Hooks Class Initialized
DEBUG - 2024-11-17 08:04:28 --> UTF-8 Support Enabled
INFO - 2024-11-17 08:04:28 --> Utf8 Class Initialized
INFO - 2024-11-17 08:04:28 --> URI Class Initialized
DEBUG - 2024-11-17 08:04:28 --> No URI present. Default controller set.
INFO - 2024-11-17 08:04:28 --> Router Class Initialized
INFO - 2024-11-17 08:04:28 --> Output Class Initialized
INFO - 2024-11-17 08:04:28 --> Security Class Initialized
DEBUG - 2024-11-17 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 08:04:28 --> Input Class Initialized
INFO - 2024-11-17 08:04:28 --> Language Class Initialized
INFO - 2024-11-17 08:04:28 --> Loader Class Initialized
INFO - 2024-11-17 08:04:28 --> Helper loaded: url_helper
INFO - 2024-11-17 08:04:28 --> Helper loaded: file_helper
INFO - 2024-11-17 08:04:28 --> Helper loaded: security_helper
INFO - 2024-11-17 08:04:28 --> Helper loaded: wpu_helper
INFO - 2024-11-17 08:04:28 --> Database Driver Class Initialized
INFO - 2024-11-17 08:04:29 --> Email Class Initialized
DEBUG - 2024-11-17 08:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 08:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 08:04:29 --> Helper loaded: form_helper
INFO - 2024-11-17 08:04:29 --> Form Validation Class Initialized
INFO - 2024-11-17 08:04:29 --> Controller Class Initialized
DEBUG - 2024-11-17 08:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 08:04:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 08:04:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 08:04:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 08:04:29 --> Final output sent to browser
DEBUG - 2024-11-17 08:04:29 --> Total execution time: 0.4305
INFO - 2024-11-17 08:09:50 --> Config Class Initialized
INFO - 2024-11-17 08:09:50 --> Hooks Class Initialized
DEBUG - 2024-11-17 08:09:50 --> UTF-8 Support Enabled
INFO - 2024-11-17 08:09:50 --> Utf8 Class Initialized
INFO - 2024-11-17 08:09:50 --> URI Class Initialized
DEBUG - 2024-11-17 08:09:50 --> No URI present. Default controller set.
INFO - 2024-11-17 08:09:50 --> Router Class Initialized
INFO - 2024-11-17 08:09:50 --> Output Class Initialized
INFO - 2024-11-17 08:09:50 --> Security Class Initialized
DEBUG - 2024-11-17 08:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 08:09:50 --> Input Class Initialized
INFO - 2024-11-17 08:09:50 --> Language Class Initialized
INFO - 2024-11-17 08:09:50 --> Loader Class Initialized
INFO - 2024-11-17 08:09:50 --> Helper loaded: url_helper
INFO - 2024-11-17 08:09:50 --> Helper loaded: file_helper
INFO - 2024-11-17 08:09:50 --> Helper loaded: security_helper
INFO - 2024-11-17 08:09:50 --> Helper loaded: wpu_helper
INFO - 2024-11-17 08:09:50 --> Database Driver Class Initialized
INFO - 2024-11-17 08:09:50 --> Email Class Initialized
DEBUG - 2024-11-17 08:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 08:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 08:09:50 --> Helper loaded: form_helper
INFO - 2024-11-17 08:09:50 --> Form Validation Class Initialized
INFO - 2024-11-17 08:09:50 --> Controller Class Initialized
DEBUG - 2024-11-17 08:09:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 08:09:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 08:09:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 08:09:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 08:09:50 --> Final output sent to browser
DEBUG - 2024-11-17 08:09:50 --> Total execution time: 0.4279
INFO - 2024-11-17 11:15:02 --> Config Class Initialized
INFO - 2024-11-17 11:15:02 --> Hooks Class Initialized
DEBUG - 2024-11-17 11:15:02 --> UTF-8 Support Enabled
INFO - 2024-11-17 11:15:02 --> Utf8 Class Initialized
INFO - 2024-11-17 11:15:02 --> URI Class Initialized
INFO - 2024-11-17 11:15:02 --> Router Class Initialized
INFO - 2024-11-17 11:15:02 --> Output Class Initialized
INFO - 2024-11-17 11:15:02 --> Security Class Initialized
DEBUG - 2024-11-17 11:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 11:15:02 --> Input Class Initialized
INFO - 2024-11-17 11:15:02 --> Language Class Initialized
ERROR - 2024-11-17 11:15:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-17 11:15:07 --> Config Class Initialized
INFO - 2024-11-17 11:15:07 --> Hooks Class Initialized
DEBUG - 2024-11-17 11:15:07 --> UTF-8 Support Enabled
INFO - 2024-11-17 11:15:07 --> Utf8 Class Initialized
INFO - 2024-11-17 11:15:07 --> URI Class Initialized
DEBUG - 2024-11-17 11:15:07 --> No URI present. Default controller set.
INFO - 2024-11-17 11:15:07 --> Router Class Initialized
INFO - 2024-11-17 11:15:07 --> Output Class Initialized
INFO - 2024-11-17 11:15:07 --> Security Class Initialized
DEBUG - 2024-11-17 11:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 11:15:07 --> Input Class Initialized
INFO - 2024-11-17 11:15:07 --> Language Class Initialized
INFO - 2024-11-17 11:15:07 --> Loader Class Initialized
INFO - 2024-11-17 11:15:07 --> Helper loaded: url_helper
INFO - 2024-11-17 11:15:07 --> Helper loaded: file_helper
INFO - 2024-11-17 11:15:07 --> Helper loaded: security_helper
INFO - 2024-11-17 11:15:07 --> Helper loaded: wpu_helper
INFO - 2024-11-17 11:15:07 --> Database Driver Class Initialized
INFO - 2024-11-17 11:15:07 --> Email Class Initialized
DEBUG - 2024-11-17 11:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 11:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 11:15:07 --> Helper loaded: form_helper
INFO - 2024-11-17 11:15:07 --> Form Validation Class Initialized
INFO - 2024-11-17 11:15:07 --> Controller Class Initialized
DEBUG - 2024-11-17 11:15:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 11:15:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 11:15:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 11:15:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 11:15:07 --> Final output sent to browser
DEBUG - 2024-11-17 11:15:07 --> Total execution time: 0.4310
INFO - 2024-11-17 15:44:53 --> Config Class Initialized
INFO - 2024-11-17 15:44:53 --> Hooks Class Initialized
DEBUG - 2024-11-17 15:44:53 --> UTF-8 Support Enabled
INFO - 2024-11-17 15:44:53 --> Utf8 Class Initialized
INFO - 2024-11-17 15:44:53 --> URI Class Initialized
DEBUG - 2024-11-17 15:44:53 --> No URI present. Default controller set.
INFO - 2024-11-17 15:44:53 --> Router Class Initialized
INFO - 2024-11-17 15:44:53 --> Output Class Initialized
INFO - 2024-11-17 15:44:53 --> Security Class Initialized
DEBUG - 2024-11-17 15:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 15:44:53 --> Input Class Initialized
INFO - 2024-11-17 15:44:53 --> Language Class Initialized
INFO - 2024-11-17 15:44:53 --> Loader Class Initialized
INFO - 2024-11-17 15:44:53 --> Helper loaded: url_helper
INFO - 2024-11-17 15:44:53 --> Helper loaded: file_helper
INFO - 2024-11-17 15:44:53 --> Helper loaded: security_helper
INFO - 2024-11-17 15:44:53 --> Helper loaded: wpu_helper
INFO - 2024-11-17 15:44:53 --> Database Driver Class Initialized
INFO - 2024-11-17 15:44:54 --> Email Class Initialized
DEBUG - 2024-11-17 15:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 15:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 15:44:54 --> Helper loaded: form_helper
INFO - 2024-11-17 15:44:54 --> Form Validation Class Initialized
INFO - 2024-11-17 15:44:54 --> Controller Class Initialized
DEBUG - 2024-11-17 15:44:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 15:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 15:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 15:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 15:44:54 --> Final output sent to browser
DEBUG - 2024-11-17 15:44:54 --> Total execution time: 0.4278
INFO - 2024-11-17 18:50:53 --> Config Class Initialized
INFO - 2024-11-17 18:50:53 --> Hooks Class Initialized
DEBUG - 2024-11-17 18:50:53 --> UTF-8 Support Enabled
INFO - 2024-11-17 18:50:53 --> Utf8 Class Initialized
INFO - 2024-11-17 18:50:53 --> URI Class Initialized
DEBUG - 2024-11-17 18:50:53 --> No URI present. Default controller set.
INFO - 2024-11-17 18:50:53 --> Router Class Initialized
INFO - 2024-11-17 18:50:53 --> Output Class Initialized
INFO - 2024-11-17 18:50:53 --> Security Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 18:50:53 --> Input Class Initialized
INFO - 2024-11-17 18:50:53 --> Language Class Initialized
INFO - 2024-11-17 18:50:53 --> Loader Class Initialized
INFO - 2024-11-17 18:50:53 --> Helper loaded: url_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: file_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: security_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: wpu_helper
INFO - 2024-11-17 18:50:53 --> Database Driver Class Initialized
INFO - 2024-11-17 18:50:53 --> Config Class Initialized
INFO - 2024-11-17 18:50:53 --> Hooks Class Initialized
DEBUG - 2024-11-17 18:50:53 --> UTF-8 Support Enabled
INFO - 2024-11-17 18:50:53 --> Utf8 Class Initialized
INFO - 2024-11-17 18:50:53 --> URI Class Initialized
DEBUG - 2024-11-17 18:50:53 --> No URI present. Default controller set.
INFO - 2024-11-17 18:50:53 --> Router Class Initialized
INFO - 2024-11-17 18:50:53 --> Output Class Initialized
INFO - 2024-11-17 18:50:53 --> Security Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 18:50:53 --> Input Class Initialized
INFO - 2024-11-17 18:50:53 --> Language Class Initialized
INFO - 2024-11-17 18:50:53 --> Loader Class Initialized
INFO - 2024-11-17 18:50:53 --> Helper loaded: url_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: file_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: security_helper
INFO - 2024-11-17 18:50:53 --> Helper loaded: wpu_helper
INFO - 2024-11-17 18:50:53 --> Database Driver Class Initialized
INFO - 2024-11-17 18:50:53 --> Email Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 18:50:53 --> Helper loaded: form_helper
INFO - 2024-11-17 18:50:53 --> Form Validation Class Initialized
INFO - 2024-11-17 18:50:53 --> Controller Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 18:50:53 --> Final output sent to browser
DEBUG - 2024-11-17 18:50:53 --> Total execution time: 0.4333
INFO - 2024-11-17 18:50:53 --> Email Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-17 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 18:50:53 --> Helper loaded: form_helper
INFO - 2024-11-17 18:50:53 --> Form Validation Class Initialized
INFO - 2024-11-17 18:50:53 --> Controller Class Initialized
DEBUG - 2024-11-17 18:50:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-17 18:50:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-17 18:50:53 --> Final output sent to browser
DEBUG - 2024-11-17 18:50:53 --> Total execution time: 0.4071
INFO - 2024-11-17 22:41:10 --> Config Class Initialized
INFO - 2024-11-17 22:41:10 --> Hooks Class Initialized
DEBUG - 2024-11-17 22:41:10 --> UTF-8 Support Enabled
INFO - 2024-11-17 22:41:10 --> Utf8 Class Initialized
INFO - 2024-11-17 22:41:10 --> URI Class Initialized
INFO - 2024-11-17 22:41:10 --> Router Class Initialized
INFO - 2024-11-17 22:41:10 --> Output Class Initialized
INFO - 2024-11-17 22:41:10 --> Security Class Initialized
DEBUG - 2024-11-17 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 22:41:10 --> Input Class Initialized
INFO - 2024-11-17 22:41:10 --> Language Class Initialized
INFO - 2024-11-17 22:41:10 --> Loader Class Initialized
INFO - 2024-11-17 22:41:10 --> Helper loaded: url_helper
INFO - 2024-11-17 22:41:10 --> Helper loaded: file_helper
INFO - 2024-11-17 22:41:10 --> Helper loaded: security_helper
INFO - 2024-11-17 22:41:10 --> Helper loaded: wpu_helper
INFO - 2024-11-17 22:41:10 --> Database Driver Class Initialized
