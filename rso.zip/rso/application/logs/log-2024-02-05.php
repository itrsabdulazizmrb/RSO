<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-05 00:01:41 --> Config Class Initialized
INFO - 2024-02-05 00:01:41 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:01:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:41 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:41 --> URI Class Initialized
INFO - 2024-02-05 00:01:41 --> Router Class Initialized
INFO - 2024-02-05 00:01:41 --> Output Class Initialized
INFO - 2024-02-05 00:01:41 --> Security Class Initialized
DEBUG - 2024-02-05 00:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:41 --> Input Class Initialized
INFO - 2024-02-05 00:01:41 --> Language Class Initialized
INFO - 2024-02-05 00:01:41 --> Loader Class Initialized
INFO - 2024-02-05 00:01:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:41 --> Email Class Initialized
DEBUG - 2024-02-05 00:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:41 --> Controller Class Initialized
INFO - 2024-02-05 00:01:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 177
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
INFO - 2024-02-05 00:01:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:01:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:01:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:01:41 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:01:41 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:01:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:01:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:41 --> Total execution time: 0.0916
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> Config Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
INFO - 2024-02-05 00:01:43 --> Hooks Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:01:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
INFO - 2024-02-05 00:01:43 --> URI Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
INFO - 2024-02-05 00:01:43 --> Router Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
INFO - 2024-02-05 00:01:43 --> Output Class Initialized
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> Security Class Initialized
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Input Class Initialized
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Language Class Initialized
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Loader Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:01:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
INFO - 2024-02-05 00:01:43 --> Email Class Initialized
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.0565
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.0682
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.0762
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.0891
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.1014
INFO - 2024-02-05 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:43 --> Controller Class Initialized
INFO - 2024-02-05 00:01:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:01:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:01:43 --> Total execution time: 0.1139
INFO - 2024-02-05 00:01:46 --> Config Class Initialized
INFO - 2024-02-05 00:01:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:01:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:01:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:01:46 --> URI Class Initialized
INFO - 2024-02-05 00:01:46 --> Router Class Initialized
INFO - 2024-02-05 00:01:46 --> Output Class Initialized
INFO - 2024-02-05 00:01:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:01:46 --> Input Class Initialized
INFO - 2024-02-05 00:01:46 --> Language Class Initialized
INFO - 2024-02-05 00:01:46 --> Loader Class Initialized
INFO - 2024-02-05 00:01:46 --> Helper loaded: url_helper
INFO - 2024-02-05 00:01:46 --> Helper loaded: file_helper
INFO - 2024-02-05 00:01:46 --> Helper loaded: security_helper
INFO - 2024-02-05 00:01:46 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:01:46 --> Database Driver Class Initialized
INFO - 2024-02-05 00:01:46 --> Email Class Initialized
DEBUG - 2024-02-05 00:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:01:46 --> Helper loaded: form_helper
INFO - 2024-02-05 00:01:46 --> Form Validation Class Initialized
INFO - 2024-02-05 00:01:46 --> Controller Class Initialized
INFO - 2024-02-05 00:01:46 --> Model "User_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:01:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:01:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:01:46 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:01:46 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 179
INFO - 2024-02-05 00:01:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:01:46 --> 404 Page Not Found: 
INFO - 2024-02-05 00:03:59 --> Config Class Initialized
INFO - 2024-02-05 00:03:59 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:03:59 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:03:59 --> Utf8 Class Initialized
INFO - 2024-02-05 00:03:59 --> URI Class Initialized
INFO - 2024-02-05 00:03:59 --> Router Class Initialized
INFO - 2024-02-05 00:03:59 --> Output Class Initialized
INFO - 2024-02-05 00:03:59 --> Security Class Initialized
DEBUG - 2024-02-05 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:03:59 --> Input Class Initialized
INFO - 2024-02-05 00:03:59 --> Language Class Initialized
INFO - 2024-02-05 00:03:59 --> Loader Class Initialized
INFO - 2024-02-05 00:03:59 --> Helper loaded: url_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: file_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: security_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:03:59 --> Database Driver Class Initialized
INFO - 2024-02-05 00:03:59 --> Email Class Initialized
DEBUG - 2024-02-05 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:03:59 --> Helper loaded: form_helper
INFO - 2024-02-05 00:03:59 --> Form Validation Class Initialized
INFO - 2024-02-05 00:03:59 --> Controller Class Initialized
INFO - 2024-02-05 00:03:59 --> Model "User_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:03:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:03:59 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:03:59 --> Final output sent to browser
DEBUG - 2024-02-05 00:03:59 --> Total execution time: 0.0756
INFO - 2024-02-05 00:03:59 --> Config Class Initialized
INFO - 2024-02-05 00:03:59 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:03:59 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:03:59 --> Utf8 Class Initialized
INFO - 2024-02-05 00:03:59 --> URI Class Initialized
INFO - 2024-02-05 00:03:59 --> Router Class Initialized
INFO - 2024-02-05 00:03:59 --> Output Class Initialized
INFO - 2024-02-05 00:03:59 --> Security Class Initialized
DEBUG - 2024-02-05 00:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:03:59 --> Input Class Initialized
INFO - 2024-02-05 00:03:59 --> Language Class Initialized
INFO - 2024-02-05 00:03:59 --> Loader Class Initialized
INFO - 2024-02-05 00:03:59 --> Helper loaded: url_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: file_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: security_helper
INFO - 2024-02-05 00:03:59 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:03:59 --> Database Driver Class Initialized
INFO - 2024-02-05 00:03:59 --> Email Class Initialized
DEBUG - 2024-02-05 00:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:03:59 --> Helper loaded: form_helper
INFO - 2024-02-05 00:03:59 --> Form Validation Class Initialized
INFO - 2024-02-05 00:03:59 --> Controller Class Initialized
INFO - 2024-02-05 00:03:59 --> Model "User_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:03:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:03:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:03:59 --> Final output sent to browser
DEBUG - 2024-02-05 00:03:59 --> Total execution time: 0.0619
INFO - 2024-02-05 00:04:25 --> Config Class Initialized
INFO - 2024-02-05 00:04:25 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:25 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:25 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:25 --> URI Class Initialized
INFO - 2024-02-05 00:04:25 --> Router Class Initialized
INFO - 2024-02-05 00:04:25 --> Output Class Initialized
INFO - 2024-02-05 00:04:25 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:25 --> Input Class Initialized
INFO - 2024-02-05 00:04:25 --> Language Class Initialized
INFO - 2024-02-05 00:04:25 --> Loader Class Initialized
INFO - 2024-02-05 00:04:25 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:25 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:25 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:25 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:25 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:25 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:25 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:25 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:25 --> Controller Class Initialized
INFO - 2024-02-05 00:04:25 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-05 00:04:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:25 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:25 --> Total execution time: 0.0860
INFO - 2024-02-05 00:04:26 --> Config Class Initialized
INFO - 2024-02-05 00:04:26 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:26 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:26 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:26 --> URI Class Initialized
INFO - 2024-02-05 00:04:26 --> Router Class Initialized
INFO - 2024-02-05 00:04:26 --> Output Class Initialized
INFO - 2024-02-05 00:04:26 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:26 --> Input Class Initialized
INFO - 2024-02-05 00:04:26 --> Language Class Initialized
INFO - 2024-02-05 00:04:26 --> Loader Class Initialized
INFO - 2024-02-05 00:04:26 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:26 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:26 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:26 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:26 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:26 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:26 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:26 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:26 --> Controller Class Initialized
INFO - 2024-02-05 00:04:26 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_permintaan.php
INFO - 2024-02-05 00:04:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:26 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:26 --> Total execution time: 0.0792
INFO - 2024-02-05 00:04:28 --> Config Class Initialized
INFO - 2024-02-05 00:04:28 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:28 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:28 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:28 --> URI Class Initialized
INFO - 2024-02-05 00:04:28 --> Router Class Initialized
INFO - 2024-02-05 00:04:28 --> Output Class Initialized
INFO - 2024-02-05 00:04:28 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:28 --> Input Class Initialized
INFO - 2024-02-05 00:04:28 --> Language Class Initialized
INFO - 2024-02-05 00:04:28 --> Loader Class Initialized
INFO - 2024-02-05 00:04:28 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:28 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:28 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:28 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:28 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:28 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:28 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:28 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:28 --> Controller Class Initialized
INFO - 2024-02-05 00:04:28 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:04:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:28 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:28 --> Total execution time: 0.0622
INFO - 2024-02-05 00:04:29 --> Config Class Initialized
INFO - 2024-02-05 00:04:29 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:29 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:29 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:29 --> URI Class Initialized
INFO - 2024-02-05 00:04:29 --> Router Class Initialized
INFO - 2024-02-05 00:04:29 --> Output Class Initialized
INFO - 2024-02-05 00:04:29 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:29 --> Input Class Initialized
INFO - 2024-02-05 00:04:29 --> Language Class Initialized
INFO - 2024-02-05 00:04:29 --> Loader Class Initialized
INFO - 2024-02-05 00:04:29 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:29 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:29 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:29 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:29 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:29 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:29 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:29 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:29 --> Controller Class Initialized
INFO - 2024-02-05 00:04:29 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:29 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:29 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:04:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:29 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:29 --> Total execution time: 0.0613
INFO - 2024-02-05 00:04:30 --> Config Class Initialized
INFO - 2024-02-05 00:04:30 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:30 --> URI Class Initialized
INFO - 2024-02-05 00:04:30 --> Router Class Initialized
INFO - 2024-02-05 00:04:30 --> Output Class Initialized
INFO - 2024-02-05 00:04:30 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:30 --> Input Class Initialized
INFO - 2024-02-05 00:04:30 --> Language Class Initialized
INFO - 2024-02-05 00:04:30 --> Loader Class Initialized
INFO - 2024-02-05 00:04:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:30 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:30 --> Controller Class Initialized
INFO - 2024-02-05 00:04:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:30 --> Total execution time: 0.0479
INFO - 2024-02-05 00:04:30 --> Config Class Initialized
INFO - 2024-02-05 00:04:30 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:30 --> URI Class Initialized
INFO - 2024-02-05 00:04:30 --> Router Class Initialized
INFO - 2024-02-05 00:04:30 --> Output Class Initialized
INFO - 2024-02-05 00:04:30 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:30 --> Input Class Initialized
INFO - 2024-02-05 00:04:30 --> Language Class Initialized
INFO - 2024-02-05 00:04:30 --> Loader Class Initialized
INFO - 2024-02-05 00:04:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:30 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:30 --> Controller Class Initialized
INFO - 2024-02-05 00:04:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_permintaan.php
INFO - 2024-02-05 00:04:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:30 --> Total execution time: 0.0703
INFO - 2024-02-05 00:04:49 --> Config Class Initialized
INFO - 2024-02-05 00:04:49 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:49 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:49 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:49 --> URI Class Initialized
INFO - 2024-02-05 00:04:49 --> Router Class Initialized
INFO - 2024-02-05 00:04:49 --> Output Class Initialized
INFO - 2024-02-05 00:04:49 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:49 --> Input Class Initialized
INFO - 2024-02-05 00:04:49 --> Language Class Initialized
INFO - 2024-02-05 00:04:49 --> Loader Class Initialized
INFO - 2024-02-05 00:04:49 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:49 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:49 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:49 --> Controller Class Initialized
INFO - 2024-02-05 00:04:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:04:49 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:04:49 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Permintaan_model.php 129
INFO - 2024-02-05 00:04:49 --> Upload Class Initialized
INFO - 2024-02-05 00:04:49 --> Config Class Initialized
INFO - 2024-02-05 00:04:49 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:49 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:49 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:49 --> URI Class Initialized
INFO - 2024-02-05 00:04:49 --> Router Class Initialized
INFO - 2024-02-05 00:04:49 --> Output Class Initialized
INFO - 2024-02-05 00:04:49 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:49 --> Input Class Initialized
INFO - 2024-02-05 00:04:49 --> Language Class Initialized
INFO - 2024-02-05 00:04:49 --> Loader Class Initialized
INFO - 2024-02-05 00:04:49 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:49 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:49 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:49 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:49 --> Controller Class Initialized
INFO - 2024-02-05 00:04:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-02-05 00:04:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:49 --> Total execution time: 0.0674
INFO - 2024-02-05 00:04:55 --> Config Class Initialized
INFO - 2024-02-05 00:04:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:55 --> URI Class Initialized
INFO - 2024-02-05 00:04:55 --> Router Class Initialized
INFO - 2024-02-05 00:04:55 --> Output Class Initialized
INFO - 2024-02-05 00:04:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:55 --> Input Class Initialized
INFO - 2024-02-05 00:04:55 --> Language Class Initialized
INFO - 2024-02-05 00:04:55 --> Loader Class Initialized
INFO - 2024-02-05 00:04:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:55 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:55 --> Controller Class Initialized
INFO - 2024-02-05 00:04:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:04:55 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:04:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:55 --> Total execution time: 0.0804
INFO - 2024-02-05 00:04:55 --> Config Class Initialized
INFO - 2024-02-05 00:04:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:55 --> URI Class Initialized
INFO - 2024-02-05 00:04:55 --> Router Class Initialized
INFO - 2024-02-05 00:04:55 --> Output Class Initialized
INFO - 2024-02-05 00:04:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:55 --> Input Class Initialized
INFO - 2024-02-05 00:04:55 --> Language Class Initialized
INFO - 2024-02-05 00:04:55 --> Loader Class Initialized
INFO - 2024-02-05 00:04:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:55 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:55 --> Controller Class Initialized
INFO - 2024-02-05 00:04:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:04:56 --> Severity: Notice --> Undefined variable: id_permintaan C:\xampp\htdocs\simba\application\controllers\Admin.php 434
INFO - 2024-02-05 00:04:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:04:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:04:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:04:56 --> Severity: Notice --> Undefined variable: JBarang C:\xampp\htdocs\simba\application\views\admin\t_pesanan.php 34
ERROR - 2024-02-05 00:04:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\simba\application\views\admin\t_pesanan.php 34
INFO - 2024-02-05 00:04:56 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_pesanan.php
INFO - 2024-02-05 00:04:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:04:56 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:56 --> Total execution time: 0.1078
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:04:58 --> Config Class Initialized
INFO - 2024-02-05 00:04:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:04:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> URI Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
INFO - 2024-02-05 00:04:58 --> Router Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
INFO - 2024-02-05 00:04:58 --> Output Class Initialized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:58 --> Security Class Initialized
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Input Class Initialized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Language Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Loader Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
INFO - 2024-02-05 00:04:58 --> Email Class Initialized
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.0556
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.0661
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.0768
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.0887
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.1044
INFO - 2024-02-05 00:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:04:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:04:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:04:58 --> Controller Class Initialized
INFO - 2024-02-05 00:04:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:04:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:04:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:04:58 --> Total execution time: 0.1159
INFO - 2024-02-05 00:05:12 --> Config Class Initialized
INFO - 2024-02-05 00:05:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:12 --> URI Class Initialized
INFO - 2024-02-05 00:05:12 --> Router Class Initialized
INFO - 2024-02-05 00:05:12 --> Output Class Initialized
INFO - 2024-02-05 00:05:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:12 --> Input Class Initialized
INFO - 2024-02-05 00:05:12 --> Language Class Initialized
INFO - 2024-02-05 00:05:12 --> Loader Class Initialized
INFO - 2024-02-05 00:05:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:12 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:12 --> Controller Class Initialized
INFO - 2024-02-05 00:05:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:12 --> Severity: Notice --> Undefined variable: id_permintaan C:\xampp\htdocs\simba\application\controllers\Admin.php 434
INFO - 2024-02-05 00:05:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:05:13 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:05:13 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 189
INFO - 2024-02-05 00:05:13 --> Upload Class Initialized
INFO - 2024-02-05 00:05:13 --> Config Class Initialized
INFO - 2024-02-05 00:05:13 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:13 --> URI Class Initialized
INFO - 2024-02-05 00:05:13 --> Router Class Initialized
INFO - 2024-02-05 00:05:13 --> Output Class Initialized
INFO - 2024-02-05 00:05:13 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:13 --> Input Class Initialized
INFO - 2024-02-05 00:05:13 --> Language Class Initialized
INFO - 2024-02-05 00:05:13 --> Loader Class Initialized
INFO - 2024-02-05 00:05:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:13 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:13 --> Controller Class Initialized
INFO - 2024-02-05 00:05:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:05:13 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:05:13 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:13 --> Total execution time: 0.0734
INFO - 2024-02-05 00:05:15 --> Config Class Initialized
INFO - 2024-02-05 00:05:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:15 --> URI Class Initialized
INFO - 2024-02-05 00:05:15 --> Router Class Initialized
INFO - 2024-02-05 00:05:16 --> Output Class Initialized
INFO - 2024-02-05 00:05:16 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:16 --> Input Class Initialized
INFO - 2024-02-05 00:05:16 --> Language Class Initialized
INFO - 2024-02-05 00:05:16 --> Loader Class Initialized
INFO - 2024-02-05 00:05:16 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:16 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:16 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:16 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:16 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:16 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:16 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:16 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:16 --> Controller Class Initialized
INFO - 2024-02-05 00:05:16 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:05:16 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:05:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:16 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:16 --> Total execution time: 0.0772
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:19 --> Config Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
INFO - 2024-02-05 00:05:19 --> URI Class Initialized
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
INFO - 2024-02-05 00:05:19 --> Router Class Initialized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
INFO - 2024-02-05 00:05:19 --> Output Class Initialized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
INFO - 2024-02-05 00:05:19 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Input Class Initialized
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
INFO - 2024-02-05 00:05:19 --> Language Class Initialized
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Loader Class Initialized
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
INFO - 2024-02-05 00:05:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:19 --> Controller Class Initialized
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:19 --> Total execution time: 0.0569
INFO - 2024-02-05 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:19 --> Controller Class Initialized
INFO - 2024-02-05 00:05:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:19 --> Total execution time: 0.0678
INFO - 2024-02-05 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:19 --> Controller Class Initialized
INFO - 2024-02-05 00:05:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:19 --> Total execution time: 0.0785
INFO - 2024-02-05 00:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:19 --> Controller Class Initialized
INFO - 2024-02-05 00:05:20 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:20 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:20 --> Total execution time: 0.0910
INFO - 2024-02-05 00:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:20 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:20 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:20 --> Controller Class Initialized
INFO - 2024-02-05 00:05:20 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:20 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:20 --> Total execution time: 0.1022
INFO - 2024-02-05 00:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:20 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:20 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:20 --> Controller Class Initialized
INFO - 2024-02-05 00:05:20 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:20 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:20 --> Total execution time: 0.1136
INFO - 2024-02-05 00:05:26 --> Config Class Initialized
INFO - 2024-02-05 00:05:26 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:26 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:26 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:26 --> URI Class Initialized
INFO - 2024-02-05 00:05:26 --> Router Class Initialized
INFO - 2024-02-05 00:05:26 --> Output Class Initialized
INFO - 2024-02-05 00:05:26 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:27 --> Input Class Initialized
INFO - 2024-02-05 00:05:27 --> Language Class Initialized
INFO - 2024-02-05 00:05:27 --> Loader Class Initialized
INFO - 2024-02-05 00:05:27 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:27 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:27 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:27 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:27 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:27 --> Controller Class Initialized
INFO - 2024-02-05 00:05:27 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:27 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:27 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:05:27 --> Config Class Initialized
INFO - 2024-02-05 00:05:27 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:27 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:27 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:27 --> URI Class Initialized
INFO - 2024-02-05 00:05:27 --> Router Class Initialized
INFO - 2024-02-05 00:05:27 --> Output Class Initialized
INFO - 2024-02-05 00:05:27 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:27 --> Input Class Initialized
INFO - 2024-02-05 00:05:27 --> Language Class Initialized
INFO - 2024-02-05 00:05:27 --> Loader Class Initialized
INFO - 2024-02-05 00:05:27 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:27 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:27 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:27 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:27 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:27 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:27 --> Controller Class Initialized
INFO - 2024-02-05 00:05:27 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:05:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:05:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:27 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:27 --> Total execution time: 0.0495
INFO - 2024-02-05 00:05:30 --> Config Class Initialized
INFO - 2024-02-05 00:05:30 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:30 --> URI Class Initialized
INFO - 2024-02-05 00:05:30 --> Router Class Initialized
INFO - 2024-02-05 00:05:30 --> Output Class Initialized
INFO - 2024-02-05 00:05:30 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:30 --> Input Class Initialized
INFO - 2024-02-05 00:05:30 --> Language Class Initialized
INFO - 2024-02-05 00:05:30 --> Loader Class Initialized
INFO - 2024-02-05 00:05:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:30 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:30 --> Controller Class Initialized
INFO - 2024-02-05 00:05:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:05:30 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:05:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:30 --> Total execution time: 0.0764
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:33 --> Config Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> URI Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
INFO - 2024-02-05 00:05:33 --> Router Class Initialized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
INFO - 2024-02-05 00:05:33 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> Security Class Initialized
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
INFO - 2024-02-05 00:05:33 --> Input Class Initialized
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Language Class Initialized
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
INFO - 2024-02-05 00:05:33 --> Loader Class Initialized
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
INFO - 2024-02-05 00:05:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
DEBUG - 2024-02-05 00:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.0552
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.0718
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.0827
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.0936
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.1048
INFO - 2024-02-05 00:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:33 --> Controller Class Initialized
INFO - 2024-02-05 00:05:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:33 --> Total execution time: 0.1196
INFO - 2024-02-05 00:05:40 --> Config Class Initialized
INFO - 2024-02-05 00:05:40 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:40 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:40 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:40 --> URI Class Initialized
INFO - 2024-02-05 00:05:40 --> Router Class Initialized
INFO - 2024-02-05 00:05:40 --> Output Class Initialized
INFO - 2024-02-05 00:05:40 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:40 --> Input Class Initialized
INFO - 2024-02-05 00:05:40 --> Language Class Initialized
INFO - 2024-02-05 00:05:40 --> Loader Class Initialized
INFO - 2024-02-05 00:05:40 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:40 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:40 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:40 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:40 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:40 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:40 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:40 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:40 --> Controller Class Initialized
INFO - 2024-02-05 00:05:40 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:40 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:40 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:05:40 --> 404 Page Not Found: 
INFO - 2024-02-05 00:05:42 --> Config Class Initialized
INFO - 2024-02-05 00:05:42 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:42 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:42 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:42 --> URI Class Initialized
INFO - 2024-02-05 00:05:42 --> Router Class Initialized
INFO - 2024-02-05 00:05:42 --> Output Class Initialized
INFO - 2024-02-05 00:05:42 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:42 --> Input Class Initialized
INFO - 2024-02-05 00:05:42 --> Language Class Initialized
INFO - 2024-02-05 00:05:42 --> Loader Class Initialized
INFO - 2024-02-05 00:05:42 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:42 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:42 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:42 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:42 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:42 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:42 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:42 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:42 --> Controller Class Initialized
INFO - 2024-02-05 00:05:42 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:42 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:05:42 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:05:42 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:05:42 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:42 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:42 --> Total execution time: 0.0751
INFO - 2024-02-05 00:05:43 --> Config Class Initialized
INFO - 2024-02-05 00:05:43 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:43 --> URI Class Initialized
INFO - 2024-02-05 00:05:43 --> Router Class Initialized
INFO - 2024-02-05 00:05:43 --> Output Class Initialized
INFO - 2024-02-05 00:05:43 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:43 --> Input Class Initialized
INFO - 2024-02-05 00:05:43 --> Language Class Initialized
INFO - 2024-02-05 00:05:43 --> Loader Class Initialized
INFO - 2024-02-05 00:05:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:43 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:43 --> Controller Class Initialized
INFO - 2024-02-05 00:05:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:05:43 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:05:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:43 --> Total execution time: 0.1172
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
INFO - 2024-02-05 00:05:44 --> Config Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
INFO - 2024-02-05 00:05:44 --> URI Class Initialized
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
INFO - 2024-02-05 00:05:44 --> Router Class Initialized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Output Class Initialized
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Security Class Initialized
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
INFO - 2024-02-05 00:05:44 --> Input Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Language Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Loader Class Initialized
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
INFO - 2024-02-05 00:05:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:44 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.0594
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.0668
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.0837
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.0941
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.1080
INFO - 2024-02-05 00:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:44 --> Controller Class Initialized
INFO - 2024-02-05 00:05:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:44 --> Total execution time: 0.1213
INFO - 2024-02-05 00:05:48 --> Config Class Initialized
INFO - 2024-02-05 00:05:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:48 --> URI Class Initialized
INFO - 2024-02-05 00:05:48 --> Router Class Initialized
INFO - 2024-02-05 00:05:48 --> Output Class Initialized
INFO - 2024-02-05 00:05:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:48 --> Input Class Initialized
INFO - 2024-02-05 00:05:48 --> Language Class Initialized
INFO - 2024-02-05 00:05:48 --> Loader Class Initialized
INFO - 2024-02-05 00:05:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:48 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:48 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:48 --> Controller Class Initialized
INFO - 2024-02-05 00:05:48 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:48 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:48 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:05:48 --> Config Class Initialized
INFO - 2024-02-05 00:05:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:48 --> URI Class Initialized
INFO - 2024-02-05 00:05:48 --> Router Class Initialized
INFO - 2024-02-05 00:05:48 --> Output Class Initialized
INFO - 2024-02-05 00:05:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:48 --> Input Class Initialized
INFO - 2024-02-05 00:05:48 --> Language Class Initialized
INFO - 2024-02-05 00:05:48 --> Loader Class Initialized
INFO - 2024-02-05 00:05:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:48 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:48 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:48 --> Controller Class Initialized
INFO - 2024-02-05 00:05:48 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:05:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:48 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:48 --> Total execution time: 0.0517
INFO - 2024-02-05 00:05:50 --> Config Class Initialized
INFO - 2024-02-05 00:05:50 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:50 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:50 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:50 --> URI Class Initialized
INFO - 2024-02-05 00:05:50 --> Router Class Initialized
INFO - 2024-02-05 00:05:50 --> Output Class Initialized
INFO - 2024-02-05 00:05:50 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:50 --> Input Class Initialized
INFO - 2024-02-05 00:05:50 --> Language Class Initialized
INFO - 2024-02-05 00:05:50 --> Loader Class Initialized
INFO - 2024-02-05 00:05:50 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:50 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:50 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:50 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:50 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:50 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:50 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:50 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:50 --> Controller Class Initialized
INFO - 2024-02-05 00:05:50 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:50 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:05:50 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:05:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:50 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:50 --> Total execution time: 0.0810
INFO - 2024-02-05 00:05:52 --> Config Class Initialized
INFO - 2024-02-05 00:05:52 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:52 --> URI Class Initialized
INFO - 2024-02-05 00:05:52 --> Router Class Initialized
INFO - 2024-02-05 00:05:52 --> Output Class Initialized
INFO - 2024-02-05 00:05:52 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:52 --> Input Class Initialized
INFO - 2024-02-05 00:05:52 --> Language Class Initialized
INFO - 2024-02-05 00:05:52 --> Loader Class Initialized
INFO - 2024-02-05 00:05:52 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:52 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:52 --> Controller Class Initialized
INFO - 2024-02-05 00:05:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:05:52 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:05:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:52 --> Total execution time: 0.0663
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:54 --> Config Class Initialized
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> Hooks Class Initialized
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
DEBUG - 2024-02-05 00:05:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
INFO - 2024-02-05 00:05:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> URI Class Initialized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
INFO - 2024-02-05 00:05:54 --> Router Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:54 --> Output Class Initialized
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> Security Class Initialized
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Input Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Language Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Loader Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.0568
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Email Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.0669
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.0776
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.0905
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.1021
INFO - 2024-02-05 00:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:54 --> Controller Class Initialized
INFO - 2024-02-05 00:05:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:54 --> Total execution time: 0.1148
INFO - 2024-02-05 00:05:57 --> Config Class Initialized
INFO - 2024-02-05 00:05:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:57 --> URI Class Initialized
INFO - 2024-02-05 00:05:57 --> Router Class Initialized
INFO - 2024-02-05 00:05:57 --> Output Class Initialized
INFO - 2024-02-05 00:05:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:57 --> Input Class Initialized
INFO - 2024-02-05 00:05:57 --> Language Class Initialized
INFO - 2024-02-05 00:05:57 --> Loader Class Initialized
INFO - 2024-02-05 00:05:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:57 --> Controller Class Initialized
INFO - 2024-02-05 00:05:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:05:57 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:05:57 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:05:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:05:57 --> Config Class Initialized
INFO - 2024-02-05 00:05:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:05:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:05:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:05:57 --> URI Class Initialized
INFO - 2024-02-05 00:05:57 --> Router Class Initialized
INFO - 2024-02-05 00:05:57 --> Output Class Initialized
INFO - 2024-02-05 00:05:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:05:57 --> Input Class Initialized
INFO - 2024-02-05 00:05:57 --> Language Class Initialized
INFO - 2024-02-05 00:05:57 --> Loader Class Initialized
INFO - 2024-02-05 00:05:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:05:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:05:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:05:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:05:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:05:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:05:57 --> Controller Class Initialized
INFO - 2024-02-05 00:05:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:05:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:05:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:05:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:05:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:05:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:05:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:05:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:05:57 --> Final output sent to browser
DEBUG - 2024-02-05 00:05:57 --> Total execution time: 0.0670
INFO - 2024-02-05 00:06:08 --> Config Class Initialized
INFO - 2024-02-05 00:06:08 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:06:08 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:08 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:08 --> URI Class Initialized
INFO - 2024-02-05 00:06:08 --> Router Class Initialized
INFO - 2024-02-05 00:06:08 --> Output Class Initialized
INFO - 2024-02-05 00:06:08 --> Security Class Initialized
DEBUG - 2024-02-05 00:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:08 --> Input Class Initialized
INFO - 2024-02-05 00:06:08 --> Language Class Initialized
INFO - 2024-02-05 00:06:08 --> Loader Class Initialized
INFO - 2024-02-05 00:06:08 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:08 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:08 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:08 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:09 --> Email Class Initialized
DEBUG - 2024-02-05 00:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:09 --> Controller Class Initialized
INFO - 2024-02-05 00:06:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 165
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 166
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 167
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 176
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:06:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:06:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:06:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:06:09 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:06:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:06:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:06:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:09 --> Total execution time: 0.0809
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
INFO - 2024-02-05 00:06:13 --> Config Class Initialized
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:13 --> Hooks Class Initialized
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
DEBUG - 2024-02-05 00:06:13 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
INFO - 2024-02-05 00:06:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> URI Class Initialized
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
INFO - 2024-02-05 00:06:13 --> Router Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
INFO - 2024-02-05 00:06:13 --> Output Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
INFO - 2024-02-05 00:06:13 --> Security Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
INFO - 2024-02-05 00:06:13 --> Input Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Language Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Loader Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:13 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
INFO - 2024-02-05 00:06:13 --> Email Class Initialized
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.0573
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.0680
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.0807
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.0937
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.1056
INFO - 2024-02-05 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:13 --> Controller Class Initialized
INFO - 2024-02-05 00:06:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:13 --> Total execution time: 0.1194
INFO - 2024-02-05 00:06:14 --> Config Class Initialized
INFO - 2024-02-05 00:06:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:06:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:14 --> URI Class Initialized
INFO - 2024-02-05 00:06:14 --> Router Class Initialized
INFO - 2024-02-05 00:06:14 --> Output Class Initialized
INFO - 2024-02-05 00:06:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:14 --> Input Class Initialized
INFO - 2024-02-05 00:06:14 --> Language Class Initialized
INFO - 2024-02-05 00:06:14 --> Loader Class Initialized
INFO - 2024-02-05 00:06:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:15 --> Controller Class Initialized
INFO - 2024-02-05 00:06:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:06:15 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 164
ERROR - 2024-02-05 00:06:15 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 178
INFO - 2024-02-05 00:06:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:06:15 --> Config Class Initialized
INFO - 2024-02-05 00:06:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:06:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:06:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:06:15 --> URI Class Initialized
INFO - 2024-02-05 00:06:15 --> Router Class Initialized
INFO - 2024-02-05 00:06:15 --> Output Class Initialized
INFO - 2024-02-05 00:06:15 --> Security Class Initialized
DEBUG - 2024-02-05 00:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:06:15 --> Input Class Initialized
INFO - 2024-02-05 00:06:15 --> Language Class Initialized
INFO - 2024-02-05 00:06:15 --> Loader Class Initialized
INFO - 2024-02-05 00:06:15 --> Helper loaded: url_helper
INFO - 2024-02-05 00:06:15 --> Helper loaded: file_helper
INFO - 2024-02-05 00:06:15 --> Helper loaded: security_helper
INFO - 2024-02-05 00:06:15 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:06:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:06:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:06:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:06:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:06:15 --> Controller Class Initialized
INFO - 2024-02-05 00:06:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:06:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:06:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:06:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:06:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:06:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:06:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:06:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:06:15 --> Final output sent to browser
DEBUG - 2024-02-05 00:06:15 --> Total execution time: 0.0519
INFO - 2024-02-05 00:09:14 --> Config Class Initialized
INFO - 2024-02-05 00:09:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:14 --> URI Class Initialized
INFO - 2024-02-05 00:09:14 --> Router Class Initialized
INFO - 2024-02-05 00:09:14 --> Output Class Initialized
INFO - 2024-02-05 00:09:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:14 --> Input Class Initialized
INFO - 2024-02-05 00:09:14 --> Language Class Initialized
INFO - 2024-02-05 00:09:14 --> Loader Class Initialized
INFO - 2024-02-05 00:09:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:14 --> Controller Class Initialized
INFO - 2024-02-05 00:09:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:09:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:09:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:09:14 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:09:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:09:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:14 --> Total execution time: 0.0622
INFO - 2024-02-05 00:09:16 --> Config Class Initialized
INFO - 2024-02-05 00:09:16 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:16 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:16 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:16 --> URI Class Initialized
INFO - 2024-02-05 00:09:16 --> Router Class Initialized
INFO - 2024-02-05 00:09:16 --> Output Class Initialized
INFO - 2024-02-05 00:09:16 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:16 --> Input Class Initialized
INFO - 2024-02-05 00:09:16 --> Language Class Initialized
INFO - 2024-02-05 00:09:16 --> Loader Class Initialized
INFO - 2024-02-05 00:09:16 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:16 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:16 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:16 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:16 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:16 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:16 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:16 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:16 --> Controller Class Initialized
INFO - 2024-02-05 00:09:16 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 175
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 181
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-05 00:09:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:09:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:09:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:09:16 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:09:16 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:09:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:09:16 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:16 --> Total execution time: 0.0853
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:19 --> Config Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
DEBUG - 2024-02-05 00:09:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
INFO - 2024-02-05 00:09:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> URI Class Initialized
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Router Class Initialized
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Output Class Initialized
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Security Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Input Class Initialized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> Language Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.0644
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Loader Class Initialized
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.0777
INFO - 2024-02-05 00:09:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Email Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
DEBUG - 2024-02-05 00:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.0885
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.1126
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.1266
INFO - 2024-02-05 00:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:19 --> Controller Class Initialized
INFO - 2024-02-05 00:09:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:19 --> Total execution time: 0.1523
INFO - 2024-02-05 00:09:23 --> Config Class Initialized
INFO - 2024-02-05 00:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:23 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:23 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:23 --> URI Class Initialized
INFO - 2024-02-05 00:09:23 --> Router Class Initialized
INFO - 2024-02-05 00:09:23 --> Output Class Initialized
INFO - 2024-02-05 00:09:23 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:23 --> Input Class Initialized
INFO - 2024-02-05 00:09:23 --> Language Class Initialized
INFO - 2024-02-05 00:09:23 --> Loader Class Initialized
INFO - 2024-02-05 00:09:23 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:23 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:23 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:23 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:23 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:23 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:23 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:23 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:23 --> Controller Class Initialized
INFO - 2024-02-05 00:09:23 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:23 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:09:23 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-05 00:09:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:09:23 --> Config Class Initialized
INFO - 2024-02-05 00:09:23 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:24 --> URI Class Initialized
INFO - 2024-02-05 00:09:24 --> Router Class Initialized
INFO - 2024-02-05 00:09:24 --> Output Class Initialized
INFO - 2024-02-05 00:09:24 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:24 --> Input Class Initialized
INFO - 2024-02-05 00:09:24 --> Language Class Initialized
INFO - 2024-02-05 00:09:24 --> Loader Class Initialized
INFO - 2024-02-05 00:09:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:24 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:24 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:24 --> Controller Class Initialized
INFO - 2024-02-05 00:09:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:09:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:09:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:09:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:09:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:09:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:24 --> Total execution time: 0.0681
INFO - 2024-02-05 00:09:27 --> Config Class Initialized
INFO - 2024-02-05 00:09:27 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:27 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:27 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:27 --> URI Class Initialized
INFO - 2024-02-05 00:09:27 --> Router Class Initialized
INFO - 2024-02-05 00:09:27 --> Output Class Initialized
INFO - 2024-02-05 00:09:27 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:27 --> Input Class Initialized
INFO - 2024-02-05 00:09:27 --> Language Class Initialized
INFO - 2024-02-05 00:09:27 --> Loader Class Initialized
INFO - 2024-02-05 00:09:27 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:27 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:27 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:27 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:27 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:27 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:27 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:27 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:27 --> Controller Class Initialized
INFO - 2024-02-05 00:09:27 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: id_permintaan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: id_supplier C:\xampp\htdocs\simba\application\models\Pesanan_model.php 169
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: id_jenis_faktur C:\xampp\htdocs\simba\application\models\Pesanan_model.php 170
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: surat_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 171
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: uraian C:\xampp\htdocs\simba\application\models\Pesanan_model.php 172
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: tanggal_surat C:\xampp\htdocs\simba\application\models\Pesanan_model.php 173
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: nip C:\xampp\htdocs\simba\application\models\Pesanan_model.php 174
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\simba\application\models\Pesanan_model.php 175
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: old_file C:\xampp\htdocs\simba\application\models\Pesanan_model.php 181
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-05 00:09:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:09:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:09:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:09:27 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:09:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:09:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:09:27 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:27 --> Total execution time: 0.0691
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
INFO - 2024-02-05 00:09:30 --> Config Class Initialized
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:30 --> Hooks Class Initialized
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
DEBUG - 2024-02-05 00:09:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> URI Class Initialized
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Router Class Initialized
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Output Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Security Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
DEBUG - 2024-02-05 00:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> Input Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:30 --> Language Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Loader Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:30 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Email Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.0720
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.0883
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.0958
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.1098
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.1275
INFO - 2024-02-05 00:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:30 --> Controller Class Initialized
INFO - 2024-02-05 00:09:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:09:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:09:30 --> Total execution time: 0.1482
INFO - 2024-02-05 00:09:32 --> Config Class Initialized
INFO - 2024-02-05 00:09:32 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:09:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:09:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:09:32 --> URI Class Initialized
INFO - 2024-02-05 00:09:32 --> Router Class Initialized
INFO - 2024-02-05 00:09:32 --> Output Class Initialized
INFO - 2024-02-05 00:09:32 --> Security Class Initialized
DEBUG - 2024-02-05 00:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:09:32 --> Input Class Initialized
INFO - 2024-02-05 00:09:32 --> Language Class Initialized
INFO - 2024-02-05 00:09:32 --> Loader Class Initialized
INFO - 2024-02-05 00:09:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:09:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:09:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:09:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:09:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:09:32 --> Email Class Initialized
DEBUG - 2024-02-05 00:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:09:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:09:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:09:32 --> Controller Class Initialized
INFO - 2024-02-05 00:09:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:09:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:09:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:09:32 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 184
INFO - 2024-02-05 00:09:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:09:32 --> 404 Page Not Found: 
INFO - 2024-02-05 00:13:34 --> Config Class Initialized
INFO - 2024-02-05 00:13:34 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:13:34 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:13:34 --> Utf8 Class Initialized
INFO - 2024-02-05 00:13:34 --> URI Class Initialized
INFO - 2024-02-05 00:13:34 --> Router Class Initialized
INFO - 2024-02-05 00:13:34 --> Output Class Initialized
INFO - 2024-02-05 00:13:34 --> Security Class Initialized
DEBUG - 2024-02-05 00:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:13:34 --> Input Class Initialized
INFO - 2024-02-05 00:13:34 --> Language Class Initialized
INFO - 2024-02-05 00:13:34 --> Loader Class Initialized
INFO - 2024-02-05 00:13:34 --> Helper loaded: url_helper
INFO - 2024-02-05 00:13:34 --> Helper loaded: file_helper
INFO - 2024-02-05 00:13:34 --> Helper loaded: security_helper
INFO - 2024-02-05 00:13:34 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:13:34 --> Database Driver Class Initialized
INFO - 2024-02-05 00:13:34 --> Email Class Initialized
DEBUG - 2024-02-05 00:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:13:34 --> Helper loaded: form_helper
INFO - 2024-02-05 00:13:34 --> Form Validation Class Initialized
INFO - 2024-02-05 00:13:34 --> Controller Class Initialized
INFO - 2024-02-05 00:13:34 --> Model "User_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:13:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:13:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:13:34 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 168
ERROR - 2024-02-05 00:13:34 --> Severity: Notice --> Undefined index: id_pesanan C:\xampp\htdocs\simba\application\models\Pesanan_model.php 185
INFO - 2024-02-05 00:13:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:13:34 --> 404 Page Not Found: 
INFO - 2024-02-05 00:14:15 --> Config Class Initialized
INFO - 2024-02-05 00:14:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:15 --> URI Class Initialized
INFO - 2024-02-05 00:14:15 --> Router Class Initialized
INFO - 2024-02-05 00:14:15 --> Output Class Initialized
INFO - 2024-02-05 00:14:15 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:15 --> Input Class Initialized
INFO - 2024-02-05 00:14:15 --> Language Class Initialized
INFO - 2024-02-05 00:14:15 --> Loader Class Initialized
INFO - 2024-02-05 00:14:15 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:15 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:15 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:15 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:15 --> Controller Class Initialized
INFO - 2024-02-05 00:14:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:14:15 --> 404 Page Not Found: 
INFO - 2024-02-05 00:14:18 --> Config Class Initialized
INFO - 2024-02-05 00:14:18 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:18 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:18 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:18 --> URI Class Initialized
INFO - 2024-02-05 00:14:18 --> Router Class Initialized
INFO - 2024-02-05 00:14:18 --> Output Class Initialized
INFO - 2024-02-05 00:14:18 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:18 --> Input Class Initialized
INFO - 2024-02-05 00:14:18 --> Language Class Initialized
INFO - 2024-02-05 00:14:18 --> Loader Class Initialized
INFO - 2024-02-05 00:14:18 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:18 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:18 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:18 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:18 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:18 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:18 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:18 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:18 --> Controller Class Initialized
INFO - 2024-02-05 00:14:18 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:14:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:14:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:14:18 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:14:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:14:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:14:18 --> Final output sent to browser
DEBUG - 2024-02-05 00:14:18 --> Total execution time: 0.0641
INFO - 2024-02-05 00:14:19 --> Config Class Initialized
INFO - 2024-02-05 00:14:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:19 --> URI Class Initialized
INFO - 2024-02-05 00:14:19 --> Router Class Initialized
INFO - 2024-02-05 00:14:19 --> Output Class Initialized
INFO - 2024-02-05 00:14:19 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:19 --> Input Class Initialized
INFO - 2024-02-05 00:14:19 --> Language Class Initialized
INFO - 2024-02-05 00:14:19 --> Loader Class Initialized
INFO - 2024-02-05 00:14:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:19 --> Controller Class Initialized
INFO - 2024-02-05 00:14:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:14:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:14:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:14:19 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:14:19 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:14:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:14:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:14:19 --> Total execution time: 0.0760
INFO - 2024-02-05 00:14:36 --> Config Class Initialized
INFO - 2024-02-05 00:14:36 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:36 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:36 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:36 --> URI Class Initialized
INFO - 2024-02-05 00:14:36 --> Router Class Initialized
INFO - 2024-02-05 00:14:36 --> Output Class Initialized
INFO - 2024-02-05 00:14:36 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:36 --> Input Class Initialized
INFO - 2024-02-05 00:14:36 --> Language Class Initialized
INFO - 2024-02-05 00:14:36 --> Loader Class Initialized
INFO - 2024-02-05 00:14:36 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:36 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:36 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:36 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:36 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:36 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:36 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:36 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:36 --> Controller Class Initialized
INFO - 2024-02-05 00:14:36 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:14:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:14:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:14:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:14:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:14:36 --> Final output sent to browser
DEBUG - 2024-02-05 00:14:36 --> Total execution time: 0.0805
INFO - 2024-02-05 00:14:37 --> Config Class Initialized
INFO - 2024-02-05 00:14:37 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:37 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:37 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:37 --> URI Class Initialized
INFO - 2024-02-05 00:14:37 --> Router Class Initialized
INFO - 2024-02-05 00:14:37 --> Output Class Initialized
INFO - 2024-02-05 00:14:37 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:37 --> Input Class Initialized
INFO - 2024-02-05 00:14:37 --> Language Class Initialized
INFO - 2024-02-05 00:14:37 --> Loader Class Initialized
INFO - 2024-02-05 00:14:37 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:37 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:37 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:37 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:37 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:37 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:37 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:37 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:37 --> Controller Class Initialized
INFO - 2024-02-05 00:14:37 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:37 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:14:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:14:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:14:37 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:14:37 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:14:37 --> Final output sent to browser
DEBUG - 2024-02-05 00:14:37 --> Total execution time: 0.0827
INFO - 2024-02-05 00:14:39 --> Config Class Initialized
INFO - 2024-02-05 00:14:39 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:14:39 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:14:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:14:39 --> URI Class Initialized
INFO - 2024-02-05 00:14:39 --> Router Class Initialized
INFO - 2024-02-05 00:14:39 --> Output Class Initialized
INFO - 2024-02-05 00:14:39 --> Security Class Initialized
DEBUG - 2024-02-05 00:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:14:39 --> Input Class Initialized
INFO - 2024-02-05 00:14:39 --> Language Class Initialized
INFO - 2024-02-05 00:14:39 --> Loader Class Initialized
INFO - 2024-02-05 00:14:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:14:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:14:39 --> Helper loaded: security_helper
INFO - 2024-02-05 00:14:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:14:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:14:39 --> Email Class Initialized
DEBUG - 2024-02-05 00:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:14:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:14:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:14:39 --> Controller Class Initialized
INFO - 2024-02-05 00:14:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:14:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:14:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:14:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:14:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:14:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:14:39 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:14:39 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:14:39 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:14:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:14:39 --> Total execution time: 0.0842
INFO - 2024-02-05 00:15:49 --> Config Class Initialized
INFO - 2024-02-05 00:15:49 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:15:49 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:49 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:49 --> URI Class Initialized
INFO - 2024-02-05 00:15:49 --> Router Class Initialized
INFO - 2024-02-05 00:15:49 --> Output Class Initialized
INFO - 2024-02-05 00:15:49 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:49 --> Input Class Initialized
INFO - 2024-02-05 00:15:49 --> Language Class Initialized
INFO - 2024-02-05 00:15:49 --> Loader Class Initialized
INFO - 2024-02-05 00:15:49 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:49 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:49 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:49 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:49 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:49 --> Email Class Initialized
DEBUG - 2024-02-05 00:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:49 --> Controller Class Initialized
INFO - 2024-02-05 00:15:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:15:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:15:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:15:49 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:15:49 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:15:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:15:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:49 --> Total execution time: 0.0694
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
INFO - 2024-02-05 00:15:52 --> Config Class Initialized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:52 --> Hooks Class Initialized
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:15:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> URI Class Initialized
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
INFO - 2024-02-05 00:15:52 --> Router Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Output Class Initialized
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:52 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:52 --> Input Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Language Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Loader Class Initialized
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:52 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.0631
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Email Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.0818
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.0967
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.1062
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.1258
INFO - 2024-02-05 00:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:52 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:52 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:52 --> Controller Class Initialized
INFO - 2024-02-05 00:15:52 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:52 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:52 --> Total execution time: 0.1380
INFO - 2024-02-05 00:15:55 --> Config Class Initialized
INFO - 2024-02-05 00:15:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:15:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:55 --> URI Class Initialized
INFO - 2024-02-05 00:15:55 --> Router Class Initialized
INFO - 2024-02-05 00:15:55 --> Output Class Initialized
INFO - 2024-02-05 00:15:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:55 --> Input Class Initialized
INFO - 2024-02-05 00:15:55 --> Language Class Initialized
INFO - 2024-02-05 00:15:55 --> Loader Class Initialized
INFO - 2024-02-05 00:15:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:55 --> Email Class Initialized
DEBUG - 2024-02-05 00:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:55 --> Controller Class Initialized
INFO - 2024-02-05 00:15:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:15:55 --> 404 Page Not Found: 
INFO - 2024-02-05 00:15:57 --> Config Class Initialized
INFO - 2024-02-05 00:15:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:15:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:15:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:15:57 --> URI Class Initialized
INFO - 2024-02-05 00:15:57 --> Router Class Initialized
INFO - 2024-02-05 00:15:57 --> Output Class Initialized
INFO - 2024-02-05 00:15:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:15:57 --> Input Class Initialized
INFO - 2024-02-05 00:15:57 --> Language Class Initialized
INFO - 2024-02-05 00:15:57 --> Loader Class Initialized
INFO - 2024-02-05 00:15:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:15:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:15:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:15:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:15:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:15:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:15:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:15:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:15:57 --> Controller Class Initialized
INFO - 2024-02-05 00:15:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:15:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:15:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:15:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:15:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:15:57 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:15:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:15:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:15:57 --> Final output sent to browser
DEBUG - 2024-02-05 00:15:57 --> Total execution time: 0.0776
INFO - 2024-02-05 00:16:38 --> Config Class Initialized
INFO - 2024-02-05 00:16:38 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:38 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:38 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:38 --> URI Class Initialized
INFO - 2024-02-05 00:16:38 --> Router Class Initialized
INFO - 2024-02-05 00:16:38 --> Output Class Initialized
INFO - 2024-02-05 00:16:38 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:38 --> Input Class Initialized
INFO - 2024-02-05 00:16:38 --> Language Class Initialized
INFO - 2024-02-05 00:16:38 --> Loader Class Initialized
INFO - 2024-02-05 00:16:38 --> Helper loaded: url_helper
INFO - 2024-02-05 00:16:38 --> Helper loaded: file_helper
INFO - 2024-02-05 00:16:38 --> Helper loaded: security_helper
INFO - 2024-02-05 00:16:38 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:16:38 --> Database Driver Class Initialized
INFO - 2024-02-05 00:16:38 --> Email Class Initialized
DEBUG - 2024-02-05 00:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:16:38 --> Helper loaded: form_helper
INFO - 2024-02-05 00:16:38 --> Form Validation Class Initialized
INFO - 2024-02-05 00:16:38 --> Controller Class Initialized
INFO - 2024-02-05 00:16:38 --> Model "User_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:16:38 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:16:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:16:38 --> Config Class Initialized
INFO - 2024-02-05 00:16:38 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:38 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:38 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:38 --> URI Class Initialized
INFO - 2024-02-05 00:16:38 --> Router Class Initialized
INFO - 2024-02-05 00:16:38 --> Output Class Initialized
INFO - 2024-02-05 00:16:38 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:38 --> Input Class Initialized
INFO - 2024-02-05 00:16:38 --> Language Class Initialized
ERROR - 2024-02-05 00:16:38 --> 404 Page Not Found: Admin/error_page
INFO - 2024-02-05 00:16:40 --> Config Class Initialized
INFO - 2024-02-05 00:16:40 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:40 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:40 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:40 --> URI Class Initialized
INFO - 2024-02-05 00:16:40 --> Router Class Initialized
INFO - 2024-02-05 00:16:40 --> Output Class Initialized
INFO - 2024-02-05 00:16:40 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:40 --> Input Class Initialized
INFO - 2024-02-05 00:16:40 --> Language Class Initialized
ERROR - 2024-02-05 00:16:40 --> 404 Page Not Found: Admin/error_page
INFO - 2024-02-05 00:16:43 --> Config Class Initialized
INFO - 2024-02-05 00:16:43 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:43 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:43 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:43 --> URI Class Initialized
INFO - 2024-02-05 00:16:43 --> Router Class Initialized
INFO - 2024-02-05 00:16:43 --> Output Class Initialized
INFO - 2024-02-05 00:16:43 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:43 --> Input Class Initialized
INFO - 2024-02-05 00:16:43 --> Language Class Initialized
INFO - 2024-02-05 00:16:43 --> Loader Class Initialized
INFO - 2024-02-05 00:16:43 --> Helper loaded: url_helper
INFO - 2024-02-05 00:16:43 --> Helper loaded: file_helper
INFO - 2024-02-05 00:16:43 --> Helper loaded: security_helper
INFO - 2024-02-05 00:16:43 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:16:43 --> Database Driver Class Initialized
INFO - 2024-02-05 00:16:43 --> Email Class Initialized
DEBUG - 2024-02-05 00:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:16:43 --> Helper loaded: form_helper
INFO - 2024-02-05 00:16:43 --> Form Validation Class Initialized
INFO - 2024-02-05 00:16:43 --> Controller Class Initialized
INFO - 2024-02-05 00:16:43 --> Model "User_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:16:43 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:16:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:16:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:16:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:16:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:16:43 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:16:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:16:43 --> Final output sent to browser
DEBUG - 2024-02-05 00:16:43 --> Total execution time: 0.0683
INFO - 2024-02-05 00:16:44 --> Config Class Initialized
INFO - 2024-02-05 00:16:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:44 --> URI Class Initialized
INFO - 2024-02-05 00:16:44 --> Router Class Initialized
INFO - 2024-02-05 00:16:44 --> Output Class Initialized
INFO - 2024-02-05 00:16:44 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:44 --> Input Class Initialized
INFO - 2024-02-05 00:16:44 --> Language Class Initialized
INFO - 2024-02-05 00:16:44 --> Loader Class Initialized
INFO - 2024-02-05 00:16:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:16:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:16:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:16:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:16:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:16:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:16:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:16:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:16:44 --> Controller Class Initialized
INFO - 2024-02-05 00:16:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:16:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:16:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:16:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:16:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:16:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:16:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:16:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:16:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:16:44 --> Total execution time: 0.0699
INFO - 2024-02-05 00:16:46 --> Config Class Initialized
INFO - 2024-02-05 00:16:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:46 --> URI Class Initialized
INFO - 2024-02-05 00:16:46 --> Router Class Initialized
INFO - 2024-02-05 00:16:46 --> Output Class Initialized
INFO - 2024-02-05 00:16:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:46 --> Input Class Initialized
INFO - 2024-02-05 00:16:46 --> Language Class Initialized
INFO - 2024-02-05 00:16:46 --> Loader Class Initialized
INFO - 2024-02-05 00:16:46 --> Helper loaded: url_helper
INFO - 2024-02-05 00:16:46 --> Helper loaded: file_helper
INFO - 2024-02-05 00:16:46 --> Helper loaded: security_helper
INFO - 2024-02-05 00:16:46 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:16:46 --> Database Driver Class Initialized
INFO - 2024-02-05 00:16:46 --> Email Class Initialized
DEBUG - 2024-02-05 00:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:16:46 --> Helper loaded: form_helper
INFO - 2024-02-05 00:16:46 --> Form Validation Class Initialized
INFO - 2024-02-05 00:16:46 --> Controller Class Initialized
INFO - 2024-02-05 00:16:46 --> Model "User_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:16:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:16:46 --> Config Class Initialized
INFO - 2024-02-05 00:16:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:16:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:16:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:16:46 --> URI Class Initialized
INFO - 2024-02-05 00:16:46 --> Router Class Initialized
INFO - 2024-02-05 00:16:46 --> Output Class Initialized
INFO - 2024-02-05 00:16:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:16:46 --> Input Class Initialized
INFO - 2024-02-05 00:16:46 --> Language Class Initialized
ERROR - 2024-02-05 00:16:46 --> 404 Page Not Found: Admin/error_page
INFO - 2024-02-05 00:18:07 --> Config Class Initialized
INFO - 2024-02-05 00:18:07 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:07 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:07 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:07 --> URI Class Initialized
INFO - 2024-02-05 00:18:07 --> Router Class Initialized
INFO - 2024-02-05 00:18:07 --> Output Class Initialized
INFO - 2024-02-05 00:18:07 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:07 --> Input Class Initialized
INFO - 2024-02-05 00:18:07 --> Language Class Initialized
ERROR - 2024-02-05 00:18:07 --> 404 Page Not Found: Admin/error_page
INFO - 2024-02-05 00:18:08 --> Config Class Initialized
INFO - 2024-02-05 00:18:08 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:08 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:08 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:08 --> URI Class Initialized
INFO - 2024-02-05 00:18:08 --> Router Class Initialized
INFO - 2024-02-05 00:18:08 --> Output Class Initialized
INFO - 2024-02-05 00:18:08 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:08 --> Input Class Initialized
INFO - 2024-02-05 00:18:08 --> Language Class Initialized
INFO - 2024-02-05 00:18:08 --> Loader Class Initialized
INFO - 2024-02-05 00:18:08 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:08 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:08 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:08 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:08 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:08 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:08 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:08 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:08 --> Controller Class Initialized
INFO - 2024-02-05 00:18:08 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:18:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:18:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:18:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:18:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:18:08 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:08 --> Total execution time: 0.0620
INFO - 2024-02-05 00:18:09 --> Config Class Initialized
INFO - 2024-02-05 00:18:09 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:09 --> URI Class Initialized
INFO - 2024-02-05 00:18:09 --> Router Class Initialized
INFO - 2024-02-05 00:18:09 --> Output Class Initialized
INFO - 2024-02-05 00:18:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:09 --> Input Class Initialized
INFO - 2024-02-05 00:18:09 --> Language Class Initialized
INFO - 2024-02-05 00:18:09 --> Loader Class Initialized
INFO - 2024-02-05 00:18:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:09 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:09 --> Controller Class Initialized
INFO - 2024-02-05 00:18:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:18:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:09 --> Total execution time: 0.1657
INFO - 2024-02-05 00:18:09 --> Config Class Initialized
INFO - 2024-02-05 00:18:09 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:09 --> URI Class Initialized
INFO - 2024-02-05 00:18:09 --> Router Class Initialized
INFO - 2024-02-05 00:18:09 --> Output Class Initialized
INFO - 2024-02-05 00:18:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:09 --> Input Class Initialized
INFO - 2024-02-05 00:18:09 --> Language Class Initialized
INFO - 2024-02-05 00:18:09 --> Loader Class Initialized
INFO - 2024-02-05 00:18:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:09 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:09 --> Controller Class Initialized
INFO - 2024-02-05 00:18:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:18:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:18:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:09 --> Total execution time: 0.0858
INFO - 2024-02-05 00:18:10 --> Config Class Initialized
INFO - 2024-02-05 00:18:10 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:10 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:10 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:10 --> URI Class Initialized
INFO - 2024-02-05 00:18:10 --> Router Class Initialized
INFO - 2024-02-05 00:18:10 --> Output Class Initialized
INFO - 2024-02-05 00:18:10 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:10 --> Input Class Initialized
INFO - 2024-02-05 00:18:10 --> Language Class Initialized
INFO - 2024-02-05 00:18:10 --> Loader Class Initialized
INFO - 2024-02-05 00:18:10 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:10 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:10 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:10 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:10 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:10 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:10 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:10 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:10 --> Controller Class Initialized
INFO - 2024-02-05 00:18:10 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:18:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:18:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:18:10 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:18:10 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:18:10 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:18:10 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:10 --> Total execution time: 0.1106
INFO - 2024-02-05 00:18:12 --> Config Class Initialized
INFO - 2024-02-05 00:18:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:12 --> Config Class Initialized
INFO - 2024-02-05 00:18:12 --> Hooks Class Initialized
INFO - 2024-02-05 00:18:12 --> URI Class Initialized
INFO - 2024-02-05 00:18:12 --> Router Class Initialized
DEBUG - 2024-02-05 00:18:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:12 --> Output Class Initialized
INFO - 2024-02-05 00:18:12 --> URI Class Initialized
INFO - 2024-02-05 00:18:12 --> Security Class Initialized
INFO - 2024-02-05 00:18:12 --> Router Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:12 --> Input Class Initialized
INFO - 2024-02-05 00:18:12 --> Output Class Initialized
INFO - 2024-02-05 00:18:12 --> Language Class Initialized
INFO - 2024-02-05 00:18:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:12 --> Input Class Initialized
INFO - 2024-02-05 00:18:12 --> Loader Class Initialized
INFO - 2024-02-05 00:18:12 --> Language Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:12 --> Config Class Initialized
INFO - 2024-02-05 00:18:12 --> Hooks Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:12 --> Loader Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:18:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:12 --> Email Class Initialized
INFO - 2024-02-05 00:18:12 --> Config Class Initialized
INFO - 2024-02-05 00:18:12 --> URI Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:12 --> Email Class Initialized
INFO - 2024-02-05 00:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:12 --> Config Class Initialized
INFO - 2024-02-05 00:18:12 --> Controller Class Initialized
INFO - 2024-02-05 00:18:12 --> Hooks Class Initialized
INFO - 2024-02-05 00:18:12 --> Router Class Initialized
DEBUG - 2024-02-05 00:18:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:12 --> Output Class Initialized
DEBUG - 2024-02-05 00:18:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:12 --> Security Class Initialized
INFO - 2024-02-05 00:18:12 --> URI Class Initialized
INFO - 2024-02-05 00:18:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:12 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:12 --> Input Class Initialized
INFO - 2024-02-05 00:18:12 --> Router Class Initialized
INFO - 2024-02-05 00:18:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:12 --> Language Class Initialized
INFO - 2024-02-05 00:18:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:12 --> Output Class Initialized
INFO - 2024-02-05 00:18:12 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:12 --> Total execution time: 0.0631
INFO - 2024-02-05 00:18:12 --> Security Class Initialized
INFO - 2024-02-05 00:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:12 --> Loader Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:12 --> Input Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:12 --> Controller Class Initialized
INFO - 2024-02-05 00:18:12 --> Language Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:12 --> Loader Class Initialized
INFO - 2024-02-05 00:18:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:12 --> URI Class Initialized
INFO - 2024-02-05 00:18:12 --> Final output sent to browser
INFO - 2024-02-05 00:18:12 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:18:12 --> Total execution time: 0.0743
INFO - 2024-02-05 00:18:12 --> Router Class Initialized
INFO - 2024-02-05 00:18:13 --> Email Class Initialized
INFO - 2024-02-05 00:18:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:13 --> Output Class Initialized
DEBUG - 2024-02-05 00:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:13 --> Config Class Initialized
INFO - 2024-02-05 00:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:13 --> Hooks Class Initialized
INFO - 2024-02-05 00:18:13 --> Security Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:13 --> Controller Class Initialized
INFO - 2024-02-05 00:18:13 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:13 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:13 --> Input Class Initialized
INFO - 2024-02-05 00:18:13 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:13 --> Language Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:13 --> URI Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Router Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:13 --> Loader Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Output Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:13 --> Final output sent to browser
INFO - 2024-02-05 00:18:13 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:13 --> Total execution time: 0.0852
INFO - 2024-02-05 00:18:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:13 --> Input Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:13 --> Language Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:13 --> Controller Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:13 --> Loader Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:13 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:13 --> Total execution time: 0.1089
INFO - 2024-02-05 00:18:13 --> Email Class Initialized
INFO - 2024-02-05 00:18:13 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:13 --> Email Class Initialized
INFO - 2024-02-05 00:18:13 --> Helper loaded: form_helper
DEBUG - 2024-02-05 00:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:13 --> Controller Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:13 --> Total execution time: 0.1217
INFO - 2024-02-05 00:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:13 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:13 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:13 --> Controller Class Initialized
INFO - 2024-02-05 00:18:13 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:13 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:13 --> Final output sent to browser
DEBUG - 2024-02-05 00:18:13 --> Total execution time: 0.0951
INFO - 2024-02-05 00:18:20 --> Config Class Initialized
INFO - 2024-02-05 00:18:20 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:18:20 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:18:20 --> Utf8 Class Initialized
INFO - 2024-02-05 00:18:20 --> URI Class Initialized
INFO - 2024-02-05 00:18:20 --> Router Class Initialized
INFO - 2024-02-05 00:18:20 --> Output Class Initialized
INFO - 2024-02-05 00:18:20 --> Security Class Initialized
DEBUG - 2024-02-05 00:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:18:20 --> Input Class Initialized
INFO - 2024-02-05 00:18:20 --> Language Class Initialized
INFO - 2024-02-05 00:18:20 --> Loader Class Initialized
INFO - 2024-02-05 00:18:20 --> Helper loaded: url_helper
INFO - 2024-02-05 00:18:20 --> Helper loaded: file_helper
INFO - 2024-02-05 00:18:20 --> Helper loaded: security_helper
INFO - 2024-02-05 00:18:20 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:18:20 --> Database Driver Class Initialized
INFO - 2024-02-05 00:18:20 --> Email Class Initialized
DEBUG - 2024-02-05 00:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:18:20 --> Helper loaded: form_helper
INFO - 2024-02-05 00:18:20 --> Form Validation Class Initialized
INFO - 2024-02-05 00:18:20 --> Controller Class Initialized
INFO - 2024-02-05 00:18:20 --> Model "User_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:18:20 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:18:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:18:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:18:20 --> 404 Page Not Found: 
INFO - 2024-02-05 00:29:36 --> Config Class Initialized
INFO - 2024-02-05 00:29:36 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:29:36 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:29:36 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:36 --> URI Class Initialized
INFO - 2024-02-05 00:29:36 --> Router Class Initialized
INFO - 2024-02-05 00:29:36 --> Output Class Initialized
INFO - 2024-02-05 00:29:36 --> Security Class Initialized
DEBUG - 2024-02-05 00:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:36 --> Input Class Initialized
INFO - 2024-02-05 00:29:36 --> Language Class Initialized
INFO - 2024-02-05 00:29:36 --> Loader Class Initialized
INFO - 2024-02-05 00:29:36 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:36 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:36 --> Helper loaded: security_helper
INFO - 2024-02-05 00:29:36 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:36 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:36 --> Email Class Initialized
DEBUG - 2024-02-05 00:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:36 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:36 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:36 --> Controller Class Initialized
INFO - 2024-02-05 00:29:36 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:29:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:29:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:29:36 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:29:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:29:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:29:36 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:36 --> Total execution time: 0.0648
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> Config Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
INFO - 2024-02-05 00:29:39 --> Hooks Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:29:39 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Utf8 Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
INFO - 2024-02-05 00:29:39 --> URI Class Initialized
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
INFO - 2024-02-05 00:29:39 --> Router Class Initialized
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
INFO - 2024-02-05 00:29:39 --> Output Class Initialized
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> Security Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Input Class Initialized
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Language Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Loader Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:39 --> Helper loaded: url_helper
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:39 --> Helper loaded: file_helper
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: security_helper
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.0656
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Database Driver Class Initialized
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:39 --> Email Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.0803
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.0935
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.1016
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.1235
INFO - 2024-02-05 00:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:29:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:29:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:29:39 --> Controller Class Initialized
INFO - 2024-02-05 00:29:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:29:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:29:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:29:39 --> Final output sent to browser
DEBUG - 2024-02-05 00:29:39 --> Total execution time: 0.1310
INFO - 2024-02-05 00:30:02 --> Config Class Initialized
INFO - 2024-02-05 00:30:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:02 --> URI Class Initialized
INFO - 2024-02-05 00:30:02 --> Router Class Initialized
INFO - 2024-02-05 00:30:02 --> Output Class Initialized
INFO - 2024-02-05 00:30:02 --> Security Class Initialized
DEBUG - 2024-02-05 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:02 --> Input Class Initialized
INFO - 2024-02-05 00:30:02 --> Language Class Initialized
INFO - 2024-02-05 00:30:02 --> Loader Class Initialized
INFO - 2024-02-05 00:30:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:02 --> Email Class Initialized
DEBUG - 2024-02-05 00:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:02 --> Controller Class Initialized
INFO - 2024-02-05 00:30:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:02 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:30:02 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:30:02 --> Upload Class Initialized
INFO - 2024-02-05 00:30:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:30:02 --> 404 Page Not Found: 
INFO - 2024-02-05 00:30:53 --> Config Class Initialized
INFO - 2024-02-05 00:30:53 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:53 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:53 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:53 --> URI Class Initialized
INFO - 2024-02-05 00:30:53 --> Router Class Initialized
INFO - 2024-02-05 00:30:53 --> Output Class Initialized
INFO - 2024-02-05 00:30:53 --> Security Class Initialized
DEBUG - 2024-02-05 00:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:53 --> Input Class Initialized
INFO - 2024-02-05 00:30:53 --> Language Class Initialized
INFO - 2024-02-05 00:30:53 --> Loader Class Initialized
INFO - 2024-02-05 00:30:53 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:53 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:53 --> Email Class Initialized
DEBUG - 2024-02-05 00:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:53 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:53 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:53 --> Controller Class Initialized
INFO - 2024-02-05 00:30:53 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:30:53 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:30:53 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:53 --> Total execution time: 0.0709
INFO - 2024-02-05 00:30:53 --> Config Class Initialized
INFO - 2024-02-05 00:30:53 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:53 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:53 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:53 --> URI Class Initialized
INFO - 2024-02-05 00:30:53 --> Router Class Initialized
INFO - 2024-02-05 00:30:53 --> Output Class Initialized
INFO - 2024-02-05 00:30:53 --> Security Class Initialized
DEBUG - 2024-02-05 00:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:53 --> Input Class Initialized
INFO - 2024-02-05 00:30:53 --> Language Class Initialized
INFO - 2024-02-05 00:30:53 --> Loader Class Initialized
INFO - 2024-02-05 00:30:53 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:53 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:53 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:53 --> Email Class Initialized
DEBUG - 2024-02-05 00:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:53 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:53 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:53 --> Controller Class Initialized
INFO - 2024-02-05 00:30:53 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:53 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:30:53 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:30:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:30:53 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:53 --> Total execution time: 0.1297
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> Config Class Initialized
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:55 --> Hooks Class Initialized
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
DEBUG - 2024-02-05 00:30:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:30:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> URI Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:55 --> Router Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Output Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Security Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.0926
DEBUG - 2024-02-05 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:55 --> Input Class Initialized
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Language Class Initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:55 --> Loader Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:30:55 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.1068
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Email Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.0991
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.1139
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.1415
INFO - 2024-02-05 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:30:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:30:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:30:55 --> Controller Class Initialized
INFO - 2024-02-05 00:30:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:30:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:30:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:30:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:30:55 --> Total execution time: 0.1333
INFO - 2024-02-05 00:31:07 --> Config Class Initialized
INFO - 2024-02-05 00:31:07 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:07 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:07 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:07 --> URI Class Initialized
INFO - 2024-02-05 00:31:07 --> Router Class Initialized
INFO - 2024-02-05 00:31:07 --> Output Class Initialized
INFO - 2024-02-05 00:31:07 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:07 --> Input Class Initialized
INFO - 2024-02-05 00:31:07 --> Language Class Initialized
INFO - 2024-02-05 00:31:07 --> Loader Class Initialized
INFO - 2024-02-05 00:31:07 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:07 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:07 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:07 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:07 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:07 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:07 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:07 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:07 --> Controller Class Initialized
INFO - 2024-02-05 00:31:07 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:07 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:31:07 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:31:07 --> Upload Class Initialized
INFO - 2024-02-05 00:31:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:31:07 --> 404 Page Not Found: 
INFO - 2024-02-05 00:31:38 --> Config Class Initialized
INFO - 2024-02-05 00:31:38 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:38 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:38 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:38 --> URI Class Initialized
INFO - 2024-02-05 00:31:38 --> Router Class Initialized
INFO - 2024-02-05 00:31:38 --> Output Class Initialized
INFO - 2024-02-05 00:31:38 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:38 --> Input Class Initialized
INFO - 2024-02-05 00:31:38 --> Language Class Initialized
INFO - 2024-02-05 00:31:38 --> Loader Class Initialized
INFO - 2024-02-05 00:31:38 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:38 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:38 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:38 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:38 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:39 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:39 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:39 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:39 --> Controller Class Initialized
INFO - 2024-02-05 00:31:39 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:39 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:39 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:31:39 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:31:39 --> Upload Class Initialized
INFO - 2024-02-05 00:31:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:31:39 --> 404 Page Not Found: 
INFO - 2024-02-05 00:31:40 --> Config Class Initialized
INFO - 2024-02-05 00:31:40 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:40 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:40 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:40 --> URI Class Initialized
INFO - 2024-02-05 00:31:40 --> Router Class Initialized
INFO - 2024-02-05 00:31:40 --> Output Class Initialized
INFO - 2024-02-05 00:31:40 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:40 --> Input Class Initialized
INFO - 2024-02-05 00:31:40 --> Language Class Initialized
INFO - 2024-02-05 00:31:40 --> Loader Class Initialized
INFO - 2024-02-05 00:31:40 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:40 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:40 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:40 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:40 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:40 --> Controller Class Initialized
INFO - 2024-02-05 00:31:40 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:31:40 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:31:40 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:40 --> Total execution time: 0.0704
INFO - 2024-02-05 00:31:40 --> Config Class Initialized
INFO - 2024-02-05 00:31:40 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:40 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:40 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:40 --> URI Class Initialized
INFO - 2024-02-05 00:31:40 --> Router Class Initialized
INFO - 2024-02-05 00:31:40 --> Output Class Initialized
INFO - 2024-02-05 00:31:40 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:40 --> Input Class Initialized
INFO - 2024-02-05 00:31:40 --> Language Class Initialized
INFO - 2024-02-05 00:31:40 --> Loader Class Initialized
INFO - 2024-02-05 00:31:40 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:40 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:40 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:40 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:40 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:40 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:40 --> Controller Class Initialized
INFO - 2024-02-05 00:31:40 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:40 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:31:40 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:31:40 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:31:40 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:40 --> Total execution time: 0.0783
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Config Class Initialized
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
INFO - 2024-02-05 00:31:44 --> Hooks Class Initialized
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
DEBUG - 2024-02-05 00:31:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> URI Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Router Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Output Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.0652
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
INFO - 2024-02-05 00:31:44 --> Input Class Initialized
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Language Class Initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
INFO - 2024-02-05 00:31:44 --> Loader Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:31:44 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.0848
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Email Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.0777
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.0929
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.1134
INFO - 2024-02-05 00:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:44 --> Controller Class Initialized
INFO - 2024-02-05 00:31:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:31:44 --> Total execution time: 0.1172
INFO - 2024-02-05 00:31:56 --> Config Class Initialized
INFO - 2024-02-05 00:31:56 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:31:56 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:31:56 --> Utf8 Class Initialized
INFO - 2024-02-05 00:31:56 --> URI Class Initialized
INFO - 2024-02-05 00:31:56 --> Router Class Initialized
INFO - 2024-02-05 00:31:56 --> Output Class Initialized
INFO - 2024-02-05 00:31:56 --> Security Class Initialized
DEBUG - 2024-02-05 00:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:31:56 --> Input Class Initialized
INFO - 2024-02-05 00:31:56 --> Language Class Initialized
INFO - 2024-02-05 00:31:56 --> Loader Class Initialized
INFO - 2024-02-05 00:31:56 --> Helper loaded: url_helper
INFO - 2024-02-05 00:31:56 --> Helper loaded: file_helper
INFO - 2024-02-05 00:31:56 --> Helper loaded: security_helper
INFO - 2024-02-05 00:31:56 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:31:56 --> Database Driver Class Initialized
INFO - 2024-02-05 00:31:56 --> Email Class Initialized
DEBUG - 2024-02-05 00:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:31:56 --> Helper loaded: form_helper
INFO - 2024-02-05 00:31:56 --> Form Validation Class Initialized
INFO - 2024-02-05 00:31:56 --> Controller Class Initialized
INFO - 2024-02-05 00:31:56 --> Model "User_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:31:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:31:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:31:56 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:31:56 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:31:56 --> Upload Class Initialized
INFO - 2024-02-05 00:31:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:31:56 --> 404 Page Not Found: 
INFO - 2024-02-05 00:32:05 --> Config Class Initialized
INFO - 2024-02-05 00:32:05 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:32:05 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:32:05 --> Utf8 Class Initialized
INFO - 2024-02-05 00:32:05 --> URI Class Initialized
INFO - 2024-02-05 00:32:05 --> Router Class Initialized
INFO - 2024-02-05 00:32:05 --> Output Class Initialized
INFO - 2024-02-05 00:32:05 --> Security Class Initialized
DEBUG - 2024-02-05 00:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:32:05 --> Input Class Initialized
INFO - 2024-02-05 00:32:05 --> Language Class Initialized
INFO - 2024-02-05 00:32:05 --> Loader Class Initialized
INFO - 2024-02-05 00:32:05 --> Helper loaded: url_helper
INFO - 2024-02-05 00:32:05 --> Helper loaded: file_helper
INFO - 2024-02-05 00:32:05 --> Helper loaded: security_helper
INFO - 2024-02-05 00:32:05 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:32:05 --> Database Driver Class Initialized
INFO - 2024-02-05 00:32:05 --> Email Class Initialized
DEBUG - 2024-02-05 00:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:32:05 --> Helper loaded: form_helper
INFO - 2024-02-05 00:32:05 --> Form Validation Class Initialized
INFO - 2024-02-05 00:32:05 --> Controller Class Initialized
INFO - 2024-02-05 00:32:05 --> Model "User_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:32:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:32:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:32:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:32:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:32:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:32:05 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:32:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:32:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:32:05 --> Final output sent to browser
DEBUG - 2024-02-05 00:32:05 --> Total execution time: 0.0677
INFO - 2024-02-05 00:32:07 --> Config Class Initialized
INFO - 2024-02-05 00:32:07 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:32:07 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:32:07 --> Utf8 Class Initialized
INFO - 2024-02-05 00:32:07 --> URI Class Initialized
INFO - 2024-02-05 00:32:07 --> Router Class Initialized
INFO - 2024-02-05 00:32:07 --> Output Class Initialized
INFO - 2024-02-05 00:32:07 --> Security Class Initialized
DEBUG - 2024-02-05 00:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:32:07 --> Input Class Initialized
INFO - 2024-02-05 00:32:07 --> Language Class Initialized
INFO - 2024-02-05 00:32:07 --> Loader Class Initialized
INFO - 2024-02-05 00:32:07 --> Helper loaded: url_helper
INFO - 2024-02-05 00:32:07 --> Helper loaded: file_helper
INFO - 2024-02-05 00:32:07 --> Helper loaded: security_helper
INFO - 2024-02-05 00:32:07 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:32:07 --> Database Driver Class Initialized
INFO - 2024-02-05 00:32:07 --> Email Class Initialized
DEBUG - 2024-02-05 00:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:32:07 --> Helper loaded: form_helper
INFO - 2024-02-05 00:32:07 --> Form Validation Class Initialized
INFO - 2024-02-05 00:32:07 --> Controller Class Initialized
INFO - 2024-02-05 00:32:07 --> Model "User_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:32:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:32:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:32:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:32:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:32:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:32:07 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:32:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:32:07 --> Final output sent to browser
DEBUG - 2024-02-05 00:32:07 --> Total execution time: 0.0681
INFO - 2024-02-05 00:32:08 --> Config Class Initialized
INFO - 2024-02-05 00:32:08 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:32:08 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:32:08 --> Utf8 Class Initialized
INFO - 2024-02-05 00:32:08 --> URI Class Initialized
INFO - 2024-02-05 00:32:08 --> Router Class Initialized
INFO - 2024-02-05 00:32:08 --> Output Class Initialized
INFO - 2024-02-05 00:32:08 --> Security Class Initialized
DEBUG - 2024-02-05 00:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:32:08 --> Input Class Initialized
INFO - 2024-02-05 00:32:08 --> Language Class Initialized
INFO - 2024-02-05 00:32:08 --> Loader Class Initialized
INFO - 2024-02-05 00:32:08 --> Helper loaded: url_helper
INFO - 2024-02-05 00:32:08 --> Helper loaded: file_helper
INFO - 2024-02-05 00:32:08 --> Helper loaded: security_helper
INFO - 2024-02-05 00:32:08 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:32:08 --> Database Driver Class Initialized
INFO - 2024-02-05 00:32:08 --> Email Class Initialized
DEBUG - 2024-02-05 00:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:32:08 --> Helper loaded: form_helper
INFO - 2024-02-05 00:32:08 --> Form Validation Class Initialized
INFO - 2024-02-05 00:32:08 --> Controller Class Initialized
INFO - 2024-02-05 00:32:08 --> Model "User_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:32:08 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:32:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:32:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:32:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:32:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:32:08 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:32:08 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:32:08 --> Final output sent to browser
DEBUG - 2024-02-05 00:32:08 --> Total execution time: 0.0902
INFO - 2024-02-05 00:32:09 --> Config Class Initialized
INFO - 2024-02-05 00:32:09 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:32:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:32:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:32:09 --> URI Class Initialized
INFO - 2024-02-05 00:32:09 --> Router Class Initialized
INFO - 2024-02-05 00:32:09 --> Output Class Initialized
INFO - 2024-02-05 00:32:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:32:09 --> Input Class Initialized
INFO - 2024-02-05 00:32:09 --> Language Class Initialized
INFO - 2024-02-05 00:32:09 --> Loader Class Initialized
INFO - 2024-02-05 00:32:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:32:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:32:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:32:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:32:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:32:09 --> Email Class Initialized
DEBUG - 2024-02-05 00:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:32:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:32:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:32:09 --> Controller Class Initialized
INFO - 2024-02-05 00:32:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:32:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:32:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:32:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:32:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:32:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:32:09 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:32:09 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:32:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:32:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:32:09 --> Total execution time: 0.0729
INFO - 2024-02-05 00:32:15 --> Config Class Initialized
INFO - 2024-02-05 00:32:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:32:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:32:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:32:15 --> URI Class Initialized
INFO - 2024-02-05 00:32:15 --> Router Class Initialized
INFO - 2024-02-05 00:32:15 --> Output Class Initialized
INFO - 2024-02-05 00:32:15 --> Security Class Initialized
DEBUG - 2024-02-05 00:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:32:15 --> Input Class Initialized
INFO - 2024-02-05 00:32:15 --> Language Class Initialized
INFO - 2024-02-05 00:32:15 --> Loader Class Initialized
INFO - 2024-02-05 00:32:15 --> Helper loaded: url_helper
INFO - 2024-02-05 00:32:15 --> Helper loaded: file_helper
INFO - 2024-02-05 00:32:15 --> Helper loaded: security_helper
INFO - 2024-02-05 00:32:15 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:32:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:32:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:32:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:32:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:32:15 --> Controller Class Initialized
INFO - 2024-02-05 00:32:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:32:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:32:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:32:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:32:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:32:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:32:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:32:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:32:15 --> Final output sent to browser
DEBUG - 2024-02-05 00:32:15 --> Total execution time: 0.0578
INFO - 2024-02-05 00:33:34 --> Config Class Initialized
INFO - 2024-02-05 00:33:34 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:34 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:34 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:34 --> URI Class Initialized
INFO - 2024-02-05 00:33:34 --> Router Class Initialized
INFO - 2024-02-05 00:33:34 --> Output Class Initialized
INFO - 2024-02-05 00:33:34 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:34 --> Input Class Initialized
INFO - 2024-02-05 00:33:34 --> Language Class Initialized
INFO - 2024-02-05 00:33:34 --> Loader Class Initialized
INFO - 2024-02-05 00:33:34 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:34 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:34 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:34 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:34 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:34 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:34 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:34 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:34 --> Controller Class Initialized
INFO - 2024-02-05 00:33:34 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:33:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:33:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:33:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:33:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:33:34 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:34 --> Total execution time: 0.0827
INFO - 2024-02-05 00:33:36 --> Config Class Initialized
INFO - 2024-02-05 00:33:36 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:36 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:36 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:36 --> URI Class Initialized
INFO - 2024-02-05 00:33:36 --> Router Class Initialized
INFO - 2024-02-05 00:33:36 --> Output Class Initialized
INFO - 2024-02-05 00:33:36 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:36 --> Input Class Initialized
INFO - 2024-02-05 00:33:36 --> Language Class Initialized
INFO - 2024-02-05 00:33:36 --> Loader Class Initialized
INFO - 2024-02-05 00:33:36 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:36 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:36 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:36 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:36 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:36 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:36 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:36 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:36 --> Controller Class Initialized
INFO - 2024-02-05 00:33:36 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:36 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:33:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:33:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:33:36 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:33:36 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:33:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:33:36 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:36 --> Total execution time: 0.0688
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
INFO - 2024-02-05 00:33:41 --> Config Class Initialized
INFO - 2024-02-05 00:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:41 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> URI Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
INFO - 2024-02-05 00:33:41 --> Router Class Initialized
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
INFO - 2024-02-05 00:33:41 --> Output Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Security Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
INFO - 2024-02-05 00:33:41 --> Input Class Initialized
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:41 --> Language Class Initialized
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Loader Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
INFO - 2024-02-05 00:33:41 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:41 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.0669
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
DEBUG - 2024-02-05 00:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.0787
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.0871
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.0999
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.1126
INFO - 2024-02-05 00:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:41 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:41 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:41 --> Controller Class Initialized
INFO - 2024-02-05 00:33:41 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:41 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:41 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:41 --> Total execution time: 0.1313
INFO - 2024-02-05 00:33:46 --> Config Class Initialized
INFO - 2024-02-05 00:33:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:46 --> URI Class Initialized
INFO - 2024-02-05 00:33:46 --> Router Class Initialized
INFO - 2024-02-05 00:33:46 --> Output Class Initialized
INFO - 2024-02-05 00:33:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:46 --> Input Class Initialized
INFO - 2024-02-05 00:33:46 --> Language Class Initialized
INFO - 2024-02-05 00:33:46 --> Loader Class Initialized
INFO - 2024-02-05 00:33:46 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:46 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:46 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:46 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:46 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:46 --> Controller Class Initialized
INFO - 2024-02-05 00:33:46 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:33:46 --> Config Class Initialized
INFO - 2024-02-05 00:33:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:46 --> URI Class Initialized
INFO - 2024-02-05 00:33:46 --> Router Class Initialized
INFO - 2024-02-05 00:33:46 --> Output Class Initialized
INFO - 2024-02-05 00:33:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:46 --> Input Class Initialized
INFO - 2024-02-05 00:33:46 --> Language Class Initialized
INFO - 2024-02-05 00:33:46 --> Loader Class Initialized
INFO - 2024-02-05 00:33:46 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:46 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:46 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:46 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:46 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:46 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:46 --> Controller Class Initialized
INFO - 2024-02-05 00:33:46 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:33:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:33:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:33:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:33:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:33:46 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:46 --> Total execution time: 0.1068
INFO - 2024-02-05 00:33:58 --> Config Class Initialized
INFO - 2024-02-05 00:33:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:58 --> URI Class Initialized
INFO - 2024-02-05 00:33:58 --> Router Class Initialized
INFO - 2024-02-05 00:33:58 --> Output Class Initialized
INFO - 2024-02-05 00:33:58 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:58 --> Input Class Initialized
INFO - 2024-02-05 00:33:58 --> Language Class Initialized
INFO - 2024-02-05 00:33:58 --> Loader Class Initialized
INFO - 2024-02-05 00:33:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:58 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:58 --> Controller Class Initialized
INFO - 2024-02-05 00:33:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:33:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:33:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:33:58 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:33:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:33:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:58 --> Total execution time: 0.0730
INFO - 2024-02-05 00:33:59 --> Config Class Initialized
INFO - 2024-02-05 00:33:59 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:33:59 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:33:59 --> Utf8 Class Initialized
INFO - 2024-02-05 00:33:59 --> URI Class Initialized
INFO - 2024-02-05 00:33:59 --> Router Class Initialized
INFO - 2024-02-05 00:33:59 --> Output Class Initialized
INFO - 2024-02-05 00:33:59 --> Security Class Initialized
DEBUG - 2024-02-05 00:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:33:59 --> Input Class Initialized
INFO - 2024-02-05 00:33:59 --> Language Class Initialized
INFO - 2024-02-05 00:33:59 --> Loader Class Initialized
INFO - 2024-02-05 00:33:59 --> Helper loaded: url_helper
INFO - 2024-02-05 00:33:59 --> Helper loaded: file_helper
INFO - 2024-02-05 00:33:59 --> Helper loaded: security_helper
INFO - 2024-02-05 00:33:59 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:33:59 --> Database Driver Class Initialized
INFO - 2024-02-05 00:33:59 --> Email Class Initialized
DEBUG - 2024-02-05 00:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:33:59 --> Helper loaded: form_helper
INFO - 2024-02-05 00:33:59 --> Form Validation Class Initialized
INFO - 2024-02-05 00:33:59 --> Controller Class Initialized
INFO - 2024-02-05 00:33:59 --> Model "User_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:33:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:33:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:33:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:33:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:33:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:33:59 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:33:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:33:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:33:59 --> Final output sent to browser
DEBUG - 2024-02-05 00:33:59 --> Total execution time: 0.0710
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
INFO - 2024-02-05 00:34:02 --> Config Class Initialized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:34:02 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:02 --> URI Class Initialized
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
INFO - 2024-02-05 00:34:02 --> Router Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
INFO - 2024-02-05 00:34:02 --> Output Class Initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:02 --> Security Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:02 --> Input Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:02 --> Language Class Initialized
INFO - 2024-02-05 00:34:02 --> Controller Class Initialized
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:02 --> Loader Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:02 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:34:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:02 --> Total execution time: 0.0612
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:02 --> Controller Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:02 --> Email Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:02 --> Total execution time: 0.0805
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:02 --> Controller Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:02 --> Total execution time: 0.0900
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:02 --> Controller Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:02 --> Total execution time: 0.1101
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:02 --> Controller Class Initialized
INFO - 2024-02-05 00:34:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:02 --> Total execution time: 0.1265
INFO - 2024-02-05 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:03 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:03 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:03 --> Controller Class Initialized
INFO - 2024-02-05 00:34:03 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:03 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:03 --> Total execution time: 0.1318
INFO - 2024-02-05 00:34:12 --> Config Class Initialized
INFO - 2024-02-05 00:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:12 --> URI Class Initialized
INFO - 2024-02-05 00:34:12 --> Router Class Initialized
INFO - 2024-02-05 00:34:12 --> Output Class Initialized
INFO - 2024-02-05 00:34:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:12 --> Input Class Initialized
INFO - 2024-02-05 00:34:12 --> Language Class Initialized
INFO - 2024-02-05 00:34:12 --> Loader Class Initialized
INFO - 2024-02-05 00:34:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:12 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:12 --> Controller Class Initialized
INFO - 2024-02-05 00:34:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:12 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:34:12 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:34:12 --> Upload Class Initialized
INFO - 2024-02-05 00:34:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:34:12 --> Config Class Initialized
INFO - 2024-02-05 00:34:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:12 --> URI Class Initialized
INFO - 2024-02-05 00:34:12 --> Router Class Initialized
INFO - 2024-02-05 00:34:12 --> Output Class Initialized
INFO - 2024-02-05 00:34:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:12 --> Input Class Initialized
INFO - 2024-02-05 00:34:12 --> Language Class Initialized
INFO - 2024-02-05 00:34:12 --> Loader Class Initialized
INFO - 2024-02-05 00:34:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:12 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:12 --> Controller Class Initialized
INFO - 2024-02-05 00:34:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:34:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:34:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:34:12 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:34:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:34:12 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:12 --> Total execution time: 0.0610
INFO - 2024-02-05 00:34:21 --> Config Class Initialized
INFO - 2024-02-05 00:34:21 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:21 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:21 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:21 --> URI Class Initialized
INFO - 2024-02-05 00:34:21 --> Router Class Initialized
INFO - 2024-02-05 00:34:21 --> Output Class Initialized
INFO - 2024-02-05 00:34:21 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:21 --> Input Class Initialized
INFO - 2024-02-05 00:34:21 --> Language Class Initialized
INFO - 2024-02-05 00:34:21 --> Loader Class Initialized
INFO - 2024-02-05 00:34:21 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:21 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:21 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:21 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:21 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:21 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:21 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:21 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:21 --> Controller Class Initialized
INFO - 2024-02-05 00:34:21 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:21 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:34:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:34:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:34:21 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:34:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:34:21 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:21 --> Total execution time: 0.1485
INFO - 2024-02-05 00:34:22 --> Config Class Initialized
INFO - 2024-02-05 00:34:22 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:22 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:22 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:22 --> URI Class Initialized
INFO - 2024-02-05 00:34:22 --> Router Class Initialized
INFO - 2024-02-05 00:34:22 --> Output Class Initialized
INFO - 2024-02-05 00:34:22 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:22 --> Input Class Initialized
INFO - 2024-02-05 00:34:22 --> Language Class Initialized
INFO - 2024-02-05 00:34:22 --> Loader Class Initialized
INFO - 2024-02-05 00:34:22 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:22 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:22 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:22 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:22 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:22 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:22 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:22 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:22 --> Controller Class Initialized
INFO - 2024-02-05 00:34:22 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:34:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:34:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:34:22 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:34:22 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:34:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:34:22 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:22 --> Total execution time: 0.0796
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.0623
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.0706
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.1370
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.0658
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
INFO - 2024-02-05 00:34:24 --> Config Class Initialized
INFO - 2024-02-05 00:34:24 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
DEBUG - 2024-02-05 00:34:24 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:24 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:24 --> URI Class Initialized
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Router Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Output Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Security Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:24 --> Input Class Initialized
INFO - 2024-02-05 00:34:24 --> Language Class Initialized
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:24 --> Loader Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
INFO - 2024-02-05 00:34:24 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:24 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Email Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.1522
INFO - 2024-02-05 00:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:24 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:24 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:24 --> Controller Class Initialized
INFO - 2024-02-05 00:34:24 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:24 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:24 --> Final output sent to browser
DEBUG - 2024-02-05 00:34:24 --> Total execution time: 0.0648
INFO - 2024-02-05 00:34:26 --> Config Class Initialized
INFO - 2024-02-05 00:34:26 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:34:26 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:34:26 --> Utf8 Class Initialized
INFO - 2024-02-05 00:34:26 --> URI Class Initialized
INFO - 2024-02-05 00:34:26 --> Router Class Initialized
INFO - 2024-02-05 00:34:26 --> Output Class Initialized
INFO - 2024-02-05 00:34:26 --> Security Class Initialized
DEBUG - 2024-02-05 00:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:34:26 --> Input Class Initialized
INFO - 2024-02-05 00:34:26 --> Language Class Initialized
INFO - 2024-02-05 00:34:26 --> Loader Class Initialized
INFO - 2024-02-05 00:34:26 --> Helper loaded: url_helper
INFO - 2024-02-05 00:34:26 --> Helper loaded: file_helper
INFO - 2024-02-05 00:34:26 --> Helper loaded: security_helper
INFO - 2024-02-05 00:34:26 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:34:26 --> Database Driver Class Initialized
INFO - 2024-02-05 00:34:26 --> Email Class Initialized
DEBUG - 2024-02-05 00:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:34:26 --> Helper loaded: form_helper
INFO - 2024-02-05 00:34:26 --> Form Validation Class Initialized
INFO - 2024-02-05 00:34:26 --> Controller Class Initialized
INFO - 2024-02-05 00:34:26 --> Model "User_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:34:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:34:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:34:26 --> 404 Page Not Found: 
INFO - 2024-02-05 00:35:56 --> Config Class Initialized
INFO - 2024-02-05 00:35:56 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:35:56 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:35:56 --> Utf8 Class Initialized
INFO - 2024-02-05 00:35:56 --> URI Class Initialized
INFO - 2024-02-05 00:35:56 --> Router Class Initialized
INFO - 2024-02-05 00:35:56 --> Output Class Initialized
INFO - 2024-02-05 00:35:56 --> Security Class Initialized
DEBUG - 2024-02-05 00:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:35:56 --> Input Class Initialized
INFO - 2024-02-05 00:35:56 --> Language Class Initialized
INFO - 2024-02-05 00:35:56 --> Loader Class Initialized
INFO - 2024-02-05 00:35:56 --> Helper loaded: url_helper
INFO - 2024-02-05 00:35:56 --> Helper loaded: file_helper
INFO - 2024-02-05 00:35:56 --> Helper loaded: security_helper
INFO - 2024-02-05 00:35:56 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:35:56 --> Database Driver Class Initialized
INFO - 2024-02-05 00:35:56 --> Email Class Initialized
DEBUG - 2024-02-05 00:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:35:56 --> Helper loaded: form_helper
INFO - 2024-02-05 00:35:56 --> Form Validation Class Initialized
INFO - 2024-02-05 00:35:56 --> Controller Class Initialized
INFO - 2024-02-05 00:35:56 --> Model "User_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:35:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:35:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:35:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:35:56 --> 404 Page Not Found: 
INFO - 2024-02-05 00:35:57 --> Config Class Initialized
INFO - 2024-02-05 00:35:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:35:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:35:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:35:57 --> URI Class Initialized
INFO - 2024-02-05 00:35:57 --> Router Class Initialized
INFO - 2024-02-05 00:35:57 --> Output Class Initialized
INFO - 2024-02-05 00:35:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:35:57 --> Input Class Initialized
INFO - 2024-02-05 00:35:57 --> Language Class Initialized
INFO - 2024-02-05 00:35:57 --> Loader Class Initialized
INFO - 2024-02-05 00:35:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:35:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:35:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:35:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:35:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:35:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:35:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:35:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:35:57 --> Controller Class Initialized
INFO - 2024-02-05 00:35:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:35:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:35:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:35:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:35:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:35:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:35:57 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:35:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:35:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:35:57 --> Final output sent to browser
DEBUG - 2024-02-05 00:35:57 --> Total execution time: 0.0799
INFO - 2024-02-05 00:35:58 --> Config Class Initialized
INFO - 2024-02-05 00:35:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:35:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:35:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:35:58 --> URI Class Initialized
INFO - 2024-02-05 00:35:58 --> Router Class Initialized
INFO - 2024-02-05 00:35:58 --> Output Class Initialized
INFO - 2024-02-05 00:35:58 --> Security Class Initialized
DEBUG - 2024-02-05 00:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:35:58 --> Input Class Initialized
INFO - 2024-02-05 00:35:58 --> Language Class Initialized
INFO - 2024-02-05 00:35:58 --> Loader Class Initialized
INFO - 2024-02-05 00:35:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:35:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:35:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:35:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:35:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:35:58 --> Email Class Initialized
DEBUG - 2024-02-05 00:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:35:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:35:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:35:58 --> Controller Class Initialized
INFO - 2024-02-05 00:35:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:35:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:35:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:35:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:35:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:35:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:35:58 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 38
INFO - 2024-02-05 00:35:58 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:35:58 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:35:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:35:58 --> Total execution time: 0.0765
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
INFO - 2024-02-05 00:36:00 --> Config Class Initialized
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:36:00 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> URI Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Router Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Output Class Initialized
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
INFO - 2024-02-05 00:36:00 --> Security Class Initialized
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:00 --> Input Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> Language Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Loader Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:00 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:00 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.0709
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Email Class Initialized
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
DEBUG - 2024-02-05 00:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.0970
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.1069
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.1351
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.1408
INFO - 2024-02-05 00:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:00 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:00 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:00 --> Controller Class Initialized
INFO - 2024-02-05 00:36:00 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:00 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:00 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:00 --> Total execution time: 0.1573
INFO - 2024-02-05 00:36:02 --> Config Class Initialized
INFO - 2024-02-05 00:36:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:02 --> URI Class Initialized
INFO - 2024-02-05 00:36:02 --> Router Class Initialized
INFO - 2024-02-05 00:36:02 --> Output Class Initialized
INFO - 2024-02-05 00:36:02 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:02 --> Input Class Initialized
INFO - 2024-02-05 00:36:02 --> Language Class Initialized
INFO - 2024-02-05 00:36:02 --> Loader Class Initialized
INFO - 2024-02-05 00:36:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:02 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:02 --> Controller Class Initialized
INFO - 2024-02-05 00:36:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-02-05 00:36:02 --> 404 Page Not Found: 
INFO - 2024-02-05 00:36:25 --> Config Class Initialized
INFO - 2024-02-05 00:36:25 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:25 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:25 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:25 --> URI Class Initialized
INFO - 2024-02-05 00:36:25 --> Router Class Initialized
INFO - 2024-02-05 00:36:25 --> Output Class Initialized
INFO - 2024-02-05 00:36:25 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:25 --> Input Class Initialized
INFO - 2024-02-05 00:36:25 --> Language Class Initialized
INFO - 2024-02-05 00:36:25 --> Loader Class Initialized
INFO - 2024-02-05 00:36:25 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:25 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:25 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:25 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:25 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:25 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:25 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:25 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:25 --> Controller Class Initialized
INFO - 2024-02-05 00:36:25 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:36:25 --> 404 Page Not Found: 
INFO - 2024-02-05 00:36:28 --> Config Class Initialized
INFO - 2024-02-05 00:36:28 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:28 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:28 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:28 --> URI Class Initialized
INFO - 2024-02-05 00:36:28 --> Router Class Initialized
INFO - 2024-02-05 00:36:28 --> Output Class Initialized
INFO - 2024-02-05 00:36:28 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:28 --> Input Class Initialized
INFO - 2024-02-05 00:36:28 --> Language Class Initialized
INFO - 2024-02-05 00:36:28 --> Loader Class Initialized
INFO - 2024-02-05 00:36:28 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:28 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:28 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:28 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:28 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:28 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:28 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:28 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:28 --> Controller Class Initialized
INFO - 2024-02-05 00:36:28 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:36:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:36:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:28 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:28 --> Total execution time: 0.0763
INFO - 2024-02-05 00:36:29 --> Config Class Initialized
INFO - 2024-02-05 00:36:29 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:29 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:29 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:29 --> URI Class Initialized
INFO - 2024-02-05 00:36:29 --> Router Class Initialized
INFO - 2024-02-05 00:36:29 --> Output Class Initialized
INFO - 2024-02-05 00:36:29 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:29 --> Input Class Initialized
INFO - 2024-02-05 00:36:29 --> Language Class Initialized
INFO - 2024-02-05 00:36:29 --> Loader Class Initialized
INFO - 2024-02-05 00:36:29 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:29 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:29 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:29 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:29 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:29 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:29 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:29 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:29 --> Controller Class Initialized
INFO - 2024-02-05 00:36:29 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:29 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:36:29 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:36:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:29 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:29 --> Total execution time: 0.0685
INFO - 2024-02-05 00:36:30 --> Config Class Initialized
INFO - 2024-02-05 00:36:30 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:30 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:30 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:30 --> URI Class Initialized
INFO - 2024-02-05 00:36:30 --> Router Class Initialized
INFO - 2024-02-05 00:36:30 --> Output Class Initialized
INFO - 2024-02-05 00:36:30 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:30 --> Input Class Initialized
INFO - 2024-02-05 00:36:30 --> Language Class Initialized
INFO - 2024-02-05 00:36:30 --> Loader Class Initialized
INFO - 2024-02-05 00:36:30 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:30 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:30 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:30 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:30 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:30 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:30 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:30 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:30 --> Controller Class Initialized
INFO - 2024-02-05 00:36:30 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:30 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:36:30 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
INFO - 2024-02-05 00:36:30 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:36:30 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:30 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:30 --> Total execution time: 0.0753
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
INFO - 2024-02-05 00:36:32 --> Config Class Initialized
INFO - 2024-02-05 00:36:32 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
DEBUG - 2024-02-05 00:36:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
INFO - 2024-02-05 00:36:32 --> URI Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
INFO - 2024-02-05 00:36:32 --> Router Class Initialized
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Output Class Initialized
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
INFO - 2024-02-05 00:36:32 --> Security Class Initialized
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:32 --> Input Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:32 --> Language Class Initialized
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Loader Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.0721
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:32 --> Email Class Initialized
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
DEBUG - 2024-02-05 00:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.0878
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.1135
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.1296
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.1418
INFO - 2024-02-05 00:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:32 --> Controller Class Initialized
INFO - 2024-02-05 00:36:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:32 --> Total execution time: 0.1537
INFO - 2024-02-05 00:36:34 --> Config Class Initialized
INFO - 2024-02-05 00:36:34 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:34 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:34 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:34 --> URI Class Initialized
INFO - 2024-02-05 00:36:34 --> Router Class Initialized
INFO - 2024-02-05 00:36:34 --> Output Class Initialized
INFO - 2024-02-05 00:36:34 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:34 --> Input Class Initialized
INFO - 2024-02-05 00:36:34 --> Language Class Initialized
INFO - 2024-02-05 00:36:34 --> Loader Class Initialized
INFO - 2024-02-05 00:36:34 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:34 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:34 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:34 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:34 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:34 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:34 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:34 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:34 --> Controller Class Initialized
INFO - 2024-02-05 00:36:34 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:34 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:36:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:36:34 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:36:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:36:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:34 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:34 --> Total execution time: 0.0940
INFO - 2024-02-05 00:36:46 --> Config Class Initialized
INFO - 2024-02-05 00:36:46 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:46 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:46 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:46 --> URI Class Initialized
INFO - 2024-02-05 00:36:46 --> Router Class Initialized
INFO - 2024-02-05 00:36:46 --> Output Class Initialized
INFO - 2024-02-05 00:36:46 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:46 --> Input Class Initialized
INFO - 2024-02-05 00:36:46 --> Language Class Initialized
INFO - 2024-02-05 00:36:46 --> Loader Class Initialized
INFO - 2024-02-05 00:36:46 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:46 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:46 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:46 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:46 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:46 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:46 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:46 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:46 --> Controller Class Initialized
INFO - 2024-02-05 00:36:46 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:46 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:36:46 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
INFO - 2024-02-05 00:36:46 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:36:46 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:46 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:46 --> Total execution time: 0.0724
INFO - 2024-02-05 00:36:47 --> Config Class Initialized
INFO - 2024-02-05 00:36:47 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:47 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:47 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:47 --> URI Class Initialized
INFO - 2024-02-05 00:36:47 --> Router Class Initialized
INFO - 2024-02-05 00:36:47 --> Output Class Initialized
INFO - 2024-02-05 00:36:47 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:47 --> Input Class Initialized
INFO - 2024-02-05 00:36:47 --> Language Class Initialized
INFO - 2024-02-05 00:36:47 --> Loader Class Initialized
INFO - 2024-02-05 00:36:47 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:47 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:47 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:47 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:47 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:47 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:47 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:47 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:47 --> Controller Class Initialized
INFO - 2024-02-05 00:36:47 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:47 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:36:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:36:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:36:47 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
INFO - 2024-02-05 00:36:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:36:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:36:47 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:47 --> Total execution time: 0.0785
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:48 --> Config Class Initialized
INFO - 2024-02-05 00:36:48 --> Hooks Class Initialized
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:48 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> Controller Class Initialized
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:36:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:36:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> URI Class Initialized
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Router Class Initialized
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:48 --> Output Class Initialized
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
INFO - 2024-02-05 00:36:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:48 --> Model "Supplier_model" initialized
DEBUG - 2024-02-05 00:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:36:48 --> Input Class Initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:48 --> Language Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:48 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:48 --> Total execution time: 0.0684
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Loader Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:48 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Controller Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:36:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:36:48 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:48 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:48 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:48 --> Total execution time: 0.0762
INFO - 2024-02-05 00:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:36:48 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
INFO - 2024-02-05 00:36:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:48 --> Form Validation Class Initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:48 --> Controller Class Initialized
INFO - 2024-02-05 00:36:48 --> Email Class Initialized
INFO - 2024-02-05 00:36:48 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:36:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:49 --> Total execution time: 0.1130
INFO - 2024-02-05 00:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:49 --> Controller Class Initialized
INFO - 2024-02-05 00:36:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:49 --> Total execution time: 0.0917
INFO - 2024-02-05 00:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:49 --> Controller Class Initialized
INFO - 2024-02-05 00:36:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:49 --> Total execution time: 0.1135
INFO - 2024-02-05 00:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:36:49 --> Helper loaded: form_helper
INFO - 2024-02-05 00:36:49 --> Form Validation Class Initialized
INFO - 2024-02-05 00:36:49 --> Controller Class Initialized
INFO - 2024-02-05 00:36:49 --> Model "User_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:36:49 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:36:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:36:49 --> Final output sent to browser
DEBUG - 2024-02-05 00:36:49 --> Total execution time: 0.1469
INFO - 2024-02-05 00:37:03 --> Config Class Initialized
INFO - 2024-02-05 00:37:03 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:37:03 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:37:03 --> Utf8 Class Initialized
INFO - 2024-02-05 00:37:03 --> URI Class Initialized
INFO - 2024-02-05 00:37:03 --> Router Class Initialized
INFO - 2024-02-05 00:37:03 --> Output Class Initialized
INFO - 2024-02-05 00:37:03 --> Security Class Initialized
DEBUG - 2024-02-05 00:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:37:03 --> Input Class Initialized
INFO - 2024-02-05 00:37:03 --> Language Class Initialized
INFO - 2024-02-05 00:37:03 --> Loader Class Initialized
INFO - 2024-02-05 00:37:03 --> Helper loaded: url_helper
INFO - 2024-02-05 00:37:03 --> Helper loaded: file_helper
INFO - 2024-02-05 00:37:03 --> Helper loaded: security_helper
INFO - 2024-02-05 00:37:03 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:37:03 --> Database Driver Class Initialized
INFO - 2024-02-05 00:37:03 --> Email Class Initialized
DEBUG - 2024-02-05 00:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:37:03 --> Helper loaded: form_helper
INFO - 2024-02-05 00:37:03 --> Form Validation Class Initialized
INFO - 2024-02-05 00:37:03 --> Controller Class Initialized
INFO - 2024-02-05 00:37:03 --> Model "User_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:37:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:37:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:37:03 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 190
INFO - 2024-02-05 00:37:03 --> Upload Class Initialized
INFO - 2024-02-05 00:37:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 00:37:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:37:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:37:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:37:03 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:37:03 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:37:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:37:03 --> Final output sent to browser
DEBUG - 2024-02-05 00:37:03 --> Total execution time: 0.0855
INFO - 2024-02-05 00:38:03 --> Config Class Initialized
INFO - 2024-02-05 00:38:03 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:03 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:03 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:03 --> URI Class Initialized
INFO - 2024-02-05 00:38:03 --> Router Class Initialized
INFO - 2024-02-05 00:38:03 --> Output Class Initialized
INFO - 2024-02-05 00:38:03 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:03 --> Input Class Initialized
INFO - 2024-02-05 00:38:03 --> Language Class Initialized
INFO - 2024-02-05 00:38:03 --> Loader Class Initialized
INFO - 2024-02-05 00:38:03 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:03 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:03 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:03 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:03 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:03 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:03 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:03 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:03 --> Controller Class Initialized
INFO - 2024-02-05 00:38:03 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:03 --> Helper loaded: inflector_helper
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Undefined index: file_var_name C:\xampp\htdocs\simba\application\models\Pesanan_model.php 186
INFO - 2024-02-05 00:38:03 --> Upload Class Initialized
INFO - 2024-02-05 00:38:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:38:03 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:38:03 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:38:03 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:03 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:03 --> Total execution time: 0.0914
INFO - 2024-02-05 00:38:05 --> Config Class Initialized
INFO - 2024-02-05 00:38:05 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:05 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:05 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:05 --> URI Class Initialized
INFO - 2024-02-05 00:38:05 --> Router Class Initialized
INFO - 2024-02-05 00:38:05 --> Output Class Initialized
INFO - 2024-02-05 00:38:05 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:05 --> Input Class Initialized
INFO - 2024-02-05 00:38:05 --> Language Class Initialized
INFO - 2024-02-05 00:38:05 --> Loader Class Initialized
INFO - 2024-02-05 00:38:05 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:05 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:05 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:05 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:05 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:05 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:05 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:05 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:05 --> Controller Class Initialized
INFO - 2024-02-05 00:38:05 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:05 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:05 --> Total execution time: 0.0685
INFO - 2024-02-05 00:38:06 --> Config Class Initialized
INFO - 2024-02-05 00:38:06 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:06 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:06 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:06 --> URI Class Initialized
INFO - 2024-02-05 00:38:06 --> Router Class Initialized
INFO - 2024-02-05 00:38:06 --> Output Class Initialized
INFO - 2024-02-05 00:38:06 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:06 --> Input Class Initialized
INFO - 2024-02-05 00:38:06 --> Language Class Initialized
INFO - 2024-02-05 00:38:06 --> Loader Class Initialized
INFO - 2024-02-05 00:38:06 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:06 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:06 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:06 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:06 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:06 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:06 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:06 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:06 --> Controller Class Initialized
INFO - 2024-02-05 00:38:06 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:06 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:06 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:06 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:06 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:06 --> Total execution time: 0.0684
INFO - 2024-02-05 00:38:07 --> Config Class Initialized
INFO - 2024-02-05 00:38:07 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:07 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:07 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:07 --> URI Class Initialized
INFO - 2024-02-05 00:38:07 --> Router Class Initialized
INFO - 2024-02-05 00:38:07 --> Output Class Initialized
INFO - 2024-02-05 00:38:07 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:07 --> Input Class Initialized
INFO - 2024-02-05 00:38:07 --> Language Class Initialized
INFO - 2024-02-05 00:38:07 --> Loader Class Initialized
INFO - 2024-02-05 00:38:07 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:07 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:07 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:07 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:07 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:07 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:07 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:07 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:07 --> Controller Class Initialized
INFO - 2024-02-05 00:38:07 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:07 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:38:07 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
INFO - 2024-02-05 00:38:07 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:38:07 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:07 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:07 --> Total execution time: 0.0678
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:09 --> Config Class Initialized
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Hooks Class Initialized
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.0626
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:38:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:09 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> URI Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Router Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> Output Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Security Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.0918
DEBUG - 2024-02-05 00:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Input Class Initialized
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:09 --> Language Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> Loader Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.0924
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Email Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.1078
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.1077
INFO - 2024-02-05 00:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:09 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:09 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:09 --> Controller Class Initialized
INFO - 2024-02-05 00:38:09 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:09 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:09 --> Total execution time: 0.1536
INFO - 2024-02-05 00:38:12 --> Config Class Initialized
INFO - 2024-02-05 00:38:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:12 --> URI Class Initialized
INFO - 2024-02-05 00:38:12 --> Router Class Initialized
INFO - 2024-02-05 00:38:12 --> Output Class Initialized
INFO - 2024-02-05 00:38:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:12 --> Input Class Initialized
INFO - 2024-02-05 00:38:12 --> Language Class Initialized
INFO - 2024-02-05 00:38:12 --> Loader Class Initialized
INFO - 2024-02-05 00:38:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:12 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:12 --> Controller Class Initialized
INFO - 2024-02-05 00:38:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:38:12 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:38:12 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:38:12 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:12 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:12 --> Total execution time: 0.0877
INFO - 2024-02-05 00:38:54 --> Config Class Initialized
INFO - 2024-02-05 00:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:54 --> URI Class Initialized
INFO - 2024-02-05 00:38:54 --> Router Class Initialized
INFO - 2024-02-05 00:38:54 --> Output Class Initialized
INFO - 2024-02-05 00:38:54 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:54 --> Input Class Initialized
INFO - 2024-02-05 00:38:54 --> Language Class Initialized
INFO - 2024-02-05 00:38:54 --> Loader Class Initialized
INFO - 2024-02-05 00:38:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:54 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:54 --> Controller Class Initialized
INFO - 2024-02-05 00:38:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:54 --> Total execution time: 0.0596
INFO - 2024-02-05 00:38:55 --> Config Class Initialized
INFO - 2024-02-05 00:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:55 --> URI Class Initialized
INFO - 2024-02-05 00:38:55 --> Router Class Initialized
INFO - 2024-02-05 00:38:55 --> Output Class Initialized
INFO - 2024-02-05 00:38:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:55 --> Input Class Initialized
INFO - 2024-02-05 00:38:55 --> Language Class Initialized
INFO - 2024-02-05 00:38:55 --> Loader Class Initialized
INFO - 2024-02-05 00:38:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:55 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:55 --> Controller Class Initialized
INFO - 2024-02-05 00:38:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:55 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:55 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:55 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:55 --> Total execution time: 0.0653
INFO - 2024-02-05 00:38:55 --> Config Class Initialized
INFO - 2024-02-05 00:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:55 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:55 --> URI Class Initialized
INFO - 2024-02-05 00:38:55 --> Router Class Initialized
INFO - 2024-02-05 00:38:55 --> Output Class Initialized
INFO - 2024-02-05 00:38:55 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:55 --> Input Class Initialized
INFO - 2024-02-05 00:38:55 --> Language Class Initialized
INFO - 2024-02-05 00:38:55 --> Loader Class Initialized
INFO - 2024-02-05 00:38:55 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:55 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:55 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:55 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:55 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:55 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:55 --> Controller Class Initialized
INFO - 2024-02-05 00:38:55 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:55 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:56 --> Config Class Initialized
INFO - 2024-02-05 00:38:56 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:56 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:56 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:56 --> URI Class Initialized
INFO - 2024-02-05 00:38:56 --> Router Class Initialized
INFO - 2024-02-05 00:38:56 --> Output Class Initialized
INFO - 2024-02-05 00:38:56 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:56 --> Input Class Initialized
INFO - 2024-02-05 00:38:56 --> Language Class Initialized
INFO - 2024-02-05 00:38:56 --> Loader Class Initialized
INFO - 2024-02-05 00:38:56 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:56 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:56 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:56 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:56 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:56 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:56 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:56 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:56 --> Controller Class Initialized
INFO - 2024-02-05 00:38:56 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:56 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:56 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:56 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:56 --> Total execution time: 0.0681
INFO - 2024-02-05 00:38:57 --> Config Class Initialized
INFO - 2024-02-05 00:38:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:57 --> URI Class Initialized
INFO - 2024-02-05 00:38:57 --> Router Class Initialized
INFO - 2024-02-05 00:38:57 --> Output Class Initialized
INFO - 2024-02-05 00:38:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:57 --> Input Class Initialized
INFO - 2024-02-05 00:38:57 --> Language Class Initialized
INFO - 2024-02-05 00:38:57 --> Loader Class Initialized
INFO - 2024-02-05 00:38:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:57 --> Controller Class Initialized
INFO - 2024-02-05 00:38:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:57 --> Config Class Initialized
INFO - 2024-02-05 00:38:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:38:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:38:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:38:57 --> URI Class Initialized
INFO - 2024-02-05 00:38:57 --> Router Class Initialized
INFO - 2024-02-05 00:38:57 --> Output Class Initialized
INFO - 2024-02-05 00:38:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:38:57 --> Input Class Initialized
INFO - 2024-02-05 00:38:57 --> Language Class Initialized
INFO - 2024-02-05 00:38:57 --> Loader Class Initialized
INFO - 2024-02-05 00:38:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:38:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:38:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:38:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:38:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:38:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:38:57 --> Controller Class Initialized
INFO - 2024-02-05 00:38:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:38:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:38:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:38:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:38:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:38:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:38:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:38:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:38:57 --> Final output sent to browser
DEBUG - 2024-02-05 00:38:57 --> Total execution time: 0.0670
INFO - 2024-02-05 00:39:04 --> Config Class Initialized
INFO - 2024-02-05 00:39:04 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:39:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:39:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:39:04 --> URI Class Initialized
INFO - 2024-02-05 00:39:04 --> Router Class Initialized
INFO - 2024-02-05 00:39:04 --> Output Class Initialized
INFO - 2024-02-05 00:39:04 --> Security Class Initialized
DEBUG - 2024-02-05 00:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:39:04 --> Input Class Initialized
INFO - 2024-02-05 00:39:04 --> Language Class Initialized
INFO - 2024-02-05 00:39:04 --> Loader Class Initialized
INFO - 2024-02-05 00:39:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:39:04 --> Helper loaded: file_helper
INFO - 2024-02-05 00:39:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:39:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:39:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:39:04 --> Email Class Initialized
DEBUG - 2024-02-05 00:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:39:04 --> Helper loaded: form_helper
INFO - 2024-02-05 00:39:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:39:04 --> Controller Class Initialized
INFO - 2024-02-05 00:39:04 --> Model "User_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:39:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:39:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:39:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:39:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:39:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:39:04 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:39:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:39:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:39:04 --> Total execution time: 0.0784
INFO - 2024-02-05 00:39:05 --> Config Class Initialized
INFO - 2024-02-05 00:39:05 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:39:05 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:39:05 --> Utf8 Class Initialized
INFO - 2024-02-05 00:39:05 --> URI Class Initialized
INFO - 2024-02-05 00:39:05 --> Router Class Initialized
INFO - 2024-02-05 00:39:05 --> Output Class Initialized
INFO - 2024-02-05 00:39:05 --> Security Class Initialized
DEBUG - 2024-02-05 00:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:39:05 --> Input Class Initialized
INFO - 2024-02-05 00:39:05 --> Language Class Initialized
INFO - 2024-02-05 00:39:05 --> Loader Class Initialized
INFO - 2024-02-05 00:39:05 --> Helper loaded: url_helper
INFO - 2024-02-05 00:39:05 --> Helper loaded: file_helper
INFO - 2024-02-05 00:39:05 --> Helper loaded: security_helper
INFO - 2024-02-05 00:39:05 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:39:05 --> Database Driver Class Initialized
INFO - 2024-02-05 00:39:05 --> Email Class Initialized
DEBUG - 2024-02-05 00:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:39:05 --> Helper loaded: form_helper
INFO - 2024-02-05 00:39:05 --> Form Validation Class Initialized
INFO - 2024-02-05 00:39:05 --> Controller Class Initialized
INFO - 2024-02-05 00:39:05 --> Model "User_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:39:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:39:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:39:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:39:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
ERROR - 2024-02-05 00:39:05 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:39:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:39:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:39:05 --> Final output sent to browser
DEBUG - 2024-02-05 00:39:05 --> Total execution time: 0.0772
INFO - 2024-02-05 00:40:17 --> Config Class Initialized
INFO - 2024-02-05 00:40:17 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:40:17 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:17 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:17 --> URI Class Initialized
INFO - 2024-02-05 00:40:17 --> Router Class Initialized
INFO - 2024-02-05 00:40:17 --> Output Class Initialized
INFO - 2024-02-05 00:40:17 --> Security Class Initialized
DEBUG - 2024-02-05 00:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:17 --> Input Class Initialized
INFO - 2024-02-05 00:40:17 --> Language Class Initialized
INFO - 2024-02-05 00:40:17 --> Loader Class Initialized
INFO - 2024-02-05 00:40:17 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:17 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:17 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:17 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:17 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:17 --> Email Class Initialized
DEBUG - 2024-02-05 00:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:17 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:17 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:17 --> Controller Class Initialized
INFO - 2024-02-05 00:40:17 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:40:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:40:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:40:17 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
INFO - 2024-02-05 00:40:17 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:40:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:40:17 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:17 --> Total execution time: 0.0691
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:40:19 --> Config Class Initialized
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:19 --> Hooks Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:40:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
INFO - 2024-02-05 00:40:19 --> URI Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.1245
INFO - 2024-02-05 00:40:19 --> Router Class Initialized
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
INFO - 2024-02-05 00:40:19 --> Output Class Initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Security Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.1397
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
DEBUG - 2024-02-05 00:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Input Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
INFO - 2024-02-05 00:40:19 --> Language Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:19 --> Loader Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.1730
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.1783
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
INFO - 2024-02-05 00:40:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.2342
INFO - 2024-02-05 00:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:19 --> Controller Class Initialized
INFO - 2024-02-05 00:40:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:19 --> Total execution time: 0.2206
INFO - 2024-02-05 00:40:25 --> Config Class Initialized
INFO - 2024-02-05 00:40:25 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:40:25 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:40:25 --> Utf8 Class Initialized
INFO - 2024-02-05 00:40:25 --> URI Class Initialized
INFO - 2024-02-05 00:40:25 --> Router Class Initialized
INFO - 2024-02-05 00:40:25 --> Output Class Initialized
INFO - 2024-02-05 00:40:25 --> Security Class Initialized
DEBUG - 2024-02-05 00:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:40:25 --> Input Class Initialized
INFO - 2024-02-05 00:40:25 --> Language Class Initialized
INFO - 2024-02-05 00:40:25 --> Loader Class Initialized
INFO - 2024-02-05 00:40:25 --> Helper loaded: url_helper
INFO - 2024-02-05 00:40:25 --> Helper loaded: file_helper
INFO - 2024-02-05 00:40:25 --> Helper loaded: security_helper
INFO - 2024-02-05 00:40:25 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:40:25 --> Database Driver Class Initialized
INFO - 2024-02-05 00:40:25 --> Email Class Initialized
DEBUG - 2024-02-05 00:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:40:25 --> Helper loaded: form_helper
INFO - 2024-02-05 00:40:25 --> Form Validation Class Initialized
INFO - 2024-02-05 00:40:25 --> Controller Class Initialized
INFO - 2024-02-05 00:40:25 --> Model "User_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:40:25 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:40:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:40:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:40:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:40:25 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:40:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:40:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:40:25 --> Final output sent to browser
DEBUG - 2024-02-05 00:40:25 --> Total execution time: 0.0714
INFO - 2024-02-05 00:41:26 --> Config Class Initialized
INFO - 2024-02-05 00:41:26 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:41:26 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:26 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:26 --> URI Class Initialized
INFO - 2024-02-05 00:41:26 --> Router Class Initialized
INFO - 2024-02-05 00:41:26 --> Output Class Initialized
INFO - 2024-02-05 00:41:26 --> Security Class Initialized
DEBUG - 2024-02-05 00:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:26 --> Input Class Initialized
INFO - 2024-02-05 00:41:26 --> Language Class Initialized
INFO - 2024-02-05 00:41:26 --> Loader Class Initialized
INFO - 2024-02-05 00:41:26 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:26 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:26 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:26 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:26 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:26 --> Email Class Initialized
DEBUG - 2024-02-05 00:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:26 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:26 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:26 --> Controller Class Initialized
INFO - 2024-02-05 00:41:26 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:41:26 --> Severity: Notice --> Undefined property: Admin::$pesanan_model C:\xampp\htdocs\simba\application\controllers\Admin.php 491
ERROR - 2024-02-05 00:41:26 --> Severity: error --> Exception: Call to a member function rules() on null C:\xampp\htdocs\simba\application\controllers\Admin.php 493
INFO - 2024-02-05 00:41:32 --> Config Class Initialized
INFO - 2024-02-05 00:41:32 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:41:32 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:32 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:32 --> URI Class Initialized
INFO - 2024-02-05 00:41:32 --> Router Class Initialized
INFO - 2024-02-05 00:41:32 --> Output Class Initialized
INFO - 2024-02-05 00:41:32 --> Security Class Initialized
DEBUG - 2024-02-05 00:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:32 --> Input Class Initialized
INFO - 2024-02-05 00:41:32 --> Language Class Initialized
INFO - 2024-02-05 00:41:32 --> Loader Class Initialized
INFO - 2024-02-05 00:41:32 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:32 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:32 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:32 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:32 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:32 --> Email Class Initialized
DEBUG - 2024-02-05 00:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:32 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:32 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:32 --> Controller Class Initialized
INFO - 2024-02-05 00:41:32 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:32 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:41:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:41:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'id_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 30
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'nip' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 31
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 32
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'id_permintaan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 39
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'surat_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 69
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'uraian' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 79
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'tanggal_surat' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 90
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Undefined variable: Pesanan C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
ERROR - 2024-02-05 00:41:32 --> Severity: Notice --> Trying to get property 'file_pesanan' of non-object C:\xampp\htdocs\simba\application\views\admin\e_pesanan.php 103
INFO - 2024-02-05 00:41:32 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:41:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:41:32 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:32 --> Total execution time: 0.0697
INFO - 2024-02-05 00:41:54 --> Config Class Initialized
INFO - 2024-02-05 00:41:54 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:41:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:54 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:54 --> URI Class Initialized
INFO - 2024-02-05 00:41:54 --> Router Class Initialized
INFO - 2024-02-05 00:41:54 --> Output Class Initialized
INFO - 2024-02-05 00:41:54 --> Security Class Initialized
DEBUG - 2024-02-05 00:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:54 --> Input Class Initialized
INFO - 2024-02-05 00:41:54 --> Language Class Initialized
INFO - 2024-02-05 00:41:54 --> Loader Class Initialized
INFO - 2024-02-05 00:41:54 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:54 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:54 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:54 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:54 --> Email Class Initialized
DEBUG - 2024-02-05 00:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:54 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:54 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:54 --> Controller Class Initialized
INFO - 2024-02-05 00:41:54 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:41:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:41:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:41:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:41:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:41:54 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:54 --> Total execution time: 0.0821
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> Config Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:41:58 --> Hooks Class Initialized
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
INFO - 2024-02-05 00:41:58 --> Utf8 Class Initialized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> URI Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> Router Class Initialized
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
INFO - 2024-02-05 00:41:58 --> Output Class Initialized
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
INFO - 2024-02-05 00:41:58 --> Security Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> Input Class Initialized
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Language Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Loader Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: url_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: file_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: security_helper
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.0755
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Database Driver Class Initialized
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Email Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.0907
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.1021
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.1218
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.1392
INFO - 2024-02-05 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:41:58 --> Helper loaded: form_helper
INFO - 2024-02-05 00:41:58 --> Form Validation Class Initialized
INFO - 2024-02-05 00:41:58 --> Controller Class Initialized
INFO - 2024-02-05 00:41:58 --> Model "User_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:41:58 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:41:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:41:58 --> Final output sent to browser
DEBUG - 2024-02-05 00:41:58 --> Total execution time: 0.1604
INFO - 2024-02-05 00:42:26 --> Config Class Initialized
INFO - 2024-02-05 00:42:26 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:42:26 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:42:26 --> Utf8 Class Initialized
INFO - 2024-02-05 00:42:26 --> URI Class Initialized
INFO - 2024-02-05 00:42:26 --> Router Class Initialized
INFO - 2024-02-05 00:42:26 --> Output Class Initialized
INFO - 2024-02-05 00:42:26 --> Security Class Initialized
DEBUG - 2024-02-05 00:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:42:26 --> Input Class Initialized
INFO - 2024-02-05 00:42:26 --> Language Class Initialized
INFO - 2024-02-05 00:42:26 --> Loader Class Initialized
INFO - 2024-02-05 00:42:26 --> Helper loaded: url_helper
INFO - 2024-02-05 00:42:26 --> Helper loaded: file_helper
INFO - 2024-02-05 00:42:26 --> Helper loaded: security_helper
INFO - 2024-02-05 00:42:26 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:42:26 --> Database Driver Class Initialized
INFO - 2024-02-05 00:42:26 --> Email Class Initialized
DEBUG - 2024-02-05 00:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:42:26 --> Helper loaded: form_helper
INFO - 2024-02-05 00:42:26 --> Form Validation Class Initialized
INFO - 2024-02-05 00:42:26 --> Controller Class Initialized
INFO - 2024-02-05 00:42:26 --> Model "User_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:42:26 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:42:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:42:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:42:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:42:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:42:26 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:42:26 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:42:26 --> Final output sent to browser
DEBUG - 2024-02-05 00:42:26 --> Total execution time: 0.0652
INFO - 2024-02-05 00:43:12 --> Config Class Initialized
INFO - 2024-02-05 00:43:12 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:12 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:12 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:12 --> URI Class Initialized
INFO - 2024-02-05 00:43:12 --> Router Class Initialized
INFO - 2024-02-05 00:43:12 --> Output Class Initialized
INFO - 2024-02-05 00:43:12 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:12 --> Input Class Initialized
INFO - 2024-02-05 00:43:12 --> Language Class Initialized
INFO - 2024-02-05 00:43:12 --> Loader Class Initialized
INFO - 2024-02-05 00:43:12 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:12 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:12 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:12 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:12 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:12 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:12 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:12 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:12 --> Controller Class Initialized
INFO - 2024-02-05 00:43:12 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:12 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:43:12 --> 404 Page Not Found: 
INFO - 2024-02-05 00:43:15 --> Config Class Initialized
INFO - 2024-02-05 00:43:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:15 --> URI Class Initialized
INFO - 2024-02-05 00:43:15 --> Router Class Initialized
INFO - 2024-02-05 00:43:15 --> Output Class Initialized
INFO - 2024-02-05 00:43:15 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:15 --> Input Class Initialized
INFO - 2024-02-05 00:43:15 --> Language Class Initialized
INFO - 2024-02-05 00:43:15 --> Loader Class Initialized
INFO - 2024-02-05 00:43:15 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:15 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:15 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:15 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:15 --> Controller Class Initialized
INFO - 2024-02-05 00:43:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:43:15 --> 404 Page Not Found: 
INFO - 2024-02-05 00:43:16 --> Config Class Initialized
INFO - 2024-02-05 00:43:16 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:16 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:16 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:16 --> URI Class Initialized
INFO - 2024-02-05 00:43:16 --> Router Class Initialized
INFO - 2024-02-05 00:43:16 --> Output Class Initialized
INFO - 2024-02-05 00:43:16 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:16 --> Input Class Initialized
INFO - 2024-02-05 00:43:16 --> Language Class Initialized
INFO - 2024-02-05 00:43:16 --> Loader Class Initialized
INFO - 2024-02-05 00:43:16 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:16 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:16 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:16 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:16 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:16 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:16 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:16 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:16 --> Controller Class Initialized
INFO - 2024-02-05 00:43:16 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:16 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:43:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:43:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:43:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:43:16 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:43:16 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:43:16 --> Final output sent to browser
DEBUG - 2024-02-05 00:43:16 --> Total execution time: 0.1739
INFO - 2024-02-05 00:43:17 --> Config Class Initialized
INFO - 2024-02-05 00:43:17 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:17 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:17 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:17 --> URI Class Initialized
INFO - 2024-02-05 00:43:17 --> Router Class Initialized
INFO - 2024-02-05 00:43:17 --> Output Class Initialized
INFO - 2024-02-05 00:43:17 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:17 --> Input Class Initialized
INFO - 2024-02-05 00:43:17 --> Language Class Initialized
INFO - 2024-02-05 00:43:17 --> Loader Class Initialized
INFO - 2024-02-05 00:43:17 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:17 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:17 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:17 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:17 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:17 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:17 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:17 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:17 --> Controller Class Initialized
INFO - 2024-02-05 00:43:17 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:43:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:43:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:43:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:43:17 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:43:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:43:17 --> Final output sent to browser
DEBUG - 2024-02-05 00:43:17 --> Total execution time: 0.0875
INFO - 2024-02-05 00:43:18 --> Config Class Initialized
INFO - 2024-02-05 00:43:18 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:18 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:18 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:18 --> URI Class Initialized
INFO - 2024-02-05 00:43:18 --> Router Class Initialized
INFO - 2024-02-05 00:43:18 --> Output Class Initialized
INFO - 2024-02-05 00:43:18 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:18 --> Input Class Initialized
INFO - 2024-02-05 00:43:18 --> Language Class Initialized
INFO - 2024-02-05 00:43:18 --> Loader Class Initialized
INFO - 2024-02-05 00:43:18 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:18 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:18 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:18 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:18 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:18 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:18 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:18 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:18 --> Controller Class Initialized
INFO - 2024-02-05 00:43:18 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:18 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:43:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:43:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:43:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:43:18 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:43:18 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:43:18 --> Final output sent to browser
DEBUG - 2024-02-05 00:43:18 --> Total execution time: 0.0812
INFO - 2024-02-05 00:43:19 --> Config Class Initialized
INFO - 2024-02-05 00:43:19 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:43:19 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:43:19 --> Utf8 Class Initialized
INFO - 2024-02-05 00:43:19 --> URI Class Initialized
INFO - 2024-02-05 00:43:19 --> Router Class Initialized
INFO - 2024-02-05 00:43:19 --> Output Class Initialized
INFO - 2024-02-05 00:43:19 --> Security Class Initialized
DEBUG - 2024-02-05 00:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:43:19 --> Input Class Initialized
INFO - 2024-02-05 00:43:19 --> Language Class Initialized
INFO - 2024-02-05 00:43:19 --> Loader Class Initialized
INFO - 2024-02-05 00:43:19 --> Helper loaded: url_helper
INFO - 2024-02-05 00:43:19 --> Helper loaded: file_helper
INFO - 2024-02-05 00:43:19 --> Helper loaded: security_helper
INFO - 2024-02-05 00:43:19 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:43:19 --> Database Driver Class Initialized
INFO - 2024-02-05 00:43:19 --> Email Class Initialized
DEBUG - 2024-02-05 00:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:43:19 --> Helper loaded: form_helper
INFO - 2024-02-05 00:43:19 --> Form Validation Class Initialized
INFO - 2024-02-05 00:43:19 --> Controller Class Initialized
INFO - 2024-02-05 00:43:19 --> Model "User_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:43:19 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:43:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:43:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:43:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:43:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:43:19 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:43:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:43:19 --> Final output sent to browser
DEBUG - 2024-02-05 00:43:19 --> Total execution time: 0.0705
INFO - 2024-02-05 00:44:02 --> Config Class Initialized
INFO - 2024-02-05 00:44:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:44:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:02 --> URI Class Initialized
INFO - 2024-02-05 00:44:02 --> Router Class Initialized
INFO - 2024-02-05 00:44:02 --> Output Class Initialized
INFO - 2024-02-05 00:44:02 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:02 --> Input Class Initialized
INFO - 2024-02-05 00:44:02 --> Language Class Initialized
INFO - 2024-02-05 00:44:02 --> Loader Class Initialized
INFO - 2024-02-05 00:44:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:02 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:02 --> Controller Class Initialized
INFO - 2024-02-05 00:44:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:44:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:44:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:44:02 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:44:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:44:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:02 --> Total execution time: 0.0609
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
INFO - 2024-02-05 00:44:04 --> Config Class Initialized
INFO - 2024-02-05 00:44:04 --> Hooks Class Initialized
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:04 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> URI Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Router Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
INFO - 2024-02-05 00:44:04 --> Controller Class Initialized
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:04 --> Output Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:04 --> Security Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:04 --> Model "Pesanan_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:04 --> Input Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:44:04 --> Language Class Initialized
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:04 --> Total execution time: 0.0734
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:04 --> Loader Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:04 --> Controller Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:04 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:04 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:04 --> Total execution time: 0.0839
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:04 --> Email Class Initialized
INFO - 2024-02-05 00:44:04 --> Helper loaded: form_helper
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:04 --> Controller Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:04 --> Total execution time: 0.1292
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:04 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:04 --> Controller Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:04 --> Total execution time: 0.1160
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:04 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:04 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:04 --> Controller Class Initialized
INFO - 2024-02-05 00:44:04 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:04 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:04 --> Total execution time: 0.2323
INFO - 2024-02-05 00:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:05 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:05 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:05 --> Controller Class Initialized
INFO - 2024-02-05 00:44:05 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:05 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:05 --> Total execution time: 0.2552
INFO - 2024-02-05 00:44:10 --> Config Class Initialized
INFO - 2024-02-05 00:44:10 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:44:10 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:10 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:10 --> URI Class Initialized
INFO - 2024-02-05 00:44:10 --> Router Class Initialized
INFO - 2024-02-05 00:44:10 --> Output Class Initialized
INFO - 2024-02-05 00:44:10 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:10 --> Input Class Initialized
INFO - 2024-02-05 00:44:10 --> Language Class Initialized
INFO - 2024-02-05 00:44:10 --> Loader Class Initialized
INFO - 2024-02-05 00:44:10 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:10 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:10 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:10 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:10 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:10 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:10 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:10 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:10 --> Controller Class Initialized
INFO - 2024-02-05 00:44:10 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:44:10 --> 404 Page Not Found: 
INFO - 2024-02-05 00:44:14 --> Config Class Initialized
INFO - 2024-02-05 00:44:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:44:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:14 --> URI Class Initialized
INFO - 2024-02-05 00:44:14 --> Router Class Initialized
INFO - 2024-02-05 00:44:14 --> Output Class Initialized
INFO - 2024-02-05 00:44:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:14 --> Input Class Initialized
INFO - 2024-02-05 00:44:14 --> Language Class Initialized
INFO - 2024-02-05 00:44:14 --> Loader Class Initialized
INFO - 2024-02-05 00:44:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:14 --> Controller Class Initialized
INFO - 2024-02-05 00:44:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:44:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:44:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:44:14 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:44:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:44:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:14 --> Total execution time: 0.0490
INFO - 2024-02-05 00:44:15 --> Config Class Initialized
INFO - 2024-02-05 00:44:15 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:44:15 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:44:15 --> Utf8 Class Initialized
INFO - 2024-02-05 00:44:15 --> URI Class Initialized
INFO - 2024-02-05 00:44:15 --> Router Class Initialized
INFO - 2024-02-05 00:44:15 --> Output Class Initialized
INFO - 2024-02-05 00:44:15 --> Security Class Initialized
DEBUG - 2024-02-05 00:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:44:15 --> Input Class Initialized
INFO - 2024-02-05 00:44:15 --> Language Class Initialized
INFO - 2024-02-05 00:44:15 --> Loader Class Initialized
INFO - 2024-02-05 00:44:15 --> Helper loaded: url_helper
INFO - 2024-02-05 00:44:15 --> Helper loaded: file_helper
INFO - 2024-02-05 00:44:15 --> Helper loaded: security_helper
INFO - 2024-02-05 00:44:15 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:44:15 --> Database Driver Class Initialized
INFO - 2024-02-05 00:44:15 --> Email Class Initialized
DEBUG - 2024-02-05 00:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:44:15 --> Helper loaded: form_helper
INFO - 2024-02-05 00:44:15 --> Form Validation Class Initialized
INFO - 2024-02-05 00:44:15 --> Controller Class Initialized
INFO - 2024-02-05 00:44:15 --> Model "User_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:44:15 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:44:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:44:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:44:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:44:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:44:15 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:44:15 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:44:15 --> Final output sent to browser
DEBUG - 2024-02-05 00:44:15 --> Total execution time: 0.0779
INFO - 2024-02-05 00:45:11 --> Config Class Initialized
INFO - 2024-02-05 00:45:11 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:11 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:11 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:11 --> URI Class Initialized
INFO - 2024-02-05 00:45:11 --> Router Class Initialized
INFO - 2024-02-05 00:45:11 --> Output Class Initialized
INFO - 2024-02-05 00:45:11 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:11 --> Input Class Initialized
INFO - 2024-02-05 00:45:11 --> Language Class Initialized
INFO - 2024-02-05 00:45:11 --> Loader Class Initialized
INFO - 2024-02-05 00:45:11 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:11 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:11 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:11 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:11 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:11 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:11 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:11 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:11 --> Controller Class Initialized
INFO - 2024-02-05 00:45:11 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:11 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:11 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:45:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:11 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:11 --> Total execution time: 0.0847
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:14 --> Config Class Initialized
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
DEBUG - 2024-02-05 00:45:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> URI Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Router Class Initialized
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Output Class Initialized
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:14 --> Security Class Initialized
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:14 --> Input Class Initialized
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> Language Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:14 --> Loader Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.0602
INFO - 2024-02-05 00:45:14 --> Helper loaded: file_helper
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.0737
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.0900
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.1099
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.1370
INFO - 2024-02-05 00:45:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:14 --> Controller Class Initialized
INFO - 2024-02-05 00:45:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:14 --> Total execution time: 0.1811
INFO - 2024-02-05 00:45:17 --> Config Class Initialized
INFO - 2024-02-05 00:45:17 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:17 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:17 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:17 --> URI Class Initialized
INFO - 2024-02-05 00:45:17 --> Router Class Initialized
INFO - 2024-02-05 00:45:17 --> Output Class Initialized
INFO - 2024-02-05 00:45:17 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:17 --> Input Class Initialized
INFO - 2024-02-05 00:45:17 --> Language Class Initialized
INFO - 2024-02-05 00:45:17 --> Loader Class Initialized
INFO - 2024-02-05 00:45:17 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:17 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:17 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:17 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:17 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:17 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:17 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:17 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:17 --> Controller Class Initialized
INFO - 2024-02-05 00:45:17 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:17 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 00:45:17 --> 404 Page Not Found: 
INFO - 2024-02-05 00:45:22 --> Config Class Initialized
INFO - 2024-02-05 00:45:22 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:22 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:22 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:22 --> URI Class Initialized
INFO - 2024-02-05 00:45:22 --> Router Class Initialized
INFO - 2024-02-05 00:45:22 --> Output Class Initialized
INFO - 2024-02-05 00:45:22 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:22 --> Input Class Initialized
INFO - 2024-02-05 00:45:22 --> Language Class Initialized
INFO - 2024-02-05 00:45:22 --> Loader Class Initialized
INFO - 2024-02-05 00:45:22 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:22 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:22 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:22 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:22 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:22 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:22 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:22 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:22 --> Controller Class Initialized
INFO - 2024-02-05 00:45:22 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:22 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:22 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:45:22 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:22 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:22 --> Total execution time: 0.0554
INFO - 2024-02-05 00:45:31 --> Config Class Initialized
INFO - 2024-02-05 00:45:31 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:31 --> URI Class Initialized
INFO - 2024-02-05 00:45:31 --> Router Class Initialized
INFO - 2024-02-05 00:45:31 --> Output Class Initialized
INFO - 2024-02-05 00:45:31 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:31 --> Input Class Initialized
INFO - 2024-02-05 00:45:31 --> Language Class Initialized
INFO - 2024-02-05 00:45:31 --> Loader Class Initialized
INFO - 2024-02-05 00:45:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:31 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:31 --> Controller Class Initialized
INFO - 2024-02-05 00:45:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:45:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:31 --> Total execution time: 0.0686
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Config Class Initialized
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Hooks Class Initialized
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
DEBUG - 2024-02-05 00:45:33 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:33 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> URI Class Initialized
INFO - 2024-02-05 00:45:33 --> Router Class Initialized
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Output Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Input Class Initialized
INFO - 2024-02-05 00:45:33 --> Language Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:33 --> Loader Class Initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.0635
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
INFO - 2024-02-05 00:45:33 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Email Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.0751
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.0976
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.1183
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.1385
INFO - 2024-02-05 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:33 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:33 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:33 --> Controller Class Initialized
INFO - 2024-02-05 00:45:33 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:33 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:33 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:33 --> Total execution time: 0.1668
INFO - 2024-02-05 00:45:37 --> Config Class Initialized
INFO - 2024-02-05 00:45:37 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:37 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:37 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:37 --> URI Class Initialized
INFO - 2024-02-05 00:45:37 --> Router Class Initialized
INFO - 2024-02-05 00:45:37 --> Output Class Initialized
INFO - 2024-02-05 00:45:37 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:37 --> Input Class Initialized
INFO - 2024-02-05 00:45:37 --> Language Class Initialized
INFO - 2024-02-05 00:45:37 --> Loader Class Initialized
INFO - 2024-02-05 00:45:37 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:37 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:37 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:37 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:37 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:38 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:38 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:38 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:38 --> Controller Class Initialized
INFO - 2024-02-05 00:45:38 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:38 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:38 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:45:38 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:38 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:38 --> Total execution time: 0.0922
INFO - 2024-02-05 00:45:57 --> Config Class Initialized
INFO - 2024-02-05 00:45:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:57 --> URI Class Initialized
INFO - 2024-02-05 00:45:57 --> Router Class Initialized
INFO - 2024-02-05 00:45:57 --> Output Class Initialized
INFO - 2024-02-05 00:45:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:57 --> Input Class Initialized
INFO - 2024-02-05 00:45:57 --> Language Class Initialized
INFO - 2024-02-05 00:45:57 --> Loader Class Initialized
INFO - 2024-02-05 00:45:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:57 --> Controller Class Initialized
INFO - 2024-02-05 00:45:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:57 --> Config Class Initialized
INFO - 2024-02-05 00:45:57 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:57 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:57 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:57 --> URI Class Initialized
INFO - 2024-02-05 00:45:57 --> Router Class Initialized
INFO - 2024-02-05 00:45:57 --> Output Class Initialized
INFO - 2024-02-05 00:45:57 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:57 --> Input Class Initialized
INFO - 2024-02-05 00:45:57 --> Language Class Initialized
INFO - 2024-02-05 00:45:57 --> Loader Class Initialized
INFO - 2024-02-05 00:45:57 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:57 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:57 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:57 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:57 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:57 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:57 --> Controller Class Initialized
INFO - 2024-02-05 00:45:57 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:57 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:57 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:45:57 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:57 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:57 --> Total execution time: 0.1346
INFO - 2024-02-05 00:45:59 --> Config Class Initialized
INFO - 2024-02-05 00:45:59 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:45:59 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:45:59 --> Utf8 Class Initialized
INFO - 2024-02-05 00:45:59 --> URI Class Initialized
INFO - 2024-02-05 00:45:59 --> Router Class Initialized
INFO - 2024-02-05 00:45:59 --> Output Class Initialized
INFO - 2024-02-05 00:45:59 --> Security Class Initialized
DEBUG - 2024-02-05 00:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:45:59 --> Input Class Initialized
INFO - 2024-02-05 00:45:59 --> Language Class Initialized
INFO - 2024-02-05 00:45:59 --> Loader Class Initialized
INFO - 2024-02-05 00:45:59 --> Helper loaded: url_helper
INFO - 2024-02-05 00:45:59 --> Helper loaded: file_helper
INFO - 2024-02-05 00:45:59 --> Helper loaded: security_helper
INFO - 2024-02-05 00:45:59 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:45:59 --> Database Driver Class Initialized
INFO - 2024-02-05 00:45:59 --> Email Class Initialized
DEBUG - 2024-02-05 00:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:45:59 --> Helper loaded: form_helper
INFO - 2024-02-05 00:45:59 --> Form Validation Class Initialized
INFO - 2024-02-05 00:45:59 --> Controller Class Initialized
INFO - 2024-02-05 00:45:59 --> Model "User_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:45:59 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:45:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:45:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:45:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:45:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:45:59 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:45:59 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:45:59 --> Final output sent to browser
DEBUG - 2024-02-05 00:45:59 --> Total execution time: 0.0659
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
INFO - 2024-02-05 00:46:02 --> Config Class Initialized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
DEBUG - 2024-02-05 00:46:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:02 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
INFO - 2024-02-05 00:46:02 --> URI Class Initialized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Router Class Initialized
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Output Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Security Class Initialized
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
DEBUG - 2024-02-05 00:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:02 --> Input Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Language Class Initialized
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Loader Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:02 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Email Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.0645
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.0823
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.0975
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.1098
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.1246
INFO - 2024-02-05 00:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:02 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:02 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:02 --> Controller Class Initialized
INFO - 2024-02-05 00:46:02 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:02 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:02 --> Total execution time: 0.1374
INFO - 2024-02-05 00:46:14 --> Config Class Initialized
INFO - 2024-02-05 00:46:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:46:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:14 --> URI Class Initialized
INFO - 2024-02-05 00:46:14 --> Router Class Initialized
INFO - 2024-02-05 00:46:14 --> Output Class Initialized
INFO - 2024-02-05 00:46:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:14 --> Input Class Initialized
INFO - 2024-02-05 00:46:14 --> Language Class Initialized
INFO - 2024-02-05 00:46:14 --> Loader Class Initialized
INFO - 2024-02-05 00:46:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:14 --> Controller Class Initialized
INFO - 2024-02-05 00:46:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:14 --> Helper loaded: inflector_helper
INFO - 2024-02-05 00:46:14 --> Upload Class Initialized
INFO - 2024-02-05 00:46:14 --> Config Class Initialized
INFO - 2024-02-05 00:46:14 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:46:14 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:14 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:14 --> URI Class Initialized
INFO - 2024-02-05 00:46:14 --> Router Class Initialized
INFO - 2024-02-05 00:46:14 --> Output Class Initialized
INFO - 2024-02-05 00:46:14 --> Security Class Initialized
DEBUG - 2024-02-05 00:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:14 --> Input Class Initialized
INFO - 2024-02-05 00:46:14 --> Language Class Initialized
INFO - 2024-02-05 00:46:14 --> Loader Class Initialized
INFO - 2024-02-05 00:46:14 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:14 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:14 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:14 --> Email Class Initialized
DEBUG - 2024-02-05 00:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:14 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:14 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:14 --> Controller Class Initialized
INFO - 2024-02-05 00:46:14 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:14 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:46:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:46:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:46:14 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:46:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:46:14 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:14 --> Total execution time: 0.0652
INFO - 2024-02-05 00:46:48 --> Config Class Initialized
INFO - 2024-02-05 00:46:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:46:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:46:48 --> Utf8 Class Initialized
INFO - 2024-02-05 00:46:48 --> URI Class Initialized
INFO - 2024-02-05 00:46:48 --> Router Class Initialized
INFO - 2024-02-05 00:46:48 --> Output Class Initialized
INFO - 2024-02-05 00:46:48 --> Security Class Initialized
DEBUG - 2024-02-05 00:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:46:48 --> Input Class Initialized
INFO - 2024-02-05 00:46:48 --> Language Class Initialized
INFO - 2024-02-05 00:46:48 --> Loader Class Initialized
INFO - 2024-02-05 00:46:48 --> Helper loaded: url_helper
INFO - 2024-02-05 00:46:48 --> Helper loaded: file_helper
INFO - 2024-02-05 00:46:48 --> Helper loaded: security_helper
INFO - 2024-02-05 00:46:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:46:48 --> Database Driver Class Initialized
INFO - 2024-02-05 00:46:48 --> Email Class Initialized
DEBUG - 2024-02-05 00:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:46:48 --> Helper loaded: form_helper
INFO - 2024-02-05 00:46:48 --> Form Validation Class Initialized
INFO - 2024-02-05 00:46:48 --> Controller Class Initialized
INFO - 2024-02-05 00:46:48 --> Model "User_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:46:48 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:46:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:46:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:46:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:46:48 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:46:48 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:46:48 --> Final output sent to browser
DEBUG - 2024-02-05 00:46:48 --> Total execution time: 0.0564
INFO - 2024-02-05 00:47:27 --> Config Class Initialized
INFO - 2024-02-05 00:47:27 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:47:27 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:27 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:27 --> URI Class Initialized
INFO - 2024-02-05 00:47:27 --> Router Class Initialized
INFO - 2024-02-05 00:47:27 --> Output Class Initialized
INFO - 2024-02-05 00:47:27 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:27 --> Input Class Initialized
INFO - 2024-02-05 00:47:27 --> Language Class Initialized
INFO - 2024-02-05 00:47:27 --> Loader Class Initialized
INFO - 2024-02-05 00:47:27 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:27 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:27 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:27 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:27 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:27 --> Email Class Initialized
DEBUG - 2024-02-05 00:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:27 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:27 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:27 --> Controller Class Initialized
INFO - 2024-02-05 00:47:27 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:27 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:47:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:47:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:47:27 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:47:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:47:27 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:27 --> Total execution time: 0.0792
INFO - 2024-02-05 00:47:28 --> Config Class Initialized
INFO - 2024-02-05 00:47:28 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:47:28 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:28 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:28 --> URI Class Initialized
INFO - 2024-02-05 00:47:28 --> Router Class Initialized
INFO - 2024-02-05 00:47:28 --> Output Class Initialized
INFO - 2024-02-05 00:47:28 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:28 --> Input Class Initialized
INFO - 2024-02-05 00:47:28 --> Language Class Initialized
INFO - 2024-02-05 00:47:28 --> Loader Class Initialized
INFO - 2024-02-05 00:47:28 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:28 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:28 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:28 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:28 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:28 --> Email Class Initialized
DEBUG - 2024-02-05 00:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:28 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:28 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:28 --> Controller Class Initialized
INFO - 2024-02-05 00:47:28 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:28 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:47:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:47:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:47:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-02-05 00:47:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:47:28 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:28 --> Total execution time: 0.0644
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Config Class Initialized
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:31 --> Hooks Class Initialized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-05 00:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
INFO - 2024-02-05 00:47:31 --> Utf8 Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
INFO - 2024-02-05 00:47:31 --> URI Class Initialized
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
INFO - 2024-02-05 00:47:31 --> Router Class Initialized
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
INFO - 2024-02-05 00:47:31 --> Output Class Initialized
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
INFO - 2024-02-05 00:47:31 --> Security Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:31 --> Input Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Language Class Initialized
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Loader Class Initialized
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:31 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.0692
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Email Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.0798
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.0932
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.1064
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.1213
INFO - 2024-02-05 00:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:31 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:31 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:31 --> Controller Class Initialized
INFO - 2024-02-05 00:47:31 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:31 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:31 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:31 --> Total execution time: 0.1331
INFO - 2024-02-05 00:47:44 --> Config Class Initialized
INFO - 2024-02-05 00:47:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:47:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:44 --> URI Class Initialized
INFO - 2024-02-05 00:47:44 --> Router Class Initialized
INFO - 2024-02-05 00:47:44 --> Output Class Initialized
INFO - 2024-02-05 00:47:44 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:44 --> Input Class Initialized
INFO - 2024-02-05 00:47:44 --> Language Class Initialized
INFO - 2024-02-05 00:47:44 --> Loader Class Initialized
INFO - 2024-02-05 00:47:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:44 --> Controller Class Initialized
INFO - 2024-02-05 00:47:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:44 --> Helper loaded: inflector_helper
INFO - 2024-02-05 00:47:44 --> Upload Class Initialized
INFO - 2024-02-05 00:47:44 --> Config Class Initialized
INFO - 2024-02-05 00:47:44 --> Hooks Class Initialized
DEBUG - 2024-02-05 00:47:44 --> UTF-8 Support Enabled
INFO - 2024-02-05 00:47:44 --> Utf8 Class Initialized
INFO - 2024-02-05 00:47:44 --> URI Class Initialized
INFO - 2024-02-05 00:47:44 --> Router Class Initialized
INFO - 2024-02-05 00:47:44 --> Output Class Initialized
INFO - 2024-02-05 00:47:44 --> Security Class Initialized
DEBUG - 2024-02-05 00:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 00:47:44 --> Input Class Initialized
INFO - 2024-02-05 00:47:44 --> Language Class Initialized
INFO - 2024-02-05 00:47:44 --> Loader Class Initialized
INFO - 2024-02-05 00:47:44 --> Helper loaded: url_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: file_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: security_helper
INFO - 2024-02-05 00:47:44 --> Helper loaded: wpu_helper
INFO - 2024-02-05 00:47:44 --> Database Driver Class Initialized
INFO - 2024-02-05 00:47:44 --> Email Class Initialized
DEBUG - 2024-02-05 00:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 00:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 00:47:44 --> Helper loaded: form_helper
INFO - 2024-02-05 00:47:44 --> Form Validation Class Initialized
INFO - 2024-02-05 00:47:44 --> Controller Class Initialized
INFO - 2024-02-05 00:47:44 --> Model "User_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Faktur_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Supplier_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 00:47:44 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 00:47:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 00:47:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 00:47:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 00:47:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 00:47:44 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-02-05 00:47:44 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 00:47:44 --> Final output sent to browser
DEBUG - 2024-02-05 00:47:44 --> Total execution time: 0.0539
INFO - 2024-02-05 14:47:48 --> Config Class Initialized
INFO - 2024-02-05 14:47:48 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:47:48 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:47:48 --> Utf8 Class Initialized
INFO - 2024-02-05 14:47:48 --> URI Class Initialized
DEBUG - 2024-02-05 14:47:48 --> No URI present. Default controller set.
INFO - 2024-02-05 14:47:48 --> Router Class Initialized
INFO - 2024-02-05 14:47:48 --> Output Class Initialized
INFO - 2024-02-05 14:47:48 --> Security Class Initialized
DEBUG - 2024-02-05 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:47:48 --> Input Class Initialized
INFO - 2024-02-05 14:47:48 --> Language Class Initialized
INFO - 2024-02-05 14:47:48 --> Loader Class Initialized
INFO - 2024-02-05 14:47:48 --> Helper loaded: url_helper
INFO - 2024-02-05 14:47:48 --> Helper loaded: file_helper
INFO - 2024-02-05 14:47:48 --> Helper loaded: security_helper
INFO - 2024-02-05 14:47:48 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:47:48 --> Database Driver Class Initialized
INFO - 2024-02-05 14:47:48 --> Email Class Initialized
DEBUG - 2024-02-05 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:47:49 --> Helper loaded: form_helper
INFO - 2024-02-05 14:47:49 --> Form Validation Class Initialized
INFO - 2024-02-05 14:47:49 --> Controller Class Initialized
DEBUG - 2024-02-05 14:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:47:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-02-05 14:47:49 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-02-05 14:47:49 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-02-05 14:47:49 --> Final output sent to browser
DEBUG - 2024-02-05 14:47:49 --> Total execution time: 0.8252
INFO - 2024-02-05 14:50:04 --> Config Class Initialized
INFO - 2024-02-05 14:50:04 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:50:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:50:04 --> Utf8 Class Initialized
INFO - 2024-02-05 14:50:04 --> URI Class Initialized
INFO - 2024-02-05 14:50:04 --> Router Class Initialized
INFO - 2024-02-05 14:50:04 --> Output Class Initialized
INFO - 2024-02-05 14:50:04 --> Security Class Initialized
DEBUG - 2024-02-05 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:50:04 --> Input Class Initialized
INFO - 2024-02-05 14:50:04 --> Language Class Initialized
INFO - 2024-02-05 14:50:04 --> Loader Class Initialized
INFO - 2024-02-05 14:50:04 --> Helper loaded: url_helper
INFO - 2024-02-05 14:50:04 --> Helper loaded: file_helper
INFO - 2024-02-05 14:50:04 --> Helper loaded: security_helper
INFO - 2024-02-05 14:50:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:50:04 --> Database Driver Class Initialized
INFO - 2024-02-05 14:50:04 --> Email Class Initialized
DEBUG - 2024-02-05 14:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:50:04 --> Helper loaded: form_helper
INFO - 2024-02-05 14:50:04 --> Form Validation Class Initialized
INFO - 2024-02-05 14:50:04 --> Controller Class Initialized
DEBUG - 2024-02-05 14:50:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:50:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-02-05 14:50:05 --> Config Class Initialized
INFO - 2024-02-05 14:50:05 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:50:05 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:50:05 --> Utf8 Class Initialized
INFO - 2024-02-05 14:50:05 --> URI Class Initialized
INFO - 2024-02-05 14:50:05 --> Router Class Initialized
INFO - 2024-02-05 14:50:05 --> Output Class Initialized
INFO - 2024-02-05 14:50:05 --> Security Class Initialized
DEBUG - 2024-02-05 14:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:50:05 --> Input Class Initialized
INFO - 2024-02-05 14:50:05 --> Language Class Initialized
INFO - 2024-02-05 14:50:05 --> Loader Class Initialized
INFO - 2024-02-05 14:50:05 --> Helper loaded: url_helper
INFO - 2024-02-05 14:50:05 --> Helper loaded: file_helper
INFO - 2024-02-05 14:50:05 --> Helper loaded: security_helper
INFO - 2024-02-05 14:50:05 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:50:05 --> Database Driver Class Initialized
INFO - 2024-02-05 14:50:05 --> Email Class Initialized
DEBUG - 2024-02-05 14:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:50:05 --> Helper loaded: form_helper
INFO - 2024-02-05 14:50:05 --> Form Validation Class Initialized
INFO - 2024-02-05 14:50:05 --> Controller Class Initialized
INFO - 2024-02-05 14:50:05 --> Model "User_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 14:50:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 14:50:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:50:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 14:50:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 14:50:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 14:50:05 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-02-05 14:50:05 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 14:50:05 --> Final output sent to browser
DEBUG - 2024-02-05 14:50:05 --> Total execution time: 0.3320
INFO - 2024-02-05 14:51:51 --> Config Class Initialized
INFO - 2024-02-05 14:51:51 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:51:51 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:51:51 --> Utf8 Class Initialized
INFO - 2024-02-05 14:51:51 --> URI Class Initialized
INFO - 2024-02-05 14:51:51 --> Router Class Initialized
INFO - 2024-02-05 14:51:51 --> Output Class Initialized
INFO - 2024-02-05 14:51:51 --> Security Class Initialized
DEBUG - 2024-02-05 14:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:51:51 --> Input Class Initialized
INFO - 2024-02-05 14:51:51 --> Language Class Initialized
INFO - 2024-02-05 14:51:51 --> Loader Class Initialized
INFO - 2024-02-05 14:51:51 --> Helper loaded: url_helper
INFO - 2024-02-05 14:51:51 --> Helper loaded: file_helper
INFO - 2024-02-05 14:51:51 --> Helper loaded: security_helper
INFO - 2024-02-05 14:51:51 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:51:51 --> Database Driver Class Initialized
INFO - 2024-02-05 14:51:51 --> Email Class Initialized
DEBUG - 2024-02-05 14:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:51:51 --> Helper loaded: form_helper
INFO - 2024-02-05 14:51:51 --> Form Validation Class Initialized
INFO - 2024-02-05 14:51:51 --> Controller Class Initialized
INFO - 2024-02-05 14:51:51 --> Model "User_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Faktur_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Supplier_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 14:51:51 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 14:51:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:51:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 14:51:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 14:51:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 14:51:51 --> File loaded: C:\xampp\htdocs\simba\application\views\report/listreport.php
INFO - 2024-02-05 14:51:51 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 14:51:51 --> Final output sent to browser
DEBUG - 2024-02-05 14:51:51 --> Total execution time: 0.0953
INFO - 2024-02-05 14:51:52 --> Config Class Initialized
INFO - 2024-02-05 14:51:52 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:51:52 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:51:52 --> Utf8 Class Initialized
INFO - 2024-02-05 14:51:52 --> URI Class Initialized
INFO - 2024-02-05 14:51:52 --> Router Class Initialized
INFO - 2024-02-05 14:51:52 --> Output Class Initialized
INFO - 2024-02-05 14:51:52 --> Security Class Initialized
DEBUG - 2024-02-05 14:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:51:52 --> Input Class Initialized
INFO - 2024-02-05 14:51:52 --> Language Class Initialized
INFO - 2024-02-05 14:51:52 --> Loader Class Initialized
INFO - 2024-02-05 14:51:52 --> Helper loaded: url_helper
INFO - 2024-02-05 14:51:52 --> Helper loaded: file_helper
INFO - 2024-02-05 14:51:52 --> Helper loaded: security_helper
INFO - 2024-02-05 14:51:52 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:51:52 --> Database Driver Class Initialized
INFO - 2024-02-05 14:51:52 --> Email Class Initialized
DEBUG - 2024-02-05 14:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:51:52 --> Helper loaded: form_helper
INFO - 2024-02-05 14:51:52 --> Form Validation Class Initialized
INFO - 2024-02-05 14:51:52 --> Controller Class Initialized
INFO - 2024-02-05 14:51:52 --> Model "User_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Faktur_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Supplier_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 14:51:52 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 14:51:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 14:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 14:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 14:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-05 14:51:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 14:51:52 --> Final output sent to browser
DEBUG - 2024-02-05 14:51:52 --> Total execution time: 0.1021
INFO - 2024-02-05 14:52:05 --> Config Class Initialized
INFO - 2024-02-05 14:52:05 --> Hooks Class Initialized
DEBUG - 2024-02-05 14:52:05 --> UTF-8 Support Enabled
INFO - 2024-02-05 14:52:05 --> Utf8 Class Initialized
INFO - 2024-02-05 14:52:05 --> URI Class Initialized
INFO - 2024-02-05 14:52:05 --> Router Class Initialized
INFO - 2024-02-05 14:52:05 --> Output Class Initialized
INFO - 2024-02-05 14:52:05 --> Security Class Initialized
DEBUG - 2024-02-05 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 14:52:05 --> Input Class Initialized
INFO - 2024-02-05 14:52:05 --> Language Class Initialized
INFO - 2024-02-05 14:52:05 --> Loader Class Initialized
INFO - 2024-02-05 14:52:05 --> Helper loaded: url_helper
INFO - 2024-02-05 14:52:05 --> Helper loaded: file_helper
INFO - 2024-02-05 14:52:05 --> Helper loaded: security_helper
INFO - 2024-02-05 14:52:05 --> Helper loaded: wpu_helper
INFO - 2024-02-05 14:52:05 --> Database Driver Class Initialized
INFO - 2024-02-05 14:52:05 --> Email Class Initialized
DEBUG - 2024-02-05 14:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 14:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 14:52:05 --> Helper loaded: form_helper
INFO - 2024-02-05 14:52:05 --> Form Validation Class Initialized
INFO - 2024-02-05 14:52:05 --> Controller Class Initialized
INFO - 2024-02-05 14:52:05 --> Model "User_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Faktur_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Supplier_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 14:52:05 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 14:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 14:52:06 --> Final output sent to browser
DEBUG - 2024-02-05 14:52:06 --> Total execution time: 1.4444
INFO - 2024-02-05 15:23:02 --> Config Class Initialized
INFO - 2024-02-05 15:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:23:02 --> Utf8 Class Initialized
INFO - 2024-02-05 15:23:02 --> URI Class Initialized
INFO - 2024-02-05 15:23:02 --> Router Class Initialized
INFO - 2024-02-05 15:23:02 --> Output Class Initialized
INFO - 2024-02-05 15:23:02 --> Security Class Initialized
DEBUG - 2024-02-05 15:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:23:02 --> Input Class Initialized
INFO - 2024-02-05 15:23:02 --> Language Class Initialized
INFO - 2024-02-05 15:23:02 --> Loader Class Initialized
INFO - 2024-02-05 15:23:02 --> Helper loaded: url_helper
INFO - 2024-02-05 15:23:02 --> Helper loaded: file_helper
INFO - 2024-02-05 15:23:02 --> Helper loaded: security_helper
INFO - 2024-02-05 15:23:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:23:02 --> Database Driver Class Initialized
INFO - 2024-02-05 15:23:02 --> Email Class Initialized
DEBUG - 2024-02-05 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:23:02 --> Helper loaded: form_helper
INFO - 2024-02-05 15:23:02 --> Form Validation Class Initialized
INFO - 2024-02-05 15:23:02 --> Controller Class Initialized
INFO - 2024-02-05 15:23:02 --> Model "User_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:23:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 15:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 15:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 15:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 15:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-05 15:23:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 15:23:02 --> Final output sent to browser
DEBUG - 2024-02-05 15:23:02 --> Total execution time: 0.0642
INFO - 2024-02-05 15:23:03 --> Config Class Initialized
INFO - 2024-02-05 15:23:03 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:23:03 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:23:03 --> Utf8 Class Initialized
INFO - 2024-02-05 15:23:03 --> URI Class Initialized
INFO - 2024-02-05 15:23:03 --> Router Class Initialized
INFO - 2024-02-05 15:23:03 --> Output Class Initialized
INFO - 2024-02-05 15:23:03 --> Security Class Initialized
DEBUG - 2024-02-05 15:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:23:03 --> Input Class Initialized
INFO - 2024-02-05 15:23:03 --> Language Class Initialized
INFO - 2024-02-05 15:23:03 --> Loader Class Initialized
INFO - 2024-02-05 15:23:03 --> Helper loaded: url_helper
INFO - 2024-02-05 15:23:03 --> Helper loaded: file_helper
INFO - 2024-02-05 15:23:03 --> Helper loaded: security_helper
INFO - 2024-02-05 15:23:03 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:23:03 --> Database Driver Class Initialized
INFO - 2024-02-05 15:23:03 --> Email Class Initialized
DEBUG - 2024-02-05 15:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:23:03 --> Helper loaded: form_helper
INFO - 2024-02-05 15:23:03 --> Form Validation Class Initialized
INFO - 2024-02-05 15:23:03 --> Controller Class Initialized
INFO - 2024-02-05 15:23:03 --> Model "User_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:23:03 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:23:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 15:23:03 --> Severity: error --> Exception: File http://localhost/simba/assets/simba.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-05 15:27:02 --> Config Class Initialized
INFO - 2024-02-05 15:27:02 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:27:02 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:27:02 --> Utf8 Class Initialized
INFO - 2024-02-05 15:27:02 --> URI Class Initialized
INFO - 2024-02-05 15:27:02 --> Router Class Initialized
INFO - 2024-02-05 15:27:02 --> Output Class Initialized
INFO - 2024-02-05 15:27:02 --> Security Class Initialized
DEBUG - 2024-02-05 15:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:27:02 --> Input Class Initialized
INFO - 2024-02-05 15:27:02 --> Language Class Initialized
INFO - 2024-02-05 15:27:02 --> Loader Class Initialized
INFO - 2024-02-05 15:27:02 --> Helper loaded: url_helper
INFO - 2024-02-05 15:27:02 --> Helper loaded: file_helper
INFO - 2024-02-05 15:27:02 --> Helper loaded: security_helper
INFO - 2024-02-05 15:27:02 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:27:02 --> Database Driver Class Initialized
INFO - 2024-02-05 15:27:02 --> Email Class Initialized
DEBUG - 2024-02-05 15:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:27:02 --> Helper loaded: form_helper
INFO - 2024-02-05 15:27:02 --> Form Validation Class Initialized
INFO - 2024-02-05 15:27:02 --> Controller Class Initialized
INFO - 2024-02-05 15:27:02 --> Model "User_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:27:02 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:27:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 15:27:02 --> Severity: error --> Exception: File http://localhost/simba/assets/simba.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-05 15:27:04 --> Config Class Initialized
INFO - 2024-02-05 15:27:04 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:27:04 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:27:04 --> Utf8 Class Initialized
INFO - 2024-02-05 15:27:04 --> URI Class Initialized
INFO - 2024-02-05 15:27:04 --> Router Class Initialized
INFO - 2024-02-05 15:27:04 --> Output Class Initialized
INFO - 2024-02-05 15:27:04 --> Security Class Initialized
DEBUG - 2024-02-05 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:27:04 --> Input Class Initialized
INFO - 2024-02-05 15:27:04 --> Language Class Initialized
INFO - 2024-02-05 15:27:04 --> Loader Class Initialized
INFO - 2024-02-05 15:27:04 --> Helper loaded: url_helper
INFO - 2024-02-05 15:27:04 --> Helper loaded: file_helper
INFO - 2024-02-05 15:27:04 --> Helper loaded: security_helper
INFO - 2024-02-05 15:27:04 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:27:04 --> Database Driver Class Initialized
INFO - 2024-02-05 15:27:04 --> Email Class Initialized
DEBUG - 2024-02-05 15:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:27:04 --> Helper loaded: form_helper
INFO - 2024-02-05 15:27:04 --> Form Validation Class Initialized
INFO - 2024-02-05 15:27:04 --> Controller Class Initialized
INFO - 2024-02-05 15:27:04 --> Model "User_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:27:04 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 15:27:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 15:27:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 15:27:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 15:27:04 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-05 15:27:04 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 15:27:04 --> Final output sent to browser
DEBUG - 2024-02-05 15:27:04 --> Total execution time: 0.0624
INFO - 2024-02-05 15:36:09 --> Config Class Initialized
INFO - 2024-02-05 15:36:09 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:36:09 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:36:09 --> Utf8 Class Initialized
INFO - 2024-02-05 15:36:09 --> URI Class Initialized
INFO - 2024-02-05 15:36:09 --> Router Class Initialized
INFO - 2024-02-05 15:36:09 --> Output Class Initialized
INFO - 2024-02-05 15:36:09 --> Security Class Initialized
DEBUG - 2024-02-05 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:36:09 --> Input Class Initialized
INFO - 2024-02-05 15:36:09 --> Language Class Initialized
INFO - 2024-02-05 15:36:09 --> Loader Class Initialized
INFO - 2024-02-05 15:36:09 --> Helper loaded: url_helper
INFO - 2024-02-05 15:36:09 --> Helper loaded: file_helper
INFO - 2024-02-05 15:36:09 --> Helper loaded: security_helper
INFO - 2024-02-05 15:36:09 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:36:09 --> Database Driver Class Initialized
INFO - 2024-02-05 15:36:09 --> Email Class Initialized
DEBUG - 2024-02-05 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:36:09 --> Helper loaded: form_helper
INFO - 2024-02-05 15:36:09 --> Form Validation Class Initialized
INFO - 2024-02-05 15:36:09 --> Controller Class Initialized
INFO - 2024-02-05 15:36:09 --> Model "User_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:36:09 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:36:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-02-05 15:36:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-02-05 15:36:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-02-05 15:36:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-02-05 15:36:09 --> File loaded: C:\xampp\htdocs\simba\application\views\report/cetakfaktur.php
INFO - 2024-02-05 15:36:09 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-02-05 15:36:09 --> Final output sent to browser
DEBUG - 2024-02-05 15:36:09 --> Total execution time: 0.1014
INFO - 2024-02-05 15:36:10 --> Config Class Initialized
INFO - 2024-02-05 15:36:10 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:36:10 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:36:10 --> Utf8 Class Initialized
INFO - 2024-02-05 15:36:10 --> URI Class Initialized
INFO - 2024-02-05 15:36:10 --> Router Class Initialized
INFO - 2024-02-05 15:36:10 --> Output Class Initialized
INFO - 2024-02-05 15:36:10 --> Security Class Initialized
DEBUG - 2024-02-05 15:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:36:10 --> Input Class Initialized
INFO - 2024-02-05 15:36:10 --> Language Class Initialized
INFO - 2024-02-05 15:36:10 --> Loader Class Initialized
INFO - 2024-02-05 15:36:10 --> Helper loaded: url_helper
INFO - 2024-02-05 15:36:10 --> Helper loaded: file_helper
INFO - 2024-02-05 15:36:10 --> Helper loaded: security_helper
INFO - 2024-02-05 15:36:10 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:36:10 --> Database Driver Class Initialized
INFO - 2024-02-05 15:36:10 --> Email Class Initialized
DEBUG - 2024-02-05 15:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:36:10 --> Helper loaded: form_helper
INFO - 2024-02-05 15:36:10 --> Form Validation Class Initialized
INFO - 2024-02-05 15:36:10 --> Controller Class Initialized
INFO - 2024-02-05 15:36:10 --> Model "User_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:36:10 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:36:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 15:36:10 --> Severity: error --> Exception: File http://localhost/simba/assets/simba.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
INFO - 2024-02-05 15:40:54 --> Config Class Initialized
INFO - 2024-02-05 15:40:54 --> Hooks Class Initialized
DEBUG - 2024-02-05 15:40:54 --> UTF-8 Support Enabled
INFO - 2024-02-05 15:40:54 --> Utf8 Class Initialized
INFO - 2024-02-05 15:40:54 --> URI Class Initialized
INFO - 2024-02-05 15:40:54 --> Router Class Initialized
INFO - 2024-02-05 15:40:54 --> Output Class Initialized
INFO - 2024-02-05 15:40:54 --> Security Class Initialized
DEBUG - 2024-02-05 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-05 15:40:54 --> Input Class Initialized
INFO - 2024-02-05 15:40:54 --> Language Class Initialized
INFO - 2024-02-05 15:40:54 --> Loader Class Initialized
INFO - 2024-02-05 15:40:54 --> Helper loaded: url_helper
INFO - 2024-02-05 15:40:54 --> Helper loaded: file_helper
INFO - 2024-02-05 15:40:54 --> Helper loaded: security_helper
INFO - 2024-02-05 15:40:54 --> Helper loaded: wpu_helper
INFO - 2024-02-05 15:40:54 --> Database Driver Class Initialized
INFO - 2024-02-05 15:40:54 --> Email Class Initialized
DEBUG - 2024-02-05 15:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-02-05 15:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-05 15:40:54 --> Helper loaded: form_helper
INFO - 2024-02-05 15:40:54 --> Form Validation Class Initialized
INFO - 2024-02-05 15:40:54 --> Controller Class Initialized
INFO - 2024-02-05 15:40:54 --> Model "User_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Permintaan_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Faktur_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Pesanan_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Supplier_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-02-05 15:40:54 --> Model "Jenis_model" initialized
DEBUG - 2024-02-05 15:40:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-02-05 15:40:54 --> Severity: error --> Exception: File http://localhost/simba/assets/simba.png not found! C:\xampp\htdocs\simba\application\third_party\PHPExcel\PHPExcel\Worksheet\Drawing.php 111
