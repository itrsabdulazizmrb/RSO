<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-28 07:58:52 --> Config Class Initialized
INFO - 2024-11-28 07:58:52 --> Hooks Class Initialized
DEBUG - 2024-11-28 07:58:52 --> UTF-8 Support Enabled
INFO - 2024-11-28 07:58:52 --> Utf8 Class Initialized
INFO - 2024-11-28 07:58:52 --> URI Class Initialized
DEBUG - 2024-11-28 07:58:52 --> No URI present. Default controller set.
INFO - 2024-11-28 07:58:52 --> Router Class Initialized
INFO - 2024-11-28 07:58:52 --> Output Class Initialized
INFO - 2024-11-28 07:58:52 --> Security Class Initialized
DEBUG - 2024-11-28 07:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-28 07:58:52 --> Input Class Initialized
INFO - 2024-11-28 07:58:52 --> Language Class Initialized
INFO - 2024-11-28 07:58:52 --> Loader Class Initialized
INFO - 2024-11-28 07:58:52 --> Helper loaded: url_helper
INFO - 2024-11-28 07:58:52 --> Helper loaded: file_helper
INFO - 2024-11-28 07:58:52 --> Helper loaded: security_helper
INFO - 2024-11-28 07:58:52 --> Helper loaded: wpu_helper
INFO - 2024-11-28 07:58:52 --> Database Driver Class Initialized
ERROR - 2024-11-28 07:58:59 --> Unable to connect to the database
INFO - 2024-11-28 07:58:59 --> Language file loaded: language/english/db_lang.php
