<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-07 00:11:45 --> Config Class Initialized
INFO - 2024-09-07 00:11:45 --> Hooks Class Initialized
DEBUG - 2024-09-07 00:11:45 --> UTF-8 Support Enabled
INFO - 2024-09-07 00:11:45 --> Utf8 Class Initialized
INFO - 2024-09-07 00:11:45 --> URI Class Initialized
DEBUG - 2024-09-07 00:11:45 --> No URI present. Default controller set.
INFO - 2024-09-07 00:11:45 --> Router Class Initialized
INFO - 2024-09-07 00:11:45 --> Output Class Initialized
INFO - 2024-09-07 00:11:45 --> Security Class Initialized
DEBUG - 2024-09-07 00:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 00:11:45 --> Input Class Initialized
INFO - 2024-09-07 00:11:45 --> Language Class Initialized
INFO - 2024-09-07 00:11:45 --> Loader Class Initialized
INFO - 2024-09-07 00:11:45 --> Helper loaded: url_helper
INFO - 2024-09-07 00:11:45 --> Helper loaded: file_helper
INFO - 2024-09-07 00:11:45 --> Helper loaded: security_helper
INFO - 2024-09-07 00:11:45 --> Helper loaded: wpu_helper
INFO - 2024-09-07 00:11:45 --> Database Driver Class Initialized
INFO - 2024-09-07 00:11:45 --> Email Class Initialized
DEBUG - 2024-09-07 00:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 00:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 00:11:45 --> Helper loaded: form_helper
INFO - 2024-09-07 00:11:45 --> Form Validation Class Initialized
INFO - 2024-09-07 00:11:45 --> Controller Class Initialized
DEBUG - 2024-09-07 00:11:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 00:11:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 00:11:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 00:11:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 00:11:45 --> Final output sent to browser
DEBUG - 2024-09-07 00:11:45 --> Total execution time: 0.2158
INFO - 2024-09-07 00:41:52 --> Config Class Initialized
INFO - 2024-09-07 00:41:52 --> Hooks Class Initialized
DEBUG - 2024-09-07 00:41:52 --> UTF-8 Support Enabled
INFO - 2024-09-07 00:41:52 --> Utf8 Class Initialized
INFO - 2024-09-07 00:41:52 --> URI Class Initialized
DEBUG - 2024-09-07 00:41:52 --> No URI present. Default controller set.
INFO - 2024-09-07 00:41:52 --> Router Class Initialized
INFO - 2024-09-07 00:41:52 --> Output Class Initialized
INFO - 2024-09-07 00:41:52 --> Security Class Initialized
DEBUG - 2024-09-07 00:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 00:41:52 --> Input Class Initialized
INFO - 2024-09-07 00:41:52 --> Language Class Initialized
INFO - 2024-09-07 00:41:52 --> Loader Class Initialized
INFO - 2024-09-07 00:41:52 --> Helper loaded: url_helper
INFO - 2024-09-07 00:41:52 --> Helper loaded: file_helper
INFO - 2024-09-07 00:41:52 --> Helper loaded: security_helper
INFO - 2024-09-07 00:41:52 --> Helper loaded: wpu_helper
INFO - 2024-09-07 00:41:52 --> Database Driver Class Initialized
INFO - 2024-09-07 00:41:52 --> Email Class Initialized
DEBUG - 2024-09-07 00:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 00:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 00:41:52 --> Helper loaded: form_helper
INFO - 2024-09-07 00:41:52 --> Form Validation Class Initialized
INFO - 2024-09-07 00:41:52 --> Controller Class Initialized
DEBUG - 2024-09-07 00:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 00:41:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 00:41:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 00:41:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 00:41:52 --> Final output sent to browser
DEBUG - 2024-09-07 00:41:52 --> Total execution time: 0.2205
INFO - 2024-09-07 01:13:05 --> Config Class Initialized
INFO - 2024-09-07 01:13:05 --> Hooks Class Initialized
DEBUG - 2024-09-07 01:13:05 --> UTF-8 Support Enabled
INFO - 2024-09-07 01:13:05 --> Utf8 Class Initialized
INFO - 2024-09-07 01:13:05 --> URI Class Initialized
DEBUG - 2024-09-07 01:13:05 --> No URI present. Default controller set.
INFO - 2024-09-07 01:13:05 --> Router Class Initialized
INFO - 2024-09-07 01:13:05 --> Output Class Initialized
INFO - 2024-09-07 01:13:05 --> Security Class Initialized
DEBUG - 2024-09-07 01:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 01:13:05 --> Input Class Initialized
INFO - 2024-09-07 01:13:05 --> Language Class Initialized
INFO - 2024-09-07 01:13:05 --> Loader Class Initialized
INFO - 2024-09-07 01:13:05 --> Helper loaded: url_helper
INFO - 2024-09-07 01:13:05 --> Helper loaded: file_helper
INFO - 2024-09-07 01:13:05 --> Helper loaded: security_helper
INFO - 2024-09-07 01:13:05 --> Helper loaded: wpu_helper
INFO - 2024-09-07 01:13:05 --> Database Driver Class Initialized
INFO - 2024-09-07 01:13:06 --> Email Class Initialized
DEBUG - 2024-09-07 01:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 01:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 01:13:06 --> Helper loaded: form_helper
INFO - 2024-09-07 01:13:06 --> Form Validation Class Initialized
INFO - 2024-09-07 01:13:06 --> Controller Class Initialized
DEBUG - 2024-09-07 01:13:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 01:13:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 01:13:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 01:13:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 01:13:06 --> Final output sent to browser
DEBUG - 2024-09-07 01:13:06 --> Total execution time: 0.2443
INFO - 2024-09-07 01:44:16 --> Config Class Initialized
INFO - 2024-09-07 01:44:16 --> Hooks Class Initialized
DEBUG - 2024-09-07 01:44:16 --> UTF-8 Support Enabled
INFO - 2024-09-07 01:44:16 --> Utf8 Class Initialized
INFO - 2024-09-07 01:44:16 --> URI Class Initialized
DEBUG - 2024-09-07 01:44:16 --> No URI present. Default controller set.
INFO - 2024-09-07 01:44:16 --> Router Class Initialized
INFO - 2024-09-07 01:44:16 --> Output Class Initialized
INFO - 2024-09-07 01:44:16 --> Security Class Initialized
DEBUG - 2024-09-07 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 01:44:16 --> Input Class Initialized
INFO - 2024-09-07 01:44:16 --> Language Class Initialized
INFO - 2024-09-07 01:44:16 --> Loader Class Initialized
INFO - 2024-09-07 01:44:16 --> Helper loaded: url_helper
INFO - 2024-09-07 01:44:16 --> Helper loaded: file_helper
INFO - 2024-09-07 01:44:16 --> Helper loaded: security_helper
INFO - 2024-09-07 01:44:16 --> Helper loaded: wpu_helper
INFO - 2024-09-07 01:44:16 --> Database Driver Class Initialized
INFO - 2024-09-07 01:44:16 --> Email Class Initialized
DEBUG - 2024-09-07 01:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 01:44:16 --> Helper loaded: form_helper
INFO - 2024-09-07 01:44:16 --> Form Validation Class Initialized
INFO - 2024-09-07 01:44:16 --> Controller Class Initialized
DEBUG - 2024-09-07 01:44:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 01:44:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 01:44:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 01:44:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 01:44:16 --> Final output sent to browser
DEBUG - 2024-09-07 01:44:16 --> Total execution time: 0.2354
INFO - 2024-09-07 02:12:12 --> Config Class Initialized
INFO - 2024-09-07 02:12:12 --> Hooks Class Initialized
DEBUG - 2024-09-07 02:12:12 --> UTF-8 Support Enabled
INFO - 2024-09-07 02:12:12 --> Utf8 Class Initialized
INFO - 2024-09-07 02:12:12 --> URI Class Initialized
DEBUG - 2024-09-07 02:12:12 --> No URI present. Default controller set.
INFO - 2024-09-07 02:12:12 --> Router Class Initialized
INFO - 2024-09-07 02:12:12 --> Output Class Initialized
INFO - 2024-09-07 02:12:12 --> Security Class Initialized
DEBUG - 2024-09-07 02:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 02:12:12 --> Input Class Initialized
INFO - 2024-09-07 02:12:12 --> Language Class Initialized
INFO - 2024-09-07 02:12:12 --> Loader Class Initialized
INFO - 2024-09-07 02:12:12 --> Helper loaded: url_helper
INFO - 2024-09-07 02:12:12 --> Helper loaded: file_helper
INFO - 2024-09-07 02:12:12 --> Helper loaded: security_helper
INFO - 2024-09-07 02:12:12 --> Helper loaded: wpu_helper
INFO - 2024-09-07 02:12:12 --> Database Driver Class Initialized
INFO - 2024-09-07 02:12:12 --> Email Class Initialized
DEBUG - 2024-09-07 02:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 02:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 02:12:12 --> Helper loaded: form_helper
INFO - 2024-09-07 02:12:12 --> Form Validation Class Initialized
INFO - 2024-09-07 02:12:12 --> Controller Class Initialized
DEBUG - 2024-09-07 02:12:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 02:12:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 02:12:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 02:12:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 02:12:12 --> Final output sent to browser
DEBUG - 2024-09-07 02:12:12 --> Total execution time: 0.2227
INFO - 2024-09-07 02:15:32 --> Config Class Initialized
INFO - 2024-09-07 02:15:32 --> Hooks Class Initialized
DEBUG - 2024-09-07 02:15:32 --> UTF-8 Support Enabled
INFO - 2024-09-07 02:15:32 --> Utf8 Class Initialized
INFO - 2024-09-07 02:15:32 --> URI Class Initialized
DEBUG - 2024-09-07 02:15:32 --> No URI present. Default controller set.
INFO - 2024-09-07 02:15:32 --> Router Class Initialized
INFO - 2024-09-07 02:15:32 --> Output Class Initialized
INFO - 2024-09-07 02:15:32 --> Security Class Initialized
DEBUG - 2024-09-07 02:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 02:15:32 --> Input Class Initialized
INFO - 2024-09-07 02:15:32 --> Language Class Initialized
INFO - 2024-09-07 02:15:32 --> Loader Class Initialized
INFO - 2024-09-07 02:15:32 --> Helper loaded: url_helper
INFO - 2024-09-07 02:15:32 --> Helper loaded: file_helper
INFO - 2024-09-07 02:15:32 --> Helper loaded: security_helper
INFO - 2024-09-07 02:15:32 --> Helper loaded: wpu_helper
INFO - 2024-09-07 02:15:32 --> Database Driver Class Initialized
INFO - 2024-09-07 02:15:32 --> Email Class Initialized
DEBUG - 2024-09-07 02:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 02:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 02:15:32 --> Helper loaded: form_helper
INFO - 2024-09-07 02:15:32 --> Form Validation Class Initialized
INFO - 2024-09-07 02:15:32 --> Controller Class Initialized
DEBUG - 2024-09-07 02:15:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 02:15:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 02:15:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 02:15:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 02:15:32 --> Final output sent to browser
DEBUG - 2024-09-07 02:15:32 --> Total execution time: 0.2151
INFO - 2024-09-07 02:43:37 --> Config Class Initialized
INFO - 2024-09-07 02:43:37 --> Hooks Class Initialized
DEBUG - 2024-09-07 02:43:37 --> UTF-8 Support Enabled
INFO - 2024-09-07 02:43:37 --> Utf8 Class Initialized
INFO - 2024-09-07 02:43:37 --> URI Class Initialized
DEBUG - 2024-09-07 02:43:37 --> No URI present. Default controller set.
INFO - 2024-09-07 02:43:37 --> Router Class Initialized
INFO - 2024-09-07 02:43:37 --> Output Class Initialized
INFO - 2024-09-07 02:43:37 --> Security Class Initialized
DEBUG - 2024-09-07 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 02:43:37 --> Input Class Initialized
INFO - 2024-09-07 02:43:37 --> Language Class Initialized
INFO - 2024-09-07 02:43:37 --> Loader Class Initialized
INFO - 2024-09-07 02:43:37 --> Helper loaded: url_helper
INFO - 2024-09-07 02:43:37 --> Helper loaded: file_helper
INFO - 2024-09-07 02:43:37 --> Helper loaded: security_helper
INFO - 2024-09-07 02:43:37 --> Helper loaded: wpu_helper
INFO - 2024-09-07 02:43:37 --> Database Driver Class Initialized
INFO - 2024-09-07 02:43:37 --> Email Class Initialized
DEBUG - 2024-09-07 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 02:43:37 --> Helper loaded: form_helper
INFO - 2024-09-07 02:43:37 --> Form Validation Class Initialized
INFO - 2024-09-07 02:43:37 --> Controller Class Initialized
DEBUG - 2024-09-07 02:43:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 02:43:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 02:43:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 02:43:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 02:43:37 --> Final output sent to browser
DEBUG - 2024-09-07 02:43:37 --> Total execution time: 0.2390
INFO - 2024-09-07 03:14:53 --> Config Class Initialized
INFO - 2024-09-07 03:14:53 --> Hooks Class Initialized
DEBUG - 2024-09-07 03:14:53 --> UTF-8 Support Enabled
INFO - 2024-09-07 03:14:53 --> Utf8 Class Initialized
INFO - 2024-09-07 03:14:53 --> URI Class Initialized
DEBUG - 2024-09-07 03:14:53 --> No URI present. Default controller set.
INFO - 2024-09-07 03:14:53 --> Router Class Initialized
INFO - 2024-09-07 03:14:53 --> Output Class Initialized
INFO - 2024-09-07 03:14:53 --> Security Class Initialized
DEBUG - 2024-09-07 03:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 03:14:53 --> Input Class Initialized
INFO - 2024-09-07 03:14:53 --> Language Class Initialized
INFO - 2024-09-07 03:14:53 --> Loader Class Initialized
INFO - 2024-09-07 03:14:53 --> Helper loaded: url_helper
INFO - 2024-09-07 03:14:53 --> Helper loaded: file_helper
INFO - 2024-09-07 03:14:53 --> Helper loaded: security_helper
INFO - 2024-09-07 03:14:53 --> Helper loaded: wpu_helper
INFO - 2024-09-07 03:14:53 --> Database Driver Class Initialized
INFO - 2024-09-07 03:14:53 --> Email Class Initialized
DEBUG - 2024-09-07 03:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 03:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 03:14:54 --> Helper loaded: form_helper
INFO - 2024-09-07 03:14:54 --> Form Validation Class Initialized
INFO - 2024-09-07 03:14:54 --> Controller Class Initialized
DEBUG - 2024-09-07 03:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 03:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 03:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 03:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 03:14:54 --> Final output sent to browser
DEBUG - 2024-09-07 03:14:54 --> Total execution time: 0.2444
INFO - 2024-09-07 03:44:30 --> Config Class Initialized
INFO - 2024-09-07 03:44:30 --> Hooks Class Initialized
DEBUG - 2024-09-07 03:44:30 --> UTF-8 Support Enabled
INFO - 2024-09-07 03:44:30 --> Utf8 Class Initialized
INFO - 2024-09-07 03:44:30 --> URI Class Initialized
DEBUG - 2024-09-07 03:44:30 --> No URI present. Default controller set.
INFO - 2024-09-07 03:44:30 --> Router Class Initialized
INFO - 2024-09-07 03:44:30 --> Output Class Initialized
INFO - 2024-09-07 03:44:30 --> Security Class Initialized
DEBUG - 2024-09-07 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 03:44:30 --> Input Class Initialized
INFO - 2024-09-07 03:44:30 --> Language Class Initialized
INFO - 2024-09-07 03:44:30 --> Loader Class Initialized
INFO - 2024-09-07 03:44:30 --> Helper loaded: url_helper
INFO - 2024-09-07 03:44:30 --> Helper loaded: file_helper
INFO - 2024-09-07 03:44:30 --> Helper loaded: security_helper
INFO - 2024-09-07 03:44:30 --> Helper loaded: wpu_helper
INFO - 2024-09-07 03:44:30 --> Database Driver Class Initialized
INFO - 2024-09-07 03:44:30 --> Email Class Initialized
DEBUG - 2024-09-07 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 03:44:30 --> Helper loaded: form_helper
INFO - 2024-09-07 03:44:30 --> Form Validation Class Initialized
INFO - 2024-09-07 03:44:30 --> Controller Class Initialized
DEBUG - 2024-09-07 03:44:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 03:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 03:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 03:44:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 03:44:30 --> Final output sent to browser
DEBUG - 2024-09-07 03:44:30 --> Total execution time: 0.2367
INFO - 2024-09-07 04:13:17 --> Config Class Initialized
INFO - 2024-09-07 04:13:17 --> Hooks Class Initialized
DEBUG - 2024-09-07 04:13:17 --> UTF-8 Support Enabled
INFO - 2024-09-07 04:13:17 --> Utf8 Class Initialized
INFO - 2024-09-07 04:13:17 --> URI Class Initialized
DEBUG - 2024-09-07 04:13:17 --> No URI present. Default controller set.
INFO - 2024-09-07 04:13:17 --> Router Class Initialized
INFO - 2024-09-07 04:13:17 --> Output Class Initialized
INFO - 2024-09-07 04:13:17 --> Security Class Initialized
DEBUG - 2024-09-07 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 04:13:17 --> Input Class Initialized
INFO - 2024-09-07 04:13:17 --> Language Class Initialized
INFO - 2024-09-07 04:13:17 --> Loader Class Initialized
INFO - 2024-09-07 04:13:17 --> Helper loaded: url_helper
INFO - 2024-09-07 04:13:17 --> Helper loaded: file_helper
INFO - 2024-09-07 04:13:17 --> Helper loaded: security_helper
INFO - 2024-09-07 04:13:17 --> Helper loaded: wpu_helper
INFO - 2024-09-07 04:13:17 --> Database Driver Class Initialized
INFO - 2024-09-07 04:13:17 --> Email Class Initialized
DEBUG - 2024-09-07 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 04:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 04:13:17 --> Helper loaded: form_helper
INFO - 2024-09-07 04:13:17 --> Form Validation Class Initialized
INFO - 2024-09-07 04:13:17 --> Controller Class Initialized
DEBUG - 2024-09-07 04:13:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 04:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 04:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 04:13:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 04:13:17 --> Final output sent to browser
DEBUG - 2024-09-07 04:13:17 --> Total execution time: 0.2290
INFO - 2024-09-07 04:44:34 --> Config Class Initialized
INFO - 2024-09-07 04:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-07 04:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-07 04:44:34 --> Utf8 Class Initialized
INFO - 2024-09-07 04:44:34 --> URI Class Initialized
DEBUG - 2024-09-07 04:44:34 --> No URI present. Default controller set.
INFO - 2024-09-07 04:44:34 --> Router Class Initialized
INFO - 2024-09-07 04:44:34 --> Output Class Initialized
INFO - 2024-09-07 04:44:34 --> Security Class Initialized
DEBUG - 2024-09-07 04:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 04:44:34 --> Input Class Initialized
INFO - 2024-09-07 04:44:34 --> Language Class Initialized
INFO - 2024-09-07 04:44:34 --> Loader Class Initialized
INFO - 2024-09-07 04:44:34 --> Helper loaded: url_helper
INFO - 2024-09-07 04:44:34 --> Helper loaded: file_helper
INFO - 2024-09-07 04:44:34 --> Helper loaded: security_helper
INFO - 2024-09-07 04:44:34 --> Helper loaded: wpu_helper
INFO - 2024-09-07 04:44:34 --> Database Driver Class Initialized
INFO - 2024-09-07 04:44:34 --> Email Class Initialized
DEBUG - 2024-09-07 04:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 04:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 04:44:34 --> Helper loaded: form_helper
INFO - 2024-09-07 04:44:34 --> Form Validation Class Initialized
INFO - 2024-09-07 04:44:34 --> Controller Class Initialized
DEBUG - 2024-09-07 04:44:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 04:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 04:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 04:44:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 04:44:34 --> Final output sent to browser
DEBUG - 2024-09-07 04:44:34 --> Total execution time: 0.4764
INFO - 2024-09-07 05:13:14 --> Config Class Initialized
INFO - 2024-09-07 05:13:14 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:13:14 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:13:14 --> Utf8 Class Initialized
INFO - 2024-09-07 05:13:14 --> URI Class Initialized
DEBUG - 2024-09-07 05:13:14 --> No URI present. Default controller set.
INFO - 2024-09-07 05:13:14 --> Router Class Initialized
INFO - 2024-09-07 05:13:14 --> Output Class Initialized
INFO - 2024-09-07 05:13:14 --> Security Class Initialized
DEBUG - 2024-09-07 05:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:13:14 --> Input Class Initialized
INFO - 2024-09-07 05:13:14 --> Language Class Initialized
INFO - 2024-09-07 05:13:14 --> Loader Class Initialized
INFO - 2024-09-07 05:13:14 --> Helper loaded: url_helper
INFO - 2024-09-07 05:13:14 --> Helper loaded: file_helper
INFO - 2024-09-07 05:13:14 --> Helper loaded: security_helper
INFO - 2024-09-07 05:13:14 --> Helper loaded: wpu_helper
INFO - 2024-09-07 05:13:14 --> Database Driver Class Initialized
INFO - 2024-09-07 05:13:14 --> Email Class Initialized
DEBUG - 2024-09-07 05:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 05:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:13:14 --> Helper loaded: form_helper
INFO - 2024-09-07 05:13:14 --> Form Validation Class Initialized
INFO - 2024-09-07 05:13:14 --> Controller Class Initialized
DEBUG - 2024-09-07 05:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 05:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 05:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 05:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 05:13:14 --> Final output sent to browser
DEBUG - 2024-09-07 05:13:14 --> Total execution time: 0.2290
INFO - 2024-09-07 05:16:10 --> Config Class Initialized
INFO - 2024-09-07 05:16:10 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:16:10 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:16:10 --> Utf8 Class Initialized
INFO - 2024-09-07 05:16:10 --> URI Class Initialized
DEBUG - 2024-09-07 05:16:10 --> No URI present. Default controller set.
INFO - 2024-09-07 05:16:10 --> Router Class Initialized
INFO - 2024-09-07 05:16:10 --> Output Class Initialized
INFO - 2024-09-07 05:16:10 --> Security Class Initialized
DEBUG - 2024-09-07 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:16:10 --> Input Class Initialized
INFO - 2024-09-07 05:16:10 --> Language Class Initialized
INFO - 2024-09-07 05:16:10 --> Loader Class Initialized
INFO - 2024-09-07 05:16:10 --> Helper loaded: url_helper
INFO - 2024-09-07 05:16:10 --> Helper loaded: file_helper
INFO - 2024-09-07 05:16:10 --> Helper loaded: security_helper
INFO - 2024-09-07 05:16:10 --> Helper loaded: wpu_helper
INFO - 2024-09-07 05:16:10 --> Database Driver Class Initialized
INFO - 2024-09-07 05:16:10 --> Email Class Initialized
DEBUG - 2024-09-07 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:16:10 --> Helper loaded: form_helper
INFO - 2024-09-07 05:16:10 --> Form Validation Class Initialized
INFO - 2024-09-07 05:16:10 --> Controller Class Initialized
DEBUG - 2024-09-07 05:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 05:16:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 05:16:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 05:16:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 05:16:10 --> Final output sent to browser
DEBUG - 2024-09-07 05:16:10 --> Total execution time: 0.2374
INFO - 2024-09-07 05:43:38 --> Config Class Initialized
INFO - 2024-09-07 05:43:38 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:43:38 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:43:38 --> Utf8 Class Initialized
INFO - 2024-09-07 05:43:38 --> URI Class Initialized
DEBUG - 2024-09-07 05:43:38 --> No URI present. Default controller set.
INFO - 2024-09-07 05:43:38 --> Router Class Initialized
INFO - 2024-09-07 05:43:38 --> Output Class Initialized
INFO - 2024-09-07 05:43:38 --> Security Class Initialized
DEBUG - 2024-09-07 05:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:43:38 --> Input Class Initialized
INFO - 2024-09-07 05:43:38 --> Language Class Initialized
INFO - 2024-09-07 05:43:38 --> Loader Class Initialized
INFO - 2024-09-07 05:43:38 --> Helper loaded: url_helper
INFO - 2024-09-07 05:43:38 --> Helper loaded: file_helper
INFO - 2024-09-07 05:43:38 --> Helper loaded: security_helper
INFO - 2024-09-07 05:43:38 --> Helper loaded: wpu_helper
INFO - 2024-09-07 05:43:38 --> Database Driver Class Initialized
INFO - 2024-09-07 05:43:38 --> Email Class Initialized
DEBUG - 2024-09-07 05:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 05:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:43:38 --> Helper loaded: form_helper
INFO - 2024-09-07 05:43:38 --> Form Validation Class Initialized
INFO - 2024-09-07 05:43:38 --> Controller Class Initialized
DEBUG - 2024-09-07 05:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 05:43:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 05:43:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 05:43:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 05:43:38 --> Final output sent to browser
DEBUG - 2024-09-07 05:43:38 --> Total execution time: 0.2399
INFO - 2024-09-07 06:12:22 --> Config Class Initialized
INFO - 2024-09-07 06:12:22 --> Hooks Class Initialized
DEBUG - 2024-09-07 06:12:22 --> UTF-8 Support Enabled
INFO - 2024-09-07 06:12:22 --> Utf8 Class Initialized
INFO - 2024-09-07 06:12:22 --> URI Class Initialized
DEBUG - 2024-09-07 06:12:22 --> No URI present. Default controller set.
INFO - 2024-09-07 06:12:22 --> Router Class Initialized
INFO - 2024-09-07 06:12:22 --> Output Class Initialized
INFO - 2024-09-07 06:12:22 --> Security Class Initialized
DEBUG - 2024-09-07 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 06:12:22 --> Input Class Initialized
INFO - 2024-09-07 06:12:22 --> Language Class Initialized
INFO - 2024-09-07 06:12:22 --> Loader Class Initialized
INFO - 2024-09-07 06:12:22 --> Helper loaded: url_helper
INFO - 2024-09-07 06:12:22 --> Helper loaded: file_helper
INFO - 2024-09-07 06:12:22 --> Helper loaded: security_helper
INFO - 2024-09-07 06:12:22 --> Helper loaded: wpu_helper
INFO - 2024-09-07 06:12:22 --> Database Driver Class Initialized
INFO - 2024-09-07 06:12:22 --> Email Class Initialized
DEBUG - 2024-09-07 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 06:12:22 --> Helper loaded: form_helper
INFO - 2024-09-07 06:12:22 --> Form Validation Class Initialized
INFO - 2024-09-07 06:12:22 --> Controller Class Initialized
DEBUG - 2024-09-07 06:12:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 06:12:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 06:12:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 06:12:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 06:12:22 --> Final output sent to browser
DEBUG - 2024-09-07 06:12:22 --> Total execution time: 0.2227
INFO - 2024-09-07 06:43:07 --> Config Class Initialized
INFO - 2024-09-07 06:43:07 --> Hooks Class Initialized
DEBUG - 2024-09-07 06:43:07 --> UTF-8 Support Enabled
INFO - 2024-09-07 06:43:07 --> Utf8 Class Initialized
INFO - 2024-09-07 06:43:07 --> URI Class Initialized
DEBUG - 2024-09-07 06:43:07 --> No URI present. Default controller set.
INFO - 2024-09-07 06:43:07 --> Router Class Initialized
INFO - 2024-09-07 06:43:07 --> Output Class Initialized
INFO - 2024-09-07 06:43:07 --> Security Class Initialized
DEBUG - 2024-09-07 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 06:43:07 --> Input Class Initialized
INFO - 2024-09-07 06:43:07 --> Language Class Initialized
INFO - 2024-09-07 06:43:07 --> Loader Class Initialized
INFO - 2024-09-07 06:43:07 --> Helper loaded: url_helper
INFO - 2024-09-07 06:43:07 --> Helper loaded: file_helper
INFO - 2024-09-07 06:43:07 --> Helper loaded: security_helper
INFO - 2024-09-07 06:43:07 --> Helper loaded: wpu_helper
INFO - 2024-09-07 06:43:07 --> Database Driver Class Initialized
INFO - 2024-09-07 06:43:07 --> Email Class Initialized
DEBUG - 2024-09-07 06:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 06:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 06:43:07 --> Helper loaded: form_helper
INFO - 2024-09-07 06:43:07 --> Form Validation Class Initialized
INFO - 2024-09-07 06:43:07 --> Controller Class Initialized
DEBUG - 2024-09-07 06:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 06:43:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 06:43:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 06:43:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 06:43:07 --> Final output sent to browser
DEBUG - 2024-09-07 06:43:07 --> Total execution time: 0.2490
INFO - 2024-09-07 07:13:38 --> Config Class Initialized
INFO - 2024-09-07 07:13:38 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:13:38 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:13:38 --> Utf8 Class Initialized
INFO - 2024-09-07 07:13:38 --> URI Class Initialized
DEBUG - 2024-09-07 07:13:38 --> No URI present. Default controller set.
INFO - 2024-09-07 07:13:38 --> Router Class Initialized
INFO - 2024-09-07 07:13:38 --> Output Class Initialized
INFO - 2024-09-07 07:13:38 --> Security Class Initialized
DEBUG - 2024-09-07 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:13:38 --> Input Class Initialized
INFO - 2024-09-07 07:13:38 --> Language Class Initialized
INFO - 2024-09-07 07:13:38 --> Loader Class Initialized
INFO - 2024-09-07 07:13:38 --> Helper loaded: url_helper
INFO - 2024-09-07 07:13:38 --> Helper loaded: file_helper
INFO - 2024-09-07 07:13:38 --> Helper loaded: security_helper
INFO - 2024-09-07 07:13:38 --> Helper loaded: wpu_helper
INFO - 2024-09-07 07:13:38 --> Database Driver Class Initialized
INFO - 2024-09-07 07:13:39 --> Email Class Initialized
DEBUG - 2024-09-07 07:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:13:39 --> Helper loaded: form_helper
INFO - 2024-09-07 07:13:39 --> Form Validation Class Initialized
INFO - 2024-09-07 07:13:39 --> Controller Class Initialized
DEBUG - 2024-09-07 07:13:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 07:13:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 07:13:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 07:13:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 07:13:39 --> Final output sent to browser
DEBUG - 2024-09-07 07:13:39 --> Total execution time: 0.4821
INFO - 2024-09-07 07:37:43 --> Config Class Initialized
INFO - 2024-09-07 07:37:43 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:37:43 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:37:43 --> Utf8 Class Initialized
INFO - 2024-09-07 07:37:43 --> URI Class Initialized
DEBUG - 2024-09-07 07:37:43 --> No URI present. Default controller set.
INFO - 2024-09-07 07:37:43 --> Router Class Initialized
INFO - 2024-09-07 07:37:43 --> Output Class Initialized
INFO - 2024-09-07 07:37:43 --> Security Class Initialized
DEBUG - 2024-09-07 07:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:37:43 --> Input Class Initialized
INFO - 2024-09-07 07:37:43 --> Language Class Initialized
INFO - 2024-09-07 07:37:43 --> Loader Class Initialized
INFO - 2024-09-07 07:37:43 --> Helper loaded: url_helper
INFO - 2024-09-07 07:37:43 --> Helper loaded: file_helper
INFO - 2024-09-07 07:37:43 --> Helper loaded: security_helper
INFO - 2024-09-07 07:37:43 --> Helper loaded: wpu_helper
INFO - 2024-09-07 07:37:43 --> Database Driver Class Initialized
INFO - 2024-09-07 07:37:43 --> Email Class Initialized
DEBUG - 2024-09-07 07:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:37:43 --> Helper loaded: form_helper
INFO - 2024-09-07 07:37:43 --> Form Validation Class Initialized
INFO - 2024-09-07 07:37:43 --> Controller Class Initialized
DEBUG - 2024-09-07 07:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 07:37:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 07:37:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 07:37:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 07:37:43 --> Final output sent to browser
DEBUG - 2024-09-07 07:37:43 --> Total execution time: 0.2213
INFO - 2024-09-07 07:38:03 --> Config Class Initialized
INFO - 2024-09-07 07:38:03 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:38:03 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:38:03 --> Utf8 Class Initialized
INFO - 2024-09-07 07:38:03 --> URI Class Initialized
INFO - 2024-09-07 07:38:03 --> Router Class Initialized
INFO - 2024-09-07 07:38:03 --> Output Class Initialized
INFO - 2024-09-07 07:38:03 --> Security Class Initialized
DEBUG - 2024-09-07 07:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:38:03 --> Input Class Initialized
INFO - 2024-09-07 07:38:03 --> Language Class Initialized
INFO - 2024-09-07 07:38:03 --> Loader Class Initialized
INFO - 2024-09-07 07:38:03 --> Helper loaded: url_helper
INFO - 2024-09-07 07:38:03 --> Helper loaded: file_helper
INFO - 2024-09-07 07:38:03 --> Helper loaded: security_helper
INFO - 2024-09-07 07:38:03 --> Helper loaded: wpu_helper
INFO - 2024-09-07 07:38:03 --> Database Driver Class Initialized
INFO - 2024-09-07 07:38:03 --> Email Class Initialized
DEBUG - 2024-09-07 07:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:38:03 --> Helper loaded: form_helper
INFO - 2024-09-07 07:38:03 --> Form Validation Class Initialized
INFO - 2024-09-07 07:38:03 --> Controller Class Initialized
DEBUG - 2024-09-07 07:38:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 07:38:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-07 07:38:04 --> Config Class Initialized
INFO - 2024-09-07 07:38:04 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:38:04 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:38:04 --> Utf8 Class Initialized
INFO - 2024-09-07 07:38:04 --> URI Class Initialized
INFO - 2024-09-07 07:38:04 --> Router Class Initialized
INFO - 2024-09-07 07:38:04 --> Output Class Initialized
INFO - 2024-09-07 07:38:04 --> Security Class Initialized
DEBUG - 2024-09-07 07:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:38:04 --> Input Class Initialized
INFO - 2024-09-07 07:38:04 --> Language Class Initialized
INFO - 2024-09-07 07:38:04 --> Loader Class Initialized
INFO - 2024-09-07 07:38:04 --> Helper loaded: url_helper
INFO - 2024-09-07 07:38:04 --> Helper loaded: file_helper
INFO - 2024-09-07 07:38:04 --> Helper loaded: security_helper
INFO - 2024-09-07 07:38:04 --> Helper loaded: wpu_helper
INFO - 2024-09-07 07:38:04 --> Database Driver Class Initialized
INFO - 2024-09-07 07:38:04 --> Email Class Initialized
DEBUG - 2024-09-07 07:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:38:04 --> Helper loaded: form_helper
INFO - 2024-09-07 07:38:04 --> Form Validation Class Initialized
INFO - 2024-09-07 07:38:04 --> Controller Class Initialized
INFO - 2024-09-07 07:38:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 07:38:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 07:38:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 07:38:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 07:38:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 07:38:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 07:38:05 --> Final output sent to browser
DEBUG - 2024-09-07 07:38:05 --> Total execution time: 0.9674
INFO - 2024-09-07 07:43:23 --> Config Class Initialized
INFO - 2024-09-07 07:43:23 --> Hooks Class Initialized
DEBUG - 2024-09-07 07:43:23 --> UTF-8 Support Enabled
INFO - 2024-09-07 07:43:23 --> Utf8 Class Initialized
INFO - 2024-09-07 07:43:23 --> URI Class Initialized
DEBUG - 2024-09-07 07:43:23 --> No URI present. Default controller set.
INFO - 2024-09-07 07:43:23 --> Router Class Initialized
INFO - 2024-09-07 07:43:23 --> Output Class Initialized
INFO - 2024-09-07 07:43:23 --> Security Class Initialized
DEBUG - 2024-09-07 07:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 07:43:23 --> Input Class Initialized
INFO - 2024-09-07 07:43:23 --> Language Class Initialized
INFO - 2024-09-07 07:43:23 --> Loader Class Initialized
INFO - 2024-09-07 07:43:23 --> Helper loaded: url_helper
INFO - 2024-09-07 07:43:23 --> Helper loaded: file_helper
INFO - 2024-09-07 07:43:23 --> Helper loaded: security_helper
INFO - 2024-09-07 07:43:23 --> Helper loaded: wpu_helper
INFO - 2024-09-07 07:43:23 --> Database Driver Class Initialized
INFO - 2024-09-07 07:43:23 --> Email Class Initialized
DEBUG - 2024-09-07 07:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 07:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 07:43:23 --> Helper loaded: form_helper
INFO - 2024-09-07 07:43:23 --> Form Validation Class Initialized
INFO - 2024-09-07 07:43:23 --> Controller Class Initialized
DEBUG - 2024-09-07 07:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 07:43:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 07:43:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 07:43:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 07:43:23 --> Final output sent to browser
DEBUG - 2024-09-07 07:43:23 --> Total execution time: 0.2221
INFO - 2024-09-07 08:12:19 --> Config Class Initialized
INFO - 2024-09-07 08:12:19 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:12:19 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:12:19 --> Utf8 Class Initialized
INFO - 2024-09-07 08:12:19 --> URI Class Initialized
DEBUG - 2024-09-07 08:12:19 --> No URI present. Default controller set.
INFO - 2024-09-07 08:12:19 --> Router Class Initialized
INFO - 2024-09-07 08:12:19 --> Output Class Initialized
INFO - 2024-09-07 08:12:19 --> Security Class Initialized
DEBUG - 2024-09-07 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:12:19 --> Input Class Initialized
INFO - 2024-09-07 08:12:19 --> Language Class Initialized
INFO - 2024-09-07 08:12:19 --> Loader Class Initialized
INFO - 2024-09-07 08:12:19 --> Helper loaded: url_helper
INFO - 2024-09-07 08:12:19 --> Helper loaded: file_helper
INFO - 2024-09-07 08:12:19 --> Helper loaded: security_helper
INFO - 2024-09-07 08:12:19 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:12:19 --> Database Driver Class Initialized
INFO - 2024-09-07 08:12:20 --> Email Class Initialized
DEBUG - 2024-09-07 08:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:12:20 --> Helper loaded: form_helper
INFO - 2024-09-07 08:12:20 --> Form Validation Class Initialized
INFO - 2024-09-07 08:12:20 --> Controller Class Initialized
DEBUG - 2024-09-07 08:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 08:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 08:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 08:12:20 --> Final output sent to browser
DEBUG - 2024-09-07 08:12:20 --> Total execution time: 0.2244
INFO - 2024-09-07 08:16:19 --> Config Class Initialized
INFO - 2024-09-07 08:16:19 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:16:19 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:16:19 --> Utf8 Class Initialized
INFO - 2024-09-07 08:16:19 --> URI Class Initialized
DEBUG - 2024-09-07 08:16:19 --> No URI present. Default controller set.
INFO - 2024-09-07 08:16:19 --> Router Class Initialized
INFO - 2024-09-07 08:16:19 --> Output Class Initialized
INFO - 2024-09-07 08:16:19 --> Security Class Initialized
DEBUG - 2024-09-07 08:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:16:19 --> Input Class Initialized
INFO - 2024-09-07 08:16:19 --> Language Class Initialized
INFO - 2024-09-07 08:16:19 --> Loader Class Initialized
INFO - 2024-09-07 08:16:19 --> Helper loaded: url_helper
INFO - 2024-09-07 08:16:19 --> Helper loaded: file_helper
INFO - 2024-09-07 08:16:19 --> Helper loaded: security_helper
INFO - 2024-09-07 08:16:19 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:16:19 --> Database Driver Class Initialized
INFO - 2024-09-07 08:16:19 --> Email Class Initialized
DEBUG - 2024-09-07 08:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:16:19 --> Helper loaded: form_helper
INFO - 2024-09-07 08:16:19 --> Form Validation Class Initialized
INFO - 2024-09-07 08:16:19 --> Controller Class Initialized
DEBUG - 2024-09-07 08:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:16:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 08:16:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 08:16:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 08:16:19 --> Final output sent to browser
DEBUG - 2024-09-07 08:16:19 --> Total execution time: 0.2227
INFO - 2024-09-07 08:26:17 --> Config Class Initialized
INFO - 2024-09-07 08:26:17 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:26:17 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:26:17 --> Utf8 Class Initialized
INFO - 2024-09-07 08:26:17 --> URI Class Initialized
INFO - 2024-09-07 08:26:17 --> Router Class Initialized
INFO - 2024-09-07 08:26:17 --> Output Class Initialized
INFO - 2024-09-07 08:26:17 --> Security Class Initialized
DEBUG - 2024-09-07 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:26:17 --> Input Class Initialized
INFO - 2024-09-07 08:26:17 --> Language Class Initialized
INFO - 2024-09-07 08:26:17 --> Loader Class Initialized
INFO - 2024-09-07 08:26:17 --> Helper loaded: url_helper
INFO - 2024-09-07 08:26:17 --> Helper loaded: file_helper
INFO - 2024-09-07 08:26:17 --> Helper loaded: security_helper
INFO - 2024-09-07 08:26:17 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:26:17 --> Database Driver Class Initialized
INFO - 2024-09-07 08:26:18 --> Email Class Initialized
DEBUG - 2024-09-07 08:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:26:18 --> Helper loaded: form_helper
INFO - 2024-09-07 08:26:18 --> Form Validation Class Initialized
INFO - 2024-09-07 08:26:18 --> Controller Class Initialized
INFO - 2024-09-07 08:26:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 08:26:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:26:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 08:26:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 08:26:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-07 08:26:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 08:26:18 --> Final output sent to browser
DEBUG - 2024-09-07 08:26:18 --> Total execution time: 0.7223
INFO - 2024-09-07 08:26:30 --> Config Class Initialized
INFO - 2024-09-07 08:26:30 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:26:30 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:26:30 --> Utf8 Class Initialized
INFO - 2024-09-07 08:26:30 --> URI Class Initialized
INFO - 2024-09-07 08:26:30 --> Router Class Initialized
INFO - 2024-09-07 08:26:30 --> Output Class Initialized
INFO - 2024-09-07 08:26:30 --> Security Class Initialized
DEBUG - 2024-09-07 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:26:30 --> Input Class Initialized
INFO - 2024-09-07 08:26:30 --> Language Class Initialized
INFO - 2024-09-07 08:26:30 --> Loader Class Initialized
INFO - 2024-09-07 08:26:30 --> Helper loaded: url_helper
INFO - 2024-09-07 08:26:30 --> Helper loaded: file_helper
INFO - 2024-09-07 08:26:30 --> Helper loaded: security_helper
INFO - 2024-09-07 08:26:30 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:26:30 --> Database Driver Class Initialized
INFO - 2024-09-07 08:26:30 --> Email Class Initialized
DEBUG - 2024-09-07 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:26:30 --> Helper loaded: form_helper
INFO - 2024-09-07 08:26:30 --> Form Validation Class Initialized
INFO - 2024-09-07 08:26:30 --> Controller Class Initialized
INFO - 2024-09-07 08:26:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 08:26:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:26:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 08:26:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 08:26:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-07 08:26:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 08:26:31 --> Final output sent to browser
DEBUG - 2024-09-07 08:26:31 --> Total execution time: 0.6912
INFO - 2024-09-07 08:26:32 --> Config Class Initialized
INFO - 2024-09-07 08:26:32 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:26:32 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:26:32 --> Utf8 Class Initialized
INFO - 2024-09-07 08:26:32 --> URI Class Initialized
INFO - 2024-09-07 08:26:32 --> Router Class Initialized
INFO - 2024-09-07 08:26:32 --> Output Class Initialized
INFO - 2024-09-07 08:26:32 --> Security Class Initialized
DEBUG - 2024-09-07 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:26:32 --> Input Class Initialized
INFO - 2024-09-07 08:26:32 --> Language Class Initialized
INFO - 2024-09-07 08:26:32 --> Loader Class Initialized
INFO - 2024-09-07 08:26:32 --> Helper loaded: url_helper
INFO - 2024-09-07 08:26:32 --> Helper loaded: file_helper
INFO - 2024-09-07 08:26:32 --> Helper loaded: security_helper
INFO - 2024-09-07 08:26:32 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:26:32 --> Database Driver Class Initialized
INFO - 2024-09-07 08:26:32 --> Email Class Initialized
DEBUG - 2024-09-07 08:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:26:32 --> Helper loaded: form_helper
INFO - 2024-09-07 08:26:32 --> Form Validation Class Initialized
INFO - 2024-09-07 08:26:32 --> Controller Class Initialized
INFO - 2024-09-07 08:26:32 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 08:26:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:26:33 --> Final output sent to browser
DEBUG - 2024-09-07 08:26:33 --> Total execution time: 1.0553
INFO - 2024-09-07 08:43:52 --> Config Class Initialized
INFO - 2024-09-07 08:43:52 --> Hooks Class Initialized
DEBUG - 2024-09-07 08:43:52 --> UTF-8 Support Enabled
INFO - 2024-09-07 08:43:52 --> Utf8 Class Initialized
INFO - 2024-09-07 08:43:52 --> URI Class Initialized
DEBUG - 2024-09-07 08:43:52 --> No URI present. Default controller set.
INFO - 2024-09-07 08:43:52 --> Router Class Initialized
INFO - 2024-09-07 08:43:52 --> Output Class Initialized
INFO - 2024-09-07 08:43:52 --> Security Class Initialized
DEBUG - 2024-09-07 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 08:43:52 --> Input Class Initialized
INFO - 2024-09-07 08:43:52 --> Language Class Initialized
INFO - 2024-09-07 08:43:52 --> Loader Class Initialized
INFO - 2024-09-07 08:43:52 --> Helper loaded: url_helper
INFO - 2024-09-07 08:43:52 --> Helper loaded: file_helper
INFO - 2024-09-07 08:43:52 --> Helper loaded: security_helper
INFO - 2024-09-07 08:43:52 --> Helper loaded: wpu_helper
INFO - 2024-09-07 08:43:52 --> Database Driver Class Initialized
INFO - 2024-09-07 08:43:53 --> Email Class Initialized
DEBUG - 2024-09-07 08:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 08:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 08:43:53 --> Helper loaded: form_helper
INFO - 2024-09-07 08:43:53 --> Form Validation Class Initialized
INFO - 2024-09-07 08:43:53 --> Controller Class Initialized
DEBUG - 2024-09-07 08:43:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 08:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 08:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 08:43:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 08:43:53 --> Final output sent to browser
DEBUG - 2024-09-07 08:43:53 --> Total execution time: 0.2241
INFO - 2024-09-07 09:16:33 --> Config Class Initialized
INFO - 2024-09-07 09:16:33 --> Hooks Class Initialized
DEBUG - 2024-09-07 09:16:33 --> UTF-8 Support Enabled
INFO - 2024-09-07 09:16:33 --> Utf8 Class Initialized
INFO - 2024-09-07 09:16:33 --> URI Class Initialized
DEBUG - 2024-09-07 09:16:33 --> No URI present. Default controller set.
INFO - 2024-09-07 09:16:33 --> Router Class Initialized
INFO - 2024-09-07 09:16:33 --> Output Class Initialized
INFO - 2024-09-07 09:16:33 --> Security Class Initialized
DEBUG - 2024-09-07 09:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 09:16:33 --> Input Class Initialized
INFO - 2024-09-07 09:16:33 --> Language Class Initialized
INFO - 2024-09-07 09:16:33 --> Loader Class Initialized
INFO - 2024-09-07 09:16:33 --> Helper loaded: url_helper
INFO - 2024-09-07 09:16:33 --> Helper loaded: file_helper
INFO - 2024-09-07 09:16:33 --> Helper loaded: security_helper
INFO - 2024-09-07 09:16:33 --> Helper loaded: wpu_helper
INFO - 2024-09-07 09:16:33 --> Database Driver Class Initialized
INFO - 2024-09-07 09:16:33 --> Email Class Initialized
DEBUG - 2024-09-07 09:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 09:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 09:16:33 --> Helper loaded: form_helper
INFO - 2024-09-07 09:16:33 --> Form Validation Class Initialized
INFO - 2024-09-07 09:16:33 --> Controller Class Initialized
DEBUG - 2024-09-07 09:16:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 09:16:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 09:16:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 09:16:33 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 09:16:33 --> Final output sent to browser
DEBUG - 2024-09-07 09:16:33 --> Total execution time: 0.2244
INFO - 2024-09-07 09:44:36 --> Config Class Initialized
INFO - 2024-09-07 09:44:36 --> Hooks Class Initialized
DEBUG - 2024-09-07 09:44:36 --> UTF-8 Support Enabled
INFO - 2024-09-07 09:44:36 --> Utf8 Class Initialized
INFO - 2024-09-07 09:44:36 --> URI Class Initialized
DEBUG - 2024-09-07 09:44:36 --> No URI present. Default controller set.
INFO - 2024-09-07 09:44:36 --> Router Class Initialized
INFO - 2024-09-07 09:44:36 --> Output Class Initialized
INFO - 2024-09-07 09:44:36 --> Security Class Initialized
DEBUG - 2024-09-07 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 09:44:36 --> Input Class Initialized
INFO - 2024-09-07 09:44:36 --> Language Class Initialized
INFO - 2024-09-07 09:44:36 --> Loader Class Initialized
INFO - 2024-09-07 09:44:36 --> Helper loaded: url_helper
INFO - 2024-09-07 09:44:36 --> Helper loaded: file_helper
INFO - 2024-09-07 09:44:36 --> Helper loaded: security_helper
INFO - 2024-09-07 09:44:36 --> Helper loaded: wpu_helper
INFO - 2024-09-07 09:44:36 --> Database Driver Class Initialized
INFO - 2024-09-07 09:44:37 --> Email Class Initialized
DEBUG - 2024-09-07 09:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 09:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 09:44:37 --> Helper loaded: form_helper
INFO - 2024-09-07 09:44:37 --> Form Validation Class Initialized
INFO - 2024-09-07 09:44:37 --> Controller Class Initialized
DEBUG - 2024-09-07 09:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 09:44:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 09:44:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 09:44:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 09:44:37 --> Final output sent to browser
DEBUG - 2024-09-07 09:44:37 --> Total execution time: 0.2205
INFO - 2024-09-07 10:12:10 --> Config Class Initialized
INFO - 2024-09-07 10:12:10 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:12:10 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:12:10 --> Utf8 Class Initialized
INFO - 2024-09-07 10:12:10 --> URI Class Initialized
DEBUG - 2024-09-07 10:12:10 --> No URI present. Default controller set.
INFO - 2024-09-07 10:12:10 --> Router Class Initialized
INFO - 2024-09-07 10:12:10 --> Output Class Initialized
INFO - 2024-09-07 10:12:10 --> Security Class Initialized
DEBUG - 2024-09-07 10:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:12:10 --> Input Class Initialized
INFO - 2024-09-07 10:12:10 --> Language Class Initialized
INFO - 2024-09-07 10:12:10 --> Loader Class Initialized
INFO - 2024-09-07 10:12:10 --> Helper loaded: url_helper
INFO - 2024-09-07 10:12:10 --> Helper loaded: file_helper
INFO - 2024-09-07 10:12:10 --> Helper loaded: security_helper
INFO - 2024-09-07 10:12:10 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:12:10 --> Database Driver Class Initialized
INFO - 2024-09-07 10:12:10 --> Email Class Initialized
DEBUG - 2024-09-07 10:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:12:10 --> Helper loaded: form_helper
INFO - 2024-09-07 10:12:10 --> Form Validation Class Initialized
INFO - 2024-09-07 10:12:10 --> Controller Class Initialized
DEBUG - 2024-09-07 10:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:12:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 10:12:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 10:12:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 10:12:10 --> Final output sent to browser
DEBUG - 2024-09-07 10:12:10 --> Total execution time: 0.2202
INFO - 2024-09-07 10:34:46 --> Config Class Initialized
INFO - 2024-09-07 10:34:46 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:34:46 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:34:46 --> Utf8 Class Initialized
INFO - 2024-09-07 10:34:46 --> URI Class Initialized
INFO - 2024-09-07 10:34:46 --> Router Class Initialized
INFO - 2024-09-07 10:34:46 --> Output Class Initialized
INFO - 2024-09-07 10:34:46 --> Security Class Initialized
DEBUG - 2024-09-07 10:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:34:46 --> Input Class Initialized
INFO - 2024-09-07 10:34:46 --> Language Class Initialized
INFO - 2024-09-07 10:34:46 --> Loader Class Initialized
INFO - 2024-09-07 10:34:46 --> Helper loaded: url_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: file_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: security_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:34:46 --> Database Driver Class Initialized
INFO - 2024-09-07 10:34:46 --> Email Class Initialized
DEBUG - 2024-09-07 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:34:46 --> Helper loaded: form_helper
INFO - 2024-09-07 10:34:46 --> Form Validation Class Initialized
INFO - 2024-09-07 10:34:46 --> Controller Class Initialized
INFO - 2024-09-07 10:34:46 --> Config Class Initialized
INFO - 2024-09-07 10:34:46 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:34:46 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:34:46 --> Utf8 Class Initialized
INFO - 2024-09-07 10:34:46 --> URI Class Initialized
INFO - 2024-09-07 10:34:46 --> Router Class Initialized
INFO - 2024-09-07 10:34:46 --> Output Class Initialized
INFO - 2024-09-07 10:34:46 --> Security Class Initialized
DEBUG - 2024-09-07 10:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:34:46 --> Input Class Initialized
INFO - 2024-09-07 10:34:46 --> Language Class Initialized
INFO - 2024-09-07 10:34:46 --> Loader Class Initialized
INFO - 2024-09-07 10:34:46 --> Helper loaded: url_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: file_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: security_helper
INFO - 2024-09-07 10:34:46 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:34:46 --> Database Driver Class Initialized
INFO - 2024-09-07 10:34:46 --> Email Class Initialized
DEBUG - 2024-09-07 10:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:34:46 --> Helper loaded: form_helper
INFO - 2024-09-07 10:34:46 --> Form Validation Class Initialized
INFO - 2024-09-07 10:34:46 --> Controller Class Initialized
DEBUG - 2024-09-07 10:34:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:34:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 10:34:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 10:34:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 10:34:46 --> Final output sent to browser
DEBUG - 2024-09-07 10:34:46 --> Total execution time: 0.2100
INFO - 2024-09-07 10:34:48 --> Config Class Initialized
INFO - 2024-09-07 10:34:48 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:34:48 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:34:48 --> Utf8 Class Initialized
INFO - 2024-09-07 10:34:48 --> URI Class Initialized
INFO - 2024-09-07 10:34:48 --> Router Class Initialized
INFO - 2024-09-07 10:34:48 --> Output Class Initialized
INFO - 2024-09-07 10:34:48 --> Security Class Initialized
DEBUG - 2024-09-07 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:34:48 --> Input Class Initialized
INFO - 2024-09-07 10:34:48 --> Language Class Initialized
INFO - 2024-09-07 10:34:48 --> Loader Class Initialized
INFO - 2024-09-07 10:34:48 --> Helper loaded: url_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: file_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: security_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:34:48 --> Database Driver Class Initialized
INFO - 2024-09-07 10:34:48 --> Email Class Initialized
DEBUG - 2024-09-07 10:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:34:48 --> Helper loaded: form_helper
INFO - 2024-09-07 10:34:48 --> Form Validation Class Initialized
INFO - 2024-09-07 10:34:48 --> Controller Class Initialized
DEBUG - 2024-09-07 10:34:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:34:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-07 10:34:48 --> Config Class Initialized
INFO - 2024-09-07 10:34:48 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:34:48 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:34:48 --> Utf8 Class Initialized
INFO - 2024-09-07 10:34:48 --> URI Class Initialized
INFO - 2024-09-07 10:34:48 --> Router Class Initialized
INFO - 2024-09-07 10:34:48 --> Output Class Initialized
INFO - 2024-09-07 10:34:48 --> Security Class Initialized
DEBUG - 2024-09-07 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:34:48 --> Input Class Initialized
INFO - 2024-09-07 10:34:48 --> Language Class Initialized
INFO - 2024-09-07 10:34:48 --> Loader Class Initialized
INFO - 2024-09-07 10:34:48 --> Helper loaded: url_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: file_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: security_helper
INFO - 2024-09-07 10:34:48 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:34:48 --> Database Driver Class Initialized
INFO - 2024-09-07 10:34:48 --> Email Class Initialized
DEBUG - 2024-09-07 10:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:34:48 --> Helper loaded: form_helper
INFO - 2024-09-07 10:34:48 --> Form Validation Class Initialized
INFO - 2024-09-07 10:34:48 --> Controller Class Initialized
INFO - 2024-09-07 10:34:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 10:34:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:34:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 10:34:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 10:34:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 10:34:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 10:34:49 --> Final output sent to browser
DEBUG - 2024-09-07 10:34:49 --> Total execution time: 0.6057
INFO - 2024-09-07 10:36:41 --> Config Class Initialized
INFO - 2024-09-07 10:36:41 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:36:41 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:36:41 --> Utf8 Class Initialized
INFO - 2024-09-07 10:36:41 --> URI Class Initialized
INFO - 2024-09-07 10:36:41 --> Router Class Initialized
INFO - 2024-09-07 10:36:41 --> Output Class Initialized
INFO - 2024-09-07 10:36:41 --> Security Class Initialized
DEBUG - 2024-09-07 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:36:41 --> Input Class Initialized
INFO - 2024-09-07 10:36:41 --> Language Class Initialized
INFO - 2024-09-07 10:36:41 --> Loader Class Initialized
INFO - 2024-09-07 10:36:41 --> Helper loaded: url_helper
INFO - 2024-09-07 10:36:41 --> Helper loaded: file_helper
INFO - 2024-09-07 10:36:41 --> Helper loaded: security_helper
INFO - 2024-09-07 10:36:41 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:36:41 --> Database Driver Class Initialized
INFO - 2024-09-07 10:36:41 --> Email Class Initialized
DEBUG - 2024-09-07 10:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:36:41 --> Helper loaded: form_helper
INFO - 2024-09-07 10:36:41 --> Form Validation Class Initialized
INFO - 2024-09-07 10:36:41 --> Controller Class Initialized
INFO - 2024-09-07 10:36:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 10:36:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 10:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 10:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 10:36:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 10:36:42 --> Final output sent to browser
DEBUG - 2024-09-07 10:36:42 --> Total execution time: 0.6039
INFO - 2024-09-07 10:36:56 --> Config Class Initialized
INFO - 2024-09-07 10:36:56 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:36:56 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:36:56 --> Utf8 Class Initialized
INFO - 2024-09-07 10:36:56 --> URI Class Initialized
INFO - 2024-09-07 10:36:56 --> Router Class Initialized
INFO - 2024-09-07 10:36:56 --> Output Class Initialized
INFO - 2024-09-07 10:36:56 --> Security Class Initialized
DEBUG - 2024-09-07 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:36:56 --> Input Class Initialized
INFO - 2024-09-07 10:36:56 --> Language Class Initialized
INFO - 2024-09-07 10:36:56 --> Loader Class Initialized
INFO - 2024-09-07 10:36:56 --> Helper loaded: url_helper
INFO - 2024-09-07 10:36:56 --> Helper loaded: file_helper
INFO - 2024-09-07 10:36:56 --> Helper loaded: security_helper
INFO - 2024-09-07 10:36:56 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:36:56 --> Database Driver Class Initialized
INFO - 2024-09-07 10:36:56 --> Email Class Initialized
DEBUG - 2024-09-07 10:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:36:56 --> Helper loaded: form_helper
INFO - 2024-09-07 10:36:56 --> Form Validation Class Initialized
INFO - 2024-09-07 10:36:56 --> Controller Class Initialized
INFO - 2024-09-07 10:36:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 10:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 10:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 10:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 10:36:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 10:36:56 --> Final output sent to browser
DEBUG - 2024-09-07 10:36:56 --> Total execution time: 0.6202
INFO - 2024-09-07 10:37:20 --> Config Class Initialized
INFO - 2024-09-07 10:37:20 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:37:20 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:37:20 --> Utf8 Class Initialized
INFO - 2024-09-07 10:37:20 --> URI Class Initialized
INFO - 2024-09-07 10:37:20 --> Router Class Initialized
INFO - 2024-09-07 10:37:20 --> Output Class Initialized
INFO - 2024-09-07 10:37:20 --> Security Class Initialized
DEBUG - 2024-09-07 10:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:37:20 --> Input Class Initialized
INFO - 2024-09-07 10:37:20 --> Language Class Initialized
INFO - 2024-09-07 10:37:20 --> Loader Class Initialized
INFO - 2024-09-07 10:37:20 --> Helper loaded: url_helper
INFO - 2024-09-07 10:37:20 --> Helper loaded: file_helper
INFO - 2024-09-07 10:37:20 --> Helper loaded: security_helper
INFO - 2024-09-07 10:37:20 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:37:20 --> Database Driver Class Initialized
INFO - 2024-09-07 10:37:20 --> Email Class Initialized
DEBUG - 2024-09-07 10:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:37:20 --> Helper loaded: form_helper
INFO - 2024-09-07 10:37:20 --> Form Validation Class Initialized
INFO - 2024-09-07 10:37:20 --> Controller Class Initialized
INFO - 2024-09-07 10:37:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 10:37:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:37:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 10:37:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 10:37:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 10:37:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 10:37:20 --> Final output sent to browser
DEBUG - 2024-09-07 10:37:20 --> Total execution time: 0.6168
INFO - 2024-09-07 10:44:01 --> Config Class Initialized
INFO - 2024-09-07 10:44:01 --> Hooks Class Initialized
DEBUG - 2024-09-07 10:44:01 --> UTF-8 Support Enabled
INFO - 2024-09-07 10:44:01 --> Utf8 Class Initialized
INFO - 2024-09-07 10:44:01 --> URI Class Initialized
DEBUG - 2024-09-07 10:44:01 --> No URI present. Default controller set.
INFO - 2024-09-07 10:44:01 --> Router Class Initialized
INFO - 2024-09-07 10:44:01 --> Output Class Initialized
INFO - 2024-09-07 10:44:01 --> Security Class Initialized
DEBUG - 2024-09-07 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 10:44:01 --> Input Class Initialized
INFO - 2024-09-07 10:44:01 --> Language Class Initialized
INFO - 2024-09-07 10:44:01 --> Loader Class Initialized
INFO - 2024-09-07 10:44:01 --> Helper loaded: url_helper
INFO - 2024-09-07 10:44:01 --> Helper loaded: file_helper
INFO - 2024-09-07 10:44:01 --> Helper loaded: security_helper
INFO - 2024-09-07 10:44:01 --> Helper loaded: wpu_helper
INFO - 2024-09-07 10:44:01 --> Database Driver Class Initialized
INFO - 2024-09-07 10:44:01 --> Email Class Initialized
DEBUG - 2024-09-07 10:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 10:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 10:44:01 --> Helper loaded: form_helper
INFO - 2024-09-07 10:44:01 --> Form Validation Class Initialized
INFO - 2024-09-07 10:44:01 --> Controller Class Initialized
DEBUG - 2024-09-07 10:44:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 10:44:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 10:44:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 10:44:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 10:44:01 --> Final output sent to browser
DEBUG - 2024-09-07 10:44:01 --> Total execution time: 0.2207
INFO - 2024-09-07 11:13:00 --> Config Class Initialized
INFO - 2024-09-07 11:13:00 --> Hooks Class Initialized
DEBUG - 2024-09-07 11:13:00 --> UTF-8 Support Enabled
INFO - 2024-09-07 11:13:00 --> Utf8 Class Initialized
INFO - 2024-09-07 11:13:00 --> URI Class Initialized
DEBUG - 2024-09-07 11:13:00 --> No URI present. Default controller set.
INFO - 2024-09-07 11:13:00 --> Router Class Initialized
INFO - 2024-09-07 11:13:00 --> Output Class Initialized
INFO - 2024-09-07 11:13:00 --> Security Class Initialized
DEBUG - 2024-09-07 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 11:13:00 --> Input Class Initialized
INFO - 2024-09-07 11:13:00 --> Language Class Initialized
INFO - 2024-09-07 11:13:00 --> Loader Class Initialized
INFO - 2024-09-07 11:13:00 --> Helper loaded: url_helper
INFO - 2024-09-07 11:13:00 --> Helper loaded: file_helper
INFO - 2024-09-07 11:13:00 --> Helper loaded: security_helper
INFO - 2024-09-07 11:13:00 --> Helper loaded: wpu_helper
INFO - 2024-09-07 11:13:00 --> Database Driver Class Initialized
INFO - 2024-09-07 11:13:01 --> Email Class Initialized
DEBUG - 2024-09-07 11:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 11:13:01 --> Helper loaded: form_helper
INFO - 2024-09-07 11:13:01 --> Form Validation Class Initialized
INFO - 2024-09-07 11:13:01 --> Controller Class Initialized
DEBUG - 2024-09-07 11:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 11:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 11:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 11:13:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 11:13:01 --> Final output sent to browser
DEBUG - 2024-09-07 11:13:01 --> Total execution time: 0.2304
INFO - 2024-09-07 11:17:13 --> Config Class Initialized
INFO - 2024-09-07 11:17:13 --> Hooks Class Initialized
DEBUG - 2024-09-07 11:17:13 --> UTF-8 Support Enabled
INFO - 2024-09-07 11:17:13 --> Utf8 Class Initialized
INFO - 2024-09-07 11:17:13 --> URI Class Initialized
DEBUG - 2024-09-07 11:17:13 --> No URI present. Default controller set.
INFO - 2024-09-07 11:17:13 --> Router Class Initialized
INFO - 2024-09-07 11:17:13 --> Output Class Initialized
INFO - 2024-09-07 11:17:13 --> Security Class Initialized
DEBUG - 2024-09-07 11:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 11:17:13 --> Input Class Initialized
INFO - 2024-09-07 11:17:13 --> Language Class Initialized
INFO - 2024-09-07 11:17:13 --> Loader Class Initialized
INFO - 2024-09-07 11:17:13 --> Helper loaded: url_helper
INFO - 2024-09-07 11:17:13 --> Helper loaded: file_helper
INFO - 2024-09-07 11:17:13 --> Helper loaded: security_helper
INFO - 2024-09-07 11:17:13 --> Helper loaded: wpu_helper
INFO - 2024-09-07 11:17:13 --> Database Driver Class Initialized
INFO - 2024-09-07 11:17:13 --> Email Class Initialized
DEBUG - 2024-09-07 11:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 11:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 11:17:13 --> Helper loaded: form_helper
INFO - 2024-09-07 11:17:13 --> Form Validation Class Initialized
INFO - 2024-09-07 11:17:13 --> Controller Class Initialized
DEBUG - 2024-09-07 11:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 11:17:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 11:17:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 11:17:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 11:17:13 --> Final output sent to browser
DEBUG - 2024-09-07 11:17:13 --> Total execution time: 0.2525
INFO - 2024-09-07 11:43:57 --> Config Class Initialized
INFO - 2024-09-07 11:43:57 --> Hooks Class Initialized
DEBUG - 2024-09-07 11:43:57 --> UTF-8 Support Enabled
INFO - 2024-09-07 11:43:57 --> Utf8 Class Initialized
INFO - 2024-09-07 11:43:57 --> URI Class Initialized
DEBUG - 2024-09-07 11:43:57 --> No URI present. Default controller set.
INFO - 2024-09-07 11:43:57 --> Router Class Initialized
INFO - 2024-09-07 11:43:57 --> Output Class Initialized
INFO - 2024-09-07 11:43:57 --> Security Class Initialized
DEBUG - 2024-09-07 11:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 11:43:57 --> Input Class Initialized
INFO - 2024-09-07 11:43:57 --> Language Class Initialized
INFO - 2024-09-07 11:43:57 --> Loader Class Initialized
INFO - 2024-09-07 11:43:57 --> Helper loaded: url_helper
INFO - 2024-09-07 11:43:57 --> Helper loaded: file_helper
INFO - 2024-09-07 11:43:57 --> Helper loaded: security_helper
INFO - 2024-09-07 11:43:57 --> Helper loaded: wpu_helper
INFO - 2024-09-07 11:43:57 --> Database Driver Class Initialized
INFO - 2024-09-07 11:43:58 --> Email Class Initialized
DEBUG - 2024-09-07 11:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 11:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 11:43:58 --> Helper loaded: form_helper
INFO - 2024-09-07 11:43:58 --> Form Validation Class Initialized
INFO - 2024-09-07 11:43:58 --> Controller Class Initialized
DEBUG - 2024-09-07 11:43:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 11:43:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 11:43:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 11:43:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 11:43:58 --> Final output sent to browser
DEBUG - 2024-09-07 11:43:58 --> Total execution time: 0.2191
INFO - 2024-09-07 11:44:52 --> Config Class Initialized
INFO - 2024-09-07 11:44:52 --> Hooks Class Initialized
DEBUG - 2024-09-07 11:44:52 --> UTF-8 Support Enabled
INFO - 2024-09-07 11:44:52 --> Utf8 Class Initialized
INFO - 2024-09-07 11:44:52 --> URI Class Initialized
INFO - 2024-09-07 11:44:52 --> Router Class Initialized
INFO - 2024-09-07 11:44:52 --> Output Class Initialized
INFO - 2024-09-07 11:44:52 --> Security Class Initialized
DEBUG - 2024-09-07 11:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 11:44:52 --> Input Class Initialized
INFO - 2024-09-07 11:44:52 --> Language Class Initialized
INFO - 2024-09-07 11:44:52 --> Loader Class Initialized
INFO - 2024-09-07 11:44:52 --> Helper loaded: url_helper
INFO - 2024-09-07 11:44:52 --> Helper loaded: file_helper
INFO - 2024-09-07 11:44:52 --> Helper loaded: security_helper
INFO - 2024-09-07 11:44:52 --> Helper loaded: wpu_helper
INFO - 2024-09-07 11:44:52 --> Database Driver Class Initialized
INFO - 2024-09-07 11:44:52 --> Email Class Initialized
DEBUG - 2024-09-07 11:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 11:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 11:44:52 --> Helper loaded: form_helper
INFO - 2024-09-07 11:44:52 --> Form Validation Class Initialized
INFO - 2024-09-07 11:44:52 --> Controller Class Initialized
INFO - 2024-09-07 11:44:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 11:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 11:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 11:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 11:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-07 11:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 11:44:52 --> Final output sent to browser
DEBUG - 2024-09-07 11:44:52 --> Total execution time: 0.7254
INFO - 2024-09-07 12:11:36 --> Config Class Initialized
INFO - 2024-09-07 12:11:36 --> Hooks Class Initialized
DEBUG - 2024-09-07 12:11:36 --> UTF-8 Support Enabled
INFO - 2024-09-07 12:11:36 --> Utf8 Class Initialized
INFO - 2024-09-07 12:11:36 --> URI Class Initialized
DEBUG - 2024-09-07 12:11:36 --> No URI present. Default controller set.
INFO - 2024-09-07 12:11:36 --> Router Class Initialized
INFO - 2024-09-07 12:11:36 --> Output Class Initialized
INFO - 2024-09-07 12:11:36 --> Security Class Initialized
DEBUG - 2024-09-07 12:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 12:11:36 --> Input Class Initialized
INFO - 2024-09-07 12:11:36 --> Language Class Initialized
INFO - 2024-09-07 12:11:37 --> Loader Class Initialized
INFO - 2024-09-07 12:11:37 --> Helper loaded: url_helper
INFO - 2024-09-07 12:11:37 --> Helper loaded: file_helper
INFO - 2024-09-07 12:11:37 --> Helper loaded: security_helper
INFO - 2024-09-07 12:11:37 --> Helper loaded: wpu_helper
INFO - 2024-09-07 12:11:37 --> Database Driver Class Initialized
INFO - 2024-09-07 12:11:37 --> Email Class Initialized
DEBUG - 2024-09-07 12:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 12:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 12:11:37 --> Helper loaded: form_helper
INFO - 2024-09-07 12:11:37 --> Form Validation Class Initialized
INFO - 2024-09-07 12:11:37 --> Controller Class Initialized
DEBUG - 2024-09-07 12:11:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 12:11:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 12:11:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 12:11:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 12:11:37 --> Final output sent to browser
DEBUG - 2024-09-07 12:11:37 --> Total execution time: 0.4693
INFO - 2024-09-07 12:22:20 --> Config Class Initialized
INFO - 2024-09-07 12:22:20 --> Hooks Class Initialized
DEBUG - 2024-09-07 12:22:20 --> UTF-8 Support Enabled
INFO - 2024-09-07 12:22:20 --> Utf8 Class Initialized
INFO - 2024-09-07 12:22:20 --> URI Class Initialized
INFO - 2024-09-07 12:22:20 --> Router Class Initialized
INFO - 2024-09-07 12:22:20 --> Output Class Initialized
INFO - 2024-09-07 12:22:20 --> Security Class Initialized
DEBUG - 2024-09-07 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 12:22:20 --> Input Class Initialized
INFO - 2024-09-07 12:22:20 --> Language Class Initialized
INFO - 2024-09-07 12:22:20 --> Loader Class Initialized
INFO - 2024-09-07 12:22:20 --> Helper loaded: url_helper
INFO - 2024-09-07 12:22:20 --> Helper loaded: file_helper
INFO - 2024-09-07 12:22:20 --> Helper loaded: security_helper
INFO - 2024-09-07 12:22:20 --> Helper loaded: wpu_helper
INFO - 2024-09-07 12:22:20 --> Database Driver Class Initialized
INFO - 2024-09-07 12:22:20 --> Email Class Initialized
DEBUG - 2024-09-07 12:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 12:22:20 --> Helper loaded: form_helper
INFO - 2024-09-07 12:22:20 --> Form Validation Class Initialized
INFO - 2024-09-07 12:22:20 --> Controller Class Initialized
INFO - 2024-09-07 12:22:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 12:22:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 12:22:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 12:22:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 12:22:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 12:22:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 12:22:21 --> Final output sent to browser
DEBUG - 2024-09-07 12:22:21 --> Total execution time: 0.5898
INFO - 2024-09-07 12:42:48 --> Config Class Initialized
INFO - 2024-09-07 12:42:48 --> Hooks Class Initialized
DEBUG - 2024-09-07 12:42:48 --> UTF-8 Support Enabled
INFO - 2024-09-07 12:42:48 --> Utf8 Class Initialized
INFO - 2024-09-07 12:42:48 --> URI Class Initialized
DEBUG - 2024-09-07 12:42:48 --> No URI present. Default controller set.
INFO - 2024-09-07 12:42:48 --> Router Class Initialized
INFO - 2024-09-07 12:42:48 --> Output Class Initialized
INFO - 2024-09-07 12:42:48 --> Security Class Initialized
DEBUG - 2024-09-07 12:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 12:42:48 --> Input Class Initialized
INFO - 2024-09-07 12:42:48 --> Language Class Initialized
INFO - 2024-09-07 12:42:48 --> Loader Class Initialized
INFO - 2024-09-07 12:42:48 --> Helper loaded: url_helper
INFO - 2024-09-07 12:42:48 --> Helper loaded: file_helper
INFO - 2024-09-07 12:42:48 --> Helper loaded: security_helper
INFO - 2024-09-07 12:42:48 --> Helper loaded: wpu_helper
INFO - 2024-09-07 12:42:48 --> Database Driver Class Initialized
INFO - 2024-09-07 12:42:48 --> Email Class Initialized
DEBUG - 2024-09-07 12:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 12:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 12:42:48 --> Helper loaded: form_helper
INFO - 2024-09-07 12:42:48 --> Form Validation Class Initialized
INFO - 2024-09-07 12:42:48 --> Controller Class Initialized
DEBUG - 2024-09-07 12:42:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 12:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 12:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 12:42:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 12:42:48 --> Final output sent to browser
DEBUG - 2024-09-07 12:42:48 --> Total execution time: 0.2186
INFO - 2024-09-07 13:13:14 --> Config Class Initialized
INFO - 2024-09-07 13:13:14 --> Hooks Class Initialized
DEBUG - 2024-09-07 13:13:14 --> UTF-8 Support Enabled
INFO - 2024-09-07 13:13:14 --> Utf8 Class Initialized
INFO - 2024-09-07 13:13:14 --> URI Class Initialized
DEBUG - 2024-09-07 13:13:14 --> No URI present. Default controller set.
INFO - 2024-09-07 13:13:14 --> Router Class Initialized
INFO - 2024-09-07 13:13:14 --> Output Class Initialized
INFO - 2024-09-07 13:13:14 --> Security Class Initialized
DEBUG - 2024-09-07 13:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 13:13:14 --> Input Class Initialized
INFO - 2024-09-07 13:13:14 --> Language Class Initialized
INFO - 2024-09-07 13:13:14 --> Loader Class Initialized
INFO - 2024-09-07 13:13:14 --> Helper loaded: url_helper
INFO - 2024-09-07 13:13:14 --> Helper loaded: file_helper
INFO - 2024-09-07 13:13:14 --> Helper loaded: security_helper
INFO - 2024-09-07 13:13:14 --> Helper loaded: wpu_helper
INFO - 2024-09-07 13:13:14 --> Database Driver Class Initialized
INFO - 2024-09-07 13:13:14 --> Email Class Initialized
DEBUG - 2024-09-07 13:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 13:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 13:13:14 --> Helper loaded: form_helper
INFO - 2024-09-07 13:13:14 --> Form Validation Class Initialized
INFO - 2024-09-07 13:13:14 --> Controller Class Initialized
DEBUG - 2024-09-07 13:13:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 13:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 13:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 13:13:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 13:13:14 --> Final output sent to browser
DEBUG - 2024-09-07 13:13:14 --> Total execution time: 0.2188
INFO - 2024-09-07 13:24:57 --> Config Class Initialized
INFO - 2024-09-07 13:24:57 --> Hooks Class Initialized
DEBUG - 2024-09-07 13:24:57 --> UTF-8 Support Enabled
INFO - 2024-09-07 13:24:57 --> Utf8 Class Initialized
INFO - 2024-09-07 13:24:57 --> URI Class Initialized
INFO - 2024-09-07 13:24:57 --> Router Class Initialized
INFO - 2024-09-07 13:24:57 --> Output Class Initialized
INFO - 2024-09-07 13:24:57 --> Security Class Initialized
DEBUG - 2024-09-07 13:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 13:24:57 --> Input Class Initialized
INFO - 2024-09-07 13:24:57 --> Language Class Initialized
INFO - 2024-09-07 13:24:57 --> Loader Class Initialized
INFO - 2024-09-07 13:24:57 --> Helper loaded: url_helper
INFO - 2024-09-07 13:24:57 --> Helper loaded: file_helper
INFO - 2024-09-07 13:24:57 --> Helper loaded: security_helper
INFO - 2024-09-07 13:24:57 --> Helper loaded: wpu_helper
INFO - 2024-09-07 13:24:57 --> Database Driver Class Initialized
INFO - 2024-09-07 13:24:58 --> Email Class Initialized
DEBUG - 2024-09-07 13:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 13:24:58 --> Helper loaded: form_helper
INFO - 2024-09-07 13:24:58 --> Form Validation Class Initialized
INFO - 2024-09-07 13:24:58 --> Controller Class Initialized
INFO - 2024-09-07 13:24:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 13:24:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 13:24:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 13:24:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 13:24:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 13:24:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 13:24:58 --> Final output sent to browser
DEBUG - 2024-09-07 13:24:58 --> Total execution time: 0.6512
INFO - 2024-09-07 13:43:24 --> Config Class Initialized
INFO - 2024-09-07 13:43:24 --> Hooks Class Initialized
DEBUG - 2024-09-07 13:43:24 --> UTF-8 Support Enabled
INFO - 2024-09-07 13:43:24 --> Utf8 Class Initialized
INFO - 2024-09-07 13:43:24 --> URI Class Initialized
DEBUG - 2024-09-07 13:43:24 --> No URI present. Default controller set.
INFO - 2024-09-07 13:43:24 --> Router Class Initialized
INFO - 2024-09-07 13:43:24 --> Output Class Initialized
INFO - 2024-09-07 13:43:24 --> Security Class Initialized
DEBUG - 2024-09-07 13:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 13:43:24 --> Input Class Initialized
INFO - 2024-09-07 13:43:24 --> Language Class Initialized
INFO - 2024-09-07 13:43:24 --> Loader Class Initialized
INFO - 2024-09-07 13:43:24 --> Helper loaded: url_helper
INFO - 2024-09-07 13:43:24 --> Helper loaded: file_helper
INFO - 2024-09-07 13:43:24 --> Helper loaded: security_helper
INFO - 2024-09-07 13:43:24 --> Helper loaded: wpu_helper
INFO - 2024-09-07 13:43:24 --> Database Driver Class Initialized
INFO - 2024-09-07 13:43:24 --> Email Class Initialized
DEBUG - 2024-09-07 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 13:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 13:43:24 --> Helper loaded: form_helper
INFO - 2024-09-07 13:43:24 --> Form Validation Class Initialized
INFO - 2024-09-07 13:43:24 --> Controller Class Initialized
DEBUG - 2024-09-07 13:43:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 13:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 13:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 13:43:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 13:43:24 --> Final output sent to browser
DEBUG - 2024-09-07 13:43:24 --> Total execution time: 0.2164
INFO - 2024-09-07 14:13:10 --> Config Class Initialized
INFO - 2024-09-07 14:13:10 --> Hooks Class Initialized
DEBUG - 2024-09-07 14:13:10 --> UTF-8 Support Enabled
INFO - 2024-09-07 14:13:10 --> Utf8 Class Initialized
INFO - 2024-09-07 14:13:10 --> URI Class Initialized
DEBUG - 2024-09-07 14:13:10 --> No URI present. Default controller set.
INFO - 2024-09-07 14:13:10 --> Router Class Initialized
INFO - 2024-09-07 14:13:10 --> Output Class Initialized
INFO - 2024-09-07 14:13:10 --> Security Class Initialized
DEBUG - 2024-09-07 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 14:13:10 --> Input Class Initialized
INFO - 2024-09-07 14:13:10 --> Language Class Initialized
INFO - 2024-09-07 14:13:10 --> Loader Class Initialized
INFO - 2024-09-07 14:13:10 --> Helper loaded: url_helper
INFO - 2024-09-07 14:13:10 --> Helper loaded: file_helper
INFO - 2024-09-07 14:13:10 --> Helper loaded: security_helper
INFO - 2024-09-07 14:13:10 --> Helper loaded: wpu_helper
INFO - 2024-09-07 14:13:10 --> Database Driver Class Initialized
INFO - 2024-09-07 14:13:10 --> Email Class Initialized
DEBUG - 2024-09-07 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 14:13:10 --> Helper loaded: form_helper
INFO - 2024-09-07 14:13:10 --> Form Validation Class Initialized
INFO - 2024-09-07 14:13:10 --> Controller Class Initialized
DEBUG - 2024-09-07 14:13:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 14:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 14:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 14:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 14:13:10 --> Final output sent to browser
DEBUG - 2024-09-07 14:13:10 --> Total execution time: 0.2398
INFO - 2024-09-07 14:17:42 --> Config Class Initialized
INFO - 2024-09-07 14:17:42 --> Hooks Class Initialized
DEBUG - 2024-09-07 14:17:42 --> UTF-8 Support Enabled
INFO - 2024-09-07 14:17:42 --> Utf8 Class Initialized
INFO - 2024-09-07 14:17:42 --> URI Class Initialized
DEBUG - 2024-09-07 14:17:42 --> No URI present. Default controller set.
INFO - 2024-09-07 14:17:42 --> Router Class Initialized
INFO - 2024-09-07 14:17:42 --> Output Class Initialized
INFO - 2024-09-07 14:17:42 --> Security Class Initialized
DEBUG - 2024-09-07 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 14:17:42 --> Input Class Initialized
INFO - 2024-09-07 14:17:42 --> Language Class Initialized
INFO - 2024-09-07 14:17:42 --> Loader Class Initialized
INFO - 2024-09-07 14:17:42 --> Helper loaded: url_helper
INFO - 2024-09-07 14:17:42 --> Helper loaded: file_helper
INFO - 2024-09-07 14:17:42 --> Helper loaded: security_helper
INFO - 2024-09-07 14:17:42 --> Helper loaded: wpu_helper
INFO - 2024-09-07 14:17:42 --> Database Driver Class Initialized
INFO - 2024-09-07 14:17:42 --> Email Class Initialized
DEBUG - 2024-09-07 14:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 14:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 14:17:42 --> Helper loaded: form_helper
INFO - 2024-09-07 14:17:42 --> Form Validation Class Initialized
INFO - 2024-09-07 14:17:42 --> Controller Class Initialized
DEBUG - 2024-09-07 14:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 14:17:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 14:17:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 14:17:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 14:17:42 --> Final output sent to browser
DEBUG - 2024-09-07 14:17:42 --> Total execution time: 0.2317
INFO - 2024-09-07 14:43:56 --> Config Class Initialized
INFO - 2024-09-07 14:43:56 --> Hooks Class Initialized
DEBUG - 2024-09-07 14:43:56 --> UTF-8 Support Enabled
INFO - 2024-09-07 14:43:56 --> Utf8 Class Initialized
INFO - 2024-09-07 14:43:56 --> URI Class Initialized
DEBUG - 2024-09-07 14:43:56 --> No URI present. Default controller set.
INFO - 2024-09-07 14:43:56 --> Router Class Initialized
INFO - 2024-09-07 14:43:56 --> Output Class Initialized
INFO - 2024-09-07 14:43:56 --> Security Class Initialized
DEBUG - 2024-09-07 14:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 14:43:56 --> Input Class Initialized
INFO - 2024-09-07 14:43:56 --> Language Class Initialized
INFO - 2024-09-07 14:43:56 --> Loader Class Initialized
INFO - 2024-09-07 14:43:56 --> Helper loaded: url_helper
INFO - 2024-09-07 14:43:56 --> Helper loaded: file_helper
INFO - 2024-09-07 14:43:56 --> Helper loaded: security_helper
INFO - 2024-09-07 14:43:56 --> Helper loaded: wpu_helper
INFO - 2024-09-07 14:43:56 --> Database Driver Class Initialized
INFO - 2024-09-07 14:43:57 --> Email Class Initialized
DEBUG - 2024-09-07 14:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 14:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 14:43:57 --> Helper loaded: form_helper
INFO - 2024-09-07 14:43:57 --> Form Validation Class Initialized
INFO - 2024-09-07 14:43:57 --> Controller Class Initialized
DEBUG - 2024-09-07 14:43:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 14:43:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 14:43:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 14:43:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 14:43:57 --> Final output sent to browser
DEBUG - 2024-09-07 14:43:57 --> Total execution time: 0.2158
INFO - 2024-09-07 15:13:35 --> Config Class Initialized
INFO - 2024-09-07 15:13:35 --> Hooks Class Initialized
DEBUG - 2024-09-07 15:13:35 --> UTF-8 Support Enabled
INFO - 2024-09-07 15:13:35 --> Utf8 Class Initialized
INFO - 2024-09-07 15:13:35 --> URI Class Initialized
DEBUG - 2024-09-07 15:13:35 --> No URI present. Default controller set.
INFO - 2024-09-07 15:13:35 --> Router Class Initialized
INFO - 2024-09-07 15:13:35 --> Output Class Initialized
INFO - 2024-09-07 15:13:35 --> Security Class Initialized
DEBUG - 2024-09-07 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 15:13:35 --> Input Class Initialized
INFO - 2024-09-07 15:13:35 --> Language Class Initialized
INFO - 2024-09-07 15:13:35 --> Loader Class Initialized
INFO - 2024-09-07 15:13:35 --> Helper loaded: url_helper
INFO - 2024-09-07 15:13:35 --> Helper loaded: file_helper
INFO - 2024-09-07 15:13:35 --> Helper loaded: security_helper
INFO - 2024-09-07 15:13:35 --> Helper loaded: wpu_helper
INFO - 2024-09-07 15:13:35 --> Database Driver Class Initialized
INFO - 2024-09-07 15:13:35 --> Email Class Initialized
DEBUG - 2024-09-07 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 15:13:35 --> Helper loaded: form_helper
INFO - 2024-09-07 15:13:35 --> Form Validation Class Initialized
INFO - 2024-09-07 15:13:35 --> Controller Class Initialized
DEBUG - 2024-09-07 15:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 15:13:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 15:13:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 15:13:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 15:13:35 --> Final output sent to browser
DEBUG - 2024-09-07 15:13:35 --> Total execution time: 0.2526
INFO - 2024-09-07 15:47:05 --> Config Class Initialized
INFO - 2024-09-07 15:47:05 --> Hooks Class Initialized
DEBUG - 2024-09-07 15:47:05 --> UTF-8 Support Enabled
INFO - 2024-09-07 15:47:05 --> Utf8 Class Initialized
INFO - 2024-09-07 15:47:05 --> URI Class Initialized
DEBUG - 2024-09-07 15:47:05 --> No URI present. Default controller set.
INFO - 2024-09-07 15:47:05 --> Router Class Initialized
INFO - 2024-09-07 15:47:05 --> Output Class Initialized
INFO - 2024-09-07 15:47:05 --> Security Class Initialized
DEBUG - 2024-09-07 15:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 15:47:05 --> Input Class Initialized
INFO - 2024-09-07 15:47:05 --> Language Class Initialized
INFO - 2024-09-07 15:47:05 --> Loader Class Initialized
INFO - 2024-09-07 15:47:05 --> Helper loaded: url_helper
INFO - 2024-09-07 15:47:05 --> Helper loaded: file_helper
INFO - 2024-09-07 15:47:05 --> Helper loaded: security_helper
INFO - 2024-09-07 15:47:05 --> Helper loaded: wpu_helper
INFO - 2024-09-07 15:47:05 --> Database Driver Class Initialized
INFO - 2024-09-07 15:47:05 --> Email Class Initialized
DEBUG - 2024-09-07 15:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 15:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 15:47:05 --> Helper loaded: form_helper
INFO - 2024-09-07 15:47:05 --> Form Validation Class Initialized
INFO - 2024-09-07 15:47:05 --> Controller Class Initialized
DEBUG - 2024-09-07 15:47:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 15:47:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 15:47:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 15:47:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 15:47:05 --> Final output sent to browser
DEBUG - 2024-09-07 15:47:05 --> Total execution time: 0.2425
INFO - 2024-09-07 16:15:37 --> Config Class Initialized
INFO - 2024-09-07 16:15:37 --> Hooks Class Initialized
DEBUG - 2024-09-07 16:15:37 --> UTF-8 Support Enabled
INFO - 2024-09-07 16:15:37 --> Utf8 Class Initialized
INFO - 2024-09-07 16:15:37 --> URI Class Initialized
DEBUG - 2024-09-07 16:15:37 --> No URI present. Default controller set.
INFO - 2024-09-07 16:15:37 --> Router Class Initialized
INFO - 2024-09-07 16:15:37 --> Output Class Initialized
INFO - 2024-09-07 16:15:37 --> Security Class Initialized
DEBUG - 2024-09-07 16:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 16:15:37 --> Input Class Initialized
INFO - 2024-09-07 16:15:37 --> Language Class Initialized
INFO - 2024-09-07 16:15:37 --> Loader Class Initialized
INFO - 2024-09-07 16:15:37 --> Helper loaded: url_helper
INFO - 2024-09-07 16:15:37 --> Helper loaded: file_helper
INFO - 2024-09-07 16:15:37 --> Helper loaded: security_helper
INFO - 2024-09-07 16:15:37 --> Helper loaded: wpu_helper
INFO - 2024-09-07 16:15:37 --> Database Driver Class Initialized
INFO - 2024-09-07 16:15:38 --> Email Class Initialized
DEBUG - 2024-09-07 16:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 16:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 16:15:38 --> Helper loaded: form_helper
INFO - 2024-09-07 16:15:38 --> Form Validation Class Initialized
INFO - 2024-09-07 16:15:38 --> Controller Class Initialized
DEBUG - 2024-09-07 16:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 16:15:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 16:15:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 16:15:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 16:15:38 --> Final output sent to browser
DEBUG - 2024-09-07 16:15:38 --> Total execution time: 0.2170
INFO - 2024-09-07 16:42:10 --> Config Class Initialized
INFO - 2024-09-07 16:42:10 --> Hooks Class Initialized
DEBUG - 2024-09-07 16:42:10 --> UTF-8 Support Enabled
INFO - 2024-09-07 16:42:10 --> Utf8 Class Initialized
INFO - 2024-09-07 16:42:10 --> URI Class Initialized
DEBUG - 2024-09-07 16:42:10 --> No URI present. Default controller set.
INFO - 2024-09-07 16:42:10 --> Router Class Initialized
INFO - 2024-09-07 16:42:10 --> Output Class Initialized
INFO - 2024-09-07 16:42:10 --> Security Class Initialized
DEBUG - 2024-09-07 16:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 16:42:10 --> Input Class Initialized
INFO - 2024-09-07 16:42:10 --> Language Class Initialized
INFO - 2024-09-07 16:42:10 --> Loader Class Initialized
INFO - 2024-09-07 16:42:10 --> Helper loaded: url_helper
INFO - 2024-09-07 16:42:10 --> Helper loaded: file_helper
INFO - 2024-09-07 16:42:10 --> Helper loaded: security_helper
INFO - 2024-09-07 16:42:10 --> Helper loaded: wpu_helper
INFO - 2024-09-07 16:42:10 --> Database Driver Class Initialized
INFO - 2024-09-07 16:42:10 --> Email Class Initialized
DEBUG - 2024-09-07 16:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 16:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 16:42:10 --> Helper loaded: form_helper
INFO - 2024-09-07 16:42:10 --> Form Validation Class Initialized
INFO - 2024-09-07 16:42:10 --> Controller Class Initialized
DEBUG - 2024-09-07 16:42:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 16:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 16:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 16:42:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 16:42:10 --> Final output sent to browser
DEBUG - 2024-09-07 16:42:10 --> Total execution time: 0.2131
INFO - 2024-09-07 17:14:37 --> Config Class Initialized
INFO - 2024-09-07 17:14:37 --> Hooks Class Initialized
DEBUG - 2024-09-07 17:14:37 --> UTF-8 Support Enabled
INFO - 2024-09-07 17:14:37 --> Utf8 Class Initialized
INFO - 2024-09-07 17:14:37 --> URI Class Initialized
DEBUG - 2024-09-07 17:14:37 --> No URI present. Default controller set.
INFO - 2024-09-07 17:14:37 --> Router Class Initialized
INFO - 2024-09-07 17:14:37 --> Output Class Initialized
INFO - 2024-09-07 17:14:37 --> Security Class Initialized
DEBUG - 2024-09-07 17:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 17:14:37 --> Input Class Initialized
INFO - 2024-09-07 17:14:37 --> Language Class Initialized
INFO - 2024-09-07 17:14:37 --> Loader Class Initialized
INFO - 2024-09-07 17:14:37 --> Helper loaded: url_helper
INFO - 2024-09-07 17:14:37 --> Helper loaded: file_helper
INFO - 2024-09-07 17:14:37 --> Helper loaded: security_helper
INFO - 2024-09-07 17:14:37 --> Helper loaded: wpu_helper
INFO - 2024-09-07 17:14:37 --> Database Driver Class Initialized
INFO - 2024-09-07 17:14:37 --> Email Class Initialized
DEBUG - 2024-09-07 17:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 17:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 17:14:37 --> Helper loaded: form_helper
INFO - 2024-09-07 17:14:37 --> Form Validation Class Initialized
INFO - 2024-09-07 17:14:37 --> Controller Class Initialized
DEBUG - 2024-09-07 17:14:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 17:14:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 17:14:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 17:14:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 17:14:37 --> Final output sent to browser
DEBUG - 2024-09-07 17:14:37 --> Total execution time: 0.2187
INFO - 2024-09-07 17:18:22 --> Config Class Initialized
INFO - 2024-09-07 17:18:22 --> Hooks Class Initialized
DEBUG - 2024-09-07 17:18:22 --> UTF-8 Support Enabled
INFO - 2024-09-07 17:18:22 --> Utf8 Class Initialized
INFO - 2024-09-07 17:18:22 --> URI Class Initialized
DEBUG - 2024-09-07 17:18:22 --> No URI present. Default controller set.
INFO - 2024-09-07 17:18:22 --> Router Class Initialized
INFO - 2024-09-07 17:18:22 --> Output Class Initialized
INFO - 2024-09-07 17:18:22 --> Security Class Initialized
DEBUG - 2024-09-07 17:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 17:18:22 --> Input Class Initialized
INFO - 2024-09-07 17:18:22 --> Language Class Initialized
INFO - 2024-09-07 17:18:22 --> Loader Class Initialized
INFO - 2024-09-07 17:18:22 --> Helper loaded: url_helper
INFO - 2024-09-07 17:18:22 --> Helper loaded: file_helper
INFO - 2024-09-07 17:18:22 --> Helper loaded: security_helper
INFO - 2024-09-07 17:18:22 --> Helper loaded: wpu_helper
INFO - 2024-09-07 17:18:22 --> Database Driver Class Initialized
INFO - 2024-09-07 17:18:22 --> Email Class Initialized
DEBUG - 2024-09-07 17:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 17:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 17:18:22 --> Helper loaded: form_helper
INFO - 2024-09-07 17:18:22 --> Form Validation Class Initialized
INFO - 2024-09-07 17:18:22 --> Controller Class Initialized
DEBUG - 2024-09-07 17:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 17:18:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 17:18:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 17:18:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 17:18:22 --> Final output sent to browser
DEBUG - 2024-09-07 17:18:22 --> Total execution time: 0.2274
INFO - 2024-09-07 17:43:12 --> Config Class Initialized
INFO - 2024-09-07 17:43:12 --> Hooks Class Initialized
DEBUG - 2024-09-07 17:43:12 --> UTF-8 Support Enabled
INFO - 2024-09-07 17:43:12 --> Utf8 Class Initialized
INFO - 2024-09-07 17:43:12 --> URI Class Initialized
DEBUG - 2024-09-07 17:43:12 --> No URI present. Default controller set.
INFO - 2024-09-07 17:43:12 --> Router Class Initialized
INFO - 2024-09-07 17:43:12 --> Output Class Initialized
INFO - 2024-09-07 17:43:12 --> Security Class Initialized
DEBUG - 2024-09-07 17:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 17:43:12 --> Input Class Initialized
INFO - 2024-09-07 17:43:12 --> Language Class Initialized
INFO - 2024-09-07 17:43:12 --> Loader Class Initialized
INFO - 2024-09-07 17:43:12 --> Helper loaded: url_helper
INFO - 2024-09-07 17:43:12 --> Helper loaded: file_helper
INFO - 2024-09-07 17:43:12 --> Helper loaded: security_helper
INFO - 2024-09-07 17:43:12 --> Helper loaded: wpu_helper
INFO - 2024-09-07 17:43:12 --> Database Driver Class Initialized
INFO - 2024-09-07 17:43:13 --> Email Class Initialized
DEBUG - 2024-09-07 17:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 17:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 17:43:13 --> Helper loaded: form_helper
INFO - 2024-09-07 17:43:13 --> Form Validation Class Initialized
INFO - 2024-09-07 17:43:13 --> Controller Class Initialized
DEBUG - 2024-09-07 17:43:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 17:43:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 17:43:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 17:43:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 17:43:13 --> Final output sent to browser
DEBUG - 2024-09-07 17:43:13 --> Total execution time: 0.2349
INFO - 2024-09-07 18:12:29 --> Config Class Initialized
INFO - 2024-09-07 18:12:29 --> Hooks Class Initialized
DEBUG - 2024-09-07 18:12:29 --> UTF-8 Support Enabled
INFO - 2024-09-07 18:12:29 --> Utf8 Class Initialized
INFO - 2024-09-07 18:12:29 --> URI Class Initialized
DEBUG - 2024-09-07 18:12:29 --> No URI present. Default controller set.
INFO - 2024-09-07 18:12:29 --> Router Class Initialized
INFO - 2024-09-07 18:12:29 --> Output Class Initialized
INFO - 2024-09-07 18:12:29 --> Security Class Initialized
DEBUG - 2024-09-07 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 18:12:29 --> Input Class Initialized
INFO - 2024-09-07 18:12:29 --> Language Class Initialized
INFO - 2024-09-07 18:12:29 --> Loader Class Initialized
INFO - 2024-09-07 18:12:29 --> Helper loaded: url_helper
INFO - 2024-09-07 18:12:29 --> Helper loaded: file_helper
INFO - 2024-09-07 18:12:29 --> Helper loaded: security_helper
INFO - 2024-09-07 18:12:29 --> Helper loaded: wpu_helper
INFO - 2024-09-07 18:12:29 --> Database Driver Class Initialized
INFO - 2024-09-07 18:12:29 --> Email Class Initialized
DEBUG - 2024-09-07 18:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 18:12:29 --> Helper loaded: form_helper
INFO - 2024-09-07 18:12:29 --> Form Validation Class Initialized
INFO - 2024-09-07 18:12:29 --> Controller Class Initialized
DEBUG - 2024-09-07 18:12:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 18:12:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 18:12:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 18:12:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 18:12:29 --> Final output sent to browser
DEBUG - 2024-09-07 18:12:29 --> Total execution time: 0.2247
INFO - 2024-09-07 18:21:44 --> Config Class Initialized
INFO - 2024-09-07 18:21:44 --> Hooks Class Initialized
DEBUG - 2024-09-07 18:21:44 --> UTF-8 Support Enabled
INFO - 2024-09-07 18:21:44 --> Utf8 Class Initialized
INFO - 2024-09-07 18:21:44 --> URI Class Initialized
DEBUG - 2024-09-07 18:21:44 --> No URI present. Default controller set.
INFO - 2024-09-07 18:21:44 --> Router Class Initialized
INFO - 2024-09-07 18:21:44 --> Output Class Initialized
INFO - 2024-09-07 18:21:44 --> Security Class Initialized
DEBUG - 2024-09-07 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 18:21:44 --> Input Class Initialized
INFO - 2024-09-07 18:21:44 --> Language Class Initialized
INFO - 2024-09-07 18:21:44 --> Loader Class Initialized
INFO - 2024-09-07 18:21:44 --> Helper loaded: url_helper
INFO - 2024-09-07 18:21:44 --> Helper loaded: file_helper
INFO - 2024-09-07 18:21:44 --> Helper loaded: security_helper
INFO - 2024-09-07 18:21:44 --> Helper loaded: wpu_helper
INFO - 2024-09-07 18:21:44 --> Database Driver Class Initialized
INFO - 2024-09-07 18:21:44 --> Email Class Initialized
DEBUG - 2024-09-07 18:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 18:21:44 --> Helper loaded: form_helper
INFO - 2024-09-07 18:21:44 --> Form Validation Class Initialized
INFO - 2024-09-07 18:21:44 --> Controller Class Initialized
DEBUG - 2024-09-07 18:21:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 18:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 18:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 18:21:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 18:21:44 --> Final output sent to browser
DEBUG - 2024-09-07 18:21:44 --> Total execution time: 0.2132
INFO - 2024-09-07 18:22:38 --> Config Class Initialized
INFO - 2024-09-07 18:22:38 --> Hooks Class Initialized
DEBUG - 2024-09-07 18:22:38 --> UTF-8 Support Enabled
INFO - 2024-09-07 18:22:38 --> Utf8 Class Initialized
INFO - 2024-09-07 18:22:38 --> URI Class Initialized
DEBUG - 2024-09-07 18:22:38 --> No URI present. Default controller set.
INFO - 2024-09-07 18:22:38 --> Router Class Initialized
INFO - 2024-09-07 18:22:38 --> Output Class Initialized
INFO - 2024-09-07 18:22:38 --> Security Class Initialized
DEBUG - 2024-09-07 18:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 18:22:38 --> Input Class Initialized
INFO - 2024-09-07 18:22:38 --> Language Class Initialized
INFO - 2024-09-07 18:22:38 --> Loader Class Initialized
INFO - 2024-09-07 18:22:38 --> Helper loaded: url_helper
INFO - 2024-09-07 18:22:38 --> Helper loaded: file_helper
INFO - 2024-09-07 18:22:38 --> Helper loaded: security_helper
INFO - 2024-09-07 18:22:38 --> Helper loaded: wpu_helper
INFO - 2024-09-07 18:22:38 --> Database Driver Class Initialized
INFO - 2024-09-07 18:22:38 --> Email Class Initialized
DEBUG - 2024-09-07 18:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 18:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 18:22:38 --> Helper loaded: form_helper
INFO - 2024-09-07 18:22:38 --> Form Validation Class Initialized
INFO - 2024-09-07 18:22:38 --> Controller Class Initialized
DEBUG - 2024-09-07 18:22:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 18:22:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 18:22:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 18:22:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 18:22:38 --> Final output sent to browser
DEBUG - 2024-09-07 18:22:38 --> Total execution time: 0.2144
INFO - 2024-09-07 18:42:55 --> Config Class Initialized
INFO - 2024-09-07 18:42:55 --> Hooks Class Initialized
DEBUG - 2024-09-07 18:42:55 --> UTF-8 Support Enabled
INFO - 2024-09-07 18:42:55 --> Utf8 Class Initialized
INFO - 2024-09-07 18:42:55 --> URI Class Initialized
DEBUG - 2024-09-07 18:42:55 --> No URI present. Default controller set.
INFO - 2024-09-07 18:42:55 --> Router Class Initialized
INFO - 2024-09-07 18:42:55 --> Output Class Initialized
INFO - 2024-09-07 18:42:55 --> Security Class Initialized
DEBUG - 2024-09-07 18:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 18:42:55 --> Input Class Initialized
INFO - 2024-09-07 18:42:55 --> Language Class Initialized
INFO - 2024-09-07 18:42:55 --> Loader Class Initialized
INFO - 2024-09-07 18:42:55 --> Helper loaded: url_helper
INFO - 2024-09-07 18:42:55 --> Helper loaded: file_helper
INFO - 2024-09-07 18:42:55 --> Helper loaded: security_helper
INFO - 2024-09-07 18:42:55 --> Helper loaded: wpu_helper
INFO - 2024-09-07 18:42:55 --> Database Driver Class Initialized
INFO - 2024-09-07 18:42:56 --> Email Class Initialized
DEBUG - 2024-09-07 18:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 18:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 18:42:56 --> Helper loaded: form_helper
INFO - 2024-09-07 18:42:56 --> Form Validation Class Initialized
INFO - 2024-09-07 18:42:56 --> Controller Class Initialized
DEBUG - 2024-09-07 18:42:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 18:42:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 18:42:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 18:42:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 18:42:56 --> Final output sent to browser
DEBUG - 2024-09-07 18:42:56 --> Total execution time: 0.2346
INFO - 2024-09-07 19:14:05 --> Config Class Initialized
INFO - 2024-09-07 19:14:05 --> Hooks Class Initialized
DEBUG - 2024-09-07 19:14:05 --> UTF-8 Support Enabled
INFO - 2024-09-07 19:14:05 --> Utf8 Class Initialized
INFO - 2024-09-07 19:14:05 --> URI Class Initialized
DEBUG - 2024-09-07 19:14:05 --> No URI present. Default controller set.
INFO - 2024-09-07 19:14:05 --> Router Class Initialized
INFO - 2024-09-07 19:14:05 --> Output Class Initialized
INFO - 2024-09-07 19:14:05 --> Security Class Initialized
DEBUG - 2024-09-07 19:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 19:14:05 --> Input Class Initialized
INFO - 2024-09-07 19:14:05 --> Language Class Initialized
INFO - 2024-09-07 19:14:05 --> Loader Class Initialized
INFO - 2024-09-07 19:14:05 --> Helper loaded: url_helper
INFO - 2024-09-07 19:14:05 --> Helper loaded: file_helper
INFO - 2024-09-07 19:14:05 --> Helper loaded: security_helper
INFO - 2024-09-07 19:14:05 --> Helper loaded: wpu_helper
INFO - 2024-09-07 19:14:05 --> Database Driver Class Initialized
INFO - 2024-09-07 19:14:05 --> Email Class Initialized
DEBUG - 2024-09-07 19:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 19:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 19:14:05 --> Helper loaded: form_helper
INFO - 2024-09-07 19:14:05 --> Form Validation Class Initialized
INFO - 2024-09-07 19:14:05 --> Controller Class Initialized
DEBUG - 2024-09-07 19:14:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 19:14:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 19:14:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 19:14:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 19:14:05 --> Final output sent to browser
DEBUG - 2024-09-07 19:14:05 --> Total execution time: 0.2242
INFO - 2024-09-07 19:43:40 --> Config Class Initialized
INFO - 2024-09-07 19:43:40 --> Hooks Class Initialized
DEBUG - 2024-09-07 19:43:40 --> UTF-8 Support Enabled
INFO - 2024-09-07 19:43:40 --> Utf8 Class Initialized
INFO - 2024-09-07 19:43:40 --> URI Class Initialized
DEBUG - 2024-09-07 19:43:40 --> No URI present. Default controller set.
INFO - 2024-09-07 19:43:40 --> Router Class Initialized
INFO - 2024-09-07 19:43:40 --> Output Class Initialized
INFO - 2024-09-07 19:43:40 --> Security Class Initialized
DEBUG - 2024-09-07 19:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 19:43:40 --> Input Class Initialized
INFO - 2024-09-07 19:43:40 --> Language Class Initialized
INFO - 2024-09-07 19:43:40 --> Loader Class Initialized
INFO - 2024-09-07 19:43:40 --> Helper loaded: url_helper
INFO - 2024-09-07 19:43:40 --> Helper loaded: file_helper
INFO - 2024-09-07 19:43:40 --> Helper loaded: security_helper
INFO - 2024-09-07 19:43:40 --> Helper loaded: wpu_helper
INFO - 2024-09-07 19:43:40 --> Database Driver Class Initialized
INFO - 2024-09-07 19:43:40 --> Email Class Initialized
DEBUG - 2024-09-07 19:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 19:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 19:43:40 --> Helper loaded: form_helper
INFO - 2024-09-07 19:43:40 --> Form Validation Class Initialized
INFO - 2024-09-07 19:43:40 --> Controller Class Initialized
DEBUG - 2024-09-07 19:43:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 19:43:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 19:43:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 19:43:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 19:43:40 --> Final output sent to browser
DEBUG - 2024-09-07 19:43:40 --> Total execution time: 0.2199
INFO - 2024-09-07 20:12:52 --> Config Class Initialized
INFO - 2024-09-07 20:12:52 --> Hooks Class Initialized
DEBUG - 2024-09-07 20:12:52 --> UTF-8 Support Enabled
INFO - 2024-09-07 20:12:52 --> Utf8 Class Initialized
INFO - 2024-09-07 20:12:52 --> URI Class Initialized
DEBUG - 2024-09-07 20:12:52 --> No URI present. Default controller set.
INFO - 2024-09-07 20:12:52 --> Router Class Initialized
INFO - 2024-09-07 20:12:52 --> Output Class Initialized
INFO - 2024-09-07 20:12:52 --> Security Class Initialized
DEBUG - 2024-09-07 20:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 20:12:52 --> Input Class Initialized
INFO - 2024-09-07 20:12:52 --> Language Class Initialized
INFO - 2024-09-07 20:12:52 --> Loader Class Initialized
INFO - 2024-09-07 20:12:52 --> Helper loaded: url_helper
INFO - 2024-09-07 20:12:52 --> Helper loaded: file_helper
INFO - 2024-09-07 20:12:52 --> Helper loaded: security_helper
INFO - 2024-09-07 20:12:52 --> Helper loaded: wpu_helper
INFO - 2024-09-07 20:12:52 --> Database Driver Class Initialized
INFO - 2024-09-07 20:12:52 --> Email Class Initialized
DEBUG - 2024-09-07 20:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 20:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 20:12:52 --> Helper loaded: form_helper
INFO - 2024-09-07 20:12:52 --> Form Validation Class Initialized
INFO - 2024-09-07 20:12:52 --> Controller Class Initialized
DEBUG - 2024-09-07 20:12:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 20:12:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 20:12:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 20:12:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 20:12:52 --> Final output sent to browser
DEBUG - 2024-09-07 20:12:52 --> Total execution time: 0.2154
INFO - 2024-09-07 20:17:35 --> Config Class Initialized
INFO - 2024-09-07 20:17:35 --> Hooks Class Initialized
DEBUG - 2024-09-07 20:17:35 --> UTF-8 Support Enabled
INFO - 2024-09-07 20:17:35 --> Utf8 Class Initialized
INFO - 2024-09-07 20:17:35 --> URI Class Initialized
DEBUG - 2024-09-07 20:17:35 --> No URI present. Default controller set.
INFO - 2024-09-07 20:17:35 --> Router Class Initialized
INFO - 2024-09-07 20:17:35 --> Output Class Initialized
INFO - 2024-09-07 20:17:35 --> Security Class Initialized
DEBUG - 2024-09-07 20:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 20:17:35 --> Input Class Initialized
INFO - 2024-09-07 20:17:35 --> Language Class Initialized
INFO - 2024-09-07 20:17:35 --> Loader Class Initialized
INFO - 2024-09-07 20:17:35 --> Helper loaded: url_helper
INFO - 2024-09-07 20:17:35 --> Helper loaded: file_helper
INFO - 2024-09-07 20:17:35 --> Helper loaded: security_helper
INFO - 2024-09-07 20:17:35 --> Helper loaded: wpu_helper
INFO - 2024-09-07 20:17:35 --> Database Driver Class Initialized
INFO - 2024-09-07 20:17:35 --> Email Class Initialized
DEBUG - 2024-09-07 20:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 20:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 20:17:35 --> Helper loaded: form_helper
INFO - 2024-09-07 20:17:35 --> Form Validation Class Initialized
INFO - 2024-09-07 20:17:35 --> Controller Class Initialized
DEBUG - 2024-09-07 20:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 20:17:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 20:17:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 20:17:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 20:17:35 --> Final output sent to browser
DEBUG - 2024-09-07 20:17:35 --> Total execution time: 0.2501
INFO - 2024-09-07 20:17:36 --> Config Class Initialized
INFO - 2024-09-07 20:17:36 --> Hooks Class Initialized
DEBUG - 2024-09-07 20:17:36 --> UTF-8 Support Enabled
INFO - 2024-09-07 20:17:36 --> Utf8 Class Initialized
INFO - 2024-09-07 20:17:36 --> URI Class Initialized
DEBUG - 2024-09-07 20:17:36 --> No URI present. Default controller set.
INFO - 2024-09-07 20:17:36 --> Router Class Initialized
INFO - 2024-09-07 20:17:36 --> Output Class Initialized
INFO - 2024-09-07 20:17:36 --> Security Class Initialized
DEBUG - 2024-09-07 20:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 20:17:36 --> Input Class Initialized
INFO - 2024-09-07 20:17:36 --> Language Class Initialized
INFO - 2024-09-07 20:17:36 --> Loader Class Initialized
INFO - 2024-09-07 20:17:36 --> Helper loaded: url_helper
INFO - 2024-09-07 20:17:36 --> Helper loaded: file_helper
INFO - 2024-09-07 20:17:36 --> Helper loaded: security_helper
INFO - 2024-09-07 20:17:36 --> Helper loaded: wpu_helper
INFO - 2024-09-07 20:17:36 --> Database Driver Class Initialized
INFO - 2024-09-07 20:17:36 --> Email Class Initialized
DEBUG - 2024-09-07 20:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 20:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 20:17:36 --> Helper loaded: form_helper
INFO - 2024-09-07 20:17:36 --> Form Validation Class Initialized
INFO - 2024-09-07 20:17:36 --> Controller Class Initialized
DEBUG - 2024-09-07 20:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 20:17:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 20:17:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 20:17:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 20:17:36 --> Final output sent to browser
DEBUG - 2024-09-07 20:17:36 --> Total execution time: 0.2253
INFO - 2024-09-07 20:19:02 --> Config Class Initialized
INFO - 2024-09-07 20:19:02 --> Hooks Class Initialized
DEBUG - 2024-09-07 20:19:02 --> UTF-8 Support Enabled
INFO - 2024-09-07 20:19:02 --> Utf8 Class Initialized
INFO - 2024-09-07 20:19:02 --> URI Class Initialized
DEBUG - 2024-09-07 20:19:02 --> No URI present. Default controller set.
INFO - 2024-09-07 20:19:02 --> Router Class Initialized
INFO - 2024-09-07 20:19:02 --> Output Class Initialized
INFO - 2024-09-07 20:19:02 --> Security Class Initialized
DEBUG - 2024-09-07 20:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 20:19:02 --> Input Class Initialized
INFO - 2024-09-07 20:19:02 --> Language Class Initialized
INFO - 2024-09-07 20:19:02 --> Loader Class Initialized
INFO - 2024-09-07 20:19:02 --> Helper loaded: url_helper
INFO - 2024-09-07 20:19:02 --> Helper loaded: file_helper
INFO - 2024-09-07 20:19:02 --> Helper loaded: security_helper
INFO - 2024-09-07 20:19:02 --> Helper loaded: wpu_helper
INFO - 2024-09-07 20:19:02 --> Database Driver Class Initialized
INFO - 2024-09-07 20:19:02 --> Email Class Initialized
DEBUG - 2024-09-07 20:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 20:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 20:19:02 --> Helper loaded: form_helper
INFO - 2024-09-07 20:19:02 --> Form Validation Class Initialized
INFO - 2024-09-07 20:19:02 --> Controller Class Initialized
DEBUG - 2024-09-07 20:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 20:19:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 20:19:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 20:19:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 20:19:02 --> Final output sent to browser
DEBUG - 2024-09-07 20:19:02 --> Total execution time: 0.2131
INFO - 2024-09-07 20:43:31 --> Config Class Initialized
INFO - 2024-09-07 20:43:31 --> Hooks Class Initialized
DEBUG - 2024-09-07 20:43:31 --> UTF-8 Support Enabled
INFO - 2024-09-07 20:43:31 --> Utf8 Class Initialized
INFO - 2024-09-07 20:43:31 --> URI Class Initialized
DEBUG - 2024-09-07 20:43:31 --> No URI present. Default controller set.
INFO - 2024-09-07 20:43:31 --> Router Class Initialized
INFO - 2024-09-07 20:43:31 --> Output Class Initialized
INFO - 2024-09-07 20:43:31 --> Security Class Initialized
DEBUG - 2024-09-07 20:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 20:43:31 --> Input Class Initialized
INFO - 2024-09-07 20:43:31 --> Language Class Initialized
INFO - 2024-09-07 20:43:31 --> Loader Class Initialized
INFO - 2024-09-07 20:43:31 --> Helper loaded: url_helper
INFO - 2024-09-07 20:43:31 --> Helper loaded: file_helper
INFO - 2024-09-07 20:43:31 --> Helper loaded: security_helper
INFO - 2024-09-07 20:43:31 --> Helper loaded: wpu_helper
INFO - 2024-09-07 20:43:31 --> Database Driver Class Initialized
INFO - 2024-09-07 20:43:32 --> Email Class Initialized
DEBUG - 2024-09-07 20:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 20:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 20:43:32 --> Helper loaded: form_helper
INFO - 2024-09-07 20:43:32 --> Form Validation Class Initialized
INFO - 2024-09-07 20:43:32 --> Controller Class Initialized
DEBUG - 2024-09-07 20:43:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 20:43:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 20:43:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 20:43:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 20:43:32 --> Final output sent to browser
DEBUG - 2024-09-07 20:43:32 --> Total execution time: 0.2236
INFO - 2024-09-07 21:13:47 --> Config Class Initialized
INFO - 2024-09-07 21:13:47 --> Hooks Class Initialized
DEBUG - 2024-09-07 21:13:47 --> UTF-8 Support Enabled
INFO - 2024-09-07 21:13:47 --> Utf8 Class Initialized
INFO - 2024-09-07 21:13:47 --> URI Class Initialized
DEBUG - 2024-09-07 21:13:47 --> No URI present. Default controller set.
INFO - 2024-09-07 21:13:47 --> Router Class Initialized
INFO - 2024-09-07 21:13:47 --> Output Class Initialized
INFO - 2024-09-07 21:13:47 --> Security Class Initialized
DEBUG - 2024-09-07 21:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 21:13:47 --> Input Class Initialized
INFO - 2024-09-07 21:13:47 --> Language Class Initialized
INFO - 2024-09-07 21:13:47 --> Loader Class Initialized
INFO - 2024-09-07 21:13:47 --> Helper loaded: url_helper
INFO - 2024-09-07 21:13:47 --> Helper loaded: file_helper
INFO - 2024-09-07 21:13:47 --> Helper loaded: security_helper
INFO - 2024-09-07 21:13:47 --> Helper loaded: wpu_helper
INFO - 2024-09-07 21:13:47 --> Database Driver Class Initialized
INFO - 2024-09-07 21:13:47 --> Email Class Initialized
DEBUG - 2024-09-07 21:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 21:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 21:13:47 --> Helper loaded: form_helper
INFO - 2024-09-07 21:13:47 --> Form Validation Class Initialized
INFO - 2024-09-07 21:13:47 --> Controller Class Initialized
DEBUG - 2024-09-07 21:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 21:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 21:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 21:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 21:13:47 --> Final output sent to browser
DEBUG - 2024-09-07 21:13:47 --> Total execution time: 0.3194
INFO - 2024-09-07 21:42:41 --> Config Class Initialized
INFO - 2024-09-07 21:42:41 --> Hooks Class Initialized
DEBUG - 2024-09-07 21:42:41 --> UTF-8 Support Enabled
INFO - 2024-09-07 21:42:41 --> Utf8 Class Initialized
INFO - 2024-09-07 21:42:41 --> URI Class Initialized
DEBUG - 2024-09-07 21:42:41 --> No URI present. Default controller set.
INFO - 2024-09-07 21:42:41 --> Router Class Initialized
INFO - 2024-09-07 21:42:41 --> Output Class Initialized
INFO - 2024-09-07 21:42:41 --> Security Class Initialized
DEBUG - 2024-09-07 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 21:42:41 --> Input Class Initialized
INFO - 2024-09-07 21:42:41 --> Language Class Initialized
INFO - 2024-09-07 21:42:41 --> Loader Class Initialized
INFO - 2024-09-07 21:42:41 --> Helper loaded: url_helper
INFO - 2024-09-07 21:42:41 --> Helper loaded: file_helper
INFO - 2024-09-07 21:42:41 --> Helper loaded: security_helper
INFO - 2024-09-07 21:42:41 --> Helper loaded: wpu_helper
INFO - 2024-09-07 21:42:41 --> Database Driver Class Initialized
INFO - 2024-09-07 21:42:41 --> Email Class Initialized
DEBUG - 2024-09-07 21:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 21:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 21:42:41 --> Helper loaded: form_helper
INFO - 2024-09-07 21:42:41 --> Form Validation Class Initialized
INFO - 2024-09-07 21:42:41 --> Controller Class Initialized
DEBUG - 2024-09-07 21:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 21:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 21:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 21:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 21:42:41 --> Final output sent to browser
DEBUG - 2024-09-07 21:42:41 --> Total execution time: 0.2176
INFO - 2024-09-07 22:13:12 --> Config Class Initialized
INFO - 2024-09-07 22:13:12 --> Hooks Class Initialized
DEBUG - 2024-09-07 22:13:12 --> UTF-8 Support Enabled
INFO - 2024-09-07 22:13:12 --> Utf8 Class Initialized
INFO - 2024-09-07 22:13:12 --> URI Class Initialized
DEBUG - 2024-09-07 22:13:12 --> No URI present. Default controller set.
INFO - 2024-09-07 22:13:12 --> Router Class Initialized
INFO - 2024-09-07 22:13:12 --> Output Class Initialized
INFO - 2024-09-07 22:13:12 --> Security Class Initialized
DEBUG - 2024-09-07 22:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 22:13:12 --> Input Class Initialized
INFO - 2024-09-07 22:13:12 --> Language Class Initialized
INFO - 2024-09-07 22:13:12 --> Loader Class Initialized
INFO - 2024-09-07 22:13:12 --> Helper loaded: url_helper
INFO - 2024-09-07 22:13:12 --> Helper loaded: file_helper
INFO - 2024-09-07 22:13:12 --> Helper loaded: security_helper
INFO - 2024-09-07 22:13:12 --> Helper loaded: wpu_helper
INFO - 2024-09-07 22:13:12 --> Database Driver Class Initialized
INFO - 2024-09-07 22:13:12 --> Email Class Initialized
DEBUG - 2024-09-07 22:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 22:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 22:13:12 --> Helper loaded: form_helper
INFO - 2024-09-07 22:13:12 --> Form Validation Class Initialized
INFO - 2024-09-07 22:13:12 --> Controller Class Initialized
DEBUG - 2024-09-07 22:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 22:13:12 --> Final output sent to browser
DEBUG - 2024-09-07 22:13:12 --> Total execution time: 0.2241
INFO - 2024-09-07 22:45:01 --> Config Class Initialized
INFO - 2024-09-07 22:45:01 --> Hooks Class Initialized
DEBUG - 2024-09-07 22:45:01 --> UTF-8 Support Enabled
INFO - 2024-09-07 22:45:01 --> Utf8 Class Initialized
INFO - 2024-09-07 22:45:01 --> URI Class Initialized
DEBUG - 2024-09-07 22:45:01 --> No URI present. Default controller set.
INFO - 2024-09-07 22:45:01 --> Router Class Initialized
INFO - 2024-09-07 22:45:01 --> Output Class Initialized
INFO - 2024-09-07 22:45:01 --> Security Class Initialized
DEBUG - 2024-09-07 22:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 22:45:01 --> Input Class Initialized
INFO - 2024-09-07 22:45:01 --> Language Class Initialized
INFO - 2024-09-07 22:45:01 --> Loader Class Initialized
INFO - 2024-09-07 22:45:01 --> Helper loaded: url_helper
INFO - 2024-09-07 22:45:01 --> Helper loaded: file_helper
INFO - 2024-09-07 22:45:01 --> Helper loaded: security_helper
INFO - 2024-09-07 22:45:01 --> Helper loaded: wpu_helper
INFO - 2024-09-07 22:45:01 --> Database Driver Class Initialized
INFO - 2024-09-07 22:45:01 --> Email Class Initialized
DEBUG - 2024-09-07 22:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 22:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 22:45:01 --> Helper loaded: form_helper
INFO - 2024-09-07 22:45:01 --> Form Validation Class Initialized
INFO - 2024-09-07 22:45:01 --> Controller Class Initialized
DEBUG - 2024-09-07 22:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 22:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 22:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 22:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 22:45:01 --> Final output sent to browser
DEBUG - 2024-09-07 22:45:01 --> Total execution time: 0.2344
INFO - 2024-09-07 23:13:02 --> Config Class Initialized
INFO - 2024-09-07 23:13:02 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:13:02 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:13:02 --> Utf8 Class Initialized
INFO - 2024-09-07 23:13:02 --> URI Class Initialized
DEBUG - 2024-09-07 23:13:02 --> No URI present. Default controller set.
INFO - 2024-09-07 23:13:02 --> Router Class Initialized
INFO - 2024-09-07 23:13:02 --> Output Class Initialized
INFO - 2024-09-07 23:13:02 --> Security Class Initialized
DEBUG - 2024-09-07 23:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:13:02 --> Input Class Initialized
INFO - 2024-09-07 23:13:02 --> Language Class Initialized
INFO - 2024-09-07 23:13:02 --> Loader Class Initialized
INFO - 2024-09-07 23:13:02 --> Helper loaded: url_helper
INFO - 2024-09-07 23:13:02 --> Helper loaded: file_helper
INFO - 2024-09-07 23:13:02 --> Helper loaded: security_helper
INFO - 2024-09-07 23:13:02 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:13:02 --> Database Driver Class Initialized
INFO - 2024-09-07 23:13:02 --> Email Class Initialized
DEBUG - 2024-09-07 23:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:13:02 --> Helper loaded: form_helper
INFO - 2024-09-07 23:13:02 --> Form Validation Class Initialized
INFO - 2024-09-07 23:13:02 --> Controller Class Initialized
DEBUG - 2024-09-07 23:13:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:13:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:13:02 --> Final output sent to browser
DEBUG - 2024-09-07 23:13:02 --> Total execution time: 0.2198
INFO - 2024-09-07 23:18:51 --> Config Class Initialized
INFO - 2024-09-07 23:18:51 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:18:51 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:18:51 --> Utf8 Class Initialized
INFO - 2024-09-07 23:18:51 --> URI Class Initialized
DEBUG - 2024-09-07 23:18:51 --> No URI present. Default controller set.
INFO - 2024-09-07 23:18:51 --> Router Class Initialized
INFO - 2024-09-07 23:18:51 --> Output Class Initialized
INFO - 2024-09-07 23:18:51 --> Security Class Initialized
DEBUG - 2024-09-07 23:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:18:51 --> Input Class Initialized
INFO - 2024-09-07 23:18:51 --> Language Class Initialized
INFO - 2024-09-07 23:18:51 --> Loader Class Initialized
INFO - 2024-09-07 23:18:51 --> Helper loaded: url_helper
INFO - 2024-09-07 23:18:51 --> Helper loaded: file_helper
INFO - 2024-09-07 23:18:51 --> Helper loaded: security_helper
INFO - 2024-09-07 23:18:51 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:18:51 --> Database Driver Class Initialized
INFO - 2024-09-07 23:18:52 --> Email Class Initialized
DEBUG - 2024-09-07 23:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:18:52 --> Helper loaded: form_helper
INFO - 2024-09-07 23:18:52 --> Form Validation Class Initialized
INFO - 2024-09-07 23:18:52 --> Controller Class Initialized
DEBUG - 2024-09-07 23:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:18:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:18:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:18:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:18:52 --> Final output sent to browser
DEBUG - 2024-09-07 23:18:52 --> Total execution time: 0.2193
INFO - 2024-09-07 23:22:48 --> Config Class Initialized
INFO - 2024-09-07 23:22:48 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:22:48 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:22:48 --> Utf8 Class Initialized
INFO - 2024-09-07 23:22:48 --> URI Class Initialized
DEBUG - 2024-09-07 23:22:48 --> No URI present. Default controller set.
INFO - 2024-09-07 23:22:48 --> Router Class Initialized
INFO - 2024-09-07 23:22:48 --> Output Class Initialized
INFO - 2024-09-07 23:22:48 --> Security Class Initialized
DEBUG - 2024-09-07 23:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:22:48 --> Input Class Initialized
INFO - 2024-09-07 23:22:48 --> Language Class Initialized
INFO - 2024-09-07 23:22:48 --> Loader Class Initialized
INFO - 2024-09-07 23:22:48 --> Helper loaded: url_helper
INFO - 2024-09-07 23:22:48 --> Helper loaded: file_helper
INFO - 2024-09-07 23:22:48 --> Helper loaded: security_helper
INFO - 2024-09-07 23:22:48 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:22:48 --> Database Driver Class Initialized
INFO - 2024-09-07 23:22:48 --> Email Class Initialized
DEBUG - 2024-09-07 23:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:22:48 --> Helper loaded: form_helper
INFO - 2024-09-07 23:22:48 --> Form Validation Class Initialized
INFO - 2024-09-07 23:22:48 --> Controller Class Initialized
DEBUG - 2024-09-07 23:22:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:22:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:22:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:22:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:22:48 --> Final output sent to browser
DEBUG - 2024-09-07 23:22:48 --> Total execution time: 0.2257
INFO - 2024-09-07 23:22:56 --> Config Class Initialized
INFO - 2024-09-07 23:22:56 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:22:56 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:22:56 --> Utf8 Class Initialized
INFO - 2024-09-07 23:22:56 --> URI Class Initialized
INFO - 2024-09-07 23:22:56 --> Router Class Initialized
INFO - 2024-09-07 23:22:56 --> Output Class Initialized
INFO - 2024-09-07 23:22:56 --> Security Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:22:56 --> Input Class Initialized
INFO - 2024-09-07 23:22:56 --> Language Class Initialized
INFO - 2024-09-07 23:22:56 --> Loader Class Initialized
INFO - 2024-09-07 23:22:56 --> Helper loaded: url_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: file_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: security_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:22:56 --> Database Driver Class Initialized
INFO - 2024-09-07 23:22:56 --> Email Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:22:56 --> Helper loaded: form_helper
INFO - 2024-09-07 23:22:56 --> Form Validation Class Initialized
INFO - 2024-09-07 23:22:56 --> Controller Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:22:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-07 23:22:56 --> Config Class Initialized
INFO - 2024-09-07 23:22:56 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:22:56 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:22:56 --> Utf8 Class Initialized
INFO - 2024-09-07 23:22:56 --> URI Class Initialized
INFO - 2024-09-07 23:22:56 --> Router Class Initialized
INFO - 2024-09-07 23:22:56 --> Output Class Initialized
INFO - 2024-09-07 23:22:56 --> Security Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:22:56 --> Input Class Initialized
INFO - 2024-09-07 23:22:56 --> Language Class Initialized
INFO - 2024-09-07 23:22:56 --> Loader Class Initialized
INFO - 2024-09-07 23:22:56 --> Helper loaded: url_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: file_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: security_helper
INFO - 2024-09-07 23:22:56 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:22:56 --> Database Driver Class Initialized
INFO - 2024-09-07 23:22:56 --> Email Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:22:56 --> Helper loaded: form_helper
INFO - 2024-09-07 23:22:56 --> Form Validation Class Initialized
INFO - 2024-09-07 23:22:56 --> Controller Class Initialized
DEBUG - 2024-09-07 23:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:22:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:22:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:22:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:22:56 --> Final output sent to browser
DEBUG - 2024-09-07 23:22:56 --> Total execution time: 0.2111
INFO - 2024-09-07 23:23:01 --> Config Class Initialized
INFO - 2024-09-07 23:23:01 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:23:01 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:23:01 --> Utf8 Class Initialized
INFO - 2024-09-07 23:23:01 --> URI Class Initialized
INFO - 2024-09-07 23:23:01 --> Router Class Initialized
INFO - 2024-09-07 23:23:01 --> Output Class Initialized
INFO - 2024-09-07 23:23:01 --> Security Class Initialized
DEBUG - 2024-09-07 23:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:23:01 --> Input Class Initialized
INFO - 2024-09-07 23:23:01 --> Language Class Initialized
INFO - 2024-09-07 23:23:01 --> Loader Class Initialized
INFO - 2024-09-07 23:23:01 --> Helper loaded: url_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: file_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: security_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:23:01 --> Database Driver Class Initialized
INFO - 2024-09-07 23:23:01 --> Email Class Initialized
DEBUG - 2024-09-07 23:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:23:01 --> Helper loaded: form_helper
INFO - 2024-09-07 23:23:01 --> Form Validation Class Initialized
INFO - 2024-09-07 23:23:01 --> Controller Class Initialized
DEBUG - 2024-09-07 23:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:23:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-07 23:23:01 --> Config Class Initialized
INFO - 2024-09-07 23:23:01 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:23:01 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:23:01 --> Utf8 Class Initialized
INFO - 2024-09-07 23:23:01 --> URI Class Initialized
INFO - 2024-09-07 23:23:01 --> Router Class Initialized
INFO - 2024-09-07 23:23:01 --> Output Class Initialized
INFO - 2024-09-07 23:23:01 --> Security Class Initialized
DEBUG - 2024-09-07 23:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:23:01 --> Input Class Initialized
INFO - 2024-09-07 23:23:01 --> Language Class Initialized
INFO - 2024-09-07 23:23:01 --> Loader Class Initialized
INFO - 2024-09-07 23:23:01 --> Helper loaded: url_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: file_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: security_helper
INFO - 2024-09-07 23:23:01 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:23:01 --> Database Driver Class Initialized
INFO - 2024-09-07 23:23:02 --> Email Class Initialized
DEBUG - 2024-09-07 23:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:23:02 --> Helper loaded: form_helper
INFO - 2024-09-07 23:23:02 --> Form Validation Class Initialized
INFO - 2024-09-07 23:23:02 --> Controller Class Initialized
INFO - 2024-09-07 23:23:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-07 23:23:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-07 23:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-07 23:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-07 23:23:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-07 23:23:02 --> Final output sent to browser
DEBUG - 2024-09-07 23:23:02 --> Total execution time: 0.6032
INFO - 2024-09-07 23:23:29 --> Config Class Initialized
INFO - 2024-09-07 23:23:29 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:23:29 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:23:29 --> Utf8 Class Initialized
INFO - 2024-09-07 23:23:29 --> URI Class Initialized
DEBUG - 2024-09-07 23:23:29 --> No URI present. Default controller set.
INFO - 2024-09-07 23:23:29 --> Router Class Initialized
INFO - 2024-09-07 23:23:29 --> Output Class Initialized
INFO - 2024-09-07 23:23:29 --> Security Class Initialized
DEBUG - 2024-09-07 23:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:23:29 --> Input Class Initialized
INFO - 2024-09-07 23:23:29 --> Language Class Initialized
INFO - 2024-09-07 23:23:29 --> Loader Class Initialized
INFO - 2024-09-07 23:23:29 --> Helper loaded: url_helper
INFO - 2024-09-07 23:23:29 --> Helper loaded: file_helper
INFO - 2024-09-07 23:23:29 --> Helper loaded: security_helper
INFO - 2024-09-07 23:23:29 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:23:29 --> Database Driver Class Initialized
INFO - 2024-09-07 23:23:29 --> Email Class Initialized
DEBUG - 2024-09-07 23:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:23:29 --> Helper loaded: form_helper
INFO - 2024-09-07 23:23:29 --> Form Validation Class Initialized
INFO - 2024-09-07 23:23:29 --> Controller Class Initialized
DEBUG - 2024-09-07 23:23:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:23:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:23:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:23:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:23:29 --> Final output sent to browser
DEBUG - 2024-09-07 23:23:29 --> Total execution time: 0.2206
INFO - 2024-09-07 23:43:16 --> Config Class Initialized
INFO - 2024-09-07 23:43:16 --> Hooks Class Initialized
DEBUG - 2024-09-07 23:43:16 --> UTF-8 Support Enabled
INFO - 2024-09-07 23:43:16 --> Utf8 Class Initialized
INFO - 2024-09-07 23:43:16 --> URI Class Initialized
DEBUG - 2024-09-07 23:43:16 --> No URI present. Default controller set.
INFO - 2024-09-07 23:43:16 --> Router Class Initialized
INFO - 2024-09-07 23:43:16 --> Output Class Initialized
INFO - 2024-09-07 23:43:16 --> Security Class Initialized
DEBUG - 2024-09-07 23:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 23:43:16 --> Input Class Initialized
INFO - 2024-09-07 23:43:16 --> Language Class Initialized
INFO - 2024-09-07 23:43:16 --> Loader Class Initialized
INFO - 2024-09-07 23:43:16 --> Helper loaded: url_helper
INFO - 2024-09-07 23:43:16 --> Helper loaded: file_helper
INFO - 2024-09-07 23:43:16 --> Helper loaded: security_helper
INFO - 2024-09-07 23:43:16 --> Helper loaded: wpu_helper
INFO - 2024-09-07 23:43:16 --> Database Driver Class Initialized
INFO - 2024-09-07 23:43:16 --> Email Class Initialized
DEBUG - 2024-09-07 23:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-07 23:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 23:43:16 --> Helper loaded: form_helper
INFO - 2024-09-07 23:43:16 --> Form Validation Class Initialized
INFO - 2024-09-07 23:43:16 --> Controller Class Initialized
DEBUG - 2024-09-07 23:43:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-07 23:43:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-07 23:43:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-07 23:43:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-07 23:43:16 --> Final output sent to browser
DEBUG - 2024-09-07 23:43:16 --> Total execution time: 0.2205
