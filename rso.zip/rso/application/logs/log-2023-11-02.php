<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-02 03:42:00 --> Query error: Unknown column 'jatuh_tempo' in 'where clause' - Invalid query: SELECT COUNT(*) as jatuh_tempo FROM tbl_faktur WHERE DATEDIFF(jatuh_tempo, CURDATE()) = 10
ERROR - 2023-11-02 03:42:22 --> Query error: Unknown column 'jatuh_tempo' in 'where clause' - Invalid query: SELECT COUNT(*) as jatuh_tempo FROM tbl_faktur WHERE DATEDIFF(jatuh_tempo, CURDATE()) = 10
ERROR - 2023-11-02 03:42:23 --> Query error: Unknown column 'jatuh_tempo' in 'where clause' - Invalid query: SELECT COUNT(*) as jatuh_tempo FROM tbl_faktur WHERE DATEDIFF(jatuh_tempo, CURDATE()) = 10
ERROR - 2023-11-02 03:42:38 --> Query error: Unknown column 'tbl_faktur' in 'where clause' - Invalid query: SELECT COUNT(*) as jatuh_tempo FROM tbl_faktur WHERE DATEDIFF(tbl_faktur, CURDATE()) = 10
