<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-20 00:08:45 --> Config Class Initialized
INFO - 2024-10-20 00:08:45 --> Hooks Class Initialized
DEBUG - 2024-10-20 00:08:45 --> UTF-8 Support Enabled
INFO - 2024-10-20 00:08:45 --> Utf8 Class Initialized
INFO - 2024-10-20 00:08:45 --> URI Class Initialized
DEBUG - 2024-10-20 00:08:45 --> No URI present. Default controller set.
INFO - 2024-10-20 00:08:45 --> Router Class Initialized
INFO - 2024-10-20 00:08:45 --> Output Class Initialized
INFO - 2024-10-20 00:08:45 --> Security Class Initialized
DEBUG - 2024-10-20 00:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 00:08:46 --> Input Class Initialized
INFO - 2024-10-20 00:08:46 --> Language Class Initialized
INFO - 2024-10-20 00:08:46 --> Loader Class Initialized
INFO - 2024-10-20 00:08:46 --> Helper loaded: url_helper
INFO - 2024-10-20 00:08:46 --> Helper loaded: file_helper
INFO - 2024-10-20 00:08:46 --> Helper loaded: security_helper
INFO - 2024-10-20 00:08:46 --> Helper loaded: wpu_helper
INFO - 2024-10-20 00:08:46 --> Database Driver Class Initialized
INFO - 2024-10-20 00:08:46 --> Email Class Initialized
DEBUG - 2024-10-20 00:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 00:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 00:08:46 --> Helper loaded: form_helper
INFO - 2024-10-20 00:08:46 --> Form Validation Class Initialized
INFO - 2024-10-20 00:08:46 --> Controller Class Initialized
DEBUG - 2024-10-20 00:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 00:08:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 00:08:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 00:08:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 00:08:46 --> Final output sent to browser
DEBUG - 2024-10-20 00:08:46 --> Total execution time: 0.2364
INFO - 2024-10-20 06:18:16 --> Config Class Initialized
INFO - 2024-10-20 06:18:16 --> Hooks Class Initialized
DEBUG - 2024-10-20 06:18:16 --> UTF-8 Support Enabled
INFO - 2024-10-20 06:18:16 --> Utf8 Class Initialized
INFO - 2024-10-20 06:18:16 --> URI Class Initialized
DEBUG - 2024-10-20 06:18:16 --> No URI present. Default controller set.
INFO - 2024-10-20 06:18:16 --> Router Class Initialized
INFO - 2024-10-20 06:18:16 --> Output Class Initialized
INFO - 2024-10-20 06:18:16 --> Security Class Initialized
DEBUG - 2024-10-20 06:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 06:18:16 --> Input Class Initialized
INFO - 2024-10-20 06:18:16 --> Language Class Initialized
INFO - 2024-10-20 06:18:16 --> Loader Class Initialized
INFO - 2024-10-20 06:18:16 --> Helper loaded: url_helper
INFO - 2024-10-20 06:18:16 --> Helper loaded: file_helper
INFO - 2024-10-20 06:18:16 --> Helper loaded: security_helper
INFO - 2024-10-20 06:18:16 --> Helper loaded: wpu_helper
INFO - 2024-10-20 06:18:16 --> Database Driver Class Initialized
INFO - 2024-10-20 06:18:16 --> Email Class Initialized
DEBUG - 2024-10-20 06:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 06:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 06:18:16 --> Helper loaded: form_helper
INFO - 2024-10-20 06:18:16 --> Form Validation Class Initialized
INFO - 2024-10-20 06:18:16 --> Controller Class Initialized
DEBUG - 2024-10-20 06:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 06:18:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 06:18:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 06:18:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 06:18:16 --> Final output sent to browser
DEBUG - 2024-10-20 06:18:16 --> Total execution time: 0.2329
INFO - 2024-10-20 06:18:17 --> Config Class Initialized
INFO - 2024-10-20 06:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-20 06:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-20 06:18:17 --> Utf8 Class Initialized
INFO - 2024-10-20 06:18:17 --> URI Class Initialized
DEBUG - 2024-10-20 06:18:17 --> No URI present. Default controller set.
INFO - 2024-10-20 06:18:17 --> Router Class Initialized
INFO - 2024-10-20 06:18:17 --> Output Class Initialized
INFO - 2024-10-20 06:18:17 --> Security Class Initialized
DEBUG - 2024-10-20 06:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 06:18:17 --> Input Class Initialized
INFO - 2024-10-20 06:18:17 --> Language Class Initialized
INFO - 2024-10-20 06:18:17 --> Loader Class Initialized
INFO - 2024-10-20 06:18:17 --> Helper loaded: url_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: file_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: security_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: wpu_helper
INFO - 2024-10-20 06:18:17 --> Database Driver Class Initialized
INFO - 2024-10-20 06:18:17 --> Email Class Initialized
DEBUG - 2024-10-20 06:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 06:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 06:18:17 --> Helper loaded: form_helper
INFO - 2024-10-20 06:18:17 --> Form Validation Class Initialized
INFO - 2024-10-20 06:18:17 --> Controller Class Initialized
DEBUG - 2024-10-20 06:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 06:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 06:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 06:18:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 06:18:17 --> Final output sent to browser
DEBUG - 2024-10-20 06:18:17 --> Total execution time: 0.2422
INFO - 2024-10-20 06:18:17 --> Config Class Initialized
INFO - 2024-10-20 06:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-20 06:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-20 06:18:17 --> Utf8 Class Initialized
INFO - 2024-10-20 06:18:17 --> URI Class Initialized
DEBUG - 2024-10-20 06:18:17 --> No URI present. Default controller set.
INFO - 2024-10-20 06:18:17 --> Router Class Initialized
INFO - 2024-10-20 06:18:17 --> Output Class Initialized
INFO - 2024-10-20 06:18:17 --> Security Class Initialized
DEBUG - 2024-10-20 06:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 06:18:17 --> Input Class Initialized
INFO - 2024-10-20 06:18:17 --> Language Class Initialized
INFO - 2024-10-20 06:18:17 --> Loader Class Initialized
INFO - 2024-10-20 06:18:17 --> Helper loaded: url_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: file_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: security_helper
INFO - 2024-10-20 06:18:17 --> Helper loaded: wpu_helper
INFO - 2024-10-20 06:18:17 --> Database Driver Class Initialized
INFO - 2024-10-20 06:18:18 --> Email Class Initialized
DEBUG - 2024-10-20 06:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 06:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 06:18:18 --> Helper loaded: form_helper
INFO - 2024-10-20 06:18:18 --> Form Validation Class Initialized
INFO - 2024-10-20 06:18:18 --> Controller Class Initialized
DEBUG - 2024-10-20 06:18:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 06:18:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 06:18:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 06:18:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 06:18:18 --> Final output sent to browser
DEBUG - 2024-10-20 06:18:18 --> Total execution time: 0.2227
INFO - 2024-10-20 08:46:50 --> Config Class Initialized
INFO - 2024-10-20 08:46:50 --> Hooks Class Initialized
DEBUG - 2024-10-20 08:46:50 --> UTF-8 Support Enabled
INFO - 2024-10-20 08:46:50 --> Utf8 Class Initialized
INFO - 2024-10-20 08:46:50 --> URI Class Initialized
DEBUG - 2024-10-20 08:46:50 --> No URI present. Default controller set.
INFO - 2024-10-20 08:46:50 --> Router Class Initialized
INFO - 2024-10-20 08:46:50 --> Output Class Initialized
INFO - 2024-10-20 08:46:50 --> Security Class Initialized
DEBUG - 2024-10-20 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 08:46:50 --> Input Class Initialized
INFO - 2024-10-20 08:46:50 --> Language Class Initialized
INFO - 2024-10-20 08:46:50 --> Loader Class Initialized
INFO - 2024-10-20 08:46:50 --> Helper loaded: url_helper
INFO - 2024-10-20 08:46:50 --> Helper loaded: file_helper
INFO - 2024-10-20 08:46:50 --> Helper loaded: security_helper
INFO - 2024-10-20 08:46:50 --> Helper loaded: wpu_helper
INFO - 2024-10-20 08:46:50 --> Database Driver Class Initialized
INFO - 2024-10-20 08:46:50 --> Email Class Initialized
DEBUG - 2024-10-20 08:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 08:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 08:46:50 --> Helper loaded: form_helper
INFO - 2024-10-20 08:46:50 --> Form Validation Class Initialized
INFO - 2024-10-20 08:46:50 --> Controller Class Initialized
DEBUG - 2024-10-20 08:46:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 08:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 08:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 08:46:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 08:46:50 --> Final output sent to browser
DEBUG - 2024-10-20 08:46:50 --> Total execution time: 0.2298
INFO - 2024-10-20 14:01:47 --> Config Class Initialized
INFO - 2024-10-20 14:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-20 14:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-20 14:01:47 --> Utf8 Class Initialized
INFO - 2024-10-20 14:01:47 --> URI Class Initialized
DEBUG - 2024-10-20 14:01:47 --> No URI present. Default controller set.
INFO - 2024-10-20 14:01:47 --> Router Class Initialized
INFO - 2024-10-20 14:01:47 --> Output Class Initialized
INFO - 2024-10-20 14:01:47 --> Security Class Initialized
DEBUG - 2024-10-20 14:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 14:01:47 --> Input Class Initialized
INFO - 2024-10-20 14:01:47 --> Language Class Initialized
INFO - 2024-10-20 14:01:47 --> Loader Class Initialized
INFO - 2024-10-20 14:01:47 --> Helper loaded: url_helper
INFO - 2024-10-20 14:01:47 --> Helper loaded: file_helper
INFO - 2024-10-20 14:01:47 --> Helper loaded: security_helper
INFO - 2024-10-20 14:01:47 --> Helper loaded: wpu_helper
INFO - 2024-10-20 14:01:47 --> Database Driver Class Initialized
INFO - 2024-10-20 14:01:48 --> Email Class Initialized
DEBUG - 2024-10-20 14:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 14:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 14:01:48 --> Helper loaded: form_helper
INFO - 2024-10-20 14:01:48 --> Form Validation Class Initialized
INFO - 2024-10-20 14:01:48 --> Controller Class Initialized
DEBUG - 2024-10-20 14:01:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 14:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 14:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 14:01:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 14:01:48 --> Final output sent to browser
DEBUG - 2024-10-20 14:01:48 --> Total execution time: 0.2394
INFO - 2024-10-20 14:06:25 --> Config Class Initialized
INFO - 2024-10-20 14:06:25 --> Hooks Class Initialized
DEBUG - 2024-10-20 14:06:25 --> UTF-8 Support Enabled
INFO - 2024-10-20 14:06:25 --> Utf8 Class Initialized
INFO - 2024-10-20 14:06:25 --> URI Class Initialized
DEBUG - 2024-10-20 14:06:25 --> No URI present. Default controller set.
INFO - 2024-10-20 14:06:25 --> Router Class Initialized
INFO - 2024-10-20 14:06:25 --> Output Class Initialized
INFO - 2024-10-20 14:06:25 --> Security Class Initialized
DEBUG - 2024-10-20 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 14:06:25 --> Input Class Initialized
INFO - 2024-10-20 14:06:25 --> Language Class Initialized
INFO - 2024-10-20 14:06:25 --> Loader Class Initialized
INFO - 2024-10-20 14:06:25 --> Helper loaded: url_helper
INFO - 2024-10-20 14:06:25 --> Helper loaded: file_helper
INFO - 2024-10-20 14:06:25 --> Helper loaded: security_helper
INFO - 2024-10-20 14:06:25 --> Helper loaded: wpu_helper
INFO - 2024-10-20 14:06:25 --> Database Driver Class Initialized
INFO - 2024-10-20 14:06:25 --> Email Class Initialized
DEBUG - 2024-10-20 14:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 14:06:25 --> Helper loaded: form_helper
INFO - 2024-10-20 14:06:25 --> Form Validation Class Initialized
INFO - 2024-10-20 14:06:25 --> Controller Class Initialized
DEBUG - 2024-10-20 14:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 14:06:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 14:06:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 14:06:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 14:06:25 --> Final output sent to browser
DEBUG - 2024-10-20 14:06:25 --> Total execution time: 0.2285
INFO - 2024-10-20 18:24:41 --> Config Class Initialized
INFO - 2024-10-20 18:24:41 --> Hooks Class Initialized
DEBUG - 2024-10-20 18:24:41 --> UTF-8 Support Enabled
INFO - 2024-10-20 18:24:41 --> Utf8 Class Initialized
INFO - 2024-10-20 18:24:41 --> URI Class Initialized
DEBUG - 2024-10-20 18:24:41 --> No URI present. Default controller set.
INFO - 2024-10-20 18:24:41 --> Router Class Initialized
INFO - 2024-10-20 18:24:41 --> Output Class Initialized
INFO - 2024-10-20 18:24:41 --> Security Class Initialized
DEBUG - 2024-10-20 18:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 18:24:41 --> Input Class Initialized
INFO - 2024-10-20 18:24:41 --> Language Class Initialized
INFO - 2024-10-20 18:24:41 --> Loader Class Initialized
INFO - 2024-10-20 18:24:41 --> Helper loaded: url_helper
INFO - 2024-10-20 18:24:41 --> Helper loaded: file_helper
INFO - 2024-10-20 18:24:41 --> Helper loaded: security_helper
INFO - 2024-10-20 18:24:41 --> Helper loaded: wpu_helper
INFO - 2024-10-20 18:24:41 --> Database Driver Class Initialized
INFO - 2024-10-20 18:24:41 --> Email Class Initialized
DEBUG - 2024-10-20 18:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 18:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 18:24:41 --> Helper loaded: form_helper
INFO - 2024-10-20 18:24:41 --> Form Validation Class Initialized
INFO - 2024-10-20 18:24:41 --> Controller Class Initialized
DEBUG - 2024-10-20 18:24:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 18:24:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 18:24:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 18:24:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 18:24:41 --> Final output sent to browser
DEBUG - 2024-10-20 18:24:41 --> Total execution time: 0.2244
INFO - 2024-10-20 18:24:49 --> Config Class Initialized
INFO - 2024-10-20 18:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-20 18:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-20 18:24:49 --> Utf8 Class Initialized
INFO - 2024-10-20 18:24:49 --> URI Class Initialized
INFO - 2024-10-20 18:24:49 --> Router Class Initialized
INFO - 2024-10-20 18:24:49 --> Output Class Initialized
INFO - 2024-10-20 18:24:49 --> Security Class Initialized
DEBUG - 2024-10-20 18:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 18:24:49 --> Input Class Initialized
INFO - 2024-10-20 18:24:49 --> Language Class Initialized
INFO - 2024-10-20 18:24:49 --> Loader Class Initialized
INFO - 2024-10-20 18:24:49 --> Helper loaded: url_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: file_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: security_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: wpu_helper
INFO - 2024-10-20 18:24:49 --> Database Driver Class Initialized
INFO - 2024-10-20 18:24:49 --> Email Class Initialized
DEBUG - 2024-10-20 18:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 18:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 18:24:49 --> Helper loaded: form_helper
INFO - 2024-10-20 18:24:49 --> Form Validation Class Initialized
INFO - 2024-10-20 18:24:49 --> Controller Class Initialized
DEBUG - 2024-10-20 18:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 18:24:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-20 18:24:49 --> Config Class Initialized
INFO - 2024-10-20 18:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-20 18:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-20 18:24:49 --> Utf8 Class Initialized
INFO - 2024-10-20 18:24:49 --> URI Class Initialized
INFO - 2024-10-20 18:24:49 --> Router Class Initialized
INFO - 2024-10-20 18:24:49 --> Output Class Initialized
INFO - 2024-10-20 18:24:49 --> Security Class Initialized
DEBUG - 2024-10-20 18:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 18:24:49 --> Input Class Initialized
INFO - 2024-10-20 18:24:49 --> Language Class Initialized
INFO - 2024-10-20 18:24:49 --> Loader Class Initialized
INFO - 2024-10-20 18:24:49 --> Helper loaded: url_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: file_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: security_helper
INFO - 2024-10-20 18:24:49 --> Helper loaded: wpu_helper
INFO - 2024-10-20 18:24:49 --> Database Driver Class Initialized
INFO - 2024-10-20 18:24:50 --> Email Class Initialized
DEBUG - 2024-10-20 18:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 18:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 18:24:50 --> Helper loaded: form_helper
INFO - 2024-10-20 18:24:50 --> Form Validation Class Initialized
INFO - 2024-10-20 18:24:50 --> Controller Class Initialized
DEBUG - 2024-10-20 18:24:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 18:24:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 18:24:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 18:24:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 18:24:50 --> Final output sent to browser
DEBUG - 2024-10-20 18:24:50 --> Total execution time: 0.2395
INFO - 2024-10-20 18:24:55 --> Config Class Initialized
INFO - 2024-10-20 18:24:55 --> Hooks Class Initialized
DEBUG - 2024-10-20 18:24:55 --> UTF-8 Support Enabled
INFO - 2024-10-20 18:24:55 --> Utf8 Class Initialized
INFO - 2024-10-20 18:24:55 --> URI Class Initialized
INFO - 2024-10-20 18:24:55 --> Router Class Initialized
INFO - 2024-10-20 18:24:55 --> Output Class Initialized
INFO - 2024-10-20 18:24:55 --> Security Class Initialized
DEBUG - 2024-10-20 18:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 18:24:55 --> Input Class Initialized
INFO - 2024-10-20 18:24:55 --> Language Class Initialized
INFO - 2024-10-20 18:24:55 --> Loader Class Initialized
INFO - 2024-10-20 18:24:55 --> Helper loaded: url_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: file_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: security_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: wpu_helper
INFO - 2024-10-20 18:24:55 --> Database Driver Class Initialized
INFO - 2024-10-20 18:24:55 --> Email Class Initialized
DEBUG - 2024-10-20 18:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 18:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 18:24:55 --> Helper loaded: form_helper
INFO - 2024-10-20 18:24:55 --> Form Validation Class Initialized
INFO - 2024-10-20 18:24:55 --> Controller Class Initialized
DEBUG - 2024-10-20 18:24:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 18:24:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-10-20 18:24:55 --> Config Class Initialized
INFO - 2024-10-20 18:24:55 --> Hooks Class Initialized
DEBUG - 2024-10-20 18:24:55 --> UTF-8 Support Enabled
INFO - 2024-10-20 18:24:55 --> Utf8 Class Initialized
INFO - 2024-10-20 18:24:55 --> URI Class Initialized
INFO - 2024-10-20 18:24:55 --> Router Class Initialized
INFO - 2024-10-20 18:24:55 --> Output Class Initialized
INFO - 2024-10-20 18:24:55 --> Security Class Initialized
DEBUG - 2024-10-20 18:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 18:24:55 --> Input Class Initialized
INFO - 2024-10-20 18:24:55 --> Language Class Initialized
INFO - 2024-10-20 18:24:55 --> Loader Class Initialized
INFO - 2024-10-20 18:24:55 --> Helper loaded: url_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: file_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: security_helper
INFO - 2024-10-20 18:24:55 --> Helper loaded: wpu_helper
INFO - 2024-10-20 18:24:55 --> Database Driver Class Initialized
INFO - 2024-10-20 18:24:56 --> Email Class Initialized
DEBUG - 2024-10-20 18:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 18:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 18:24:56 --> Helper loaded: form_helper
INFO - 2024-10-20 18:24:56 --> Form Validation Class Initialized
INFO - 2024-10-20 18:24:56 --> Controller Class Initialized
DEBUG - 2024-10-20 18:24:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 18:24:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 18:24:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 18:24:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 18:24:56 --> Final output sent to browser
DEBUG - 2024-10-20 18:24:56 --> Total execution time: 0.2278
INFO - 2024-10-20 19:03:09 --> Config Class Initialized
INFO - 2024-10-20 19:03:09 --> Hooks Class Initialized
DEBUG - 2024-10-20 19:03:09 --> UTF-8 Support Enabled
INFO - 2024-10-20 19:03:09 --> Utf8 Class Initialized
INFO - 2024-10-20 19:03:09 --> URI Class Initialized
DEBUG - 2024-10-20 19:03:09 --> No URI present. Default controller set.
INFO - 2024-10-20 19:03:09 --> Router Class Initialized
INFO - 2024-10-20 19:03:09 --> Output Class Initialized
INFO - 2024-10-20 19:03:09 --> Security Class Initialized
DEBUG - 2024-10-20 19:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 19:03:09 --> Input Class Initialized
INFO - 2024-10-20 19:03:09 --> Language Class Initialized
INFO - 2024-10-20 19:03:09 --> Loader Class Initialized
INFO - 2024-10-20 19:03:09 --> Helper loaded: url_helper
INFO - 2024-10-20 19:03:09 --> Helper loaded: file_helper
INFO - 2024-10-20 19:03:09 --> Helper loaded: security_helper
INFO - 2024-10-20 19:03:09 --> Helper loaded: wpu_helper
INFO - 2024-10-20 19:03:09 --> Database Driver Class Initialized
INFO - 2024-10-20 19:03:09 --> Email Class Initialized
DEBUG - 2024-10-20 19:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-20 19:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 19:03:09 --> Helper loaded: form_helper
INFO - 2024-10-20 19:03:09 --> Form Validation Class Initialized
INFO - 2024-10-20 19:03:09 --> Controller Class Initialized
DEBUG - 2024-10-20 19:03:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-20 19:03:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-20 19:03:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-20 19:03:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-20 19:03:09 --> Final output sent to browser
DEBUG - 2024-10-20 19:03:09 --> Total execution time: 0.2224
