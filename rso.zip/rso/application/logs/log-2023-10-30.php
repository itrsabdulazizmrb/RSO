<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-30 12:39:53 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-10-30 13:01:00 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-10-30 13:07:43 --> 404 Page Not Found: Data/cetak_kp
ERROR - 2023-10-30 13:08:18 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:09:02 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:19:27 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:35:22 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:35:55 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:35:56 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:39:57 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:40:01 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:40:03 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:40:04 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:40:32 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:40:34 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 13:42:16 --> 404 Page Not Found: Admin/adddetailfaktur
ERROR - 2023-10-30 15:03:43 --> 404 Page Not Found: Admin/barangmasuk
ERROR - 2023-10-30 16:54:59 --> 404 Page Not Found: Admin/adddetailfaktur
ERROR - 2023-10-30 17:00:18 --> 404 Page Not Found: Admin/adddetailfaktur
ERROR - 2023-10-30 18:13:13 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '2023-10-31', '200000', '30', 'Rp. 1.400.000', 'belum')
ERROR - 2023-10-30 18:14:10 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '2023-10-31', '200000', '30', 'Rp. 1.400.000', 'belum')
ERROR - 2023-10-30 18:14:18 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '', '200002', '30', '1.400.014', 'belum')
ERROR - 2023-10-30 18:25:49 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '2023-10-31', '100000', '10', '900000', 'belum')
ERROR - 2023-10-30 18:30:29 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '2023-10-31', '200000', '20', 'Rp. 1.600.000', 'belum')
ERROR - 2023-10-30 18:30:57 --> Query error: Column 'jumlah' cannot be null - Invalid query: INSERT INTO `tbl_detail_faktur` (`id_barang`, `no_faktur`, `nama_barang`, `jumlah`, `satuan`, `no_batch`, `expired`, `harga`, `diskon`, `total`, `status`) VALUES (NULL, '009.127-28.2018821', 'Kertas F4', NULL, 'Rim', '1', '2023-10-31', '200000', '10', '1800000', 'belum')
ERROR - 2023-10-30 18:31:38 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 604
ERROR - 2023-10-30 18:32:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2023-10-30 18:51:43 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 604
ERROR - 2023-10-30 18:51:54 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 604
ERROR - 2023-10-30 18:52:17 --> Severity: error --> Exception: Too few arguments to function Admin::detailfaktur(), 0 passed in C:\xampp\htdocs\simba\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\simba\application\controllers\Admin.php 604
ERROR - 2023-10-30 19:23:15 --> 404 Page Not Found: Data/detailfaktur
ERROR - 2023-10-30 19:25:19 --> Severity: error --> Exception: syntax error, unexpected '$no_faktur' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\simba\application\controllers\Admin.php 630
ERROR - 2023-10-30 19:29:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2023-10-30 19:43:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2023-10-30 19:44:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2023-10-30 19:44:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
