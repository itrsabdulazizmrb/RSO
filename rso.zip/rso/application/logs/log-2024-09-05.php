<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-05 06:07:35 --> Config Class Initialized
INFO - 2024-09-05 06:07:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:07:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:07:35 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:07:35 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:07:35 --> URI Class Initialized
ERROR - 2024-09-05 06:07:35 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:07:35 --> Router Class Initialized
INFO - 2024-09-05 06:07:35 --> Output Class Initialized
INFO - 2024-09-05 06:07:35 --> Security Class Initialized
DEBUG - 2024-09-05 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:07:35 --> Input Class Initialized
INFO - 2024-09-05 06:07:35 --> Language Class Initialized
ERROR - 2024-09-05 06:07:35 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:07:38 --> Config Class Initialized
INFO - 2024-09-05 06:07:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:07:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:07:38 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:07:38 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:07:38 --> URI Class Initialized
ERROR - 2024-09-05 06:07:38 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:07:38 --> Router Class Initialized
INFO - 2024-09-05 06:07:38 --> Output Class Initialized
INFO - 2024-09-05 06:07:38 --> Security Class Initialized
DEBUG - 2024-09-05 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:07:38 --> Input Class Initialized
INFO - 2024-09-05 06:07:38 --> Language Class Initialized
ERROR - 2024-09-05 06:07:38 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:07:55 --> Config Class Initialized
INFO - 2024-09-05 06:07:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:07:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:07:55 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:07:55 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:07:55 --> URI Class Initialized
ERROR - 2024-09-05 06:07:55 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:07:55 --> Router Class Initialized
INFO - 2024-09-05 06:07:55 --> Output Class Initialized
INFO - 2024-09-05 06:07:55 --> Security Class Initialized
DEBUG - 2024-09-05 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:07:55 --> Input Class Initialized
INFO - 2024-09-05 06:07:55 --> Language Class Initialized
ERROR - 2024-09-05 06:07:55 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:07:57 --> Config Class Initialized
INFO - 2024-09-05 06:07:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:07:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:07:57 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:07:57 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:07:57 --> URI Class Initialized
ERROR - 2024-09-05 06:07:57 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:07:57 --> Router Class Initialized
INFO - 2024-09-05 06:07:57 --> Output Class Initialized
INFO - 2024-09-05 06:07:57 --> Security Class Initialized
DEBUG - 2024-09-05 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:07:57 --> Input Class Initialized
INFO - 2024-09-05 06:07:57 --> Language Class Initialized
ERROR - 2024-09-05 06:07:57 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:43 --> Config Class Initialized
INFO - 2024-09-05 06:08:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:43 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:43 --> URI Class Initialized
ERROR - 2024-09-05 06:08:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:43 --> Router Class Initialized
INFO - 2024-09-05 06:08:43 --> Output Class Initialized
INFO - 2024-09-05 06:08:43 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:43 --> Input Class Initialized
INFO - 2024-09-05 06:08:43 --> Language Class Initialized
ERROR - 2024-09-05 06:08:43 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:43 --> Config Class Initialized
INFO - 2024-09-05 06:08:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:43 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:43 --> URI Class Initialized
ERROR - 2024-09-05 06:08:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:43 --> Router Class Initialized
INFO - 2024-09-05 06:08:43 --> Output Class Initialized
INFO - 2024-09-05 06:08:43 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:43 --> Input Class Initialized
INFO - 2024-09-05 06:08:43 --> Language Class Initialized
ERROR - 2024-09-05 06:08:43 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:44 --> Config Class Initialized
INFO - 2024-09-05 06:08:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:44 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:44 --> URI Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:44 --> Router Class Initialized
INFO - 2024-09-05 06:08:44 --> Output Class Initialized
INFO - 2024-09-05 06:08:44 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:44 --> Input Class Initialized
INFO - 2024-09-05 06:08:44 --> Language Class Initialized
ERROR - 2024-09-05 06:08:44 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:44 --> Config Class Initialized
INFO - 2024-09-05 06:08:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:44 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:44 --> URI Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:44 --> Router Class Initialized
INFO - 2024-09-05 06:08:44 --> Output Class Initialized
INFO - 2024-09-05 06:08:44 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:44 --> Input Class Initialized
INFO - 2024-09-05 06:08:44 --> Language Class Initialized
ERROR - 2024-09-05 06:08:44 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:44 --> Config Class Initialized
INFO - 2024-09-05 06:08:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:44 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:44 --> URI Class Initialized
ERROR - 2024-09-05 06:08:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:44 --> Router Class Initialized
INFO - 2024-09-05 06:08:44 --> Output Class Initialized
INFO - 2024-09-05 06:08:44 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:44 --> Input Class Initialized
INFO - 2024-09-05 06:08:44 --> Language Class Initialized
ERROR - 2024-09-05 06:08:44 --> 404 Page Not Found: /index
INFO - 2024-09-05 06:08:57 --> Config Class Initialized
INFO - 2024-09-05 06:08:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 06:08:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 06:08:57 --> Utf8 Class Initialized
ERROR - 2024-09-05 06:08:57 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 06:08:57 --> URI Class Initialized
ERROR - 2024-09-05 06:08:57 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 06:08:57 --> Router Class Initialized
INFO - 2024-09-05 06:08:57 --> Output Class Initialized
INFO - 2024-09-05 06:08:57 --> Security Class Initialized
DEBUG - 2024-09-05 06:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 06:08:57 --> Input Class Initialized
INFO - 2024-09-05 06:08:57 --> Language Class Initialized
INFO - 2024-09-05 06:08:57 --> Loader Class Initialized
INFO - 2024-09-05 06:08:57 --> Helper loaded: url_helper
INFO - 2024-09-05 06:08:57 --> Helper loaded: file_helper
INFO - 2024-09-05 06:08:57 --> Helper loaded: security_helper
INFO - 2024-09-05 06:08:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 06:08:57 --> Database Driver Class Initialized
INFO - 2024-09-05 06:08:57 --> Email Class Initialized
DEBUG - 2024-09-05 06:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 06:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 06:08:58 --> Helper loaded: form_helper
INFO - 2024-09-05 06:08:58 --> Form Validation Class Initialized
INFO - 2024-09-05 06:08:58 --> Controller Class Initialized
INFO - 2024-09-05 06:08:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 06:08:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 06:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 06:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 06:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 06:08:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 06:08:58 --> Final output sent to browser
DEBUG - 2024-09-05 06:08:58 --> Total execution time: 0.7760
INFO - 2024-09-05 07:09:35 --> Config Class Initialized
INFO - 2024-09-05 07:09:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:35 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:35 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:35 --> URI Class Initialized
ERROR - 2024-09-05 07:09:35 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 07:09:35 --> Router Class Initialized
INFO - 2024-09-05 07:09:35 --> Output Class Initialized
INFO - 2024-09-05 07:09:35 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:35 --> Input Class Initialized
INFO - 2024-09-05 07:09:35 --> Language Class Initialized
ERROR - 2024-09-05 07:09:35 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 07:09:35 --> Config Class Initialized
INFO - 2024-09-05 07:09:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:35 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:35 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:35 --> URI Class Initialized
ERROR - 2024-09-05 07:09:35 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 07:09:35 --> Router Class Initialized
INFO - 2024-09-05 07:09:35 --> Output Class Initialized
INFO - 2024-09-05 07:09:35 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:35 --> Input Class Initialized
INFO - 2024-09-05 07:09:35 --> Language Class Initialized
ERROR - 2024-09-05 07:09:35 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 07:09:36 --> Config Class Initialized
INFO - 2024-09-05 07:09:36 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:36 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:36 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:36 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:36 --> URI Class Initialized
ERROR - 2024-09-05 07:09:36 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 07:09:36 --> Router Class Initialized
INFO - 2024-09-05 07:09:36 --> Output Class Initialized
INFO - 2024-09-05 07:09:36 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:36 --> Input Class Initialized
INFO - 2024-09-05 07:09:36 --> Language Class Initialized
ERROR - 2024-09-05 07:09:36 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 07:09:37 --> Config Class Initialized
INFO - 2024-09-05 07:09:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:37 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:37 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:37 --> URI Class Initialized
ERROR - 2024-09-05 07:09:37 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 07:09:37 --> Router Class Initialized
INFO - 2024-09-05 07:09:37 --> Output Class Initialized
INFO - 2024-09-05 07:09:37 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:37 --> Input Class Initialized
INFO - 2024-09-05 07:09:37 --> Language Class Initialized
ERROR - 2024-09-05 07:09:37 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 07:09:40 --> Config Class Initialized
INFO - 2024-09-05 07:09:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:40 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:40 --> URI Class Initialized
ERROR - 2024-09-05 07:09:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 07:09:40 --> Router Class Initialized
INFO - 2024-09-05 07:09:40 --> Output Class Initialized
INFO - 2024-09-05 07:09:40 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:40 --> Input Class Initialized
INFO - 2024-09-05 07:09:40 --> Language Class Initialized
ERROR - 2024-09-05 07:09:40 --> 404 Page Not Found: Data/index
INFO - 2024-09-05 07:09:43 --> Config Class Initialized
INFO - 2024-09-05 07:09:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:09:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:09:43 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:09:43 --> URI Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:09:43 --> No URI present. Default controller set.
INFO - 2024-09-05 07:09:43 --> Router Class Initialized
INFO - 2024-09-05 07:09:43 --> Output Class Initialized
INFO - 2024-09-05 07:09:43 --> Security Class Initialized
DEBUG - 2024-09-05 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:09:43 --> Input Class Initialized
INFO - 2024-09-05 07:09:43 --> Language Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$config is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$log is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$exceptions is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$router is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$output is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$security is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$input is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
INFO - 2024-09-05 07:09:43 --> Loader Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$load is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 78
INFO - 2024-09-05 07:09:43 --> Helper loaded: url_helper
INFO - 2024-09-05 07:09:43 --> Helper loaded: file_helper
INFO - 2024-09-05 07:09:43 --> Helper loaded: security_helper
INFO - 2024-09-05 07:09:43 --> Helper loaded: wpu_helper
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 396
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\antrol\system\database\DB_driver.php 371
INFO - 2024-09-05 07:09:43 --> Database Driver Class Initialized
INFO - 2024-09-05 07:09:43 --> Email Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 132
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 292
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 166
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 235
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 315
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 356
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 282
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 289
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 304
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 314
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 315
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 316
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 317
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 375
DEBUG - 2024-09-05 07:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 110
ERROR - 2024-09-05 07:09:43 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 143
INFO - 2024-09-05 07:09:43 --> Session: Class initialized using 'files' driver.
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:09:43 --> Helper loaded: form_helper
INFO - 2024-09-05 07:09:43 --> Form Validation Class Initialized
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property Auth::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:09:43 --> Controller Class Initialized
DEBUG - 2024-09-05 07:09:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:09:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
INFO - 2024-09-05 07:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:09:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:09:43 --> Final output sent to browser
DEBUG - 2024-09-05 07:09:43 --> Total execution time: 0.2419
INFO - 2024-09-05 07:11:12 --> Config Class Initialized
INFO - 2024-09-05 07:11:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:11:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:11:12 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:11:12 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:11:12 --> URI Class Initialized
ERROR - 2024-09-05 07:11:12 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:11:12 --> No URI present. Default controller set.
INFO - 2024-09-05 07:11:12 --> Router Class Initialized
INFO - 2024-09-05 07:11:12 --> Output Class Initialized
INFO - 2024-09-05 07:11:12 --> Security Class Initialized
DEBUG - 2024-09-05 07:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:11:12 --> Input Class Initialized
INFO - 2024-09-05 07:11:12 --> Language Class Initialized
INFO - 2024-09-05 07:11:12 --> Loader Class Initialized
INFO - 2024-09-05 07:11:12 --> Helper loaded: url_helper
INFO - 2024-09-05 07:11:12 --> Helper loaded: file_helper
INFO - 2024-09-05 07:11:12 --> Helper loaded: security_helper
INFO - 2024-09-05 07:11:12 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:11:12 --> Database Driver Class Initialized
INFO - 2024-09-05 07:11:12 --> Email Class Initialized
DEBUG - 2024-09-05 07:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:11:12 --> Helper loaded: form_helper
INFO - 2024-09-05 07:11:12 --> Form Validation Class Initialized
INFO - 2024-09-05 07:11:12 --> Controller Class Initialized
DEBUG - 2024-09-05 07:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:11:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:11:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:11:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:11:12 --> Final output sent to browser
DEBUG - 2024-09-05 07:11:12 --> Total execution time: 0.1158
INFO - 2024-09-05 07:11:14 --> Config Class Initialized
INFO - 2024-09-05 07:11:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:11:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:11:14 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:11:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:11:14 --> URI Class Initialized
ERROR - 2024-09-05 07:11:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:11:14 --> No URI present. Default controller set.
INFO - 2024-09-05 07:11:14 --> Router Class Initialized
INFO - 2024-09-05 07:11:14 --> Output Class Initialized
INFO - 2024-09-05 07:11:14 --> Security Class Initialized
DEBUG - 2024-09-05 07:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:11:14 --> Input Class Initialized
INFO - 2024-09-05 07:11:14 --> Language Class Initialized
INFO - 2024-09-05 07:11:14 --> Loader Class Initialized
INFO - 2024-09-05 07:11:14 --> Helper loaded: url_helper
INFO - 2024-09-05 07:11:14 --> Helper loaded: file_helper
INFO - 2024-09-05 07:11:14 --> Helper loaded: security_helper
INFO - 2024-09-05 07:11:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:11:14 --> Database Driver Class Initialized
INFO - 2024-09-05 07:11:14 --> Email Class Initialized
DEBUG - 2024-09-05 07:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:11:14 --> Helper loaded: form_helper
INFO - 2024-09-05 07:11:14 --> Form Validation Class Initialized
INFO - 2024-09-05 07:11:14 --> Controller Class Initialized
DEBUG - 2024-09-05 07:11:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:11:14 --> Final output sent to browser
DEBUG - 2024-09-05 07:11:14 --> Total execution time: 0.0548
INFO - 2024-09-05 07:11:15 --> Config Class Initialized
INFO - 2024-09-05 07:11:15 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:11:15 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:11:15 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:11:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:11:15 --> URI Class Initialized
ERROR - 2024-09-05 07:11:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:11:15 --> No URI present. Default controller set.
INFO - 2024-09-05 07:11:15 --> Router Class Initialized
INFO - 2024-09-05 07:11:15 --> Output Class Initialized
INFO - 2024-09-05 07:11:15 --> Security Class Initialized
DEBUG - 2024-09-05 07:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:11:15 --> Input Class Initialized
INFO - 2024-09-05 07:11:15 --> Language Class Initialized
INFO - 2024-09-05 07:11:15 --> Loader Class Initialized
INFO - 2024-09-05 07:11:15 --> Helper loaded: url_helper
INFO - 2024-09-05 07:11:15 --> Helper loaded: file_helper
INFO - 2024-09-05 07:11:15 --> Helper loaded: security_helper
INFO - 2024-09-05 07:11:15 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:11:15 --> Database Driver Class Initialized
INFO - 2024-09-05 07:11:15 --> Email Class Initialized
DEBUG - 2024-09-05 07:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:11:15 --> Helper loaded: form_helper
INFO - 2024-09-05 07:11:15 --> Form Validation Class Initialized
INFO - 2024-09-05 07:11:15 --> Controller Class Initialized
DEBUG - 2024-09-05 07:11:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:11:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:11:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:11:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:11:15 --> Final output sent to browser
DEBUG - 2024-09-05 07:11:15 --> Total execution time: 0.0773
INFO - 2024-09-05 07:11:49 --> Config Class Initialized
INFO - 2024-09-05 07:11:49 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:11:49 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:11:49 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:11:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:11:49 --> URI Class Initialized
ERROR - 2024-09-05 07:11:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:11:49 --> No URI present. Default controller set.
INFO - 2024-09-05 07:11:49 --> Router Class Initialized
INFO - 2024-09-05 07:11:49 --> Output Class Initialized
INFO - 2024-09-05 07:11:49 --> Security Class Initialized
DEBUG - 2024-09-05 07:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:11:49 --> Input Class Initialized
INFO - 2024-09-05 07:11:49 --> Language Class Initialized
INFO - 2024-09-05 07:11:49 --> Loader Class Initialized
INFO - 2024-09-05 07:11:49 --> Helper loaded: url_helper
INFO - 2024-09-05 07:11:49 --> Helper loaded: file_helper
INFO - 2024-09-05 07:11:49 --> Helper loaded: security_helper
INFO - 2024-09-05 07:11:49 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:11:49 --> Database Driver Class Initialized
INFO - 2024-09-05 07:11:49 --> Email Class Initialized
DEBUG - 2024-09-05 07:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:11:49 --> Helper loaded: form_helper
INFO - 2024-09-05 07:11:49 --> Form Validation Class Initialized
INFO - 2024-09-05 07:11:49 --> Controller Class Initialized
DEBUG - 2024-09-05 07:11:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:11:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:11:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:11:49 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:11:49 --> Final output sent to browser
DEBUG - 2024-09-05 07:11:49 --> Total execution time: 0.0416
INFO - 2024-09-05 07:11:50 --> Config Class Initialized
INFO - 2024-09-05 07:11:50 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:11:50 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:11:50 --> Utf8 Class Initialized
ERROR - 2024-09-05 07:11:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 07:11:50 --> URI Class Initialized
ERROR - 2024-09-05 07:11:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:11:50 --> No URI present. Default controller set.
INFO - 2024-09-05 07:11:50 --> Router Class Initialized
INFO - 2024-09-05 07:11:50 --> Output Class Initialized
INFO - 2024-09-05 07:11:50 --> Security Class Initialized
DEBUG - 2024-09-05 07:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:11:50 --> Input Class Initialized
INFO - 2024-09-05 07:11:50 --> Language Class Initialized
INFO - 2024-09-05 07:11:50 --> Loader Class Initialized
INFO - 2024-09-05 07:11:50 --> Helper loaded: url_helper
INFO - 2024-09-05 07:11:50 --> Helper loaded: file_helper
INFO - 2024-09-05 07:11:50 --> Helper loaded: security_helper
INFO - 2024-09-05 07:11:50 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:11:50 --> Database Driver Class Initialized
INFO - 2024-09-05 07:11:50 --> Email Class Initialized
DEBUG - 2024-09-05 07:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:11:50 --> Helper loaded: form_helper
INFO - 2024-09-05 07:11:50 --> Form Validation Class Initialized
INFO - 2024-09-05 07:11:50 --> Controller Class Initialized
DEBUG - 2024-09-05 07:11:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:11:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:11:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:11:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:11:50 --> Final output sent to browser
DEBUG - 2024-09-05 07:11:50 --> Total execution time: 0.0439
INFO - 2024-09-05 07:14:03 --> Config Class Initialized
INFO - 2024-09-05 07:14:03 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:14:03 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:14:03 --> Utf8 Class Initialized
INFO - 2024-09-05 07:14:03 --> URI Class Initialized
ERROR - 2024-09-05 07:14:03 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
DEBUG - 2024-09-05 07:14:03 --> No URI present. Default controller set.
INFO - 2024-09-05 07:14:03 --> Router Class Initialized
INFO - 2024-09-05 07:14:03 --> Output Class Initialized
INFO - 2024-09-05 07:14:03 --> Security Class Initialized
DEBUG - 2024-09-05 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:14:03 --> Input Class Initialized
INFO - 2024-09-05 07:14:03 --> Language Class Initialized
INFO - 2024-09-05 07:14:03 --> Loader Class Initialized
INFO - 2024-09-05 07:14:03 --> Helper loaded: url_helper
INFO - 2024-09-05 07:14:03 --> Helper loaded: file_helper
INFO - 2024-09-05 07:14:03 --> Helper loaded: security_helper
INFO - 2024-09-05 07:14:03 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:14:03 --> Database Driver Class Initialized
INFO - 2024-09-05 07:14:03 --> Email Class Initialized
DEBUG - 2024-09-05 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:14:03 --> Helper loaded: form_helper
INFO - 2024-09-05 07:14:03 --> Form Validation Class Initialized
INFO - 2024-09-05 07:14:03 --> Controller Class Initialized
DEBUG - 2024-09-05 07:14:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:14:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:14:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:14:03 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:14:03 --> Final output sent to browser
DEBUG - 2024-09-05 07:14:03 --> Total execution time: 0.2454
INFO - 2024-09-05 07:14:20 --> Config Class Initialized
INFO - 2024-09-05 07:14:20 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:14:20 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:14:20 --> Utf8 Class Initialized
INFO - 2024-09-05 07:14:20 --> URI Class Initialized
DEBUG - 2024-09-05 07:14:21 --> No URI present. Default controller set.
INFO - 2024-09-05 07:14:21 --> Router Class Initialized
INFO - 2024-09-05 07:14:21 --> Output Class Initialized
INFO - 2024-09-05 07:14:21 --> Security Class Initialized
DEBUG - 2024-09-05 07:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:14:21 --> Input Class Initialized
INFO - 2024-09-05 07:14:21 --> Language Class Initialized
INFO - 2024-09-05 07:14:21 --> Loader Class Initialized
INFO - 2024-09-05 07:14:21 --> Helper loaded: url_helper
INFO - 2024-09-05 07:14:21 --> Helper loaded: file_helper
INFO - 2024-09-05 07:14:21 --> Helper loaded: security_helper
INFO - 2024-09-05 07:14:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:14:21 --> Database Driver Class Initialized
INFO - 2024-09-05 07:14:21 --> Email Class Initialized
DEBUG - 2024-09-05 07:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:14:21 --> Helper loaded: form_helper
INFO - 2024-09-05 07:14:21 --> Form Validation Class Initialized
INFO - 2024-09-05 07:14:21 --> Controller Class Initialized
DEBUG - 2024-09-05 07:14:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:14:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:14:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:14:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:14:21 --> Final output sent to browser
DEBUG - 2024-09-05 07:14:21 --> Total execution time: 0.1546
INFO - 2024-09-05 07:14:23 --> Config Class Initialized
INFO - 2024-09-05 07:14:23 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:14:23 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:14:23 --> Utf8 Class Initialized
INFO - 2024-09-05 07:14:23 --> URI Class Initialized
INFO - 2024-09-05 07:14:23 --> Router Class Initialized
INFO - 2024-09-05 07:14:23 --> Output Class Initialized
INFO - 2024-09-05 07:14:23 --> Security Class Initialized
DEBUG - 2024-09-05 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:14:23 --> Input Class Initialized
INFO - 2024-09-05 07:14:23 --> Language Class Initialized
INFO - 2024-09-05 07:14:23 --> Loader Class Initialized
INFO - 2024-09-05 07:14:23 --> Helper loaded: url_helper
INFO - 2024-09-05 07:14:23 --> Helper loaded: file_helper
INFO - 2024-09-05 07:14:23 --> Helper loaded: security_helper
INFO - 2024-09-05 07:14:23 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:14:23 --> Database Driver Class Initialized
INFO - 2024-09-05 07:14:23 --> Email Class Initialized
DEBUG - 2024-09-05 07:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:14:23 --> Helper loaded: form_helper
INFO - 2024-09-05 07:14:23 --> Form Validation Class Initialized
INFO - 2024-09-05 07:14:23 --> Controller Class Initialized
DEBUG - 2024-09-05 07:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:14:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2024-09-05 07:14:23 --> Severity: error --> Exception: Unknown column 'username' in 'where clause' C:\xampp\htdocs\antrol\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2024-09-05 07:28:13 --> Config Class Initialized
INFO - 2024-09-05 07:28:13 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:13 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:13 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:13 --> URI Class Initialized
INFO - 2024-09-05 07:28:13 --> Router Class Initialized
INFO - 2024-09-05 07:28:13 --> Output Class Initialized
INFO - 2024-09-05 07:28:13 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:13 --> Input Class Initialized
INFO - 2024-09-05 07:28:13 --> Language Class Initialized
INFO - 2024-09-05 07:28:13 --> Loader Class Initialized
INFO - 2024-09-05 07:28:13 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:13 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:13 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:13 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:13 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:13 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:28:13 --> Config Class Initialized
INFO - 2024-09-05 07:28:13 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:13 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:13 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:13 --> URI Class Initialized
INFO - 2024-09-05 07:28:13 --> Router Class Initialized
INFO - 2024-09-05 07:28:13 --> Output Class Initialized
INFO - 2024-09-05 07:28:13 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:13 --> Input Class Initialized
INFO - 2024-09-05 07:28:13 --> Language Class Initialized
INFO - 2024-09-05 07:28:13 --> Loader Class Initialized
INFO - 2024-09-05 07:28:13 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:13 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:13 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:13 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:13 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:13 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:13 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:28:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:28:13 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:28:13 --> Final output sent to browser
DEBUG - 2024-09-05 07:28:13 --> Total execution time: 0.0542
INFO - 2024-09-05 07:28:16 --> Config Class Initialized
INFO - 2024-09-05 07:28:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:16 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:16 --> URI Class Initialized
INFO - 2024-09-05 07:28:16 --> Router Class Initialized
INFO - 2024-09-05 07:28:16 --> Output Class Initialized
INFO - 2024-09-05 07:28:16 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:16 --> Input Class Initialized
INFO - 2024-09-05 07:28:16 --> Language Class Initialized
INFO - 2024-09-05 07:28:16 --> Loader Class Initialized
INFO - 2024-09-05 07:28:16 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:16 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:16 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:16 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:16 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:16 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:28:16 --> Config Class Initialized
INFO - 2024-09-05 07:28:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:16 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:16 --> URI Class Initialized
INFO - 2024-09-05 07:28:16 --> Router Class Initialized
INFO - 2024-09-05 07:28:16 --> Output Class Initialized
INFO - 2024-09-05 07:28:16 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:16 --> Input Class Initialized
INFO - 2024-09-05 07:28:16 --> Language Class Initialized
INFO - 2024-09-05 07:28:16 --> Loader Class Initialized
INFO - 2024-09-05 07:28:16 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:16 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:16 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:16 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:16 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:16 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:28:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:28:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:28:16 --> Final output sent to browser
DEBUG - 2024-09-05 07:28:16 --> Total execution time: 0.0505
INFO - 2024-09-05 07:28:17 --> Config Class Initialized
INFO - 2024-09-05 07:28:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:17 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:17 --> URI Class Initialized
INFO - 2024-09-05 07:28:17 --> Router Class Initialized
INFO - 2024-09-05 07:28:17 --> Output Class Initialized
INFO - 2024-09-05 07:28:17 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:17 --> Input Class Initialized
INFO - 2024-09-05 07:28:17 --> Language Class Initialized
INFO - 2024-09-05 07:28:17 --> Loader Class Initialized
INFO - 2024-09-05 07:28:17 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:17 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:17 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:17 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:17 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:17 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:28:17 --> Config Class Initialized
INFO - 2024-09-05 07:28:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:17 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:17 --> URI Class Initialized
INFO - 2024-09-05 07:28:17 --> Router Class Initialized
INFO - 2024-09-05 07:28:17 --> Output Class Initialized
INFO - 2024-09-05 07:28:17 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:17 --> Input Class Initialized
INFO - 2024-09-05 07:28:17 --> Language Class Initialized
INFO - 2024-09-05 07:28:17 --> Loader Class Initialized
INFO - 2024-09-05 07:28:17 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:17 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:17 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:17 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:17 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:17 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:28:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:28:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:28:17 --> Final output sent to browser
DEBUG - 2024-09-05 07:28:17 --> Total execution time: 0.0429
INFO - 2024-09-05 07:28:18 --> Config Class Initialized
INFO - 2024-09-05 07:28:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:18 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:18 --> URI Class Initialized
INFO - 2024-09-05 07:28:18 --> Router Class Initialized
INFO - 2024-09-05 07:28:18 --> Output Class Initialized
INFO - 2024-09-05 07:28:18 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:18 --> Input Class Initialized
INFO - 2024-09-05 07:28:18 --> Language Class Initialized
INFO - 2024-09-05 07:28:18 --> Loader Class Initialized
INFO - 2024-09-05 07:28:18 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:18 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:18 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:18 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:18 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:18 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:28:18 --> Config Class Initialized
INFO - 2024-09-05 07:28:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:18 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:18 --> URI Class Initialized
INFO - 2024-09-05 07:28:18 --> Router Class Initialized
INFO - 2024-09-05 07:28:18 --> Output Class Initialized
INFO - 2024-09-05 07:28:18 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:18 --> Input Class Initialized
INFO - 2024-09-05 07:28:18 --> Language Class Initialized
INFO - 2024-09-05 07:28:18 --> Loader Class Initialized
INFO - 2024-09-05 07:28:18 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:18 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:18 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:18 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:18 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:18 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:28:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:28:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:28:18 --> Final output sent to browser
DEBUG - 2024-09-05 07:28:18 --> Total execution time: 0.0454
INFO - 2024-09-05 07:28:21 --> Config Class Initialized
INFO - 2024-09-05 07:28:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:21 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:21 --> URI Class Initialized
INFO - 2024-09-05 07:28:21 --> Router Class Initialized
INFO - 2024-09-05 07:28:21 --> Output Class Initialized
INFO - 2024-09-05 07:28:21 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:21 --> Input Class Initialized
INFO - 2024-09-05 07:28:21 --> Language Class Initialized
INFO - 2024-09-05 07:28:21 --> Loader Class Initialized
INFO - 2024-09-05 07:28:21 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:21 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:21 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:21 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:21 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:21 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:28:21 --> Config Class Initialized
INFO - 2024-09-05 07:28:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:28:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:28:21 --> Utf8 Class Initialized
INFO - 2024-09-05 07:28:21 --> URI Class Initialized
INFO - 2024-09-05 07:28:21 --> Router Class Initialized
INFO - 2024-09-05 07:28:21 --> Output Class Initialized
INFO - 2024-09-05 07:28:21 --> Security Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:28:21 --> Input Class Initialized
INFO - 2024-09-05 07:28:21 --> Language Class Initialized
INFO - 2024-09-05 07:28:21 --> Loader Class Initialized
INFO - 2024-09-05 07:28:21 --> Helper loaded: url_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: file_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: security_helper
INFO - 2024-09-05 07:28:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:28:21 --> Database Driver Class Initialized
INFO - 2024-09-05 07:28:21 --> Email Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:28:21 --> Helper loaded: form_helper
INFO - 2024-09-05 07:28:21 --> Form Validation Class Initialized
INFO - 2024-09-05 07:28:21 --> Controller Class Initialized
DEBUG - 2024-09-05 07:28:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:28:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:28:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:28:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:28:21 --> Final output sent to browser
DEBUG - 2024-09-05 07:28:21 --> Total execution time: 0.0599
INFO - 2024-09-05 07:29:04 --> Config Class Initialized
INFO - 2024-09-05 07:29:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:04 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:04 --> URI Class Initialized
INFO - 2024-09-05 07:29:04 --> Router Class Initialized
INFO - 2024-09-05 07:29:04 --> Output Class Initialized
INFO - 2024-09-05 07:29:04 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:04 --> Input Class Initialized
INFO - 2024-09-05 07:29:04 --> Language Class Initialized
INFO - 2024-09-05 07:29:04 --> Loader Class Initialized
INFO - 2024-09-05 07:29:04 --> Helper loaded: url_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: file_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: security_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:29:04 --> Database Driver Class Initialized
INFO - 2024-09-05 07:29:04 --> Email Class Initialized
DEBUG - 2024-09-05 07:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:29:04 --> Helper loaded: form_helper
INFO - 2024-09-05 07:29:04 --> Form Validation Class Initialized
INFO - 2024-09-05 07:29:04 --> Controller Class Initialized
DEBUG - 2024-09-05 07:29:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:29:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:29:04 --> Config Class Initialized
INFO - 2024-09-05 07:29:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:04 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:04 --> URI Class Initialized
INFO - 2024-09-05 07:29:04 --> Router Class Initialized
INFO - 2024-09-05 07:29:04 --> Output Class Initialized
INFO - 2024-09-05 07:29:04 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:04 --> Input Class Initialized
INFO - 2024-09-05 07:29:04 --> Language Class Initialized
INFO - 2024-09-05 07:29:04 --> Loader Class Initialized
INFO - 2024-09-05 07:29:04 --> Helper loaded: url_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: file_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: security_helper
INFO - 2024-09-05 07:29:04 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:29:04 --> Database Driver Class Initialized
INFO - 2024-09-05 07:29:04 --> Email Class Initialized
DEBUG - 2024-09-05 07:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:29:04 --> Helper loaded: form_helper
INFO - 2024-09-05 07:29:04 --> Form Validation Class Initialized
INFO - 2024-09-05 07:29:04 --> Controller Class Initialized
INFO - 2024-09-05 07:29:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:29:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:29:04 --> Severity: error --> Exception: Table 'rsaz_sik.tbl_pesanan' doesn't exist C:\xampp\htdocs\antrol\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2024-09-05 07:29:07 --> Config Class Initialized
INFO - 2024-09-05 07:29:07 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:07 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:07 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:07 --> URI Class Initialized
INFO - 2024-09-05 07:29:07 --> Router Class Initialized
INFO - 2024-09-05 07:29:07 --> Output Class Initialized
INFO - 2024-09-05 07:29:07 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:07 --> Input Class Initialized
INFO - 2024-09-05 07:29:07 --> Language Class Initialized
INFO - 2024-09-05 07:29:07 --> Loader Class Initialized
INFO - 2024-09-05 07:29:07 --> Helper loaded: url_helper
INFO - 2024-09-05 07:29:07 --> Helper loaded: file_helper
INFO - 2024-09-05 07:29:07 --> Helper loaded: security_helper
INFO - 2024-09-05 07:29:07 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:29:07 --> Database Driver Class Initialized
INFO - 2024-09-05 07:29:07 --> Email Class Initialized
DEBUG - 2024-09-05 07:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:29:07 --> Helper loaded: form_helper
INFO - 2024-09-05 07:29:07 --> Form Validation Class Initialized
INFO - 2024-09-05 07:29:07 --> Controller Class Initialized
DEBUG - 2024-09-05 07:29:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:29:07 --> Config Class Initialized
INFO - 2024-09-05 07:29:07 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:07 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:07 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:07 --> URI Class Initialized
INFO - 2024-09-05 07:29:07 --> Router Class Initialized
INFO - 2024-09-05 07:29:07 --> Output Class Initialized
INFO - 2024-09-05 07:29:07 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:07 --> Input Class Initialized
INFO - 2024-09-05 07:29:07 --> Language Class Initialized
ERROR - 2024-09-05 07:29:07 --> 404 Page Not Found: User/index
INFO - 2024-09-05 07:29:10 --> Config Class Initialized
INFO - 2024-09-05 07:29:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:10 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:10 --> URI Class Initialized
INFO - 2024-09-05 07:29:10 --> Router Class Initialized
INFO - 2024-09-05 07:29:10 --> Output Class Initialized
INFO - 2024-09-05 07:29:10 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:10 --> Input Class Initialized
INFO - 2024-09-05 07:29:10 --> Language Class Initialized
INFO - 2024-09-05 07:29:10 --> Loader Class Initialized
INFO - 2024-09-05 07:29:10 --> Helper loaded: url_helper
INFO - 2024-09-05 07:29:10 --> Helper loaded: file_helper
INFO - 2024-09-05 07:29:10 --> Helper loaded: security_helper
INFO - 2024-09-05 07:29:10 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:29:10 --> Database Driver Class Initialized
INFO - 2024-09-05 07:29:10 --> Email Class Initialized
DEBUG - 2024-09-05 07:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:29:10 --> Helper loaded: form_helper
INFO - 2024-09-05 07:29:10 --> Form Validation Class Initialized
INFO - 2024-09-05 07:29:10 --> Controller Class Initialized
DEBUG - 2024-09-05 07:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:29:10 --> Config Class Initialized
INFO - 2024-09-05 07:29:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:10 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:10 --> URI Class Initialized
INFO - 2024-09-05 07:29:10 --> Router Class Initialized
INFO - 2024-09-05 07:29:10 --> Output Class Initialized
INFO - 2024-09-05 07:29:10 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:10 --> Input Class Initialized
INFO - 2024-09-05 07:29:10 --> Language Class Initialized
ERROR - 2024-09-05 07:29:10 --> 404 Page Not Found: User/index
INFO - 2024-09-05 07:29:59 --> Config Class Initialized
INFO - 2024-09-05 07:29:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:59 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:59 --> URI Class Initialized
INFO - 2024-09-05 07:29:59 --> Router Class Initialized
INFO - 2024-09-05 07:29:59 --> Output Class Initialized
INFO - 2024-09-05 07:29:59 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:59 --> Input Class Initialized
INFO - 2024-09-05 07:29:59 --> Language Class Initialized
INFO - 2024-09-05 07:29:59 --> Loader Class Initialized
INFO - 2024-09-05 07:29:59 --> Helper loaded: url_helper
INFO - 2024-09-05 07:29:59 --> Helper loaded: file_helper
INFO - 2024-09-05 07:29:59 --> Helper loaded: security_helper
INFO - 2024-09-05 07:29:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:29:59 --> Database Driver Class Initialized
INFO - 2024-09-05 07:29:59 --> Email Class Initialized
DEBUG - 2024-09-05 07:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:29:59 --> Helper loaded: form_helper
INFO - 2024-09-05 07:29:59 --> Form Validation Class Initialized
INFO - 2024-09-05 07:29:59 --> Controller Class Initialized
DEBUG - 2024-09-05 07:29:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:29:59 --> Config Class Initialized
INFO - 2024-09-05 07:29:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:29:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:29:59 --> Utf8 Class Initialized
INFO - 2024-09-05 07:29:59 --> URI Class Initialized
INFO - 2024-09-05 07:29:59 --> Router Class Initialized
INFO - 2024-09-05 07:29:59 --> Output Class Initialized
INFO - 2024-09-05 07:29:59 --> Security Class Initialized
DEBUG - 2024-09-05 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:29:59 --> Input Class Initialized
INFO - 2024-09-05 07:29:59 --> Language Class Initialized
ERROR - 2024-09-05 07:29:59 --> 404 Page Not Found: User/index
INFO - 2024-09-05 07:30:09 --> Config Class Initialized
INFO - 2024-09-05 07:30:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:30:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:30:09 --> Utf8 Class Initialized
INFO - 2024-09-05 07:30:09 --> URI Class Initialized
INFO - 2024-09-05 07:30:09 --> Router Class Initialized
INFO - 2024-09-05 07:30:09 --> Output Class Initialized
INFO - 2024-09-05 07:30:09 --> Security Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:30:09 --> Input Class Initialized
INFO - 2024-09-05 07:30:09 --> Language Class Initialized
INFO - 2024-09-05 07:30:09 --> Loader Class Initialized
INFO - 2024-09-05 07:30:09 --> Helper loaded: url_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: file_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: security_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:30:09 --> Database Driver Class Initialized
INFO - 2024-09-05 07:30:09 --> Email Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:30:09 --> Helper loaded: form_helper
INFO - 2024-09-05 07:30:09 --> Form Validation Class Initialized
INFO - 2024-09-05 07:30:09 --> Controller Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:30:09 --> Config Class Initialized
INFO - 2024-09-05 07:30:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:30:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:30:09 --> Utf8 Class Initialized
INFO - 2024-09-05 07:30:09 --> URI Class Initialized
INFO - 2024-09-05 07:30:09 --> Router Class Initialized
INFO - 2024-09-05 07:30:09 --> Output Class Initialized
INFO - 2024-09-05 07:30:09 --> Security Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:30:09 --> Input Class Initialized
INFO - 2024-09-05 07:30:09 --> Language Class Initialized
INFO - 2024-09-05 07:30:09 --> Loader Class Initialized
INFO - 2024-09-05 07:30:09 --> Helper loaded: url_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: file_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: security_helper
INFO - 2024-09-05 07:30:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:30:09 --> Database Driver Class Initialized
INFO - 2024-09-05 07:30:09 --> Email Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:30:09 --> Helper loaded: form_helper
INFO - 2024-09-05 07:30:09 --> Form Validation Class Initialized
INFO - 2024-09-05 07:30:09 --> Controller Class Initialized
DEBUG - 2024-09-05 07:30:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:30:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 07:30:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 07:30:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 07:30:09 --> Final output sent to browser
DEBUG - 2024-09-05 07:30:09 --> Total execution time: 0.0526
INFO - 2024-09-05 07:30:11 --> Config Class Initialized
INFO - 2024-09-05 07:30:11 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:30:11 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:30:11 --> Utf8 Class Initialized
INFO - 2024-09-05 07:30:11 --> URI Class Initialized
INFO - 2024-09-05 07:30:11 --> Router Class Initialized
INFO - 2024-09-05 07:30:11 --> Output Class Initialized
INFO - 2024-09-05 07:30:11 --> Security Class Initialized
DEBUG - 2024-09-05 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:30:11 --> Input Class Initialized
INFO - 2024-09-05 07:30:11 --> Language Class Initialized
INFO - 2024-09-05 07:30:11 --> Loader Class Initialized
INFO - 2024-09-05 07:30:11 --> Helper loaded: url_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: file_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: security_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:30:11 --> Database Driver Class Initialized
INFO - 2024-09-05 07:30:11 --> Email Class Initialized
DEBUG - 2024-09-05 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:30:11 --> Helper loaded: form_helper
INFO - 2024-09-05 07:30:11 --> Form Validation Class Initialized
INFO - 2024-09-05 07:30:11 --> Controller Class Initialized
DEBUG - 2024-09-05 07:30:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:30:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 07:30:11 --> Config Class Initialized
INFO - 2024-09-05 07:30:11 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:30:11 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:30:11 --> Utf8 Class Initialized
INFO - 2024-09-05 07:30:11 --> URI Class Initialized
INFO - 2024-09-05 07:30:11 --> Router Class Initialized
INFO - 2024-09-05 07:30:11 --> Output Class Initialized
INFO - 2024-09-05 07:30:11 --> Security Class Initialized
DEBUG - 2024-09-05 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:30:11 --> Input Class Initialized
INFO - 2024-09-05 07:30:11 --> Language Class Initialized
INFO - 2024-09-05 07:30:11 --> Loader Class Initialized
INFO - 2024-09-05 07:30:11 --> Helper loaded: url_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: file_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: security_helper
INFO - 2024-09-05 07:30:11 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:30:11 --> Database Driver Class Initialized
INFO - 2024-09-05 07:30:11 --> Email Class Initialized
DEBUG - 2024-09-05 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:30:11 --> Helper loaded: form_helper
INFO - 2024-09-05 07:30:11 --> Form Validation Class Initialized
INFO - 2024-09-05 07:30:11 --> Controller Class Initialized
INFO - 2024-09-05 07:30:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:30:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:30:11 --> Severity: error --> Exception: Table 'rsaz_sik.tbl_pesanan' doesn't exist C:\xampp\htdocs\antrol\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2024-09-05 07:30:33 --> Config Class Initialized
INFO - 2024-09-05 07:30:33 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:30:33 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:30:33 --> Utf8 Class Initialized
INFO - 2024-09-05 07:30:33 --> URI Class Initialized
INFO - 2024-09-05 07:30:33 --> Router Class Initialized
INFO - 2024-09-05 07:30:33 --> Output Class Initialized
INFO - 2024-09-05 07:30:33 --> Security Class Initialized
DEBUG - 2024-09-05 07:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:30:33 --> Input Class Initialized
INFO - 2024-09-05 07:30:33 --> Language Class Initialized
INFO - 2024-09-05 07:30:33 --> Loader Class Initialized
INFO - 2024-09-05 07:30:33 --> Helper loaded: url_helper
INFO - 2024-09-05 07:30:33 --> Helper loaded: file_helper
INFO - 2024-09-05 07:30:33 --> Helper loaded: security_helper
INFO - 2024-09-05 07:30:33 --> Helper loaded: wpu_helper
INFO - 2024-09-05 07:30:33 --> Database Driver Class Initialized
INFO - 2024-09-05 07:30:33 --> Email Class Initialized
DEBUG - 2024-09-05 07:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:30:33 --> Helper loaded: form_helper
INFO - 2024-09-05 07:30:33 --> Form Validation Class Initialized
INFO - 2024-09-05 07:30:33 --> Controller Class Initialized
INFO - 2024-09-05 07:30:33 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:30:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 07:30:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 07:30:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 07:30:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 07:30:33 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 07:30:33 --> Final output sent to browser
DEBUG - 2024-09-05 07:30:33 --> Total execution time: 0.0972
INFO - 2024-09-05 07:32:23 --> Config Class Initialized
INFO - 2024-09-05 07:32:23 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:32:23 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:32:23 --> Utf8 Class Initialized
INFO - 2024-09-05 07:32:23 --> URI Class Initialized
INFO - 2024-09-05 07:32:23 --> Router Class Initialized
INFO - 2024-09-05 07:32:23 --> Output Class Initialized
INFO - 2024-09-05 07:32:23 --> Security Class Initialized
DEBUG - 2024-09-05 07:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:32:23 --> Input Class Initialized
INFO - 2024-09-05 07:32:23 --> Language Class Initialized
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$config is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$log is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$router is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$output is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$security is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$input is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
INFO - 2024-09-05 07:32:23 --> Loader Class Initialized
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$load is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 78
INFO - 2024-09-05 07:32:23 --> Helper loaded: url_helper
INFO - 2024-09-05 07:32:23 --> Helper loaded: file_helper
INFO - 2024-09-05 07:32:23 --> Helper loaded: security_helper
INFO - 2024-09-05 07:32:23 --> Helper loaded: wpu_helper
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 396
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\antrol\system\database\DB_driver.php 371
INFO - 2024-09-05 07:32:23 --> Database Driver Class Initialized
INFO - 2024-09-05 07:32:23 --> Email Class Initialized
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 132
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 292
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 166
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 235
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 315
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 356
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 282
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 289
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 304
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 314
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 315
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 316
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 317
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 375
DEBUG - 2024-09-05 07:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 110
ERROR - 2024-09-05 07:32:23 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 143
INFO - 2024-09-05 07:32:23 --> Session: Class initialized using 'files' driver.
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:32:23 --> Helper loaded: form_helper
INFO - 2024-09-05 07:32:23 --> Form Validation Class Initialized
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:32:23 --> Controller Class Initialized
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property Report::$Antrol_model is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 358
INFO - 2024-09-05 07:32:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:32:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
ERROR - 2024-09-05 07:32:23 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Antrol_model is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 931
INFO - 2024-09-05 07:32:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 07:32:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 07:32:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 07:32:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 07:32:24 --> Final output sent to browser
DEBUG - 2024-09-05 07:32:24 --> Total execution time: 0.4075
INFO - 2024-09-05 07:32:30 --> Config Class Initialized
INFO - 2024-09-05 07:32:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:32:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:32:30 --> Utf8 Class Initialized
INFO - 2024-09-05 07:32:30 --> URI Class Initialized
INFO - 2024-09-05 07:32:30 --> Router Class Initialized
INFO - 2024-09-05 07:32:30 --> Output Class Initialized
INFO - 2024-09-05 07:32:30 --> Security Class Initialized
DEBUG - 2024-09-05 07:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:32:30 --> Input Class Initialized
INFO - 2024-09-05 07:32:30 --> Language Class Initialized
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$config is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$log is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$router is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$output is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$security is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$input is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
INFO - 2024-09-05 07:32:30 --> Loader Class Initialized
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$load is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 78
INFO - 2024-09-05 07:32:30 --> Helper loaded: url_helper
INFO - 2024-09-05 07:32:30 --> Helper loaded: file_helper
INFO - 2024-09-05 07:32:30 --> Helper loaded: security_helper
INFO - 2024-09-05 07:32:30 --> Helper loaded: wpu_helper
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 396
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\antrol\system\database\DB_driver.php 371
INFO - 2024-09-05 07:32:30 --> Database Driver Class Initialized
INFO - 2024-09-05 07:32:30 --> Email Class Initialized
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 132
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 292
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 166
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 235
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 315
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 356
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 282
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 289
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 304
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 314
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 315
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 316
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 317
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 375
DEBUG - 2024-09-05 07:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 110
ERROR - 2024-09-05 07:32:30 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 143
INFO - 2024-09-05 07:32:30 --> Session: Class initialized using 'files' driver.
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:32:30 --> Helper loaded: form_helper
INFO - 2024-09-05 07:32:30 --> Form Validation Class Initialized
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 07:32:30 --> Controller Class Initialized
ERROR - 2024-09-05 07:32:30 --> Severity: 8192 --> Creation of dynamic property Report::$Antrol_model is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 358
INFO - 2024-09-05 07:32:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:32:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:32:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\antrol\system\core\Exceptions.php:271) C:\xampp\htdocs\antrol\system\core\Common.php 570
ERROR - 2024-09-05 07:32:31 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\Shared\String.php 538
INFO - 2024-09-05 07:33:48 --> Config Class Initialized
INFO - 2024-09-05 07:33:48 --> Hooks Class Initialized
DEBUG - 2024-09-05 07:33:48 --> UTF-8 Support Enabled
INFO - 2024-09-05 07:33:48 --> Utf8 Class Initialized
INFO - 2024-09-05 07:33:48 --> URI Class Initialized
INFO - 2024-09-05 07:33:48 --> Router Class Initialized
INFO - 2024-09-05 07:33:48 --> Output Class Initialized
INFO - 2024-09-05 07:33:48 --> Security Class Initialized
DEBUG - 2024-09-05 07:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 07:33:48 --> Input Class Initialized
INFO - 2024-09-05 07:33:48 --> Language Class Initialized
INFO - 2024-09-05 07:33:48 --> Loader Class Initialized
INFO - 2024-09-05 07:33:48 --> Helper loaded: url_helper
INFO - 2024-09-05 07:33:48 --> Helper loaded: file_helper
INFO - 2024-09-05 07:33:48 --> Helper loaded: security_helper
INFO - 2024-09-05 07:33:48 --> Helper loaded: wpu_helper
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\antrol\system\database\DB_driver.php 371
INFO - 2024-09-05 07:33:48 --> Database Driver Class Initialized
INFO - 2024-09-05 07:33:48 --> Email Class Initialized
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 132
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 292
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 166
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 235
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 315
ERROR - 2024-09-05 07:33:48 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 356
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 282
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 289
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 304
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 314
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 315
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 316
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 317
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 375
DEBUG - 2024-09-05 07:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 110
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 143
INFO - 2024-09-05 07:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 07:33:48 --> Helper loaded: form_helper
INFO - 2024-09-05 07:33:48 --> Form Validation Class Initialized
INFO - 2024-09-05 07:33:48 --> Controller Class Initialized
INFO - 2024-09-05 07:33:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 07:33:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 07:33:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\antrol\system\core\Exceptions.php:271) C:\xampp\htdocs\antrol\system\core\Common.php 570
ERROR - 2024-09-05 07:33:48 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\Shared\String.php 538
INFO - 2024-09-05 08:00:14 --> Config Class Initialized
INFO - 2024-09-05 08:00:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 08:00:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 08:00:14 --> Utf8 Class Initialized
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\antrol\system\core\URI.php 101
INFO - 2024-09-05 08:00:14 --> URI Class Initialized
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Router.php 127
INFO - 2024-09-05 08:00:14 --> Router Class Initialized
INFO - 2024-09-05 08:00:14 --> Output Class Initialized
INFO - 2024-09-05 08:00:14 --> Security Class Initialized
DEBUG - 2024-09-05 08:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 08:00:14 --> Input Class Initialized
INFO - 2024-09-05 08:00:14 --> Language Class Initialized
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$benchmark is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$hooks is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$config is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$log is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$utf8 is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$uri is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$exceptions is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$router is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$output is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$security is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$input is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$lang is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 75
INFO - 2024-09-05 08:00:14 --> Loader Class Initialized
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$load is deprecated C:\xampp\htdocs\antrol\system\core\Controller.php 78
INFO - 2024-09-05 08:00:14 --> Helper loaded: url_helper
INFO - 2024-09-05 08:00:14 --> Helper loaded: file_helper
INFO - 2024-09-05 08:00:14 --> Helper loaded: security_helper
INFO - 2024-09-05 08:00:14 --> Helper loaded: wpu_helper
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$db is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 396
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\antrol\system\database\DB_driver.php 371
INFO - 2024-09-05 08:00:14 --> Database Driver Class Initialized
INFO - 2024-09-05 08:00:14 --> Email Class Initialized
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$email is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::open($save_path, $name) should either be compatible with SessionHandlerInterface::open(string $path, string $name): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 132
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::close() should either be compatible with SessionHandlerInterface::close(): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 292
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::read($session_id) should either be compatible with SessionHandlerInterface::read(string $id): string|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 166
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::write($session_id, $session_data) should either be compatible with SessionHandlerInterface::write(string $id, string $data): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 235
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::destroy($session_id) should either be compatible with SessionHandlerInterface::destroy(string $id): bool, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 315
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Return type of CI_Session_files_driver::gc($maxlifetime) should either be compatible with SessionHandlerInterface::gc(int $max_lifetime): int|false, or the #[\ReturnTypeWillChange] attribute should be used to temporarily suppress the notice C:\xampp\htdocs\antrol\system\libraries\Session\drivers\Session_files_driver.php 356
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 282
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 289
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 304
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 314
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 315
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 316
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 317
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 375
DEBUG - 2024-09-05 08:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 110
ERROR - 2024-09-05 08:00:14 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\antrol\system\libraries\Session\Session.php 143
INFO - 2024-09-05 08:00:14 --> Session: Class initialized using 'files' driver.
ERROR - 2024-09-05 08:00:14 --> Severity: 8192 --> Creation of dynamic property Report::$session is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 08:00:15 --> Helper loaded: form_helper
INFO - 2024-09-05 08:00:15 --> Form Validation Class Initialized
ERROR - 2024-09-05 08:00:15 --> Severity: 8192 --> Creation of dynamic property Report::$form_validation is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 1283
INFO - 2024-09-05 08:00:15 --> Controller Class Initialized
ERROR - 2024-09-05 08:00:15 --> Severity: 8192 --> Creation of dynamic property Report::$Antrol_model is deprecated C:\xampp\htdocs\antrol\system\core\Loader.php 358
INFO - 2024-09-05 08:00:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 08:00:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2024-09-05 08:00:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\antrol\system\core\Exceptions.php:271) C:\xampp\htdocs\antrol\system\core\Common.php 570
ERROR - 2024-09-05 08:00:15 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\antrol\application\third_party\PHPExcel\PHPExcel\Shared\String.php 538
INFO - 2024-09-05 12:42:30 --> Config Class Initialized
INFO - 2024-09-05 12:42:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 12:42:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 12:42:30 --> Utf8 Class Initialized
INFO - 2024-09-05 12:42:30 --> URI Class Initialized
DEBUG - 2024-09-05 12:42:30 --> No URI present. Default controller set.
INFO - 2024-09-05 12:42:30 --> Router Class Initialized
INFO - 2024-09-05 12:42:30 --> Output Class Initialized
INFO - 2024-09-05 12:42:30 --> Security Class Initialized
DEBUG - 2024-09-05 12:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 12:42:30 --> Input Class Initialized
INFO - 2024-09-05 12:42:30 --> Language Class Initialized
INFO - 2024-09-05 12:42:30 --> Loader Class Initialized
INFO - 2024-09-05 12:42:30 --> Helper loaded: url_helper
INFO - 2024-09-05 12:42:30 --> Helper loaded: file_helper
INFO - 2024-09-05 12:42:30 --> Helper loaded: security_helper
INFO - 2024-09-05 12:42:30 --> Helper loaded: wpu_helper
INFO - 2024-09-05 12:42:30 --> Database Driver Class Initialized
ERROR - 2024-09-05 12:42:30 --> Unable to connect to the database
INFO - 2024-09-05 12:42:30 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 13:33:43 --> Config Class Initialized
INFO - 2024-09-05 13:33:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 13:33:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 13:33:44 --> Utf8 Class Initialized
INFO - 2024-09-05 13:33:44 --> URI Class Initialized
DEBUG - 2024-09-05 13:33:44 --> No URI present. Default controller set.
INFO - 2024-09-05 13:33:44 --> Router Class Initialized
INFO - 2024-09-05 13:33:44 --> Output Class Initialized
INFO - 2024-09-05 13:33:44 --> Security Class Initialized
DEBUG - 2024-09-05 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 13:33:44 --> Input Class Initialized
INFO - 2024-09-05 13:33:44 --> Language Class Initialized
INFO - 2024-09-05 13:33:44 --> Loader Class Initialized
INFO - 2024-09-05 13:33:44 --> Helper loaded: url_helper
INFO - 2024-09-05 13:33:44 --> Helper loaded: file_helper
INFO - 2024-09-05 13:33:44 --> Helper loaded: security_helper
INFO - 2024-09-05 13:33:44 --> Helper loaded: wpu_helper
INFO - 2024-09-05 13:33:44 --> Database Driver Class Initialized
INFO - 2024-09-05 13:33:44 --> Email Class Initialized
DEBUG - 2024-09-05 13:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 13:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 13:33:44 --> Helper loaded: form_helper
INFO - 2024-09-05 13:33:44 --> Form Validation Class Initialized
INFO - 2024-09-05 13:33:44 --> Controller Class Initialized
DEBUG - 2024-09-05 13:33:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 13:33:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 13:33:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 13:33:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 13:33:44 --> Final output sent to browser
DEBUG - 2024-09-05 13:33:44 --> Total execution time: 0.5268
INFO - 2024-09-05 13:33:45 --> Config Class Initialized
INFO - 2024-09-05 13:33:45 --> Hooks Class Initialized
DEBUG - 2024-09-05 13:33:45 --> UTF-8 Support Enabled
INFO - 2024-09-05 13:33:45 --> Utf8 Class Initialized
INFO - 2024-09-05 13:33:45 --> URI Class Initialized
INFO - 2024-09-05 13:33:45 --> Router Class Initialized
INFO - 2024-09-05 13:33:45 --> Output Class Initialized
INFO - 2024-09-05 13:33:45 --> Security Class Initialized
DEBUG - 2024-09-05 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 13:33:45 --> Input Class Initialized
INFO - 2024-09-05 13:33:45 --> Language Class Initialized
INFO - 2024-09-05 13:33:45 --> Loader Class Initialized
INFO - 2024-09-05 13:33:45 --> Helper loaded: url_helper
INFO - 2024-09-05 13:33:45 --> Helper loaded: file_helper
INFO - 2024-09-05 13:33:45 --> Helper loaded: security_helper
INFO - 2024-09-05 13:33:45 --> Helper loaded: wpu_helper
INFO - 2024-09-05 13:33:45 --> Database Driver Class Initialized
INFO - 2024-09-05 13:33:45 --> Email Class Initialized
DEBUG - 2024-09-05 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 13:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 13:33:45 --> Helper loaded: form_helper
INFO - 2024-09-05 13:33:45 --> Form Validation Class Initialized
INFO - 2024-09-05 13:33:45 --> Controller Class Initialized
DEBUG - 2024-09-05 13:33:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 13:33:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 13:33:46 --> Config Class Initialized
INFO - 2024-09-05 13:33:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 13:33:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 13:33:46 --> Utf8 Class Initialized
INFO - 2024-09-05 13:33:46 --> URI Class Initialized
INFO - 2024-09-05 13:33:46 --> Router Class Initialized
INFO - 2024-09-05 13:33:46 --> Output Class Initialized
INFO - 2024-09-05 13:33:46 --> Security Class Initialized
DEBUG - 2024-09-05 13:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 13:33:46 --> Input Class Initialized
INFO - 2024-09-05 13:33:46 --> Language Class Initialized
INFO - 2024-09-05 13:33:46 --> Loader Class Initialized
INFO - 2024-09-05 13:33:46 --> Helper loaded: url_helper
INFO - 2024-09-05 13:33:46 --> Helper loaded: file_helper
INFO - 2024-09-05 13:33:46 --> Helper loaded: security_helper
INFO - 2024-09-05 13:33:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 13:33:46 --> Database Driver Class Initialized
INFO - 2024-09-05 13:33:46 --> Email Class Initialized
DEBUG - 2024-09-05 13:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 13:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 13:33:46 --> Helper loaded: form_helper
INFO - 2024-09-05 13:33:46 --> Form Validation Class Initialized
INFO - 2024-09-05 13:33:46 --> Controller Class Initialized
INFO - 2024-09-05 13:33:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 13:33:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 13:33:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 13:33:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 13:33:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 13:33:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 13:33:46 --> Final output sent to browser
DEBUG - 2024-09-05 13:33:46 --> Total execution time: 0.3476
INFO - 2024-09-05 14:11:05 --> Config Class Initialized
INFO - 2024-09-05 14:11:05 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:05 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:05 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:05 --> URI Class Initialized
DEBUG - 2024-09-05 14:11:05 --> No URI present. Default controller set.
INFO - 2024-09-05 14:11:05 --> Router Class Initialized
INFO - 2024-09-05 14:11:05 --> Output Class Initialized
INFO - 2024-09-05 14:11:05 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:05 --> Input Class Initialized
INFO - 2024-09-05 14:11:05 --> Language Class Initialized
INFO - 2024-09-05 14:11:05 --> Loader Class Initialized
INFO - 2024-09-05 14:11:05 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:05 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:05 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:05 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:06 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:06 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:06 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:06 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:06 --> Controller Class Initialized
DEBUG - 2024-09-05 14:11:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:06 --> Config Class Initialized
INFO - 2024-09-05 14:11:06 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:06 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:06 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:06 --> URI Class Initialized
INFO - 2024-09-05 14:11:06 --> Router Class Initialized
INFO - 2024-09-05 14:11:06 --> Output Class Initialized
INFO - 2024-09-05 14:11:06 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:06 --> Input Class Initialized
INFO - 2024-09-05 14:11:06 --> Language Class Initialized
ERROR - 2024-09-05 14:11:06 --> 404 Page Not Found: User/index
INFO - 2024-09-05 14:11:11 --> Config Class Initialized
INFO - 2024-09-05 14:11:11 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:11 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:11 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:11 --> URI Class Initialized
INFO - 2024-09-05 14:11:11 --> Router Class Initialized
INFO - 2024-09-05 14:11:11 --> Output Class Initialized
INFO - 2024-09-05 14:11:11 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:11 --> Input Class Initialized
INFO - 2024-09-05 14:11:11 --> Language Class Initialized
ERROR - 2024-09-05 14:11:11 --> 404 Page Not Found: Data/index
INFO - 2024-09-05 14:11:12 --> Config Class Initialized
INFO - 2024-09-05 14:11:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:12 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:12 --> URI Class Initialized
DEBUG - 2024-09-05 14:11:12 --> No URI present. Default controller set.
INFO - 2024-09-05 14:11:12 --> Router Class Initialized
INFO - 2024-09-05 14:11:12 --> Output Class Initialized
INFO - 2024-09-05 14:11:12 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:12 --> Input Class Initialized
INFO - 2024-09-05 14:11:12 --> Language Class Initialized
INFO - 2024-09-05 14:11:12 --> Loader Class Initialized
INFO - 2024-09-05 14:11:12 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:12 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:12 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:12 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:12 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:12 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:12 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:12 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:12 --> Controller Class Initialized
DEBUG - 2024-09-05 14:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:12 --> Config Class Initialized
INFO - 2024-09-05 14:11:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:12 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:12 --> URI Class Initialized
INFO - 2024-09-05 14:11:12 --> Router Class Initialized
INFO - 2024-09-05 14:11:12 --> Output Class Initialized
INFO - 2024-09-05 14:11:12 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:12 --> Input Class Initialized
INFO - 2024-09-05 14:11:12 --> Language Class Initialized
ERROR - 2024-09-05 14:11:12 --> 404 Page Not Found: User/index
INFO - 2024-09-05 14:11:14 --> Config Class Initialized
INFO - 2024-09-05 14:11:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:14 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:14 --> URI Class Initialized
INFO - 2024-09-05 14:11:14 --> Router Class Initialized
INFO - 2024-09-05 14:11:14 --> Output Class Initialized
INFO - 2024-09-05 14:11:14 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:14 --> Input Class Initialized
INFO - 2024-09-05 14:11:14 --> Language Class Initialized
INFO - 2024-09-05 14:11:14 --> Loader Class Initialized
INFO - 2024-09-05 14:11:14 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:14 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:14 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:14 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:14 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:14 --> Controller Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:14 --> Config Class Initialized
INFO - 2024-09-05 14:11:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:14 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:14 --> URI Class Initialized
INFO - 2024-09-05 14:11:14 --> Router Class Initialized
INFO - 2024-09-05 14:11:14 --> Output Class Initialized
INFO - 2024-09-05 14:11:14 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:14 --> Input Class Initialized
INFO - 2024-09-05 14:11:14 --> Language Class Initialized
INFO - 2024-09-05 14:11:14 --> Loader Class Initialized
INFO - 2024-09-05 14:11:14 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:14 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:14 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:14 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:14 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:14 --> Controller Class Initialized
DEBUG - 2024-09-05 14:11:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 14:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 14:11:14 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 14:11:14 --> Final output sent to browser
DEBUG - 2024-09-05 14:11:14 --> Total execution time: 0.0433
INFO - 2024-09-05 14:11:16 --> Config Class Initialized
INFO - 2024-09-05 14:11:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:16 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:16 --> URI Class Initialized
INFO - 2024-09-05 14:11:16 --> Router Class Initialized
INFO - 2024-09-05 14:11:16 --> Output Class Initialized
INFO - 2024-09-05 14:11:16 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:16 --> Input Class Initialized
INFO - 2024-09-05 14:11:16 --> Language Class Initialized
INFO - 2024-09-05 14:11:16 --> Loader Class Initialized
INFO - 2024-09-05 14:11:16 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:16 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:16 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:16 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:16 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:16 --> Controller Class Initialized
DEBUG - 2024-09-05 14:11:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 14:11:16 --> Config Class Initialized
INFO - 2024-09-05 14:11:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:16 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:16 --> URI Class Initialized
INFO - 2024-09-05 14:11:16 --> Router Class Initialized
INFO - 2024-09-05 14:11:16 --> Output Class Initialized
INFO - 2024-09-05 14:11:16 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:16 --> Input Class Initialized
INFO - 2024-09-05 14:11:16 --> Language Class Initialized
INFO - 2024-09-05 14:11:16 --> Loader Class Initialized
INFO - 2024-09-05 14:11:16 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:16 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:16 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:16 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:16 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:16 --> Controller Class Initialized
INFO - 2024-09-05 14:11:16 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 14:11:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 14:11:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 14:11:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 14:11:16 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 14:11:16 --> Final output sent to browser
DEBUG - 2024-09-05 14:11:16 --> Total execution time: 0.0776
INFO - 2024-09-05 14:11:24 --> Config Class Initialized
INFO - 2024-09-05 14:11:24 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:24 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:24 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:24 --> URI Class Initialized
INFO - 2024-09-05 14:11:24 --> Router Class Initialized
INFO - 2024-09-05 14:11:24 --> Output Class Initialized
INFO - 2024-09-05 14:11:24 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:24 --> Input Class Initialized
INFO - 2024-09-05 14:11:24 --> Language Class Initialized
INFO - 2024-09-05 14:11:24 --> Loader Class Initialized
INFO - 2024-09-05 14:11:24 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:24 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:24 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:24 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:24 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:24 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:24 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:24 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:24 --> Controller Class Initialized
INFO - 2024-09-05 14:11:24 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 14:11:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 14:11:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 14:11:24 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 14:11:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 14:11:25 --> Final output sent to browser
DEBUG - 2024-09-05 14:11:25 --> Total execution time: 0.4238
INFO - 2024-09-05 14:11:30 --> Config Class Initialized
INFO - 2024-09-05 14:11:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:11:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:11:30 --> Utf8 Class Initialized
INFO - 2024-09-05 14:11:30 --> URI Class Initialized
INFO - 2024-09-05 14:11:30 --> Router Class Initialized
INFO - 2024-09-05 14:11:30 --> Output Class Initialized
INFO - 2024-09-05 14:11:30 --> Security Class Initialized
DEBUG - 2024-09-05 14:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:11:30 --> Input Class Initialized
INFO - 2024-09-05 14:11:30 --> Language Class Initialized
INFO - 2024-09-05 14:11:30 --> Loader Class Initialized
INFO - 2024-09-05 14:11:30 --> Helper loaded: url_helper
INFO - 2024-09-05 14:11:30 --> Helper loaded: file_helper
INFO - 2024-09-05 14:11:30 --> Helper loaded: security_helper
INFO - 2024-09-05 14:11:30 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:11:30 --> Database Driver Class Initialized
INFO - 2024-09-05 14:11:30 --> Email Class Initialized
DEBUG - 2024-09-05 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:11:30 --> Helper loaded: form_helper
INFO - 2024-09-05 14:11:30 --> Form Validation Class Initialized
INFO - 2024-09-05 14:11:30 --> Controller Class Initialized
INFO - 2024-09-05 14:11:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 14:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:11:32 --> Final output sent to browser
DEBUG - 2024-09-05 14:11:32 --> Total execution time: 2.1169
INFO - 2024-09-05 14:13:35 --> Config Class Initialized
INFO - 2024-09-05 14:13:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:13:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:13:35 --> Utf8 Class Initialized
INFO - 2024-09-05 14:13:35 --> URI Class Initialized
INFO - 2024-09-05 14:13:35 --> Router Class Initialized
INFO - 2024-09-05 14:13:35 --> Output Class Initialized
INFO - 2024-09-05 14:13:35 --> Security Class Initialized
DEBUG - 2024-09-05 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:13:35 --> Input Class Initialized
INFO - 2024-09-05 14:13:35 --> Language Class Initialized
INFO - 2024-09-05 14:13:35 --> Loader Class Initialized
INFO - 2024-09-05 14:13:35 --> Helper loaded: url_helper
INFO - 2024-09-05 14:13:35 --> Helper loaded: file_helper
INFO - 2024-09-05 14:13:35 --> Helper loaded: security_helper
INFO - 2024-09-05 14:13:35 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:13:35 --> Database Driver Class Initialized
INFO - 2024-09-05 14:13:35 --> Email Class Initialized
DEBUG - 2024-09-05 14:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:13:35 --> Helper loaded: form_helper
INFO - 2024-09-05 14:13:35 --> Form Validation Class Initialized
INFO - 2024-09-05 14:13:35 --> Controller Class Initialized
INFO - 2024-09-05 14:13:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 14:13:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:13:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 14:13:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 14:13:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 14:13:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 14:13:36 --> Final output sent to browser
DEBUG - 2024-09-05 14:13:36 --> Total execution time: 0.1377
INFO - 2024-09-05 14:13:37 --> Config Class Initialized
INFO - 2024-09-05 14:13:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 14:13:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 14:13:37 --> Utf8 Class Initialized
INFO - 2024-09-05 14:13:37 --> URI Class Initialized
INFO - 2024-09-05 14:13:37 --> Router Class Initialized
INFO - 2024-09-05 14:13:37 --> Output Class Initialized
INFO - 2024-09-05 14:13:37 --> Security Class Initialized
DEBUG - 2024-09-05 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 14:13:37 --> Input Class Initialized
INFO - 2024-09-05 14:13:37 --> Language Class Initialized
INFO - 2024-09-05 14:13:37 --> Loader Class Initialized
INFO - 2024-09-05 14:13:37 --> Helper loaded: url_helper
INFO - 2024-09-05 14:13:37 --> Helper loaded: file_helper
INFO - 2024-09-05 14:13:37 --> Helper loaded: security_helper
INFO - 2024-09-05 14:13:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 14:13:37 --> Database Driver Class Initialized
INFO - 2024-09-05 14:13:37 --> Email Class Initialized
DEBUG - 2024-09-05 14:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 14:13:37 --> Helper loaded: form_helper
INFO - 2024-09-05 14:13:37 --> Form Validation Class Initialized
INFO - 2024-09-05 14:13:37 --> Controller Class Initialized
INFO - 2024-09-05 14:13:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 14:13:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 14:13:37 --> Final output sent to browser
DEBUG - 2024-09-05 14:13:37 --> Total execution time: 0.5661
INFO - 2024-09-05 17:38:18 --> Config Class Initialized
INFO - 2024-09-05 17:38:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 17:38:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 17:38:18 --> Utf8 Class Initialized
INFO - 2024-09-05 17:38:18 --> URI Class Initialized
INFO - 2024-09-05 17:38:18 --> Router Class Initialized
INFO - 2024-09-05 17:38:18 --> Output Class Initialized
INFO - 2024-09-05 17:38:19 --> Security Class Initialized
DEBUG - 2024-09-05 17:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 17:38:19 --> Input Class Initialized
INFO - 2024-09-05 17:38:19 --> Language Class Initialized
INFO - 2024-09-05 17:38:19 --> Loader Class Initialized
INFO - 2024-09-05 17:38:19 --> Helper loaded: url_helper
INFO - 2024-09-05 17:38:19 --> Helper loaded: file_helper
INFO - 2024-09-05 17:38:19 --> Helper loaded: security_helper
INFO - 2024-09-05 17:38:19 --> Helper loaded: wpu_helper
INFO - 2024-09-05 17:38:19 --> Database Driver Class Initialized
INFO - 2024-09-05 17:38:19 --> Email Class Initialized
DEBUG - 2024-09-05 17:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 17:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 17:38:19 --> Helper loaded: form_helper
INFO - 2024-09-05 17:38:19 --> Form Validation Class Initialized
INFO - 2024-09-05 17:38:19 --> Controller Class Initialized
INFO - 2024-09-05 17:38:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 17:38:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 17:38:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 17:38:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 17:38:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 17:38:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 17:38:20 --> Final output sent to browser
DEBUG - 2024-09-05 17:38:20 --> Total execution time: 2.2454
INFO - 2024-09-05 17:54:42 --> Config Class Initialized
INFO - 2024-09-05 17:54:42 --> Hooks Class Initialized
DEBUG - 2024-09-05 17:54:42 --> UTF-8 Support Enabled
INFO - 2024-09-05 17:54:42 --> Utf8 Class Initialized
INFO - 2024-09-05 17:54:42 --> URI Class Initialized
INFO - 2024-09-05 17:54:42 --> Router Class Initialized
INFO - 2024-09-05 17:54:42 --> Output Class Initialized
INFO - 2024-09-05 17:54:42 --> Security Class Initialized
DEBUG - 2024-09-05 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 17:54:42 --> Input Class Initialized
INFO - 2024-09-05 17:54:42 --> Language Class Initialized
INFO - 2024-09-05 17:54:42 --> Loader Class Initialized
INFO - 2024-09-05 17:54:42 --> Helper loaded: url_helper
INFO - 2024-09-05 17:54:42 --> Helper loaded: file_helper
INFO - 2024-09-05 17:54:42 --> Helper loaded: security_helper
INFO - 2024-09-05 17:54:42 --> Helper loaded: wpu_helper
INFO - 2024-09-05 17:54:43 --> Database Driver Class Initialized
INFO - 2024-09-05 17:54:43 --> Email Class Initialized
DEBUG - 2024-09-05 17:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 17:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 17:54:43 --> Helper loaded: form_helper
INFO - 2024-09-05 17:54:43 --> Form Validation Class Initialized
INFO - 2024-09-05 17:54:43 --> Controller Class Initialized
INFO - 2024-09-05 17:54:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 17:54:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 17:54:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 17:54:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 17:54:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 17:54:43 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 17:54:43 --> Final output sent to browser
DEBUG - 2024-09-05 17:54:43 --> Total execution time: 0.2716
INFO - 2024-09-05 17:54:44 --> Config Class Initialized
INFO - 2024-09-05 17:54:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 17:54:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 17:54:44 --> Utf8 Class Initialized
INFO - 2024-09-05 17:54:44 --> URI Class Initialized
INFO - 2024-09-05 17:54:44 --> Router Class Initialized
INFO - 2024-09-05 17:54:44 --> Output Class Initialized
INFO - 2024-09-05 17:54:44 --> Security Class Initialized
DEBUG - 2024-09-05 17:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 17:54:44 --> Input Class Initialized
INFO - 2024-09-05 17:54:44 --> Language Class Initialized
INFO - 2024-09-05 17:54:44 --> Loader Class Initialized
INFO - 2024-09-05 17:54:44 --> Helper loaded: url_helper
INFO - 2024-09-05 17:54:44 --> Helper loaded: file_helper
INFO - 2024-09-05 17:54:44 --> Helper loaded: security_helper
INFO - 2024-09-05 17:54:44 --> Helper loaded: wpu_helper
INFO - 2024-09-05 17:54:44 --> Database Driver Class Initialized
INFO - 2024-09-05 17:54:44 --> Email Class Initialized
DEBUG - 2024-09-05 17:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 17:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 17:54:44 --> Helper loaded: form_helper
INFO - 2024-09-05 17:54:44 --> Form Validation Class Initialized
INFO - 2024-09-05 17:54:44 --> Controller Class Initialized
INFO - 2024-09-05 17:54:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 17:54:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 17:54:47 --> Final output sent to browser
DEBUG - 2024-09-05 17:54:47 --> Total execution time: 2.6292
INFO - 2024-09-05 17:55:17 --> Config Class Initialized
INFO - 2024-09-05 17:55:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 17:55:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 17:55:17 --> Utf8 Class Initialized
INFO - 2024-09-05 17:55:17 --> URI Class Initialized
INFO - 2024-09-05 17:55:17 --> Router Class Initialized
INFO - 2024-09-05 17:55:17 --> Output Class Initialized
INFO - 2024-09-05 17:55:17 --> Security Class Initialized
DEBUG - 2024-09-05 17:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 17:55:17 --> Input Class Initialized
INFO - 2024-09-05 17:55:17 --> Language Class Initialized
INFO - 2024-09-05 17:55:17 --> Loader Class Initialized
INFO - 2024-09-05 17:55:17 --> Helper loaded: url_helper
INFO - 2024-09-05 17:55:17 --> Helper loaded: file_helper
INFO - 2024-09-05 17:55:17 --> Helper loaded: security_helper
INFO - 2024-09-05 17:55:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 17:55:17 --> Database Driver Class Initialized
INFO - 2024-09-05 17:55:17 --> Email Class Initialized
DEBUG - 2024-09-05 17:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 17:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 17:55:17 --> Helper loaded: form_helper
INFO - 2024-09-05 17:55:17 --> Form Validation Class Initialized
INFO - 2024-09-05 17:55:17 --> Controller Class Initialized
INFO - 2024-09-05 17:55:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 17:55:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 17:55:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 17:55:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 17:55:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 17:55:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 17:55:17 --> Final output sent to browser
DEBUG - 2024-09-05 17:55:17 --> Total execution time: 0.1105
INFO - 2024-09-05 17:55:18 --> Config Class Initialized
INFO - 2024-09-05 17:55:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 17:55:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 17:55:18 --> Utf8 Class Initialized
INFO - 2024-09-05 17:55:18 --> URI Class Initialized
INFO - 2024-09-05 17:55:18 --> Router Class Initialized
INFO - 2024-09-05 17:55:18 --> Output Class Initialized
INFO - 2024-09-05 17:55:18 --> Security Class Initialized
DEBUG - 2024-09-05 17:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 17:55:18 --> Input Class Initialized
INFO - 2024-09-05 17:55:18 --> Language Class Initialized
INFO - 2024-09-05 17:55:18 --> Loader Class Initialized
INFO - 2024-09-05 17:55:18 --> Helper loaded: url_helper
INFO - 2024-09-05 17:55:18 --> Helper loaded: file_helper
INFO - 2024-09-05 17:55:18 --> Helper loaded: security_helper
INFO - 2024-09-05 17:55:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 17:55:18 --> Database Driver Class Initialized
INFO - 2024-09-05 17:55:18 --> Email Class Initialized
DEBUG - 2024-09-05 17:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 17:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 17:55:18 --> Helper loaded: form_helper
INFO - 2024-09-05 17:55:18 --> Form Validation Class Initialized
INFO - 2024-09-05 17:55:18 --> Controller Class Initialized
INFO - 2024-09-05 17:55:18 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 17:55:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 17:55:19 --> Final output sent to browser
DEBUG - 2024-09-05 17:55:19 --> Total execution time: 0.9878
INFO - 2024-09-05 23:04:21 --> Config Class Initialized
INFO - 2024-09-05 23:04:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:21 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:21 --> URI Class Initialized
INFO - 2024-09-05 23:04:21 --> Router Class Initialized
INFO - 2024-09-05 23:04:21 --> Output Class Initialized
INFO - 2024-09-05 23:04:21 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:21 --> Input Class Initialized
INFO - 2024-09-05 23:04:21 --> Language Class Initialized
ERROR - 2024-09-05 23:04:21 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 23:04:28 --> Config Class Initialized
INFO - 2024-09-05 23:04:28 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:28 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:28 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:28 --> URI Class Initialized
INFO - 2024-09-05 23:04:28 --> Router Class Initialized
INFO - 2024-09-05 23:04:28 --> Output Class Initialized
INFO - 2024-09-05 23:04:28 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:28 --> Input Class Initialized
INFO - 2024-09-05 23:04:28 --> Language Class Initialized
ERROR - 2024-09-05 23:04:28 --> 404 Page Not Found: Data/index
INFO - 2024-09-05 23:04:33 --> Config Class Initialized
INFO - 2024-09-05 23:04:33 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:33 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:33 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:33 --> URI Class Initialized
INFO - 2024-09-05 23:04:33 --> Router Class Initialized
INFO - 2024-09-05 23:04:33 --> Output Class Initialized
INFO - 2024-09-05 23:04:33 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:33 --> Input Class Initialized
INFO - 2024-09-05 23:04:33 --> Language Class Initialized
ERROR - 2024-09-05 23:04:33 --> 404 Page Not Found: Data/index
INFO - 2024-09-05 23:04:38 --> Config Class Initialized
INFO - 2024-09-05 23:04:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:38 --> URI Class Initialized
DEBUG - 2024-09-05 23:04:38 --> No URI present. Default controller set.
INFO - 2024-09-05 23:04:38 --> Router Class Initialized
INFO - 2024-09-05 23:04:38 --> Output Class Initialized
INFO - 2024-09-05 23:04:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:38 --> Input Class Initialized
INFO - 2024-09-05 23:04:38 --> Language Class Initialized
INFO - 2024-09-05 23:04:38 --> Loader Class Initialized
INFO - 2024-09-05 23:04:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:04:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:04:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:04:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:04:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:04:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:04:39 --> Helper loaded: form_helper
INFO - 2024-09-05 23:04:39 --> Form Validation Class Initialized
INFO - 2024-09-05 23:04:39 --> Controller Class Initialized
DEBUG - 2024-09-05 23:04:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:04:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:04:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:04:39 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:04:39 --> Final output sent to browser
DEBUG - 2024-09-05 23:04:39 --> Total execution time: 1.0310
INFO - 2024-09-05 23:04:40 --> Config Class Initialized
INFO - 2024-09-05 23:04:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:40 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:40 --> URI Class Initialized
INFO - 2024-09-05 23:04:40 --> Router Class Initialized
INFO - 2024-09-05 23:04:40 --> Output Class Initialized
INFO - 2024-09-05 23:04:40 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:40 --> Input Class Initialized
INFO - 2024-09-05 23:04:40 --> Language Class Initialized
INFO - 2024-09-05 23:04:40 --> Loader Class Initialized
INFO - 2024-09-05 23:04:40 --> Helper loaded: url_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: file_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: security_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:04:40 --> Database Driver Class Initialized
INFO - 2024-09-05 23:04:40 --> Email Class Initialized
DEBUG - 2024-09-05 23:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:04:40 --> Helper loaded: form_helper
INFO - 2024-09-05 23:04:40 --> Form Validation Class Initialized
INFO - 2024-09-05 23:04:40 --> Controller Class Initialized
DEBUG - 2024-09-05 23:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:04:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:04:40 --> Config Class Initialized
INFO - 2024-09-05 23:04:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:04:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:04:40 --> Utf8 Class Initialized
INFO - 2024-09-05 23:04:40 --> URI Class Initialized
INFO - 2024-09-05 23:04:40 --> Router Class Initialized
INFO - 2024-09-05 23:04:40 --> Output Class Initialized
INFO - 2024-09-05 23:04:40 --> Security Class Initialized
DEBUG - 2024-09-05 23:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:04:40 --> Input Class Initialized
INFO - 2024-09-05 23:04:40 --> Language Class Initialized
INFO - 2024-09-05 23:04:40 --> Loader Class Initialized
INFO - 2024-09-05 23:04:40 --> Helper loaded: url_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: file_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: security_helper
INFO - 2024-09-05 23:04:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:04:40 --> Database Driver Class Initialized
INFO - 2024-09-05 23:04:40 --> Email Class Initialized
DEBUG - 2024-09-05 23:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:04:40 --> Helper loaded: form_helper
INFO - 2024-09-05 23:04:40 --> Form Validation Class Initialized
INFO - 2024-09-05 23:04:40 --> Controller Class Initialized
INFO - 2024-09-05 23:04:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:04:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:04:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:04:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:04:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:04:41 --> Final output sent to browser
DEBUG - 2024-09-05 23:04:41 --> Total execution time: 0.3390
INFO - 2024-09-05 23:16:40 --> Config Class Initialized
INFO - 2024-09-05 23:16:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:16:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:16:40 --> Utf8 Class Initialized
INFO - 2024-09-05 23:16:40 --> URI Class Initialized
INFO - 2024-09-05 23:16:40 --> Router Class Initialized
INFO - 2024-09-05 23:16:40 --> Output Class Initialized
INFO - 2024-09-05 23:16:40 --> Security Class Initialized
DEBUG - 2024-09-05 23:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:16:40 --> Input Class Initialized
INFO - 2024-09-05 23:16:40 --> Language Class Initialized
INFO - 2024-09-05 23:16:40 --> Loader Class Initialized
INFO - 2024-09-05 23:16:40 --> Helper loaded: url_helper
INFO - 2024-09-05 23:16:40 --> Helper loaded: file_helper
INFO - 2024-09-05 23:16:40 --> Helper loaded: security_helper
INFO - 2024-09-05 23:16:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:16:40 --> Database Driver Class Initialized
INFO - 2024-09-05 23:16:40 --> Email Class Initialized
DEBUG - 2024-09-05 23:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:16:40 --> Helper loaded: form_helper
INFO - 2024-09-05 23:16:40 --> Form Validation Class Initialized
INFO - 2024-09-05 23:16:40 --> Controller Class Initialized
INFO - 2024-09-05 23:16:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:16:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:16:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:16:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:16:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:16:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:16:40 --> Final output sent to browser
DEBUG - 2024-09-05 23:16:40 --> Total execution time: 0.1722
INFO - 2024-09-05 23:19:48 --> Config Class Initialized
INFO - 2024-09-05 23:19:48 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:19:48 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:19:48 --> Utf8 Class Initialized
INFO - 2024-09-05 23:19:48 --> URI Class Initialized
INFO - 2024-09-05 23:19:48 --> Router Class Initialized
INFO - 2024-09-05 23:19:48 --> Output Class Initialized
INFO - 2024-09-05 23:19:48 --> Security Class Initialized
DEBUG - 2024-09-05 23:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:19:48 --> Input Class Initialized
INFO - 2024-09-05 23:19:48 --> Language Class Initialized
INFO - 2024-09-05 23:19:48 --> Loader Class Initialized
INFO - 2024-09-05 23:19:48 --> Helper loaded: url_helper
INFO - 2024-09-05 23:19:48 --> Helper loaded: file_helper
INFO - 2024-09-05 23:19:48 --> Helper loaded: security_helper
INFO - 2024-09-05 23:19:48 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:19:48 --> Database Driver Class Initialized
INFO - 2024-09-05 23:19:48 --> Email Class Initialized
DEBUG - 2024-09-05 23:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:19:48 --> Helper loaded: form_helper
INFO - 2024-09-05 23:19:48 --> Form Validation Class Initialized
INFO - 2024-09-05 23:19:48 --> Controller Class Initialized
INFO - 2024-09-05 23:19:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:19:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:19:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:19:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:19:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:19:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:19:48 --> Final output sent to browser
DEBUG - 2024-09-05 23:19:48 --> Total execution time: 0.1285
INFO - 2024-09-05 23:20:17 --> Config Class Initialized
INFO - 2024-09-05 23:20:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:20:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:20:17 --> Utf8 Class Initialized
INFO - 2024-09-05 23:20:17 --> URI Class Initialized
INFO - 2024-09-05 23:20:17 --> Router Class Initialized
INFO - 2024-09-05 23:20:17 --> Output Class Initialized
INFO - 2024-09-05 23:20:17 --> Security Class Initialized
DEBUG - 2024-09-05 23:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:20:17 --> Input Class Initialized
INFO - 2024-09-05 23:20:17 --> Language Class Initialized
INFO - 2024-09-05 23:20:17 --> Loader Class Initialized
INFO - 2024-09-05 23:20:17 --> Helper loaded: url_helper
INFO - 2024-09-05 23:20:17 --> Helper loaded: file_helper
INFO - 2024-09-05 23:20:17 --> Helper loaded: security_helper
INFO - 2024-09-05 23:20:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:20:17 --> Database Driver Class Initialized
INFO - 2024-09-05 23:20:17 --> Email Class Initialized
DEBUG - 2024-09-05 23:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:20:17 --> Helper loaded: form_helper
INFO - 2024-09-05 23:20:17 --> Form Validation Class Initialized
INFO - 2024-09-05 23:20:17 --> Controller Class Initialized
INFO - 2024-09-05 23:20:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:20:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:20:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:20:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:20:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:20:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:20:17 --> Final output sent to browser
DEBUG - 2024-09-05 23:20:17 --> Total execution time: 0.1389
INFO - 2024-09-05 23:23:35 --> Config Class Initialized
INFO - 2024-09-05 23:23:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:23:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:23:35 --> Utf8 Class Initialized
INFO - 2024-09-05 23:23:35 --> URI Class Initialized
INFO - 2024-09-05 23:23:35 --> Router Class Initialized
INFO - 2024-09-05 23:23:35 --> Output Class Initialized
INFO - 2024-09-05 23:23:35 --> Security Class Initialized
DEBUG - 2024-09-05 23:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:23:35 --> Input Class Initialized
INFO - 2024-09-05 23:23:35 --> Language Class Initialized
INFO - 2024-09-05 23:23:35 --> Loader Class Initialized
INFO - 2024-09-05 23:23:35 --> Helper loaded: url_helper
INFO - 2024-09-05 23:23:35 --> Helper loaded: file_helper
INFO - 2024-09-05 23:23:35 --> Helper loaded: security_helper
INFO - 2024-09-05 23:23:35 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:23:35 --> Database Driver Class Initialized
INFO - 2024-09-05 23:23:35 --> Email Class Initialized
DEBUG - 2024-09-05 23:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:23:35 --> Helper loaded: form_helper
INFO - 2024-09-05 23:23:35 --> Form Validation Class Initialized
INFO - 2024-09-05 23:23:35 --> Controller Class Initialized
INFO - 2024-09-05 23:23:35 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:23:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:23:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:23:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:23:35 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:23:35 --> Final output sent to browser
DEBUG - 2024-09-05 23:23:35 --> Total execution time: 0.1533
INFO - 2024-09-05 23:25:40 --> Config Class Initialized
INFO - 2024-09-05 23:25:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:25:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:25:40 --> Utf8 Class Initialized
INFO - 2024-09-05 23:25:40 --> URI Class Initialized
INFO - 2024-09-05 23:25:40 --> Router Class Initialized
INFO - 2024-09-05 23:25:40 --> Output Class Initialized
INFO - 2024-09-05 23:25:40 --> Security Class Initialized
DEBUG - 2024-09-05 23:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:25:40 --> Input Class Initialized
INFO - 2024-09-05 23:25:40 --> Language Class Initialized
INFO - 2024-09-05 23:25:40 --> Loader Class Initialized
INFO - 2024-09-05 23:25:40 --> Helper loaded: url_helper
INFO - 2024-09-05 23:25:40 --> Helper loaded: file_helper
INFO - 2024-09-05 23:25:40 --> Helper loaded: security_helper
INFO - 2024-09-05 23:25:41 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:25:41 --> Database Driver Class Initialized
INFO - 2024-09-05 23:25:41 --> Email Class Initialized
DEBUG - 2024-09-05 23:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:25:41 --> Helper loaded: form_helper
INFO - 2024-09-05 23:25:41 --> Form Validation Class Initialized
INFO - 2024-09-05 23:25:41 --> Controller Class Initialized
INFO - 2024-09-05 23:25:41 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:25:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:25:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:25:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:25:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:25:41 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:25:41 --> Final output sent to browser
DEBUG - 2024-09-05 23:25:41 --> Total execution time: 0.1091
INFO - 2024-09-05 23:29:48 --> Config Class Initialized
INFO - 2024-09-05 23:29:48 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:29:48 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:29:48 --> Utf8 Class Initialized
INFO - 2024-09-05 23:29:48 --> URI Class Initialized
INFO - 2024-09-05 23:29:48 --> Router Class Initialized
INFO - 2024-09-05 23:29:48 --> Output Class Initialized
INFO - 2024-09-05 23:29:48 --> Security Class Initialized
DEBUG - 2024-09-05 23:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:29:48 --> Input Class Initialized
INFO - 2024-09-05 23:29:48 --> Language Class Initialized
INFO - 2024-09-05 23:29:48 --> Loader Class Initialized
INFO - 2024-09-05 23:29:48 --> Helper loaded: url_helper
INFO - 2024-09-05 23:29:48 --> Helper loaded: file_helper
INFO - 2024-09-05 23:29:48 --> Helper loaded: security_helper
INFO - 2024-09-05 23:29:48 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:29:48 --> Database Driver Class Initialized
INFO - 2024-09-05 23:29:48 --> Email Class Initialized
DEBUG - 2024-09-05 23:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:29:48 --> Helper loaded: form_helper
INFO - 2024-09-05 23:29:48 --> Form Validation Class Initialized
INFO - 2024-09-05 23:29:48 --> Controller Class Initialized
INFO - 2024-09-05 23:29:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:29:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:29:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:29:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:29:48 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:29:48 --> Final output sent to browser
DEBUG - 2024-09-05 23:29:48 --> Total execution time: 0.2570
INFO - 2024-09-05 23:29:58 --> Config Class Initialized
INFO - 2024-09-05 23:29:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:29:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:29:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:29:58 --> URI Class Initialized
INFO - 2024-09-05 23:29:58 --> Router Class Initialized
INFO - 2024-09-05 23:29:58 --> Output Class Initialized
INFO - 2024-09-05 23:29:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:29:58 --> Input Class Initialized
INFO - 2024-09-05 23:29:58 --> Language Class Initialized
INFO - 2024-09-05 23:29:58 --> Loader Class Initialized
INFO - 2024-09-05 23:29:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:29:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:29:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:29:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:29:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:29:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:29:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:29:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:29:58 --> Controller Class Initialized
INFO - 2024-09-05 23:29:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:29:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:29:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:29:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:29:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:29:58 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:29:58 --> Final output sent to browser
DEBUG - 2024-09-05 23:29:58 --> Total execution time: 0.1226
INFO - 2024-09-05 23:30:12 --> Config Class Initialized
INFO - 2024-09-05 23:30:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:30:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:30:12 --> Utf8 Class Initialized
INFO - 2024-09-05 23:30:12 --> URI Class Initialized
INFO - 2024-09-05 23:30:12 --> Router Class Initialized
INFO - 2024-09-05 23:30:12 --> Output Class Initialized
INFO - 2024-09-05 23:30:12 --> Security Class Initialized
DEBUG - 2024-09-05 23:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:30:12 --> Input Class Initialized
INFO - 2024-09-05 23:30:12 --> Language Class Initialized
INFO - 2024-09-05 23:30:12 --> Loader Class Initialized
INFO - 2024-09-05 23:30:12 --> Helper loaded: url_helper
INFO - 2024-09-05 23:30:12 --> Helper loaded: file_helper
INFO - 2024-09-05 23:30:12 --> Helper loaded: security_helper
INFO - 2024-09-05 23:30:12 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:30:12 --> Database Driver Class Initialized
INFO - 2024-09-05 23:30:12 --> Email Class Initialized
DEBUG - 2024-09-05 23:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:30:12 --> Helper loaded: form_helper
INFO - 2024-09-05 23:30:12 --> Form Validation Class Initialized
INFO - 2024-09-05 23:30:12 --> Controller Class Initialized
INFO - 2024-09-05 23:30:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:30:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:30:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:30:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:30:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:30:12 --> Final output sent to browser
DEBUG - 2024-09-05 23:30:12 --> Total execution time: 0.1164
INFO - 2024-09-05 23:30:21 --> Config Class Initialized
INFO - 2024-09-05 23:30:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:30:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:30:21 --> Utf8 Class Initialized
INFO - 2024-09-05 23:30:21 --> URI Class Initialized
INFO - 2024-09-05 23:30:21 --> Router Class Initialized
INFO - 2024-09-05 23:30:21 --> Output Class Initialized
INFO - 2024-09-05 23:30:21 --> Security Class Initialized
DEBUG - 2024-09-05 23:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:30:21 --> Input Class Initialized
INFO - 2024-09-05 23:30:21 --> Language Class Initialized
INFO - 2024-09-05 23:30:21 --> Loader Class Initialized
INFO - 2024-09-05 23:30:21 --> Helper loaded: url_helper
INFO - 2024-09-05 23:30:21 --> Helper loaded: file_helper
INFO - 2024-09-05 23:30:21 --> Helper loaded: security_helper
INFO - 2024-09-05 23:30:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:30:21 --> Database Driver Class Initialized
INFO - 2024-09-05 23:30:21 --> Email Class Initialized
DEBUG - 2024-09-05 23:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:30:21 --> Helper loaded: form_helper
INFO - 2024-09-05 23:30:21 --> Form Validation Class Initialized
INFO - 2024-09-05 23:30:21 --> Controller Class Initialized
INFO - 2024-09-05 23:30:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:30:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:30:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:30:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:30:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:30:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:30:21 --> Final output sent to browser
DEBUG - 2024-09-05 23:30:21 --> Total execution time: 0.1343
INFO - 2024-09-05 23:30:23 --> Config Class Initialized
INFO - 2024-09-05 23:30:23 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:30:23 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:30:23 --> Utf8 Class Initialized
INFO - 2024-09-05 23:30:23 --> URI Class Initialized
INFO - 2024-09-05 23:30:23 --> Router Class Initialized
INFO - 2024-09-05 23:30:23 --> Output Class Initialized
INFO - 2024-09-05 23:30:23 --> Security Class Initialized
DEBUG - 2024-09-05 23:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:30:23 --> Input Class Initialized
INFO - 2024-09-05 23:30:23 --> Language Class Initialized
INFO - 2024-09-05 23:30:23 --> Loader Class Initialized
INFO - 2024-09-05 23:30:23 --> Helper loaded: url_helper
INFO - 2024-09-05 23:30:23 --> Helper loaded: file_helper
INFO - 2024-09-05 23:30:23 --> Helper loaded: security_helper
INFO - 2024-09-05 23:30:23 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:30:23 --> Database Driver Class Initialized
INFO - 2024-09-05 23:30:23 --> Email Class Initialized
DEBUG - 2024-09-05 23:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:30:23 --> Helper loaded: form_helper
INFO - 2024-09-05 23:30:23 --> Form Validation Class Initialized
INFO - 2024-09-05 23:30:23 --> Controller Class Initialized
INFO - 2024-09-05 23:30:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:30:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:30:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:30:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:30:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:30:23 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:30:23 --> Final output sent to browser
DEBUG - 2024-09-05 23:30:23 --> Total execution time: 0.1180
INFO - 2024-09-05 23:30:29 --> Config Class Initialized
INFO - 2024-09-05 23:30:29 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:30:29 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:30:29 --> Utf8 Class Initialized
INFO - 2024-09-05 23:30:29 --> URI Class Initialized
INFO - 2024-09-05 23:30:29 --> Router Class Initialized
INFO - 2024-09-05 23:30:29 --> Output Class Initialized
INFO - 2024-09-05 23:30:29 --> Security Class Initialized
DEBUG - 2024-09-05 23:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:30:29 --> Input Class Initialized
INFO - 2024-09-05 23:30:29 --> Language Class Initialized
INFO - 2024-09-05 23:30:29 --> Loader Class Initialized
INFO - 2024-09-05 23:30:29 --> Helper loaded: url_helper
INFO - 2024-09-05 23:30:29 --> Helper loaded: file_helper
INFO - 2024-09-05 23:30:29 --> Helper loaded: security_helper
INFO - 2024-09-05 23:30:29 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:30:29 --> Database Driver Class Initialized
INFO - 2024-09-05 23:30:30 --> Email Class Initialized
DEBUG - 2024-09-05 23:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:30:30 --> Helper loaded: form_helper
INFO - 2024-09-05 23:30:30 --> Form Validation Class Initialized
INFO - 2024-09-05 23:30:30 --> Controller Class Initialized
INFO - 2024-09-05 23:30:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:30:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:30:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:30:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:30:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:30:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:30:30 --> Final output sent to browser
DEBUG - 2024-09-05 23:30:30 --> Total execution time: 0.1291
INFO - 2024-09-05 23:32:51 --> Config Class Initialized
INFO - 2024-09-05 23:32:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:32:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:32:51 --> Utf8 Class Initialized
INFO - 2024-09-05 23:32:51 --> URI Class Initialized
INFO - 2024-09-05 23:32:51 --> Router Class Initialized
INFO - 2024-09-05 23:32:51 --> Output Class Initialized
INFO - 2024-09-05 23:32:51 --> Security Class Initialized
DEBUG - 2024-09-05 23:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:32:51 --> Input Class Initialized
INFO - 2024-09-05 23:32:51 --> Language Class Initialized
INFO - 2024-09-05 23:32:51 --> Loader Class Initialized
INFO - 2024-09-05 23:32:51 --> Helper loaded: url_helper
INFO - 2024-09-05 23:32:51 --> Helper loaded: file_helper
INFO - 2024-09-05 23:32:51 --> Helper loaded: security_helper
INFO - 2024-09-05 23:32:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:32:51 --> Database Driver Class Initialized
INFO - 2024-09-05 23:32:51 --> Email Class Initialized
DEBUG - 2024-09-05 23:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:32:51 --> Helper loaded: form_helper
INFO - 2024-09-05 23:32:51 --> Form Validation Class Initialized
INFO - 2024-09-05 23:32:51 --> Controller Class Initialized
INFO - 2024-09-05 23:32:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:32:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:32:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:32:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:32:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:32:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:32:51 --> Final output sent to browser
DEBUG - 2024-09-05 23:32:51 --> Total execution time: 0.1448
INFO - 2024-09-05 23:33:08 --> Config Class Initialized
INFO - 2024-09-05 23:33:08 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:33:08 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:33:08 --> Utf8 Class Initialized
INFO - 2024-09-05 23:33:08 --> URI Class Initialized
INFO - 2024-09-05 23:33:08 --> Router Class Initialized
INFO - 2024-09-05 23:33:08 --> Output Class Initialized
INFO - 2024-09-05 23:33:08 --> Security Class Initialized
DEBUG - 2024-09-05 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:33:08 --> Input Class Initialized
INFO - 2024-09-05 23:33:08 --> Language Class Initialized
INFO - 2024-09-05 23:33:08 --> Loader Class Initialized
INFO - 2024-09-05 23:33:08 --> Helper loaded: url_helper
INFO - 2024-09-05 23:33:08 --> Helper loaded: file_helper
INFO - 2024-09-05 23:33:08 --> Helper loaded: security_helper
INFO - 2024-09-05 23:33:08 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:33:08 --> Database Driver Class Initialized
INFO - 2024-09-05 23:33:08 --> Email Class Initialized
DEBUG - 2024-09-05 23:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:33:08 --> Helper loaded: form_helper
INFO - 2024-09-05 23:33:08 --> Form Validation Class Initialized
INFO - 2024-09-05 23:33:08 --> Controller Class Initialized
INFO - 2024-09-05 23:33:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:33:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:33:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:33:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:33:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:33:08 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:33:08 --> Final output sent to browser
DEBUG - 2024-09-05 23:33:08 --> Total execution time: 0.1511
INFO - 2024-09-05 23:34:19 --> Config Class Initialized
INFO - 2024-09-05 23:34:19 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:34:19 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:34:19 --> Utf8 Class Initialized
INFO - 2024-09-05 23:34:19 --> URI Class Initialized
INFO - 2024-09-05 23:34:19 --> Router Class Initialized
INFO - 2024-09-05 23:34:19 --> Output Class Initialized
INFO - 2024-09-05 23:34:19 --> Security Class Initialized
DEBUG - 2024-09-05 23:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:34:19 --> Input Class Initialized
INFO - 2024-09-05 23:34:19 --> Language Class Initialized
INFO - 2024-09-05 23:34:19 --> Loader Class Initialized
INFO - 2024-09-05 23:34:19 --> Helper loaded: url_helper
INFO - 2024-09-05 23:34:19 --> Helper loaded: file_helper
INFO - 2024-09-05 23:34:19 --> Helper loaded: security_helper
INFO - 2024-09-05 23:34:19 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:34:19 --> Database Driver Class Initialized
INFO - 2024-09-05 23:34:19 --> Email Class Initialized
DEBUG - 2024-09-05 23:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:34:19 --> Helper loaded: form_helper
INFO - 2024-09-05 23:34:19 --> Form Validation Class Initialized
INFO - 2024-09-05 23:34:19 --> Controller Class Initialized
INFO - 2024-09-05 23:34:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:34:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:34:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:34:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:34:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:34:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:34:19 --> Final output sent to browser
DEBUG - 2024-09-05 23:34:19 --> Total execution time: 0.1308
INFO - 2024-09-05 23:37:35 --> Config Class Initialized
INFO - 2024-09-05 23:37:35 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:37:35 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:37:35 --> Utf8 Class Initialized
INFO - 2024-09-05 23:37:35 --> URI Class Initialized
INFO - 2024-09-05 23:37:35 --> Router Class Initialized
INFO - 2024-09-05 23:37:35 --> Output Class Initialized
INFO - 2024-09-05 23:37:35 --> Security Class Initialized
DEBUG - 2024-09-05 23:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:37:35 --> Input Class Initialized
INFO - 2024-09-05 23:37:35 --> Language Class Initialized
INFO - 2024-09-05 23:37:35 --> Loader Class Initialized
INFO - 2024-09-05 23:37:35 --> Helper loaded: url_helper
INFO - 2024-09-05 23:37:35 --> Helper loaded: file_helper
INFO - 2024-09-05 23:37:35 --> Helper loaded: security_helper
INFO - 2024-09-05 23:37:35 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:37:35 --> Database Driver Class Initialized
INFO - 2024-09-05 23:37:36 --> Email Class Initialized
DEBUG - 2024-09-05 23:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:37:36 --> Helper loaded: form_helper
INFO - 2024-09-05 23:37:36 --> Form Validation Class Initialized
INFO - 2024-09-05 23:37:36 --> Controller Class Initialized
INFO - 2024-09-05 23:37:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:37:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:37:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:37:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:37:36 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:37:36 --> Final output sent to browser
DEBUG - 2024-09-05 23:37:36 --> Total execution time: 0.1878
INFO - 2024-09-05 23:37:51 --> Config Class Initialized
INFO - 2024-09-05 23:37:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:37:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:37:51 --> Utf8 Class Initialized
INFO - 2024-09-05 23:37:51 --> URI Class Initialized
INFO - 2024-09-05 23:37:51 --> Router Class Initialized
INFO - 2024-09-05 23:37:51 --> Output Class Initialized
INFO - 2024-09-05 23:37:51 --> Security Class Initialized
DEBUG - 2024-09-05 23:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:37:51 --> Input Class Initialized
INFO - 2024-09-05 23:37:51 --> Language Class Initialized
INFO - 2024-09-05 23:37:51 --> Loader Class Initialized
INFO - 2024-09-05 23:37:51 --> Helper loaded: url_helper
INFO - 2024-09-05 23:37:51 --> Helper loaded: file_helper
INFO - 2024-09-05 23:37:51 --> Helper loaded: security_helper
INFO - 2024-09-05 23:37:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:37:51 --> Database Driver Class Initialized
INFO - 2024-09-05 23:37:51 --> Email Class Initialized
DEBUG - 2024-09-05 23:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:37:51 --> Helper loaded: form_helper
INFO - 2024-09-05 23:37:51 --> Form Validation Class Initialized
INFO - 2024-09-05 23:37:51 --> Controller Class Initialized
INFO - 2024-09-05 23:37:51 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:37:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:37:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:37:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:37:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:37:51 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:37:51 --> Final output sent to browser
DEBUG - 2024-09-05 23:37:51 --> Total execution time: 0.1387
INFO - 2024-09-05 23:37:56 --> Config Class Initialized
INFO - 2024-09-05 23:37:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:37:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:37:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:37:56 --> URI Class Initialized
INFO - 2024-09-05 23:37:56 --> Router Class Initialized
INFO - 2024-09-05 23:37:56 --> Output Class Initialized
INFO - 2024-09-05 23:37:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:37:56 --> Input Class Initialized
INFO - 2024-09-05 23:37:56 --> Language Class Initialized
INFO - 2024-09-05 23:37:56 --> Loader Class Initialized
INFO - 2024-09-05 23:37:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:37:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:37:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:37:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:37:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:37:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:37:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:37:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:37:56 --> Controller Class Initialized
INFO - 2024-09-05 23:37:56 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:37:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:37:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:37:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:37:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:37:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:37:56 --> Final output sent to browser
DEBUG - 2024-09-05 23:37:56 --> Total execution time: 0.2465
INFO - 2024-09-05 23:39:14 --> Config Class Initialized
INFO - 2024-09-05 23:39:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:39:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:39:14 --> Utf8 Class Initialized
INFO - 2024-09-05 23:39:14 --> URI Class Initialized
INFO - 2024-09-05 23:39:14 --> Router Class Initialized
INFO - 2024-09-05 23:39:14 --> Output Class Initialized
INFO - 2024-09-05 23:39:14 --> Security Class Initialized
DEBUG - 2024-09-05 23:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:39:14 --> Input Class Initialized
INFO - 2024-09-05 23:39:14 --> Language Class Initialized
INFO - 2024-09-05 23:39:14 --> Loader Class Initialized
INFO - 2024-09-05 23:39:14 --> Helper loaded: url_helper
INFO - 2024-09-05 23:39:14 --> Helper loaded: file_helper
INFO - 2024-09-05 23:39:14 --> Helper loaded: security_helper
INFO - 2024-09-05 23:39:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:39:14 --> Database Driver Class Initialized
INFO - 2024-09-05 23:39:14 --> Email Class Initialized
DEBUG - 2024-09-05 23:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:39:14 --> Helper loaded: form_helper
INFO - 2024-09-05 23:39:14 --> Form Validation Class Initialized
INFO - 2024-09-05 23:39:14 --> Controller Class Initialized
INFO - 2024-09-05 23:39:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:39:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:39:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:39:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:39:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:39:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:39:15 --> Final output sent to browser
DEBUG - 2024-09-05 23:39:15 --> Total execution time: 0.2042
INFO - 2024-09-05 23:39:52 --> Config Class Initialized
INFO - 2024-09-05 23:39:52 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:39:52 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:39:52 --> Utf8 Class Initialized
INFO - 2024-09-05 23:39:52 --> URI Class Initialized
INFO - 2024-09-05 23:39:52 --> Router Class Initialized
INFO - 2024-09-05 23:39:52 --> Output Class Initialized
INFO - 2024-09-05 23:39:52 --> Security Class Initialized
DEBUG - 2024-09-05 23:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:39:52 --> Input Class Initialized
INFO - 2024-09-05 23:39:52 --> Language Class Initialized
INFO - 2024-09-05 23:39:52 --> Loader Class Initialized
INFO - 2024-09-05 23:39:52 --> Helper loaded: url_helper
INFO - 2024-09-05 23:39:52 --> Helper loaded: file_helper
INFO - 2024-09-05 23:39:52 --> Helper loaded: security_helper
INFO - 2024-09-05 23:39:52 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:39:52 --> Database Driver Class Initialized
INFO - 2024-09-05 23:39:52 --> Email Class Initialized
DEBUG - 2024-09-05 23:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:39:52 --> Helper loaded: form_helper
INFO - 2024-09-05 23:39:52 --> Form Validation Class Initialized
INFO - 2024-09-05 23:39:52 --> Controller Class Initialized
INFO - 2024-09-05 23:39:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:39:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:39:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:39:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:39:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:39:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:39:52 --> Final output sent to browser
DEBUG - 2024-09-05 23:39:52 --> Total execution time: 0.1450
INFO - 2024-09-05 23:40:18 --> Config Class Initialized
INFO - 2024-09-05 23:40:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:40:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:40:18 --> Utf8 Class Initialized
INFO - 2024-09-05 23:40:18 --> URI Class Initialized
INFO - 2024-09-05 23:40:18 --> Router Class Initialized
INFO - 2024-09-05 23:40:18 --> Output Class Initialized
INFO - 2024-09-05 23:40:18 --> Security Class Initialized
DEBUG - 2024-09-05 23:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:40:18 --> Input Class Initialized
INFO - 2024-09-05 23:40:18 --> Language Class Initialized
INFO - 2024-09-05 23:40:18 --> Loader Class Initialized
INFO - 2024-09-05 23:40:18 --> Helper loaded: url_helper
INFO - 2024-09-05 23:40:18 --> Helper loaded: file_helper
INFO - 2024-09-05 23:40:18 --> Helper loaded: security_helper
INFO - 2024-09-05 23:40:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:40:18 --> Database Driver Class Initialized
INFO - 2024-09-05 23:40:19 --> Email Class Initialized
DEBUG - 2024-09-05 23:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:40:19 --> Helper loaded: form_helper
INFO - 2024-09-05 23:40:19 --> Form Validation Class Initialized
INFO - 2024-09-05 23:40:19 --> Controller Class Initialized
INFO - 2024-09-05 23:40:19 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:40:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:40:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:40:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:40:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:40:19 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:40:19 --> Final output sent to browser
DEBUG - 2024-09-05 23:40:19 --> Total execution time: 0.1172
INFO - 2024-09-05 23:40:50 --> Config Class Initialized
INFO - 2024-09-05 23:40:50 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:40:50 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:40:50 --> Utf8 Class Initialized
INFO - 2024-09-05 23:40:50 --> URI Class Initialized
INFO - 2024-09-05 23:40:50 --> Router Class Initialized
INFO - 2024-09-05 23:40:50 --> Output Class Initialized
INFO - 2024-09-05 23:40:50 --> Security Class Initialized
DEBUG - 2024-09-05 23:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:40:50 --> Input Class Initialized
INFO - 2024-09-05 23:40:50 --> Language Class Initialized
INFO - 2024-09-05 23:40:50 --> Loader Class Initialized
INFO - 2024-09-05 23:40:50 --> Helper loaded: url_helper
INFO - 2024-09-05 23:40:50 --> Helper loaded: file_helper
INFO - 2024-09-05 23:40:50 --> Helper loaded: security_helper
INFO - 2024-09-05 23:40:50 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:40:50 --> Database Driver Class Initialized
INFO - 2024-09-05 23:40:50 --> Email Class Initialized
DEBUG - 2024-09-05 23:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:40:50 --> Helper loaded: form_helper
INFO - 2024-09-05 23:40:50 --> Form Validation Class Initialized
INFO - 2024-09-05 23:40:50 --> Controller Class Initialized
INFO - 2024-09-05 23:40:50 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:40:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:40:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:40:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:40:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:40:50 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:40:50 --> Final output sent to browser
DEBUG - 2024-09-05 23:40:50 --> Total execution time: 0.2557
INFO - 2024-09-05 23:42:25 --> Config Class Initialized
INFO - 2024-09-05 23:42:25 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:42:25 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:42:25 --> Utf8 Class Initialized
INFO - 2024-09-05 23:42:25 --> URI Class Initialized
INFO - 2024-09-05 23:42:25 --> Router Class Initialized
INFO - 2024-09-05 23:42:25 --> Output Class Initialized
INFO - 2024-09-05 23:42:25 --> Security Class Initialized
DEBUG - 2024-09-05 23:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:42:25 --> Input Class Initialized
INFO - 2024-09-05 23:42:25 --> Language Class Initialized
INFO - 2024-09-05 23:42:25 --> Loader Class Initialized
INFO - 2024-09-05 23:42:25 --> Helper loaded: url_helper
INFO - 2024-09-05 23:42:25 --> Helper loaded: file_helper
INFO - 2024-09-05 23:42:25 --> Helper loaded: security_helper
INFO - 2024-09-05 23:42:25 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:42:25 --> Database Driver Class Initialized
INFO - 2024-09-05 23:42:25 --> Email Class Initialized
DEBUG - 2024-09-05 23:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:42:25 --> Helper loaded: form_helper
INFO - 2024-09-05 23:42:25 --> Form Validation Class Initialized
INFO - 2024-09-05 23:42:25 --> Controller Class Initialized
INFO - 2024-09-05 23:42:25 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:42:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:42:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:42:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:42:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:42:25 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:42:25 --> Final output sent to browser
DEBUG - 2024-09-05 23:42:25 --> Total execution time: 0.1701
INFO - 2024-09-05 23:43:09 --> Config Class Initialized
INFO - 2024-09-05 23:43:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:43:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:43:09 --> Utf8 Class Initialized
INFO - 2024-09-05 23:43:09 --> URI Class Initialized
INFO - 2024-09-05 23:43:09 --> Router Class Initialized
INFO - 2024-09-05 23:43:09 --> Output Class Initialized
INFO - 2024-09-05 23:43:09 --> Security Class Initialized
DEBUG - 2024-09-05 23:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:43:09 --> Input Class Initialized
INFO - 2024-09-05 23:43:09 --> Language Class Initialized
INFO - 2024-09-05 23:43:09 --> Loader Class Initialized
INFO - 2024-09-05 23:43:09 --> Helper loaded: url_helper
INFO - 2024-09-05 23:43:09 --> Helper loaded: file_helper
INFO - 2024-09-05 23:43:09 --> Helper loaded: security_helper
INFO - 2024-09-05 23:43:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:43:09 --> Database Driver Class Initialized
INFO - 2024-09-05 23:43:09 --> Email Class Initialized
DEBUG - 2024-09-05 23:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:43:09 --> Helper loaded: form_helper
INFO - 2024-09-05 23:43:09 --> Form Validation Class Initialized
INFO - 2024-09-05 23:43:09 --> Controller Class Initialized
INFO - 2024-09-05 23:43:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:43:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:43:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:43:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:43:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:43:09 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:43:09 --> Final output sent to browser
DEBUG - 2024-09-05 23:43:09 --> Total execution time: 0.1434
INFO - 2024-09-05 23:43:15 --> Config Class Initialized
INFO - 2024-09-05 23:43:15 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:43:15 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:43:15 --> Utf8 Class Initialized
INFO - 2024-09-05 23:43:15 --> URI Class Initialized
INFO - 2024-09-05 23:43:15 --> Router Class Initialized
INFO - 2024-09-05 23:43:15 --> Output Class Initialized
INFO - 2024-09-05 23:43:15 --> Security Class Initialized
DEBUG - 2024-09-05 23:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:43:15 --> Input Class Initialized
INFO - 2024-09-05 23:43:15 --> Language Class Initialized
INFO - 2024-09-05 23:43:15 --> Loader Class Initialized
INFO - 2024-09-05 23:43:15 --> Helper loaded: url_helper
INFO - 2024-09-05 23:43:15 --> Helper loaded: file_helper
INFO - 2024-09-05 23:43:15 --> Helper loaded: security_helper
INFO - 2024-09-05 23:43:15 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:43:15 --> Database Driver Class Initialized
INFO - 2024-09-05 23:43:15 --> Email Class Initialized
DEBUG - 2024-09-05 23:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:43:15 --> Helper loaded: form_helper
INFO - 2024-09-05 23:43:15 --> Form Validation Class Initialized
INFO - 2024-09-05 23:43:15 --> Controller Class Initialized
INFO - 2024-09-05 23:43:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:43:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:43:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:43:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:43:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:43:15 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:43:15 --> Final output sent to browser
DEBUG - 2024-09-05 23:43:15 --> Total execution time: 0.1756
INFO - 2024-09-05 23:43:29 --> Config Class Initialized
INFO - 2024-09-05 23:43:29 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:43:29 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:43:29 --> Utf8 Class Initialized
INFO - 2024-09-05 23:43:29 --> URI Class Initialized
INFO - 2024-09-05 23:43:29 --> Router Class Initialized
INFO - 2024-09-05 23:43:29 --> Output Class Initialized
INFO - 2024-09-05 23:43:29 --> Security Class Initialized
DEBUG - 2024-09-05 23:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:43:29 --> Input Class Initialized
INFO - 2024-09-05 23:43:29 --> Language Class Initialized
INFO - 2024-09-05 23:43:29 --> Loader Class Initialized
INFO - 2024-09-05 23:43:29 --> Helper loaded: url_helper
INFO - 2024-09-05 23:43:29 --> Helper loaded: file_helper
INFO - 2024-09-05 23:43:29 --> Helper loaded: security_helper
INFO - 2024-09-05 23:43:29 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:43:29 --> Database Driver Class Initialized
INFO - 2024-09-05 23:43:29 --> Email Class Initialized
DEBUG - 2024-09-05 23:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:43:29 --> Helper loaded: form_helper
INFO - 2024-09-05 23:43:29 --> Form Validation Class Initialized
INFO - 2024-09-05 23:43:29 --> Controller Class Initialized
INFO - 2024-09-05 23:43:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:43:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:43:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:43:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:43:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:43:29 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:43:29 --> Final output sent to browser
DEBUG - 2024-09-05 23:43:29 --> Total execution time: 0.1469
INFO - 2024-09-05 23:45:30 --> Config Class Initialized
INFO - 2024-09-05 23:45:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:45:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:45:30 --> Utf8 Class Initialized
INFO - 2024-09-05 23:45:30 --> URI Class Initialized
INFO - 2024-09-05 23:45:30 --> Router Class Initialized
INFO - 2024-09-05 23:45:30 --> Output Class Initialized
INFO - 2024-09-05 23:45:30 --> Security Class Initialized
DEBUG - 2024-09-05 23:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:45:30 --> Input Class Initialized
INFO - 2024-09-05 23:45:30 --> Language Class Initialized
INFO - 2024-09-05 23:45:30 --> Loader Class Initialized
INFO - 2024-09-05 23:45:30 --> Helper loaded: url_helper
INFO - 2024-09-05 23:45:30 --> Helper loaded: file_helper
INFO - 2024-09-05 23:45:30 --> Helper loaded: security_helper
INFO - 2024-09-05 23:45:30 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:45:30 --> Database Driver Class Initialized
INFO - 2024-09-05 23:45:30 --> Email Class Initialized
DEBUG - 2024-09-05 23:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:45:30 --> Helper loaded: form_helper
INFO - 2024-09-05 23:45:30 --> Form Validation Class Initialized
INFO - 2024-09-05 23:45:30 --> Controller Class Initialized
INFO - 2024-09-05 23:45:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:45:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:45:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:45:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:45:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:45:30 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:45:30 --> Final output sent to browser
DEBUG - 2024-09-05 23:45:30 --> Total execution time: 0.1646
INFO - 2024-09-05 23:45:44 --> Config Class Initialized
INFO - 2024-09-05 23:45:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:45:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:45:44 --> Utf8 Class Initialized
INFO - 2024-09-05 23:45:44 --> URI Class Initialized
INFO - 2024-09-05 23:45:44 --> Router Class Initialized
INFO - 2024-09-05 23:45:44 --> Output Class Initialized
INFO - 2024-09-05 23:45:44 --> Security Class Initialized
DEBUG - 2024-09-05 23:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:45:44 --> Input Class Initialized
INFO - 2024-09-05 23:45:44 --> Language Class Initialized
INFO - 2024-09-05 23:45:44 --> Loader Class Initialized
INFO - 2024-09-05 23:45:44 --> Helper loaded: url_helper
INFO - 2024-09-05 23:45:44 --> Helper loaded: file_helper
INFO - 2024-09-05 23:45:44 --> Helper loaded: security_helper
INFO - 2024-09-05 23:45:44 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:45:44 --> Database Driver Class Initialized
INFO - 2024-09-05 23:45:44 --> Email Class Initialized
DEBUG - 2024-09-05 23:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:45:44 --> Helper loaded: form_helper
INFO - 2024-09-05 23:45:44 --> Form Validation Class Initialized
INFO - 2024-09-05 23:45:44 --> Controller Class Initialized
INFO - 2024-09-05 23:45:44 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:45:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:45:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:45:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:45:44 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:45:44 --> Final output sent to browser
DEBUG - 2024-09-05 23:45:44 --> Total execution time: 0.1326
INFO - 2024-09-05 23:49:12 --> Config Class Initialized
INFO - 2024-09-05 23:49:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:12 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:12 --> URI Class Initialized
INFO - 2024-09-05 23:49:12 --> Router Class Initialized
INFO - 2024-09-05 23:49:12 --> Output Class Initialized
INFO - 2024-09-05 23:49:12 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:12 --> Input Class Initialized
INFO - 2024-09-05 23:49:12 --> Language Class Initialized
INFO - 2024-09-05 23:49:12 --> Loader Class Initialized
INFO - 2024-09-05 23:49:12 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:12 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:12 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:12 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:12 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:12 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:12 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:12 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:12 --> Controller Class Initialized
INFO - 2024-09-05 23:49:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:49:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:49:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:49:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\report/cetakantrol.php
INFO - 2024-09-05 23:49:12 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:49:12 --> Final output sent to browser
DEBUG - 2024-09-05 23:49:12 --> Total execution time: 0.1815
INFO - 2024-09-05 23:49:18 --> Config Class Initialized
INFO - 2024-09-05 23:49:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:18 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:18 --> URI Class Initialized
INFO - 2024-09-05 23:49:18 --> Router Class Initialized
INFO - 2024-09-05 23:49:18 --> Output Class Initialized
INFO - 2024-09-05 23:49:18 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:18 --> Input Class Initialized
INFO - 2024-09-05 23:49:18 --> Language Class Initialized
INFO - 2024-09-05 23:49:18 --> Loader Class Initialized
INFO - 2024-09-05 23:49:18 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:18 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:18 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:18 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:18 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:18 --> Controller Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:18 --> Config Class Initialized
INFO - 2024-09-05 23:49:18 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:18 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:18 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:18 --> URI Class Initialized
INFO - 2024-09-05 23:49:18 --> Router Class Initialized
INFO - 2024-09-05 23:49:18 --> Output Class Initialized
INFO - 2024-09-05 23:49:18 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:18 --> Input Class Initialized
INFO - 2024-09-05 23:49:18 --> Language Class Initialized
INFO - 2024-09-05 23:49:18 --> Loader Class Initialized
INFO - 2024-09-05 23:49:18 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:18 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:18 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:18 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:18 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:18 --> Controller Class Initialized
DEBUG - 2024-09-05 23:49:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:49:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:49:18 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:49:18 --> Final output sent to browser
DEBUG - 2024-09-05 23:49:18 --> Total execution time: 0.0450
INFO - 2024-09-05 23:49:20 --> Config Class Initialized
INFO - 2024-09-05 23:49:20 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:20 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:20 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:20 --> URI Class Initialized
INFO - 2024-09-05 23:49:20 --> Router Class Initialized
INFO - 2024-09-05 23:49:20 --> Output Class Initialized
INFO - 2024-09-05 23:49:20 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:20 --> Input Class Initialized
INFO - 2024-09-05 23:49:20 --> Language Class Initialized
INFO - 2024-09-05 23:49:20 --> Loader Class Initialized
INFO - 2024-09-05 23:49:20 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:20 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:20 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:20 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:20 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:20 --> Controller Class Initialized
DEBUG - 2024-09-05 23:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:49:20 --> Config Class Initialized
INFO - 2024-09-05 23:49:20 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:20 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:20 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:20 --> URI Class Initialized
INFO - 2024-09-05 23:49:20 --> Router Class Initialized
INFO - 2024-09-05 23:49:20 --> Output Class Initialized
INFO - 2024-09-05 23:49:20 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:20 --> Input Class Initialized
INFO - 2024-09-05 23:49:20 --> Language Class Initialized
INFO - 2024-09-05 23:49:20 --> Loader Class Initialized
INFO - 2024-09-05 23:49:20 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:20 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:20 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:20 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:20 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:20 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:20 --> Controller Class Initialized
INFO - 2024-09-05 23:49:20 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:49:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:49:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:49:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:49:20 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:49:20 --> Final output sent to browser
DEBUG - 2024-09-05 23:49:20 --> Total execution time: 0.1216
INFO - 2024-09-05 23:49:28 --> Config Class Initialized
INFO - 2024-09-05 23:49:28 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:28 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:28 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:28 --> URI Class Initialized
INFO - 2024-09-05 23:49:28 --> Router Class Initialized
INFO - 2024-09-05 23:49:28 --> Output Class Initialized
INFO - 2024-09-05 23:49:28 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:28 --> Input Class Initialized
INFO - 2024-09-05 23:49:28 --> Language Class Initialized
INFO - 2024-09-05 23:49:28 --> Loader Class Initialized
INFO - 2024-09-05 23:49:28 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:28 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:28 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:28 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:28 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:28 --> Controller Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:28 --> Config Class Initialized
INFO - 2024-09-05 23:49:28 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:28 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:28 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:28 --> URI Class Initialized
INFO - 2024-09-05 23:49:28 --> Router Class Initialized
INFO - 2024-09-05 23:49:28 --> Output Class Initialized
INFO - 2024-09-05 23:49:28 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:28 --> Input Class Initialized
INFO - 2024-09-05 23:49:28 --> Language Class Initialized
INFO - 2024-09-05 23:49:28 --> Loader Class Initialized
INFO - 2024-09-05 23:49:28 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:28 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:28 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:28 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:28 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:28 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:28 --> Controller Class Initialized
DEBUG - 2024-09-05 23:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:49:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:49:28 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:49:28 --> Final output sent to browser
DEBUG - 2024-09-05 23:49:28 --> Total execution time: 0.0536
INFO - 2024-09-05 23:49:34 --> Config Class Initialized
INFO - 2024-09-05 23:49:34 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:34 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:34 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:34 --> URI Class Initialized
INFO - 2024-09-05 23:49:34 --> Router Class Initialized
INFO - 2024-09-05 23:49:34 --> Output Class Initialized
INFO - 2024-09-05 23:49:34 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:34 --> Input Class Initialized
INFO - 2024-09-05 23:49:34 --> Language Class Initialized
ERROR - 2024-09-05 23:49:34 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 23:49:40 --> Config Class Initialized
INFO - 2024-09-05 23:49:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:49:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:49:40 --> Utf8 Class Initialized
INFO - 2024-09-05 23:49:40 --> URI Class Initialized
INFO - 2024-09-05 23:49:40 --> Router Class Initialized
INFO - 2024-09-05 23:49:40 --> Output Class Initialized
INFO - 2024-09-05 23:49:40 --> Security Class Initialized
DEBUG - 2024-09-05 23:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:49:40 --> Input Class Initialized
INFO - 2024-09-05 23:49:40 --> Language Class Initialized
INFO - 2024-09-05 23:49:40 --> Loader Class Initialized
INFO - 2024-09-05 23:49:40 --> Helper loaded: url_helper
INFO - 2024-09-05 23:49:40 --> Helper loaded: file_helper
INFO - 2024-09-05 23:49:40 --> Helper loaded: security_helper
INFO - 2024-09-05 23:49:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:49:40 --> Database Driver Class Initialized
INFO - 2024-09-05 23:49:40 --> Email Class Initialized
DEBUG - 2024-09-05 23:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:49:40 --> Helper loaded: form_helper
INFO - 2024-09-05 23:49:40 --> Form Validation Class Initialized
INFO - 2024-09-05 23:49:40 --> Controller Class Initialized
INFO - 2024-09-05 23:49:40 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:49:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:49:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:49:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:49:40 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:49:40 --> Final output sent to browser
DEBUG - 2024-09-05 23:49:40 --> Total execution time: 0.1188
INFO - 2024-09-05 23:50:17 --> Config Class Initialized
INFO - 2024-09-05 23:50:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:50:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:50:17 --> Utf8 Class Initialized
INFO - 2024-09-05 23:50:17 --> URI Class Initialized
INFO - 2024-09-05 23:50:17 --> Router Class Initialized
INFO - 2024-09-05 23:50:17 --> Output Class Initialized
INFO - 2024-09-05 23:50:17 --> Security Class Initialized
DEBUG - 2024-09-05 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:50:17 --> Input Class Initialized
INFO - 2024-09-05 23:50:17 --> Language Class Initialized
INFO - 2024-09-05 23:50:17 --> Loader Class Initialized
INFO - 2024-09-05 23:50:17 --> Helper loaded: url_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: file_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: security_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:50:17 --> Database Driver Class Initialized
INFO - 2024-09-05 23:50:17 --> Email Class Initialized
DEBUG - 2024-09-05 23:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:50:17 --> Helper loaded: form_helper
INFO - 2024-09-05 23:50:17 --> Form Validation Class Initialized
INFO - 2024-09-05 23:50:17 --> Controller Class Initialized
INFO - 2024-09-05 23:50:17 --> Config Class Initialized
INFO - 2024-09-05 23:50:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:50:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:50:17 --> Utf8 Class Initialized
INFO - 2024-09-05 23:50:17 --> URI Class Initialized
INFO - 2024-09-05 23:50:17 --> Router Class Initialized
INFO - 2024-09-05 23:50:17 --> Output Class Initialized
INFO - 2024-09-05 23:50:17 --> Security Class Initialized
DEBUG - 2024-09-05 23:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:50:17 --> Input Class Initialized
INFO - 2024-09-05 23:50:17 --> Language Class Initialized
INFO - 2024-09-05 23:50:17 --> Loader Class Initialized
INFO - 2024-09-05 23:50:17 --> Helper loaded: url_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: file_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: security_helper
INFO - 2024-09-05 23:50:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:50:17 --> Database Driver Class Initialized
INFO - 2024-09-05 23:50:17 --> Email Class Initialized
DEBUG - 2024-09-05 23:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:50:17 --> Helper loaded: form_helper
INFO - 2024-09-05 23:50:17 --> Form Validation Class Initialized
INFO - 2024-09-05 23:50:17 --> Controller Class Initialized
DEBUG - 2024-09-05 23:50:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:50:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:50:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:50:17 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:50:17 --> Final output sent to browser
DEBUG - 2024-09-05 23:50:17 --> Total execution time: 0.0594
INFO - 2024-09-05 23:50:21 --> Config Class Initialized
INFO - 2024-09-05 23:50:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:50:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:50:21 --> Utf8 Class Initialized
INFO - 2024-09-05 23:50:21 --> URI Class Initialized
INFO - 2024-09-05 23:50:21 --> Router Class Initialized
INFO - 2024-09-05 23:50:21 --> Output Class Initialized
INFO - 2024-09-05 23:50:21 --> Security Class Initialized
DEBUG - 2024-09-05 23:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:50:21 --> Input Class Initialized
INFO - 2024-09-05 23:50:21 --> Language Class Initialized
INFO - 2024-09-05 23:50:21 --> Loader Class Initialized
INFO - 2024-09-05 23:50:21 --> Helper loaded: url_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: file_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: security_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:50:21 --> Database Driver Class Initialized
INFO - 2024-09-05 23:50:21 --> Email Class Initialized
DEBUG - 2024-09-05 23:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:50:21 --> Helper loaded: form_helper
INFO - 2024-09-05 23:50:21 --> Form Validation Class Initialized
INFO - 2024-09-05 23:50:21 --> Controller Class Initialized
INFO - 2024-09-05 23:50:21 --> Config Class Initialized
INFO - 2024-09-05 23:50:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:50:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:50:21 --> Utf8 Class Initialized
INFO - 2024-09-05 23:50:21 --> URI Class Initialized
INFO - 2024-09-05 23:50:21 --> Router Class Initialized
INFO - 2024-09-05 23:50:21 --> Output Class Initialized
INFO - 2024-09-05 23:50:21 --> Security Class Initialized
DEBUG - 2024-09-05 23:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:50:21 --> Input Class Initialized
INFO - 2024-09-05 23:50:21 --> Language Class Initialized
INFO - 2024-09-05 23:50:21 --> Loader Class Initialized
INFO - 2024-09-05 23:50:21 --> Helper loaded: url_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: file_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: security_helper
INFO - 2024-09-05 23:50:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:50:21 --> Database Driver Class Initialized
INFO - 2024-09-05 23:50:21 --> Email Class Initialized
DEBUG - 2024-09-05 23:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:50:21 --> Helper loaded: form_helper
INFO - 2024-09-05 23:50:21 --> Form Validation Class Initialized
INFO - 2024-09-05 23:50:21 --> Controller Class Initialized
DEBUG - 2024-09-05 23:50:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:50:21 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:50:21 --> Final output sent to browser
DEBUG - 2024-09-05 23:50:21 --> Total execution time: 0.0411
INFO - 2024-09-05 23:51:17 --> Config Class Initialized
INFO - 2024-09-05 23:51:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:17 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:17 --> URI Class Initialized
INFO - 2024-09-05 23:51:17 --> Router Class Initialized
INFO - 2024-09-05 23:51:17 --> Output Class Initialized
INFO - 2024-09-05 23:51:17 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:17 --> Input Class Initialized
INFO - 2024-09-05 23:51:17 --> Language Class Initialized
INFO - 2024-09-05 23:51:17 --> Loader Class Initialized
INFO - 2024-09-05 23:51:17 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:17 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:17 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:17 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:17 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:17 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:17 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:17 --> Controller Class Initialized
DEBUG - 2024-09-05 23:51:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:51:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:51:17 --> Config Class Initialized
INFO - 2024-09-05 23:51:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:17 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:17 --> URI Class Initialized
INFO - 2024-09-05 23:51:18 --> Router Class Initialized
INFO - 2024-09-05 23:51:18 --> Output Class Initialized
INFO - 2024-09-05 23:51:18 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:18 --> Input Class Initialized
INFO - 2024-09-05 23:51:18 --> Language Class Initialized
INFO - 2024-09-05 23:51:18 --> Loader Class Initialized
INFO - 2024-09-05 23:51:18 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:18 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:18 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:18 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:18 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:18 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:18 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:18 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:18 --> Controller Class Initialized
ERROR - 2024-09-05 23:51:18 --> Query error: Table 'rsaz_sik.user_menu' doesn't exist - Invalid query: SELECT *
FROM `user_menu`
WHERE `menu` = 'antrol'
INFO - 2024-09-05 23:51:18 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 23:51:41 --> Config Class Initialized
INFO - 2024-09-05 23:51:41 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:41 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:41 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:41 --> URI Class Initialized
INFO - 2024-09-05 23:51:41 --> Router Class Initialized
INFO - 2024-09-05 23:51:41 --> Output Class Initialized
INFO - 2024-09-05 23:51:41 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:41 --> Input Class Initialized
INFO - 2024-09-05 23:51:41 --> Language Class Initialized
INFO - 2024-09-05 23:51:41 --> Loader Class Initialized
INFO - 2024-09-05 23:51:41 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:41 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:41 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:41 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:41 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:41 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:41 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:41 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:41 --> Controller Class Initialized
ERROR - 2024-09-05 23:51:41 --> Query error: Table 'rsaz_sik.user_menu' doesn't exist - Invalid query: SELECT *
FROM `user_menu`
WHERE `menu` = 'antrol'
INFO - 2024-09-05 23:51:41 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 23:51:43 --> Config Class Initialized
INFO - 2024-09-05 23:51:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:43 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:43 --> URI Class Initialized
INFO - 2024-09-05 23:51:43 --> Router Class Initialized
INFO - 2024-09-05 23:51:43 --> Output Class Initialized
INFO - 2024-09-05 23:51:43 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:43 --> Input Class Initialized
INFO - 2024-09-05 23:51:43 --> Language Class Initialized
INFO - 2024-09-05 23:51:43 --> Loader Class Initialized
INFO - 2024-09-05 23:51:43 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:43 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:43 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:43 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:43 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:43 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:43 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:43 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:43 --> Controller Class Initialized
DEBUG - 2024-09-05 23:51:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:51:43 --> Config Class Initialized
INFO - 2024-09-05 23:51:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:43 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:43 --> URI Class Initialized
INFO - 2024-09-05 23:51:43 --> Router Class Initialized
INFO - 2024-09-05 23:51:43 --> Output Class Initialized
INFO - 2024-09-05 23:51:43 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:43 --> Input Class Initialized
INFO - 2024-09-05 23:51:43 --> Language Class Initialized
ERROR - 2024-09-05 23:51:43 --> 404 Page Not Found: User/index
INFO - 2024-09-05 23:51:46 --> Config Class Initialized
INFO - 2024-09-05 23:51:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:46 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:46 --> URI Class Initialized
INFO - 2024-09-05 23:51:46 --> Router Class Initialized
INFO - 2024-09-05 23:51:46 --> Output Class Initialized
INFO - 2024-09-05 23:51:46 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:46 --> Input Class Initialized
INFO - 2024-09-05 23:51:46 --> Language Class Initialized
INFO - 2024-09-05 23:51:46 --> Loader Class Initialized
INFO - 2024-09-05 23:51:46 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:46 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:46 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:46 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:46 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:46 --> Controller Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:51:46 --> Config Class Initialized
INFO - 2024-09-05 23:51:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:46 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:46 --> URI Class Initialized
INFO - 2024-09-05 23:51:46 --> Router Class Initialized
INFO - 2024-09-05 23:51:46 --> Output Class Initialized
INFO - 2024-09-05 23:51:46 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:46 --> Input Class Initialized
INFO - 2024-09-05 23:51:46 --> Language Class Initialized
INFO - 2024-09-05 23:51:46 --> Loader Class Initialized
INFO - 2024-09-05 23:51:46 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:46 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:46 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:46 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:46 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:46 --> Controller Class Initialized
DEBUG - 2024-09-05 23:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:51:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:51:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:51:46 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:51:46 --> Final output sent to browser
DEBUG - 2024-09-05 23:51:46 --> Total execution time: 0.0540
INFO - 2024-09-05 23:51:47 --> Config Class Initialized
INFO - 2024-09-05 23:51:47 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:47 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:47 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:47 --> URI Class Initialized
INFO - 2024-09-05 23:51:47 --> Router Class Initialized
INFO - 2024-09-05 23:51:47 --> Output Class Initialized
INFO - 2024-09-05 23:51:47 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:47 --> Input Class Initialized
INFO - 2024-09-05 23:51:47 --> Language Class Initialized
INFO - 2024-09-05 23:51:47 --> Loader Class Initialized
INFO - 2024-09-05 23:51:47 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:47 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:47 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:47 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:47 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:47 --> Controller Class Initialized
DEBUG - 2024-09-05 23:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:51:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:51:47 --> Config Class Initialized
INFO - 2024-09-05 23:51:47 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:51:47 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:51:47 --> Utf8 Class Initialized
INFO - 2024-09-05 23:51:47 --> URI Class Initialized
INFO - 2024-09-05 23:51:47 --> Router Class Initialized
INFO - 2024-09-05 23:51:47 --> Output Class Initialized
INFO - 2024-09-05 23:51:47 --> Security Class Initialized
DEBUG - 2024-09-05 23:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:51:47 --> Input Class Initialized
INFO - 2024-09-05 23:51:47 --> Language Class Initialized
INFO - 2024-09-05 23:51:47 --> Loader Class Initialized
INFO - 2024-09-05 23:51:47 --> Helper loaded: url_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: file_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: security_helper
INFO - 2024-09-05 23:51:47 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:51:47 --> Database Driver Class Initialized
INFO - 2024-09-05 23:51:47 --> Email Class Initialized
DEBUG - 2024-09-05 23:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:51:47 --> Helper loaded: form_helper
INFO - 2024-09-05 23:51:47 --> Form Validation Class Initialized
INFO - 2024-09-05 23:51:47 --> Controller Class Initialized
ERROR - 2024-09-05 23:51:47 --> Query error: Table 'rsaz_sik.user_menu' doesn't exist - Invalid query: SELECT *
FROM `user_menu`
WHERE `menu` = 'antrol'
INFO - 2024-09-05 23:51:47 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 23:53:49 --> Config Class Initialized
INFO - 2024-09-05 23:53:49 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:49 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:49 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:49 --> URI Class Initialized
INFO - 2024-09-05 23:53:49 --> Router Class Initialized
INFO - 2024-09-05 23:53:49 --> Output Class Initialized
INFO - 2024-09-05 23:53:49 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:49 --> Input Class Initialized
INFO - 2024-09-05 23:53:49 --> Language Class Initialized
INFO - 2024-09-05 23:53:49 --> Loader Class Initialized
INFO - 2024-09-05 23:53:49 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:49 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:49 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:49 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:49 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:49 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:49 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:49 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:49 --> Controller Class Initialized
DEBUG - 2024-09-05 23:53:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:53:51 --> Config Class Initialized
INFO - 2024-09-05 23:53:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:51 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:51 --> URI Class Initialized
INFO - 2024-09-05 23:53:51 --> Router Class Initialized
INFO - 2024-09-05 23:53:51 --> Output Class Initialized
INFO - 2024-09-05 23:53:51 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:51 --> Input Class Initialized
INFO - 2024-09-05 23:53:51 --> Language Class Initialized
INFO - 2024-09-05 23:53:51 --> Loader Class Initialized
INFO - 2024-09-05 23:53:51 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:51 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:51 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:51 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:51 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:51 --> Controller Class Initialized
DEBUG - 2024-09-05 23:53:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:53:51 --> Config Class Initialized
INFO - 2024-09-05 23:53:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:51 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:51 --> URI Class Initialized
INFO - 2024-09-05 23:53:51 --> Router Class Initialized
INFO - 2024-09-05 23:53:51 --> Output Class Initialized
INFO - 2024-09-05 23:53:51 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:51 --> Input Class Initialized
INFO - 2024-09-05 23:53:51 --> Language Class Initialized
INFO - 2024-09-05 23:53:51 --> Loader Class Initialized
INFO - 2024-09-05 23:53:51 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:51 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:52 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:52 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:52 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:52 --> Controller Class Initialized
DEBUG - 2024-09-05 23:53:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:53:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:53:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:53:52 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:53:52 --> Final output sent to browser
DEBUG - 2024-09-05 23:53:52 --> Total execution time: 0.0451
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:53:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:53 --> Controller Class Initialized
INFO - 2024-09-05 23:53:53 --> Config Class Initialized
INFO - 2024-09-05 23:53:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:53 --> URI Class Initialized
INFO - 2024-09-05 23:53:53 --> Router Class Initialized
INFO - 2024-09-05 23:53:53 --> Output Class Initialized
INFO - 2024-09-05 23:53:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:53 --> Input Class Initialized
INFO - 2024-09-05 23:53:53 --> Language Class Initialized
INFO - 2024-09-05 23:53:53 --> Loader Class Initialized
INFO - 2024-09-05 23:53:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:54 --> Config Class Initialized
INFO - 2024-09-05 23:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:54 --> URI Class Initialized
INFO - 2024-09-05 23:53:54 --> Router Class Initialized
INFO - 2024-09-05 23:53:54 --> Output Class Initialized
INFO - 2024-09-05 23:53:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:54 --> Input Class Initialized
INFO - 2024-09-05 23:53:54 --> Language Class Initialized
INFO - 2024-09-05 23:53:54 --> Loader Class Initialized
INFO - 2024-09-05 23:53:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:54 --> Controller Class Initialized
INFO - 2024-09-05 23:53:55 --> Config Class Initialized
INFO - 2024-09-05 23:53:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:55 --> URI Class Initialized
INFO - 2024-09-05 23:53:55 --> Router Class Initialized
INFO - 2024-09-05 23:53:55 --> Output Class Initialized
INFO - 2024-09-05 23:53:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:55 --> Input Class Initialized
INFO - 2024-09-05 23:53:55 --> Language Class Initialized
INFO - 2024-09-05 23:53:55 --> Loader Class Initialized
INFO - 2024-09-05 23:53:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:55 --> Controller Class Initialized
INFO - 2024-09-05 23:53:55 --> Config Class Initialized
INFO - 2024-09-05 23:53:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:55 --> URI Class Initialized
INFO - 2024-09-05 23:53:55 --> Router Class Initialized
INFO - 2024-09-05 23:53:55 --> Output Class Initialized
INFO - 2024-09-05 23:53:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:55 --> Input Class Initialized
INFO - 2024-09-05 23:53:55 --> Language Class Initialized
INFO - 2024-09-05 23:53:55 --> Loader Class Initialized
INFO - 2024-09-05 23:53:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:55 --> Controller Class Initialized
INFO - 2024-09-05 23:53:55 --> Config Class Initialized
INFO - 2024-09-05 23:53:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:55 --> URI Class Initialized
INFO - 2024-09-05 23:53:55 --> Router Class Initialized
INFO - 2024-09-05 23:53:55 --> Output Class Initialized
INFO - 2024-09-05 23:53:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:55 --> Input Class Initialized
INFO - 2024-09-05 23:53:55 --> Language Class Initialized
INFO - 2024-09-05 23:53:55 --> Loader Class Initialized
INFO - 2024-09-05 23:53:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:55 --> Controller Class Initialized
INFO - 2024-09-05 23:53:55 --> Config Class Initialized
INFO - 2024-09-05 23:53:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:55 --> URI Class Initialized
INFO - 2024-09-05 23:53:55 --> Router Class Initialized
INFO - 2024-09-05 23:53:55 --> Output Class Initialized
INFO - 2024-09-05 23:53:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:55 --> Input Class Initialized
INFO - 2024-09-05 23:53:55 --> Language Class Initialized
INFO - 2024-09-05 23:53:55 --> Loader Class Initialized
INFO - 2024-09-05 23:53:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:55 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:56 --> Output Class Initialized
INFO - 2024-09-05 23:53:56 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:56 --> Input Class Initialized
INFO - 2024-09-05 23:53:56 --> Language Class Initialized
INFO - 2024-09-05 23:53:56 --> Loader Class Initialized
INFO - 2024-09-05 23:53:56 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:56 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:56 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:56 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:56 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:56 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:56 --> Controller Class Initialized
INFO - 2024-09-05 23:53:56 --> Config Class Initialized
INFO - 2024-09-05 23:53:56 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:56 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:56 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:56 --> URI Class Initialized
INFO - 2024-09-05 23:53:56 --> Router Class Initialized
INFO - 2024-09-05 23:53:57 --> Output Class Initialized
INFO - 2024-09-05 23:53:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:57 --> Input Class Initialized
INFO - 2024-09-05 23:53:57 --> Language Class Initialized
INFO - 2024-09-05 23:53:57 --> Loader Class Initialized
INFO - 2024-09-05 23:53:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:57 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:57 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:57 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:57 --> Controller Class Initialized
INFO - 2024-09-05 23:53:57 --> Config Class Initialized
INFO - 2024-09-05 23:53:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:57 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:57 --> URI Class Initialized
INFO - 2024-09-05 23:53:57 --> Router Class Initialized
INFO - 2024-09-05 23:53:57 --> Output Class Initialized
INFO - 2024-09-05 23:53:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:57 --> Input Class Initialized
INFO - 2024-09-05 23:53:57 --> Language Class Initialized
INFO - 2024-09-05 23:53:57 --> Loader Class Initialized
INFO - 2024-09-05 23:53:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:57 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:57 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:57 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:57 --> Controller Class Initialized
INFO - 2024-09-05 23:53:57 --> Config Class Initialized
INFO - 2024-09-05 23:53:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:57 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:57 --> URI Class Initialized
INFO - 2024-09-05 23:53:57 --> Router Class Initialized
INFO - 2024-09-05 23:53:57 --> Output Class Initialized
INFO - 2024-09-05 23:53:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:57 --> Input Class Initialized
INFO - 2024-09-05 23:53:57 --> Language Class Initialized
INFO - 2024-09-05 23:53:57 --> Loader Class Initialized
INFO - 2024-09-05 23:53:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:57 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:57 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:57 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:57 --> Controller Class Initialized
INFO - 2024-09-05 23:53:57 --> Config Class Initialized
INFO - 2024-09-05 23:53:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:57 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:57 --> URI Class Initialized
INFO - 2024-09-05 23:53:57 --> Router Class Initialized
INFO - 2024-09-05 23:53:57 --> Output Class Initialized
INFO - 2024-09-05 23:53:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:57 --> Input Class Initialized
INFO - 2024-09-05 23:53:57 --> Language Class Initialized
INFO - 2024-09-05 23:53:57 --> Loader Class Initialized
INFO - 2024-09-05 23:53:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:57 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:57 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:57 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:57 --> Controller Class Initialized
INFO - 2024-09-05 23:53:57 --> Config Class Initialized
INFO - 2024-09-05 23:53:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:57 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:57 --> URI Class Initialized
INFO - 2024-09-05 23:53:57 --> Router Class Initialized
INFO - 2024-09-05 23:53:57 --> Output Class Initialized
INFO - 2024-09-05 23:53:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:57 --> Input Class Initialized
INFO - 2024-09-05 23:53:57 --> Language Class Initialized
INFO - 2024-09-05 23:53:57 --> Loader Class Initialized
INFO - 2024-09-05 23:53:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:57 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:57 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:57 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:57 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:58 --> Controller Class Initialized
INFO - 2024-09-05 23:53:58 --> Config Class Initialized
INFO - 2024-09-05 23:53:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:58 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:58 --> URI Class Initialized
INFO - 2024-09-05 23:53:58 --> Router Class Initialized
INFO - 2024-09-05 23:53:58 --> Output Class Initialized
INFO - 2024-09-05 23:53:58 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:58 --> Input Class Initialized
INFO - 2024-09-05 23:53:58 --> Language Class Initialized
INFO - 2024-09-05 23:53:58 --> Loader Class Initialized
INFO - 2024-09-05 23:53:58 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:58 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:53:59 --> Config Class Initialized
INFO - 2024-09-05 23:53:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:53:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:53:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:53:59 --> URI Class Initialized
INFO - 2024-09-05 23:53:59 --> Router Class Initialized
INFO - 2024-09-05 23:53:59 --> Output Class Initialized
INFO - 2024-09-05 23:53:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:53:59 --> Input Class Initialized
INFO - 2024-09-05 23:53:59 --> Language Class Initialized
INFO - 2024-09-05 23:53:59 --> Loader Class Initialized
INFO - 2024-09-05 23:53:59 --> Helper loaded: url_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: file_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: security_helper
INFO - 2024-09-05 23:53:59 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:53:59 --> Database Driver Class Initialized
INFO - 2024-09-05 23:53:59 --> Email Class Initialized
DEBUG - 2024-09-05 23:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:53:59 --> Helper loaded: form_helper
INFO - 2024-09-05 23:53:59 --> Form Validation Class Initialized
INFO - 2024-09-05 23:53:59 --> Controller Class Initialized
INFO - 2024-09-05 23:54:01 --> Config Class Initialized
INFO - 2024-09-05 23:54:01 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:01 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:01 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:01 --> URI Class Initialized
INFO - 2024-09-05 23:54:01 --> Router Class Initialized
INFO - 2024-09-05 23:54:01 --> Output Class Initialized
INFO - 2024-09-05 23:54:01 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:01 --> Input Class Initialized
INFO - 2024-09-05 23:54:01 --> Language Class Initialized
INFO - 2024-09-05 23:54:01 --> Loader Class Initialized
INFO - 2024-09-05 23:54:01 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:01 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:01 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:01 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:01 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:01 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:01 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:01 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:01 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:02 --> Config Class Initialized
INFO - 2024-09-05 23:54:02 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:02 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:02 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:02 --> URI Class Initialized
INFO - 2024-09-05 23:54:02 --> Router Class Initialized
INFO - 2024-09-05 23:54:02 --> Output Class Initialized
INFO - 2024-09-05 23:54:02 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:02 --> Input Class Initialized
INFO - 2024-09-05 23:54:02 --> Language Class Initialized
ERROR - 2024-09-05 23:54:02 --> 404 Page Not Found: User/index
INFO - 2024-09-05 23:54:37 --> Config Class Initialized
INFO - 2024-09-05 23:54:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:37 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:37 --> URI Class Initialized
INFO - 2024-09-05 23:54:37 --> Router Class Initialized
INFO - 2024-09-05 23:54:37 --> Output Class Initialized
INFO - 2024-09-05 23:54:37 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:37 --> Input Class Initialized
INFO - 2024-09-05 23:54:37 --> Language Class Initialized
INFO - 2024-09-05 23:54:37 --> Loader Class Initialized
INFO - 2024-09-05 23:54:37 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:37 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:37 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:37 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:37 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:37 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:37 --> Config Class Initialized
INFO - 2024-09-05 23:54:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:37 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:37 --> URI Class Initialized
INFO - 2024-09-05 23:54:37 --> Router Class Initialized
INFO - 2024-09-05 23:54:37 --> Output Class Initialized
INFO - 2024-09-05 23:54:37 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:37 --> Input Class Initialized
INFO - 2024-09-05 23:54:37 --> Language Class Initialized
INFO - 2024-09-05 23:54:37 --> Loader Class Initialized
INFO - 2024-09-05 23:54:37 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:37 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:37 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:37 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:37 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:37 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:54:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:54:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:54:37 --> Final output sent to browser
DEBUG - 2024-09-05 23:54:37 --> Total execution time: 0.0437
INFO - 2024-09-05 23:54:38 --> Config Class Initialized
INFO - 2024-09-05 23:54:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:38 --> URI Class Initialized
INFO - 2024-09-05 23:54:38 --> Router Class Initialized
INFO - 2024-09-05 23:54:38 --> Output Class Initialized
INFO - 2024-09-05 23:54:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:38 --> Input Class Initialized
INFO - 2024-09-05 23:54:38 --> Language Class Initialized
INFO - 2024-09-05 23:54:38 --> Loader Class Initialized
INFO - 2024-09-05 23:54:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:38 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:54:38 --> Config Class Initialized
INFO - 2024-09-05 23:54:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:38 --> URI Class Initialized
INFO - 2024-09-05 23:54:38 --> Router Class Initialized
INFO - 2024-09-05 23:54:38 --> Output Class Initialized
INFO - 2024-09-05 23:54:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:38 --> Input Class Initialized
INFO - 2024-09-05 23:54:38 --> Language Class Initialized
INFO - 2024-09-05 23:54:38 --> Loader Class Initialized
INFO - 2024-09-05 23:54:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:38 --> Controller Class Initialized
ERROR - 2024-09-05 23:54:38 --> Query error: Table 'rsaz_sik.user_menu' doesn't exist - Invalid query: SELECT *
FROM `user_menu`
WHERE `menu` = 'antrol'
INFO - 2024-09-05 23:54:38 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 23:54:53 --> Config Class Initialized
INFO - 2024-09-05 23:54:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:53 --> URI Class Initialized
INFO - 2024-09-05 23:54:53 --> Router Class Initialized
INFO - 2024-09-05 23:54:53 --> Output Class Initialized
INFO - 2024-09-05 23:54:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:53 --> Input Class Initialized
INFO - 2024-09-05 23:54:53 --> Language Class Initialized
INFO - 2024-09-05 23:54:53 --> Loader Class Initialized
INFO - 2024-09-05 23:54:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:53 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:53 --> Config Class Initialized
INFO - 2024-09-05 23:54:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:53 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:53 --> URI Class Initialized
INFO - 2024-09-05 23:54:53 --> Router Class Initialized
INFO - 2024-09-05 23:54:53 --> Output Class Initialized
INFO - 2024-09-05 23:54:53 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:53 --> Input Class Initialized
INFO - 2024-09-05 23:54:53 --> Language Class Initialized
INFO - 2024-09-05 23:54:53 --> Loader Class Initialized
INFO - 2024-09-05 23:54:53 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:53 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:53 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:53 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:53 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:53 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:54:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:54:53 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:54:53 --> Final output sent to browser
DEBUG - 2024-09-05 23:54:53 --> Total execution time: 0.0452
INFO - 2024-09-05 23:54:54 --> Config Class Initialized
INFO - 2024-09-05 23:54:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:54 --> URI Class Initialized
INFO - 2024-09-05 23:54:54 --> Router Class Initialized
INFO - 2024-09-05 23:54:54 --> Output Class Initialized
INFO - 2024-09-05 23:54:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:54 --> Input Class Initialized
INFO - 2024-09-05 23:54:54 --> Language Class Initialized
INFO - 2024-09-05 23:54:54 --> Loader Class Initialized
INFO - 2024-09-05 23:54:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:54 --> Controller Class Initialized
DEBUG - 2024-09-05 23:54:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:54:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:54:54 --> Config Class Initialized
INFO - 2024-09-05 23:54:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:54:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:54:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:54:54 --> URI Class Initialized
INFO - 2024-09-05 23:54:54 --> Router Class Initialized
INFO - 2024-09-05 23:54:54 --> Output Class Initialized
INFO - 2024-09-05 23:54:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:54:54 --> Input Class Initialized
INFO - 2024-09-05 23:54:54 --> Language Class Initialized
INFO - 2024-09-05 23:54:54 --> Loader Class Initialized
INFO - 2024-09-05 23:54:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:54:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:54:54 --> Database Driver Class Initialized
INFO - 2024-09-05 23:54:54 --> Email Class Initialized
DEBUG - 2024-09-05 23:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:54:54 --> Helper loaded: form_helper
INFO - 2024-09-05 23:54:54 --> Form Validation Class Initialized
INFO - 2024-09-05 23:54:54 --> Controller Class Initialized
ERROR - 2024-09-05 23:54:54 --> Query error: Table 'rsaz_sik.user_menu' doesn't exist - Invalid query: SELECT *
FROM `user_menu`
WHERE `menu` = 'antrol'
INFO - 2024-09-05 23:54:54 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-05 23:57:37 --> Config Class Initialized
INFO - 2024-09-05 23:57:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:37 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:37 --> URI Class Initialized
INFO - 2024-09-05 23:57:37 --> Router Class Initialized
INFO - 2024-09-05 23:57:37 --> Output Class Initialized
INFO - 2024-09-05 23:57:37 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:37 --> Input Class Initialized
INFO - 2024-09-05 23:57:37 --> Language Class Initialized
INFO - 2024-09-05 23:57:37 --> Loader Class Initialized
INFO - 2024-09-05 23:57:37 --> Helper loaded: url_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: file_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: security_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:57:37 --> Database Driver Class Initialized
INFO - 2024-09-05 23:57:37 --> Email Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:57:37 --> Helper loaded: form_helper
INFO - 2024-09-05 23:57:37 --> Form Validation Class Initialized
INFO - 2024-09-05 23:57:37 --> Controller Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:57:37 --> Config Class Initialized
INFO - 2024-09-05 23:57:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:37 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:37 --> URI Class Initialized
INFO - 2024-09-05 23:57:37 --> Router Class Initialized
INFO - 2024-09-05 23:57:37 --> Output Class Initialized
INFO - 2024-09-05 23:57:37 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:37 --> Input Class Initialized
INFO - 2024-09-05 23:57:37 --> Language Class Initialized
INFO - 2024-09-05 23:57:37 --> Loader Class Initialized
INFO - 2024-09-05 23:57:37 --> Helper loaded: url_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: file_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: security_helper
INFO - 2024-09-05 23:57:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:57:37 --> Database Driver Class Initialized
INFO - 2024-09-05 23:57:37 --> Email Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:57:37 --> Helper loaded: form_helper
INFO - 2024-09-05 23:57:37 --> Form Validation Class Initialized
INFO - 2024-09-05 23:57:37 --> Controller Class Initialized
DEBUG - 2024-09-05 23:57:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:57:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:57:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:57:37 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:57:37 --> Final output sent to browser
DEBUG - 2024-09-05 23:57:37 --> Total execution time: 0.0406
INFO - 2024-09-05 23:57:38 --> Config Class Initialized
INFO - 2024-09-05 23:57:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:38 --> URI Class Initialized
INFO - 2024-09-05 23:57:38 --> Router Class Initialized
INFO - 2024-09-05 23:57:38 --> Output Class Initialized
INFO - 2024-09-05 23:57:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:38 --> Input Class Initialized
INFO - 2024-09-05 23:57:38 --> Language Class Initialized
INFO - 2024-09-05 23:57:38 --> Loader Class Initialized
INFO - 2024-09-05 23:57:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:57:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:57:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:57:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:57:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:57:38 --> Controller Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:57:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:57:38 --> Config Class Initialized
INFO - 2024-09-05 23:57:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:38 --> URI Class Initialized
INFO - 2024-09-05 23:57:38 --> Router Class Initialized
INFO - 2024-09-05 23:57:38 --> Output Class Initialized
INFO - 2024-09-05 23:57:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:38 --> Input Class Initialized
INFO - 2024-09-05 23:57:38 --> Language Class Initialized
INFO - 2024-09-05 23:57:38 --> Loader Class Initialized
INFO - 2024-09-05 23:57:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:57:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:57:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:57:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:57:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:57:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:57:38 --> Controller Class Initialized
INFO - 2024-09-05 23:57:38 --> Config Class Initialized
INFO - 2024-09-05 23:57:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:38 --> URI Class Initialized
INFO - 2024-09-05 23:57:38 --> Router Class Initialized
INFO - 2024-09-05 23:57:38 --> Output Class Initialized
INFO - 2024-09-05 23:57:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:38 --> Input Class Initialized
INFO - 2024-09-05 23:57:38 --> Language Class Initialized
ERROR - 2024-09-05 23:57:38 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 23:57:43 --> Config Class Initialized
INFO - 2024-09-05 23:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:43 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:43 --> URI Class Initialized
INFO - 2024-09-05 23:57:43 --> Router Class Initialized
INFO - 2024-09-05 23:57:43 --> Output Class Initialized
INFO - 2024-09-05 23:57:43 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:43 --> Input Class Initialized
INFO - 2024-09-05 23:57:43 --> Language Class Initialized
INFO - 2024-09-05 23:57:43 --> Loader Class Initialized
INFO - 2024-09-05 23:57:43 --> Helper loaded: url_helper
INFO - 2024-09-05 23:57:43 --> Helper loaded: file_helper
INFO - 2024-09-05 23:57:43 --> Helper loaded: security_helper
INFO - 2024-09-05 23:57:43 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:57:43 --> Database Driver Class Initialized
INFO - 2024-09-05 23:57:43 --> Email Class Initialized
DEBUG - 2024-09-05 23:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:57:43 --> Helper loaded: form_helper
INFO - 2024-09-05 23:57:43 --> Form Validation Class Initialized
INFO - 2024-09-05 23:57:43 --> Controller Class Initialized
INFO - 2024-09-05 23:57:43 --> Config Class Initialized
INFO - 2024-09-05 23:57:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:57:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:57:43 --> Utf8 Class Initialized
INFO - 2024-09-05 23:57:43 --> URI Class Initialized
INFO - 2024-09-05 23:57:43 --> Router Class Initialized
INFO - 2024-09-05 23:57:43 --> Output Class Initialized
INFO - 2024-09-05 23:57:43 --> Security Class Initialized
DEBUG - 2024-09-05 23:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:57:43 --> Input Class Initialized
INFO - 2024-09-05 23:57:43 --> Language Class Initialized
ERROR - 2024-09-05 23:57:43 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 23:58:02 --> Config Class Initialized
INFO - 2024-09-05 23:58:02 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:02 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:02 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:02 --> URI Class Initialized
DEBUG - 2024-09-05 23:58:02 --> No URI present. Default controller set.
INFO - 2024-09-05 23:58:02 --> Router Class Initialized
INFO - 2024-09-05 23:58:02 --> Output Class Initialized
INFO - 2024-09-05 23:58:02 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:02 --> Input Class Initialized
INFO - 2024-09-05 23:58:02 --> Language Class Initialized
INFO - 2024-09-05 23:58:02 --> Loader Class Initialized
INFO - 2024-09-05 23:58:02 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:02 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:02 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:02 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:02 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:02 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:02 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:02 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:02 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:02 --> Config Class Initialized
INFO - 2024-09-05 23:58:02 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:02 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:02 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:02 --> URI Class Initialized
INFO - 2024-09-05 23:58:02 --> Router Class Initialized
INFO - 2024-09-05 23:58:02 --> Output Class Initialized
INFO - 2024-09-05 23:58:02 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:02 --> Input Class Initialized
INFO - 2024-09-05 23:58:02 --> Language Class Initialized
ERROR - 2024-09-05 23:58:02 --> 404 Page Not Found: User/index
INFO - 2024-09-05 23:58:04 --> Config Class Initialized
INFO - 2024-09-05 23:58:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:04 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:04 --> URI Class Initialized
DEBUG - 2024-09-05 23:58:04 --> No URI present. Default controller set.
INFO - 2024-09-05 23:58:04 --> Router Class Initialized
INFO - 2024-09-05 23:58:04 --> Output Class Initialized
INFO - 2024-09-05 23:58:04 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:04 --> Input Class Initialized
INFO - 2024-09-05 23:58:04 --> Language Class Initialized
INFO - 2024-09-05 23:58:04 --> Loader Class Initialized
INFO - 2024-09-05 23:58:04 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:04 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:04 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:04 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:04 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:04 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:04 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:04 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:04 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:04 --> Config Class Initialized
INFO - 2024-09-05 23:58:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:04 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:04 --> URI Class Initialized
INFO - 2024-09-05 23:58:04 --> Router Class Initialized
INFO - 2024-09-05 23:58:04 --> Output Class Initialized
INFO - 2024-09-05 23:58:04 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:04 --> Input Class Initialized
INFO - 2024-09-05 23:58:04 --> Language Class Initialized
ERROR - 2024-09-05 23:58:04 --> 404 Page Not Found: User/index
INFO - 2024-09-05 23:58:07 --> Config Class Initialized
INFO - 2024-09-05 23:58:07 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:07 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:07 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:07 --> URI Class Initialized
INFO - 2024-09-05 23:58:07 --> Router Class Initialized
INFO - 2024-09-05 23:58:07 --> Output Class Initialized
INFO - 2024-09-05 23:58:07 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:07 --> Input Class Initialized
INFO - 2024-09-05 23:58:07 --> Language Class Initialized
INFO - 2024-09-05 23:58:07 --> Loader Class Initialized
INFO - 2024-09-05 23:58:07 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:07 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:07 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:07 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:07 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:07 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:07 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:07 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:07 --> Controller Class Initialized
INFO - 2024-09-05 23:58:07 --> Config Class Initialized
INFO - 2024-09-05 23:58:07 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:07 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:07 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:07 --> URI Class Initialized
INFO - 2024-09-05 23:58:07 --> Router Class Initialized
INFO - 2024-09-05 23:58:07 --> Output Class Initialized
INFO - 2024-09-05 23:58:07 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:07 --> Input Class Initialized
INFO - 2024-09-05 23:58:07 --> Language Class Initialized
ERROR - 2024-09-05 23:58:07 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 23:58:10 --> Config Class Initialized
INFO - 2024-09-05 23:58:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:10 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:10 --> URI Class Initialized
INFO - 2024-09-05 23:58:10 --> Router Class Initialized
INFO - 2024-09-05 23:58:10 --> Output Class Initialized
INFO - 2024-09-05 23:58:10 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:10 --> Input Class Initialized
INFO - 2024-09-05 23:58:10 --> Language Class Initialized
INFO - 2024-09-05 23:58:10 --> Loader Class Initialized
INFO - 2024-09-05 23:58:10 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:10 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:10 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:10 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:10 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:10 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:10 --> Config Class Initialized
INFO - 2024-09-05 23:58:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:10 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:10 --> URI Class Initialized
INFO - 2024-09-05 23:58:10 --> Router Class Initialized
INFO - 2024-09-05 23:58:10 --> Output Class Initialized
INFO - 2024-09-05 23:58:10 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:10 --> Input Class Initialized
INFO - 2024-09-05 23:58:10 --> Language Class Initialized
INFO - 2024-09-05 23:58:10 --> Loader Class Initialized
INFO - 2024-09-05 23:58:10 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:10 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:10 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:10 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:10 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:10 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:10 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:58:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:58:10 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:58:10 --> Final output sent to browser
DEBUG - 2024-09-05 23:58:10 --> Total execution time: 0.0503
INFO - 2024-09-05 23:58:54 --> Config Class Initialized
INFO - 2024-09-05 23:58:54 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:54 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:54 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:54 --> URI Class Initialized
INFO - 2024-09-05 23:58:54 --> Router Class Initialized
INFO - 2024-09-05 23:58:54 --> Output Class Initialized
INFO - 2024-09-05 23:58:54 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:54 --> Input Class Initialized
INFO - 2024-09-05 23:58:54 --> Language Class Initialized
INFO - 2024-09-05 23:58:54 --> Loader Class Initialized
INFO - 2024-09-05 23:58:54 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:54 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:54 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:54 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:55 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_header.php
INFO - 2024-09-05 23:58:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\auth/login.php
INFO - 2024-09-05 23:58:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/auth_footer.php
INFO - 2024-09-05 23:58:55 --> Final output sent to browser
DEBUG - 2024-09-05 23:58:55 --> Total execution time: 0.0778
INFO - 2024-09-05 23:58:55 --> Config Class Initialized
INFO - 2024-09-05 23:58:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:55 --> URI Class Initialized
INFO - 2024-09-05 23:58:55 --> Router Class Initialized
INFO - 2024-09-05 23:58:55 --> Output Class Initialized
INFO - 2024-09-05 23:58:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:55 --> Input Class Initialized
INFO - 2024-09-05 23:58:55 --> Language Class Initialized
INFO - 2024-09-05 23:58:55 --> Loader Class Initialized
INFO - 2024-09-05 23:58:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:55 --> Controller Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:58:55 --> Config Class Initialized
INFO - 2024-09-05 23:58:55 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:55 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:55 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:55 --> URI Class Initialized
INFO - 2024-09-05 23:58:55 --> Router Class Initialized
INFO - 2024-09-05 23:58:55 --> Output Class Initialized
INFO - 2024-09-05 23:58:55 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:55 --> Input Class Initialized
INFO - 2024-09-05 23:58:55 --> Language Class Initialized
INFO - 2024-09-05 23:58:55 --> Loader Class Initialized
INFO - 2024-09-05 23:58:55 --> Helper loaded: url_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: file_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: security_helper
INFO - 2024-09-05 23:58:55 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:58:55 --> Database Driver Class Initialized
INFO - 2024-09-05 23:58:55 --> Email Class Initialized
DEBUG - 2024-09-05 23:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:58:55 --> Helper loaded: form_helper
INFO - 2024-09-05 23:58:55 --> Form Validation Class Initialized
INFO - 2024-09-05 23:58:55 --> Controller Class Initialized
INFO - 2024-09-05 23:58:55 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:58:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:58:55 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/header.php
INFO - 2024-09-05 23:58:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/topbar.php
INFO - 2024-09-05 23:58:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\data/antrol.php
INFO - 2024-09-05 23:58:56 --> File loaded: C:\xampp\htdocs\antrol\application\views\templates/footer.php
INFO - 2024-09-05 23:58:56 --> Final output sent to browser
DEBUG - 2024-09-05 23:58:56 --> Total execution time: 0.1250
INFO - 2024-09-05 23:58:59 --> Config Class Initialized
INFO - 2024-09-05 23:58:59 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:58:59 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:58:59 --> Utf8 Class Initialized
INFO - 2024-09-05 23:58:59 --> URI Class Initialized
INFO - 2024-09-05 23:58:59 --> Router Class Initialized
INFO - 2024-09-05 23:58:59 --> Output Class Initialized
INFO - 2024-09-05 23:58:59 --> Security Class Initialized
DEBUG - 2024-09-05 23:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:58:59 --> Input Class Initialized
INFO - 2024-09-05 23:58:59 --> Language Class Initialized
ERROR - 2024-09-05 23:58:59 --> 404 Page Not Found: Antrol/auth
INFO - 2024-09-05 22:05:33 --> Config Class Initialized
INFO - 2024-09-05 22:05:33 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:33 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:33 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:33 --> URI Class Initialized
INFO - 2024-09-05 22:05:33 --> Router Class Initialized
INFO - 2024-09-05 22:05:33 --> Output Class Initialized
INFO - 2024-09-05 22:05:33 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:33 --> Input Class Initialized
INFO - 2024-09-05 22:05:33 --> Language Class Initialized
ERROR - 2024-09-05 22:05:33 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-05 22:05:36 --> Config Class Initialized
INFO - 2024-09-05 22:05:36 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:36 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:36 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:36 --> URI Class Initialized
DEBUG - 2024-09-05 22:05:36 --> No URI present. Default controller set.
INFO - 2024-09-05 22:05:36 --> Router Class Initialized
INFO - 2024-09-05 22:05:36 --> Output Class Initialized
INFO - 2024-09-05 22:05:36 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:36 --> Input Class Initialized
INFO - 2024-09-05 22:05:36 --> Language Class Initialized
INFO - 2024-09-05 22:05:36 --> Loader Class Initialized
INFO - 2024-09-05 22:05:36 --> Helper loaded: url_helper
INFO - 2024-09-05 22:05:36 --> Helper loaded: file_helper
INFO - 2024-09-05 22:05:36 --> Helper loaded: security_helper
INFO - 2024-09-05 22:05:36 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:05:36 --> Database Driver Class Initialized
INFO - 2024-09-05 22:05:36 --> Email Class Initialized
DEBUG - 2024-09-05 22:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:05:36 --> Helper loaded: form_helper
INFO - 2024-09-05 22:05:36 --> Form Validation Class Initialized
INFO - 2024-09-05 22:05:36 --> Controller Class Initialized
DEBUG - 2024-09-05 22:05:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:05:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:05:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:05:36 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:05:36 --> Final output sent to browser
DEBUG - 2024-09-05 22:05:36 --> Total execution time: 0.2224
INFO - 2024-09-05 22:05:42 --> Config Class Initialized
INFO - 2024-09-05 22:05:42 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:42 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:42 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:42 --> URI Class Initialized
INFO - 2024-09-05 22:05:42 --> Router Class Initialized
INFO - 2024-09-05 22:05:42 --> Output Class Initialized
INFO - 2024-09-05 22:05:42 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:42 --> Input Class Initialized
INFO - 2024-09-05 22:05:42 --> Language Class Initialized
INFO - 2024-09-05 22:05:42 --> Loader Class Initialized
INFO - 2024-09-05 22:05:42 --> Helper loaded: url_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: file_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: security_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:05:42 --> Database Driver Class Initialized
INFO - 2024-09-05 22:05:42 --> Email Class Initialized
DEBUG - 2024-09-05 22:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:05:42 --> Helper loaded: form_helper
INFO - 2024-09-05 22:05:42 --> Form Validation Class Initialized
INFO - 2024-09-05 22:05:42 --> Controller Class Initialized
DEBUG - 2024-09-05 22:05:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:05:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:05:42 --> Config Class Initialized
INFO - 2024-09-05 22:05:42 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:42 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:42 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:42 --> URI Class Initialized
INFO - 2024-09-05 22:05:42 --> Router Class Initialized
INFO - 2024-09-05 22:05:42 --> Output Class Initialized
INFO - 2024-09-05 22:05:42 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:42 --> Input Class Initialized
INFO - 2024-09-05 22:05:42 --> Language Class Initialized
INFO - 2024-09-05 22:05:42 --> Loader Class Initialized
INFO - 2024-09-05 22:05:42 --> Helper loaded: url_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: file_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: security_helper
INFO - 2024-09-05 22:05:42 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:05:42 --> Database Driver Class Initialized
INFO - 2024-09-05 22:05:43 --> Email Class Initialized
DEBUG - 2024-09-05 22:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:05:43 --> Helper loaded: form_helper
INFO - 2024-09-05 22:05:43 --> Form Validation Class Initialized
INFO - 2024-09-05 22:05:43 --> Controller Class Initialized
INFO - 2024-09-05 22:05:43 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:05:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:05:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:05:43 --> Final output sent to browser
DEBUG - 2024-09-05 22:05:43 --> Total execution time: 0.5593
INFO - 2024-09-05 22:05:45 --> Config Class Initialized
INFO - 2024-09-05 22:05:45 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:45 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:45 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:45 --> URI Class Initialized
INFO - 2024-09-05 22:05:45 --> Router Class Initialized
INFO - 2024-09-05 22:05:45 --> Output Class Initialized
INFO - 2024-09-05 22:05:45 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:45 --> Input Class Initialized
INFO - 2024-09-05 22:05:45 --> Language Class Initialized
INFO - 2024-09-05 22:05:45 --> Loader Class Initialized
INFO - 2024-09-05 22:05:45 --> Helper loaded: url_helper
INFO - 2024-09-05 22:05:45 --> Helper loaded: file_helper
INFO - 2024-09-05 22:05:45 --> Helper loaded: security_helper
INFO - 2024-09-05 22:05:45 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:05:45 --> Database Driver Class Initialized
INFO - 2024-09-05 22:05:45 --> Email Class Initialized
DEBUG - 2024-09-05 22:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:05:45 --> Helper loaded: form_helper
INFO - 2024-09-05 22:05:45 --> Form Validation Class Initialized
INFO - 2024-09-05 22:05:45 --> Controller Class Initialized
INFO - 2024-09-05 22:05:45 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:05:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:05:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:05:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:05:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-05 22:05:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:05:46 --> Final output sent to browser
DEBUG - 2024-09-05 22:05:46 --> Total execution time: 0.4756
INFO - 2024-09-05 22:05:47 --> Config Class Initialized
INFO - 2024-09-05 22:05:47 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:05:47 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:05:47 --> Utf8 Class Initialized
INFO - 2024-09-05 22:05:47 --> URI Class Initialized
INFO - 2024-09-05 22:05:47 --> Router Class Initialized
INFO - 2024-09-05 22:05:47 --> Output Class Initialized
INFO - 2024-09-05 22:05:47 --> Security Class Initialized
DEBUG - 2024-09-05 22:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:05:47 --> Input Class Initialized
INFO - 2024-09-05 22:05:47 --> Language Class Initialized
INFO - 2024-09-05 22:05:47 --> Loader Class Initialized
INFO - 2024-09-05 22:05:47 --> Helper loaded: url_helper
INFO - 2024-09-05 22:05:47 --> Helper loaded: file_helper
INFO - 2024-09-05 22:05:47 --> Helper loaded: security_helper
INFO - 2024-09-05 22:05:47 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:05:47 --> Database Driver Class Initialized
INFO - 2024-09-05 22:05:48 --> Email Class Initialized
DEBUG - 2024-09-05 22:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:05:48 --> Helper loaded: form_helper
INFO - 2024-09-05 22:05:48 --> Form Validation Class Initialized
INFO - 2024-09-05 22:05:48 --> Controller Class Initialized
INFO - 2024-09-05 22:05:48 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:05:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:05:48 --> Final output sent to browser
DEBUG - 2024-09-05 22:05:48 --> Total execution time: 0.9503
INFO - 2024-09-05 22:06:12 --> Config Class Initialized
INFO - 2024-09-05 22:06:12 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:06:12 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:06:12 --> Utf8 Class Initialized
INFO - 2024-09-05 22:06:12 --> URI Class Initialized
INFO - 2024-09-05 22:06:12 --> Router Class Initialized
INFO - 2024-09-05 22:06:12 --> Output Class Initialized
INFO - 2024-09-05 22:06:12 --> Security Class Initialized
DEBUG - 2024-09-05 22:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:06:12 --> Input Class Initialized
INFO - 2024-09-05 22:06:12 --> Language Class Initialized
INFO - 2024-09-05 22:06:12 --> Loader Class Initialized
INFO - 2024-09-05 22:06:12 --> Helper loaded: url_helper
INFO - 2024-09-05 22:06:12 --> Helper loaded: file_helper
INFO - 2024-09-05 22:06:12 --> Helper loaded: security_helper
INFO - 2024-09-05 22:06:12 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:06:12 --> Database Driver Class Initialized
INFO - 2024-09-05 22:06:12 --> Email Class Initialized
DEBUG - 2024-09-05 22:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:06:12 --> Helper loaded: form_helper
INFO - 2024-09-05 22:06:12 --> Form Validation Class Initialized
INFO - 2024-09-05 22:06:12 --> Controller Class Initialized
INFO - 2024-09-05 22:06:12 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:06:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:06:13 --> Final output sent to browser
DEBUG - 2024-09-05 22:06:13 --> Total execution time: 0.9987
INFO - 2024-09-05 22:06:30 --> Config Class Initialized
INFO - 2024-09-05 22:06:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:06:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:06:30 --> Utf8 Class Initialized
INFO - 2024-09-05 22:06:30 --> URI Class Initialized
INFO - 2024-09-05 22:06:30 --> Router Class Initialized
INFO - 2024-09-05 22:06:30 --> Output Class Initialized
INFO - 2024-09-05 22:06:30 --> Security Class Initialized
DEBUG - 2024-09-05 22:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:06:30 --> Input Class Initialized
INFO - 2024-09-05 22:06:30 --> Language Class Initialized
INFO - 2024-09-05 22:06:30 --> Loader Class Initialized
INFO - 2024-09-05 22:06:30 --> Helper loaded: url_helper
INFO - 2024-09-05 22:06:30 --> Helper loaded: file_helper
INFO - 2024-09-05 22:06:30 --> Helper loaded: security_helper
INFO - 2024-09-05 22:06:30 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:06:30 --> Database Driver Class Initialized
INFO - 2024-09-05 22:06:30 --> Email Class Initialized
DEBUG - 2024-09-05 22:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:06:30 --> Helper loaded: form_helper
INFO - 2024-09-05 22:06:30 --> Form Validation Class Initialized
INFO - 2024-09-05 22:06:30 --> Controller Class Initialized
INFO - 2024-09-05 22:06:30 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:06:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:06:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:06:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:06:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-05 22:06:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:06:31 --> Final output sent to browser
DEBUG - 2024-09-05 22:06:31 --> Total execution time: 0.8189
INFO - 2024-09-05 22:06:36 --> Config Class Initialized
INFO - 2024-09-05 22:06:36 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:06:36 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:06:36 --> Utf8 Class Initialized
INFO - 2024-09-05 22:06:36 --> URI Class Initialized
INFO - 2024-09-05 22:06:36 --> Router Class Initialized
INFO - 2024-09-05 22:06:36 --> Output Class Initialized
INFO - 2024-09-05 22:06:36 --> Security Class Initialized
DEBUG - 2024-09-05 22:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:06:36 --> Input Class Initialized
INFO - 2024-09-05 22:06:36 --> Language Class Initialized
INFO - 2024-09-05 22:06:36 --> Loader Class Initialized
INFO - 2024-09-05 22:06:36 --> Helper loaded: url_helper
INFO - 2024-09-05 22:06:36 --> Helper loaded: file_helper
INFO - 2024-09-05 22:06:36 --> Helper loaded: security_helper
INFO - 2024-09-05 22:06:36 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:06:36 --> Database Driver Class Initialized
INFO - 2024-09-05 22:06:36 --> Email Class Initialized
DEBUG - 2024-09-05 22:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:06:36 --> Helper loaded: form_helper
INFO - 2024-09-05 22:06:36 --> Form Validation Class Initialized
INFO - 2024-09-05 22:06:36 --> Controller Class Initialized
INFO - 2024-09-05 22:06:36 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:06:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:06:42 --> Final output sent to browser
DEBUG - 2024-09-05 22:06:42 --> Total execution time: 6.6003
INFO - 2024-09-05 22:07:41 --> Config Class Initialized
INFO - 2024-09-05 22:07:41 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:41 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:41 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:41 --> URI Class Initialized
DEBUG - 2024-09-05 22:07:41 --> No URI present. Default controller set.
INFO - 2024-09-05 22:07:41 --> Router Class Initialized
INFO - 2024-09-05 22:07:41 --> Output Class Initialized
INFO - 2024-09-05 22:07:41 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:41 --> Input Class Initialized
INFO - 2024-09-05 22:07:41 --> Language Class Initialized
INFO - 2024-09-05 22:07:41 --> Loader Class Initialized
INFO - 2024-09-05 22:07:41 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:41 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:41 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:41 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:41 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:41 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:41 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:41 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:41 --> Controller Class Initialized
DEBUG - 2024-09-05 22:07:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:41 --> Config Class Initialized
INFO - 2024-09-05 22:07:41 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:41 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:41 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:41 --> URI Class Initialized
INFO - 2024-09-05 22:07:41 --> Router Class Initialized
INFO - 2024-09-05 22:07:41 --> Output Class Initialized
INFO - 2024-09-05 22:07:41 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:41 --> Input Class Initialized
INFO - 2024-09-05 22:07:41 --> Language Class Initialized
ERROR - 2024-09-05 22:07:41 --> 404 Page Not Found: User/index
INFO - 2024-09-05 22:07:43 --> Config Class Initialized
INFO - 2024-09-05 22:07:43 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:43 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:43 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:43 --> URI Class Initialized
DEBUG - 2024-09-05 22:07:43 --> No URI present. Default controller set.
INFO - 2024-09-05 22:07:43 --> Router Class Initialized
INFO - 2024-09-05 22:07:43 --> Output Class Initialized
INFO - 2024-09-05 22:07:43 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:43 --> Input Class Initialized
INFO - 2024-09-05 22:07:43 --> Language Class Initialized
INFO - 2024-09-05 22:07:43 --> Loader Class Initialized
INFO - 2024-09-05 22:07:43 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:43 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:43 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:43 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:43 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:44 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:44 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:44 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:44 --> Controller Class Initialized
DEBUG - 2024-09-05 22:07:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:44 --> Config Class Initialized
INFO - 2024-09-05 22:07:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:44 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:44 --> URI Class Initialized
INFO - 2024-09-05 22:07:44 --> Router Class Initialized
INFO - 2024-09-05 22:07:44 --> Output Class Initialized
INFO - 2024-09-05 22:07:44 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:44 --> Input Class Initialized
INFO - 2024-09-05 22:07:44 --> Language Class Initialized
ERROR - 2024-09-05 22:07:44 --> 404 Page Not Found: User/index
INFO - 2024-09-05 22:07:50 --> Config Class Initialized
INFO - 2024-09-05 22:07:50 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:50 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:50 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:50 --> URI Class Initialized
INFO - 2024-09-05 22:07:50 --> Router Class Initialized
INFO - 2024-09-05 22:07:50 --> Output Class Initialized
INFO - 2024-09-05 22:07:50 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:50 --> Input Class Initialized
INFO - 2024-09-05 22:07:50 --> Language Class Initialized
INFO - 2024-09-05 22:07:50 --> Loader Class Initialized
INFO - 2024-09-05 22:07:50 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:50 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:50 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:50 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:50 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:51 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:51 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:51 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:51 --> Controller Class Initialized
DEBUG - 2024-09-05 22:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:51 --> Config Class Initialized
INFO - 2024-09-05 22:07:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:51 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:51 --> URI Class Initialized
INFO - 2024-09-05 22:07:51 --> Router Class Initialized
INFO - 2024-09-05 22:07:51 --> Output Class Initialized
INFO - 2024-09-05 22:07:51 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:51 --> Input Class Initialized
INFO - 2024-09-05 22:07:51 --> Language Class Initialized
INFO - 2024-09-05 22:07:51 --> Loader Class Initialized
INFO - 2024-09-05 22:07:51 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:51 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:51 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:51 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:51 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:51 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:51 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:51 --> Controller Class Initialized
DEBUG - 2024-09-05 22:07:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:07:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:07:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:07:51 --> Final output sent to browser
DEBUG - 2024-09-05 22:07:51 --> Total execution time: 0.2129
INFO - 2024-09-05 22:07:52 --> Config Class Initialized
INFO - 2024-09-05 22:07:52 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:52 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:52 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:52 --> URI Class Initialized
INFO - 2024-09-05 22:07:52 --> Router Class Initialized
INFO - 2024-09-05 22:07:52 --> Output Class Initialized
INFO - 2024-09-05 22:07:52 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:52 --> Input Class Initialized
INFO - 2024-09-05 22:07:52 --> Language Class Initialized
INFO - 2024-09-05 22:07:52 --> Loader Class Initialized
INFO - 2024-09-05 22:07:52 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:52 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:52 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:52 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:52 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:53 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:53 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:53 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:53 --> Controller Class Initialized
DEBUG - 2024-09-05 22:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:07:53 --> Config Class Initialized
INFO - 2024-09-05 22:07:53 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:07:53 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:07:53 --> Utf8 Class Initialized
INFO - 2024-09-05 22:07:53 --> URI Class Initialized
INFO - 2024-09-05 22:07:53 --> Router Class Initialized
INFO - 2024-09-05 22:07:53 --> Output Class Initialized
INFO - 2024-09-05 22:07:53 --> Security Class Initialized
DEBUG - 2024-09-05 22:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:07:53 --> Input Class Initialized
INFO - 2024-09-05 22:07:53 --> Language Class Initialized
INFO - 2024-09-05 22:07:53 --> Loader Class Initialized
INFO - 2024-09-05 22:07:53 --> Helper loaded: url_helper
INFO - 2024-09-05 22:07:53 --> Helper loaded: file_helper
INFO - 2024-09-05 22:07:53 --> Helper loaded: security_helper
INFO - 2024-09-05 22:07:53 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:07:53 --> Database Driver Class Initialized
INFO - 2024-09-05 22:07:53 --> Email Class Initialized
DEBUG - 2024-09-05 22:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:07:53 --> Helper loaded: form_helper
INFO - 2024-09-05 22:07:53 --> Form Validation Class Initialized
INFO - 2024-09-05 22:07:53 --> Controller Class Initialized
INFO - 2024-09-05 22:07:53 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:07:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:07:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:07:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:07:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:07:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:07:54 --> Final output sent to browser
DEBUG - 2024-09-05 22:07:54 --> Total execution time: 1.1687
INFO - 2024-09-05 22:08:09 --> Config Class Initialized
INFO - 2024-09-05 22:08:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:08:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:08:09 --> Utf8 Class Initialized
INFO - 2024-09-05 22:08:09 --> URI Class Initialized
INFO - 2024-09-05 22:08:09 --> Router Class Initialized
INFO - 2024-09-05 22:08:09 --> Output Class Initialized
INFO - 2024-09-05 22:08:09 --> Security Class Initialized
DEBUG - 2024-09-05 22:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:08:09 --> Input Class Initialized
INFO - 2024-09-05 22:08:09 --> Language Class Initialized
INFO - 2024-09-05 22:08:09 --> Loader Class Initialized
INFO - 2024-09-05 22:08:09 --> Helper loaded: url_helper
INFO - 2024-09-05 22:08:09 --> Helper loaded: file_helper
INFO - 2024-09-05 22:08:09 --> Helper loaded: security_helper
INFO - 2024-09-05 22:08:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:08:09 --> Database Driver Class Initialized
INFO - 2024-09-05 22:08:09 --> Email Class Initialized
DEBUG - 2024-09-05 22:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:08:09 --> Helper loaded: form_helper
INFO - 2024-09-05 22:08:09 --> Form Validation Class Initialized
INFO - 2024-09-05 22:08:09 --> Controller Class Initialized
INFO - 2024-09-05 22:08:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:08:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:08:09 --> Final output sent to browser
DEBUG - 2024-09-05 22:08:09 --> Total execution time: 0.5664
INFO - 2024-09-05 22:08:11 --> Config Class Initialized
INFO - 2024-09-05 22:08:11 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:08:11 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:08:11 --> Utf8 Class Initialized
INFO - 2024-09-05 22:08:11 --> URI Class Initialized
INFO - 2024-09-05 22:08:11 --> Router Class Initialized
INFO - 2024-09-05 22:08:11 --> Output Class Initialized
INFO - 2024-09-05 22:08:11 --> Security Class Initialized
DEBUG - 2024-09-05 22:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:08:11 --> Input Class Initialized
INFO - 2024-09-05 22:08:11 --> Language Class Initialized
INFO - 2024-09-05 22:08:11 --> Loader Class Initialized
INFO - 2024-09-05 22:08:11 --> Helper loaded: url_helper
INFO - 2024-09-05 22:08:11 --> Helper loaded: file_helper
INFO - 2024-09-05 22:08:11 --> Helper loaded: security_helper
INFO - 2024-09-05 22:08:11 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:08:11 --> Database Driver Class Initialized
INFO - 2024-09-05 22:08:11 --> Email Class Initialized
DEBUG - 2024-09-05 22:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:08:11 --> Helper loaded: form_helper
INFO - 2024-09-05 22:08:11 --> Form Validation Class Initialized
INFO - 2024-09-05 22:08:11 --> Controller Class Initialized
INFO - 2024-09-05 22:08:11 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-05 22:08:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:08:12 --> Final output sent to browser
DEBUG - 2024-09-05 22:08:12 --> Total execution time: 0.6145
INFO - 2024-09-05 22:08:14 --> Config Class Initialized
INFO - 2024-09-05 22:08:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:08:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:08:14 --> Utf8 Class Initialized
INFO - 2024-09-05 22:08:14 --> URI Class Initialized
INFO - 2024-09-05 22:08:14 --> Router Class Initialized
INFO - 2024-09-05 22:08:14 --> Output Class Initialized
INFO - 2024-09-05 22:08:14 --> Security Class Initialized
DEBUG - 2024-09-05 22:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:08:14 --> Input Class Initialized
INFO - 2024-09-05 22:08:14 --> Language Class Initialized
INFO - 2024-09-05 22:08:14 --> Loader Class Initialized
INFO - 2024-09-05 22:08:14 --> Helper loaded: url_helper
INFO - 2024-09-05 22:08:14 --> Helper loaded: file_helper
INFO - 2024-09-05 22:08:14 --> Helper loaded: security_helper
INFO - 2024-09-05 22:08:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:08:14 --> Database Driver Class Initialized
INFO - 2024-09-05 22:08:14 --> Email Class Initialized
DEBUG - 2024-09-05 22:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:08:14 --> Helper loaded: form_helper
INFO - 2024-09-05 22:08:14 --> Form Validation Class Initialized
INFO - 2024-09-05 22:08:14 --> Controller Class Initialized
INFO - 2024-09-05 22:08:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:08:14 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:08:14 --> Final output sent to browser
DEBUG - 2024-09-05 22:08:14 --> Total execution time: 0.5853
INFO - 2024-09-05 22:08:16 --> Config Class Initialized
INFO - 2024-09-05 22:08:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:08:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:08:16 --> Utf8 Class Initialized
INFO - 2024-09-05 22:08:16 --> URI Class Initialized
INFO - 2024-09-05 22:08:16 --> Router Class Initialized
INFO - 2024-09-05 22:08:16 --> Output Class Initialized
INFO - 2024-09-05 22:08:16 --> Security Class Initialized
DEBUG - 2024-09-05 22:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:08:16 --> Input Class Initialized
INFO - 2024-09-05 22:08:16 --> Language Class Initialized
INFO - 2024-09-05 22:08:16 --> Loader Class Initialized
INFO - 2024-09-05 22:08:16 --> Helper loaded: url_helper
INFO - 2024-09-05 22:08:16 --> Helper loaded: file_helper
INFO - 2024-09-05 22:08:16 --> Helper loaded: security_helper
INFO - 2024-09-05 22:08:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:08:16 --> Database Driver Class Initialized
INFO - 2024-09-05 22:08:17 --> Email Class Initialized
DEBUG - 2024-09-05 22:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:08:17 --> Helper loaded: form_helper
INFO - 2024-09-05 22:08:17 --> Form Validation Class Initialized
INFO - 2024-09-05 22:08:17 --> Controller Class Initialized
DEBUG - 2024-09-05 22:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:08:17 --> Config Class Initialized
INFO - 2024-09-05 22:08:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:08:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:08:17 --> Utf8 Class Initialized
INFO - 2024-09-05 22:08:17 --> URI Class Initialized
INFO - 2024-09-05 22:08:17 --> Router Class Initialized
INFO - 2024-09-05 22:08:17 --> Output Class Initialized
INFO - 2024-09-05 22:08:17 --> Security Class Initialized
DEBUG - 2024-09-05 22:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:08:17 --> Input Class Initialized
INFO - 2024-09-05 22:08:17 --> Language Class Initialized
INFO - 2024-09-05 22:08:17 --> Loader Class Initialized
INFO - 2024-09-05 22:08:17 --> Helper loaded: url_helper
INFO - 2024-09-05 22:08:17 --> Helper loaded: file_helper
INFO - 2024-09-05 22:08:17 --> Helper loaded: security_helper
INFO - 2024-09-05 22:08:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:08:17 --> Database Driver Class Initialized
INFO - 2024-09-05 22:08:17 --> Email Class Initialized
DEBUG - 2024-09-05 22:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:08:17 --> Helper loaded: form_helper
INFO - 2024-09-05 22:08:17 --> Form Validation Class Initialized
INFO - 2024-09-05 22:08:17 --> Controller Class Initialized
DEBUG - 2024-09-05 22:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:08:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:08:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:08:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:08:17 --> Final output sent to browser
DEBUG - 2024-09-05 22:08:17 --> Total execution time: 0.2124
INFO - 2024-09-05 22:09:04 --> Config Class Initialized
INFO - 2024-09-05 22:09:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:09:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:09:04 --> Utf8 Class Initialized
INFO - 2024-09-05 22:09:05 --> URI Class Initialized
INFO - 2024-09-05 22:09:05 --> Router Class Initialized
INFO - 2024-09-05 22:09:05 --> Output Class Initialized
INFO - 2024-09-05 22:09:05 --> Security Class Initialized
DEBUG - 2024-09-05 22:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:09:05 --> Input Class Initialized
INFO - 2024-09-05 22:09:05 --> Language Class Initialized
INFO - 2024-09-05 22:09:05 --> Loader Class Initialized
INFO - 2024-09-05 22:09:05 --> Helper loaded: url_helper
INFO - 2024-09-05 22:09:05 --> Helper loaded: file_helper
INFO - 2024-09-05 22:09:05 --> Helper loaded: security_helper
INFO - 2024-09-05 22:09:05 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:09:05 --> Database Driver Class Initialized
INFO - 2024-09-05 22:09:05 --> Email Class Initialized
DEBUG - 2024-09-05 22:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:09:05 --> Helper loaded: form_helper
INFO - 2024-09-05 22:09:05 --> Form Validation Class Initialized
INFO - 2024-09-05 22:09:05 --> Controller Class Initialized
DEBUG - 2024-09-05 22:09:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:09:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:09:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:09:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:09:05 --> Final output sent to browser
DEBUG - 2024-09-05 22:09:05 --> Total execution time: 0.5033
INFO - 2024-09-05 22:09:16 --> Config Class Initialized
INFO - 2024-09-05 22:09:16 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:09:16 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:09:16 --> Utf8 Class Initialized
INFO - 2024-09-05 22:09:16 --> URI Class Initialized
INFO - 2024-09-05 22:09:16 --> Router Class Initialized
INFO - 2024-09-05 22:09:16 --> Output Class Initialized
INFO - 2024-09-05 22:09:16 --> Security Class Initialized
DEBUG - 2024-09-05 22:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:09:16 --> Input Class Initialized
INFO - 2024-09-05 22:09:16 --> Language Class Initialized
INFO - 2024-09-05 22:09:16 --> Loader Class Initialized
INFO - 2024-09-05 22:09:16 --> Helper loaded: url_helper
INFO - 2024-09-05 22:09:16 --> Helper loaded: file_helper
INFO - 2024-09-05 22:09:16 --> Helper loaded: security_helper
INFO - 2024-09-05 22:09:16 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:09:16 --> Database Driver Class Initialized
INFO - 2024-09-05 22:09:16 --> Email Class Initialized
DEBUG - 2024-09-05 22:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:09:16 --> Helper loaded: form_helper
INFO - 2024-09-05 22:09:16 --> Form Validation Class Initialized
INFO - 2024-09-05 22:09:16 --> Controller Class Initialized
DEBUG - 2024-09-05 22:09:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:09:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:09:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:09:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:09:16 --> Final output sent to browser
DEBUG - 2024-09-05 22:09:16 --> Total execution time: 0.2183
INFO - 2024-09-05 22:09:17 --> Config Class Initialized
INFO - 2024-09-05 22:09:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:09:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:09:17 --> Utf8 Class Initialized
INFO - 2024-09-05 22:09:17 --> URI Class Initialized
INFO - 2024-09-05 22:09:17 --> Router Class Initialized
INFO - 2024-09-05 22:09:17 --> Output Class Initialized
INFO - 2024-09-05 22:09:17 --> Security Class Initialized
DEBUG - 2024-09-05 22:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:09:17 --> Input Class Initialized
INFO - 2024-09-05 22:09:17 --> Language Class Initialized
INFO - 2024-09-05 22:09:17 --> Loader Class Initialized
INFO - 2024-09-05 22:09:17 --> Helper loaded: url_helper
INFO - 2024-09-05 22:09:17 --> Helper loaded: file_helper
INFO - 2024-09-05 22:09:17 --> Helper loaded: security_helper
INFO - 2024-09-05 22:09:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:09:17 --> Database Driver Class Initialized
INFO - 2024-09-05 22:09:17 --> Email Class Initialized
DEBUG - 2024-09-05 22:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:09:17 --> Helper loaded: form_helper
INFO - 2024-09-05 22:09:17 --> Form Validation Class Initialized
INFO - 2024-09-05 22:09:17 --> Controller Class Initialized
DEBUG - 2024-09-05 22:09:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:09:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:09:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:09:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:09:17 --> Final output sent to browser
DEBUG - 2024-09-05 22:09:17 --> Total execution time: 0.2154
INFO - 2024-09-05 22:12:44 --> Config Class Initialized
INFO - 2024-09-05 22:12:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:12:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:12:44 --> Utf8 Class Initialized
INFO - 2024-09-05 22:12:44 --> URI Class Initialized
DEBUG - 2024-09-05 22:12:44 --> No URI present. Default controller set.
INFO - 2024-09-05 22:12:44 --> Router Class Initialized
INFO - 2024-09-05 22:12:44 --> Output Class Initialized
INFO - 2024-09-05 22:12:44 --> Security Class Initialized
DEBUG - 2024-09-05 22:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:12:44 --> Input Class Initialized
INFO - 2024-09-05 22:12:44 --> Language Class Initialized
INFO - 2024-09-05 22:12:44 --> Loader Class Initialized
INFO - 2024-09-05 22:12:44 --> Helper loaded: url_helper
INFO - 2024-09-05 22:12:44 --> Helper loaded: file_helper
INFO - 2024-09-05 22:12:44 --> Helper loaded: security_helper
INFO - 2024-09-05 22:12:44 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:12:44 --> Database Driver Class Initialized
INFO - 2024-09-05 22:12:44 --> Email Class Initialized
DEBUG - 2024-09-05 22:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:12:44 --> Helper loaded: form_helper
INFO - 2024-09-05 22:12:44 --> Form Validation Class Initialized
INFO - 2024-09-05 22:12:44 --> Controller Class Initialized
DEBUG - 2024-09-05 22:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:12:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:12:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:12:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:12:44 --> Final output sent to browser
DEBUG - 2024-09-05 22:12:44 --> Total execution time: 0.2507
INFO - 2024-09-05 22:13:10 --> Config Class Initialized
INFO - 2024-09-05 22:13:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:13:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:13:10 --> Utf8 Class Initialized
INFO - 2024-09-05 22:13:10 --> URI Class Initialized
INFO - 2024-09-05 22:13:10 --> Router Class Initialized
INFO - 2024-09-05 22:13:10 --> Output Class Initialized
INFO - 2024-09-05 22:13:10 --> Security Class Initialized
DEBUG - 2024-09-05 22:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:13:10 --> Input Class Initialized
INFO - 2024-09-05 22:13:10 --> Language Class Initialized
INFO - 2024-09-05 22:13:10 --> Loader Class Initialized
INFO - 2024-09-05 22:13:10 --> Helper loaded: url_helper
INFO - 2024-09-05 22:13:10 --> Helper loaded: file_helper
INFO - 2024-09-05 22:13:10 --> Helper loaded: security_helper
INFO - 2024-09-05 22:13:10 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:13:10 --> Database Driver Class Initialized
INFO - 2024-09-05 22:13:10 --> Email Class Initialized
DEBUG - 2024-09-05 22:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:13:10 --> Helper loaded: form_helper
INFO - 2024-09-05 22:13:10 --> Form Validation Class Initialized
INFO - 2024-09-05 22:13:10 --> Controller Class Initialized
DEBUG - 2024-09-05 22:13:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:13:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:13:10 --> Final output sent to browser
DEBUG - 2024-09-05 22:13:10 --> Total execution time: 0.2212
INFO - 2024-09-05 22:13:11 --> Config Class Initialized
INFO - 2024-09-05 22:13:11 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:13:11 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:13:11 --> Utf8 Class Initialized
INFO - 2024-09-05 22:13:11 --> URI Class Initialized
INFO - 2024-09-05 22:13:11 --> Router Class Initialized
INFO - 2024-09-05 22:13:11 --> Output Class Initialized
INFO - 2024-09-05 22:13:11 --> Security Class Initialized
DEBUG - 2024-09-05 22:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:13:11 --> Input Class Initialized
INFO - 2024-09-05 22:13:11 --> Language Class Initialized
INFO - 2024-09-05 22:13:11 --> Loader Class Initialized
INFO - 2024-09-05 22:13:11 --> Helper loaded: url_helper
INFO - 2024-09-05 22:13:11 --> Helper loaded: file_helper
INFO - 2024-09-05 22:13:11 --> Helper loaded: security_helper
INFO - 2024-09-05 22:13:11 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:13:11 --> Database Driver Class Initialized
INFO - 2024-09-05 22:13:12 --> Email Class Initialized
DEBUG - 2024-09-05 22:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:13:12 --> Helper loaded: form_helper
INFO - 2024-09-05 22:13:12 --> Form Validation Class Initialized
INFO - 2024-09-05 22:13:12 --> Controller Class Initialized
DEBUG - 2024-09-05 22:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:13:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:13:12 --> Final output sent to browser
DEBUG - 2024-09-05 22:13:12 --> Total execution time: 0.2235
INFO - 2024-09-05 22:20:40 --> Config Class Initialized
INFO - 2024-09-05 22:20:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:20:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:20:40 --> Utf8 Class Initialized
INFO - 2024-09-05 22:20:40 --> URI Class Initialized
INFO - 2024-09-05 22:20:40 --> Router Class Initialized
INFO - 2024-09-05 22:20:40 --> Output Class Initialized
INFO - 2024-09-05 22:20:40 --> Security Class Initialized
DEBUG - 2024-09-05 22:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:20:40 --> Input Class Initialized
INFO - 2024-09-05 22:20:40 --> Language Class Initialized
INFO - 2024-09-05 22:20:40 --> Loader Class Initialized
INFO - 2024-09-05 22:20:40 --> Helper loaded: url_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: file_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: security_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:20:40 --> Database Driver Class Initialized
INFO - 2024-09-05 22:20:40 --> Email Class Initialized
DEBUG - 2024-09-05 22:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:20:40 --> Helper loaded: form_helper
INFO - 2024-09-05 22:20:40 --> Form Validation Class Initialized
INFO - 2024-09-05 22:20:40 --> Controller Class Initialized
INFO - 2024-09-05 22:20:40 --> Config Class Initialized
INFO - 2024-09-05 22:20:40 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:20:40 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:20:40 --> Utf8 Class Initialized
INFO - 2024-09-05 22:20:40 --> URI Class Initialized
INFO - 2024-09-05 22:20:40 --> Router Class Initialized
INFO - 2024-09-05 22:20:40 --> Output Class Initialized
INFO - 2024-09-05 22:20:40 --> Security Class Initialized
DEBUG - 2024-09-05 22:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:20:40 --> Input Class Initialized
INFO - 2024-09-05 22:20:40 --> Language Class Initialized
INFO - 2024-09-05 22:20:40 --> Loader Class Initialized
INFO - 2024-09-05 22:20:40 --> Helper loaded: url_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: file_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: security_helper
INFO - 2024-09-05 22:20:40 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:20:40 --> Database Driver Class Initialized
INFO - 2024-09-05 22:20:40 --> Email Class Initialized
DEBUG - 2024-09-05 22:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:20:40 --> Helper loaded: form_helper
INFO - 2024-09-05 22:20:40 --> Form Validation Class Initialized
INFO - 2024-09-05 22:20:40 --> Controller Class Initialized
DEBUG - 2024-09-05 22:20:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:20:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:20:40 --> Final output sent to browser
DEBUG - 2024-09-05 22:20:40 --> Total execution time: 0.2107
INFO - 2024-09-05 22:20:42 --> Config Class Initialized
INFO - 2024-09-05 22:20:42 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:20:42 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:20:42 --> Utf8 Class Initialized
INFO - 2024-09-05 22:20:42 --> URI Class Initialized
INFO - 2024-09-05 22:20:42 --> Router Class Initialized
INFO - 2024-09-05 22:20:42 --> Output Class Initialized
INFO - 2024-09-05 22:20:42 --> Security Class Initialized
DEBUG - 2024-09-05 22:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:20:42 --> Input Class Initialized
INFO - 2024-09-05 22:20:42 --> Language Class Initialized
INFO - 2024-09-05 22:20:42 --> Loader Class Initialized
INFO - 2024-09-05 22:20:42 --> Helper loaded: url_helper
INFO - 2024-09-05 22:20:42 --> Helper loaded: file_helper
INFO - 2024-09-05 22:20:42 --> Helper loaded: security_helper
INFO - 2024-09-05 22:20:42 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:20:42 --> Database Driver Class Initialized
INFO - 2024-09-05 22:20:45 --> Email Class Initialized
DEBUG - 2024-09-05 22:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:20:45 --> Helper loaded: form_helper
INFO - 2024-09-05 22:20:45 --> Form Validation Class Initialized
INFO - 2024-09-05 22:20:45 --> Controller Class Initialized
DEBUG - 2024-09-05 22:20:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:20:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:20:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:20:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:20:45 --> Final output sent to browser
DEBUG - 2024-09-05 22:20:45 --> Total execution time: 3.3060
INFO - 2024-09-05 22:33:17 --> Config Class Initialized
INFO - 2024-09-05 22:33:17 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:33:17 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:33:17 --> Utf8 Class Initialized
INFO - 2024-09-05 22:33:17 --> URI Class Initialized
INFO - 2024-09-05 22:33:17 --> Router Class Initialized
INFO - 2024-09-05 22:33:17 --> Output Class Initialized
INFO - 2024-09-05 22:33:17 --> Security Class Initialized
DEBUG - 2024-09-05 22:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:33:17 --> Input Class Initialized
INFO - 2024-09-05 22:33:17 --> Language Class Initialized
INFO - 2024-09-05 22:33:17 --> Loader Class Initialized
INFO - 2024-09-05 22:33:17 --> Helper loaded: url_helper
INFO - 2024-09-05 22:33:17 --> Helper loaded: file_helper
INFO - 2024-09-05 22:33:17 --> Helper loaded: security_helper
INFO - 2024-09-05 22:33:17 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:33:17 --> Database Driver Class Initialized
INFO - 2024-09-05 22:33:17 --> Email Class Initialized
DEBUG - 2024-09-05 22:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:33:17 --> Helper loaded: form_helper
INFO - 2024-09-05 22:33:17 --> Form Validation Class Initialized
INFO - 2024-09-05 22:33:17 --> Controller Class Initialized
DEBUG - 2024-09-05 22:33:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:33:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:33:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:33:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:33:17 --> Final output sent to browser
DEBUG - 2024-09-05 22:33:17 --> Total execution time: 0.2191
INFO - 2024-09-05 22:41:15 --> Config Class Initialized
INFO - 2024-09-05 22:41:15 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:41:15 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:41:15 --> Utf8 Class Initialized
INFO - 2024-09-05 22:41:15 --> URI Class Initialized
DEBUG - 2024-09-05 22:41:15 --> No URI present. Default controller set.
INFO - 2024-09-05 22:41:15 --> Router Class Initialized
INFO - 2024-09-05 22:41:15 --> Output Class Initialized
INFO - 2024-09-05 22:41:15 --> Security Class Initialized
DEBUG - 2024-09-05 22:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:41:15 --> Input Class Initialized
INFO - 2024-09-05 22:41:15 --> Language Class Initialized
INFO - 2024-09-05 22:41:15 --> Loader Class Initialized
INFO - 2024-09-05 22:41:15 --> Helper loaded: url_helper
INFO - 2024-09-05 22:41:15 --> Helper loaded: file_helper
INFO - 2024-09-05 22:41:15 --> Helper loaded: security_helper
INFO - 2024-09-05 22:41:15 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:41:15 --> Database Driver Class Initialized
INFO - 2024-09-05 22:41:15 --> Email Class Initialized
DEBUG - 2024-09-05 22:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:41:15 --> Helper loaded: form_helper
INFO - 2024-09-05 22:41:15 --> Form Validation Class Initialized
INFO - 2024-09-05 22:41:15 --> Controller Class Initialized
DEBUG - 2024-09-05 22:41:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:41:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:41:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:41:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:41:15 --> Final output sent to browser
DEBUG - 2024-09-05 22:41:15 --> Total execution time: 0.2201
INFO - 2024-09-05 22:44:52 --> Config Class Initialized
INFO - 2024-09-05 22:44:52 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:44:52 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:44:52 --> Utf8 Class Initialized
INFO - 2024-09-05 22:44:52 --> URI Class Initialized
DEBUG - 2024-09-05 22:44:52 --> No URI present. Default controller set.
INFO - 2024-09-05 22:44:52 --> Router Class Initialized
INFO - 2024-09-05 22:44:52 --> Output Class Initialized
INFO - 2024-09-05 22:44:52 --> Security Class Initialized
DEBUG - 2024-09-05 22:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:44:52 --> Input Class Initialized
INFO - 2024-09-05 22:44:52 --> Language Class Initialized
INFO - 2024-09-05 22:44:52 --> Loader Class Initialized
INFO - 2024-09-05 22:44:52 --> Helper loaded: url_helper
INFO - 2024-09-05 22:44:52 --> Helper loaded: file_helper
INFO - 2024-09-05 22:44:52 --> Helper loaded: security_helper
INFO - 2024-09-05 22:44:52 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:44:52 --> Database Driver Class Initialized
INFO - 2024-09-05 22:44:52 --> Email Class Initialized
DEBUG - 2024-09-05 22:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:44:52 --> Helper loaded: form_helper
INFO - 2024-09-05 22:44:52 --> Form Validation Class Initialized
INFO - 2024-09-05 22:44:52 --> Controller Class Initialized
DEBUG - 2024-09-05 22:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:44:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:44:52 --> Final output sent to browser
DEBUG - 2024-09-05 22:44:52 --> Total execution time: 0.2242
INFO - 2024-09-05 22:44:57 --> Config Class Initialized
INFO - 2024-09-05 22:44:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:44:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:44:57 --> Utf8 Class Initialized
INFO - 2024-09-05 22:44:57 --> URI Class Initialized
INFO - 2024-09-05 22:44:57 --> Router Class Initialized
INFO - 2024-09-05 22:44:57 --> Output Class Initialized
INFO - 2024-09-05 22:44:57 --> Security Class Initialized
DEBUG - 2024-09-05 22:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:44:57 --> Input Class Initialized
INFO - 2024-09-05 22:44:57 --> Language Class Initialized
INFO - 2024-09-05 22:44:57 --> Loader Class Initialized
INFO - 2024-09-05 22:44:57 --> Helper loaded: url_helper
INFO - 2024-09-05 22:44:57 --> Helper loaded: file_helper
INFO - 2024-09-05 22:44:57 --> Helper loaded: security_helper
INFO - 2024-09-05 22:44:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:44:57 --> Database Driver Class Initialized
INFO - 2024-09-05 22:44:58 --> Email Class Initialized
DEBUG - 2024-09-05 22:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:44:58 --> Helper loaded: form_helper
INFO - 2024-09-05 22:44:58 --> Form Validation Class Initialized
INFO - 2024-09-05 22:44:58 --> Controller Class Initialized
DEBUG - 2024-09-05 22:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:44:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:44:58 --> Config Class Initialized
INFO - 2024-09-05 22:44:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:44:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:44:58 --> Utf8 Class Initialized
INFO - 2024-09-05 22:44:58 --> URI Class Initialized
INFO - 2024-09-05 22:44:58 --> Router Class Initialized
INFO - 2024-09-05 22:44:58 --> Output Class Initialized
INFO - 2024-09-05 22:44:58 --> Security Class Initialized
DEBUG - 2024-09-05 22:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:44:58 --> Input Class Initialized
INFO - 2024-09-05 22:44:58 --> Language Class Initialized
INFO - 2024-09-05 22:44:58 --> Loader Class Initialized
INFO - 2024-09-05 22:44:58 --> Helper loaded: url_helper
INFO - 2024-09-05 22:44:58 --> Helper loaded: file_helper
INFO - 2024-09-05 22:44:58 --> Helper loaded: security_helper
INFO - 2024-09-05 22:44:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:44:58 --> Database Driver Class Initialized
INFO - 2024-09-05 22:44:58 --> Email Class Initialized
DEBUG - 2024-09-05 22:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:44:58 --> Helper loaded: form_helper
INFO - 2024-09-05 22:44:58 --> Form Validation Class Initialized
INFO - 2024-09-05 22:44:58 --> Controller Class Initialized
DEBUG - 2024-09-05 22:44:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:44:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:44:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:44:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:44:58 --> Final output sent to browser
DEBUG - 2024-09-05 22:44:58 --> Total execution time: 0.2340
INFO - 2024-09-05 22:45:04 --> Config Class Initialized
INFO - 2024-09-05 22:45:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:04 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:04 --> URI Class Initialized
INFO - 2024-09-05 22:45:04 --> Router Class Initialized
INFO - 2024-09-05 22:45:04 --> Output Class Initialized
INFO - 2024-09-05 22:45:04 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:04 --> Input Class Initialized
INFO - 2024-09-05 22:45:04 --> Language Class Initialized
INFO - 2024-09-05 22:45:04 --> Loader Class Initialized
INFO - 2024-09-05 22:45:04 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:04 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:04 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:04 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:04 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:05 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:05 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:05 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:05 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:45:05 --> Config Class Initialized
INFO - 2024-09-05 22:45:05 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:05 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:05 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:05 --> URI Class Initialized
INFO - 2024-09-05 22:45:05 --> Router Class Initialized
INFO - 2024-09-05 22:45:05 --> Output Class Initialized
INFO - 2024-09-05 22:45:05 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:05 --> Input Class Initialized
INFO - 2024-09-05 22:45:05 --> Language Class Initialized
INFO - 2024-09-05 22:45:05 --> Loader Class Initialized
INFO - 2024-09-05 22:45:05 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:05 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:05 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:05 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:05 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:09 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:09 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:09 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:09 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:45:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:45:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:45:09 --> Final output sent to browser
DEBUG - 2024-09-05 22:45:09 --> Total execution time: 3.3084
INFO - 2024-09-05 22:45:23 --> Config Class Initialized
INFO - 2024-09-05 22:45:23 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:23 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:23 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:23 --> URI Class Initialized
INFO - 2024-09-05 22:45:23 --> Router Class Initialized
INFO - 2024-09-05 22:45:23 --> Output Class Initialized
INFO - 2024-09-05 22:45:23 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:23 --> Input Class Initialized
INFO - 2024-09-05 22:45:23 --> Language Class Initialized
INFO - 2024-09-05 22:45:23 --> Loader Class Initialized
INFO - 2024-09-05 22:45:23 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:23 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:23 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:23 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:23 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:23 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:23 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:23 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:23 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:45:24 --> Config Class Initialized
INFO - 2024-09-05 22:45:24 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:24 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:24 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:24 --> URI Class Initialized
INFO - 2024-09-05 22:45:24 --> Router Class Initialized
INFO - 2024-09-05 22:45:24 --> Output Class Initialized
INFO - 2024-09-05 22:45:24 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:24 --> Input Class Initialized
INFO - 2024-09-05 22:45:24 --> Language Class Initialized
INFO - 2024-09-05 22:45:24 --> Loader Class Initialized
INFO - 2024-09-05 22:45:24 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:24 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:24 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:24 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:24 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:24 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:24 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:24 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:24 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:45:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:45:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:45:24 --> Final output sent to browser
DEBUG - 2024-09-05 22:45:24 --> Total execution time: 0.2107
INFO - 2024-09-05 22:45:31 --> Config Class Initialized
INFO - 2024-09-05 22:45:31 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:31 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:31 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:31 --> URI Class Initialized
INFO - 2024-09-05 22:45:31 --> Router Class Initialized
INFO - 2024-09-05 22:45:31 --> Output Class Initialized
INFO - 2024-09-05 22:45:31 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:31 --> Input Class Initialized
INFO - 2024-09-05 22:45:31 --> Language Class Initialized
INFO - 2024-09-05 22:45:31 --> Loader Class Initialized
INFO - 2024-09-05 22:45:31 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:31 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:31 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:31 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:31 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:31 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:45:31 --> Config Class Initialized
INFO - 2024-09-05 22:45:31 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:45:31 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:45:31 --> Utf8 Class Initialized
INFO - 2024-09-05 22:45:31 --> URI Class Initialized
INFO - 2024-09-05 22:45:31 --> Router Class Initialized
INFO - 2024-09-05 22:45:31 --> Output Class Initialized
INFO - 2024-09-05 22:45:31 --> Security Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:45:31 --> Input Class Initialized
INFO - 2024-09-05 22:45:31 --> Language Class Initialized
INFO - 2024-09-05 22:45:31 --> Loader Class Initialized
INFO - 2024-09-05 22:45:31 --> Helper loaded: url_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: file_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: security_helper
INFO - 2024-09-05 22:45:31 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:45:31 --> Database Driver Class Initialized
INFO - 2024-09-05 22:45:31 --> Email Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:45:31 --> Helper loaded: form_helper
INFO - 2024-09-05 22:45:31 --> Form Validation Class Initialized
INFO - 2024-09-05 22:45:31 --> Controller Class Initialized
DEBUG - 2024-09-05 22:45:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:45:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:45:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:45:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:45:31 --> Final output sent to browser
DEBUG - 2024-09-05 22:45:31 --> Total execution time: 0.2595
INFO - 2024-09-05 22:46:04 --> Config Class Initialized
INFO - 2024-09-05 22:46:04 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:04 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:04 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:04 --> URI Class Initialized
INFO - 2024-09-05 22:46:04 --> Router Class Initialized
INFO - 2024-09-05 22:46:04 --> Output Class Initialized
INFO - 2024-09-05 22:46:04 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:04 --> Input Class Initialized
INFO - 2024-09-05 22:46:04 --> Language Class Initialized
INFO - 2024-09-05 22:46:04 --> Loader Class Initialized
INFO - 2024-09-05 22:46:04 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:04 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:04 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:04 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:04 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:04 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:04 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:04 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:04 --> Controller Class Initialized
DEBUG - 2024-09-05 22:46:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:46:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:46:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:46:04 --> Final output sent to browser
DEBUG - 2024-09-05 22:46:04 --> Total execution time: 0.2145
INFO - 2024-09-05 22:46:08 --> Config Class Initialized
INFO - 2024-09-05 22:46:08 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:08 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:08 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:08 --> URI Class Initialized
INFO - 2024-09-05 22:46:08 --> Router Class Initialized
INFO - 2024-09-05 22:46:08 --> Output Class Initialized
INFO - 2024-09-05 22:46:08 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:08 --> Input Class Initialized
INFO - 2024-09-05 22:46:08 --> Language Class Initialized
INFO - 2024-09-05 22:46:08 --> Loader Class Initialized
INFO - 2024-09-05 22:46:08 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:08 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:08 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:08 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:08 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:09 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:09 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:09 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:09 --> Controller Class Initialized
DEBUG - 2024-09-05 22:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:46:09 --> Config Class Initialized
INFO - 2024-09-05 22:46:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:09 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:09 --> URI Class Initialized
INFO - 2024-09-05 22:46:09 --> Router Class Initialized
INFO - 2024-09-05 22:46:09 --> Output Class Initialized
INFO - 2024-09-05 22:46:09 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:09 --> Input Class Initialized
INFO - 2024-09-05 22:46:09 --> Language Class Initialized
INFO - 2024-09-05 22:46:09 --> Loader Class Initialized
INFO - 2024-09-05 22:46:09 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:09 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:09 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:09 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:09 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:09 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:09 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:09 --> Controller Class Initialized
INFO - 2024-09-05 22:46:09 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:46:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:46:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:46:09 --> Final output sent to browser
DEBUG - 2024-09-05 22:46:09 --> Total execution time: 0.5873
INFO - 2024-09-05 22:46:14 --> Config Class Initialized
INFO - 2024-09-05 22:46:14 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:14 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:14 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:14 --> URI Class Initialized
INFO - 2024-09-05 22:46:14 --> Router Class Initialized
INFO - 2024-09-05 22:46:14 --> Output Class Initialized
INFO - 2024-09-05 22:46:14 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:14 --> Input Class Initialized
INFO - 2024-09-05 22:46:14 --> Language Class Initialized
INFO - 2024-09-05 22:46:14 --> Loader Class Initialized
INFO - 2024-09-05 22:46:14 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:14 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:14 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:14 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:14 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:14 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:14 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:14 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:14 --> Controller Class Initialized
DEBUG - 2024-09-05 22:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:15 --> Config Class Initialized
INFO - 2024-09-05 22:46:15 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:15 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:15 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:15 --> URI Class Initialized
INFO - 2024-09-05 22:46:15 --> Router Class Initialized
INFO - 2024-09-05 22:46:15 --> Output Class Initialized
INFO - 2024-09-05 22:46:15 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:15 --> Input Class Initialized
INFO - 2024-09-05 22:46:15 --> Language Class Initialized
INFO - 2024-09-05 22:46:15 --> Loader Class Initialized
INFO - 2024-09-05 22:46:15 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:15 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:15 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:15 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:15 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:15 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:15 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:15 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:15 --> Controller Class Initialized
DEBUG - 2024-09-05 22:46:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:46:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:46:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:46:15 --> Final output sent to browser
DEBUG - 2024-09-05 22:46:15 --> Total execution time: 0.2374
INFO - 2024-09-05 22:46:57 --> Config Class Initialized
INFO - 2024-09-05 22:46:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:57 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:57 --> URI Class Initialized
INFO - 2024-09-05 22:46:57 --> Router Class Initialized
INFO - 2024-09-05 22:46:57 --> Output Class Initialized
INFO - 2024-09-05 22:46:57 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:57 --> Input Class Initialized
INFO - 2024-09-05 22:46:57 --> Language Class Initialized
INFO - 2024-09-05 22:46:57 --> Loader Class Initialized
INFO - 2024-09-05 22:46:57 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:57 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:57 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:57 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:57 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:57 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:57 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:57 --> Controller Class Initialized
DEBUG - 2024-09-05 22:46:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:46:58 --> Config Class Initialized
INFO - 2024-09-05 22:46:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:46:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:46:58 --> Utf8 Class Initialized
INFO - 2024-09-05 22:46:58 --> URI Class Initialized
INFO - 2024-09-05 22:46:58 --> Router Class Initialized
INFO - 2024-09-05 22:46:58 --> Output Class Initialized
INFO - 2024-09-05 22:46:58 --> Security Class Initialized
DEBUG - 2024-09-05 22:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:46:58 --> Input Class Initialized
INFO - 2024-09-05 22:46:58 --> Language Class Initialized
INFO - 2024-09-05 22:46:58 --> Loader Class Initialized
INFO - 2024-09-05 22:46:58 --> Helper loaded: url_helper
INFO - 2024-09-05 22:46:58 --> Helper loaded: file_helper
INFO - 2024-09-05 22:46:58 --> Helper loaded: security_helper
INFO - 2024-09-05 22:46:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:46:58 --> Database Driver Class Initialized
INFO - 2024-09-05 22:46:58 --> Email Class Initialized
DEBUG - 2024-09-05 22:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:46:58 --> Helper loaded: form_helper
INFO - 2024-09-05 22:46:58 --> Form Validation Class Initialized
INFO - 2024-09-05 22:46:58 --> Controller Class Initialized
INFO - 2024-09-05 22:46:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:46:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:46:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:46:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:46:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:46:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:46:58 --> Final output sent to browser
DEBUG - 2024-09-05 22:46:58 --> Total execution time: 0.5415
INFO - 2024-09-05 22:47:02 --> Config Class Initialized
INFO - 2024-09-05 22:47:02 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:02 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:02 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:02 --> URI Class Initialized
INFO - 2024-09-05 22:47:02 --> Router Class Initialized
INFO - 2024-09-05 22:47:02 --> Output Class Initialized
INFO - 2024-09-05 22:47:02 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:02 --> Input Class Initialized
INFO - 2024-09-05 22:47:02 --> Language Class Initialized
INFO - 2024-09-05 22:47:02 --> Loader Class Initialized
INFO - 2024-09-05 22:47:02 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:02 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:02 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:02 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:02 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:03 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:03 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:03 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:03 --> Controller Class Initialized
DEBUG - 2024-09-05 22:47:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:03 --> Config Class Initialized
INFO - 2024-09-05 22:47:03 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:03 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:03 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:03 --> URI Class Initialized
INFO - 2024-09-05 22:47:03 --> Router Class Initialized
INFO - 2024-09-05 22:47:03 --> Output Class Initialized
INFO - 2024-09-05 22:47:03 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:03 --> Input Class Initialized
INFO - 2024-09-05 22:47:03 --> Language Class Initialized
INFO - 2024-09-05 22:47:03 --> Loader Class Initialized
INFO - 2024-09-05 22:47:03 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:03 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:03 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:03 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:03 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:03 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:03 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:03 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:03 --> Controller Class Initialized
DEBUG - 2024-09-05 22:47:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:47:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:47:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:47:03 --> Final output sent to browser
DEBUG - 2024-09-05 22:47:03 --> Total execution time: 0.2281
INFO - 2024-09-05 22:47:09 --> Config Class Initialized
INFO - 2024-09-05 22:47:09 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:09 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:09 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:09 --> URI Class Initialized
INFO - 2024-09-05 22:47:09 --> Router Class Initialized
INFO - 2024-09-05 22:47:09 --> Output Class Initialized
INFO - 2024-09-05 22:47:09 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:09 --> Input Class Initialized
INFO - 2024-09-05 22:47:09 --> Language Class Initialized
INFO - 2024-09-05 22:47:09 --> Loader Class Initialized
INFO - 2024-09-05 22:47:09 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:09 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:09 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:09 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:09 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:10 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:10 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:10 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:10 --> Controller Class Initialized
DEBUG - 2024-09-05 22:47:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:47:10 --> Config Class Initialized
INFO - 2024-09-05 22:47:10 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:10 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:10 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:10 --> URI Class Initialized
INFO - 2024-09-05 22:47:10 --> Router Class Initialized
INFO - 2024-09-05 22:47:10 --> Output Class Initialized
INFO - 2024-09-05 22:47:10 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:10 --> Input Class Initialized
INFO - 2024-09-05 22:47:10 --> Language Class Initialized
INFO - 2024-09-05 22:47:10 --> Loader Class Initialized
INFO - 2024-09-05 22:47:10 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:10 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:10 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:10 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:10 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:10 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:10 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:10 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:10 --> Controller Class Initialized
DEBUG - 2024-09-05 22:47:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:47:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:47:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:47:10 --> Final output sent to browser
DEBUG - 2024-09-05 22:47:10 --> Total execution time: 0.2058
INFO - 2024-09-05 22:47:45 --> Config Class Initialized
INFO - 2024-09-05 22:47:45 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:45 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:45 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:45 --> URI Class Initialized
INFO - 2024-09-05 22:47:45 --> Router Class Initialized
INFO - 2024-09-05 22:47:45 --> Output Class Initialized
INFO - 2024-09-05 22:47:45 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:45 --> Input Class Initialized
INFO - 2024-09-05 22:47:45 --> Language Class Initialized
INFO - 2024-09-05 22:47:45 --> Loader Class Initialized
INFO - 2024-09-05 22:47:45 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:45 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:45 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:45 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:45 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:45 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:45 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:45 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:45 --> Controller Class Initialized
DEBUG - 2024-09-05 22:47:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:47:46 --> Config Class Initialized
INFO - 2024-09-05 22:47:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:47:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:47:46 --> Utf8 Class Initialized
INFO - 2024-09-05 22:47:46 --> URI Class Initialized
INFO - 2024-09-05 22:47:46 --> Router Class Initialized
INFO - 2024-09-05 22:47:46 --> Output Class Initialized
INFO - 2024-09-05 22:47:46 --> Security Class Initialized
DEBUG - 2024-09-05 22:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:47:46 --> Input Class Initialized
INFO - 2024-09-05 22:47:46 --> Language Class Initialized
INFO - 2024-09-05 22:47:46 --> Loader Class Initialized
INFO - 2024-09-05 22:47:46 --> Helper loaded: url_helper
INFO - 2024-09-05 22:47:46 --> Helper loaded: file_helper
INFO - 2024-09-05 22:47:46 --> Helper loaded: security_helper
INFO - 2024-09-05 22:47:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:47:46 --> Database Driver Class Initialized
INFO - 2024-09-05 22:47:46 --> Email Class Initialized
DEBUG - 2024-09-05 22:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:47:46 --> Helper loaded: form_helper
INFO - 2024-09-05 22:47:46 --> Form Validation Class Initialized
INFO - 2024-09-05 22:47:46 --> Controller Class Initialized
INFO - 2024-09-05 22:47:46 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:47:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:47:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:47:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:47:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:47:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:47:46 --> Final output sent to browser
DEBUG - 2024-09-05 22:47:46 --> Total execution time: 0.5428
INFO - 2024-09-05 22:49:58 --> Config Class Initialized
INFO - 2024-09-05 22:49:58 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:49:58 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:49:58 --> Utf8 Class Initialized
INFO - 2024-09-05 22:49:58 --> URI Class Initialized
INFO - 2024-09-05 22:49:58 --> Router Class Initialized
INFO - 2024-09-05 22:49:58 --> Output Class Initialized
INFO - 2024-09-05 22:49:58 --> Security Class Initialized
DEBUG - 2024-09-05 22:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:49:58 --> Input Class Initialized
INFO - 2024-09-05 22:49:58 --> Language Class Initialized
INFO - 2024-09-05 22:49:58 --> Loader Class Initialized
INFO - 2024-09-05 22:49:58 --> Helper loaded: url_helper
INFO - 2024-09-05 22:49:58 --> Helper loaded: file_helper
INFO - 2024-09-05 22:49:58 --> Helper loaded: security_helper
INFO - 2024-09-05 22:49:58 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:49:58 --> Database Driver Class Initialized
INFO - 2024-09-05 22:49:58 --> Email Class Initialized
DEBUG - 2024-09-05 22:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:49:58 --> Helper loaded: form_helper
INFO - 2024-09-05 22:49:58 --> Form Validation Class Initialized
INFO - 2024-09-05 22:49:58 --> Controller Class Initialized
INFO - 2024-09-05 22:49:58 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:49:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:49:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:49:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:49:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-05 22:49:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:49:58 --> Final output sent to browser
DEBUG - 2024-09-05 22:49:58 --> Total execution time: 0.6132
INFO - 2024-09-05 22:50:02 --> Config Class Initialized
INFO - 2024-09-05 22:50:02 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:50:02 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:50:02 --> Utf8 Class Initialized
INFO - 2024-09-05 22:50:02 --> URI Class Initialized
INFO - 2024-09-05 22:50:02 --> Router Class Initialized
INFO - 2024-09-05 22:50:02 --> Output Class Initialized
INFO - 2024-09-05 22:50:02 --> Security Class Initialized
DEBUG - 2024-09-05 22:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:50:02 --> Input Class Initialized
INFO - 2024-09-05 22:50:02 --> Language Class Initialized
INFO - 2024-09-05 22:50:02 --> Loader Class Initialized
INFO - 2024-09-05 22:50:02 --> Helper loaded: url_helper
INFO - 2024-09-05 22:50:02 --> Helper loaded: file_helper
INFO - 2024-09-05 22:50:02 --> Helper loaded: security_helper
INFO - 2024-09-05 22:50:02 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:50:02 --> Database Driver Class Initialized
INFO - 2024-09-05 22:50:02 --> Email Class Initialized
DEBUG - 2024-09-05 22:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:50:02 --> Helper loaded: form_helper
INFO - 2024-09-05 22:50:02 --> Form Validation Class Initialized
INFO - 2024-09-05 22:50:02 --> Controller Class Initialized
INFO - 2024-09-05 22:50:02 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:50:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:50:03 --> Final output sent to browser
DEBUG - 2024-09-05 22:50:03 --> Total execution time: 1.3311
INFO - 2024-09-05 22:52:29 --> Config Class Initialized
INFO - 2024-09-05 22:52:29 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:52:29 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:52:29 --> Utf8 Class Initialized
INFO - 2024-09-05 22:52:29 --> URI Class Initialized
DEBUG - 2024-09-05 22:52:29 --> No URI present. Default controller set.
INFO - 2024-09-05 22:52:29 --> Router Class Initialized
INFO - 2024-09-05 22:52:29 --> Output Class Initialized
INFO - 2024-09-05 22:52:29 --> Security Class Initialized
DEBUG - 2024-09-05 22:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:52:29 --> Input Class Initialized
INFO - 2024-09-05 22:52:29 --> Language Class Initialized
INFO - 2024-09-05 22:52:29 --> Loader Class Initialized
INFO - 2024-09-05 22:52:29 --> Helper loaded: url_helper
INFO - 2024-09-05 22:52:29 --> Helper loaded: file_helper
INFO - 2024-09-05 22:52:29 --> Helper loaded: security_helper
INFO - 2024-09-05 22:52:29 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:52:29 --> Database Driver Class Initialized
INFO - 2024-09-05 22:52:29 --> Email Class Initialized
DEBUG - 2024-09-05 22:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:52:29 --> Helper loaded: form_helper
INFO - 2024-09-05 22:52:29 --> Form Validation Class Initialized
INFO - 2024-09-05 22:52:29 --> Controller Class Initialized
DEBUG - 2024-09-05 22:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:52:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 22:52:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 22:52:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 22:52:29 --> Final output sent to browser
DEBUG - 2024-09-05 22:52:29 --> Total execution time: 0.2101
INFO - 2024-09-05 22:52:46 --> Config Class Initialized
INFO - 2024-09-05 22:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:52:46 --> Utf8 Class Initialized
INFO - 2024-09-05 22:52:46 --> URI Class Initialized
INFO - 2024-09-05 22:52:46 --> Router Class Initialized
INFO - 2024-09-05 22:52:46 --> Output Class Initialized
INFO - 2024-09-05 22:52:46 --> Security Class Initialized
DEBUG - 2024-09-05 22:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:52:46 --> Input Class Initialized
INFO - 2024-09-05 22:52:46 --> Language Class Initialized
INFO - 2024-09-05 22:52:46 --> Loader Class Initialized
INFO - 2024-09-05 22:52:46 --> Helper loaded: url_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: file_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: security_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:52:46 --> Database Driver Class Initialized
INFO - 2024-09-05 22:52:46 --> Email Class Initialized
DEBUG - 2024-09-05 22:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:52:46 --> Helper loaded: form_helper
INFO - 2024-09-05 22:52:46 --> Form Validation Class Initialized
INFO - 2024-09-05 22:52:46 --> Controller Class Initialized
DEBUG - 2024-09-05 22:52:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:52:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 22:52:46 --> Config Class Initialized
INFO - 2024-09-05 22:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:52:46 --> Utf8 Class Initialized
INFO - 2024-09-05 22:52:46 --> URI Class Initialized
INFO - 2024-09-05 22:52:46 --> Router Class Initialized
INFO - 2024-09-05 22:52:46 --> Output Class Initialized
INFO - 2024-09-05 22:52:46 --> Security Class Initialized
DEBUG - 2024-09-05 22:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:52:46 --> Input Class Initialized
INFO - 2024-09-05 22:52:46 --> Language Class Initialized
INFO - 2024-09-05 22:52:46 --> Loader Class Initialized
INFO - 2024-09-05 22:52:46 --> Helper loaded: url_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: file_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: security_helper
INFO - 2024-09-05 22:52:46 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:52:46 --> Database Driver Class Initialized
INFO - 2024-09-05 22:52:47 --> Email Class Initialized
DEBUG - 2024-09-05 22:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:52:47 --> Helper loaded: form_helper
INFO - 2024-09-05 22:52:47 --> Form Validation Class Initialized
INFO - 2024-09-05 22:52:47 --> Controller Class Initialized
INFO - 2024-09-05 22:52:47 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:52:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:52:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:52:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:52:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:52:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:52:47 --> Final output sent to browser
DEBUG - 2024-09-05 22:52:47 --> Total execution time: 0.5935
INFO - 2024-09-05 22:56:08 --> Config Class Initialized
INFO - 2024-09-05 22:56:08 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:56:08 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:56:08 --> Utf8 Class Initialized
INFO - 2024-09-05 22:56:08 --> URI Class Initialized
INFO - 2024-09-05 22:56:08 --> Router Class Initialized
INFO - 2024-09-05 22:56:08 --> Output Class Initialized
INFO - 2024-09-05 22:56:08 --> Security Class Initialized
DEBUG - 2024-09-05 22:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:56:08 --> Input Class Initialized
INFO - 2024-09-05 22:56:08 --> Language Class Initialized
INFO - 2024-09-05 22:56:08 --> Loader Class Initialized
INFO - 2024-09-05 22:56:08 --> Helper loaded: url_helper
INFO - 2024-09-05 22:56:08 --> Helper loaded: file_helper
INFO - 2024-09-05 22:56:08 --> Helper loaded: security_helper
INFO - 2024-09-05 22:56:08 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:56:08 --> Database Driver Class Initialized
INFO - 2024-09-05 22:56:08 --> Email Class Initialized
DEBUG - 2024-09-05 22:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:56:08 --> Helper loaded: form_helper
INFO - 2024-09-05 22:56:08 --> Form Validation Class Initialized
INFO - 2024-09-05 22:56:08 --> Controller Class Initialized
INFO - 2024-09-05 22:56:08 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:56:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:56:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:56:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-05 22:56:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:56:08 --> Final output sent to browser
DEBUG - 2024-09-05 22:56:08 --> Total execution time: 0.5450
INFO - 2024-09-05 22:56:15 --> Config Class Initialized
INFO - 2024-09-05 22:56:15 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:56:15 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:56:15 --> Utf8 Class Initialized
INFO - 2024-09-05 22:56:15 --> URI Class Initialized
INFO - 2024-09-05 22:56:15 --> Router Class Initialized
INFO - 2024-09-05 22:56:15 --> Output Class Initialized
INFO - 2024-09-05 22:56:15 --> Security Class Initialized
DEBUG - 2024-09-05 22:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:56:15 --> Input Class Initialized
INFO - 2024-09-05 22:56:15 --> Language Class Initialized
INFO - 2024-09-05 22:56:15 --> Loader Class Initialized
INFO - 2024-09-05 22:56:15 --> Helper loaded: url_helper
INFO - 2024-09-05 22:56:15 --> Helper loaded: file_helper
INFO - 2024-09-05 22:56:15 --> Helper loaded: security_helper
INFO - 2024-09-05 22:56:15 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:56:15 --> Database Driver Class Initialized
INFO - 2024-09-05 22:56:15 --> Email Class Initialized
DEBUG - 2024-09-05 22:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:56:15 --> Helper loaded: form_helper
INFO - 2024-09-05 22:56:15 --> Form Validation Class Initialized
INFO - 2024-09-05 22:56:15 --> Controller Class Initialized
INFO - 2024-09-05 22:56:15 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:56:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:56:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:56:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:56:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:56:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:56:16 --> Final output sent to browser
DEBUG - 2024-09-05 22:56:16 --> Total execution time: 0.6135
INFO - 2024-09-05 22:57:21 --> Config Class Initialized
INFO - 2024-09-05 22:57:21 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:57:21 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:57:21 --> Utf8 Class Initialized
INFO - 2024-09-05 22:57:21 --> URI Class Initialized
INFO - 2024-09-05 22:57:21 --> Router Class Initialized
INFO - 2024-09-05 22:57:21 --> Output Class Initialized
INFO - 2024-09-05 22:57:21 --> Security Class Initialized
DEBUG - 2024-09-05 22:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:57:21 --> Input Class Initialized
INFO - 2024-09-05 22:57:21 --> Language Class Initialized
INFO - 2024-09-05 22:57:21 --> Loader Class Initialized
INFO - 2024-09-05 22:57:21 --> Helper loaded: url_helper
INFO - 2024-09-05 22:57:21 --> Helper loaded: file_helper
INFO - 2024-09-05 22:57:21 --> Helper loaded: security_helper
INFO - 2024-09-05 22:57:21 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:57:21 --> Database Driver Class Initialized
INFO - 2024-09-05 22:57:21 --> Email Class Initialized
DEBUG - 2024-09-05 22:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:57:21 --> Helper loaded: form_helper
INFO - 2024-09-05 22:57:21 --> Form Validation Class Initialized
INFO - 2024-09-05 22:57:21 --> Controller Class Initialized
INFO - 2024-09-05 22:57:21 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:57:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:57:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:57:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:57:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:57:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:57:21 --> Final output sent to browser
DEBUG - 2024-09-05 22:57:21 --> Total execution time: 0.8295
INFO - 2024-09-05 22:57:37 --> Config Class Initialized
INFO - 2024-09-05 22:57:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:57:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:57:37 --> Utf8 Class Initialized
INFO - 2024-09-05 22:57:37 --> URI Class Initialized
INFO - 2024-09-05 22:57:37 --> Router Class Initialized
INFO - 2024-09-05 22:57:37 --> Output Class Initialized
INFO - 2024-09-05 22:57:37 --> Security Class Initialized
DEBUG - 2024-09-05 22:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:57:37 --> Input Class Initialized
INFO - 2024-09-05 22:57:37 --> Language Class Initialized
INFO - 2024-09-05 22:57:37 --> Loader Class Initialized
INFO - 2024-09-05 22:57:37 --> Helper loaded: url_helper
INFO - 2024-09-05 22:57:37 --> Helper loaded: file_helper
INFO - 2024-09-05 22:57:37 --> Helper loaded: security_helper
INFO - 2024-09-05 22:57:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:57:37 --> Database Driver Class Initialized
INFO - 2024-09-05 22:57:37 --> Email Class Initialized
DEBUG - 2024-09-05 22:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:57:37 --> Helper loaded: form_helper
INFO - 2024-09-05 22:57:37 --> Form Validation Class Initialized
INFO - 2024-09-05 22:57:37 --> Controller Class Initialized
INFO - 2024-09-05 22:57:37 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:57:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:57:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:57:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:57:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:57:37 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:57:37 --> Final output sent to browser
DEBUG - 2024-09-05 22:57:37 --> Total execution time: 0.5348
INFO - 2024-09-05 22:58:26 --> Config Class Initialized
INFO - 2024-09-05 22:58:26 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:58:26 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:58:26 --> Utf8 Class Initialized
INFO - 2024-09-05 22:58:26 --> URI Class Initialized
INFO - 2024-09-05 22:58:26 --> Router Class Initialized
INFO - 2024-09-05 22:58:26 --> Output Class Initialized
INFO - 2024-09-05 22:58:26 --> Security Class Initialized
DEBUG - 2024-09-05 22:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:58:26 --> Input Class Initialized
INFO - 2024-09-05 22:58:26 --> Language Class Initialized
INFO - 2024-09-05 22:58:26 --> Loader Class Initialized
INFO - 2024-09-05 22:58:26 --> Helper loaded: url_helper
INFO - 2024-09-05 22:58:26 --> Helper loaded: file_helper
INFO - 2024-09-05 22:58:26 --> Helper loaded: security_helper
INFO - 2024-09-05 22:58:26 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:58:26 --> Database Driver Class Initialized
INFO - 2024-09-05 22:58:26 --> Email Class Initialized
DEBUG - 2024-09-05 22:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:58:26 --> Helper loaded: form_helper
INFO - 2024-09-05 22:58:26 --> Form Validation Class Initialized
INFO - 2024-09-05 22:58:26 --> Controller Class Initialized
INFO - 2024-09-05 22:58:26 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:58:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:58:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:58:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:58:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:58:26 --> Final output sent to browser
DEBUG - 2024-09-05 22:58:26 --> Total execution time: 0.5737
INFO - 2024-09-05 22:58:29 --> Config Class Initialized
INFO - 2024-09-05 22:58:29 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:58:29 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:58:29 --> Utf8 Class Initialized
INFO - 2024-09-05 22:58:29 --> URI Class Initialized
INFO - 2024-09-05 22:58:29 --> Router Class Initialized
INFO - 2024-09-05 22:58:29 --> Output Class Initialized
INFO - 2024-09-05 22:58:29 --> Security Class Initialized
DEBUG - 2024-09-05 22:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:58:29 --> Input Class Initialized
INFO - 2024-09-05 22:58:29 --> Language Class Initialized
INFO - 2024-09-05 22:58:29 --> Loader Class Initialized
INFO - 2024-09-05 22:58:29 --> Helper loaded: url_helper
INFO - 2024-09-05 22:58:29 --> Helper loaded: file_helper
INFO - 2024-09-05 22:58:29 --> Helper loaded: security_helper
INFO - 2024-09-05 22:58:29 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:58:29 --> Database Driver Class Initialized
INFO - 2024-09-05 22:58:29 --> Email Class Initialized
DEBUG - 2024-09-05 22:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:58:29 --> Helper loaded: form_helper
INFO - 2024-09-05 22:58:29 --> Form Validation Class Initialized
INFO - 2024-09-05 22:58:29 --> Controller Class Initialized
INFO - 2024-09-05 22:58:29 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:58:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:58:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:58:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:58:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:58:30 --> Final output sent to browser
DEBUG - 2024-09-05 22:58:30 --> Total execution time: 0.5851
INFO - 2024-09-05 22:59:23 --> Config Class Initialized
INFO - 2024-09-05 22:59:23 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:59:23 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:59:23 --> Utf8 Class Initialized
INFO - 2024-09-05 22:59:23 --> URI Class Initialized
INFO - 2024-09-05 22:59:23 --> Router Class Initialized
INFO - 2024-09-05 22:59:23 --> Output Class Initialized
INFO - 2024-09-05 22:59:23 --> Security Class Initialized
DEBUG - 2024-09-05 22:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:59:23 --> Input Class Initialized
INFO - 2024-09-05 22:59:23 --> Language Class Initialized
INFO - 2024-09-05 22:59:23 --> Loader Class Initialized
INFO - 2024-09-05 22:59:23 --> Helper loaded: url_helper
INFO - 2024-09-05 22:59:23 --> Helper loaded: file_helper
INFO - 2024-09-05 22:59:23 --> Helper loaded: security_helper
INFO - 2024-09-05 22:59:23 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:59:23 --> Database Driver Class Initialized
INFO - 2024-09-05 22:59:23 --> Email Class Initialized
DEBUG - 2024-09-05 22:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:59:23 --> Helper loaded: form_helper
INFO - 2024-09-05 22:59:23 --> Form Validation Class Initialized
INFO - 2024-09-05 22:59:23 --> Controller Class Initialized
INFO - 2024-09-05 22:59:23 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:59:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:59:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:59:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:59:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:59:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:59:24 --> Final output sent to browser
DEBUG - 2024-09-05 22:59:24 --> Total execution time: 0.6348
INFO - 2024-09-05 22:59:51 --> Config Class Initialized
INFO - 2024-09-05 22:59:51 --> Hooks Class Initialized
DEBUG - 2024-09-05 22:59:51 --> UTF-8 Support Enabled
INFO - 2024-09-05 22:59:51 --> Utf8 Class Initialized
INFO - 2024-09-05 22:59:51 --> URI Class Initialized
INFO - 2024-09-05 22:59:51 --> Router Class Initialized
INFO - 2024-09-05 22:59:51 --> Output Class Initialized
INFO - 2024-09-05 22:59:51 --> Security Class Initialized
DEBUG - 2024-09-05 22:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 22:59:51 --> Input Class Initialized
INFO - 2024-09-05 22:59:51 --> Language Class Initialized
INFO - 2024-09-05 22:59:51 --> Loader Class Initialized
INFO - 2024-09-05 22:59:51 --> Helper loaded: url_helper
INFO - 2024-09-05 22:59:51 --> Helper loaded: file_helper
INFO - 2024-09-05 22:59:51 --> Helper loaded: security_helper
INFO - 2024-09-05 22:59:51 --> Helper loaded: wpu_helper
INFO - 2024-09-05 22:59:51 --> Database Driver Class Initialized
INFO - 2024-09-05 22:59:51 --> Email Class Initialized
DEBUG - 2024-09-05 22:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 22:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 22:59:52 --> Helper loaded: form_helper
INFO - 2024-09-05 22:59:52 --> Form Validation Class Initialized
INFO - 2024-09-05 22:59:52 --> Controller Class Initialized
INFO - 2024-09-05 22:59:52 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 22:59:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 22:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 22:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 22:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 22:59:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 22:59:52 --> Final output sent to browser
DEBUG - 2024-09-05 22:59:52 --> Total execution time: 0.6426
INFO - 2024-09-05 23:08:06 --> Config Class Initialized
INFO - 2024-09-05 23:08:06 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:08:06 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:08:06 --> Utf8 Class Initialized
INFO - 2024-09-05 23:08:06 --> URI Class Initialized
DEBUG - 2024-09-05 23:08:06 --> No URI present. Default controller set.
INFO - 2024-09-05 23:08:06 --> Router Class Initialized
INFO - 2024-09-05 23:08:06 --> Output Class Initialized
INFO - 2024-09-05 23:08:06 --> Security Class Initialized
DEBUG - 2024-09-05 23:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:08:06 --> Input Class Initialized
INFO - 2024-09-05 23:08:06 --> Language Class Initialized
INFO - 2024-09-05 23:08:06 --> Loader Class Initialized
INFO - 2024-09-05 23:08:06 --> Helper loaded: url_helper
INFO - 2024-09-05 23:08:06 --> Helper loaded: file_helper
INFO - 2024-09-05 23:08:06 --> Helper loaded: security_helper
INFO - 2024-09-05 23:08:06 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:08:06 --> Database Driver Class Initialized
INFO - 2024-09-05 23:08:06 --> Email Class Initialized
DEBUG - 2024-09-05 23:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:08:06 --> Helper loaded: form_helper
INFO - 2024-09-05 23:08:06 --> Form Validation Class Initialized
INFO - 2024-09-05 23:08:06 --> Controller Class Initialized
DEBUG - 2024-09-05 23:08:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:08:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 23:08:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 23:08:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 23:08:06 --> Final output sent to browser
DEBUG - 2024-09-05 23:08:06 --> Total execution time: 0.2418
INFO - 2024-09-05 23:08:37 --> Config Class Initialized
INFO - 2024-09-05 23:08:37 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:08:37 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:08:37 --> Utf8 Class Initialized
INFO - 2024-09-05 23:08:37 --> URI Class Initialized
INFO - 2024-09-05 23:08:37 --> Router Class Initialized
INFO - 2024-09-05 23:08:37 --> Output Class Initialized
INFO - 2024-09-05 23:08:37 --> Security Class Initialized
DEBUG - 2024-09-05 23:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:08:37 --> Input Class Initialized
INFO - 2024-09-05 23:08:37 --> Language Class Initialized
INFO - 2024-09-05 23:08:37 --> Loader Class Initialized
INFO - 2024-09-05 23:08:37 --> Helper loaded: url_helper
INFO - 2024-09-05 23:08:37 --> Helper loaded: file_helper
INFO - 2024-09-05 23:08:37 --> Helper loaded: security_helper
INFO - 2024-09-05 23:08:37 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:08:37 --> Database Driver Class Initialized
INFO - 2024-09-05 23:08:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:08:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:08:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:08:38 --> Controller Class Initialized
DEBUG - 2024-09-05 23:08:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:08:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-05 23:08:38 --> Config Class Initialized
INFO - 2024-09-05 23:08:38 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:08:38 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:08:38 --> Utf8 Class Initialized
INFO - 2024-09-05 23:08:38 --> URI Class Initialized
INFO - 2024-09-05 23:08:38 --> Router Class Initialized
INFO - 2024-09-05 23:08:38 --> Output Class Initialized
INFO - 2024-09-05 23:08:38 --> Security Class Initialized
DEBUG - 2024-09-05 23:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:08:38 --> Input Class Initialized
INFO - 2024-09-05 23:08:38 --> Language Class Initialized
INFO - 2024-09-05 23:08:38 --> Loader Class Initialized
INFO - 2024-09-05 23:08:38 --> Helper loaded: url_helper
INFO - 2024-09-05 23:08:38 --> Helper loaded: file_helper
INFO - 2024-09-05 23:08:38 --> Helper loaded: security_helper
INFO - 2024-09-05 23:08:38 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:08:38 --> Database Driver Class Initialized
INFO - 2024-09-05 23:08:38 --> Email Class Initialized
DEBUG - 2024-09-05 23:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:08:38 --> Helper loaded: form_helper
INFO - 2024-09-05 23:08:38 --> Form Validation Class Initialized
INFO - 2024-09-05 23:08:38 --> Controller Class Initialized
INFO - 2024-09-05 23:08:38 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:08:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:08:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 23:08:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 23:08:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 23:08:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 23:08:38 --> Final output sent to browser
DEBUG - 2024-09-05 23:08:38 --> Total execution time: 0.4968
INFO - 2024-09-05 23:09:03 --> Config Class Initialized
INFO - 2024-09-05 23:09:03 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:09:03 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:09:03 --> Utf8 Class Initialized
INFO - 2024-09-05 23:09:03 --> URI Class Initialized
INFO - 2024-09-05 23:09:03 --> Router Class Initialized
INFO - 2024-09-05 23:09:03 --> Output Class Initialized
INFO - 2024-09-05 23:09:03 --> Security Class Initialized
DEBUG - 2024-09-05 23:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:09:03 --> Input Class Initialized
INFO - 2024-09-05 23:09:03 --> Language Class Initialized
INFO - 2024-09-05 23:09:03 --> Loader Class Initialized
INFO - 2024-09-05 23:09:03 --> Helper loaded: url_helper
INFO - 2024-09-05 23:09:03 --> Helper loaded: file_helper
INFO - 2024-09-05 23:09:03 --> Helper loaded: security_helper
INFO - 2024-09-05 23:09:03 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:09:03 --> Database Driver Class Initialized
INFO - 2024-09-05 23:09:03 --> Email Class Initialized
DEBUG - 2024-09-05 23:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:09:03 --> Helper loaded: form_helper
INFO - 2024-09-05 23:09:03 --> Form Validation Class Initialized
INFO - 2024-09-05 23:09:03 --> Controller Class Initialized
INFO - 2024-09-05 23:09:03 --> Model "Antrol_model" initialized
DEBUG - 2024-09-05 23:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-05 23:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-05 23:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-05 23:09:03 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-05 23:09:03 --> Final output sent to browser
DEBUG - 2024-09-05 23:09:03 --> Total execution time: 0.6139
INFO - 2024-09-05 23:11:44 --> Config Class Initialized
INFO - 2024-09-05 23:11:44 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:11:44 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:11:44 --> Utf8 Class Initialized
INFO - 2024-09-05 23:11:44 --> URI Class Initialized
DEBUG - 2024-09-05 23:11:44 --> No URI present. Default controller set.
INFO - 2024-09-05 23:11:44 --> Router Class Initialized
INFO - 2024-09-05 23:11:44 --> Output Class Initialized
INFO - 2024-09-05 23:11:44 --> Security Class Initialized
DEBUG - 2024-09-05 23:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:11:44 --> Input Class Initialized
INFO - 2024-09-05 23:11:44 --> Language Class Initialized
INFO - 2024-09-05 23:11:44 --> Loader Class Initialized
INFO - 2024-09-05 23:11:44 --> Helper loaded: url_helper
INFO - 2024-09-05 23:11:44 --> Helper loaded: file_helper
INFO - 2024-09-05 23:11:44 --> Helper loaded: security_helper
INFO - 2024-09-05 23:11:44 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:11:44 --> Database Driver Class Initialized
INFO - 2024-09-05 23:11:44 --> Email Class Initialized
DEBUG - 2024-09-05 23:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:11:44 --> Helper loaded: form_helper
INFO - 2024-09-05 23:11:44 --> Form Validation Class Initialized
INFO - 2024-09-05 23:11:44 --> Controller Class Initialized
DEBUG - 2024-09-05 23:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:11:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 23:11:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 23:11:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 23:11:44 --> Final output sent to browser
DEBUG - 2024-09-05 23:11:44 --> Total execution time: 0.2105
INFO - 2024-09-05 23:16:30 --> Config Class Initialized
INFO - 2024-09-05 23:16:30 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:16:30 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:16:30 --> Utf8 Class Initialized
INFO - 2024-09-05 23:16:30 --> URI Class Initialized
DEBUG - 2024-09-05 23:16:30 --> No URI present. Default controller set.
INFO - 2024-09-05 23:16:30 --> Router Class Initialized
INFO - 2024-09-05 23:16:30 --> Output Class Initialized
INFO - 2024-09-05 23:16:30 --> Security Class Initialized
DEBUG - 2024-09-05 23:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:16:30 --> Input Class Initialized
INFO - 2024-09-05 23:16:30 --> Language Class Initialized
INFO - 2024-09-05 23:16:30 --> Loader Class Initialized
INFO - 2024-09-05 23:16:30 --> Helper loaded: url_helper
INFO - 2024-09-05 23:16:30 --> Helper loaded: file_helper
INFO - 2024-09-05 23:16:30 --> Helper loaded: security_helper
INFO - 2024-09-05 23:16:30 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:16:30 --> Database Driver Class Initialized
INFO - 2024-09-05 23:16:31 --> Email Class Initialized
DEBUG - 2024-09-05 23:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:16:31 --> Helper loaded: form_helper
INFO - 2024-09-05 23:16:31 --> Form Validation Class Initialized
INFO - 2024-09-05 23:16:31 --> Controller Class Initialized
DEBUG - 2024-09-05 23:16:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 23:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 23:16:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 23:16:31 --> Final output sent to browser
DEBUG - 2024-09-05 23:16:31 --> Total execution time: 0.2359
INFO - 2024-09-05 23:22:57 --> Config Class Initialized
INFO - 2024-09-05 23:22:57 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:22:57 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:22:57 --> Utf8 Class Initialized
INFO - 2024-09-05 23:22:57 --> URI Class Initialized
DEBUG - 2024-09-05 23:22:57 --> No URI present. Default controller set.
INFO - 2024-09-05 23:22:57 --> Router Class Initialized
INFO - 2024-09-05 23:22:57 --> Output Class Initialized
INFO - 2024-09-05 23:22:57 --> Security Class Initialized
DEBUG - 2024-09-05 23:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:22:57 --> Input Class Initialized
INFO - 2024-09-05 23:22:57 --> Language Class Initialized
INFO - 2024-09-05 23:22:57 --> Loader Class Initialized
INFO - 2024-09-05 23:22:57 --> Helper loaded: url_helper
INFO - 2024-09-05 23:22:57 --> Helper loaded: file_helper
INFO - 2024-09-05 23:22:57 --> Helper loaded: security_helper
INFO - 2024-09-05 23:22:57 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:22:57 --> Database Driver Class Initialized
INFO - 2024-09-05 23:22:58 --> Email Class Initialized
DEBUG - 2024-09-05 23:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:22:58 --> Helper loaded: form_helper
INFO - 2024-09-05 23:22:58 --> Form Validation Class Initialized
INFO - 2024-09-05 23:22:58 --> Controller Class Initialized
DEBUG - 2024-09-05 23:22:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:22:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 23:22:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 23:22:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 23:22:58 --> Final output sent to browser
DEBUG - 2024-09-05 23:22:58 --> Total execution time: 0.2192
INFO - 2024-09-05 23:42:19 --> Config Class Initialized
INFO - 2024-09-05 23:42:19 --> Hooks Class Initialized
DEBUG - 2024-09-05 23:42:19 --> UTF-8 Support Enabled
INFO - 2024-09-05 23:42:19 --> Utf8 Class Initialized
INFO - 2024-09-05 23:42:19 --> URI Class Initialized
DEBUG - 2024-09-05 23:42:19 --> No URI present. Default controller set.
INFO - 2024-09-05 23:42:19 --> Router Class Initialized
INFO - 2024-09-05 23:42:19 --> Output Class Initialized
INFO - 2024-09-05 23:42:19 --> Security Class Initialized
DEBUG - 2024-09-05 23:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 23:42:19 --> Input Class Initialized
INFO - 2024-09-05 23:42:19 --> Language Class Initialized
INFO - 2024-09-05 23:42:19 --> Loader Class Initialized
INFO - 2024-09-05 23:42:19 --> Helper loaded: url_helper
INFO - 2024-09-05 23:42:19 --> Helper loaded: file_helper
INFO - 2024-09-05 23:42:19 --> Helper loaded: security_helper
INFO - 2024-09-05 23:42:19 --> Helper loaded: wpu_helper
INFO - 2024-09-05 23:42:19 --> Database Driver Class Initialized
INFO - 2024-09-05 23:42:20 --> Email Class Initialized
DEBUG - 2024-09-05 23:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-05 23:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 23:42:20 --> Helper loaded: form_helper
INFO - 2024-09-05 23:42:20 --> Form Validation Class Initialized
INFO - 2024-09-05 23:42:20 --> Controller Class Initialized
DEBUG - 2024-09-05 23:42:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-05 23:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-05 23:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-05 23:42:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-05 23:42:20 --> Final output sent to browser
DEBUG - 2024-09-05 23:42:20 --> Total execution time: 0.2203
