<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-26 15:10:32 --> Config Class Initialized
INFO - 2024-08-26 15:10:32 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:10:32 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:10:32 --> Utf8 Class Initialized
INFO - 2024-08-26 15:10:32 --> URI Class Initialized
INFO - 2024-08-26 15:10:32 --> Router Class Initialized
INFO - 2024-08-26 15:10:32 --> Output Class Initialized
INFO - 2024-08-26 15:10:32 --> Security Class Initialized
DEBUG - 2024-08-26 15:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:10:32 --> Input Class Initialized
INFO - 2024-08-26 15:10:32 --> Language Class Initialized
INFO - 2024-08-26 15:10:32 --> Loader Class Initialized
INFO - 2024-08-26 15:10:33 --> Helper loaded: url_helper
INFO - 2024-08-26 15:10:33 --> Helper loaded: file_helper
INFO - 2024-08-26 15:10:33 --> Helper loaded: security_helper
INFO - 2024-08-26 15:10:33 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:10:33 --> Database Driver Class Initialized
INFO - 2024-08-26 15:10:33 --> Email Class Initialized
DEBUG - 2024-08-26 15:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:10:33 --> Helper loaded: form_helper
INFO - 2024-08-26 15:10:33 --> Form Validation Class Initialized
INFO - 2024-08-26 15:10:33 --> Controller Class Initialized
INFO - 2024-08-26 15:10:33 --> Model "User_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:10:33 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:10:33 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris_detail.php
INFO - 2024-08-26 15:10:33 --> Final output sent to browser
DEBUG - 2024-08-26 15:10:33 --> Total execution time: 1.3923
INFO - 2024-08-26 15:10:36 --> Config Class Initialized
INFO - 2024-08-26 15:10:36 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:10:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:10:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:10:36 --> URI Class Initialized
DEBUG - 2024-08-26 15:10:36 --> No URI present. Default controller set.
INFO - 2024-08-26 15:10:36 --> Router Class Initialized
INFO - 2024-08-26 15:10:36 --> Output Class Initialized
INFO - 2024-08-26 15:10:36 --> Security Class Initialized
DEBUG - 2024-08-26 15:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:10:36 --> Input Class Initialized
INFO - 2024-08-26 15:10:36 --> Language Class Initialized
INFO - 2024-08-26 15:10:36 --> Loader Class Initialized
INFO - 2024-08-26 15:10:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:10:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:10:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:10:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:10:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:10:36 --> Email Class Initialized
DEBUG - 2024-08-26 15:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:10:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:10:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:10:36 --> Controller Class Initialized
DEBUG - 2024-08-26 15:10:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:10:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-26 15:10:36 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-26 15:10:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-26 15:10:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:10:36 --> Total execution time: 0.1045
INFO - 2024-08-26 15:10:38 --> Config Class Initialized
INFO - 2024-08-26 15:10:38 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:10:38 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:10:38 --> Utf8 Class Initialized
INFO - 2024-08-26 15:10:38 --> URI Class Initialized
INFO - 2024-08-26 15:10:38 --> Router Class Initialized
INFO - 2024-08-26 15:10:38 --> Output Class Initialized
INFO - 2024-08-26 15:10:38 --> Security Class Initialized
DEBUG - 2024-08-26 15:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:10:38 --> Input Class Initialized
INFO - 2024-08-26 15:10:38 --> Language Class Initialized
INFO - 2024-08-26 15:10:38 --> Loader Class Initialized
INFO - 2024-08-26 15:10:38 --> Helper loaded: url_helper
INFO - 2024-08-26 15:10:38 --> Helper loaded: file_helper
INFO - 2024-08-26 15:10:38 --> Helper loaded: security_helper
INFO - 2024-08-26 15:10:38 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:10:38 --> Database Driver Class Initialized
INFO - 2024-08-26 15:10:38 --> Email Class Initialized
DEBUG - 2024-08-26 15:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:10:38 --> Helper loaded: form_helper
INFO - 2024-08-26 15:10:38 --> Form Validation Class Initialized
INFO - 2024-08-26 15:10:38 --> Controller Class Initialized
INFO - 2024-08-26 15:10:38 --> Model "User_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:10:38 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:10:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:10:38 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris_detail.php
INFO - 2024-08-26 15:10:38 --> Final output sent to browser
DEBUG - 2024-08-26 15:10:38 --> Total execution time: 0.0859
INFO - 2024-08-26 15:10:47 --> Config Class Initialized
INFO - 2024-08-26 15:10:47 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:10:47 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:10:47 --> Utf8 Class Initialized
INFO - 2024-08-26 15:10:47 --> URI Class Initialized
INFO - 2024-08-26 15:10:47 --> Router Class Initialized
INFO - 2024-08-26 15:10:47 --> Output Class Initialized
INFO - 2024-08-26 15:10:47 --> Security Class Initialized
DEBUG - 2024-08-26 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:10:47 --> Input Class Initialized
INFO - 2024-08-26 15:10:47 --> Language Class Initialized
INFO - 2024-08-26 15:10:47 --> Loader Class Initialized
INFO - 2024-08-26 15:10:47 --> Helper loaded: url_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: file_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: security_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:10:47 --> Database Driver Class Initialized
INFO - 2024-08-26 15:10:47 --> Email Class Initialized
DEBUG - 2024-08-26 15:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:10:47 --> Helper loaded: form_helper
INFO - 2024-08-26 15:10:47 --> Form Validation Class Initialized
INFO - 2024-08-26 15:10:47 --> Controller Class Initialized
DEBUG - 2024-08-26 15:10:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:10:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-26 15:10:47 --> Config Class Initialized
INFO - 2024-08-26 15:10:47 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:10:47 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:10:47 --> Utf8 Class Initialized
INFO - 2024-08-26 15:10:47 --> URI Class Initialized
INFO - 2024-08-26 15:10:47 --> Router Class Initialized
INFO - 2024-08-26 15:10:47 --> Output Class Initialized
INFO - 2024-08-26 15:10:47 --> Security Class Initialized
DEBUG - 2024-08-26 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:10:47 --> Input Class Initialized
INFO - 2024-08-26 15:10:47 --> Language Class Initialized
INFO - 2024-08-26 15:10:47 --> Loader Class Initialized
INFO - 2024-08-26 15:10:47 --> Helper loaded: url_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: file_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: security_helper
INFO - 2024-08-26 15:10:47 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:10:47 --> Database Driver Class Initialized
INFO - 2024-08-26 15:10:47 --> Email Class Initialized
DEBUG - 2024-08-26 15:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:10:47 --> Helper loaded: form_helper
INFO - 2024-08-26 15:10:47 --> Form Validation Class Initialized
INFO - 2024-08-26 15:10:47 --> Controller Class Initialized
INFO - 2024-08-26 15:10:47 --> Model "User_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:10:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:10:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:10:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:10:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:10:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:10:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-26 15:10:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:10:47 --> Final output sent to browser
DEBUG - 2024-08-26 15:10:47 --> Total execution time: 0.1784
INFO - 2024-08-26 15:18:54 --> Config Class Initialized
INFO - 2024-08-26 15:18:54 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:18:54 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:18:54 --> Utf8 Class Initialized
INFO - 2024-08-26 15:18:54 --> URI Class Initialized
INFO - 2024-08-26 15:18:54 --> Router Class Initialized
INFO - 2024-08-26 15:18:54 --> Output Class Initialized
INFO - 2024-08-26 15:18:54 --> Security Class Initialized
DEBUG - 2024-08-26 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:18:54 --> Input Class Initialized
INFO - 2024-08-26 15:18:54 --> Language Class Initialized
INFO - 2024-08-26 15:18:54 --> Loader Class Initialized
INFO - 2024-08-26 15:18:54 --> Helper loaded: url_helper
INFO - 2024-08-26 15:18:54 --> Helper loaded: file_helper
INFO - 2024-08-26 15:18:54 --> Helper loaded: security_helper
INFO - 2024-08-26 15:18:54 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:18:54 --> Database Driver Class Initialized
INFO - 2024-08-26 15:18:54 --> Email Class Initialized
DEBUG - 2024-08-26 15:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:18:54 --> Helper loaded: form_helper
INFO - 2024-08-26 15:18:54 --> Form Validation Class Initialized
INFO - 2024-08-26 15:18:54 --> Controller Class Initialized
INFO - 2024-08-26 15:18:54 --> Model "User_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:18:54 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:18:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:18:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:18:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:18:54 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-26 15:18:54 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:18:54 --> Final output sent to browser
DEBUG - 2024-08-26 15:18:54 --> Total execution time: 0.1530
INFO - 2024-08-26 15:18:56 --> Config Class Initialized
INFO - 2024-08-26 15:18:56 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:18:56 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:18:56 --> Utf8 Class Initialized
INFO - 2024-08-26 15:18:56 --> URI Class Initialized
INFO - 2024-08-26 15:18:56 --> Router Class Initialized
INFO - 2024-08-26 15:18:56 --> Output Class Initialized
INFO - 2024-08-26 15:18:56 --> Security Class Initialized
DEBUG - 2024-08-26 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:18:56 --> Input Class Initialized
INFO - 2024-08-26 15:18:56 --> Language Class Initialized
INFO - 2024-08-26 15:18:56 --> Loader Class Initialized
INFO - 2024-08-26 15:18:56 --> Helper loaded: url_helper
INFO - 2024-08-26 15:18:56 --> Helper loaded: file_helper
INFO - 2024-08-26 15:18:56 --> Helper loaded: security_helper
INFO - 2024-08-26 15:18:56 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:18:56 --> Database Driver Class Initialized
INFO - 2024-08-26 15:18:56 --> Email Class Initialized
DEBUG - 2024-08-26 15:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:18:56 --> Helper loaded: form_helper
INFO - 2024-08-26 15:18:56 --> Form Validation Class Initialized
INFO - 2024-08-26 15:18:56 --> Controller Class Initialized
INFO - 2024-08-26 15:18:56 --> Model "User_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:18:56 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:18:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-26 15:18:56 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:18:56 --> Final output sent to browser
DEBUG - 2024-08-26 15:18:56 --> Total execution time: 0.1161
INFO - 2024-08-26 15:19:29 --> Config Class Initialized
INFO - 2024-08-26 15:19:29 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:29 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:29 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:29 --> URI Class Initialized
INFO - 2024-08-26 15:19:29 --> Router Class Initialized
INFO - 2024-08-26 15:19:29 --> Output Class Initialized
INFO - 2024-08-26 15:19:29 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:29 --> Input Class Initialized
INFO - 2024-08-26 15:19:29 --> Language Class Initialized
INFO - 2024-08-26 15:19:29 --> Loader Class Initialized
INFO - 2024-08-26 15:19:29 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:29 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:29 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:29 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:29 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:29 --> Email Class Initialized
DEBUG - 2024-08-26 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:29 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:29 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:29 --> Controller Class Initialized
INFO - 2024-08-26 15:19:29 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:29 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:19:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:19:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:19:29 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:19:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:19:29 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:29 --> Total execution time: 0.1187
INFO - 2024-08-26 15:19:34 --> Config Class Initialized
INFO - 2024-08-26 15:19:34 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:34 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:34 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:34 --> URI Class Initialized
INFO - 2024-08-26 15:19:34 --> Router Class Initialized
INFO - 2024-08-26 15:19:34 --> Output Class Initialized
INFO - 2024-08-26 15:19:34 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:34 --> Input Class Initialized
INFO - 2024-08-26 15:19:34 --> Language Class Initialized
INFO - 2024-08-26 15:19:34 --> Loader Class Initialized
INFO - 2024-08-26 15:19:34 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:34 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:34 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:34 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:34 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:34 --> Email Class Initialized
DEBUG - 2024-08-26 15:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:34 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:34 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:34 --> Controller Class Initialized
INFO - 2024-08-26 15:19:34 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:34 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-08-26 15:19:34 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:19:34 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:34 --> Total execution time: 0.1210
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> Config Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:19:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> URI Class Initialized
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
INFO - 2024-08-26 15:19:36 --> Router Class Initialized
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Output Class Initialized
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
INFO - 2024-08-26 15:19:36 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
INFO - 2024-08-26 15:19:36 --> Input Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
INFO - 2024-08-26 15:19:36 --> Language Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Loader Class Initialized
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:36 --> Database Driver Class Initialized
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
INFO - 2024-08-26 15:19:36 --> Email Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.0762
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.0913
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.1187
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.1399
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.1645
INFO - 2024-08-26 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:36 --> Controller Class Initialized
INFO - 2024-08-26 15:19:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:36 --> Total execution time: 0.1877
INFO - 2024-08-26 15:19:47 --> Config Class Initialized
INFO - 2024-08-26 15:19:47 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:47 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:47 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:47 --> URI Class Initialized
INFO - 2024-08-26 15:19:47 --> Router Class Initialized
INFO - 2024-08-26 15:19:47 --> Output Class Initialized
INFO - 2024-08-26 15:19:47 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:47 --> Input Class Initialized
INFO - 2024-08-26 15:19:47 --> Language Class Initialized
INFO - 2024-08-26 15:19:47 --> Loader Class Initialized
INFO - 2024-08-26 15:19:47 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:47 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:47 --> Email Class Initialized
DEBUG - 2024-08-26 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:47 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:47 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:47 --> Controller Class Initialized
INFO - 2024-08-26 15:19:47 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:47 --> Config Class Initialized
INFO - 2024-08-26 15:19:47 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:19:47 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:19:47 --> Utf8 Class Initialized
INFO - 2024-08-26 15:19:47 --> URI Class Initialized
INFO - 2024-08-26 15:19:47 --> Router Class Initialized
INFO - 2024-08-26 15:19:47 --> Output Class Initialized
INFO - 2024-08-26 15:19:47 --> Security Class Initialized
DEBUG - 2024-08-26 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:19:47 --> Input Class Initialized
INFO - 2024-08-26 15:19:47 --> Language Class Initialized
INFO - 2024-08-26 15:19:47 --> Loader Class Initialized
INFO - 2024-08-26 15:19:47 --> Helper loaded: url_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: file_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: security_helper
INFO - 2024-08-26 15:19:47 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:19:47 --> Database Driver Class Initialized
INFO - 2024-08-26 15:19:47 --> Email Class Initialized
DEBUG - 2024-08-26 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:19:47 --> Helper loaded: form_helper
INFO - 2024-08-26 15:19:47 --> Form Validation Class Initialized
INFO - 2024-08-26 15:19:47 --> Controller Class Initialized
INFO - 2024-08-26 15:19:47 --> Model "User_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:19:47 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:19:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:19:47 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:19:47 --> Final output sent to browser
DEBUG - 2024-08-26 15:19:47 --> Total execution time: 0.0812
INFO - 2024-08-26 15:20:02 --> Config Class Initialized
INFO - 2024-08-26 15:20:02 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:02 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:02 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:02 --> URI Class Initialized
INFO - 2024-08-26 15:20:02 --> Router Class Initialized
INFO - 2024-08-26 15:20:02 --> Output Class Initialized
INFO - 2024-08-26 15:20:02 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:02 --> Input Class Initialized
INFO - 2024-08-26 15:20:02 --> Language Class Initialized
INFO - 2024-08-26 15:20:02 --> Loader Class Initialized
INFO - 2024-08-26 15:20:02 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:02 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:02 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:02 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:02 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:02 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:02 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:02 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:02 --> Controller Class Initialized
INFO - 2024-08-26 15:20:02 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:02 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-26 15:20:02 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:02 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:02 --> Total execution time: 0.0777
INFO - 2024-08-26 15:20:11 --> Config Class Initialized
INFO - 2024-08-26 15:20:11 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:11 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:11 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:11 --> URI Class Initialized
INFO - 2024-08-26 15:20:11 --> Router Class Initialized
INFO - 2024-08-26 15:20:11 --> Output Class Initialized
INFO - 2024-08-26 15:20:11 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:11 --> Input Class Initialized
INFO - 2024-08-26 15:20:11 --> Language Class Initialized
INFO - 2024-08-26 15:20:11 --> Loader Class Initialized
INFO - 2024-08-26 15:20:11 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:11 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:11 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:11 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:11 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:11 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:11 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:11 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:11 --> Controller Class Initialized
INFO - 2024-08-26 15:20:11 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:11 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:11 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:20:11 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:11 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:11 --> Total execution time: 0.0782
INFO - 2024-08-26 15:20:14 --> Config Class Initialized
INFO - 2024-08-26 15:20:14 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:14 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:14 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:14 --> URI Class Initialized
INFO - 2024-08-26 15:20:14 --> Router Class Initialized
INFO - 2024-08-26 15:20:14 --> Output Class Initialized
INFO - 2024-08-26 15:20:14 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:14 --> Input Class Initialized
INFO - 2024-08-26 15:20:14 --> Language Class Initialized
INFO - 2024-08-26 15:20:14 --> Loader Class Initialized
INFO - 2024-08-26 15:20:14 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:14 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:14 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:14 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:14 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:14 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:14 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:14 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:14 --> Controller Class Initialized
INFO - 2024-08-26 15:20:14 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:14 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:14 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-08-26 15:20:14 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:14 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:14 --> Total execution time: 0.0745
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:16 --> Config Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:16 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
DEBUG - 2024-08-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
INFO - 2024-08-26 15:20:16 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> URI Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> Router Class Initialized
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> Output Class Initialized
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
INFO - 2024-08-26 15:20:16 --> Security Class Initialized
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
INFO - 2024-08-26 15:20:16 --> Input Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Language Class Initialized
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Loader Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:16 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:16 --> Database Driver Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:16 --> Email Class Initialized
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.0661
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.0882
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.1121
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.1364
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.1618
INFO - 2024-08-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:16 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:16 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:16 --> Controller Class Initialized
INFO - 2024-08-26 15:20:16 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:16 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:16 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:16 --> Total execution time: 0.1845
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Config Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
INFO - 2024-08-26 15:20:18 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:18 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
INFO - 2024-08-26 15:20:18 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> URI Class Initialized
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> Router Class Initialized
INFO - 2024-08-26 15:20:18 --> Output Class Initialized
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Security Class Initialized
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
DEBUG - 2024-08-26 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:18 --> Input Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Language Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Loader Class Initialized
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Helper loaded: file_helper
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:18 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:18 --> Helper loaded: wpu_helper
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Email Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.0704
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.0972
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.1182
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.1389
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.1613
INFO - 2024-08-26 15:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:18 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:18 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:18 --> Controller Class Initialized
INFO - 2024-08-26 15:20:18 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:18 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:18 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:18 --> Total execution time: 0.1834
INFO - 2024-08-26 15:20:19 --> Config Class Initialized
INFO - 2024-08-26 15:20:19 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:19 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:19 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:19 --> URI Class Initialized
INFO - 2024-08-26 15:20:19 --> Router Class Initialized
INFO - 2024-08-26 15:20:19 --> Output Class Initialized
INFO - 2024-08-26 15:20:19 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:19 --> Input Class Initialized
INFO - 2024-08-26 15:20:19 --> Language Class Initialized
INFO - 2024-08-26 15:20:19 --> Loader Class Initialized
INFO - 2024-08-26 15:20:19 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:19 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:19 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:19 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:19 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:19 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:19 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:19 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:19 --> Controller Class Initialized
INFO - 2024-08-26 15:20:19 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:19 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:19 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:20:19 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:19 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:19 --> Total execution time: 0.0784
INFO - 2024-08-26 15:20:21 --> Config Class Initialized
INFO - 2024-08-26 15:20:21 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:21 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:21 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:21 --> URI Class Initialized
INFO - 2024-08-26 15:20:21 --> Router Class Initialized
INFO - 2024-08-26 15:20:21 --> Output Class Initialized
INFO - 2024-08-26 15:20:21 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:21 --> Input Class Initialized
INFO - 2024-08-26 15:20:21 --> Language Class Initialized
INFO - 2024-08-26 15:20:21 --> Loader Class Initialized
INFO - 2024-08-26 15:20:21 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:21 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:21 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:21 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:21 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:21 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:21 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:21 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:21 --> Controller Class Initialized
INFO - 2024-08-26 15:20:21 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:21 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-08-26 15:20:21 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:21 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:21 --> Total execution time: 0.0703
INFO - 2024-08-26 15:20:24 --> Config Class Initialized
INFO - 2024-08-26 15:20:24 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:24 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:24 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:24 --> URI Class Initialized
INFO - 2024-08-26 15:20:24 --> Router Class Initialized
INFO - 2024-08-26 15:20:24 --> Output Class Initialized
INFO - 2024-08-26 15:20:24 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:24 --> Input Class Initialized
INFO - 2024-08-26 15:20:24 --> Language Class Initialized
INFO - 2024-08-26 15:20:24 --> Loader Class Initialized
INFO - 2024-08-26 15:20:24 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:24 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:24 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:24 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:24 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:24 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:24 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:24 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:24 --> Controller Class Initialized
INFO - 2024-08-26 15:20:24 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:20:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:24 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:24 --> Total execution time: 0.0892
INFO - 2024-08-26 15:20:29 --> Config Class Initialized
INFO - 2024-08-26 15:20:29 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:29 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:29 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:29 --> URI Class Initialized
INFO - 2024-08-26 15:20:29 --> Router Class Initialized
INFO - 2024-08-26 15:20:29 --> Output Class Initialized
INFO - 2024-08-26 15:20:29 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:29 --> Input Class Initialized
INFO - 2024-08-26 15:20:29 --> Language Class Initialized
INFO - 2024-08-26 15:20:29 --> Loader Class Initialized
INFO - 2024-08-26 15:20:29 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:29 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:29 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:29 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:29 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:29 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:29 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:29 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:29 --> Controller Class Initialized
INFO - 2024-08-26 15:20:29 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:29 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:29 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/e_pesanan.php
INFO - 2024-08-26 15:20:29 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:29 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:29 --> Total execution time: 0.0791
INFO - 2024-08-26 15:20:50 --> Config Class Initialized
INFO - 2024-08-26 15:20:50 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:50 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:50 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:50 --> URI Class Initialized
INFO - 2024-08-26 15:20:50 --> Router Class Initialized
INFO - 2024-08-26 15:20:50 --> Output Class Initialized
INFO - 2024-08-26 15:20:50 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:50 --> Input Class Initialized
INFO - 2024-08-26 15:20:50 --> Language Class Initialized
INFO - 2024-08-26 15:20:50 --> Loader Class Initialized
INFO - 2024-08-26 15:20:50 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:50 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:50 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:50 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:50 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:50 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:50 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:50 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:50 --> Controller Class Initialized
INFO - 2024-08-26 15:20:50 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:50 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:50 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/permintaan.php
INFO - 2024-08-26 15:20:50 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:50 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:50 --> Total execution time: 0.0748
INFO - 2024-08-26 15:20:52 --> Config Class Initialized
INFO - 2024-08-26 15:20:52 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:20:53 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:20:53 --> Utf8 Class Initialized
INFO - 2024-08-26 15:20:53 --> URI Class Initialized
INFO - 2024-08-26 15:20:53 --> Router Class Initialized
INFO - 2024-08-26 15:20:53 --> Output Class Initialized
INFO - 2024-08-26 15:20:53 --> Security Class Initialized
DEBUG - 2024-08-26 15:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:20:53 --> Input Class Initialized
INFO - 2024-08-26 15:20:53 --> Language Class Initialized
INFO - 2024-08-26 15:20:53 --> Loader Class Initialized
INFO - 2024-08-26 15:20:53 --> Helper loaded: url_helper
INFO - 2024-08-26 15:20:53 --> Helper loaded: file_helper
INFO - 2024-08-26 15:20:53 --> Helper loaded: security_helper
INFO - 2024-08-26 15:20:53 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:20:53 --> Database Driver Class Initialized
INFO - 2024-08-26 15:20:53 --> Email Class Initialized
DEBUG - 2024-08-26 15:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:20:53 --> Helper loaded: form_helper
INFO - 2024-08-26 15:20:53 --> Form Validation Class Initialized
INFO - 2024-08-26 15:20:53 --> Controller Class Initialized
INFO - 2024-08-26 15:20:53 --> Model "User_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:20:53 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:20:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:20:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:20:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:20:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:20:53 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:20:53 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:20:53 --> Final output sent to browser
DEBUG - 2024-08-26 15:20:53 --> Total execution time: 0.0860
INFO - 2024-08-26 15:21:33 --> Config Class Initialized
INFO - 2024-08-26 15:21:33 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:21:33 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:33 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:33 --> URI Class Initialized
INFO - 2024-08-26 15:21:33 --> Router Class Initialized
INFO - 2024-08-26 15:21:33 --> Output Class Initialized
INFO - 2024-08-26 15:21:33 --> Security Class Initialized
DEBUG - 2024-08-26 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:33 --> Input Class Initialized
INFO - 2024-08-26 15:21:33 --> Language Class Initialized
INFO - 2024-08-26 15:21:33 --> Loader Class Initialized
INFO - 2024-08-26 15:21:33 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:33 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:33 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:33 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:33 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:33 --> Email Class Initialized
DEBUG - 2024-08-26 15:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:33 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:33 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:33 --> Controller Class Initialized
INFO - 2024-08-26 15:21:33 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:33 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:21:33 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:21:33 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:33 --> Total execution time: 0.0741
INFO - 2024-08-26 15:21:35 --> Config Class Initialized
INFO - 2024-08-26 15:21:35 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:21:35 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:35 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:35 --> URI Class Initialized
INFO - 2024-08-26 15:21:35 --> Router Class Initialized
INFO - 2024-08-26 15:21:35 --> Output Class Initialized
INFO - 2024-08-26 15:21:35 --> Security Class Initialized
DEBUG - 2024-08-26 15:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:35 --> Input Class Initialized
INFO - 2024-08-26 15:21:35 --> Language Class Initialized
INFO - 2024-08-26 15:21:35 --> Loader Class Initialized
INFO - 2024-08-26 15:21:35 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:35 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:35 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:35 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:35 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:35 --> Email Class Initialized
DEBUG - 2024-08-26 15:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:35 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:35 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:35 --> Controller Class Initialized
INFO - 2024-08-26 15:21:35 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:35 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/t_pesanan.php
INFO - 2024-08-26 15:21:35 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:21:35 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:35 --> Total execution time: 0.1197
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:36 --> Config Class Initialized
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
INFO - 2024-08-26 15:21:36 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
DEBUG - 2024-08-26 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:36 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
INFO - 2024-08-26 15:21:36 --> URI Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Router Class Initialized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
INFO - 2024-08-26 15:21:36 --> Output Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
INFO - 2024-08-26 15:21:36 --> Security Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Input Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Language Class Initialized
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Loader Class Initialized
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
INFO - 2024-08-26 15:21:36 --> Email Class Initialized
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.0716
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.0902
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.1115
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.1317
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.1544
INFO - 2024-08-26 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:36 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:36 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:36 --> Controller Class Initialized
INFO - 2024-08-26 15:21:36 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:36 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:36 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:36 --> Total execution time: 0.1779
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Config Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
INFO - 2024-08-26 15:21:39 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
DEBUG - 2024-08-26 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:21:39 --> Utf8 Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
INFO - 2024-08-26 15:21:39 --> URI Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> Router Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Output Class Initialized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
INFO - 2024-08-26 15:21:39 --> Security Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
INFO - 2024-08-26 15:21:39 --> Input Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
INFO - 2024-08-26 15:21:39 --> Language Class Initialized
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Loader Class Initialized
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: url_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: file_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: security_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
INFO - 2024-08-26 15:21:39 --> Database Driver Class Initialized
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.0694
INFO - 2024-08-26 15:21:39 --> Email Class Initialized
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
DEBUG - 2024-08-26 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.0908
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.1125
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.1349
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.1569
INFO - 2024-08-26 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:21:39 --> Helper loaded: form_helper
INFO - 2024-08-26 15:21:39 --> Form Validation Class Initialized
INFO - 2024-08-26 15:21:39 --> Controller Class Initialized
INFO - 2024-08-26 15:21:39 --> Model "User_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:21:39 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:21:39 --> Final output sent to browser
DEBUG - 2024-08-26 15:21:39 --> Total execution time: 0.1790
INFO - 2024-08-26 15:22:25 --> Config Class Initialized
INFO - 2024-08-26 15:22:25 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:22:25 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:22:25 --> Utf8 Class Initialized
INFO - 2024-08-26 15:22:25 --> URI Class Initialized
INFO - 2024-08-26 15:22:25 --> Router Class Initialized
INFO - 2024-08-26 15:22:25 --> Output Class Initialized
INFO - 2024-08-26 15:22:25 --> Security Class Initialized
DEBUG - 2024-08-26 15:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:22:25 --> Input Class Initialized
INFO - 2024-08-26 15:22:25 --> Language Class Initialized
INFO - 2024-08-26 15:22:25 --> Loader Class Initialized
INFO - 2024-08-26 15:22:25 --> Helper loaded: url_helper
INFO - 2024-08-26 15:22:25 --> Helper loaded: file_helper
INFO - 2024-08-26 15:22:25 --> Helper loaded: security_helper
INFO - 2024-08-26 15:22:25 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:22:25 --> Database Driver Class Initialized
INFO - 2024-08-26 15:22:25 --> Email Class Initialized
DEBUG - 2024-08-26 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:22:25 --> Helper loaded: form_helper
INFO - 2024-08-26 15:22:25 --> Form Validation Class Initialized
INFO - 2024-08-26 15:22:25 --> Controller Class Initialized
INFO - 2024-08-26 15:22:25 --> Model "User_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:22:25 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:22:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:22:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:22:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:22:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:22:25 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/faktur.php
INFO - 2024-08-26 15:22:25 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:22:25 --> Final output sent to browser
DEBUG - 2024-08-26 15:22:25 --> Total execution time: 0.1255
INFO - 2024-08-26 15:22:28 --> Config Class Initialized
INFO - 2024-08-26 15:22:28 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:22:28 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:22:28 --> Utf8 Class Initialized
INFO - 2024-08-26 15:22:28 --> URI Class Initialized
INFO - 2024-08-26 15:22:28 --> Router Class Initialized
INFO - 2024-08-26 15:22:28 --> Output Class Initialized
INFO - 2024-08-26 15:22:28 --> Security Class Initialized
DEBUG - 2024-08-26 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:22:28 --> Input Class Initialized
INFO - 2024-08-26 15:22:28 --> Language Class Initialized
INFO - 2024-08-26 15:22:28 --> Loader Class Initialized
INFO - 2024-08-26 15:22:28 --> Helper loaded: url_helper
INFO - 2024-08-26 15:22:28 --> Helper loaded: file_helper
INFO - 2024-08-26 15:22:28 --> Helper loaded: security_helper
INFO - 2024-08-26 15:22:28 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:22:28 --> Database Driver Class Initialized
INFO - 2024-08-26 15:22:28 --> Email Class Initialized
DEBUG - 2024-08-26 15:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:22:28 --> Helper loaded: form_helper
INFO - 2024-08-26 15:22:28 --> Form Validation Class Initialized
INFO - 2024-08-26 15:22:28 --> Controller Class Initialized
INFO - 2024-08-26 15:22:28 --> Model "User_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:22:28 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:22:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:22:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:22:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:22:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:22:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:22:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:22:28 --> Final output sent to browser
DEBUG - 2024-08-26 15:22:28 --> Total execution time: 0.0842
INFO - 2024-08-26 15:29:27 --> Config Class Initialized
INFO - 2024-08-26 15:29:27 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:29:27 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:29:27 --> Utf8 Class Initialized
INFO - 2024-08-26 15:29:27 --> URI Class Initialized
INFO - 2024-08-26 15:29:27 --> Router Class Initialized
INFO - 2024-08-26 15:29:27 --> Output Class Initialized
INFO - 2024-08-26 15:29:27 --> Security Class Initialized
DEBUG - 2024-08-26 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:29:28 --> Input Class Initialized
INFO - 2024-08-26 15:29:28 --> Language Class Initialized
INFO - 2024-08-26 15:29:28 --> Loader Class Initialized
INFO - 2024-08-26 15:29:28 --> Helper loaded: url_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: file_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: security_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:29:28 --> Database Driver Class Initialized
INFO - 2024-08-26 15:29:28 --> Email Class Initialized
DEBUG - 2024-08-26 15:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:29:28 --> Helper loaded: form_helper
INFO - 2024-08-26 15:29:28 --> Form Validation Class Initialized
INFO - 2024-08-26 15:29:28 --> Controller Class Initialized
INFO - 2024-08-26 15:29:28 --> Model "User_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/pesanan.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:29:28 --> Final output sent to browser
DEBUG - 2024-08-26 15:29:28 --> Total execution time: 0.1224
INFO - 2024-08-26 15:29:28 --> Config Class Initialized
INFO - 2024-08-26 15:29:28 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:29:28 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:29:28 --> Utf8 Class Initialized
INFO - 2024-08-26 15:29:28 --> URI Class Initialized
INFO - 2024-08-26 15:29:28 --> Router Class Initialized
INFO - 2024-08-26 15:29:28 --> Output Class Initialized
INFO - 2024-08-26 15:29:28 --> Security Class Initialized
DEBUG - 2024-08-26 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:29:28 --> Input Class Initialized
INFO - 2024-08-26 15:29:28 --> Language Class Initialized
INFO - 2024-08-26 15:29:28 --> Loader Class Initialized
INFO - 2024-08-26 15:29:28 --> Helper loaded: url_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: file_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: security_helper
INFO - 2024-08-26 15:29:28 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:29:28 --> Database Driver Class Initialized
INFO - 2024-08-26 15:29:28 --> Email Class Initialized
DEBUG - 2024-08-26 15:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:29:28 --> Helper loaded: form_helper
INFO - 2024-08-26 15:29:28 --> Form Validation Class Initialized
INFO - 2024-08-26 15:29:28 --> Controller Class Initialized
INFO - 2024-08-26 15:29:28 --> Model "User_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:29:28 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/inventaris.php
INFO - 2024-08-26 15:29:28 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:29:28 --> Final output sent to browser
DEBUG - 2024-08-26 15:29:28 --> Total execution time: 0.0852
INFO - 2024-08-26 15:29:31 --> Config Class Initialized
INFO - 2024-08-26 15:29:31 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:29:31 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:29:31 --> Utf8 Class Initialized
INFO - 2024-08-26 15:29:31 --> URI Class Initialized
INFO - 2024-08-26 15:29:31 --> Router Class Initialized
INFO - 2024-08-26 15:29:31 --> Output Class Initialized
INFO - 2024-08-26 15:29:31 --> Security Class Initialized
DEBUG - 2024-08-26 15:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:29:31 --> Input Class Initialized
INFO - 2024-08-26 15:29:31 --> Language Class Initialized
INFO - 2024-08-26 15:29:31 --> Loader Class Initialized
INFO - 2024-08-26 15:29:31 --> Helper loaded: url_helper
INFO - 2024-08-26 15:29:31 --> Helper loaded: file_helper
INFO - 2024-08-26 15:29:31 --> Helper loaded: security_helper
INFO - 2024-08-26 15:29:31 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:29:31 --> Database Driver Class Initialized
INFO - 2024-08-26 15:29:31 --> Email Class Initialized
DEBUG - 2024-08-26 15:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:29:31 --> Helper loaded: form_helper
INFO - 2024-08-26 15:29:31 --> Form Validation Class Initialized
INFO - 2024-08-26 15:29:31 --> Controller Class Initialized
INFO - 2024-08-26 15:29:31 --> Model "User_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Faktur_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Supplier_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Jenis_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Barang_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 15:29:31 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 15:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:29:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 15:29:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 15:29:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 15:29:31 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/barang.php
INFO - 2024-08-26 15:29:31 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 15:29:31 --> Final output sent to browser
DEBUG - 2024-08-26 15:29:31 --> Total execution time: 0.0925
INFO - 2024-08-26 15:31:43 --> Config Class Initialized
INFO - 2024-08-26 15:31:43 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:31:43 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:31:43 --> Utf8 Class Initialized
INFO - 2024-08-26 15:31:43 --> URI Class Initialized
INFO - 2024-08-26 15:31:43 --> Router Class Initialized
INFO - 2024-08-26 15:31:43 --> Output Class Initialized
INFO - 2024-08-26 15:31:43 --> Security Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:31:43 --> Input Class Initialized
INFO - 2024-08-26 15:31:43 --> Language Class Initialized
INFO - 2024-08-26 15:31:43 --> Loader Class Initialized
INFO - 2024-08-26 15:31:43 --> Helper loaded: url_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: file_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: security_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:31:43 --> Database Driver Class Initialized
INFO - 2024-08-26 15:31:43 --> Email Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:31:43 --> Helper loaded: form_helper
INFO - 2024-08-26 15:31:43 --> Form Validation Class Initialized
INFO - 2024-08-26 15:31:43 --> Controller Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:31:43 --> Config Class Initialized
INFO - 2024-08-26 15:31:43 --> Hooks Class Initialized
DEBUG - 2024-08-26 15:31:43 --> UTF-8 Support Enabled
INFO - 2024-08-26 15:31:43 --> Utf8 Class Initialized
INFO - 2024-08-26 15:31:43 --> URI Class Initialized
INFO - 2024-08-26 15:31:43 --> Router Class Initialized
INFO - 2024-08-26 15:31:43 --> Output Class Initialized
INFO - 2024-08-26 15:31:43 --> Security Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 15:31:43 --> Input Class Initialized
INFO - 2024-08-26 15:31:43 --> Language Class Initialized
INFO - 2024-08-26 15:31:43 --> Loader Class Initialized
INFO - 2024-08-26 15:31:43 --> Helper loaded: url_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: file_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: security_helper
INFO - 2024-08-26 15:31:43 --> Helper loaded: wpu_helper
INFO - 2024-08-26 15:31:43 --> Database Driver Class Initialized
INFO - 2024-08-26 15:31:43 --> Email Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 15:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 15:31:43 --> Helper loaded: form_helper
INFO - 2024-08-26 15:31:43 --> Form Validation Class Initialized
INFO - 2024-08-26 15:31:43 --> Controller Class Initialized
DEBUG - 2024-08-26 15:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 15:31:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-26 15:31:43 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-26 15:31:43 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-26 15:31:43 --> Final output sent to browser
DEBUG - 2024-08-26 15:31:43 --> Total execution time: 0.0524
INFO - 2024-08-26 16:12:17 --> Config Class Initialized
INFO - 2024-08-26 16:12:17 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:12:17 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:12:17 --> Utf8 Class Initialized
INFO - 2024-08-26 16:12:17 --> URI Class Initialized
DEBUG - 2024-08-26 16:12:17 --> No URI present. Default controller set.
INFO - 2024-08-26 16:12:17 --> Router Class Initialized
INFO - 2024-08-26 16:12:17 --> Output Class Initialized
INFO - 2024-08-26 16:12:17 --> Security Class Initialized
DEBUG - 2024-08-26 16:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:12:17 --> Input Class Initialized
INFO - 2024-08-26 16:12:17 --> Language Class Initialized
INFO - 2024-08-26 16:12:17 --> Loader Class Initialized
INFO - 2024-08-26 16:12:17 --> Helper loaded: url_helper
INFO - 2024-08-26 16:12:17 --> Helper loaded: file_helper
INFO - 2024-08-26 16:12:17 --> Helper loaded: security_helper
INFO - 2024-08-26 16:12:17 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:12:17 --> Database Driver Class Initialized
INFO - 2024-08-26 16:12:17 --> Email Class Initialized
DEBUG - 2024-08-26 16:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:12:17 --> Helper loaded: form_helper
INFO - 2024-08-26 16:12:17 --> Form Validation Class Initialized
INFO - 2024-08-26 16:12:17 --> Controller Class Initialized
DEBUG - 2024-08-26 16:12:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 16:12:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_header.php
INFO - 2024-08-26 16:12:17 --> File loaded: C:\xampp\htdocs\simba\application\views\auth/login.php
INFO - 2024-08-26 16:12:17 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/auth_footer.php
INFO - 2024-08-26 16:12:17 --> Final output sent to browser
DEBUG - 2024-08-26 16:12:17 --> Total execution time: 0.0658
INFO - 2024-08-26 16:12:24 --> Config Class Initialized
INFO - 2024-08-26 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:12:24 --> Utf8 Class Initialized
INFO - 2024-08-26 16:12:24 --> URI Class Initialized
INFO - 2024-08-26 16:12:24 --> Router Class Initialized
INFO - 2024-08-26 16:12:24 --> Output Class Initialized
INFO - 2024-08-26 16:12:24 --> Security Class Initialized
DEBUG - 2024-08-26 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:12:24 --> Input Class Initialized
INFO - 2024-08-26 16:12:24 --> Language Class Initialized
INFO - 2024-08-26 16:12:24 --> Loader Class Initialized
INFO - 2024-08-26 16:12:24 --> Helper loaded: url_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: file_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: security_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:12:24 --> Database Driver Class Initialized
INFO - 2024-08-26 16:12:24 --> Email Class Initialized
DEBUG - 2024-08-26 16:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:12:24 --> Helper loaded: form_helper
INFO - 2024-08-26 16:12:24 --> Form Validation Class Initialized
INFO - 2024-08-26 16:12:24 --> Controller Class Initialized
DEBUG - 2024-08-26 16:12:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 16:12:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-26 16:12:24 --> Config Class Initialized
INFO - 2024-08-26 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:12:24 --> Utf8 Class Initialized
INFO - 2024-08-26 16:12:24 --> URI Class Initialized
INFO - 2024-08-26 16:12:24 --> Router Class Initialized
INFO - 2024-08-26 16:12:24 --> Output Class Initialized
INFO - 2024-08-26 16:12:24 --> Security Class Initialized
DEBUG - 2024-08-26 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:12:24 --> Input Class Initialized
INFO - 2024-08-26 16:12:24 --> Language Class Initialized
INFO - 2024-08-26 16:12:24 --> Loader Class Initialized
INFO - 2024-08-26 16:12:24 --> Helper loaded: url_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: file_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: security_helper
INFO - 2024-08-26 16:12:24 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:12:24 --> Database Driver Class Initialized
INFO - 2024-08-26 16:12:24 --> Email Class Initialized
DEBUG - 2024-08-26 16:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:12:24 --> Helper loaded: form_helper
INFO - 2024-08-26 16:12:24 --> Form Validation Class Initialized
INFO - 2024-08-26 16:12:24 --> Controller Class Initialized
INFO - 2024-08-26 16:12:24 --> Model "User_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Permintaan_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Faktur_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Pesanan_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Supplier_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Detailfaktur_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Jenis_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Inventaris_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Barang_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Pemeliharaan_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Perbaikan_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Penghapusan_model" initialized
INFO - 2024-08-26 16:12:24 --> Model "Mutasi_model" initialized
DEBUG - 2024-08-26 16:12:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-08-26 16:12:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:12:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:12:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:12:24 --> File loaded: C:\xampp\htdocs\simba\application\views\admin/dashboard.php
INFO - 2024-08-26 16:12:24 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:12:24 --> Final output sent to browser
DEBUG - 2024-08-26 16:12:24 --> Total execution time: 0.0845
INFO - 2024-08-26 16:12:31 --> Config Class Initialized
INFO - 2024-08-26 16:12:31 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:12:31 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:12:31 --> Utf8 Class Initialized
INFO - 2024-08-26 16:12:31 --> URI Class Initialized
INFO - 2024-08-26 16:12:31 --> Router Class Initialized
INFO - 2024-08-26 16:12:31 --> Output Class Initialized
INFO - 2024-08-26 16:12:31 --> Security Class Initialized
DEBUG - 2024-08-26 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:12:31 --> Input Class Initialized
INFO - 2024-08-26 16:12:31 --> Language Class Initialized
INFO - 2024-08-26 16:12:31 --> Loader Class Initialized
INFO - 2024-08-26 16:12:31 --> Helper loaded: url_helper
INFO - 2024-08-26 16:12:31 --> Helper loaded: file_helper
INFO - 2024-08-26 16:12:31 --> Helper loaded: security_helper
INFO - 2024-08-26 16:12:31 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:12:31 --> Database Driver Class Initialized
INFO - 2024-08-26 16:12:32 --> Email Class Initialized
DEBUG - 2024-08-26 16:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:12:32 --> Helper loaded: form_helper
INFO - 2024-08-26 16:12:32 --> Form Validation Class Initialized
INFO - 2024-08-26 16:12:32 --> Controller Class Initialized
INFO - 2024-08-26 16:12:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:12:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:12:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:12:32 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/index.php
INFO - 2024-08-26 16:12:32 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:12:32 --> Final output sent to browser
DEBUG - 2024-08-26 16:12:32 --> Total execution time: 0.0913
INFO - 2024-08-26 16:12:52 --> Config Class Initialized
INFO - 2024-08-26 16:12:52 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:12:52 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:12:52 --> Utf8 Class Initialized
INFO - 2024-08-26 16:12:52 --> URI Class Initialized
INFO - 2024-08-26 16:12:52 --> Router Class Initialized
INFO - 2024-08-26 16:12:52 --> Output Class Initialized
INFO - 2024-08-26 16:12:52 --> Security Class Initialized
DEBUG - 2024-08-26 16:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:12:52 --> Input Class Initialized
INFO - 2024-08-26 16:12:52 --> Language Class Initialized
INFO - 2024-08-26 16:12:52 --> Loader Class Initialized
INFO - 2024-08-26 16:12:52 --> Helper loaded: url_helper
INFO - 2024-08-26 16:12:52 --> Helper loaded: file_helper
INFO - 2024-08-26 16:12:52 --> Helper loaded: security_helper
INFO - 2024-08-26 16:12:52 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:12:52 --> Database Driver Class Initialized
INFO - 2024-08-26 16:12:52 --> Email Class Initialized
DEBUG - 2024-08-26 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:12:52 --> Helper loaded: form_helper
INFO - 2024-08-26 16:12:52 --> Form Validation Class Initialized
INFO - 2024-08-26 16:12:52 --> Controller Class Initialized
INFO - 2024-08-26 16:12:52 --> Model "Menu_model" initialized
INFO - 2024-08-26 16:12:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:12:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:12:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:12:52 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-08-26 16:12:52 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:12:52 --> Final output sent to browser
DEBUG - 2024-08-26 16:12:52 --> Total execution time: 0.0929
INFO - 2024-08-26 16:13:27 --> Config Class Initialized
INFO - 2024-08-26 16:13:27 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:27 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:27 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:27 --> URI Class Initialized
INFO - 2024-08-26 16:13:27 --> Router Class Initialized
INFO - 2024-08-26 16:13:27 --> Output Class Initialized
INFO - 2024-08-26 16:13:27 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:27 --> Input Class Initialized
INFO - 2024-08-26 16:13:27 --> Language Class Initialized
INFO - 2024-08-26 16:13:27 --> Loader Class Initialized
INFO - 2024-08-26 16:13:27 --> Helper loaded: url_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: file_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: security_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:13:27 --> Database Driver Class Initialized
INFO - 2024-08-26 16:13:27 --> Email Class Initialized
DEBUG - 2024-08-26 16:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:13:27 --> Helper loaded: form_helper
INFO - 2024-08-26 16:13:27 --> Form Validation Class Initialized
INFO - 2024-08-26 16:13:27 --> Controller Class Initialized
INFO - 2024-08-26 16:13:27 --> Model "Menu_model" initialized
INFO - 2024-08-26 16:13:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-08-26 16:13:27 --> Config Class Initialized
INFO - 2024-08-26 16:13:27 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:27 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:27 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:27 --> URI Class Initialized
INFO - 2024-08-26 16:13:27 --> Router Class Initialized
INFO - 2024-08-26 16:13:27 --> Output Class Initialized
INFO - 2024-08-26 16:13:27 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:27 --> Input Class Initialized
INFO - 2024-08-26 16:13:27 --> Language Class Initialized
INFO - 2024-08-26 16:13:27 --> Loader Class Initialized
INFO - 2024-08-26 16:13:27 --> Helper loaded: url_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: file_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: security_helper
INFO - 2024-08-26 16:13:27 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:13:27 --> Database Driver Class Initialized
INFO - 2024-08-26 16:13:27 --> Email Class Initialized
DEBUG - 2024-08-26 16:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:13:27 --> Helper loaded: form_helper
INFO - 2024-08-26 16:13:27 --> Form Validation Class Initialized
INFO - 2024-08-26 16:13:27 --> Controller Class Initialized
INFO - 2024-08-26 16:13:27 --> Model "Menu_model" initialized
INFO - 2024-08-26 16:13:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:13:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:13:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:13:27 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-08-26 16:13:27 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:13:27 --> Final output sent to browser
DEBUG - 2024-08-26 16:13:27 --> Total execution time: 0.0610
INFO - 2024-08-26 16:13:32 --> Config Class Initialized
INFO - 2024-08-26 16:13:32 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:32 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:32 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:32 --> URI Class Initialized
INFO - 2024-08-26 16:13:32 --> Router Class Initialized
INFO - 2024-08-26 16:13:32 --> Output Class Initialized
INFO - 2024-08-26 16:13:32 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:32 --> Input Class Initialized
INFO - 2024-08-26 16:13:32 --> Language Class Initialized
ERROR - 2024-08-26 16:13:32 --> 404 Page Not Found: Data/Dosen
INFO - 2024-08-26 16:13:36 --> Config Class Initialized
INFO - 2024-08-26 16:13:36 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:36 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:36 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:36 --> URI Class Initialized
INFO - 2024-08-26 16:13:36 --> Router Class Initialized
INFO - 2024-08-26 16:13:36 --> Output Class Initialized
INFO - 2024-08-26 16:13:36 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:36 --> Input Class Initialized
INFO - 2024-08-26 16:13:36 --> Language Class Initialized
INFO - 2024-08-26 16:13:36 --> Loader Class Initialized
INFO - 2024-08-26 16:13:36 --> Helper loaded: url_helper
INFO - 2024-08-26 16:13:36 --> Helper loaded: file_helper
INFO - 2024-08-26 16:13:36 --> Helper loaded: security_helper
INFO - 2024-08-26 16:13:36 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:13:36 --> Database Driver Class Initialized
INFO - 2024-08-26 16:13:36 --> Email Class Initialized
DEBUG - 2024-08-26 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:13:36 --> Helper loaded: form_helper
INFO - 2024-08-26 16:13:36 --> Form Validation Class Initialized
INFO - 2024-08-26 16:13:36 --> Controller Class Initialized
INFO - 2024-08-26 16:13:36 --> Model "Menu_model" initialized
INFO - 2024-08-26 16:13:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:13:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:13:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:13:36 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-08-26 16:13:36 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:13:36 --> Final output sent to browser
DEBUG - 2024-08-26 16:13:36 --> Total execution time: 0.0520
INFO - 2024-08-26 16:13:39 --> Config Class Initialized
INFO - 2024-08-26 16:13:39 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:39 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:39 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:39 --> URI Class Initialized
INFO - 2024-08-26 16:13:39 --> Router Class Initialized
INFO - 2024-08-26 16:13:39 --> Output Class Initialized
INFO - 2024-08-26 16:13:39 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:39 --> Input Class Initialized
INFO - 2024-08-26 16:13:39 --> Language Class Initialized
ERROR - 2024-08-26 16:13:39 --> 404 Page Not Found: Data/Dosen
INFO - 2024-08-26 16:13:41 --> Config Class Initialized
INFO - 2024-08-26 16:13:41 --> Hooks Class Initialized
DEBUG - 2024-08-26 16:13:41 --> UTF-8 Support Enabled
INFO - 2024-08-26 16:13:41 --> Utf8 Class Initialized
INFO - 2024-08-26 16:13:41 --> URI Class Initialized
INFO - 2024-08-26 16:13:41 --> Router Class Initialized
INFO - 2024-08-26 16:13:41 --> Output Class Initialized
INFO - 2024-08-26 16:13:41 --> Security Class Initialized
DEBUG - 2024-08-26 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 16:13:41 --> Input Class Initialized
INFO - 2024-08-26 16:13:41 --> Language Class Initialized
INFO - 2024-08-26 16:13:41 --> Loader Class Initialized
INFO - 2024-08-26 16:13:41 --> Helper loaded: url_helper
INFO - 2024-08-26 16:13:41 --> Helper loaded: file_helper
INFO - 2024-08-26 16:13:41 --> Helper loaded: security_helper
INFO - 2024-08-26 16:13:41 --> Helper loaded: wpu_helper
INFO - 2024-08-26 16:13:41 --> Database Driver Class Initialized
INFO - 2024-08-26 16:13:41 --> Email Class Initialized
DEBUG - 2024-08-26 16:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-26 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 16:13:41 --> Helper loaded: form_helper
INFO - 2024-08-26 16:13:41 --> Form Validation Class Initialized
INFO - 2024-08-26 16:13:41 --> Controller Class Initialized
INFO - 2024-08-26 16:13:41 --> Model "Menu_model" initialized
INFO - 2024-08-26 16:13:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/header.php
INFO - 2024-08-26 16:13:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/sidebar.php
INFO - 2024-08-26 16:13:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/topbar.php
INFO - 2024-08-26 16:13:41 --> File loaded: C:\xampp\htdocs\simba\application\views\menu/submenu.php
INFO - 2024-08-26 16:13:41 --> File loaded: C:\xampp\htdocs\simba\application\views\templates/footer.php
INFO - 2024-08-26 16:13:41 --> Final output sent to browser
DEBUG - 2024-08-26 16:13:41 --> Total execution time: 0.0678
