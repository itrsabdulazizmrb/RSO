<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-09 04:08:04 --> Config Class Initialized
INFO - 2024-12-09 04:08:04 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:04 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:04 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:04 --> URI Class Initialized
DEBUG - 2024-12-09 04:08:04 --> No URI present. Default controller set.
INFO - 2024-12-09 04:08:04 --> Router Class Initialized
INFO - 2024-12-09 04:08:04 --> Output Class Initialized
INFO - 2024-12-09 04:08:04 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:04 --> Input Class Initialized
INFO - 2024-12-09 04:08:04 --> Language Class Initialized
INFO - 2024-12-09 04:08:04 --> Loader Class Initialized
INFO - 2024-12-09 04:08:04 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:04 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:04 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:04 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:04 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:04 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:04 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:04 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:04 --> Controller Class Initialized
DEBUG - 2024-12-09 04:08:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-09 04:08:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-09 04:08:04 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-09 04:08:04 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:04 --> Total execution time: 0.4449
INFO - 2024-12-09 04:08:07 --> Config Class Initialized
INFO - 2024-12-09 04:08:07 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:07 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:07 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:07 --> URI Class Initialized
INFO - 2024-12-09 04:08:07 --> Router Class Initialized
INFO - 2024-12-09 04:08:07 --> Output Class Initialized
INFO - 2024-12-09 04:08:07 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:07 --> Input Class Initialized
INFO - 2024-12-09 04:08:07 --> Language Class Initialized
INFO - 2024-12-09 04:08:07 --> Loader Class Initialized
INFO - 2024-12-09 04:08:07 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:07 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:07 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:07 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:07 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:07 --> Controller Class Initialized
DEBUG - 2024-12-09 04:08:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-12-09 04:08:07 --> Config Class Initialized
INFO - 2024-12-09 04:08:07 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:07 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:07 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:07 --> URI Class Initialized
INFO - 2024-12-09 04:08:07 --> Router Class Initialized
INFO - 2024-12-09 04:08:07 --> Output Class Initialized
INFO - 2024-12-09 04:08:07 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:07 --> Input Class Initialized
INFO - 2024-12-09 04:08:07 --> Language Class Initialized
INFO - 2024-12-09 04:08:07 --> Loader Class Initialized
INFO - 2024-12-09 04:08:07 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:07 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:07 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:08 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:08 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:08 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:08 --> Controller Class Initialized
INFO - 2024-12-09 04:08:08 --> Model "Antrol_model" initialized
DEBUG - 2024-12-09 04:08:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-09 04:08:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-09 04:08:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-12-09 04:08:08 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-09 04:08:08 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:08 --> Total execution time: 1.0316
INFO - 2024-12-09 04:08:14 --> Config Class Initialized
INFO - 2024-12-09 04:08:14 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:14 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:14 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:14 --> URI Class Initialized
INFO - 2024-12-09 04:08:14 --> Router Class Initialized
INFO - 2024-12-09 04:08:14 --> Output Class Initialized
INFO - 2024-12-09 04:08:14 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:14 --> Input Class Initialized
INFO - 2024-12-09 04:08:14 --> Language Class Initialized
INFO - 2024-12-09 04:08:14 --> Loader Class Initialized
INFO - 2024-12-09 04:08:14 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:14 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:14 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:14 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:14 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:14 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:14 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:14 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:14 --> Controller Class Initialized
INFO - 2024-12-09 04:08:14 --> Model "Antrol_model" initialized
DEBUG - 2024-12-09 04:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-09 04:08:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-09 04:08:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-09 04:08:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-09 04:08:15 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:15 --> Total execution time: 0.9183
INFO - 2024-12-09 04:08:24 --> Config Class Initialized
INFO - 2024-12-09 04:08:24 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:24 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:24 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:24 --> URI Class Initialized
INFO - 2024-12-09 04:08:24 --> Router Class Initialized
INFO - 2024-12-09 04:08:24 --> Output Class Initialized
INFO - 2024-12-09 04:08:24 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:24 --> Input Class Initialized
INFO - 2024-12-09 04:08:24 --> Language Class Initialized
INFO - 2024-12-09 04:08:24 --> Loader Class Initialized
INFO - 2024-12-09 04:08:24 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:24 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:24 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:24 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:24 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:24 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:24 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:24 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:24 --> Controller Class Initialized
INFO - 2024-12-09 04:08:24 --> Model "Antrol_model" initialized
DEBUG - 2024-12-09 04:08:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-12-09 04:08:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-12-09 04:08:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-12-09 04:08:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-12-09 04:08:24 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:24 --> Total execution time: 0.8700
INFO - 2024-12-09 04:08:37 --> Config Class Initialized
INFO - 2024-12-09 04:08:37 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:37 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:37 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:37 --> URI Class Initialized
INFO - 2024-12-09 04:08:37 --> Router Class Initialized
INFO - 2024-12-09 04:08:37 --> Output Class Initialized
INFO - 2024-12-09 04:08:37 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:37 --> Input Class Initialized
INFO - 2024-12-09 04:08:37 --> Language Class Initialized
INFO - 2024-12-09 04:08:37 --> Loader Class Initialized
INFO - 2024-12-09 04:08:37 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:37 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:37 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:37 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:37 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:37 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:37 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:37 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:37 --> Controller Class Initialized
INFO - 2024-12-09 04:08:37 --> Model "Antrol_model" initialized
DEBUG - 2024-12-09 04:08:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:37 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:37 --> Total execution time: 0.7257
INFO - 2024-12-09 04:08:40 --> Config Class Initialized
INFO - 2024-12-09 04:08:40 --> Hooks Class Initialized
DEBUG - 2024-12-09 04:08:40 --> UTF-8 Support Enabled
INFO - 2024-12-09 04:08:40 --> Utf8 Class Initialized
INFO - 2024-12-09 04:08:40 --> URI Class Initialized
INFO - 2024-12-09 04:08:40 --> Router Class Initialized
INFO - 2024-12-09 04:08:40 --> Output Class Initialized
INFO - 2024-12-09 04:08:40 --> Security Class Initialized
DEBUG - 2024-12-09 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 04:08:40 --> Input Class Initialized
INFO - 2024-12-09 04:08:40 --> Language Class Initialized
INFO - 2024-12-09 04:08:40 --> Loader Class Initialized
INFO - 2024-12-09 04:08:40 --> Helper loaded: url_helper
INFO - 2024-12-09 04:08:40 --> Helper loaded: file_helper
INFO - 2024-12-09 04:08:40 --> Helper loaded: security_helper
INFO - 2024-12-09 04:08:40 --> Helper loaded: wpu_helper
INFO - 2024-12-09 04:08:40 --> Database Driver Class Initialized
INFO - 2024-12-09 04:08:41 --> Email Class Initialized
DEBUG - 2024-12-09 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 04:08:41 --> Helper loaded: form_helper
INFO - 2024-12-09 04:08:41 --> Form Validation Class Initialized
INFO - 2024-12-09 04:08:41 --> Controller Class Initialized
INFO - 2024-12-09 04:08:41 --> Model "Antrol_model" initialized
DEBUG - 2024-12-09 04:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 04:08:41 --> Final output sent to browser
DEBUG - 2024-12-09 04:08:41 --> Total execution time: 0.7070
INFO - 2024-12-09 05:53:19 --> Config Class Initialized
INFO - 2024-12-09 05:53:19 --> Hooks Class Initialized
DEBUG - 2024-12-09 05:53:19 --> UTF-8 Support Enabled
INFO - 2024-12-09 05:53:19 --> Utf8 Class Initialized
INFO - 2024-12-09 05:53:19 --> URI Class Initialized
INFO - 2024-12-09 05:53:19 --> Router Class Initialized
INFO - 2024-12-09 05:53:19 --> Output Class Initialized
INFO - 2024-12-09 05:53:19 --> Security Class Initialized
DEBUG - 2024-12-09 05:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 05:53:19 --> Input Class Initialized
INFO - 2024-12-09 05:53:19 --> Language Class Initialized
INFO - 2024-12-09 05:53:19 --> Loader Class Initialized
INFO - 2024-12-09 05:53:19 --> Helper loaded: url_helper
INFO - 2024-12-09 05:53:19 --> Helper loaded: file_helper
INFO - 2024-12-09 05:53:19 --> Helper loaded: security_helper
INFO - 2024-12-09 05:53:19 --> Helper loaded: wpu_helper
INFO - 2024-12-09 05:53:19 --> Database Driver Class Initialized
INFO - 2024-12-09 05:53:19 --> Email Class Initialized
DEBUG - 2024-12-09 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 05:53:19 --> Helper loaded: form_helper
INFO - 2024-12-09 05:53:19 --> Form Validation Class Initialized
INFO - 2024-12-09 05:53:19 --> Controller Class Initialized
INFO - 2024-12-09 05:53:20 --> Config Class Initialized
INFO - 2024-12-09 05:53:20 --> Hooks Class Initialized
DEBUG - 2024-12-09 05:53:20 --> UTF-8 Support Enabled
INFO - 2024-12-09 05:53:20 --> Utf8 Class Initialized
INFO - 2024-12-09 05:53:20 --> URI Class Initialized
INFO - 2024-12-09 05:53:20 --> Router Class Initialized
INFO - 2024-12-09 05:53:20 --> Output Class Initialized
INFO - 2024-12-09 05:53:20 --> Security Class Initialized
DEBUG - 2024-12-09 05:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 05:53:20 --> Input Class Initialized
INFO - 2024-12-09 05:53:20 --> Language Class Initialized
INFO - 2024-12-09 05:53:20 --> Loader Class Initialized
INFO - 2024-12-09 05:53:20 --> Helper loaded: url_helper
INFO - 2024-12-09 05:53:20 --> Helper loaded: file_helper
INFO - 2024-12-09 05:53:20 --> Helper loaded: security_helper
INFO - 2024-12-09 05:53:20 --> Helper loaded: wpu_helper
INFO - 2024-12-09 05:53:20 --> Database Driver Class Initialized
INFO - 2024-12-09 05:53:20 --> Email Class Initialized
DEBUG - 2024-12-09 05:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 05:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 05:53:20 --> Helper loaded: form_helper
INFO - 2024-12-09 05:53:20 --> Form Validation Class Initialized
INFO - 2024-12-09 05:53:20 --> Controller Class Initialized
DEBUG - 2024-12-09 05:53:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 05:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-09 05:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-09 05:53:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-09 05:53:20 --> Final output sent to browser
DEBUG - 2024-12-09 05:53:20 --> Total execution time: 0.4281
INFO - 2024-12-09 08:52:41 --> Config Class Initialized
INFO - 2024-12-09 08:52:41 --> Hooks Class Initialized
DEBUG - 2024-12-09 08:52:41 --> UTF-8 Support Enabled
INFO - 2024-12-09 08:52:41 --> Utf8 Class Initialized
INFO - 2024-12-09 08:52:41 --> URI Class Initialized
DEBUG - 2024-12-09 08:52:41 --> No URI present. Default controller set.
INFO - 2024-12-09 08:52:41 --> Router Class Initialized
INFO - 2024-12-09 08:52:41 --> Output Class Initialized
INFO - 2024-12-09 08:52:41 --> Security Class Initialized
DEBUG - 2024-12-09 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 08:52:41 --> Input Class Initialized
INFO - 2024-12-09 08:52:41 --> Language Class Initialized
INFO - 2024-12-09 08:52:41 --> Loader Class Initialized
INFO - 2024-12-09 08:52:41 --> Helper loaded: url_helper
INFO - 2024-12-09 08:52:41 --> Helper loaded: file_helper
INFO - 2024-12-09 08:52:41 --> Helper loaded: security_helper
INFO - 2024-12-09 08:52:41 --> Helper loaded: wpu_helper
INFO - 2024-12-09 08:52:41 --> Database Driver Class Initialized
INFO - 2024-12-09 08:52:41 --> Email Class Initialized
DEBUG - 2024-12-09 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 08:52:41 --> Helper loaded: form_helper
INFO - 2024-12-09 08:52:41 --> Form Validation Class Initialized
INFO - 2024-12-09 08:52:41 --> Controller Class Initialized
DEBUG - 2024-12-09 08:52:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 08:52:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-09 08:52:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-09 08:52:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-09 08:52:41 --> Final output sent to browser
DEBUG - 2024-12-09 08:52:41 --> Total execution time: 0.4309
INFO - 2024-12-09 13:39:05 --> Config Class Initialized
INFO - 2024-12-09 13:39:05 --> Hooks Class Initialized
DEBUG - 2024-12-09 13:39:05 --> UTF-8 Support Enabled
INFO - 2024-12-09 13:39:05 --> Utf8 Class Initialized
INFO - 2024-12-09 13:39:05 --> URI Class Initialized
DEBUG - 2024-12-09 13:39:05 --> No URI present. Default controller set.
INFO - 2024-12-09 13:39:05 --> Router Class Initialized
INFO - 2024-12-09 13:39:05 --> Output Class Initialized
INFO - 2024-12-09 13:39:05 --> Security Class Initialized
DEBUG - 2024-12-09 13:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 13:39:05 --> Input Class Initialized
INFO - 2024-12-09 13:39:05 --> Language Class Initialized
INFO - 2024-12-09 13:39:05 --> Loader Class Initialized
INFO - 2024-12-09 13:39:05 --> Helper loaded: url_helper
INFO - 2024-12-09 13:39:05 --> Helper loaded: file_helper
INFO - 2024-12-09 13:39:05 --> Helper loaded: security_helper
INFO - 2024-12-09 13:39:05 --> Helper loaded: wpu_helper
INFO - 2024-12-09 13:39:05 --> Database Driver Class Initialized
INFO - 2024-12-09 13:39:05 --> Email Class Initialized
DEBUG - 2024-12-09 13:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-09 13:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 13:39:05 --> Helper loaded: form_helper
INFO - 2024-12-09 13:39:05 --> Form Validation Class Initialized
INFO - 2024-12-09 13:39:05 --> Controller Class Initialized
DEBUG - 2024-12-09 13:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-09 13:39:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-09 13:39:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-09 13:39:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-09 13:39:05 --> Final output sent to browser
DEBUG - 2024-12-09 13:39:05 --> Total execution time: 0.4017
