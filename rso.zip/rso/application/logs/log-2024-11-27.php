<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-27 07:59:34 --> Config Class Initialized
INFO - 2024-11-27 07:59:34 --> Hooks Class Initialized
DEBUG - 2024-11-27 07:59:34 --> UTF-8 Support Enabled
INFO - 2024-11-27 07:59:34 --> Utf8 Class Initialized
INFO - 2024-11-27 07:59:34 --> URI Class Initialized
DEBUG - 2024-11-27 07:59:34 --> No URI present. Default controller set.
INFO - 2024-11-27 07:59:34 --> Router Class Initialized
INFO - 2024-11-27 07:59:34 --> Output Class Initialized
INFO - 2024-11-27 07:59:34 --> Security Class Initialized
DEBUG - 2024-11-27 07:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 07:59:34 --> Input Class Initialized
INFO - 2024-11-27 07:59:35 --> Language Class Initialized
INFO - 2024-11-27 07:59:35 --> Loader Class Initialized
INFO - 2024-11-27 07:59:35 --> Helper loaded: url_helper
INFO - 2024-11-27 07:59:35 --> Helper loaded: file_helper
INFO - 2024-11-27 07:59:35 --> Helper loaded: security_helper
INFO - 2024-11-27 07:59:35 --> Helper loaded: wpu_helper
INFO - 2024-11-27 07:59:35 --> Database Driver Class Initialized
ERROR - 2024-11-27 07:59:42 --> Unable to connect to the database
INFO - 2024-11-27 07:59:42 --> Language file loaded: language/english/db_lang.php
