<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-09 02:24:32 --> Config Class Initialized
INFO - 2024-10-09 02:24:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 02:24:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 02:24:32 --> Utf8 Class Initialized
INFO - 2024-10-09 02:24:32 --> URI Class Initialized
DEBUG - 2024-10-09 02:24:32 --> No URI present. Default controller set.
INFO - 2024-10-09 02:24:32 --> Router Class Initialized
INFO - 2024-10-09 02:24:32 --> Output Class Initialized
INFO - 2024-10-09 02:24:32 --> Security Class Initialized
DEBUG - 2024-10-09 02:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 02:24:32 --> Input Class Initialized
INFO - 2024-10-09 02:24:32 --> Language Class Initialized
INFO - 2024-10-09 02:24:32 --> Loader Class Initialized
INFO - 2024-10-09 02:24:32 --> Helper loaded: url_helper
INFO - 2024-10-09 02:24:32 --> Helper loaded: file_helper
INFO - 2024-10-09 02:24:32 --> Helper loaded: security_helper
INFO - 2024-10-09 02:24:32 --> Helper loaded: wpu_helper
INFO - 2024-10-09 02:24:32 --> Database Driver Class Initialized
INFO - 2024-10-09 02:24:32 --> Email Class Initialized
DEBUG - 2024-10-09 02:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 02:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 02:24:32 --> Helper loaded: form_helper
INFO - 2024-10-09 02:24:32 --> Form Validation Class Initialized
INFO - 2024-10-09 02:24:32 --> Controller Class Initialized
DEBUG - 2024-10-09 02:24:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 02:24:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 02:24:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 02:24:32 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 02:24:32 --> Final output sent to browser
DEBUG - 2024-10-09 02:24:32 --> Total execution time: 0.2339
INFO - 2024-10-09 02:28:32 --> Config Class Initialized
INFO - 2024-10-09 02:28:32 --> Hooks Class Initialized
DEBUG - 2024-10-09 02:28:32 --> UTF-8 Support Enabled
INFO - 2024-10-09 02:28:32 --> Utf8 Class Initialized
INFO - 2024-10-09 02:28:32 --> URI Class Initialized
INFO - 2024-10-09 02:28:32 --> Router Class Initialized
INFO - 2024-10-09 02:28:32 --> Output Class Initialized
INFO - 2024-10-09 02:28:32 --> Security Class Initialized
DEBUG - 2024-10-09 02:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 02:28:32 --> Input Class Initialized
INFO - 2024-10-09 02:28:32 --> Language Class Initialized
ERROR - 2024-10-09 02:28:32 --> 404 Page Not Found: Beaefe39-0ca5-485e-8d39-33659a1f5c5c/i7ONCnQPD2.js
INFO - 2024-10-09 05:10:09 --> Config Class Initialized
INFO - 2024-10-09 05:10:09 --> Hooks Class Initialized
DEBUG - 2024-10-09 05:10:09 --> UTF-8 Support Enabled
INFO - 2024-10-09 05:10:09 --> Utf8 Class Initialized
INFO - 2024-10-09 05:10:09 --> URI Class Initialized
DEBUG - 2024-10-09 05:10:09 --> No URI present. Default controller set.
INFO - 2024-10-09 05:10:09 --> Router Class Initialized
INFO - 2024-10-09 05:10:09 --> Output Class Initialized
INFO - 2024-10-09 05:10:09 --> Security Class Initialized
DEBUG - 2024-10-09 05:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 05:10:09 --> Input Class Initialized
INFO - 2024-10-09 05:10:09 --> Language Class Initialized
INFO - 2024-10-09 05:10:09 --> Loader Class Initialized
INFO - 2024-10-09 05:10:09 --> Helper loaded: url_helper
INFO - 2024-10-09 05:10:09 --> Helper loaded: file_helper
INFO - 2024-10-09 05:10:09 --> Helper loaded: security_helper
INFO - 2024-10-09 05:10:09 --> Helper loaded: wpu_helper
INFO - 2024-10-09 05:10:09 --> Database Driver Class Initialized
INFO - 2024-10-09 05:10:09 --> Email Class Initialized
DEBUG - 2024-10-09 05:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 05:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 05:10:09 --> Helper loaded: form_helper
INFO - 2024-10-09 05:10:09 --> Form Validation Class Initialized
INFO - 2024-10-09 05:10:09 --> Controller Class Initialized
DEBUG - 2024-10-09 05:10:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 05:10:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 05:10:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 05:10:09 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 05:10:09 --> Final output sent to browser
DEBUG - 2024-10-09 05:10:09 --> Total execution time: 0.2298
INFO - 2024-10-09 05:10:12 --> Config Class Initialized
INFO - 2024-10-09 05:10:12 --> Hooks Class Initialized
DEBUG - 2024-10-09 05:10:12 --> UTF-8 Support Enabled
INFO - 2024-10-09 05:10:12 --> Utf8 Class Initialized
INFO - 2024-10-09 05:10:12 --> URI Class Initialized
DEBUG - 2024-10-09 05:10:12 --> No URI present. Default controller set.
INFO - 2024-10-09 05:10:12 --> Router Class Initialized
INFO - 2024-10-09 05:10:12 --> Output Class Initialized
INFO - 2024-10-09 05:10:12 --> Security Class Initialized
DEBUG - 2024-10-09 05:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 05:10:12 --> Input Class Initialized
INFO - 2024-10-09 05:10:12 --> Language Class Initialized
INFO - 2024-10-09 05:10:12 --> Loader Class Initialized
INFO - 2024-10-09 05:10:12 --> Helper loaded: url_helper
INFO - 2024-10-09 05:10:12 --> Helper loaded: file_helper
INFO - 2024-10-09 05:10:12 --> Helper loaded: security_helper
INFO - 2024-10-09 05:10:12 --> Helper loaded: wpu_helper
INFO - 2024-10-09 05:10:12 --> Database Driver Class Initialized
INFO - 2024-10-09 05:10:12 --> Email Class Initialized
DEBUG - 2024-10-09 05:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 05:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 05:10:12 --> Helper loaded: form_helper
INFO - 2024-10-09 05:10:12 --> Form Validation Class Initialized
INFO - 2024-10-09 05:10:12 --> Controller Class Initialized
DEBUG - 2024-10-09 05:10:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 05:10:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 05:10:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 05:10:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 05:10:12 --> Final output sent to browser
DEBUG - 2024-10-09 05:10:12 --> Total execution time: 0.2441
INFO - 2024-10-09 05:32:58 --> Config Class Initialized
INFO - 2024-10-09 05:32:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 05:32:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 05:32:58 --> Utf8 Class Initialized
INFO - 2024-10-09 05:32:58 --> URI Class Initialized
INFO - 2024-10-09 05:32:58 --> Config Class Initialized
INFO - 2024-10-09 05:32:58 --> Hooks Class Initialized
DEBUG - 2024-10-09 05:32:58 --> No URI present. Default controller set.
INFO - 2024-10-09 05:32:58 --> Router Class Initialized
DEBUG - 2024-10-09 05:32:58 --> UTF-8 Support Enabled
INFO - 2024-10-09 05:32:58 --> Utf8 Class Initialized
INFO - 2024-10-09 05:32:58 --> Output Class Initialized
INFO - 2024-10-09 05:32:58 --> Security Class Initialized
INFO - 2024-10-09 05:32:58 --> URI Class Initialized
DEBUG - 2024-10-09 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 05:32:58 --> Input Class Initialized
DEBUG - 2024-10-09 05:32:58 --> No URI present. Default controller set.
INFO - 2024-10-09 05:32:58 --> Router Class Initialized
INFO - 2024-10-09 05:32:58 --> Language Class Initialized
INFO - 2024-10-09 05:32:58 --> Output Class Initialized
INFO - 2024-10-09 05:32:58 --> Loader Class Initialized
INFO - 2024-10-09 05:32:58 --> Security Class Initialized
INFO - 2024-10-09 05:32:58 --> Helper loaded: url_helper
INFO - 2024-10-09 05:32:58 --> Helper loaded: file_helper
INFO - 2024-10-09 05:32:58 --> Helper loaded: security_helper
DEBUG - 2024-10-09 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 05:32:58 --> Helper loaded: wpu_helper
INFO - 2024-10-09 05:32:58 --> Input Class Initialized
INFO - 2024-10-09 05:32:58 --> Language Class Initialized
INFO - 2024-10-09 05:32:58 --> Loader Class Initialized
INFO - 2024-10-09 05:32:58 --> Helper loaded: url_helper
INFO - 2024-10-09 05:32:58 --> Helper loaded: file_helper
INFO - 2024-10-09 05:32:58 --> Helper loaded: security_helper
INFO - 2024-10-09 05:32:58 --> Database Driver Class Initialized
INFO - 2024-10-09 05:32:58 --> Helper loaded: wpu_helper
INFO - 2024-10-09 05:32:58 --> Database Driver Class Initialized
INFO - 2024-10-09 05:32:58 --> Email Class Initialized
DEBUG - 2024-10-09 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 05:32:58 --> Helper loaded: form_helper
INFO - 2024-10-09 05:32:58 --> Form Validation Class Initialized
INFO - 2024-10-09 05:32:58 --> Controller Class Initialized
DEBUG - 2024-10-09 05:32:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 05:32:58 --> Final output sent to browser
DEBUG - 2024-10-09 05:32:58 --> Total execution time: 0.2252
INFO - 2024-10-09 05:32:58 --> Email Class Initialized
DEBUG - 2024-10-09 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 05:32:58 --> Helper loaded: form_helper
INFO - 2024-10-09 05:32:58 --> Form Validation Class Initialized
INFO - 2024-10-09 05:32:58 --> Controller Class Initialized
DEBUG - 2024-10-09 05:32:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 05:32:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 05:32:58 --> Final output sent to browser
DEBUG - 2024-10-09 05:32:58 --> Total execution time: 0.2387
INFO - 2024-10-09 09:00:25 --> Config Class Initialized
INFO - 2024-10-09 09:00:25 --> Hooks Class Initialized
DEBUG - 2024-10-09 09:00:25 --> UTF-8 Support Enabled
INFO - 2024-10-09 09:00:25 --> Utf8 Class Initialized
INFO - 2024-10-09 09:00:25 --> URI Class Initialized
DEBUG - 2024-10-09 09:00:25 --> No URI present. Default controller set.
INFO - 2024-10-09 09:00:25 --> Router Class Initialized
INFO - 2024-10-09 09:00:25 --> Output Class Initialized
INFO - 2024-10-09 09:00:25 --> Security Class Initialized
DEBUG - 2024-10-09 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-09 09:00:25 --> Input Class Initialized
INFO - 2024-10-09 09:00:25 --> Language Class Initialized
INFO - 2024-10-09 09:00:25 --> Loader Class Initialized
INFO - 2024-10-09 09:00:25 --> Helper loaded: url_helper
INFO - 2024-10-09 09:00:25 --> Helper loaded: file_helper
INFO - 2024-10-09 09:00:25 --> Helper loaded: security_helper
INFO - 2024-10-09 09:00:25 --> Helper loaded: wpu_helper
INFO - 2024-10-09 09:00:25 --> Database Driver Class Initialized
INFO - 2024-10-09 09:00:25 --> Email Class Initialized
DEBUG - 2024-10-09 09:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-09 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-09 09:00:25 --> Helper loaded: form_helper
INFO - 2024-10-09 09:00:25 --> Form Validation Class Initialized
INFO - 2024-10-09 09:00:25 --> Controller Class Initialized
DEBUG - 2024-10-09 09:00:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-09 09:00:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-09 09:00:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-09 09:00:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-09 09:00:25 --> Final output sent to browser
DEBUG - 2024-10-09 09:00:25 --> Total execution time: 0.2297
