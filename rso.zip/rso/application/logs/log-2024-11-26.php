<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-26 08:01:16 --> Config Class Initialized
INFO - 2024-11-26 08:01:16 --> Hooks Class Initialized
DEBUG - 2024-11-26 08:01:16 --> UTF-8 Support Enabled
INFO - 2024-11-26 08:01:16 --> Utf8 Class Initialized
INFO - 2024-11-26 08:01:16 --> URI Class Initialized
DEBUG - 2024-11-26 08:01:16 --> No URI present. Default controller set.
INFO - 2024-11-26 08:01:16 --> Router Class Initialized
INFO - 2024-11-26 08:01:16 --> Output Class Initialized
INFO - 2024-11-26 08:01:16 --> Security Class Initialized
DEBUG - 2024-11-26 08:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 08:01:16 --> Input Class Initialized
INFO - 2024-11-26 08:01:16 --> Language Class Initialized
INFO - 2024-11-26 08:01:16 --> Loader Class Initialized
INFO - 2024-11-26 08:01:16 --> Helper loaded: url_helper
INFO - 2024-11-26 08:01:16 --> Helper loaded: file_helper
INFO - 2024-11-26 08:01:16 --> Helper loaded: security_helper
INFO - 2024-11-26 08:01:16 --> Helper loaded: wpu_helper
INFO - 2024-11-26 08:01:16 --> Database Driver Class Initialized
ERROR - 2024-11-26 08:01:23 --> Unable to connect to the database
INFO - 2024-11-26 08:01:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-26 16:39:09 --> Config Class Initialized
INFO - 2024-11-26 16:39:09 --> Hooks Class Initialized
DEBUG - 2024-11-26 16:39:09 --> UTF-8 Support Enabled
INFO - 2024-11-26 16:39:09 --> Utf8 Class Initialized
INFO - 2024-11-26 16:39:09 --> URI Class Initialized
DEBUG - 2024-11-26 16:39:09 --> No URI present. Default controller set.
INFO - 2024-11-26 16:39:09 --> Router Class Initialized
INFO - 2024-11-26 16:39:09 --> Output Class Initialized
INFO - 2024-11-26 16:39:09 --> Security Class Initialized
DEBUG - 2024-11-26 16:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-26 16:39:09 --> Input Class Initialized
INFO - 2024-11-26 16:39:09 --> Language Class Initialized
INFO - 2024-11-26 16:39:09 --> Loader Class Initialized
INFO - 2024-11-26 16:39:09 --> Helper loaded: url_helper
INFO - 2024-11-26 16:39:09 --> Helper loaded: file_helper
INFO - 2024-11-26 16:39:09 --> Helper loaded: security_helper
INFO - 2024-11-26 16:39:09 --> Helper loaded: wpu_helper
INFO - 2024-11-26 16:39:09 --> Database Driver Class Initialized
ERROR - 2024-11-26 16:39:16 --> Unable to connect to the database
INFO - 2024-11-26 16:39:16 --> Language file loaded: language/english/db_lang.php
