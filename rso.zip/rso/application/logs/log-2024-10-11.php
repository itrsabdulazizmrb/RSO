<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-11 02:03:05 --> Config Class Initialized
INFO - 2024-10-11 02:03:05 --> Hooks Class Initialized
DEBUG - 2024-10-11 02:03:05 --> UTF-8 Support Enabled
INFO - 2024-10-11 02:03:05 --> Utf8 Class Initialized
INFO - 2024-10-11 02:03:05 --> URI Class Initialized
DEBUG - 2024-10-11 02:03:05 --> No URI present. Default controller set.
INFO - 2024-10-11 02:03:05 --> Router Class Initialized
INFO - 2024-10-11 02:03:05 --> Output Class Initialized
INFO - 2024-10-11 02:03:05 --> Security Class Initialized
DEBUG - 2024-10-11 02:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 02:03:05 --> Input Class Initialized
INFO - 2024-10-11 02:03:05 --> Language Class Initialized
INFO - 2024-10-11 02:03:05 --> Loader Class Initialized
INFO - 2024-10-11 02:03:05 --> Helper loaded: url_helper
INFO - 2024-10-11 02:03:05 --> Helper loaded: file_helper
INFO - 2024-10-11 02:03:05 --> Helper loaded: security_helper
INFO - 2024-10-11 02:03:05 --> Helper loaded: wpu_helper
INFO - 2024-10-11 02:03:05 --> Database Driver Class Initialized
INFO - 2024-10-11 08:57:07 --> Config Class Initialized
INFO - 2024-10-11 08:57:07 --> Hooks Class Initialized
DEBUG - 2024-10-11 08:57:07 --> UTF-8 Support Enabled
INFO - 2024-10-11 08:57:07 --> Utf8 Class Initialized
INFO - 2024-10-11 08:57:07 --> URI Class Initialized
DEBUG - 2024-10-11 08:57:07 --> No URI present. Default controller set.
INFO - 2024-10-11 08:57:07 --> Router Class Initialized
INFO - 2024-10-11 08:57:07 --> Output Class Initialized
INFO - 2024-10-11 08:57:07 --> Security Class Initialized
DEBUG - 2024-10-11 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 08:57:07 --> Input Class Initialized
INFO - 2024-10-11 08:57:07 --> Language Class Initialized
INFO - 2024-10-11 08:57:07 --> Loader Class Initialized
INFO - 2024-10-11 08:57:07 --> Helper loaded: url_helper
INFO - 2024-10-11 08:57:07 --> Helper loaded: file_helper
INFO - 2024-10-11 08:57:07 --> Helper loaded: security_helper
INFO - 2024-10-11 08:57:07 --> Helper loaded: wpu_helper
INFO - 2024-10-11 08:57:07 --> Database Driver Class Initialized
INFO - 2024-10-11 09:20:15 --> Config Class Initialized
INFO - 2024-10-11 09:20:15 --> Hooks Class Initialized
DEBUG - 2024-10-11 09:20:15 --> UTF-8 Support Enabled
INFO - 2024-10-11 09:20:15 --> Utf8 Class Initialized
INFO - 2024-10-11 09:20:15 --> URI Class Initialized
DEBUG - 2024-10-11 09:20:15 --> No URI present. Default controller set.
INFO - 2024-10-11 09:20:15 --> Router Class Initialized
INFO - 2024-10-11 09:20:15 --> Output Class Initialized
INFO - 2024-10-11 09:20:15 --> Security Class Initialized
DEBUG - 2024-10-11 09:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 09:20:15 --> Input Class Initialized
INFO - 2024-10-11 09:20:15 --> Language Class Initialized
INFO - 2024-10-11 09:20:15 --> Loader Class Initialized
INFO - 2024-10-11 09:20:15 --> Helper loaded: url_helper
INFO - 2024-10-11 09:20:15 --> Helper loaded: file_helper
INFO - 2024-10-11 09:20:15 --> Helper loaded: security_helper
INFO - 2024-10-11 09:20:15 --> Helper loaded: wpu_helper
INFO - 2024-10-11 09:20:15 --> Database Driver Class Initialized
INFO - 2024-10-11 09:20:19 --> Config Class Initialized
INFO - 2024-10-11 09:20:19 --> Hooks Class Initialized
DEBUG - 2024-10-11 09:20:19 --> UTF-8 Support Enabled
INFO - 2024-10-11 09:20:19 --> Utf8 Class Initialized
INFO - 2024-10-11 09:20:19 --> URI Class Initialized
DEBUG - 2024-10-11 09:20:19 --> No URI present. Default controller set.
INFO - 2024-10-11 09:20:19 --> Router Class Initialized
INFO - 2024-10-11 09:20:19 --> Output Class Initialized
INFO - 2024-10-11 09:20:19 --> Security Class Initialized
DEBUG - 2024-10-11 09:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 09:20:19 --> Input Class Initialized
INFO - 2024-10-11 09:20:19 --> Language Class Initialized
INFO - 2024-10-11 09:20:19 --> Loader Class Initialized
INFO - 2024-10-11 09:20:19 --> Helper loaded: url_helper
INFO - 2024-10-11 09:20:19 --> Helper loaded: file_helper
INFO - 2024-10-11 09:20:19 --> Helper loaded: security_helper
INFO - 2024-10-11 09:20:19 --> Helper loaded: wpu_helper
INFO - 2024-10-11 09:20:19 --> Database Driver Class Initialized
INFO - 2024-10-11 17:13:47 --> Config Class Initialized
INFO - 2024-10-11 17:13:47 --> Hooks Class Initialized
DEBUG - 2024-10-11 17:13:47 --> UTF-8 Support Enabled
INFO - 2024-10-11 17:13:47 --> Utf8 Class Initialized
INFO - 2024-10-11 17:13:47 --> URI Class Initialized
DEBUG - 2024-10-11 17:13:47 --> No URI present. Default controller set.
INFO - 2024-10-11 17:13:47 --> Router Class Initialized
INFO - 2024-10-11 17:13:47 --> Output Class Initialized
INFO - 2024-10-11 17:13:47 --> Security Class Initialized
DEBUG - 2024-10-11 17:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 17:13:47 --> Input Class Initialized
INFO - 2024-10-11 17:13:47 --> Language Class Initialized
INFO - 2024-10-11 17:13:47 --> Loader Class Initialized
INFO - 2024-10-11 17:13:47 --> Helper loaded: url_helper
INFO - 2024-10-11 17:13:47 --> Helper loaded: file_helper
INFO - 2024-10-11 17:13:47 --> Helper loaded: security_helper
INFO - 2024-10-11 17:13:47 --> Helper loaded: wpu_helper
INFO - 2024-10-11 17:13:47 --> Database Driver Class Initialized
INFO - 2024-10-11 17:13:47 --> Email Class Initialized
DEBUG - 2024-10-11 17:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-11 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 17:13:47 --> Helper loaded: form_helper
INFO - 2024-10-11 17:13:47 --> Form Validation Class Initialized
INFO - 2024-10-11 17:13:47 --> Controller Class Initialized
DEBUG - 2024-10-11 17:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-11 17:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-11 17:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-11 17:13:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-11 17:13:47 --> Final output sent to browser
DEBUG - 2024-10-11 17:13:47 --> Total execution time: 0.2195
INFO - 2024-10-11 17:13:48 --> Config Class Initialized
INFO - 2024-10-11 17:13:48 --> Hooks Class Initialized
DEBUG - 2024-10-11 17:13:48 --> UTF-8 Support Enabled
INFO - 2024-10-11 17:13:48 --> Utf8 Class Initialized
INFO - 2024-10-11 17:13:48 --> URI Class Initialized
DEBUG - 2024-10-11 17:13:48 --> No URI present. Default controller set.
INFO - 2024-10-11 17:13:48 --> Router Class Initialized
INFO - 2024-10-11 17:13:48 --> Output Class Initialized
INFO - 2024-10-11 17:13:48 --> Security Class Initialized
DEBUG - 2024-10-11 17:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 17:13:48 --> Input Class Initialized
INFO - 2024-10-11 17:13:48 --> Language Class Initialized
INFO - 2024-10-11 17:13:48 --> Loader Class Initialized
INFO - 2024-10-11 17:13:48 --> Helper loaded: url_helper
INFO - 2024-10-11 17:13:48 --> Helper loaded: file_helper
INFO - 2024-10-11 17:13:48 --> Helper loaded: security_helper
INFO - 2024-10-11 17:13:48 --> Helper loaded: wpu_helper
INFO - 2024-10-11 17:13:48 --> Database Driver Class Initialized
INFO - 2024-10-11 17:13:48 --> Email Class Initialized
DEBUG - 2024-10-11 17:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-11 17:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 17:13:48 --> Helper loaded: form_helper
INFO - 2024-10-11 17:13:48 --> Form Validation Class Initialized
INFO - 2024-10-11 17:13:48 --> Controller Class Initialized
DEBUG - 2024-10-11 17:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-11 17:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-11 17:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-11 17:13:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-11 17:13:48 --> Final output sent to browser
DEBUG - 2024-10-11 17:13:48 --> Total execution time: 0.2222
INFO - 2024-10-11 17:13:56 --> Config Class Initialized
INFO - 2024-10-11 17:13:56 --> Hooks Class Initialized
DEBUG - 2024-10-11 17:13:56 --> UTF-8 Support Enabled
INFO - 2024-10-11 17:13:56 --> Utf8 Class Initialized
INFO - 2024-10-11 17:13:56 --> URI Class Initialized
DEBUG - 2024-10-11 17:13:56 --> No URI present. Default controller set.
INFO - 2024-10-11 17:13:56 --> Router Class Initialized
INFO - 2024-10-11 17:13:56 --> Output Class Initialized
INFO - 2024-10-11 17:13:56 --> Security Class Initialized
DEBUG - 2024-10-11 17:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 17:13:56 --> Input Class Initialized
INFO - 2024-10-11 17:13:56 --> Language Class Initialized
INFO - 2024-10-11 17:13:56 --> Loader Class Initialized
INFO - 2024-10-11 17:13:56 --> Helper loaded: url_helper
INFO - 2024-10-11 17:13:56 --> Helper loaded: file_helper
INFO - 2024-10-11 17:13:56 --> Helper loaded: security_helper
INFO - 2024-10-11 17:13:56 --> Helper loaded: wpu_helper
INFO - 2024-10-11 17:13:56 --> Database Driver Class Initialized
INFO - 2024-10-11 17:13:56 --> Email Class Initialized
DEBUG - 2024-10-11 17:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-11 17:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 17:13:56 --> Helper loaded: form_helper
INFO - 2024-10-11 17:13:56 --> Form Validation Class Initialized
INFO - 2024-10-11 17:13:56 --> Controller Class Initialized
DEBUG - 2024-10-11 17:13:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-11 17:13:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-11 17:13:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-11 17:13:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-11 17:13:56 --> Final output sent to browser
DEBUG - 2024-10-11 17:13:56 --> Total execution time: 0.2153
