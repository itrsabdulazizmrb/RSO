<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-05 08:25:20 --> Config Class Initialized
INFO - 2024-11-05 08:25:20 --> Hooks Class Initialized
DEBUG - 2024-11-05 08:25:20 --> UTF-8 Support Enabled
INFO - 2024-11-05 08:25:20 --> Utf8 Class Initialized
INFO - 2024-11-05 08:25:20 --> URI Class Initialized
DEBUG - 2024-11-05 08:25:20 --> No URI present. Default controller set.
INFO - 2024-11-05 08:25:20 --> Router Class Initialized
INFO - 2024-11-05 08:25:20 --> Output Class Initialized
INFO - 2024-11-05 08:25:20 --> Security Class Initialized
DEBUG - 2024-11-05 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-05 08:25:20 --> Input Class Initialized
INFO - 2024-11-05 08:25:20 --> Language Class Initialized
INFO - 2024-11-05 08:25:20 --> Loader Class Initialized
INFO - 2024-11-05 08:25:20 --> Helper loaded: url_helper
INFO - 2024-11-05 08:25:20 --> Helper loaded: file_helper
INFO - 2024-11-05 08:25:20 --> Helper loaded: security_helper
INFO - 2024-11-05 08:25:20 --> Helper loaded: wpu_helper
INFO - 2024-11-05 08:25:20 --> Database Driver Class Initialized
ERROR - 2024-11-05 08:25:27 --> Unable to connect to the database
INFO - 2024-11-05 08:25:27 --> Language file loaded: language/english/db_lang.php
