<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-06 00:19:54 --> Config Class Initialized
INFO - 2024-11-06 00:19:54 --> Hooks Class Initialized
DEBUG - 2024-11-06 00:19:54 --> UTF-8 Support Enabled
INFO - 2024-11-06 00:19:54 --> Utf8 Class Initialized
INFO - 2024-11-06 00:19:54 --> URI Class Initialized
DEBUG - 2024-11-06 00:19:54 --> No URI present. Default controller set.
INFO - 2024-11-06 00:19:54 --> Router Class Initialized
INFO - 2024-11-06 00:19:54 --> Output Class Initialized
INFO - 2024-11-06 00:19:54 --> Security Class Initialized
DEBUG - 2024-11-06 00:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 00:19:54 --> Input Class Initialized
INFO - 2024-11-06 00:19:54 --> Language Class Initialized
INFO - 2024-11-06 00:19:54 --> Loader Class Initialized
INFO - 2024-11-06 00:19:54 --> Helper loaded: url_helper
INFO - 2024-11-06 00:19:54 --> Helper loaded: file_helper
INFO - 2024-11-06 00:19:54 --> Helper loaded: security_helper
INFO - 2024-11-06 00:19:54 --> Helper loaded: wpu_helper
INFO - 2024-11-06 00:19:54 --> Database Driver Class Initialized
ERROR - 2024-11-06 00:20:01 --> Unable to connect to the database
INFO - 2024-11-06 00:20:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 03:13:03 --> Config Class Initialized
INFO - 2024-11-06 03:13:03 --> Hooks Class Initialized
DEBUG - 2024-11-06 03:13:03 --> UTF-8 Support Enabled
INFO - 2024-11-06 03:13:03 --> Utf8 Class Initialized
INFO - 2024-11-06 03:13:03 --> URI Class Initialized
DEBUG - 2024-11-06 03:13:03 --> No URI present. Default controller set.
INFO - 2024-11-06 03:13:03 --> Router Class Initialized
INFO - 2024-11-06 03:13:03 --> Output Class Initialized
INFO - 2024-11-06 03:13:03 --> Security Class Initialized
DEBUG - 2024-11-06 03:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 03:13:03 --> Input Class Initialized
INFO - 2024-11-06 03:13:03 --> Language Class Initialized
INFO - 2024-11-06 03:13:03 --> Loader Class Initialized
INFO - 2024-11-06 03:13:03 --> Helper loaded: url_helper
INFO - 2024-11-06 03:13:03 --> Helper loaded: file_helper
INFO - 2024-11-06 03:13:03 --> Helper loaded: security_helper
INFO - 2024-11-06 03:13:03 --> Helper loaded: wpu_helper
INFO - 2024-11-06 03:13:03 --> Database Driver Class Initialized
ERROR - 2024-11-06 03:13:10 --> Unable to connect to the database
INFO - 2024-11-06 03:13:10 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 07:20:18 --> Config Class Initialized
INFO - 2024-11-06 07:20:18 --> Hooks Class Initialized
DEBUG - 2024-11-06 07:20:18 --> UTF-8 Support Enabled
INFO - 2024-11-06 07:20:18 --> Utf8 Class Initialized
INFO - 2024-11-06 07:20:18 --> URI Class Initialized
DEBUG - 2024-11-06 07:20:18 --> No URI present. Default controller set.
INFO - 2024-11-06 07:20:18 --> Router Class Initialized
INFO - 2024-11-06 07:20:18 --> Output Class Initialized
INFO - 2024-11-06 07:20:18 --> Security Class Initialized
DEBUG - 2024-11-06 07:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 07:20:18 --> Input Class Initialized
INFO - 2024-11-06 07:20:18 --> Language Class Initialized
INFO - 2024-11-06 07:20:18 --> Loader Class Initialized
INFO - 2024-11-06 07:20:18 --> Helper loaded: url_helper
INFO - 2024-11-06 07:20:18 --> Helper loaded: file_helper
INFO - 2024-11-06 07:20:18 --> Helper loaded: security_helper
INFO - 2024-11-06 07:20:18 --> Helper loaded: wpu_helper
INFO - 2024-11-06 07:20:18 --> Database Driver Class Initialized
ERROR - 2024-11-06 07:20:25 --> Unable to connect to the database
INFO - 2024-11-06 07:20:25 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 08:23:53 --> Config Class Initialized
INFO - 2024-11-06 08:23:53 --> Hooks Class Initialized
DEBUG - 2024-11-06 08:23:53 --> UTF-8 Support Enabled
INFO - 2024-11-06 08:23:53 --> Utf8 Class Initialized
INFO - 2024-11-06 08:23:53 --> URI Class Initialized
DEBUG - 2024-11-06 08:23:53 --> No URI present. Default controller set.
INFO - 2024-11-06 08:23:53 --> Router Class Initialized
INFO - 2024-11-06 08:23:53 --> Output Class Initialized
INFO - 2024-11-06 08:23:53 --> Security Class Initialized
DEBUG - 2024-11-06 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 08:23:53 --> Input Class Initialized
INFO - 2024-11-06 08:23:53 --> Language Class Initialized
INFO - 2024-11-06 08:23:53 --> Loader Class Initialized
INFO - 2024-11-06 08:23:53 --> Helper loaded: url_helper
INFO - 2024-11-06 08:23:53 --> Helper loaded: file_helper
INFO - 2024-11-06 08:23:53 --> Helper loaded: security_helper
INFO - 2024-11-06 08:23:53 --> Helper loaded: wpu_helper
INFO - 2024-11-06 08:23:53 --> Database Driver Class Initialized
ERROR - 2024-11-06 08:24:01 --> Unable to connect to the database
INFO - 2024-11-06 08:24:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 09:00:05 --> Config Class Initialized
INFO - 2024-11-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2024-11-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2024-11-06 09:00:05 --> Utf8 Class Initialized
INFO - 2024-11-06 09:00:05 --> URI Class Initialized
DEBUG - 2024-11-06 09:00:05 --> No URI present. Default controller set.
INFO - 2024-11-06 09:00:05 --> Router Class Initialized
INFO - 2024-11-06 09:00:05 --> Output Class Initialized
INFO - 2024-11-06 09:00:05 --> Security Class Initialized
DEBUG - 2024-11-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 09:00:05 --> Input Class Initialized
INFO - 2024-11-06 09:00:05 --> Language Class Initialized
INFO - 2024-11-06 09:00:05 --> Loader Class Initialized
INFO - 2024-11-06 09:00:05 --> Helper loaded: url_helper
INFO - 2024-11-06 09:00:05 --> Helper loaded: file_helper
INFO - 2024-11-06 09:00:05 --> Helper loaded: security_helper
INFO - 2024-11-06 09:00:05 --> Helper loaded: wpu_helper
INFO - 2024-11-06 09:00:05 --> Database Driver Class Initialized
INFO - 2024-11-06 09:00:09 --> Config Class Initialized
INFO - 2024-11-06 09:00:09 --> Hooks Class Initialized
DEBUG - 2024-11-06 09:00:09 --> UTF-8 Support Enabled
INFO - 2024-11-06 09:00:09 --> Utf8 Class Initialized
INFO - 2024-11-06 09:00:09 --> URI Class Initialized
DEBUG - 2024-11-06 09:00:09 --> No URI present. Default controller set.
INFO - 2024-11-06 09:00:09 --> Router Class Initialized
INFO - 2024-11-06 09:00:09 --> Output Class Initialized
INFO - 2024-11-06 09:00:09 --> Security Class Initialized
DEBUG - 2024-11-06 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 09:00:09 --> Input Class Initialized
INFO - 2024-11-06 09:00:09 --> Language Class Initialized
INFO - 2024-11-06 09:00:09 --> Loader Class Initialized
INFO - 2024-11-06 09:00:09 --> Helper loaded: url_helper
INFO - 2024-11-06 09:00:09 --> Helper loaded: file_helper
INFO - 2024-11-06 09:00:09 --> Helper loaded: security_helper
INFO - 2024-11-06 09:00:09 --> Helper loaded: wpu_helper
INFO - 2024-11-06 09:00:09 --> Database Driver Class Initialized
ERROR - 2024-11-06 09:00:12 --> Unable to connect to the database
INFO - 2024-11-06 09:00:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2024-11-06 09:00:16 --> Unable to connect to the database
INFO - 2024-11-06 09:00:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 23:45:19 --> Config Class Initialized
INFO - 2024-11-06 23:45:19 --> Hooks Class Initialized
DEBUG - 2024-11-06 23:45:19 --> UTF-8 Support Enabled
INFO - 2024-11-06 23:45:19 --> Utf8 Class Initialized
INFO - 2024-11-06 23:45:19 --> URI Class Initialized
DEBUG - 2024-11-06 23:45:19 --> No URI present. Default controller set.
INFO - 2024-11-06 23:45:19 --> Router Class Initialized
INFO - 2024-11-06 23:45:19 --> Output Class Initialized
INFO - 2024-11-06 23:45:19 --> Security Class Initialized
DEBUG - 2024-11-06 23:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 23:45:19 --> Input Class Initialized
INFO - 2024-11-06 23:45:19 --> Language Class Initialized
INFO - 2024-11-06 23:45:19 --> Loader Class Initialized
INFO - 2024-11-06 23:45:19 --> Helper loaded: url_helper
INFO - 2024-11-06 23:45:19 --> Helper loaded: file_helper
INFO - 2024-11-06 23:45:19 --> Helper loaded: security_helper
INFO - 2024-11-06 23:45:19 --> Helper loaded: wpu_helper
INFO - 2024-11-06 23:45:19 --> Database Driver Class Initialized
ERROR - 2024-11-06 23:45:27 --> Unable to connect to the database
INFO - 2024-11-06 23:45:27 --> Language file loaded: language/english/db_lang.php
INFO - 2024-11-06 23:45:27 --> Config Class Initialized
INFO - 2024-11-06 23:45:27 --> Hooks Class Initialized
DEBUG - 2024-11-06 23:45:27 --> UTF-8 Support Enabled
INFO - 2024-11-06 23:45:27 --> Utf8 Class Initialized
INFO - 2024-11-06 23:45:27 --> URI Class Initialized
DEBUG - 2024-11-06 23:45:27 --> No URI present. Default controller set.
INFO - 2024-11-06 23:45:27 --> Router Class Initialized
INFO - 2024-11-06 23:45:27 --> Output Class Initialized
INFO - 2024-11-06 23:45:27 --> Security Class Initialized
DEBUG - 2024-11-06 23:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 23:45:27 --> Input Class Initialized
INFO - 2024-11-06 23:45:27 --> Language Class Initialized
INFO - 2024-11-06 23:45:27 --> Loader Class Initialized
INFO - 2024-11-06 23:45:27 --> Helper loaded: url_helper
INFO - 2024-11-06 23:45:27 --> Helper loaded: file_helper
INFO - 2024-11-06 23:45:27 --> Helper loaded: security_helper
INFO - 2024-11-06 23:45:27 --> Helper loaded: wpu_helper
INFO - 2024-11-06 23:45:27 --> Database Driver Class Initialized
ERROR - 2024-11-06 23:45:34 --> Unable to connect to the database
INFO - 2024-11-06 23:45:34 --> Language file loaded: language/english/db_lang.php
