<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-22 08:47:18 --> Config Class Initialized
INFO - 2024-10-22 08:47:18 --> Hooks Class Initialized
DEBUG - 2024-10-22 08:47:18 --> UTF-8 Support Enabled
INFO - 2024-10-22 08:47:18 --> Utf8 Class Initialized
INFO - 2024-10-22 08:47:18 --> URI Class Initialized
DEBUG - 2024-10-22 08:47:18 --> No URI present. Default controller set.
INFO - 2024-10-22 08:47:18 --> Router Class Initialized
INFO - 2024-10-22 08:47:18 --> Output Class Initialized
INFO - 2024-10-22 08:47:18 --> Security Class Initialized
DEBUG - 2024-10-22 08:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 08:47:18 --> Input Class Initialized
INFO - 2024-10-22 08:47:18 --> Language Class Initialized
INFO - 2024-10-22 08:47:18 --> Loader Class Initialized
INFO - 2024-10-22 08:47:18 --> Helper loaded: url_helper
INFO - 2024-10-22 08:47:18 --> Helper loaded: file_helper
INFO - 2024-10-22 08:47:18 --> Helper loaded: security_helper
INFO - 2024-10-22 08:47:18 --> Helper loaded: wpu_helper
INFO - 2024-10-22 08:47:18 --> Database Driver Class Initialized
INFO - 2024-10-22 08:47:18 --> Email Class Initialized
DEBUG - 2024-10-22 08:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-10-22 08:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-22 08:47:18 --> Helper loaded: form_helper
INFO - 2024-10-22 08:47:18 --> Form Validation Class Initialized
INFO - 2024-10-22 08:47:18 --> Controller Class Initialized
DEBUG - 2024-10-22 08:47:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-22 08:47:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-10-22 08:47:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-10-22 08:47:18 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-10-22 08:47:18 --> Final output sent to browser
DEBUG - 2024-10-22 08:47:18 --> Total execution time: 0.2562
INFO - 2024-10-22 22:09:47 --> Config Class Initialized
INFO - 2024-10-22 22:09:47 --> Hooks Class Initialized
DEBUG - 2024-10-22 22:09:47 --> UTF-8 Support Enabled
INFO - 2024-10-22 22:09:47 --> Utf8 Class Initialized
INFO - 2024-10-22 22:09:47 --> URI Class Initialized
DEBUG - 2024-10-22 22:09:47 --> No URI present. Default controller set.
INFO - 2024-10-22 22:09:47 --> Router Class Initialized
INFO - 2024-10-22 22:09:47 --> Output Class Initialized
INFO - 2024-10-22 22:09:47 --> Security Class Initialized
DEBUG - 2024-10-22 22:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 22:09:47 --> Input Class Initialized
INFO - 2024-10-22 22:09:47 --> Language Class Initialized
INFO - 2024-10-22 22:09:47 --> Loader Class Initialized
INFO - 2024-10-22 22:09:47 --> Helper loaded: url_helper
INFO - 2024-10-22 22:09:47 --> Helper loaded: file_helper
INFO - 2024-10-22 22:09:47 --> Helper loaded: security_helper
INFO - 2024-10-22 22:09:47 --> Helper loaded: wpu_helper
INFO - 2024-10-22 22:09:47 --> Database Driver Class Initialized
ERROR - 2024-10-22 22:09:47 --> Unable to connect to the database
INFO - 2024-10-22 22:09:47 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-22 22:27:53 --> Config Class Initialized
INFO - 2024-10-22 22:27:53 --> Hooks Class Initialized
DEBUG - 2024-10-22 22:27:53 --> UTF-8 Support Enabled
INFO - 2024-10-22 22:27:53 --> Utf8 Class Initialized
INFO - 2024-10-22 22:27:53 --> URI Class Initialized
DEBUG - 2024-10-22 22:27:53 --> No URI present. Default controller set.
INFO - 2024-10-22 22:27:53 --> Router Class Initialized
INFO - 2024-10-22 22:27:53 --> Output Class Initialized
INFO - 2024-10-22 22:27:53 --> Security Class Initialized
DEBUG - 2024-10-22 22:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-22 22:27:53 --> Input Class Initialized
INFO - 2024-10-22 22:27:53 --> Language Class Initialized
INFO - 2024-10-22 22:27:53 --> Loader Class Initialized
INFO - 2024-10-22 22:27:53 --> Helper loaded: url_helper
INFO - 2024-10-22 22:27:53 --> Helper loaded: file_helper
INFO - 2024-10-22 22:27:53 --> Helper loaded: security_helper
INFO - 2024-10-22 22:27:53 --> Helper loaded: wpu_helper
INFO - 2024-10-22 22:27:53 --> Database Driver Class Initialized
ERROR - 2024-10-22 22:27:56 --> Unable to connect to the database
INFO - 2024-10-22 22:27:56 --> Language file loaded: language/english/db_lang.php
