<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-20 01:35:18 --> 404 Page Not Found: 
ERROR - 2024-01-20 01:41:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2024-01-20 01:41:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Detail_model C:\xampp\htdocs\simba\system\core\Loader.php 348
ERROR - 2024-01-20 01:41:34 --> 404 Page Not Found: Assets/img
ERROR - 2024-01-20 02:13:24 --> 404 Page Not Found: 
ERROR - 2024-01-20 02:14:10 --> 404 Page Not Found: 
ERROR - 2024-01-20 02:14:34 --> 404 Page Not Found: Admin/deletepermintaan
ERROR - 2024-01-20 02:16:40 --> Query error: Duplicate entry '1110119999166302' for key 'PRIMARY' - Invalid query: INSERT INTO `tbl_faktur` (`no_faktur`, `id_pesanan`, `id_supplier`, `tanggal_jatuh_tempo`, `tanggal_faktur`, `petugas_penerima`, `bukti_faktur`, `total_pembayaran`, `status`) VALUES ('1110119999166302', '24', ' 3', '2024-01-27', '2024-01-20', 'Gintoki', NULL, '9000000', 'Belum')
ERROR - 2024-01-20 02:30:46 --> 404 Page Not Found: 
