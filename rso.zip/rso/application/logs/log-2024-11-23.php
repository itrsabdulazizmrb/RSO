<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-23 08:06:23 --> Config Class Initialized
INFO - 2024-11-23 08:06:23 --> Hooks Class Initialized
DEBUG - 2024-11-23 08:06:23 --> UTF-8 Support Enabled
INFO - 2024-11-23 08:06:23 --> Utf8 Class Initialized
INFO - 2024-11-23 08:06:23 --> URI Class Initialized
DEBUG - 2024-11-23 08:06:23 --> No URI present. Default controller set.
INFO - 2024-11-23 08:06:23 --> Router Class Initialized
INFO - 2024-11-23 08:06:23 --> Output Class Initialized
INFO - 2024-11-23 08:06:23 --> Security Class Initialized
DEBUG - 2024-11-23 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 08:06:23 --> Input Class Initialized
INFO - 2024-11-23 08:06:23 --> Language Class Initialized
INFO - 2024-11-23 08:06:23 --> Loader Class Initialized
INFO - 2024-11-23 08:06:23 --> Helper loaded: url_helper
INFO - 2024-11-23 08:06:23 --> Helper loaded: file_helper
INFO - 2024-11-23 08:06:23 --> Helper loaded: security_helper
INFO - 2024-11-23 08:06:23 --> Helper loaded: wpu_helper
INFO - 2024-11-23 08:06:23 --> Database Driver Class Initialized
INFO - 2024-11-23 08:06:24 --> Email Class Initialized
DEBUG - 2024-11-23 08:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-23 08:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 08:06:24 --> Helper loaded: form_helper
INFO - 2024-11-23 08:06:24 --> Form Validation Class Initialized
INFO - 2024-11-23 08:06:24 --> Controller Class Initialized
DEBUG - 2024-11-23 08:06:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-23 08:06:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-23 08:06:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-23 08:06:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-23 08:06:24 --> Final output sent to browser
DEBUG - 2024-11-23 08:06:24 --> Total execution time: 0.4517
INFO - 2024-11-23 12:20:15 --> Config Class Initialized
INFO - 2024-11-23 12:20:15 --> Hooks Class Initialized
DEBUG - 2024-11-23 12:20:15 --> UTF-8 Support Enabled
INFO - 2024-11-23 12:20:15 --> Utf8 Class Initialized
INFO - 2024-11-23 12:20:15 --> URI Class Initialized
DEBUG - 2024-11-23 12:20:15 --> No URI present. Default controller set.
INFO - 2024-11-23 12:20:15 --> Router Class Initialized
INFO - 2024-11-23 12:20:15 --> Output Class Initialized
INFO - 2024-11-23 12:20:15 --> Security Class Initialized
DEBUG - 2024-11-23 12:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 12:20:15 --> Input Class Initialized
INFO - 2024-11-23 12:20:15 --> Language Class Initialized
INFO - 2024-11-23 12:20:15 --> Loader Class Initialized
INFO - 2024-11-23 12:20:15 --> Helper loaded: url_helper
INFO - 2024-11-23 12:20:15 --> Helper loaded: file_helper
INFO - 2024-11-23 12:20:15 --> Helper loaded: security_helper
INFO - 2024-11-23 12:20:15 --> Helper loaded: wpu_helper
INFO - 2024-11-23 12:20:15 --> Database Driver Class Initialized
INFO - 2024-11-23 12:20:15 --> Email Class Initialized
DEBUG - 2024-11-23 12:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-23 12:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 12:20:15 --> Helper loaded: form_helper
INFO - 2024-11-23 12:20:15 --> Form Validation Class Initialized
INFO - 2024-11-23 12:20:15 --> Controller Class Initialized
DEBUG - 2024-11-23 12:20:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-23 12:20:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-23 12:20:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-23 12:20:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-23 12:20:15 --> Final output sent to browser
DEBUG - 2024-11-23 12:20:15 --> Total execution time: 0.4364
INFO - 2024-11-23 19:09:06 --> Config Class Initialized
INFO - 2024-11-23 19:09:06 --> Hooks Class Initialized
DEBUG - 2024-11-23 19:09:06 --> UTF-8 Support Enabled
INFO - 2024-11-23 19:09:06 --> Utf8 Class Initialized
INFO - 2024-11-23 19:09:06 --> URI Class Initialized
DEBUG - 2024-11-23 19:09:06 --> No URI present. Default controller set.
INFO - 2024-11-23 19:09:06 --> Router Class Initialized
INFO - 2024-11-23 19:09:06 --> Output Class Initialized
INFO - 2024-11-23 19:09:06 --> Security Class Initialized
DEBUG - 2024-11-23 19:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 19:09:06 --> Input Class Initialized
INFO - 2024-11-23 19:09:06 --> Language Class Initialized
INFO - 2024-11-23 19:09:06 --> Loader Class Initialized
INFO - 2024-11-23 19:09:06 --> Helper loaded: url_helper
INFO - 2024-11-23 19:09:06 --> Helper loaded: file_helper
INFO - 2024-11-23 19:09:06 --> Helper loaded: security_helper
INFO - 2024-11-23 19:09:06 --> Helper loaded: wpu_helper
INFO - 2024-11-23 19:09:06 --> Database Driver Class Initialized
INFO - 2024-11-23 19:09:06 --> Email Class Initialized
DEBUG - 2024-11-23 19:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-23 19:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 19:09:06 --> Helper loaded: form_helper
INFO - 2024-11-23 19:09:06 --> Form Validation Class Initialized
INFO - 2024-11-23 19:09:06 --> Controller Class Initialized
DEBUG - 2024-11-23 19:09:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-23 19:09:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-23 19:09:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-23 19:09:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-23 19:09:06 --> Final output sent to browser
DEBUG - 2024-11-23 19:09:06 --> Total execution time: 0.4096
INFO - 2024-11-23 21:12:20 --> Config Class Initialized
INFO - 2024-11-23 21:12:20 --> Hooks Class Initialized
DEBUG - 2024-11-23 21:12:20 --> UTF-8 Support Enabled
INFO - 2024-11-23 21:12:20 --> Utf8 Class Initialized
INFO - 2024-11-23 21:12:20 --> URI Class Initialized
DEBUG - 2024-11-23 21:12:20 --> No URI present. Default controller set.
INFO - 2024-11-23 21:12:20 --> Router Class Initialized
INFO - 2024-11-23 21:12:20 --> Output Class Initialized
INFO - 2024-11-23 21:12:20 --> Security Class Initialized
DEBUG - 2024-11-23 21:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 21:12:20 --> Input Class Initialized
INFO - 2024-11-23 21:12:20 --> Language Class Initialized
INFO - 2024-11-23 21:12:20 --> Loader Class Initialized
INFO - 2024-11-23 21:12:20 --> Helper loaded: url_helper
INFO - 2024-11-23 21:12:20 --> Helper loaded: file_helper
INFO - 2024-11-23 21:12:20 --> Helper loaded: security_helper
INFO - 2024-11-23 21:12:20 --> Helper loaded: wpu_helper
INFO - 2024-11-23 21:12:20 --> Database Driver Class Initialized
INFO - 2024-11-23 21:12:20 --> Email Class Initialized
DEBUG - 2024-11-23 21:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-23 21:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 21:12:20 --> Helper loaded: form_helper
INFO - 2024-11-23 21:12:20 --> Form Validation Class Initialized
INFO - 2024-11-23 21:12:20 --> Controller Class Initialized
DEBUG - 2024-11-23 21:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-23 21:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-23 21:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-23 21:12:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-23 21:12:20 --> Final output sent to browser
DEBUG - 2024-11-23 21:12:20 --> Total execution time: 0.4757
INFO - 2024-11-23 23:45:45 --> Config Class Initialized
INFO - 2024-11-23 23:45:45 --> Hooks Class Initialized
DEBUG - 2024-11-23 23:45:45 --> UTF-8 Support Enabled
INFO - 2024-11-23 23:45:45 --> Utf8 Class Initialized
INFO - 2024-11-23 23:45:45 --> URI Class Initialized
DEBUG - 2024-11-23 23:45:45 --> No URI present. Default controller set.
INFO - 2024-11-23 23:45:45 --> Router Class Initialized
INFO - 2024-11-23 23:45:45 --> Output Class Initialized
INFO - 2024-11-23 23:45:45 --> Security Class Initialized
DEBUG - 2024-11-23 23:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 23:45:45 --> Input Class Initialized
INFO - 2024-11-23 23:45:45 --> Language Class Initialized
INFO - 2024-11-23 23:45:45 --> Loader Class Initialized
INFO - 2024-11-23 23:45:45 --> Helper loaded: url_helper
INFO - 2024-11-23 23:45:45 --> Helper loaded: file_helper
INFO - 2024-11-23 23:45:45 --> Helper loaded: security_helper
INFO - 2024-11-23 23:45:45 --> Helper loaded: wpu_helper
INFO - 2024-11-23 23:45:45 --> Database Driver Class Initialized
INFO - 2024-11-23 23:45:45 --> Email Class Initialized
DEBUG - 2024-11-23 23:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-11-23 23:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 23:45:45 --> Helper loaded: form_helper
INFO - 2024-11-23 23:45:45 --> Form Validation Class Initialized
INFO - 2024-11-23 23:45:45 --> Controller Class Initialized
DEBUG - 2024-11-23 23:45:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-23 23:45:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-11-23 23:45:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-11-23 23:45:45 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-11-23 23:45:45 --> Final output sent to browser
DEBUG - 2024-11-23 23:45:45 --> Total execution time: 0.4159
