<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-22 00:59:58 --> Config Class Initialized
INFO - 2024-09-22 00:59:58 --> Hooks Class Initialized
DEBUG - 2024-09-22 00:59:58 --> UTF-8 Support Enabled
INFO - 2024-09-22 00:59:58 --> Utf8 Class Initialized
INFO - 2024-09-22 00:59:58 --> URI Class Initialized
DEBUG - 2024-09-22 00:59:58 --> No URI present. Default controller set.
INFO - 2024-09-22 00:59:58 --> Router Class Initialized
INFO - 2024-09-22 00:59:58 --> Output Class Initialized
INFO - 2024-09-22 00:59:58 --> Security Class Initialized
DEBUG - 2024-09-22 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 00:59:58 --> Input Class Initialized
INFO - 2024-09-22 00:59:58 --> Language Class Initialized
INFO - 2024-09-22 00:59:58 --> Loader Class Initialized
INFO - 2024-09-22 00:59:58 --> Helper loaded: url_helper
INFO - 2024-09-22 00:59:58 --> Helper loaded: file_helper
INFO - 2024-09-22 00:59:58 --> Helper loaded: security_helper
INFO - 2024-09-22 00:59:58 --> Helper loaded: wpu_helper
INFO - 2024-09-22 00:59:58 --> Database Driver Class Initialized
INFO - 2024-09-22 00:59:58 --> Email Class Initialized
DEBUG - 2024-09-22 00:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 00:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 00:59:58 --> Helper loaded: form_helper
INFO - 2024-09-22 00:59:58 --> Form Validation Class Initialized
INFO - 2024-09-22 00:59:58 --> Controller Class Initialized
DEBUG - 2024-09-22 00:59:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 00:59:58 --> Config Class Initialized
INFO - 2024-09-22 00:59:58 --> Hooks Class Initialized
DEBUG - 2024-09-22 00:59:58 --> UTF-8 Support Enabled
INFO - 2024-09-22 00:59:58 --> Utf8 Class Initialized
INFO - 2024-09-22 00:59:58 --> URI Class Initialized
INFO - 2024-09-22 00:59:58 --> Router Class Initialized
INFO - 2024-09-22 00:59:58 --> Output Class Initialized
INFO - 2024-09-22 00:59:58 --> Security Class Initialized
DEBUG - 2024-09-22 00:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 00:59:58 --> Input Class Initialized
INFO - 2024-09-22 00:59:58 --> Language Class Initialized
ERROR - 2024-09-22 00:59:58 --> 404 Page Not Found: User/index
INFO - 2024-09-22 01:00:00 --> Config Class Initialized
INFO - 2024-09-22 01:00:00 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:00 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:00 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:00 --> URI Class Initialized
INFO - 2024-09-22 01:00:00 --> Router Class Initialized
INFO - 2024-09-22 01:00:00 --> Output Class Initialized
INFO - 2024-09-22 01:00:00 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:00 --> Input Class Initialized
INFO - 2024-09-22 01:00:00 --> Language Class Initialized
ERROR - 2024-09-22 01:00:00 --> 404 Page Not Found: User/index
INFO - 2024-09-22 01:00:04 --> Config Class Initialized
INFO - 2024-09-22 01:00:04 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:04 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:04 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:04 --> URI Class Initialized
INFO - 2024-09-22 01:00:04 --> Router Class Initialized
INFO - 2024-09-22 01:00:04 --> Output Class Initialized
INFO - 2024-09-22 01:00:04 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:04 --> Input Class Initialized
INFO - 2024-09-22 01:00:04 --> Language Class Initialized
ERROR - 2024-09-22 01:00:04 --> 404 Page Not Found: Antrol/index
INFO - 2024-09-22 01:00:08 --> Config Class Initialized
INFO - 2024-09-22 01:00:08 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:08 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:08 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:08 --> URI Class Initialized
INFO - 2024-09-22 01:00:08 --> Router Class Initialized
INFO - 2024-09-22 01:00:08 --> Output Class Initialized
INFO - 2024-09-22 01:00:08 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:08 --> Input Class Initialized
INFO - 2024-09-22 01:00:08 --> Language Class Initialized
INFO - 2024-09-22 01:00:08 --> Loader Class Initialized
INFO - 2024-09-22 01:00:08 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:08 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:08 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:08 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:08 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:09 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:09 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:09 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:09 --> Controller Class Initialized
DEBUG - 2024-09-22 01:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:09 --> Config Class Initialized
INFO - 2024-09-22 01:00:09 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:09 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:09 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:09 --> URI Class Initialized
INFO - 2024-09-22 01:00:09 --> Router Class Initialized
INFO - 2024-09-22 01:00:09 --> Output Class Initialized
INFO - 2024-09-22 01:00:09 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:09 --> Input Class Initialized
INFO - 2024-09-22 01:00:09 --> Language Class Initialized
INFO - 2024-09-22 01:00:09 --> Loader Class Initialized
INFO - 2024-09-22 01:00:09 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:09 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:09 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:09 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:09 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:10 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:10 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:10 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:10 --> Controller Class Initialized
DEBUG - 2024-09-22 01:00:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-22 01:00:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-22 01:00:10 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-22 01:00:10 --> Final output sent to browser
DEBUG - 2024-09-22 01:00:10 --> Total execution time: 1.2516
INFO - 2024-09-22 01:00:12 --> Config Class Initialized
INFO - 2024-09-22 01:00:12 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:12 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:12 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:12 --> URI Class Initialized
INFO - 2024-09-22 01:00:12 --> Router Class Initialized
INFO - 2024-09-22 01:00:12 --> Output Class Initialized
INFO - 2024-09-22 01:00:12 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:12 --> Input Class Initialized
INFO - 2024-09-22 01:00:12 --> Language Class Initialized
INFO - 2024-09-22 01:00:12 --> Loader Class Initialized
INFO - 2024-09-22 01:00:12 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:12 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:12 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:12 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:12 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:12 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:12 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:12 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:12 --> Controller Class Initialized
DEBUG - 2024-09-22 01:00:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-22 01:00:13 --> Config Class Initialized
INFO - 2024-09-22 01:00:13 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:13 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:13 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:13 --> URI Class Initialized
INFO - 2024-09-22 01:00:13 --> Router Class Initialized
INFO - 2024-09-22 01:00:13 --> Output Class Initialized
INFO - 2024-09-22 01:00:13 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:13 --> Input Class Initialized
INFO - 2024-09-22 01:00:13 --> Language Class Initialized
INFO - 2024-09-22 01:00:13 --> Loader Class Initialized
INFO - 2024-09-22 01:00:13 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:13 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:13 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:13 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:13 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:13 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:13 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:13 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:13 --> Controller Class Initialized
INFO - 2024-09-22 01:00:13 --> Model "Antrol_model" initialized
DEBUG - 2024-09-22 01:00:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-22 01:00:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-22 01:00:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-22 01:00:13 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-22 01:00:13 --> Final output sent to browser
DEBUG - 2024-09-22 01:00:13 --> Total execution time: 0.6553
INFO - 2024-09-22 01:00:17 --> Config Class Initialized
INFO - 2024-09-22 01:00:17 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:17 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:17 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:17 --> URI Class Initialized
INFO - 2024-09-22 01:00:17 --> Router Class Initialized
INFO - 2024-09-22 01:00:17 --> Output Class Initialized
INFO - 2024-09-22 01:00:17 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:17 --> Input Class Initialized
INFO - 2024-09-22 01:00:17 --> Language Class Initialized
INFO - 2024-09-22 01:00:17 --> Loader Class Initialized
INFO - 2024-09-22 01:00:17 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:17 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:17 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:17 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:17 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:17 --> Controller Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:17 --> Config Class Initialized
INFO - 2024-09-22 01:00:17 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:00:17 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:00:17 --> Utf8 Class Initialized
INFO - 2024-09-22 01:00:17 --> URI Class Initialized
INFO - 2024-09-22 01:00:17 --> Router Class Initialized
INFO - 2024-09-22 01:00:17 --> Output Class Initialized
INFO - 2024-09-22 01:00:17 --> Security Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:00:17 --> Input Class Initialized
INFO - 2024-09-22 01:00:17 --> Language Class Initialized
INFO - 2024-09-22 01:00:17 --> Loader Class Initialized
INFO - 2024-09-22 01:00:17 --> Helper loaded: url_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: file_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: security_helper
INFO - 2024-09-22 01:00:17 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:00:17 --> Database Driver Class Initialized
INFO - 2024-09-22 01:00:17 --> Email Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:00:17 --> Helper loaded: form_helper
INFO - 2024-09-22 01:00:17 --> Form Validation Class Initialized
INFO - 2024-09-22 01:00:17 --> Controller Class Initialized
DEBUG - 2024-09-22 01:00:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:00:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-22 01:00:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-22 01:00:17 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-22 01:00:17 --> Final output sent to browser
DEBUG - 2024-09-22 01:00:17 --> Total execution time: 0.2135
INFO - 2024-09-22 01:08:28 --> Config Class Initialized
INFO - 2024-09-22 01:08:28 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:08:28 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:08:28 --> Utf8 Class Initialized
INFO - 2024-09-22 01:08:28 --> URI Class Initialized
DEBUG - 2024-09-22 01:08:28 --> No URI present. Default controller set.
INFO - 2024-09-22 01:08:28 --> Router Class Initialized
INFO - 2024-09-22 01:08:28 --> Output Class Initialized
INFO - 2024-09-22 01:08:28 --> Security Class Initialized
DEBUG - 2024-09-22 01:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:08:28 --> Input Class Initialized
INFO - 2024-09-22 01:08:28 --> Language Class Initialized
INFO - 2024-09-22 01:08:28 --> Loader Class Initialized
INFO - 2024-09-22 01:08:28 --> Helper loaded: url_helper
INFO - 2024-09-22 01:08:28 --> Helper loaded: file_helper
INFO - 2024-09-22 01:08:28 --> Helper loaded: security_helper
INFO - 2024-09-22 01:08:28 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:08:28 --> Database Driver Class Initialized
INFO - 2024-09-22 01:08:28 --> Email Class Initialized
DEBUG - 2024-09-22 01:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-22 01:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 01:08:28 --> Helper loaded: form_helper
INFO - 2024-09-22 01:08:28 --> Form Validation Class Initialized
INFO - 2024-09-22 01:08:28 --> Controller Class Initialized
DEBUG - 2024-09-22 01:08:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-22 01:08:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-22 01:08:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-22 01:08:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-22 01:08:28 --> Final output sent to browser
DEBUG - 2024-09-22 01:08:28 --> Total execution time: 0.2176
INFO - 2024-09-22 01:33:19 --> Config Class Initialized
INFO - 2024-09-22 01:33:19 --> Hooks Class Initialized
DEBUG - 2024-09-22 01:33:19 --> UTF-8 Support Enabled
INFO - 2024-09-22 01:33:19 --> Utf8 Class Initialized
INFO - 2024-09-22 01:33:19 --> URI Class Initialized
DEBUG - 2024-09-22 01:33:19 --> No URI present. Default controller set.
INFO - 2024-09-22 01:33:19 --> Router Class Initialized
INFO - 2024-09-22 01:33:19 --> Output Class Initialized
INFO - 2024-09-22 01:33:19 --> Security Class Initialized
DEBUG - 2024-09-22 01:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 01:33:19 --> Input Class Initialized
INFO - 2024-09-22 01:33:19 --> Language Class Initialized
INFO - 2024-09-22 01:33:19 --> Loader Class Initialized
INFO - 2024-09-22 01:33:19 --> Helper loaded: url_helper
INFO - 2024-09-22 01:33:19 --> Helper loaded: file_helper
INFO - 2024-09-22 01:33:19 --> Helper loaded: security_helper
INFO - 2024-09-22 01:33:19 --> Helper loaded: wpu_helper
INFO - 2024-09-22 01:33:19 --> Database Driver Class Initialized
INFO - 2024-09-22 09:07:32 --> Config Class Initialized
INFO - 2024-09-22 09:07:32 --> Hooks Class Initialized
DEBUG - 2024-09-22 09:07:32 --> UTF-8 Support Enabled
INFO - 2024-09-22 09:07:32 --> Utf8 Class Initialized
INFO - 2024-09-22 09:07:32 --> URI Class Initialized
DEBUG - 2024-09-22 09:07:32 --> No URI present. Default controller set.
INFO - 2024-09-22 09:07:32 --> Router Class Initialized
INFO - 2024-09-22 09:07:32 --> Output Class Initialized
INFO - 2024-09-22 09:07:32 --> Security Class Initialized
DEBUG - 2024-09-22 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 09:07:32 --> Input Class Initialized
INFO - 2024-09-22 09:07:32 --> Language Class Initialized
INFO - 2024-09-22 09:07:32 --> Loader Class Initialized
INFO - 2024-09-22 09:07:32 --> Helper loaded: url_helper
INFO - 2024-09-22 09:07:32 --> Helper loaded: file_helper
INFO - 2024-09-22 09:07:32 --> Helper loaded: security_helper
INFO - 2024-09-22 09:07:32 --> Helper loaded: wpu_helper
INFO - 2024-09-22 09:07:32 --> Database Driver Class Initialized
ERROR - 2024-09-22 09:08:02 --> Unable to connect to the database
INFO - 2024-09-22 09:08:02 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-22 12:08:30 --> Config Class Initialized
INFO - 2024-09-22 12:08:30 --> Hooks Class Initialized
DEBUG - 2024-09-22 12:08:30 --> UTF-8 Support Enabled
INFO - 2024-09-22 12:08:30 --> Utf8 Class Initialized
INFO - 2024-09-22 12:08:30 --> URI Class Initialized
DEBUG - 2024-09-22 12:08:30 --> No URI present. Default controller set.
INFO - 2024-09-22 12:08:30 --> Router Class Initialized
INFO - 2024-09-22 12:08:30 --> Output Class Initialized
INFO - 2024-09-22 12:08:30 --> Security Class Initialized
DEBUG - 2024-09-22 12:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 12:08:30 --> Input Class Initialized
INFO - 2024-09-22 12:08:30 --> Language Class Initialized
INFO - 2024-09-22 12:08:30 --> Loader Class Initialized
INFO - 2024-09-22 12:08:30 --> Helper loaded: url_helper
INFO - 2024-09-22 12:08:30 --> Helper loaded: file_helper
INFO - 2024-09-22 12:08:30 --> Helper loaded: security_helper
INFO - 2024-09-22 12:08:30 --> Helper loaded: wpu_helper
INFO - 2024-09-22 12:08:30 --> Database Driver Class Initialized
