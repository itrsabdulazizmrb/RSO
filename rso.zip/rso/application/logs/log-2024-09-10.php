<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-10 00:17:37 --> Config Class Initialized
INFO - 2024-09-10 00:17:37 --> Hooks Class Initialized
DEBUG - 2024-09-10 00:17:37 --> UTF-8 Support Enabled
INFO - 2024-09-10 00:17:37 --> Utf8 Class Initialized
INFO - 2024-09-10 00:17:37 --> URI Class Initialized
DEBUG - 2024-09-10 00:17:37 --> No URI present. Default controller set.
INFO - 2024-09-10 00:17:37 --> Router Class Initialized
INFO - 2024-09-10 00:17:37 --> Output Class Initialized
INFO - 2024-09-10 00:17:37 --> Security Class Initialized
DEBUG - 2024-09-10 00:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 00:17:37 --> Input Class Initialized
INFO - 2024-09-10 00:17:37 --> Language Class Initialized
INFO - 2024-09-10 00:17:37 --> Loader Class Initialized
INFO - 2024-09-10 00:17:37 --> Helper loaded: url_helper
INFO - 2024-09-10 00:17:37 --> Helper loaded: file_helper
INFO - 2024-09-10 00:17:37 --> Helper loaded: security_helper
INFO - 2024-09-10 00:17:37 --> Helper loaded: wpu_helper
INFO - 2024-09-10 00:17:37 --> Database Driver Class Initialized
INFO - 2024-09-10 00:17:38 --> Email Class Initialized
DEBUG - 2024-09-10 00:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 00:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 00:17:38 --> Helper loaded: form_helper
INFO - 2024-09-10 00:17:38 --> Form Validation Class Initialized
INFO - 2024-09-10 00:17:38 --> Controller Class Initialized
DEBUG - 2024-09-10 00:17:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 00:17:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 00:17:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 00:17:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 00:17:38 --> Final output sent to browser
DEBUG - 2024-09-10 00:17:38 --> Total execution time: 0.2329
INFO - 2024-09-10 00:47:00 --> Config Class Initialized
INFO - 2024-09-10 00:47:00 --> Hooks Class Initialized
DEBUG - 2024-09-10 00:47:00 --> UTF-8 Support Enabled
INFO - 2024-09-10 00:47:00 --> Utf8 Class Initialized
INFO - 2024-09-10 00:47:00 --> URI Class Initialized
DEBUG - 2024-09-10 00:47:00 --> No URI present. Default controller set.
INFO - 2024-09-10 00:47:00 --> Router Class Initialized
INFO - 2024-09-10 00:47:00 --> Output Class Initialized
INFO - 2024-09-10 00:47:00 --> Security Class Initialized
DEBUG - 2024-09-10 00:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 00:47:00 --> Input Class Initialized
INFO - 2024-09-10 00:47:00 --> Language Class Initialized
INFO - 2024-09-10 00:47:00 --> Loader Class Initialized
INFO - 2024-09-10 00:47:00 --> Helper loaded: url_helper
INFO - 2024-09-10 00:47:00 --> Helper loaded: file_helper
INFO - 2024-09-10 00:47:00 --> Helper loaded: security_helper
INFO - 2024-09-10 00:47:00 --> Helper loaded: wpu_helper
INFO - 2024-09-10 00:47:00 --> Database Driver Class Initialized
INFO - 2024-09-10 00:47:00 --> Email Class Initialized
DEBUG - 2024-09-10 00:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 00:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 00:47:00 --> Helper loaded: form_helper
INFO - 2024-09-10 00:47:00 --> Form Validation Class Initialized
INFO - 2024-09-10 00:47:00 --> Controller Class Initialized
DEBUG - 2024-09-10 00:47:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 00:47:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 00:47:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 00:47:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 00:47:00 --> Final output sent to browser
DEBUG - 2024-09-10 00:47:00 --> Total execution time: 0.2287
INFO - 2024-09-10 01:18:25 --> Config Class Initialized
INFO - 2024-09-10 01:18:25 --> Hooks Class Initialized
DEBUG - 2024-09-10 01:18:25 --> UTF-8 Support Enabled
INFO - 2024-09-10 01:18:25 --> Utf8 Class Initialized
INFO - 2024-09-10 01:18:25 --> URI Class Initialized
DEBUG - 2024-09-10 01:18:25 --> No URI present. Default controller set.
INFO - 2024-09-10 01:18:25 --> Router Class Initialized
INFO - 2024-09-10 01:18:25 --> Output Class Initialized
INFO - 2024-09-10 01:18:25 --> Security Class Initialized
DEBUG - 2024-09-10 01:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 01:18:25 --> Input Class Initialized
INFO - 2024-09-10 01:18:25 --> Language Class Initialized
INFO - 2024-09-10 01:18:25 --> Loader Class Initialized
INFO - 2024-09-10 01:18:25 --> Helper loaded: url_helper
INFO - 2024-09-10 01:18:25 --> Helper loaded: file_helper
INFO - 2024-09-10 01:18:25 --> Helper loaded: security_helper
INFO - 2024-09-10 01:18:25 --> Helper loaded: wpu_helper
INFO - 2024-09-10 01:18:25 --> Database Driver Class Initialized
INFO - 2024-09-10 01:18:25 --> Email Class Initialized
DEBUG - 2024-09-10 01:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 01:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 01:18:25 --> Helper loaded: form_helper
INFO - 2024-09-10 01:18:25 --> Form Validation Class Initialized
INFO - 2024-09-10 01:18:25 --> Controller Class Initialized
DEBUG - 2024-09-10 01:18:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 01:18:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 01:18:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 01:18:25 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 01:18:25 --> Final output sent to browser
DEBUG - 2024-09-10 01:18:25 --> Total execution time: 0.2348
INFO - 2024-09-10 01:45:44 --> Config Class Initialized
INFO - 2024-09-10 01:45:44 --> Hooks Class Initialized
DEBUG - 2024-09-10 01:45:44 --> UTF-8 Support Enabled
INFO - 2024-09-10 01:45:44 --> Utf8 Class Initialized
INFO - 2024-09-10 01:45:44 --> URI Class Initialized
DEBUG - 2024-09-10 01:45:44 --> No URI present. Default controller set.
INFO - 2024-09-10 01:45:44 --> Router Class Initialized
INFO - 2024-09-10 01:45:44 --> Output Class Initialized
INFO - 2024-09-10 01:45:44 --> Security Class Initialized
DEBUG - 2024-09-10 01:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 01:45:44 --> Input Class Initialized
INFO - 2024-09-10 01:45:44 --> Language Class Initialized
INFO - 2024-09-10 01:45:44 --> Loader Class Initialized
INFO - 2024-09-10 01:45:44 --> Helper loaded: url_helper
INFO - 2024-09-10 01:45:44 --> Helper loaded: file_helper
INFO - 2024-09-10 01:45:44 --> Helper loaded: security_helper
INFO - 2024-09-10 01:45:44 --> Helper loaded: wpu_helper
INFO - 2024-09-10 01:45:44 --> Database Driver Class Initialized
INFO - 2024-09-10 01:45:44 --> Email Class Initialized
DEBUG - 2024-09-10 01:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 01:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 01:45:44 --> Helper loaded: form_helper
INFO - 2024-09-10 01:45:44 --> Form Validation Class Initialized
INFO - 2024-09-10 01:45:44 --> Controller Class Initialized
DEBUG - 2024-09-10 01:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 01:45:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 01:45:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 01:45:44 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 01:45:44 --> Final output sent to browser
DEBUG - 2024-09-10 01:45:44 --> Total execution time: 0.2333
INFO - 2024-09-10 02:19:58 --> Config Class Initialized
INFO - 2024-09-10 02:19:58 --> Hooks Class Initialized
DEBUG - 2024-09-10 02:19:58 --> UTF-8 Support Enabled
INFO - 2024-09-10 02:19:58 --> Utf8 Class Initialized
INFO - 2024-09-10 02:19:58 --> URI Class Initialized
DEBUG - 2024-09-10 02:19:58 --> No URI present. Default controller set.
INFO - 2024-09-10 02:19:58 --> Router Class Initialized
INFO - 2024-09-10 02:19:58 --> Output Class Initialized
INFO - 2024-09-10 02:19:58 --> Security Class Initialized
DEBUG - 2024-09-10 02:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 02:19:58 --> Input Class Initialized
INFO - 2024-09-10 02:19:58 --> Language Class Initialized
INFO - 2024-09-10 02:19:58 --> Loader Class Initialized
INFO - 2024-09-10 02:19:58 --> Helper loaded: url_helper
INFO - 2024-09-10 02:19:58 --> Helper loaded: file_helper
INFO - 2024-09-10 02:19:58 --> Helper loaded: security_helper
INFO - 2024-09-10 02:19:58 --> Helper loaded: wpu_helper
INFO - 2024-09-10 02:19:58 --> Database Driver Class Initialized
INFO - 2024-09-10 02:19:58 --> Email Class Initialized
DEBUG - 2024-09-10 02:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 02:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 02:19:58 --> Helper loaded: form_helper
INFO - 2024-09-10 02:19:58 --> Form Validation Class Initialized
INFO - 2024-09-10 02:19:58 --> Controller Class Initialized
DEBUG - 2024-09-10 02:19:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 02:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 02:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 02:19:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 02:19:58 --> Final output sent to browser
DEBUG - 2024-09-10 02:19:58 --> Total execution time: 0.2307
INFO - 2024-09-10 02:27:36 --> Config Class Initialized
INFO - 2024-09-10 02:27:36 --> Hooks Class Initialized
DEBUG - 2024-09-10 02:27:36 --> UTF-8 Support Enabled
INFO - 2024-09-10 02:27:36 --> Utf8 Class Initialized
INFO - 2024-09-10 02:27:36 --> URI Class Initialized
DEBUG - 2024-09-10 02:27:36 --> No URI present. Default controller set.
INFO - 2024-09-10 02:27:36 --> Router Class Initialized
INFO - 2024-09-10 02:27:36 --> Output Class Initialized
INFO - 2024-09-10 02:27:36 --> Security Class Initialized
DEBUG - 2024-09-10 02:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 02:27:36 --> Input Class Initialized
INFO - 2024-09-10 02:27:36 --> Language Class Initialized
INFO - 2024-09-10 02:27:36 --> Loader Class Initialized
INFO - 2024-09-10 02:27:36 --> Helper loaded: url_helper
INFO - 2024-09-10 02:27:36 --> Helper loaded: file_helper
INFO - 2024-09-10 02:27:36 --> Helper loaded: security_helper
INFO - 2024-09-10 02:27:36 --> Helper loaded: wpu_helper
INFO - 2024-09-10 02:27:36 --> Database Driver Class Initialized
INFO - 2024-09-10 02:27:38 --> Email Class Initialized
DEBUG - 2024-09-10 02:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 02:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 02:27:38 --> Helper loaded: form_helper
INFO - 2024-09-10 02:27:38 --> Form Validation Class Initialized
INFO - 2024-09-10 02:27:38 --> Controller Class Initialized
DEBUG - 2024-09-10 02:27:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 02:27:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 02:27:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 02:27:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 02:27:38 --> Final output sent to browser
DEBUG - 2024-09-10 02:27:38 --> Total execution time: 1.6798
INFO - 2024-09-10 02:45:34 --> Config Class Initialized
INFO - 2024-09-10 02:45:34 --> Hooks Class Initialized
DEBUG - 2024-09-10 02:45:34 --> UTF-8 Support Enabled
INFO - 2024-09-10 02:45:34 --> Utf8 Class Initialized
INFO - 2024-09-10 02:45:34 --> URI Class Initialized
DEBUG - 2024-09-10 02:45:34 --> No URI present. Default controller set.
INFO - 2024-09-10 02:45:34 --> Router Class Initialized
INFO - 2024-09-10 02:45:34 --> Output Class Initialized
INFO - 2024-09-10 02:45:34 --> Security Class Initialized
DEBUG - 2024-09-10 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 02:45:34 --> Input Class Initialized
INFO - 2024-09-10 02:45:34 --> Language Class Initialized
INFO - 2024-09-10 02:45:34 --> Loader Class Initialized
INFO - 2024-09-10 02:45:34 --> Helper loaded: url_helper
INFO - 2024-09-10 02:45:34 --> Helper loaded: file_helper
INFO - 2024-09-10 02:45:34 --> Helper loaded: security_helper
INFO - 2024-09-10 02:45:34 --> Helper loaded: wpu_helper
INFO - 2024-09-10 02:45:34 --> Database Driver Class Initialized
INFO - 2024-09-10 02:45:35 --> Email Class Initialized
DEBUG - 2024-09-10 02:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 02:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 02:45:35 --> Helper loaded: form_helper
INFO - 2024-09-10 02:45:35 --> Form Validation Class Initialized
INFO - 2024-09-10 02:45:35 --> Controller Class Initialized
DEBUG - 2024-09-10 02:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 02:45:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 02:45:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 02:45:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 02:45:35 --> Final output sent to browser
DEBUG - 2024-09-10 02:45:35 --> Total execution time: 0.7275
INFO - 2024-09-10 03:15:57 --> Config Class Initialized
INFO - 2024-09-10 03:15:57 --> Hooks Class Initialized
DEBUG - 2024-09-10 03:15:57 --> UTF-8 Support Enabled
INFO - 2024-09-10 03:15:57 --> Utf8 Class Initialized
INFO - 2024-09-10 03:15:57 --> URI Class Initialized
DEBUG - 2024-09-10 03:15:57 --> No URI present. Default controller set.
INFO - 2024-09-10 03:15:57 --> Router Class Initialized
INFO - 2024-09-10 03:15:57 --> Output Class Initialized
INFO - 2024-09-10 03:15:57 --> Security Class Initialized
DEBUG - 2024-09-10 03:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 03:15:57 --> Input Class Initialized
INFO - 2024-09-10 03:15:57 --> Language Class Initialized
INFO - 2024-09-10 03:15:57 --> Loader Class Initialized
INFO - 2024-09-10 03:15:57 --> Helper loaded: url_helper
INFO - 2024-09-10 03:15:57 --> Helper loaded: file_helper
INFO - 2024-09-10 03:15:57 --> Helper loaded: security_helper
INFO - 2024-09-10 03:15:57 --> Helper loaded: wpu_helper
INFO - 2024-09-10 03:15:57 --> Database Driver Class Initialized
INFO - 2024-09-10 03:15:58 --> Email Class Initialized
DEBUG - 2024-09-10 03:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 03:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 03:15:58 --> Helper loaded: form_helper
INFO - 2024-09-10 03:15:58 --> Form Validation Class Initialized
INFO - 2024-09-10 03:15:58 --> Controller Class Initialized
DEBUG - 2024-09-10 03:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 03:15:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 03:15:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 03:15:58 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 03:15:58 --> Final output sent to browser
DEBUG - 2024-09-10 03:15:58 --> Total execution time: 1.2007
INFO - 2024-09-10 03:45:19 --> Config Class Initialized
INFO - 2024-09-10 03:45:19 --> Hooks Class Initialized
DEBUG - 2024-09-10 03:45:19 --> UTF-8 Support Enabled
INFO - 2024-09-10 03:45:19 --> Utf8 Class Initialized
INFO - 2024-09-10 03:45:19 --> URI Class Initialized
DEBUG - 2024-09-10 03:45:19 --> No URI present. Default controller set.
INFO - 2024-09-10 03:45:19 --> Router Class Initialized
INFO - 2024-09-10 03:45:19 --> Output Class Initialized
INFO - 2024-09-10 03:45:19 --> Security Class Initialized
DEBUG - 2024-09-10 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 03:45:19 --> Input Class Initialized
INFO - 2024-09-10 03:45:19 --> Language Class Initialized
INFO - 2024-09-10 03:45:19 --> Loader Class Initialized
INFO - 2024-09-10 03:45:19 --> Helper loaded: url_helper
INFO - 2024-09-10 03:45:19 --> Helper loaded: file_helper
INFO - 2024-09-10 03:45:19 --> Helper loaded: security_helper
INFO - 2024-09-10 03:45:19 --> Helper loaded: wpu_helper
INFO - 2024-09-10 03:45:19 --> Database Driver Class Initialized
INFO - 2024-09-10 03:45:19 --> Email Class Initialized
DEBUG - 2024-09-10 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 03:45:19 --> Helper loaded: form_helper
INFO - 2024-09-10 03:45:19 --> Form Validation Class Initialized
INFO - 2024-09-10 03:45:19 --> Controller Class Initialized
DEBUG - 2024-09-10 03:45:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 03:45:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 03:45:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 03:45:19 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 03:45:19 --> Final output sent to browser
DEBUG - 2024-09-10 03:45:19 --> Total execution time: 0.2243
INFO - 2024-09-10 04:19:39 --> Config Class Initialized
INFO - 2024-09-10 04:19:39 --> Hooks Class Initialized
DEBUG - 2024-09-10 04:19:39 --> UTF-8 Support Enabled
INFO - 2024-09-10 04:19:39 --> Utf8 Class Initialized
INFO - 2024-09-10 04:19:39 --> URI Class Initialized
DEBUG - 2024-09-10 04:19:39 --> No URI present. Default controller set.
INFO - 2024-09-10 04:19:39 --> Router Class Initialized
INFO - 2024-09-10 04:19:39 --> Output Class Initialized
INFO - 2024-09-10 04:19:39 --> Security Class Initialized
DEBUG - 2024-09-10 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 04:19:39 --> Input Class Initialized
INFO - 2024-09-10 04:19:39 --> Language Class Initialized
INFO - 2024-09-10 04:19:39 --> Loader Class Initialized
INFO - 2024-09-10 04:19:39 --> Helper loaded: url_helper
INFO - 2024-09-10 04:19:39 --> Helper loaded: file_helper
INFO - 2024-09-10 04:19:39 --> Helper loaded: security_helper
INFO - 2024-09-10 04:19:39 --> Helper loaded: wpu_helper
INFO - 2024-09-10 04:19:39 --> Database Driver Class Initialized
INFO - 2024-09-10 04:19:40 --> Email Class Initialized
DEBUG - 2024-09-10 04:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 04:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 04:19:40 --> Helper loaded: form_helper
INFO - 2024-09-10 04:19:40 --> Form Validation Class Initialized
INFO - 2024-09-10 04:19:40 --> Controller Class Initialized
DEBUG - 2024-09-10 04:19:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 04:19:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 04:19:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 04:19:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 04:19:40 --> Final output sent to browser
DEBUG - 2024-09-10 04:19:40 --> Total execution time: 0.2326
INFO - 2024-09-10 04:47:12 --> Config Class Initialized
INFO - 2024-09-10 04:47:12 --> Hooks Class Initialized
DEBUG - 2024-09-10 04:47:12 --> UTF-8 Support Enabled
INFO - 2024-09-10 04:47:12 --> Utf8 Class Initialized
INFO - 2024-09-10 04:47:12 --> URI Class Initialized
DEBUG - 2024-09-10 04:47:12 --> No URI present. Default controller set.
INFO - 2024-09-10 04:47:12 --> Router Class Initialized
INFO - 2024-09-10 04:47:12 --> Output Class Initialized
INFO - 2024-09-10 04:47:12 --> Security Class Initialized
DEBUG - 2024-09-10 04:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 04:47:12 --> Input Class Initialized
INFO - 2024-09-10 04:47:12 --> Language Class Initialized
INFO - 2024-09-10 04:47:12 --> Loader Class Initialized
INFO - 2024-09-10 04:47:12 --> Helper loaded: url_helper
INFO - 2024-09-10 04:47:12 --> Helper loaded: file_helper
INFO - 2024-09-10 04:47:12 --> Helper loaded: security_helper
INFO - 2024-09-10 04:47:12 --> Helper loaded: wpu_helper
INFO - 2024-09-10 04:47:12 --> Database Driver Class Initialized
INFO - 2024-09-10 04:47:12 --> Email Class Initialized
DEBUG - 2024-09-10 04:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 04:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 04:47:12 --> Helper loaded: form_helper
INFO - 2024-09-10 04:47:12 --> Form Validation Class Initialized
INFO - 2024-09-10 04:47:12 --> Controller Class Initialized
DEBUG - 2024-09-10 04:47:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 04:47:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 04:47:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 04:47:12 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 04:47:12 --> Final output sent to browser
DEBUG - 2024-09-10 04:47:12 --> Total execution time: 0.2652
INFO - 2024-09-10 05:17:01 --> Config Class Initialized
INFO - 2024-09-10 05:17:01 --> Hooks Class Initialized
DEBUG - 2024-09-10 05:17:01 --> UTF-8 Support Enabled
INFO - 2024-09-10 05:17:01 --> Utf8 Class Initialized
INFO - 2024-09-10 05:17:01 --> URI Class Initialized
DEBUG - 2024-09-10 05:17:01 --> No URI present. Default controller set.
INFO - 2024-09-10 05:17:01 --> Router Class Initialized
INFO - 2024-09-10 05:17:01 --> Output Class Initialized
INFO - 2024-09-10 05:17:01 --> Security Class Initialized
DEBUG - 2024-09-10 05:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 05:17:01 --> Input Class Initialized
INFO - 2024-09-10 05:17:01 --> Language Class Initialized
INFO - 2024-09-10 05:17:01 --> Loader Class Initialized
INFO - 2024-09-10 05:17:01 --> Helper loaded: url_helper
INFO - 2024-09-10 05:17:01 --> Helper loaded: file_helper
INFO - 2024-09-10 05:17:01 --> Helper loaded: security_helper
INFO - 2024-09-10 05:17:01 --> Helper loaded: wpu_helper
INFO - 2024-09-10 05:17:01 --> Database Driver Class Initialized
INFO - 2024-09-10 05:17:01 --> Email Class Initialized
DEBUG - 2024-09-10 05:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 05:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 05:17:01 --> Helper loaded: form_helper
INFO - 2024-09-10 05:17:01 --> Form Validation Class Initialized
INFO - 2024-09-10 05:17:01 --> Controller Class Initialized
DEBUG - 2024-09-10 05:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 05:17:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 05:17:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 05:17:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 05:17:01 --> Final output sent to browser
DEBUG - 2024-09-10 05:17:01 --> Total execution time: 0.2566
INFO - 2024-09-10 05:28:41 --> Config Class Initialized
INFO - 2024-09-10 05:28:41 --> Hooks Class Initialized
DEBUG - 2024-09-10 05:28:41 --> UTF-8 Support Enabled
INFO - 2024-09-10 05:28:41 --> Utf8 Class Initialized
INFO - 2024-09-10 05:28:41 --> URI Class Initialized
DEBUG - 2024-09-10 05:28:41 --> No URI present. Default controller set.
INFO - 2024-09-10 05:28:41 --> Router Class Initialized
INFO - 2024-09-10 05:28:41 --> Output Class Initialized
INFO - 2024-09-10 05:28:41 --> Security Class Initialized
DEBUG - 2024-09-10 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 05:28:41 --> Input Class Initialized
INFO - 2024-09-10 05:28:41 --> Language Class Initialized
INFO - 2024-09-10 05:28:41 --> Loader Class Initialized
INFO - 2024-09-10 05:28:41 --> Helper loaded: url_helper
INFO - 2024-09-10 05:28:41 --> Helper loaded: file_helper
INFO - 2024-09-10 05:28:41 --> Helper loaded: security_helper
INFO - 2024-09-10 05:28:41 --> Helper loaded: wpu_helper
INFO - 2024-09-10 05:28:41 --> Database Driver Class Initialized
INFO - 2024-09-10 05:28:41 --> Email Class Initialized
DEBUG - 2024-09-10 05:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 05:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 05:28:41 --> Helper loaded: form_helper
INFO - 2024-09-10 05:28:41 --> Form Validation Class Initialized
INFO - 2024-09-10 05:28:41 --> Controller Class Initialized
DEBUG - 2024-09-10 05:28:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 05:28:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 05:28:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 05:28:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 05:28:41 --> Final output sent to browser
DEBUG - 2024-09-10 05:28:41 --> Total execution time: 0.2262
INFO - 2024-09-10 05:50:59 --> Config Class Initialized
INFO - 2024-09-10 05:50:59 --> Hooks Class Initialized
DEBUG - 2024-09-10 05:50:59 --> UTF-8 Support Enabled
INFO - 2024-09-10 05:50:59 --> Utf8 Class Initialized
INFO - 2024-09-10 05:50:59 --> URI Class Initialized
DEBUG - 2024-09-10 05:50:59 --> No URI present. Default controller set.
INFO - 2024-09-10 05:50:59 --> Router Class Initialized
INFO - 2024-09-10 05:50:59 --> Output Class Initialized
INFO - 2024-09-10 05:50:59 --> Security Class Initialized
DEBUG - 2024-09-10 05:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 05:50:59 --> Input Class Initialized
INFO - 2024-09-10 05:50:59 --> Language Class Initialized
INFO - 2024-09-10 05:50:59 --> Loader Class Initialized
INFO - 2024-09-10 05:50:59 --> Helper loaded: url_helper
INFO - 2024-09-10 05:50:59 --> Helper loaded: file_helper
INFO - 2024-09-10 05:50:59 --> Helper loaded: security_helper
INFO - 2024-09-10 05:50:59 --> Helper loaded: wpu_helper
INFO - 2024-09-10 05:50:59 --> Database Driver Class Initialized
INFO - 2024-09-10 05:51:01 --> Email Class Initialized
DEBUG - 2024-09-10 05:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 05:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 05:51:01 --> Helper loaded: form_helper
INFO - 2024-09-10 05:51:01 --> Form Validation Class Initialized
INFO - 2024-09-10 05:51:01 --> Controller Class Initialized
DEBUG - 2024-09-10 05:51:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 05:51:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 05:51:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 05:51:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 05:51:01 --> Final output sent to browser
DEBUG - 2024-09-10 05:51:01 --> Total execution time: 1.2753
INFO - 2024-09-10 06:17:53 --> Config Class Initialized
INFO - 2024-09-10 06:17:53 --> Hooks Class Initialized
DEBUG - 2024-09-10 06:17:53 --> UTF-8 Support Enabled
INFO - 2024-09-10 06:17:53 --> Utf8 Class Initialized
INFO - 2024-09-10 06:17:53 --> URI Class Initialized
DEBUG - 2024-09-10 06:17:53 --> No URI present. Default controller set.
INFO - 2024-09-10 06:17:53 --> Router Class Initialized
INFO - 2024-09-10 06:17:53 --> Output Class Initialized
INFO - 2024-09-10 06:17:53 --> Security Class Initialized
DEBUG - 2024-09-10 06:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 06:17:53 --> Input Class Initialized
INFO - 2024-09-10 06:17:53 --> Language Class Initialized
INFO - 2024-09-10 06:17:53 --> Loader Class Initialized
INFO - 2024-09-10 06:17:53 --> Helper loaded: url_helper
INFO - 2024-09-10 06:17:53 --> Helper loaded: file_helper
INFO - 2024-09-10 06:17:53 --> Helper loaded: security_helper
INFO - 2024-09-10 06:17:53 --> Helper loaded: wpu_helper
INFO - 2024-09-10 06:17:53 --> Database Driver Class Initialized
INFO - 2024-09-10 06:17:53 --> Email Class Initialized
DEBUG - 2024-09-10 06:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 06:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 06:17:53 --> Helper loaded: form_helper
INFO - 2024-09-10 06:17:53 --> Form Validation Class Initialized
INFO - 2024-09-10 06:17:53 --> Controller Class Initialized
DEBUG - 2024-09-10 06:17:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 06:17:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 06:17:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 06:17:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 06:17:53 --> Final output sent to browser
DEBUG - 2024-09-10 06:17:53 --> Total execution time: 0.2219
INFO - 2024-09-10 06:48:07 --> Config Class Initialized
INFO - 2024-09-10 06:48:07 --> Hooks Class Initialized
DEBUG - 2024-09-10 06:48:07 --> UTF-8 Support Enabled
INFO - 2024-09-10 06:48:07 --> Utf8 Class Initialized
INFO - 2024-09-10 06:48:07 --> URI Class Initialized
DEBUG - 2024-09-10 06:48:07 --> No URI present. Default controller set.
INFO - 2024-09-10 06:48:07 --> Router Class Initialized
INFO - 2024-09-10 06:48:07 --> Output Class Initialized
INFO - 2024-09-10 06:48:07 --> Security Class Initialized
DEBUG - 2024-09-10 06:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 06:48:07 --> Input Class Initialized
INFO - 2024-09-10 06:48:07 --> Language Class Initialized
INFO - 2024-09-10 06:48:07 --> Loader Class Initialized
INFO - 2024-09-10 06:48:07 --> Helper loaded: url_helper
INFO - 2024-09-10 06:48:07 --> Helper loaded: file_helper
INFO - 2024-09-10 06:48:07 --> Helper loaded: security_helper
INFO - 2024-09-10 06:48:07 --> Helper loaded: wpu_helper
INFO - 2024-09-10 06:48:07 --> Database Driver Class Initialized
INFO - 2024-09-10 06:48:07 --> Email Class Initialized
DEBUG - 2024-09-10 06:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 06:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 06:48:07 --> Helper loaded: form_helper
INFO - 2024-09-10 06:48:07 --> Form Validation Class Initialized
INFO - 2024-09-10 06:48:07 --> Controller Class Initialized
DEBUG - 2024-09-10 06:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 06:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 06:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 06:48:07 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 06:48:07 --> Final output sent to browser
DEBUG - 2024-09-10 06:48:07 --> Total execution time: 0.2606
INFO - 2024-09-10 07:17:48 --> Config Class Initialized
INFO - 2024-09-10 07:17:48 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:17:48 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:17:48 --> Utf8 Class Initialized
INFO - 2024-09-10 07:17:48 --> URI Class Initialized
DEBUG - 2024-09-10 07:17:48 --> No URI present. Default controller set.
INFO - 2024-09-10 07:17:48 --> Router Class Initialized
INFO - 2024-09-10 07:17:48 --> Output Class Initialized
INFO - 2024-09-10 07:17:48 --> Security Class Initialized
DEBUG - 2024-09-10 07:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:17:48 --> Input Class Initialized
INFO - 2024-09-10 07:17:48 --> Language Class Initialized
INFO - 2024-09-10 07:17:48 --> Loader Class Initialized
INFO - 2024-09-10 07:17:48 --> Helper loaded: url_helper
INFO - 2024-09-10 07:17:48 --> Helper loaded: file_helper
INFO - 2024-09-10 07:17:48 --> Helper loaded: security_helper
INFO - 2024-09-10 07:17:48 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:17:48 --> Database Driver Class Initialized
INFO - 2024-09-10 07:17:48 --> Email Class Initialized
DEBUG - 2024-09-10 07:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:17:48 --> Helper loaded: form_helper
INFO - 2024-09-10 07:17:48 --> Form Validation Class Initialized
INFO - 2024-09-10 07:17:48 --> Controller Class Initialized
DEBUG - 2024-09-10 07:17:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:17:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:17:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:17:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:17:48 --> Final output sent to browser
DEBUG - 2024-09-10 07:17:48 --> Total execution time: 0.2206
INFO - 2024-09-10 07:42:38 --> Config Class Initialized
INFO - 2024-09-10 07:42:38 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:42:38 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:42:38 --> Utf8 Class Initialized
INFO - 2024-09-10 07:42:38 --> URI Class Initialized
DEBUG - 2024-09-10 07:42:38 --> No URI present. Default controller set.
INFO - 2024-09-10 07:42:38 --> Router Class Initialized
INFO - 2024-09-10 07:42:38 --> Output Class Initialized
INFO - 2024-09-10 07:42:38 --> Security Class Initialized
DEBUG - 2024-09-10 07:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:42:38 --> Input Class Initialized
INFO - 2024-09-10 07:42:38 --> Language Class Initialized
INFO - 2024-09-10 07:42:38 --> Loader Class Initialized
INFO - 2024-09-10 07:42:38 --> Helper loaded: url_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: file_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: security_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:42:38 --> Database Driver Class Initialized
INFO - 2024-09-10 07:42:38 --> Config Class Initialized
INFO - 2024-09-10 07:42:38 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:42:38 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:42:38 --> Utf8 Class Initialized
INFO - 2024-09-10 07:42:38 --> URI Class Initialized
DEBUG - 2024-09-10 07:42:38 --> No URI present. Default controller set.
INFO - 2024-09-10 07:42:38 --> Router Class Initialized
INFO - 2024-09-10 07:42:38 --> Output Class Initialized
INFO - 2024-09-10 07:42:38 --> Security Class Initialized
DEBUG - 2024-09-10 07:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:42:38 --> Input Class Initialized
INFO - 2024-09-10 07:42:38 --> Language Class Initialized
INFO - 2024-09-10 07:42:38 --> Loader Class Initialized
INFO - 2024-09-10 07:42:38 --> Helper loaded: url_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: file_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: security_helper
INFO - 2024-09-10 07:42:38 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:42:38 --> Database Driver Class Initialized
INFO - 2024-09-10 07:42:38 --> Email Class Initialized
DEBUG - 2024-09-10 07:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:42:38 --> Helper loaded: form_helper
INFO - 2024-09-10 07:42:38 --> Form Validation Class Initialized
INFO - 2024-09-10 07:42:38 --> Controller Class Initialized
DEBUG - 2024-09-10 07:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:42:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:42:38 --> Final output sent to browser
DEBUG - 2024-09-10 07:42:38 --> Total execution time: 0.2240
INFO - 2024-09-10 07:42:39 --> Email Class Initialized
DEBUG - 2024-09-10 07:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:42:39 --> Helper loaded: form_helper
INFO - 2024-09-10 07:42:39 --> Form Validation Class Initialized
INFO - 2024-09-10 07:42:39 --> Controller Class Initialized
DEBUG - 2024-09-10 07:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:42:39 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:42:39 --> Final output sent to browser
DEBUG - 2024-09-10 07:42:39 --> Total execution time: 1.6448
INFO - 2024-09-10 07:42:41 --> Config Class Initialized
INFO - 2024-09-10 07:42:41 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:42:41 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:42:41 --> Utf8 Class Initialized
INFO - 2024-09-10 07:42:41 --> URI Class Initialized
DEBUG - 2024-09-10 07:42:41 --> No URI present. Default controller set.
INFO - 2024-09-10 07:42:41 --> Router Class Initialized
INFO - 2024-09-10 07:42:41 --> Output Class Initialized
INFO - 2024-09-10 07:42:41 --> Security Class Initialized
DEBUG - 2024-09-10 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:42:41 --> Input Class Initialized
INFO - 2024-09-10 07:42:41 --> Language Class Initialized
INFO - 2024-09-10 07:42:41 --> Loader Class Initialized
INFO - 2024-09-10 07:42:41 --> Helper loaded: url_helper
INFO - 2024-09-10 07:42:41 --> Helper loaded: file_helper
INFO - 2024-09-10 07:42:41 --> Helper loaded: security_helper
INFO - 2024-09-10 07:42:41 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:42:41 --> Database Driver Class Initialized
INFO - 2024-09-10 07:42:41 --> Email Class Initialized
DEBUG - 2024-09-10 07:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:42:41 --> Helper loaded: form_helper
INFO - 2024-09-10 07:42:41 --> Form Validation Class Initialized
INFO - 2024-09-10 07:42:41 --> Controller Class Initialized
DEBUG - 2024-09-10 07:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:42:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:42:41 --> Final output sent to browser
DEBUG - 2024-09-10 07:42:41 --> Total execution time: 0.2380
INFO - 2024-09-10 07:42:43 --> Config Class Initialized
INFO - 2024-09-10 07:42:43 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:42:43 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:42:43 --> Utf8 Class Initialized
INFO - 2024-09-10 07:42:43 --> URI Class Initialized
DEBUG - 2024-09-10 07:42:43 --> No URI present. Default controller set.
INFO - 2024-09-10 07:42:43 --> Router Class Initialized
INFO - 2024-09-10 07:42:43 --> Output Class Initialized
INFO - 2024-09-10 07:42:43 --> Security Class Initialized
DEBUG - 2024-09-10 07:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:42:43 --> Input Class Initialized
INFO - 2024-09-10 07:42:43 --> Language Class Initialized
INFO - 2024-09-10 07:42:43 --> Loader Class Initialized
INFO - 2024-09-10 07:42:43 --> Helper loaded: url_helper
INFO - 2024-09-10 07:42:43 --> Helper loaded: file_helper
INFO - 2024-09-10 07:42:43 --> Helper loaded: security_helper
INFO - 2024-09-10 07:42:43 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:42:43 --> Database Driver Class Initialized
INFO - 2024-09-10 07:42:43 --> Email Class Initialized
DEBUG - 2024-09-10 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:42:43 --> Helper loaded: form_helper
INFO - 2024-09-10 07:42:43 --> Form Validation Class Initialized
INFO - 2024-09-10 07:42:43 --> Controller Class Initialized
DEBUG - 2024-09-10 07:42:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:42:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:42:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:42:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:42:43 --> Final output sent to browser
DEBUG - 2024-09-10 07:42:43 --> Total execution time: 0.2270
INFO - 2024-09-10 07:48:55 --> Config Class Initialized
INFO - 2024-09-10 07:48:55 --> Hooks Class Initialized
DEBUG - 2024-09-10 07:48:55 --> UTF-8 Support Enabled
INFO - 2024-09-10 07:48:55 --> Utf8 Class Initialized
INFO - 2024-09-10 07:48:55 --> URI Class Initialized
DEBUG - 2024-09-10 07:48:55 --> No URI present. Default controller set.
INFO - 2024-09-10 07:48:55 --> Router Class Initialized
INFO - 2024-09-10 07:48:55 --> Output Class Initialized
INFO - 2024-09-10 07:48:55 --> Security Class Initialized
DEBUG - 2024-09-10 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 07:48:55 --> Input Class Initialized
INFO - 2024-09-10 07:48:55 --> Language Class Initialized
INFO - 2024-09-10 07:48:55 --> Loader Class Initialized
INFO - 2024-09-10 07:48:55 --> Helper loaded: url_helper
INFO - 2024-09-10 07:48:55 --> Helper loaded: file_helper
INFO - 2024-09-10 07:48:55 --> Helper loaded: security_helper
INFO - 2024-09-10 07:48:55 --> Helper loaded: wpu_helper
INFO - 2024-09-10 07:48:55 --> Database Driver Class Initialized
INFO - 2024-09-10 07:48:56 --> Email Class Initialized
DEBUG - 2024-09-10 07:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 07:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 07:48:56 --> Helper loaded: form_helper
INFO - 2024-09-10 07:48:56 --> Form Validation Class Initialized
INFO - 2024-09-10 07:48:56 --> Controller Class Initialized
DEBUG - 2024-09-10 07:48:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 07:48:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 07:48:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 07:48:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 07:48:56 --> Final output sent to browser
DEBUG - 2024-09-10 07:48:56 --> Total execution time: 1.2512
INFO - 2024-09-10 08:16:18 --> Config Class Initialized
INFO - 2024-09-10 08:16:18 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:16:18 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:16:18 --> Utf8 Class Initialized
INFO - 2024-09-10 08:16:18 --> URI Class Initialized
DEBUG - 2024-09-10 08:16:18 --> No URI present. Default controller set.
INFO - 2024-09-10 08:16:18 --> Router Class Initialized
INFO - 2024-09-10 08:16:18 --> Output Class Initialized
INFO - 2024-09-10 08:16:18 --> Security Class Initialized
DEBUG - 2024-09-10 08:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:16:18 --> Input Class Initialized
INFO - 2024-09-10 08:16:18 --> Language Class Initialized
INFO - 2024-09-10 08:16:18 --> Loader Class Initialized
INFO - 2024-09-10 08:16:18 --> Helper loaded: url_helper
INFO - 2024-09-10 08:16:18 --> Helper loaded: file_helper
INFO - 2024-09-10 08:16:18 --> Helper loaded: security_helper
INFO - 2024-09-10 08:16:18 --> Helper loaded: wpu_helper
INFO - 2024-09-10 08:16:18 --> Database Driver Class Initialized
INFO - 2024-09-10 08:16:20 --> Email Class Initialized
DEBUG - 2024-09-10 08:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 08:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:16:20 --> Helper loaded: form_helper
INFO - 2024-09-10 08:16:20 --> Form Validation Class Initialized
INFO - 2024-09-10 08:16:20 --> Controller Class Initialized
DEBUG - 2024-09-10 08:16:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 08:16:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 08:16:20 --> Final output sent to browser
DEBUG - 2024-09-10 08:16:20 --> Total execution time: 1.5088
INFO - 2024-09-10 08:29:31 --> Config Class Initialized
INFO - 2024-09-10 08:29:31 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:29:31 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:29:31 --> Utf8 Class Initialized
INFO - 2024-09-10 08:29:31 --> URI Class Initialized
DEBUG - 2024-09-10 08:29:31 --> No URI present. Default controller set.
INFO - 2024-09-10 08:29:31 --> Router Class Initialized
INFO - 2024-09-10 08:29:31 --> Output Class Initialized
INFO - 2024-09-10 08:29:31 --> Security Class Initialized
DEBUG - 2024-09-10 08:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:29:31 --> Input Class Initialized
INFO - 2024-09-10 08:29:31 --> Language Class Initialized
INFO - 2024-09-10 08:29:31 --> Loader Class Initialized
INFO - 2024-09-10 08:29:31 --> Helper loaded: url_helper
INFO - 2024-09-10 08:29:31 --> Helper loaded: file_helper
INFO - 2024-09-10 08:29:31 --> Helper loaded: security_helper
INFO - 2024-09-10 08:29:31 --> Helper loaded: wpu_helper
INFO - 2024-09-10 08:29:31 --> Database Driver Class Initialized
INFO - 2024-09-10 08:29:31 --> Email Class Initialized
DEBUG - 2024-09-10 08:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 08:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:29:31 --> Helper loaded: form_helper
INFO - 2024-09-10 08:29:31 --> Form Validation Class Initialized
INFO - 2024-09-10 08:29:31 --> Controller Class Initialized
DEBUG - 2024-09-10 08:29:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 08:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 08:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 08:29:31 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 08:29:31 --> Final output sent to browser
DEBUG - 2024-09-10 08:29:31 --> Total execution time: 0.2186
INFO - 2024-09-10 08:47:38 --> Config Class Initialized
INFO - 2024-09-10 08:47:38 --> Hooks Class Initialized
DEBUG - 2024-09-10 08:47:38 --> UTF-8 Support Enabled
INFO - 2024-09-10 08:47:38 --> Utf8 Class Initialized
INFO - 2024-09-10 08:47:38 --> URI Class Initialized
DEBUG - 2024-09-10 08:47:38 --> No URI present. Default controller set.
INFO - 2024-09-10 08:47:38 --> Router Class Initialized
INFO - 2024-09-10 08:47:38 --> Output Class Initialized
INFO - 2024-09-10 08:47:38 --> Security Class Initialized
DEBUG - 2024-09-10 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 08:47:38 --> Input Class Initialized
INFO - 2024-09-10 08:47:38 --> Language Class Initialized
INFO - 2024-09-10 08:47:38 --> Loader Class Initialized
INFO - 2024-09-10 08:47:38 --> Helper loaded: url_helper
INFO - 2024-09-10 08:47:38 --> Helper loaded: file_helper
INFO - 2024-09-10 08:47:38 --> Helper loaded: security_helper
INFO - 2024-09-10 08:47:38 --> Helper loaded: wpu_helper
INFO - 2024-09-10 08:47:38 --> Database Driver Class Initialized
INFO - 2024-09-10 08:47:38 --> Email Class Initialized
DEBUG - 2024-09-10 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 08:47:38 --> Helper loaded: form_helper
INFO - 2024-09-10 08:47:38 --> Form Validation Class Initialized
INFO - 2024-09-10 08:47:38 --> Controller Class Initialized
DEBUG - 2024-09-10 08:47:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 08:47:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 08:47:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 08:47:38 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 08:47:38 --> Final output sent to browser
DEBUG - 2024-09-10 08:47:38 --> Total execution time: 0.2388
INFO - 2024-09-10 09:03:00 --> Config Class Initialized
INFO - 2024-09-10 09:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:00 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:00 --> URI Class Initialized
INFO - 2024-09-10 09:03:00 --> Router Class Initialized
INFO - 2024-09-10 09:03:00 --> Output Class Initialized
INFO - 2024-09-10 09:03:00 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:00 --> Input Class Initialized
INFO - 2024-09-10 09:03:00 --> Language Class Initialized
INFO - 2024-09-10 09:03:00 --> Loader Class Initialized
INFO - 2024-09-10 09:03:00 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:00 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:00 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:00 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:00 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:00 --> Controller Class Initialized
INFO - 2024-09-10 09:03:00 --> Config Class Initialized
INFO - 2024-09-10 09:03:00 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:00 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:00 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:00 --> URI Class Initialized
INFO - 2024-09-10 09:03:00 --> Router Class Initialized
INFO - 2024-09-10 09:03:00 --> Output Class Initialized
INFO - 2024-09-10 09:03:00 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:00 --> Input Class Initialized
INFO - 2024-09-10 09:03:00 --> Language Class Initialized
INFO - 2024-09-10 09:03:00 --> Loader Class Initialized
INFO - 2024-09-10 09:03:00 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:00 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:00 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:00 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:00 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:00 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:00 --> Controller Class Initialized
DEBUG - 2024-09-10 09:03:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:03:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 09:03:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 09:03:00 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 09:03:00 --> Final output sent to browser
DEBUG - 2024-09-10 09:03:00 --> Total execution time: 0.2207
INFO - 2024-09-10 09:03:02 --> Config Class Initialized
INFO - 2024-09-10 09:03:02 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:02 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:02 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:02 --> URI Class Initialized
INFO - 2024-09-10 09:03:02 --> Router Class Initialized
INFO - 2024-09-10 09:03:02 --> Output Class Initialized
INFO - 2024-09-10 09:03:02 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:02 --> Input Class Initialized
INFO - 2024-09-10 09:03:02 --> Language Class Initialized
INFO - 2024-09-10 09:03:02 --> Loader Class Initialized
INFO - 2024-09-10 09:03:02 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:02 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:02 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:02 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:02 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:04 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:04 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:04 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:04 --> Controller Class Initialized
DEBUG - 2024-09-10 09:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:03:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2024-09-10 09:03:04 --> Config Class Initialized
INFO - 2024-09-10 09:03:04 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:04 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:04 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:04 --> URI Class Initialized
INFO - 2024-09-10 09:03:04 --> Router Class Initialized
INFO - 2024-09-10 09:03:04 --> Output Class Initialized
INFO - 2024-09-10 09:03:04 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:04 --> Input Class Initialized
INFO - 2024-09-10 09:03:04 --> Language Class Initialized
INFO - 2024-09-10 09:03:04 --> Loader Class Initialized
INFO - 2024-09-10 09:03:04 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:04 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:04 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:04 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:04 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:04 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:04 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:04 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:04 --> Controller Class Initialized
INFO - 2024-09-10 09:03:04 --> Model "Antrol_model" initialized
DEBUG - 2024-09-10 09:03:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:03:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-10 09:03:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-10 09:03:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/data/antrol.php
INFO - 2024-09-10 09:03:05 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-10 09:03:05 --> Final output sent to browser
DEBUG - 2024-09-10 09:03:05 --> Total execution time: 0.6869
INFO - 2024-09-10 09:03:14 --> Config Class Initialized
INFO - 2024-09-10 09:03:14 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:14 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:14 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:14 --> URI Class Initialized
INFO - 2024-09-10 09:03:14 --> Router Class Initialized
INFO - 2024-09-10 09:03:14 --> Output Class Initialized
INFO - 2024-09-10 09:03:14 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:14 --> Input Class Initialized
INFO - 2024-09-10 09:03:14 --> Language Class Initialized
INFO - 2024-09-10 09:03:14 --> Loader Class Initialized
INFO - 2024-09-10 09:03:14 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:14 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:14 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:14 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:14 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:14 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:14 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:14 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:14 --> Controller Class Initialized
INFO - 2024-09-10 09:03:14 --> Model "Antrol_model" initialized
DEBUG - 2024-09-10 09:03:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:03:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/header.php
INFO - 2024-09-10 09:03:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/topbar.php
INFO - 2024-09-10 09:03:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/report/cetakantrol.php
INFO - 2024-09-10 09:03:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/footer.php
INFO - 2024-09-10 09:03:15 --> Final output sent to browser
DEBUG - 2024-09-10 09:03:15 --> Total execution time: 0.9597
INFO - 2024-09-10 09:03:17 --> Config Class Initialized
INFO - 2024-09-10 09:03:17 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:03:17 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:03:17 --> Utf8 Class Initialized
INFO - 2024-09-10 09:03:17 --> URI Class Initialized
INFO - 2024-09-10 09:03:17 --> Router Class Initialized
INFO - 2024-09-10 09:03:17 --> Output Class Initialized
INFO - 2024-09-10 09:03:17 --> Security Class Initialized
DEBUG - 2024-09-10 09:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:03:17 --> Input Class Initialized
INFO - 2024-09-10 09:03:17 --> Language Class Initialized
INFO - 2024-09-10 09:03:17 --> Loader Class Initialized
INFO - 2024-09-10 09:03:17 --> Helper loaded: url_helper
INFO - 2024-09-10 09:03:17 --> Helper loaded: file_helper
INFO - 2024-09-10 09:03:17 --> Helper loaded: security_helper
INFO - 2024-09-10 09:03:17 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:03:17 --> Database Driver Class Initialized
INFO - 2024-09-10 09:03:17 --> Email Class Initialized
DEBUG - 2024-09-10 09:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:03:17 --> Helper loaded: form_helper
INFO - 2024-09-10 09:03:17 --> Form Validation Class Initialized
INFO - 2024-09-10 09:03:17 --> Controller Class Initialized
INFO - 2024-09-10 09:03:17 --> Model "Antrol_model" initialized
DEBUG - 2024-09-10 09:03:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:03:19 --> Final output sent to browser
DEBUG - 2024-09-10 09:03:19 --> Total execution time: 1.8430
INFO - 2024-09-10 09:17:57 --> Config Class Initialized
INFO - 2024-09-10 09:17:57 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:17:57 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:17:57 --> Utf8 Class Initialized
INFO - 2024-09-10 09:17:57 --> URI Class Initialized
DEBUG - 2024-09-10 09:17:57 --> No URI present. Default controller set.
INFO - 2024-09-10 09:17:57 --> Router Class Initialized
INFO - 2024-09-10 09:17:57 --> Output Class Initialized
INFO - 2024-09-10 09:17:57 --> Security Class Initialized
DEBUG - 2024-09-10 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:17:57 --> Input Class Initialized
INFO - 2024-09-10 09:17:57 --> Language Class Initialized
INFO - 2024-09-10 09:17:57 --> Loader Class Initialized
INFO - 2024-09-10 09:17:57 --> Helper loaded: url_helper
INFO - 2024-09-10 09:17:57 --> Helper loaded: file_helper
INFO - 2024-09-10 09:17:57 --> Helper loaded: security_helper
INFO - 2024-09-10 09:17:57 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:17:57 --> Database Driver Class Initialized
INFO - 2024-09-10 09:17:57 --> Email Class Initialized
DEBUG - 2024-09-10 09:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:17:57 --> Helper loaded: form_helper
INFO - 2024-09-10 09:17:57 --> Form Validation Class Initialized
INFO - 2024-09-10 09:17:57 --> Controller Class Initialized
DEBUG - 2024-09-10 09:17:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:17:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 09:17:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 09:17:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 09:17:57 --> Final output sent to browser
DEBUG - 2024-09-10 09:17:57 --> Total execution time: 0.2278
INFO - 2024-09-10 09:46:21 --> Config Class Initialized
INFO - 2024-09-10 09:46:21 --> Hooks Class Initialized
DEBUG - 2024-09-10 09:46:21 --> UTF-8 Support Enabled
INFO - 2024-09-10 09:46:21 --> Utf8 Class Initialized
INFO - 2024-09-10 09:46:21 --> URI Class Initialized
DEBUG - 2024-09-10 09:46:21 --> No URI present. Default controller set.
INFO - 2024-09-10 09:46:21 --> Router Class Initialized
INFO - 2024-09-10 09:46:21 --> Output Class Initialized
INFO - 2024-09-10 09:46:21 --> Security Class Initialized
DEBUG - 2024-09-10 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 09:46:21 --> Input Class Initialized
INFO - 2024-09-10 09:46:21 --> Language Class Initialized
INFO - 2024-09-10 09:46:21 --> Loader Class Initialized
INFO - 2024-09-10 09:46:21 --> Helper loaded: url_helper
INFO - 2024-09-10 09:46:21 --> Helper loaded: file_helper
INFO - 2024-09-10 09:46:21 --> Helper loaded: security_helper
INFO - 2024-09-10 09:46:21 --> Helper loaded: wpu_helper
INFO - 2024-09-10 09:46:21 --> Database Driver Class Initialized
INFO - 2024-09-10 09:46:21 --> Email Class Initialized
DEBUG - 2024-09-10 09:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 09:46:21 --> Helper loaded: form_helper
INFO - 2024-09-10 09:46:21 --> Form Validation Class Initialized
INFO - 2024-09-10 09:46:21 --> Controller Class Initialized
DEBUG - 2024-09-10 09:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 09:46:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 09:46:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 09:46:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 09:46:21 --> Final output sent to browser
DEBUG - 2024-09-10 09:46:21 --> Total execution time: 0.4675
INFO - 2024-09-10 10:15:56 --> Config Class Initialized
INFO - 2024-09-10 10:15:56 --> Hooks Class Initialized
DEBUG - 2024-09-10 10:15:56 --> UTF-8 Support Enabled
INFO - 2024-09-10 10:15:56 --> Utf8 Class Initialized
INFO - 2024-09-10 10:15:56 --> URI Class Initialized
DEBUG - 2024-09-10 10:15:56 --> No URI present. Default controller set.
INFO - 2024-09-10 10:15:56 --> Router Class Initialized
INFO - 2024-09-10 10:15:56 --> Output Class Initialized
INFO - 2024-09-10 10:15:56 --> Security Class Initialized
DEBUG - 2024-09-10 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 10:15:56 --> Input Class Initialized
INFO - 2024-09-10 10:15:56 --> Language Class Initialized
INFO - 2024-09-10 10:15:56 --> Loader Class Initialized
INFO - 2024-09-10 10:15:56 --> Helper loaded: url_helper
INFO - 2024-09-10 10:15:56 --> Helper loaded: file_helper
INFO - 2024-09-10 10:15:56 --> Helper loaded: security_helper
INFO - 2024-09-10 10:15:56 --> Helper loaded: wpu_helper
INFO - 2024-09-10 10:15:56 --> Database Driver Class Initialized
INFO - 2024-09-10 10:15:56 --> Email Class Initialized
DEBUG - 2024-09-10 10:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 10:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 10:15:56 --> Helper loaded: form_helper
INFO - 2024-09-10 10:15:56 --> Form Validation Class Initialized
INFO - 2024-09-10 10:15:56 --> Controller Class Initialized
DEBUG - 2024-09-10 10:15:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 10:15:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 10:15:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 10:15:56 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 10:15:56 --> Final output sent to browser
DEBUG - 2024-09-10 10:15:56 --> Total execution time: 0.2326
INFO - 2024-09-10 10:46:30 --> Config Class Initialized
INFO - 2024-09-10 10:46:30 --> Hooks Class Initialized
DEBUG - 2024-09-10 10:46:30 --> UTF-8 Support Enabled
INFO - 2024-09-10 10:46:30 --> Utf8 Class Initialized
INFO - 2024-09-10 10:46:30 --> URI Class Initialized
DEBUG - 2024-09-10 10:46:30 --> No URI present. Default controller set.
INFO - 2024-09-10 10:46:30 --> Router Class Initialized
INFO - 2024-09-10 10:46:30 --> Output Class Initialized
INFO - 2024-09-10 10:46:30 --> Security Class Initialized
DEBUG - 2024-09-10 10:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 10:46:30 --> Input Class Initialized
INFO - 2024-09-10 10:46:30 --> Language Class Initialized
INFO - 2024-09-10 10:46:30 --> Loader Class Initialized
INFO - 2024-09-10 10:46:30 --> Helper loaded: url_helper
INFO - 2024-09-10 10:46:30 --> Helper loaded: file_helper
INFO - 2024-09-10 10:46:30 --> Helper loaded: security_helper
INFO - 2024-09-10 10:46:30 --> Helper loaded: wpu_helper
INFO - 2024-09-10 10:46:30 --> Database Driver Class Initialized
INFO - 2024-09-10 10:46:30 --> Email Class Initialized
DEBUG - 2024-09-10 10:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 10:46:30 --> Helper loaded: form_helper
INFO - 2024-09-10 10:46:30 --> Form Validation Class Initialized
INFO - 2024-09-10 10:46:30 --> Controller Class Initialized
DEBUG - 2024-09-10 10:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 10:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 10:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 10:46:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 10:46:30 --> Final output sent to browser
DEBUG - 2024-09-10 10:46:30 --> Total execution time: 0.2257
INFO - 2024-09-10 11:15:48 --> Config Class Initialized
INFO - 2024-09-10 11:15:48 --> Hooks Class Initialized
DEBUG - 2024-09-10 11:15:48 --> UTF-8 Support Enabled
INFO - 2024-09-10 11:15:48 --> Utf8 Class Initialized
INFO - 2024-09-10 11:15:48 --> URI Class Initialized
DEBUG - 2024-09-10 11:15:48 --> No URI present. Default controller set.
INFO - 2024-09-10 11:15:48 --> Router Class Initialized
INFO - 2024-09-10 11:15:48 --> Output Class Initialized
INFO - 2024-09-10 11:15:48 --> Security Class Initialized
DEBUG - 2024-09-10 11:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 11:15:48 --> Input Class Initialized
INFO - 2024-09-10 11:15:48 --> Language Class Initialized
INFO - 2024-09-10 11:15:48 --> Loader Class Initialized
INFO - 2024-09-10 11:15:48 --> Helper loaded: url_helper
INFO - 2024-09-10 11:15:48 --> Helper loaded: file_helper
INFO - 2024-09-10 11:15:48 --> Helper loaded: security_helper
INFO - 2024-09-10 11:15:48 --> Helper loaded: wpu_helper
INFO - 2024-09-10 11:15:48 --> Database Driver Class Initialized
INFO - 2024-09-10 11:15:49 --> Email Class Initialized
DEBUG - 2024-09-10 11:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 11:15:49 --> Helper loaded: form_helper
INFO - 2024-09-10 11:15:49 --> Form Validation Class Initialized
INFO - 2024-09-10 11:15:49 --> Controller Class Initialized
DEBUG - 2024-09-10 11:15:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 11:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 11:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 11:15:49 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 11:15:49 --> Final output sent to browser
DEBUG - 2024-09-10 11:15:49 --> Total execution time: 0.2340
INFO - 2024-09-10 11:34:57 --> Config Class Initialized
INFO - 2024-09-10 11:34:57 --> Hooks Class Initialized
DEBUG - 2024-09-10 11:34:57 --> UTF-8 Support Enabled
INFO - 2024-09-10 11:34:57 --> Utf8 Class Initialized
INFO - 2024-09-10 11:34:57 --> URI Class Initialized
DEBUG - 2024-09-10 11:34:57 --> No URI present. Default controller set.
INFO - 2024-09-10 11:34:57 --> Router Class Initialized
INFO - 2024-09-10 11:34:57 --> Output Class Initialized
INFO - 2024-09-10 11:34:57 --> Security Class Initialized
DEBUG - 2024-09-10 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 11:34:57 --> Input Class Initialized
INFO - 2024-09-10 11:34:57 --> Language Class Initialized
INFO - 2024-09-10 11:34:57 --> Loader Class Initialized
INFO - 2024-09-10 11:34:57 --> Helper loaded: url_helper
INFO - 2024-09-10 11:34:57 --> Helper loaded: file_helper
INFO - 2024-09-10 11:34:57 --> Helper loaded: security_helper
INFO - 2024-09-10 11:34:57 --> Helper loaded: wpu_helper
INFO - 2024-09-10 11:34:57 --> Database Driver Class Initialized
INFO - 2024-09-10 11:34:57 --> Email Class Initialized
DEBUG - 2024-09-10 11:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 11:34:57 --> Helper loaded: form_helper
INFO - 2024-09-10 11:34:57 --> Form Validation Class Initialized
INFO - 2024-09-10 11:34:57 --> Controller Class Initialized
DEBUG - 2024-09-10 11:34:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 11:34:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 11:34:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 11:34:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 11:34:57 --> Final output sent to browser
DEBUG - 2024-09-10 11:34:57 --> Total execution time: 0.2288
INFO - 2024-09-10 11:46:53 --> Config Class Initialized
INFO - 2024-09-10 11:46:53 --> Hooks Class Initialized
DEBUG - 2024-09-10 11:46:53 --> UTF-8 Support Enabled
INFO - 2024-09-10 11:46:53 --> Utf8 Class Initialized
INFO - 2024-09-10 11:46:53 --> URI Class Initialized
DEBUG - 2024-09-10 11:46:53 --> No URI present. Default controller set.
INFO - 2024-09-10 11:46:53 --> Router Class Initialized
INFO - 2024-09-10 11:46:53 --> Output Class Initialized
INFO - 2024-09-10 11:46:53 --> Security Class Initialized
DEBUG - 2024-09-10 11:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 11:46:53 --> Input Class Initialized
INFO - 2024-09-10 11:46:53 --> Language Class Initialized
INFO - 2024-09-10 11:46:53 --> Loader Class Initialized
INFO - 2024-09-10 11:46:53 --> Helper loaded: url_helper
INFO - 2024-09-10 11:46:53 --> Helper loaded: file_helper
INFO - 2024-09-10 11:46:53 --> Helper loaded: security_helper
INFO - 2024-09-10 11:46:53 --> Helper loaded: wpu_helper
INFO - 2024-09-10 11:46:53 --> Database Driver Class Initialized
INFO - 2024-09-10 11:46:53 --> Email Class Initialized
DEBUG - 2024-09-10 11:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 11:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 11:46:53 --> Helper loaded: form_helper
INFO - 2024-09-10 11:46:53 --> Form Validation Class Initialized
INFO - 2024-09-10 11:46:53 --> Controller Class Initialized
DEBUG - 2024-09-10 11:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 11:46:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 11:46:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 11:46:53 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 11:46:53 --> Final output sent to browser
DEBUG - 2024-09-10 11:46:53 --> Total execution time: 0.2388
INFO - 2024-09-10 12:17:52 --> Config Class Initialized
INFO - 2024-09-10 12:17:52 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:17:52 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:17:52 --> Utf8 Class Initialized
INFO - 2024-09-10 12:17:52 --> URI Class Initialized
DEBUG - 2024-09-10 12:17:52 --> No URI present. Default controller set.
INFO - 2024-09-10 12:17:52 --> Router Class Initialized
INFO - 2024-09-10 12:17:52 --> Output Class Initialized
INFO - 2024-09-10 12:17:52 --> Security Class Initialized
DEBUG - 2024-09-10 12:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:17:52 --> Input Class Initialized
INFO - 2024-09-10 12:17:52 --> Language Class Initialized
INFO - 2024-09-10 12:17:52 --> Loader Class Initialized
INFO - 2024-09-10 12:17:52 --> Helper loaded: url_helper
INFO - 2024-09-10 12:17:52 --> Helper loaded: file_helper
INFO - 2024-09-10 12:17:52 --> Helper loaded: security_helper
INFO - 2024-09-10 12:17:52 --> Helper loaded: wpu_helper
INFO - 2024-09-10 12:17:52 --> Database Driver Class Initialized
INFO - 2024-09-10 12:17:52 --> Email Class Initialized
DEBUG - 2024-09-10 12:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 12:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:17:52 --> Helper loaded: form_helper
INFO - 2024-09-10 12:17:52 --> Form Validation Class Initialized
INFO - 2024-09-10 12:17:52 --> Controller Class Initialized
DEBUG - 2024-09-10 12:17:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 12:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 12:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 12:17:52 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 12:17:52 --> Final output sent to browser
DEBUG - 2024-09-10 12:17:52 --> Total execution time: 0.2392
INFO - 2024-09-10 12:46:21 --> Config Class Initialized
INFO - 2024-09-10 12:46:21 --> Hooks Class Initialized
DEBUG - 2024-09-10 12:46:21 --> UTF-8 Support Enabled
INFO - 2024-09-10 12:46:21 --> Utf8 Class Initialized
INFO - 2024-09-10 12:46:21 --> URI Class Initialized
DEBUG - 2024-09-10 12:46:21 --> No URI present. Default controller set.
INFO - 2024-09-10 12:46:21 --> Router Class Initialized
INFO - 2024-09-10 12:46:21 --> Output Class Initialized
INFO - 2024-09-10 12:46:21 --> Security Class Initialized
DEBUG - 2024-09-10 12:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 12:46:21 --> Input Class Initialized
INFO - 2024-09-10 12:46:21 --> Language Class Initialized
INFO - 2024-09-10 12:46:21 --> Loader Class Initialized
INFO - 2024-09-10 12:46:21 --> Helper loaded: url_helper
INFO - 2024-09-10 12:46:21 --> Helper loaded: file_helper
INFO - 2024-09-10 12:46:21 --> Helper loaded: security_helper
INFO - 2024-09-10 12:46:21 --> Helper loaded: wpu_helper
INFO - 2024-09-10 12:46:21 --> Database Driver Class Initialized
INFO - 2024-09-10 12:46:23 --> Email Class Initialized
DEBUG - 2024-09-10 12:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 12:46:23 --> Helper loaded: form_helper
INFO - 2024-09-10 12:46:23 --> Form Validation Class Initialized
INFO - 2024-09-10 12:46:23 --> Controller Class Initialized
DEBUG - 2024-09-10 12:46:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 12:46:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 12:46:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 12:46:23 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 12:46:23 --> Final output sent to browser
DEBUG - 2024-09-10 12:46:23 --> Total execution time: 2.1029
INFO - 2024-09-10 13:14:55 --> Config Class Initialized
INFO - 2024-09-10 13:14:55 --> Hooks Class Initialized
DEBUG - 2024-09-10 13:14:55 --> UTF-8 Support Enabled
INFO - 2024-09-10 13:14:55 --> Utf8 Class Initialized
INFO - 2024-09-10 13:14:55 --> URI Class Initialized
DEBUG - 2024-09-10 13:14:55 --> No URI present. Default controller set.
INFO - 2024-09-10 13:14:55 --> Router Class Initialized
INFO - 2024-09-10 13:14:55 --> Output Class Initialized
INFO - 2024-09-10 13:14:55 --> Security Class Initialized
DEBUG - 2024-09-10 13:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 13:14:55 --> Input Class Initialized
INFO - 2024-09-10 13:14:55 --> Language Class Initialized
INFO - 2024-09-10 13:14:55 --> Loader Class Initialized
INFO - 2024-09-10 13:14:55 --> Helper loaded: url_helper
INFO - 2024-09-10 13:14:55 --> Helper loaded: file_helper
INFO - 2024-09-10 13:14:55 --> Helper loaded: security_helper
INFO - 2024-09-10 13:14:55 --> Helper loaded: wpu_helper
INFO - 2024-09-10 13:14:55 --> Database Driver Class Initialized
INFO - 2024-09-10 13:14:55 --> Email Class Initialized
DEBUG - 2024-09-10 13:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 13:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 13:14:55 --> Helper loaded: form_helper
INFO - 2024-09-10 13:14:55 --> Form Validation Class Initialized
INFO - 2024-09-10 13:14:55 --> Controller Class Initialized
DEBUG - 2024-09-10 13:14:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 13:14:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 13:14:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 13:14:55 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 13:14:55 --> Final output sent to browser
DEBUG - 2024-09-10 13:14:55 --> Total execution time: 0.6860
INFO - 2024-09-10 13:45:27 --> Config Class Initialized
INFO - 2024-09-10 13:45:27 --> Hooks Class Initialized
DEBUG - 2024-09-10 13:45:27 --> UTF-8 Support Enabled
INFO - 2024-09-10 13:45:27 --> Utf8 Class Initialized
INFO - 2024-09-10 13:45:27 --> URI Class Initialized
DEBUG - 2024-09-10 13:45:27 --> No URI present. Default controller set.
INFO - 2024-09-10 13:45:27 --> Router Class Initialized
INFO - 2024-09-10 13:45:27 --> Output Class Initialized
INFO - 2024-09-10 13:45:27 --> Security Class Initialized
DEBUG - 2024-09-10 13:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 13:45:27 --> Input Class Initialized
INFO - 2024-09-10 13:45:27 --> Language Class Initialized
INFO - 2024-09-10 13:45:27 --> Loader Class Initialized
INFO - 2024-09-10 13:45:27 --> Helper loaded: url_helper
INFO - 2024-09-10 13:45:27 --> Helper loaded: file_helper
INFO - 2024-09-10 13:45:27 --> Helper loaded: security_helper
INFO - 2024-09-10 13:45:27 --> Helper loaded: wpu_helper
INFO - 2024-09-10 13:45:27 --> Database Driver Class Initialized
INFO - 2024-09-10 13:45:27 --> Email Class Initialized
DEBUG - 2024-09-10 13:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 13:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 13:45:27 --> Helper loaded: form_helper
INFO - 2024-09-10 13:45:27 --> Form Validation Class Initialized
INFO - 2024-09-10 13:45:27 --> Controller Class Initialized
DEBUG - 2024-09-10 13:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 13:45:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 13:45:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 13:45:27 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 13:45:27 --> Final output sent to browser
DEBUG - 2024-09-10 13:45:27 --> Total execution time: 0.7399
INFO - 2024-09-10 14:15:47 --> Config Class Initialized
INFO - 2024-09-10 14:15:47 --> Hooks Class Initialized
DEBUG - 2024-09-10 14:15:47 --> UTF-8 Support Enabled
INFO - 2024-09-10 14:15:47 --> Utf8 Class Initialized
INFO - 2024-09-10 14:15:47 --> URI Class Initialized
DEBUG - 2024-09-10 14:15:47 --> No URI present. Default controller set.
INFO - 2024-09-10 14:15:47 --> Router Class Initialized
INFO - 2024-09-10 14:15:47 --> Output Class Initialized
INFO - 2024-09-10 14:15:47 --> Security Class Initialized
DEBUG - 2024-09-10 14:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 14:15:47 --> Input Class Initialized
INFO - 2024-09-10 14:15:47 --> Language Class Initialized
INFO - 2024-09-10 14:15:47 --> Loader Class Initialized
INFO - 2024-09-10 14:15:47 --> Helper loaded: url_helper
INFO - 2024-09-10 14:15:47 --> Helper loaded: file_helper
INFO - 2024-09-10 14:15:47 --> Helper loaded: security_helper
INFO - 2024-09-10 14:15:47 --> Helper loaded: wpu_helper
INFO - 2024-09-10 14:15:47 --> Database Driver Class Initialized
INFO - 2024-09-10 14:15:48 --> Email Class Initialized
DEBUG - 2024-09-10 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 14:15:48 --> Helper loaded: form_helper
INFO - 2024-09-10 14:15:48 --> Form Validation Class Initialized
INFO - 2024-09-10 14:15:48 --> Controller Class Initialized
DEBUG - 2024-09-10 14:15:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 14:15:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 14:15:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 14:15:48 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 14:15:48 --> Final output sent to browser
DEBUG - 2024-09-10 14:15:48 --> Total execution time: 0.2402
INFO - 2024-09-10 14:31:28 --> Config Class Initialized
INFO - 2024-09-10 14:31:28 --> Hooks Class Initialized
DEBUG - 2024-09-10 14:31:28 --> UTF-8 Support Enabled
INFO - 2024-09-10 14:31:28 --> Utf8 Class Initialized
INFO - 2024-09-10 14:31:28 --> URI Class Initialized
DEBUG - 2024-09-10 14:31:28 --> No URI present. Default controller set.
INFO - 2024-09-10 14:31:28 --> Router Class Initialized
INFO - 2024-09-10 14:31:28 --> Output Class Initialized
INFO - 2024-09-10 14:31:28 --> Security Class Initialized
DEBUG - 2024-09-10 14:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 14:31:28 --> Input Class Initialized
INFO - 2024-09-10 14:31:28 --> Language Class Initialized
INFO - 2024-09-10 14:31:28 --> Loader Class Initialized
INFO - 2024-09-10 14:31:28 --> Helper loaded: url_helper
INFO - 2024-09-10 14:31:28 --> Helper loaded: file_helper
INFO - 2024-09-10 14:31:28 --> Helper loaded: security_helper
INFO - 2024-09-10 14:31:28 --> Helper loaded: wpu_helper
INFO - 2024-09-10 14:31:28 --> Database Driver Class Initialized
INFO - 2024-09-10 14:31:28 --> Email Class Initialized
DEBUG - 2024-09-10 14:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 14:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 14:31:28 --> Helper loaded: form_helper
INFO - 2024-09-10 14:31:28 --> Form Validation Class Initialized
INFO - 2024-09-10 14:31:28 --> Controller Class Initialized
DEBUG - 2024-09-10 14:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 14:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 14:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 14:31:28 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 14:31:28 --> Final output sent to browser
DEBUG - 2024-09-10 14:31:28 --> Total execution time: 0.2189
INFO - 2024-09-10 14:44:43 --> Config Class Initialized
INFO - 2024-09-10 14:44:43 --> Hooks Class Initialized
DEBUG - 2024-09-10 14:44:43 --> UTF-8 Support Enabled
INFO - 2024-09-10 14:44:43 --> Utf8 Class Initialized
INFO - 2024-09-10 14:44:43 --> URI Class Initialized
DEBUG - 2024-09-10 14:44:43 --> No URI present. Default controller set.
INFO - 2024-09-10 14:44:43 --> Router Class Initialized
INFO - 2024-09-10 14:44:43 --> Output Class Initialized
INFO - 2024-09-10 14:44:43 --> Security Class Initialized
DEBUG - 2024-09-10 14:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 14:44:43 --> Input Class Initialized
INFO - 2024-09-10 14:44:43 --> Language Class Initialized
INFO - 2024-09-10 14:44:43 --> Loader Class Initialized
INFO - 2024-09-10 14:44:43 --> Helper loaded: url_helper
INFO - 2024-09-10 14:44:43 --> Helper loaded: file_helper
INFO - 2024-09-10 14:44:43 --> Helper loaded: security_helper
INFO - 2024-09-10 14:44:43 --> Helper loaded: wpu_helper
INFO - 2024-09-10 14:44:43 --> Database Driver Class Initialized
INFO - 2024-09-10 14:44:43 --> Email Class Initialized
DEBUG - 2024-09-10 14:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 14:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 14:44:43 --> Helper loaded: form_helper
INFO - 2024-09-10 14:44:43 --> Form Validation Class Initialized
INFO - 2024-09-10 14:44:43 --> Controller Class Initialized
DEBUG - 2024-09-10 14:44:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 14:44:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 14:44:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 14:44:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 14:44:43 --> Final output sent to browser
DEBUG - 2024-09-10 14:44:43 --> Total execution time: 0.2235
INFO - 2024-09-10 15:14:53 --> Config Class Initialized
INFO - 2024-09-10 15:14:53 --> Hooks Class Initialized
DEBUG - 2024-09-10 15:14:53 --> UTF-8 Support Enabled
INFO - 2024-09-10 15:14:53 --> Utf8 Class Initialized
INFO - 2024-09-10 15:14:53 --> URI Class Initialized
DEBUG - 2024-09-10 15:14:53 --> No URI present. Default controller set.
INFO - 2024-09-10 15:14:53 --> Router Class Initialized
INFO - 2024-09-10 15:14:53 --> Output Class Initialized
INFO - 2024-09-10 15:14:53 --> Security Class Initialized
DEBUG - 2024-09-10 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 15:14:53 --> Input Class Initialized
INFO - 2024-09-10 15:14:53 --> Language Class Initialized
INFO - 2024-09-10 15:14:53 --> Loader Class Initialized
INFO - 2024-09-10 15:14:53 --> Helper loaded: url_helper
INFO - 2024-09-10 15:14:53 --> Helper loaded: file_helper
INFO - 2024-09-10 15:14:53 --> Helper loaded: security_helper
INFO - 2024-09-10 15:14:53 --> Helper loaded: wpu_helper
INFO - 2024-09-10 15:14:53 --> Database Driver Class Initialized
INFO - 2024-09-10 15:14:54 --> Email Class Initialized
DEBUG - 2024-09-10 15:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 15:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 15:14:54 --> Helper loaded: form_helper
INFO - 2024-09-10 15:14:54 --> Form Validation Class Initialized
INFO - 2024-09-10 15:14:54 --> Controller Class Initialized
DEBUG - 2024-09-10 15:14:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 15:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 15:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 15:14:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 15:14:54 --> Final output sent to browser
DEBUG - 2024-09-10 15:14:54 --> Total execution time: 0.2250
INFO - 2024-09-10 15:48:41 --> Config Class Initialized
INFO - 2024-09-10 15:48:41 --> Hooks Class Initialized
DEBUG - 2024-09-10 15:48:41 --> UTF-8 Support Enabled
INFO - 2024-09-10 15:48:41 --> Utf8 Class Initialized
INFO - 2024-09-10 15:48:41 --> URI Class Initialized
DEBUG - 2024-09-10 15:48:41 --> No URI present. Default controller set.
INFO - 2024-09-10 15:48:41 --> Router Class Initialized
INFO - 2024-09-10 15:48:41 --> Output Class Initialized
INFO - 2024-09-10 15:48:41 --> Security Class Initialized
DEBUG - 2024-09-10 15:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 15:48:41 --> Input Class Initialized
INFO - 2024-09-10 15:48:41 --> Language Class Initialized
INFO - 2024-09-10 15:48:41 --> Loader Class Initialized
INFO - 2024-09-10 15:48:41 --> Helper loaded: url_helper
INFO - 2024-09-10 15:48:41 --> Helper loaded: file_helper
INFO - 2024-09-10 15:48:41 --> Helper loaded: security_helper
INFO - 2024-09-10 15:48:41 --> Helper loaded: wpu_helper
INFO - 2024-09-10 15:48:41 --> Database Driver Class Initialized
INFO - 2024-09-10 15:48:41 --> Email Class Initialized
DEBUG - 2024-09-10 15:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 15:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 15:48:41 --> Helper loaded: form_helper
INFO - 2024-09-10 15:48:41 --> Form Validation Class Initialized
INFO - 2024-09-10 15:48:41 --> Controller Class Initialized
DEBUG - 2024-09-10 15:48:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 15:48:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 15:48:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 15:48:41 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 15:48:41 --> Final output sent to browser
DEBUG - 2024-09-10 15:48:41 --> Total execution time: 0.2655
INFO - 2024-09-10 16:15:42 --> Config Class Initialized
INFO - 2024-09-10 16:15:42 --> Hooks Class Initialized
DEBUG - 2024-09-10 16:15:42 --> UTF-8 Support Enabled
INFO - 2024-09-10 16:15:42 --> Utf8 Class Initialized
INFO - 2024-09-10 16:15:42 --> URI Class Initialized
DEBUG - 2024-09-10 16:15:42 --> No URI present. Default controller set.
INFO - 2024-09-10 16:15:42 --> Router Class Initialized
INFO - 2024-09-10 16:15:42 --> Output Class Initialized
INFO - 2024-09-10 16:15:42 --> Security Class Initialized
DEBUG - 2024-09-10 16:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 16:15:42 --> Input Class Initialized
INFO - 2024-09-10 16:15:42 --> Language Class Initialized
INFO - 2024-09-10 16:15:42 --> Loader Class Initialized
INFO - 2024-09-10 16:15:42 --> Helper loaded: url_helper
INFO - 2024-09-10 16:15:42 --> Helper loaded: file_helper
INFO - 2024-09-10 16:15:42 --> Helper loaded: security_helper
INFO - 2024-09-10 16:15:42 --> Helper loaded: wpu_helper
INFO - 2024-09-10 16:15:42 --> Database Driver Class Initialized
INFO - 2024-09-10 16:15:42 --> Email Class Initialized
DEBUG - 2024-09-10 16:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 16:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 16:15:42 --> Helper loaded: form_helper
INFO - 2024-09-10 16:15:42 --> Form Validation Class Initialized
INFO - 2024-09-10 16:15:42 --> Controller Class Initialized
DEBUG - 2024-09-10 16:15:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 16:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 16:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 16:15:42 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 16:15:42 --> Final output sent to browser
DEBUG - 2024-09-10 16:15:42 --> Total execution time: 0.2224
INFO - 2024-09-10 16:45:00 --> Config Class Initialized
INFO - 2024-09-10 16:45:00 --> Hooks Class Initialized
DEBUG - 2024-09-10 16:45:00 --> UTF-8 Support Enabled
INFO - 2024-09-10 16:45:00 --> Utf8 Class Initialized
INFO - 2024-09-10 16:45:00 --> URI Class Initialized
DEBUG - 2024-09-10 16:45:00 --> No URI present. Default controller set.
INFO - 2024-09-10 16:45:00 --> Router Class Initialized
INFO - 2024-09-10 16:45:00 --> Output Class Initialized
INFO - 2024-09-10 16:45:00 --> Security Class Initialized
DEBUG - 2024-09-10 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 16:45:00 --> Input Class Initialized
INFO - 2024-09-10 16:45:00 --> Language Class Initialized
INFO - 2024-09-10 16:45:00 --> Loader Class Initialized
INFO - 2024-09-10 16:45:00 --> Helper loaded: url_helper
INFO - 2024-09-10 16:45:00 --> Helper loaded: file_helper
INFO - 2024-09-10 16:45:00 --> Helper loaded: security_helper
INFO - 2024-09-10 16:45:00 --> Helper loaded: wpu_helper
INFO - 2024-09-10 16:45:00 --> Database Driver Class Initialized
INFO - 2024-09-10 16:45:01 --> Email Class Initialized
DEBUG - 2024-09-10 16:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 16:45:01 --> Helper loaded: form_helper
INFO - 2024-09-10 16:45:01 --> Form Validation Class Initialized
INFO - 2024-09-10 16:45:01 --> Controller Class Initialized
DEBUG - 2024-09-10 16:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 16:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 16:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 16:45:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 16:45:01 --> Final output sent to browser
DEBUG - 2024-09-10 16:45:01 --> Total execution time: 0.2427
INFO - 2024-09-10 17:17:06 --> Config Class Initialized
INFO - 2024-09-10 17:17:06 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:17:06 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:17:06 --> Utf8 Class Initialized
INFO - 2024-09-10 17:17:06 --> URI Class Initialized
DEBUG - 2024-09-10 17:17:06 --> No URI present. Default controller set.
INFO - 2024-09-10 17:17:06 --> Router Class Initialized
INFO - 2024-09-10 17:17:06 --> Output Class Initialized
INFO - 2024-09-10 17:17:06 --> Security Class Initialized
DEBUG - 2024-09-10 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:17:06 --> Input Class Initialized
INFO - 2024-09-10 17:17:06 --> Language Class Initialized
INFO - 2024-09-10 17:17:06 --> Loader Class Initialized
INFO - 2024-09-10 17:17:06 --> Helper loaded: url_helper
INFO - 2024-09-10 17:17:06 --> Helper loaded: file_helper
INFO - 2024-09-10 17:17:06 --> Helper loaded: security_helper
INFO - 2024-09-10 17:17:06 --> Helper loaded: wpu_helper
INFO - 2024-09-10 17:17:06 --> Database Driver Class Initialized
INFO - 2024-09-10 17:17:06 --> Email Class Initialized
DEBUG - 2024-09-10 17:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:17:06 --> Helper loaded: form_helper
INFO - 2024-09-10 17:17:06 --> Form Validation Class Initialized
INFO - 2024-09-10 17:17:06 --> Controller Class Initialized
DEBUG - 2024-09-10 17:17:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 17:17:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 17:17:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 17:17:06 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 17:17:06 --> Final output sent to browser
DEBUG - 2024-09-10 17:17:06 --> Total execution time: 0.2231
INFO - 2024-09-10 17:30:34 --> Config Class Initialized
INFO - 2024-09-10 17:30:34 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:30:34 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:30:34 --> Utf8 Class Initialized
INFO - 2024-09-10 17:30:34 --> URI Class Initialized
DEBUG - 2024-09-10 17:30:34 --> No URI present. Default controller set.
INFO - 2024-09-10 17:30:34 --> Router Class Initialized
INFO - 2024-09-10 17:30:34 --> Output Class Initialized
INFO - 2024-09-10 17:30:34 --> Security Class Initialized
DEBUG - 2024-09-10 17:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:30:34 --> Input Class Initialized
INFO - 2024-09-10 17:30:34 --> Language Class Initialized
INFO - 2024-09-10 17:30:34 --> Loader Class Initialized
INFO - 2024-09-10 17:30:34 --> Helper loaded: url_helper
INFO - 2024-09-10 17:30:34 --> Helper loaded: file_helper
INFO - 2024-09-10 17:30:34 --> Helper loaded: security_helper
INFO - 2024-09-10 17:30:34 --> Helper loaded: wpu_helper
INFO - 2024-09-10 17:30:34 --> Database Driver Class Initialized
INFO - 2024-09-10 17:30:34 --> Email Class Initialized
DEBUG - 2024-09-10 17:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 17:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:30:34 --> Helper loaded: form_helper
INFO - 2024-09-10 17:30:34 --> Form Validation Class Initialized
INFO - 2024-09-10 17:30:34 --> Controller Class Initialized
DEBUG - 2024-09-10 17:30:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 17:30:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 17:30:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 17:30:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 17:30:34 --> Final output sent to browser
DEBUG - 2024-09-10 17:30:34 --> Total execution time: 0.2087
INFO - 2024-09-10 17:44:54 --> Config Class Initialized
INFO - 2024-09-10 17:44:54 --> Hooks Class Initialized
DEBUG - 2024-09-10 17:44:54 --> UTF-8 Support Enabled
INFO - 2024-09-10 17:44:54 --> Utf8 Class Initialized
INFO - 2024-09-10 17:44:54 --> URI Class Initialized
DEBUG - 2024-09-10 17:44:54 --> No URI present. Default controller set.
INFO - 2024-09-10 17:44:54 --> Router Class Initialized
INFO - 2024-09-10 17:44:54 --> Output Class Initialized
INFO - 2024-09-10 17:44:54 --> Security Class Initialized
DEBUG - 2024-09-10 17:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 17:44:54 --> Input Class Initialized
INFO - 2024-09-10 17:44:54 --> Language Class Initialized
INFO - 2024-09-10 17:44:54 --> Loader Class Initialized
INFO - 2024-09-10 17:44:54 --> Helper loaded: url_helper
INFO - 2024-09-10 17:44:54 --> Helper loaded: file_helper
INFO - 2024-09-10 17:44:54 --> Helper loaded: security_helper
INFO - 2024-09-10 17:44:54 --> Helper loaded: wpu_helper
INFO - 2024-09-10 17:44:54 --> Database Driver Class Initialized
INFO - 2024-09-10 17:44:54 --> Email Class Initialized
DEBUG - 2024-09-10 17:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 17:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 17:44:54 --> Helper loaded: form_helper
INFO - 2024-09-10 17:44:54 --> Form Validation Class Initialized
INFO - 2024-09-10 17:44:54 --> Controller Class Initialized
DEBUG - 2024-09-10 17:44:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 17:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 17:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 17:44:54 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 17:44:54 --> Final output sent to browser
DEBUG - 2024-09-10 17:44:54 --> Total execution time: 0.2142
INFO - 2024-09-10 18:15:35 --> Config Class Initialized
INFO - 2024-09-10 18:15:35 --> Hooks Class Initialized
DEBUG - 2024-09-10 18:15:35 --> UTF-8 Support Enabled
INFO - 2024-09-10 18:15:35 --> Utf8 Class Initialized
INFO - 2024-09-10 18:15:35 --> URI Class Initialized
DEBUG - 2024-09-10 18:15:35 --> No URI present. Default controller set.
INFO - 2024-09-10 18:15:35 --> Router Class Initialized
INFO - 2024-09-10 18:15:35 --> Output Class Initialized
INFO - 2024-09-10 18:15:35 --> Security Class Initialized
DEBUG - 2024-09-10 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 18:15:35 --> Input Class Initialized
INFO - 2024-09-10 18:15:35 --> Language Class Initialized
INFO - 2024-09-10 18:15:35 --> Loader Class Initialized
INFO - 2024-09-10 18:15:35 --> Helper loaded: url_helper
INFO - 2024-09-10 18:15:35 --> Helper loaded: file_helper
INFO - 2024-09-10 18:15:35 --> Helper loaded: security_helper
INFO - 2024-09-10 18:15:35 --> Helper loaded: wpu_helper
INFO - 2024-09-10 18:15:35 --> Database Driver Class Initialized
INFO - 2024-09-10 18:15:35 --> Email Class Initialized
DEBUG - 2024-09-10 18:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 18:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 18:15:35 --> Helper loaded: form_helper
INFO - 2024-09-10 18:15:35 --> Form Validation Class Initialized
INFO - 2024-09-10 18:15:35 --> Controller Class Initialized
DEBUG - 2024-09-10 18:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 18:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 18:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 18:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 18:15:35 --> Final output sent to browser
DEBUG - 2024-09-10 18:15:35 --> Total execution time: 0.2216
INFO - 2024-09-10 18:44:51 --> Config Class Initialized
INFO - 2024-09-10 18:44:51 --> Hooks Class Initialized
DEBUG - 2024-09-10 18:44:51 --> UTF-8 Support Enabled
INFO - 2024-09-10 18:44:51 --> Utf8 Class Initialized
INFO - 2024-09-10 18:44:51 --> URI Class Initialized
DEBUG - 2024-09-10 18:44:51 --> No URI present. Default controller set.
INFO - 2024-09-10 18:44:51 --> Router Class Initialized
INFO - 2024-09-10 18:44:51 --> Output Class Initialized
INFO - 2024-09-10 18:44:51 --> Security Class Initialized
DEBUG - 2024-09-10 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 18:44:51 --> Input Class Initialized
INFO - 2024-09-10 18:44:51 --> Language Class Initialized
INFO - 2024-09-10 18:44:51 --> Loader Class Initialized
INFO - 2024-09-10 18:44:51 --> Helper loaded: url_helper
INFO - 2024-09-10 18:44:51 --> Helper loaded: file_helper
INFO - 2024-09-10 18:44:51 --> Helper loaded: security_helper
INFO - 2024-09-10 18:44:51 --> Helper loaded: wpu_helper
INFO - 2024-09-10 18:44:51 --> Database Driver Class Initialized
INFO - 2024-09-10 18:44:51 --> Email Class Initialized
DEBUG - 2024-09-10 18:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 18:44:51 --> Helper loaded: form_helper
INFO - 2024-09-10 18:44:51 --> Form Validation Class Initialized
INFO - 2024-09-10 18:44:51 --> Controller Class Initialized
DEBUG - 2024-09-10 18:44:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 18:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 18:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 18:44:51 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 18:44:51 --> Final output sent to browser
DEBUG - 2024-09-10 18:44:51 --> Total execution time: 0.2190
INFO - 2024-09-10 18:45:14 --> Config Class Initialized
INFO - 2024-09-10 18:45:14 --> Hooks Class Initialized
DEBUG - 2024-09-10 18:45:14 --> UTF-8 Support Enabled
INFO - 2024-09-10 18:45:14 --> Utf8 Class Initialized
INFO - 2024-09-10 18:45:14 --> URI Class Initialized
DEBUG - 2024-09-10 18:45:14 --> No URI present. Default controller set.
INFO - 2024-09-10 18:45:14 --> Router Class Initialized
INFO - 2024-09-10 18:45:14 --> Output Class Initialized
INFO - 2024-09-10 18:45:14 --> Security Class Initialized
DEBUG - 2024-09-10 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 18:45:14 --> Input Class Initialized
INFO - 2024-09-10 18:45:14 --> Language Class Initialized
INFO - 2024-09-10 18:45:14 --> Loader Class Initialized
INFO - 2024-09-10 18:45:14 --> Helper loaded: url_helper
INFO - 2024-09-10 18:45:14 --> Helper loaded: file_helper
INFO - 2024-09-10 18:45:14 --> Helper loaded: security_helper
INFO - 2024-09-10 18:45:14 --> Helper loaded: wpu_helper
INFO - 2024-09-10 18:45:14 --> Database Driver Class Initialized
INFO - 2024-09-10 18:45:15 --> Email Class Initialized
DEBUG - 2024-09-10 18:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 18:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 18:45:15 --> Helper loaded: form_helper
INFO - 2024-09-10 18:45:15 --> Form Validation Class Initialized
INFO - 2024-09-10 18:45:15 --> Controller Class Initialized
DEBUG - 2024-09-10 18:45:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 18:45:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 18:45:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 18:45:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 18:45:15 --> Final output sent to browser
DEBUG - 2024-09-10 18:45:15 --> Total execution time: 0.2156
INFO - 2024-09-10 19:14:34 --> Config Class Initialized
INFO - 2024-09-10 19:14:34 --> Hooks Class Initialized
DEBUG - 2024-09-10 19:14:34 --> UTF-8 Support Enabled
INFO - 2024-09-10 19:14:34 --> Utf8 Class Initialized
INFO - 2024-09-10 19:14:34 --> URI Class Initialized
DEBUG - 2024-09-10 19:14:34 --> No URI present. Default controller set.
INFO - 2024-09-10 19:14:34 --> Router Class Initialized
INFO - 2024-09-10 19:14:34 --> Output Class Initialized
INFO - 2024-09-10 19:14:34 --> Security Class Initialized
DEBUG - 2024-09-10 19:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 19:14:34 --> Input Class Initialized
INFO - 2024-09-10 19:14:34 --> Language Class Initialized
INFO - 2024-09-10 19:14:34 --> Loader Class Initialized
INFO - 2024-09-10 19:14:34 --> Helper loaded: url_helper
INFO - 2024-09-10 19:14:34 --> Helper loaded: file_helper
INFO - 2024-09-10 19:14:34 --> Helper loaded: security_helper
INFO - 2024-09-10 19:14:34 --> Helper loaded: wpu_helper
INFO - 2024-09-10 19:14:34 --> Database Driver Class Initialized
INFO - 2024-09-10 19:14:34 --> Email Class Initialized
DEBUG - 2024-09-10 19:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 19:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 19:14:34 --> Helper loaded: form_helper
INFO - 2024-09-10 19:14:34 --> Form Validation Class Initialized
INFO - 2024-09-10 19:14:34 --> Controller Class Initialized
DEBUG - 2024-09-10 19:14:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 19:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 19:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 19:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 19:14:34 --> Final output sent to browser
DEBUG - 2024-09-10 19:14:34 --> Total execution time: 0.2188
INFO - 2024-09-10 19:16:02 --> Config Class Initialized
INFO - 2024-09-10 19:16:02 --> Hooks Class Initialized
DEBUG - 2024-09-10 19:16:02 --> UTF-8 Support Enabled
INFO - 2024-09-10 19:16:02 --> Utf8 Class Initialized
INFO - 2024-09-10 19:16:02 --> URI Class Initialized
DEBUG - 2024-09-10 19:16:02 --> No URI present. Default controller set.
INFO - 2024-09-10 19:16:02 --> Router Class Initialized
INFO - 2024-09-10 19:16:02 --> Output Class Initialized
INFO - 2024-09-10 19:16:02 --> Security Class Initialized
DEBUG - 2024-09-10 19:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 19:16:02 --> Input Class Initialized
INFO - 2024-09-10 19:16:02 --> Language Class Initialized
INFO - 2024-09-10 19:16:02 --> Loader Class Initialized
INFO - 2024-09-10 19:16:02 --> Helper loaded: url_helper
INFO - 2024-09-10 19:16:02 --> Helper loaded: file_helper
INFO - 2024-09-10 19:16:02 --> Helper loaded: security_helper
INFO - 2024-09-10 19:16:02 --> Helper loaded: wpu_helper
INFO - 2024-09-10 19:16:02 --> Database Driver Class Initialized
INFO - 2024-09-10 19:16:02 --> Email Class Initialized
DEBUG - 2024-09-10 19:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 19:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 19:16:02 --> Helper loaded: form_helper
INFO - 2024-09-10 19:16:02 --> Form Validation Class Initialized
INFO - 2024-09-10 19:16:02 --> Controller Class Initialized
DEBUG - 2024-09-10 19:16:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 19:16:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 19:16:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 19:16:02 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 19:16:02 --> Final output sent to browser
DEBUG - 2024-09-10 19:16:02 --> Total execution time: 0.2233
INFO - 2024-09-10 19:45:50 --> Config Class Initialized
INFO - 2024-09-10 19:45:50 --> Hooks Class Initialized
DEBUG - 2024-09-10 19:45:50 --> UTF-8 Support Enabled
INFO - 2024-09-10 19:45:50 --> Utf8 Class Initialized
INFO - 2024-09-10 19:45:50 --> URI Class Initialized
DEBUG - 2024-09-10 19:45:50 --> No URI present. Default controller set.
INFO - 2024-09-10 19:45:50 --> Router Class Initialized
INFO - 2024-09-10 19:45:50 --> Output Class Initialized
INFO - 2024-09-10 19:45:50 --> Security Class Initialized
DEBUG - 2024-09-10 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 19:45:50 --> Input Class Initialized
INFO - 2024-09-10 19:45:50 --> Language Class Initialized
INFO - 2024-09-10 19:45:50 --> Loader Class Initialized
INFO - 2024-09-10 19:45:50 --> Helper loaded: url_helper
INFO - 2024-09-10 19:45:50 --> Helper loaded: file_helper
INFO - 2024-09-10 19:45:50 --> Helper loaded: security_helper
INFO - 2024-09-10 19:45:50 --> Helper loaded: wpu_helper
INFO - 2024-09-10 19:45:50 --> Database Driver Class Initialized
INFO - 2024-09-10 19:45:50 --> Email Class Initialized
DEBUG - 2024-09-10 19:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 19:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 19:45:50 --> Helper loaded: form_helper
INFO - 2024-09-10 19:45:50 --> Form Validation Class Initialized
INFO - 2024-09-10 19:45:50 --> Controller Class Initialized
DEBUG - 2024-09-10 19:45:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 19:45:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 19:45:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 19:45:50 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 19:45:50 --> Final output sent to browser
DEBUG - 2024-09-10 19:45:50 --> Total execution time: 0.2211
INFO - 2024-09-10 20:17:20 --> Config Class Initialized
INFO - 2024-09-10 20:17:20 --> Hooks Class Initialized
DEBUG - 2024-09-10 20:17:20 --> UTF-8 Support Enabled
INFO - 2024-09-10 20:17:20 --> Utf8 Class Initialized
INFO - 2024-09-10 20:17:20 --> URI Class Initialized
DEBUG - 2024-09-10 20:17:20 --> No URI present. Default controller set.
INFO - 2024-09-10 20:17:20 --> Router Class Initialized
INFO - 2024-09-10 20:17:20 --> Output Class Initialized
INFO - 2024-09-10 20:17:20 --> Security Class Initialized
DEBUG - 2024-09-10 20:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 20:17:20 --> Input Class Initialized
INFO - 2024-09-10 20:17:20 --> Language Class Initialized
INFO - 2024-09-10 20:17:20 --> Loader Class Initialized
INFO - 2024-09-10 20:17:20 --> Helper loaded: url_helper
INFO - 2024-09-10 20:17:20 --> Helper loaded: file_helper
INFO - 2024-09-10 20:17:20 --> Helper loaded: security_helper
INFO - 2024-09-10 20:17:20 --> Helper loaded: wpu_helper
INFO - 2024-09-10 20:17:20 --> Database Driver Class Initialized
INFO - 2024-09-10 20:17:20 --> Email Class Initialized
DEBUG - 2024-09-10 20:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 20:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 20:17:20 --> Helper loaded: form_helper
INFO - 2024-09-10 20:17:20 --> Form Validation Class Initialized
INFO - 2024-09-10 20:17:20 --> Controller Class Initialized
DEBUG - 2024-09-10 20:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 20:17:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 20:17:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 20:17:20 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 20:17:20 --> Final output sent to browser
DEBUG - 2024-09-10 20:17:20 --> Total execution time: 0.2257
INFO - 2024-09-10 20:35:40 --> Config Class Initialized
INFO - 2024-09-10 20:35:40 --> Hooks Class Initialized
DEBUG - 2024-09-10 20:35:40 --> UTF-8 Support Enabled
INFO - 2024-09-10 20:35:40 --> Utf8 Class Initialized
INFO - 2024-09-10 20:35:40 --> URI Class Initialized
DEBUG - 2024-09-10 20:35:40 --> No URI present. Default controller set.
INFO - 2024-09-10 20:35:40 --> Router Class Initialized
INFO - 2024-09-10 20:35:40 --> Output Class Initialized
INFO - 2024-09-10 20:35:40 --> Security Class Initialized
DEBUG - 2024-09-10 20:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 20:35:40 --> Input Class Initialized
INFO - 2024-09-10 20:35:40 --> Language Class Initialized
INFO - 2024-09-10 20:35:40 --> Loader Class Initialized
INFO - 2024-09-10 20:35:40 --> Helper loaded: url_helper
INFO - 2024-09-10 20:35:40 --> Helper loaded: file_helper
INFO - 2024-09-10 20:35:40 --> Helper loaded: security_helper
INFO - 2024-09-10 20:35:40 --> Helper loaded: wpu_helper
INFO - 2024-09-10 20:35:40 --> Database Driver Class Initialized
INFO - 2024-09-10 20:35:40 --> Email Class Initialized
DEBUG - 2024-09-10 20:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 20:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 20:35:40 --> Helper loaded: form_helper
INFO - 2024-09-10 20:35:40 --> Form Validation Class Initialized
INFO - 2024-09-10 20:35:40 --> Controller Class Initialized
DEBUG - 2024-09-10 20:35:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 20:35:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 20:35:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 20:35:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 20:35:40 --> Final output sent to browser
DEBUG - 2024-09-10 20:35:40 --> Total execution time: 0.2158
INFO - 2024-09-10 20:45:30 --> Config Class Initialized
INFO - 2024-09-10 20:45:30 --> Hooks Class Initialized
DEBUG - 2024-09-10 20:45:30 --> UTF-8 Support Enabled
INFO - 2024-09-10 20:45:30 --> Utf8 Class Initialized
INFO - 2024-09-10 20:45:30 --> URI Class Initialized
DEBUG - 2024-09-10 20:45:30 --> No URI present. Default controller set.
INFO - 2024-09-10 20:45:30 --> Router Class Initialized
INFO - 2024-09-10 20:45:30 --> Output Class Initialized
INFO - 2024-09-10 20:45:30 --> Security Class Initialized
DEBUG - 2024-09-10 20:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 20:45:30 --> Input Class Initialized
INFO - 2024-09-10 20:45:30 --> Language Class Initialized
INFO - 2024-09-10 20:45:30 --> Loader Class Initialized
INFO - 2024-09-10 20:45:30 --> Helper loaded: url_helper
INFO - 2024-09-10 20:45:30 --> Helper loaded: file_helper
INFO - 2024-09-10 20:45:30 --> Helper loaded: security_helper
INFO - 2024-09-10 20:45:30 --> Helper loaded: wpu_helper
INFO - 2024-09-10 20:45:30 --> Database Driver Class Initialized
INFO - 2024-09-10 20:45:30 --> Email Class Initialized
DEBUG - 2024-09-10 20:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 20:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 20:45:30 --> Helper loaded: form_helper
INFO - 2024-09-10 20:45:30 --> Form Validation Class Initialized
INFO - 2024-09-10 20:45:30 --> Controller Class Initialized
DEBUG - 2024-09-10 20:45:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 20:45:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 20:45:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 20:45:30 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 20:45:30 --> Final output sent to browser
DEBUG - 2024-09-10 20:45:30 --> Total execution time: 0.2192
INFO - 2024-09-10 21:17:23 --> Config Class Initialized
INFO - 2024-09-10 21:17:23 --> Hooks Class Initialized
DEBUG - 2024-09-10 21:17:23 --> UTF-8 Support Enabled
INFO - 2024-09-10 21:17:23 --> Utf8 Class Initialized
INFO - 2024-09-10 21:17:23 --> URI Class Initialized
DEBUG - 2024-09-10 21:17:23 --> No URI present. Default controller set.
INFO - 2024-09-10 21:17:23 --> Router Class Initialized
INFO - 2024-09-10 21:17:23 --> Output Class Initialized
INFO - 2024-09-10 21:17:23 --> Security Class Initialized
DEBUG - 2024-09-10 21:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 21:17:23 --> Input Class Initialized
INFO - 2024-09-10 21:17:23 --> Language Class Initialized
INFO - 2024-09-10 21:17:23 --> Loader Class Initialized
INFO - 2024-09-10 21:17:23 --> Helper loaded: url_helper
INFO - 2024-09-10 21:17:23 --> Helper loaded: file_helper
INFO - 2024-09-10 21:17:23 --> Helper loaded: security_helper
INFO - 2024-09-10 21:17:23 --> Helper loaded: wpu_helper
INFO - 2024-09-10 21:17:23 --> Database Driver Class Initialized
INFO - 2024-09-10 21:17:24 --> Email Class Initialized
DEBUG - 2024-09-10 21:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 21:17:24 --> Helper loaded: form_helper
INFO - 2024-09-10 21:17:24 --> Form Validation Class Initialized
INFO - 2024-09-10 21:17:24 --> Controller Class Initialized
DEBUG - 2024-09-10 21:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 21:17:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 21:17:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 21:17:24 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 21:17:24 --> Final output sent to browser
DEBUG - 2024-09-10 21:17:24 --> Total execution time: 0.6018
INFO - 2024-09-10 21:45:26 --> Config Class Initialized
INFO - 2024-09-10 21:45:26 --> Hooks Class Initialized
DEBUG - 2024-09-10 21:45:26 --> UTF-8 Support Enabled
INFO - 2024-09-10 21:45:26 --> Utf8 Class Initialized
INFO - 2024-09-10 21:45:26 --> URI Class Initialized
DEBUG - 2024-09-10 21:45:26 --> No URI present. Default controller set.
INFO - 2024-09-10 21:45:26 --> Router Class Initialized
INFO - 2024-09-10 21:45:26 --> Output Class Initialized
INFO - 2024-09-10 21:45:26 --> Security Class Initialized
DEBUG - 2024-09-10 21:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 21:45:26 --> Input Class Initialized
INFO - 2024-09-10 21:45:26 --> Language Class Initialized
INFO - 2024-09-10 21:45:26 --> Loader Class Initialized
INFO - 2024-09-10 21:45:26 --> Helper loaded: url_helper
INFO - 2024-09-10 21:45:26 --> Helper loaded: file_helper
INFO - 2024-09-10 21:45:26 --> Helper loaded: security_helper
INFO - 2024-09-10 21:45:26 --> Helper loaded: wpu_helper
INFO - 2024-09-10 21:45:26 --> Database Driver Class Initialized
INFO - 2024-09-10 21:45:26 --> Email Class Initialized
DEBUG - 2024-09-10 21:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 21:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 21:45:26 --> Helper loaded: form_helper
INFO - 2024-09-10 21:45:26 --> Form Validation Class Initialized
INFO - 2024-09-10 21:45:26 --> Controller Class Initialized
DEBUG - 2024-09-10 21:45:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 21:45:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 21:45:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 21:45:26 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 21:45:26 --> Final output sent to browser
DEBUG - 2024-09-10 21:45:26 --> Total execution time: 0.2131
INFO - 2024-09-10 22:15:35 --> Config Class Initialized
INFO - 2024-09-10 22:15:35 --> Hooks Class Initialized
DEBUG - 2024-09-10 22:15:35 --> UTF-8 Support Enabled
INFO - 2024-09-10 22:15:35 --> Utf8 Class Initialized
INFO - 2024-09-10 22:15:35 --> URI Class Initialized
DEBUG - 2024-09-10 22:15:35 --> No URI present. Default controller set.
INFO - 2024-09-10 22:15:35 --> Router Class Initialized
INFO - 2024-09-10 22:15:35 --> Output Class Initialized
INFO - 2024-09-10 22:15:35 --> Security Class Initialized
DEBUG - 2024-09-10 22:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 22:15:35 --> Input Class Initialized
INFO - 2024-09-10 22:15:35 --> Language Class Initialized
INFO - 2024-09-10 22:15:35 --> Loader Class Initialized
INFO - 2024-09-10 22:15:35 --> Helper loaded: url_helper
INFO - 2024-09-10 22:15:35 --> Helper loaded: file_helper
INFO - 2024-09-10 22:15:35 --> Helper loaded: security_helper
INFO - 2024-09-10 22:15:35 --> Helper loaded: wpu_helper
INFO - 2024-09-10 22:15:35 --> Database Driver Class Initialized
INFO - 2024-09-10 22:15:35 --> Email Class Initialized
DEBUG - 2024-09-10 22:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 22:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 22:15:35 --> Helper loaded: form_helper
INFO - 2024-09-10 22:15:35 --> Form Validation Class Initialized
INFO - 2024-09-10 22:15:35 --> Controller Class Initialized
DEBUG - 2024-09-10 22:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 22:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 22:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 22:15:35 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 22:15:35 --> Final output sent to browser
DEBUG - 2024-09-10 22:15:35 --> Total execution time: 0.2131
INFO - 2024-09-10 22:42:14 --> Config Class Initialized
INFO - 2024-09-10 22:42:14 --> Hooks Class Initialized
DEBUG - 2024-09-10 22:42:14 --> UTF-8 Support Enabled
INFO - 2024-09-10 22:42:14 --> Utf8 Class Initialized
INFO - 2024-09-10 22:42:14 --> URI Class Initialized
INFO - 2024-09-10 22:42:14 --> Router Class Initialized
INFO - 2024-09-10 22:42:14 --> Output Class Initialized
INFO - 2024-09-10 22:42:14 --> Security Class Initialized
DEBUG - 2024-09-10 22:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 22:42:14 --> Input Class Initialized
INFO - 2024-09-10 22:42:14 --> Language Class Initialized
INFO - 2024-09-10 22:42:14 --> Loader Class Initialized
INFO - 2024-09-10 22:42:14 --> Helper loaded: url_helper
INFO - 2024-09-10 22:42:14 --> Helper loaded: file_helper
INFO - 2024-09-10 22:42:14 --> Helper loaded: security_helper
INFO - 2024-09-10 22:42:14 --> Helper loaded: wpu_helper
INFO - 2024-09-10 22:42:14 --> Database Driver Class Initialized
INFO - 2024-09-10 22:42:14 --> Email Class Initialized
DEBUG - 2024-09-10 22:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 22:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 22:42:14 --> Helper loaded: form_helper
INFO - 2024-09-10 22:42:14 --> Form Validation Class Initialized
INFO - 2024-09-10 22:42:14 --> Controller Class Initialized
INFO - 2024-09-10 22:42:15 --> Config Class Initialized
INFO - 2024-09-10 22:42:15 --> Hooks Class Initialized
DEBUG - 2024-09-10 22:42:15 --> UTF-8 Support Enabled
INFO - 2024-09-10 22:42:15 --> Utf8 Class Initialized
INFO - 2024-09-10 22:42:15 --> URI Class Initialized
INFO - 2024-09-10 22:42:15 --> Router Class Initialized
INFO - 2024-09-10 22:42:15 --> Output Class Initialized
INFO - 2024-09-10 22:42:15 --> Security Class Initialized
DEBUG - 2024-09-10 22:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 22:42:15 --> Input Class Initialized
INFO - 2024-09-10 22:42:15 --> Language Class Initialized
INFO - 2024-09-10 22:42:15 --> Loader Class Initialized
INFO - 2024-09-10 22:42:15 --> Helper loaded: url_helper
INFO - 2024-09-10 22:42:15 --> Helper loaded: file_helper
INFO - 2024-09-10 22:42:15 --> Helper loaded: security_helper
INFO - 2024-09-10 22:42:15 --> Helper loaded: wpu_helper
INFO - 2024-09-10 22:42:15 --> Database Driver Class Initialized
INFO - 2024-09-10 22:42:15 --> Email Class Initialized
DEBUG - 2024-09-10 22:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 22:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 22:42:15 --> Helper loaded: form_helper
INFO - 2024-09-10 22:42:15 --> Form Validation Class Initialized
INFO - 2024-09-10 22:42:15 --> Controller Class Initialized
DEBUG - 2024-09-10 22:42:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 22:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 22:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 22:42:15 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 22:42:15 --> Final output sent to browser
DEBUG - 2024-09-10 22:42:15 --> Total execution time: 0.2216
INFO - 2024-09-10 22:45:57 --> Config Class Initialized
INFO - 2024-09-10 22:45:57 --> Hooks Class Initialized
DEBUG - 2024-09-10 22:45:57 --> UTF-8 Support Enabled
INFO - 2024-09-10 22:45:57 --> Utf8 Class Initialized
INFO - 2024-09-10 22:45:57 --> URI Class Initialized
DEBUG - 2024-09-10 22:45:57 --> No URI present. Default controller set.
INFO - 2024-09-10 22:45:57 --> Router Class Initialized
INFO - 2024-09-10 22:45:57 --> Output Class Initialized
INFO - 2024-09-10 22:45:57 --> Security Class Initialized
DEBUG - 2024-09-10 22:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 22:45:57 --> Input Class Initialized
INFO - 2024-09-10 22:45:57 --> Language Class Initialized
INFO - 2024-09-10 22:45:57 --> Loader Class Initialized
INFO - 2024-09-10 22:45:57 --> Helper loaded: url_helper
INFO - 2024-09-10 22:45:57 --> Helper loaded: file_helper
INFO - 2024-09-10 22:45:57 --> Helper loaded: security_helper
INFO - 2024-09-10 22:45:57 --> Helper loaded: wpu_helper
INFO - 2024-09-10 22:45:57 --> Database Driver Class Initialized
INFO - 2024-09-10 22:45:57 --> Email Class Initialized
DEBUG - 2024-09-10 22:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 22:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 22:45:57 --> Helper loaded: form_helper
INFO - 2024-09-10 22:45:57 --> Form Validation Class Initialized
INFO - 2024-09-10 22:45:57 --> Controller Class Initialized
DEBUG - 2024-09-10 22:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 22:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 22:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 22:45:57 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 22:45:57 --> Final output sent to browser
DEBUG - 2024-09-10 22:45:57 --> Total execution time: 0.2394
INFO - 2024-09-10 23:14:34 --> Config Class Initialized
INFO - 2024-09-10 23:14:34 --> Hooks Class Initialized
DEBUG - 2024-09-10 23:14:34 --> UTF-8 Support Enabled
INFO - 2024-09-10 23:14:34 --> Utf8 Class Initialized
INFO - 2024-09-10 23:14:34 --> URI Class Initialized
DEBUG - 2024-09-10 23:14:34 --> No URI present. Default controller set.
INFO - 2024-09-10 23:14:34 --> Router Class Initialized
INFO - 2024-09-10 23:14:34 --> Output Class Initialized
INFO - 2024-09-10 23:14:34 --> Security Class Initialized
DEBUG - 2024-09-10 23:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 23:14:34 --> Input Class Initialized
INFO - 2024-09-10 23:14:34 --> Language Class Initialized
INFO - 2024-09-10 23:14:34 --> Loader Class Initialized
INFO - 2024-09-10 23:14:34 --> Helper loaded: url_helper
INFO - 2024-09-10 23:14:34 --> Helper loaded: file_helper
INFO - 2024-09-10 23:14:34 --> Helper loaded: security_helper
INFO - 2024-09-10 23:14:34 --> Helper loaded: wpu_helper
INFO - 2024-09-10 23:14:34 --> Database Driver Class Initialized
INFO - 2024-09-10 23:14:34 --> Email Class Initialized
DEBUG - 2024-09-10 23:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 23:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 23:14:34 --> Helper loaded: form_helper
INFO - 2024-09-10 23:14:34 --> Form Validation Class Initialized
INFO - 2024-09-10 23:14:34 --> Controller Class Initialized
DEBUG - 2024-09-10 23:14:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 23:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 23:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 23:14:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 23:14:34 --> Final output sent to browser
DEBUG - 2024-09-10 23:14:34 --> Total execution time: 0.2187
INFO - 2024-09-10 23:31:34 --> Config Class Initialized
INFO - 2024-09-10 23:31:34 --> Hooks Class Initialized
DEBUG - 2024-09-10 23:31:34 --> UTF-8 Support Enabled
INFO - 2024-09-10 23:31:34 --> Utf8 Class Initialized
INFO - 2024-09-10 23:31:34 --> URI Class Initialized
DEBUG - 2024-09-10 23:31:34 --> No URI present. Default controller set.
INFO - 2024-09-10 23:31:34 --> Router Class Initialized
INFO - 2024-09-10 23:31:34 --> Output Class Initialized
INFO - 2024-09-10 23:31:34 --> Security Class Initialized
DEBUG - 2024-09-10 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 23:31:34 --> Input Class Initialized
INFO - 2024-09-10 23:31:34 --> Language Class Initialized
INFO - 2024-09-10 23:31:34 --> Loader Class Initialized
INFO - 2024-09-10 23:31:34 --> Helper loaded: url_helper
INFO - 2024-09-10 23:31:34 --> Helper loaded: file_helper
INFO - 2024-09-10 23:31:34 --> Helper loaded: security_helper
INFO - 2024-09-10 23:31:34 --> Helper loaded: wpu_helper
INFO - 2024-09-10 23:31:34 --> Database Driver Class Initialized
INFO - 2024-09-10 23:31:34 --> Email Class Initialized
DEBUG - 2024-09-10 23:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 23:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 23:31:34 --> Helper loaded: form_helper
INFO - 2024-09-10 23:31:34 --> Form Validation Class Initialized
INFO - 2024-09-10 23:31:34 --> Controller Class Initialized
DEBUG - 2024-09-10 23:31:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 23:31:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 23:31:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 23:31:34 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 23:31:34 --> Final output sent to browser
DEBUG - 2024-09-10 23:31:34 --> Total execution time: 0.2599
INFO - 2024-09-10 23:45:16 --> Config Class Initialized
INFO - 2024-09-10 23:45:16 --> Hooks Class Initialized
DEBUG - 2024-09-10 23:45:16 --> UTF-8 Support Enabled
INFO - 2024-09-10 23:45:16 --> Utf8 Class Initialized
INFO - 2024-09-10 23:45:16 --> URI Class Initialized
DEBUG - 2024-09-10 23:45:16 --> No URI present. Default controller set.
INFO - 2024-09-10 23:45:16 --> Router Class Initialized
INFO - 2024-09-10 23:45:16 --> Output Class Initialized
INFO - 2024-09-10 23:45:16 --> Security Class Initialized
DEBUG - 2024-09-10 23:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-10 23:45:16 --> Input Class Initialized
INFO - 2024-09-10 23:45:16 --> Language Class Initialized
INFO - 2024-09-10 23:45:16 --> Loader Class Initialized
INFO - 2024-09-10 23:45:16 --> Helper loaded: url_helper
INFO - 2024-09-10 23:45:16 --> Helper loaded: file_helper
INFO - 2024-09-10 23:45:16 --> Helper loaded: security_helper
INFO - 2024-09-10 23:45:16 --> Helper loaded: wpu_helper
INFO - 2024-09-10 23:45:16 --> Database Driver Class Initialized
INFO - 2024-09-10 23:45:16 --> Email Class Initialized
DEBUG - 2024-09-10 23:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-09-10 23:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-10 23:45:16 --> Helper loaded: form_helper
INFO - 2024-09-10 23:45:16 --> Form Validation Class Initialized
INFO - 2024-09-10 23:45:16 --> Controller Class Initialized
DEBUG - 2024-09-10 23:45:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-09-10 23:45:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-09-10 23:45:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-09-10 23:45:16 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-09-10 23:45:16 --> Final output sent to browser
DEBUG - 2024-09-10 23:45:16 --> Total execution time: 0.2663
