<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-26 02:40:31 --> Config Class Initialized
INFO - 2024-09-26 02:40:31 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:40:31 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:40:31 --> Utf8 Class Initialized
INFO - 2024-09-26 02:40:31 --> URI Class Initialized
DEBUG - 2024-09-26 02:40:31 --> No URI present. Default controller set.
INFO - 2024-09-26 02:40:31 --> Router Class Initialized
INFO - 2024-09-26 02:40:31 --> Output Class Initialized
INFO - 2024-09-26 02:40:31 --> Security Class Initialized
DEBUG - 2024-09-26 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:40:31 --> Input Class Initialized
INFO - 2024-09-26 02:40:31 --> Language Class Initialized
INFO - 2024-09-26 02:40:31 --> Loader Class Initialized
INFO - 2024-09-26 02:40:31 --> Helper loaded: url_helper
INFO - 2024-09-26 02:40:31 --> Helper loaded: file_helper
INFO - 2024-09-26 02:40:31 --> Helper loaded: security_helper
INFO - 2024-09-26 02:40:31 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:40:31 --> Database Driver Class Initialized
INFO - 2024-09-26 02:40:57 --> Config Class Initialized
INFO - 2024-09-26 02:40:57 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:40:57 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:40:57 --> Utf8 Class Initialized
INFO - 2024-09-26 02:40:57 --> URI Class Initialized
DEBUG - 2024-09-26 02:40:57 --> No URI present. Default controller set.
INFO - 2024-09-26 02:40:57 --> Router Class Initialized
INFO - 2024-09-26 02:40:57 --> Output Class Initialized
INFO - 2024-09-26 02:40:57 --> Security Class Initialized
DEBUG - 2024-09-26 02:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:40:57 --> Input Class Initialized
INFO - 2024-09-26 02:40:57 --> Language Class Initialized
INFO - 2024-09-26 02:40:57 --> Loader Class Initialized
INFO - 2024-09-26 02:40:57 --> Helper loaded: url_helper
INFO - 2024-09-26 02:40:57 --> Helper loaded: file_helper
INFO - 2024-09-26 02:40:57 --> Helper loaded: security_helper
INFO - 2024-09-26 02:40:57 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:40:57 --> Database Driver Class Initialized
INFO - 2024-09-26 02:41:07 --> Config Class Initialized
INFO - 2024-09-26 02:41:07 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:41:07 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:41:07 --> Utf8 Class Initialized
INFO - 2024-09-26 02:41:07 --> URI Class Initialized
DEBUG - 2024-09-26 02:41:07 --> No URI present. Default controller set.
INFO - 2024-09-26 02:41:07 --> Router Class Initialized
INFO - 2024-09-26 02:41:07 --> Output Class Initialized
INFO - 2024-09-26 02:41:07 --> Security Class Initialized
DEBUG - 2024-09-26 02:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:41:07 --> Input Class Initialized
INFO - 2024-09-26 02:41:07 --> Language Class Initialized
INFO - 2024-09-26 02:41:07 --> Loader Class Initialized
INFO - 2024-09-26 02:41:07 --> Helper loaded: url_helper
INFO - 2024-09-26 02:41:07 --> Helper loaded: file_helper
INFO - 2024-09-26 02:41:07 --> Helper loaded: security_helper
INFO - 2024-09-26 02:41:07 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:41:07 --> Database Driver Class Initialized
INFO - 2024-09-26 02:42:04 --> Config Class Initialized
INFO - 2024-09-26 02:42:04 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:42:04 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:42:04 --> Utf8 Class Initialized
INFO - 2024-09-26 02:42:04 --> URI Class Initialized
DEBUG - 2024-09-26 02:42:04 --> No URI present. Default controller set.
INFO - 2024-09-26 02:42:04 --> Router Class Initialized
INFO - 2024-09-26 02:42:04 --> Output Class Initialized
INFO - 2024-09-26 02:42:04 --> Security Class Initialized
DEBUG - 2024-09-26 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:42:04 --> Input Class Initialized
INFO - 2024-09-26 02:42:04 --> Language Class Initialized
INFO - 2024-09-26 02:42:04 --> Loader Class Initialized
INFO - 2024-09-26 02:42:04 --> Helper loaded: url_helper
INFO - 2024-09-26 02:42:04 --> Helper loaded: file_helper
INFO - 2024-09-26 02:42:04 --> Helper loaded: security_helper
INFO - 2024-09-26 02:42:04 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:42:04 --> Database Driver Class Initialized
INFO - 2024-09-26 02:42:11 --> Config Class Initialized
INFO - 2024-09-26 02:42:11 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:42:11 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:42:11 --> Utf8 Class Initialized
INFO - 2024-09-26 02:42:11 --> URI Class Initialized
DEBUG - 2024-09-26 02:42:11 --> No URI present. Default controller set.
INFO - 2024-09-26 02:42:11 --> Router Class Initialized
INFO - 2024-09-26 02:42:11 --> Output Class Initialized
INFO - 2024-09-26 02:42:11 --> Security Class Initialized
DEBUG - 2024-09-26 02:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:42:11 --> Input Class Initialized
INFO - 2024-09-26 02:42:11 --> Language Class Initialized
INFO - 2024-09-26 02:42:11 --> Loader Class Initialized
INFO - 2024-09-26 02:42:11 --> Helper loaded: url_helper
INFO - 2024-09-26 02:42:11 --> Helper loaded: file_helper
INFO - 2024-09-26 02:42:11 --> Helper loaded: security_helper
INFO - 2024-09-26 02:42:11 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:42:11 --> Database Driver Class Initialized
INFO - 2024-09-26 02:43:05 --> Config Class Initialized
INFO - 2024-09-26 02:43:05 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:43:05 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:43:05 --> Utf8 Class Initialized
INFO - 2024-09-26 02:43:05 --> URI Class Initialized
DEBUG - 2024-09-26 02:43:05 --> No URI present. Default controller set.
INFO - 2024-09-26 02:43:05 --> Router Class Initialized
INFO - 2024-09-26 02:43:05 --> Output Class Initialized
INFO - 2024-09-26 02:43:05 --> Security Class Initialized
DEBUG - 2024-09-26 02:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:43:05 --> Input Class Initialized
INFO - 2024-09-26 02:43:05 --> Language Class Initialized
INFO - 2024-09-26 02:43:05 --> Loader Class Initialized
INFO - 2024-09-26 02:43:05 --> Helper loaded: url_helper
INFO - 2024-09-26 02:43:05 --> Helper loaded: file_helper
INFO - 2024-09-26 02:43:05 --> Helper loaded: security_helper
INFO - 2024-09-26 02:43:05 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:43:05 --> Database Driver Class Initialized
INFO - 2024-09-26 02:43:11 --> Config Class Initialized
INFO - 2024-09-26 02:43:11 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:43:11 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:43:11 --> Utf8 Class Initialized
INFO - 2024-09-26 02:43:11 --> URI Class Initialized
DEBUG - 2024-09-26 02:43:11 --> No URI present. Default controller set.
INFO - 2024-09-26 02:43:11 --> Router Class Initialized
INFO - 2024-09-26 02:43:11 --> Output Class Initialized
INFO - 2024-09-26 02:43:11 --> Security Class Initialized
DEBUG - 2024-09-26 02:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:43:11 --> Input Class Initialized
INFO - 2024-09-26 02:43:11 --> Language Class Initialized
INFO - 2024-09-26 02:43:11 --> Loader Class Initialized
INFO - 2024-09-26 02:43:11 --> Helper loaded: url_helper
INFO - 2024-09-26 02:43:11 --> Helper loaded: file_helper
INFO - 2024-09-26 02:43:11 --> Helper loaded: security_helper
INFO - 2024-09-26 02:43:11 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:43:11 --> Database Driver Class Initialized
INFO - 2024-09-26 02:46:04 --> Config Class Initialized
INFO - 2024-09-26 02:46:04 --> Hooks Class Initialized
DEBUG - 2024-09-26 02:46:04 --> UTF-8 Support Enabled
INFO - 2024-09-26 02:46:04 --> Utf8 Class Initialized
INFO - 2024-09-26 02:46:04 --> URI Class Initialized
DEBUG - 2024-09-26 02:46:04 --> No URI present. Default controller set.
INFO - 2024-09-26 02:46:04 --> Router Class Initialized
INFO - 2024-09-26 02:46:04 --> Output Class Initialized
INFO - 2024-09-26 02:46:04 --> Security Class Initialized
DEBUG - 2024-09-26 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 02:46:04 --> Input Class Initialized
INFO - 2024-09-26 02:46:04 --> Language Class Initialized
INFO - 2024-09-26 02:46:04 --> Loader Class Initialized
INFO - 2024-09-26 02:46:04 --> Helper loaded: url_helper
INFO - 2024-09-26 02:46:04 --> Helper loaded: file_helper
INFO - 2024-09-26 02:46:04 --> Helper loaded: security_helper
INFO - 2024-09-26 02:46:04 --> Helper loaded: wpu_helper
INFO - 2024-09-26 02:46:04 --> Database Driver Class Initialized
INFO - 2024-09-26 03:09:04 --> Config Class Initialized
INFO - 2024-09-26 03:09:04 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:09:04 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:09:04 --> Utf8 Class Initialized
INFO - 2024-09-26 03:09:04 --> URI Class Initialized
DEBUG - 2024-09-26 03:09:04 --> No URI present. Default controller set.
INFO - 2024-09-26 03:09:04 --> Router Class Initialized
INFO - 2024-09-26 03:09:04 --> Output Class Initialized
INFO - 2024-09-26 03:09:04 --> Security Class Initialized
DEBUG - 2024-09-26 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:09:04 --> Input Class Initialized
INFO - 2024-09-26 03:09:04 --> Language Class Initialized
INFO - 2024-09-26 03:09:04 --> Loader Class Initialized
INFO - 2024-09-26 03:09:04 --> Helper loaded: url_helper
INFO - 2024-09-26 03:09:04 --> Helper loaded: file_helper
INFO - 2024-09-26 03:09:04 --> Helper loaded: security_helper
INFO - 2024-09-26 03:09:04 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:09:04 --> Database Driver Class Initialized
INFO - 2024-09-26 03:09:14 --> Config Class Initialized
INFO - 2024-09-26 03:09:14 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:09:14 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:09:14 --> Utf8 Class Initialized
INFO - 2024-09-26 03:09:14 --> URI Class Initialized
DEBUG - 2024-09-26 03:09:14 --> No URI present. Default controller set.
INFO - 2024-09-26 03:09:14 --> Router Class Initialized
INFO - 2024-09-26 03:09:14 --> Output Class Initialized
INFO - 2024-09-26 03:09:14 --> Security Class Initialized
DEBUG - 2024-09-26 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:09:14 --> Input Class Initialized
INFO - 2024-09-26 03:09:14 --> Language Class Initialized
INFO - 2024-09-26 03:09:14 --> Loader Class Initialized
INFO - 2024-09-26 03:09:14 --> Helper loaded: url_helper
INFO - 2024-09-26 03:09:14 --> Helper loaded: file_helper
INFO - 2024-09-26 03:09:14 --> Helper loaded: security_helper
INFO - 2024-09-26 03:09:14 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:09:14 --> Database Driver Class Initialized
INFO - 2024-09-26 03:09:35 --> Config Class Initialized
INFO - 2024-09-26 03:09:35 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:09:35 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:09:35 --> Utf8 Class Initialized
INFO - 2024-09-26 03:09:35 --> URI Class Initialized
DEBUG - 2024-09-26 03:09:35 --> No URI present. Default controller set.
INFO - 2024-09-26 03:09:35 --> Router Class Initialized
INFO - 2024-09-26 03:09:35 --> Output Class Initialized
INFO - 2024-09-26 03:09:35 --> Security Class Initialized
DEBUG - 2024-09-26 03:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:09:35 --> Input Class Initialized
INFO - 2024-09-26 03:09:35 --> Language Class Initialized
INFO - 2024-09-26 03:09:35 --> Loader Class Initialized
INFO - 2024-09-26 03:09:35 --> Helper loaded: url_helper
INFO - 2024-09-26 03:09:35 --> Helper loaded: file_helper
INFO - 2024-09-26 03:09:35 --> Helper loaded: security_helper
INFO - 2024-09-26 03:09:35 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:09:35 --> Database Driver Class Initialized
INFO - 2024-09-26 03:13:56 --> Config Class Initialized
INFO - 2024-09-26 03:13:56 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:13:56 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:13:56 --> Utf8 Class Initialized
INFO - 2024-09-26 03:13:56 --> URI Class Initialized
DEBUG - 2024-09-26 03:13:56 --> No URI present. Default controller set.
INFO - 2024-09-26 03:13:56 --> Router Class Initialized
INFO - 2024-09-26 03:13:56 --> Output Class Initialized
INFO - 2024-09-26 03:13:56 --> Security Class Initialized
DEBUG - 2024-09-26 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:13:56 --> Input Class Initialized
INFO - 2024-09-26 03:13:56 --> Language Class Initialized
INFO - 2024-09-26 03:13:56 --> Loader Class Initialized
INFO - 2024-09-26 03:13:56 --> Helper loaded: url_helper
INFO - 2024-09-26 03:13:56 --> Helper loaded: file_helper
INFO - 2024-09-26 03:13:56 --> Helper loaded: security_helper
INFO - 2024-09-26 03:13:56 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:13:56 --> Database Driver Class Initialized
INFO - 2024-09-26 03:14:00 --> Config Class Initialized
INFO - 2024-09-26 03:14:00 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:14:00 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:14:00 --> Utf8 Class Initialized
INFO - 2024-09-26 03:14:00 --> URI Class Initialized
DEBUG - 2024-09-26 03:14:00 --> No URI present. Default controller set.
INFO - 2024-09-26 03:14:00 --> Router Class Initialized
INFO - 2024-09-26 03:14:00 --> Output Class Initialized
INFO - 2024-09-26 03:14:00 --> Security Class Initialized
DEBUG - 2024-09-26 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:14:00 --> Input Class Initialized
INFO - 2024-09-26 03:14:00 --> Language Class Initialized
INFO - 2024-09-26 03:14:00 --> Loader Class Initialized
INFO - 2024-09-26 03:14:00 --> Helper loaded: url_helper
INFO - 2024-09-26 03:14:00 --> Helper loaded: file_helper
INFO - 2024-09-26 03:14:00 --> Helper loaded: security_helper
INFO - 2024-09-26 03:14:00 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:14:00 --> Database Driver Class Initialized
INFO - 2024-09-26 03:14:04 --> Config Class Initialized
INFO - 2024-09-26 03:14:04 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:14:04 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:14:04 --> Utf8 Class Initialized
INFO - 2024-09-26 03:14:04 --> URI Class Initialized
DEBUG - 2024-09-26 03:14:04 --> No URI present. Default controller set.
INFO - 2024-09-26 03:14:04 --> Router Class Initialized
INFO - 2024-09-26 03:14:04 --> Output Class Initialized
INFO - 2024-09-26 03:14:04 --> Security Class Initialized
DEBUG - 2024-09-26 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:14:04 --> Input Class Initialized
INFO - 2024-09-26 03:14:04 --> Language Class Initialized
INFO - 2024-09-26 03:14:04 --> Loader Class Initialized
INFO - 2024-09-26 03:14:04 --> Helper loaded: url_helper
INFO - 2024-09-26 03:14:04 --> Helper loaded: file_helper
INFO - 2024-09-26 03:14:04 --> Helper loaded: security_helper
INFO - 2024-09-26 03:14:04 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:14:04 --> Database Driver Class Initialized
INFO - 2024-09-26 03:14:42 --> Config Class Initialized
INFO - 2024-09-26 03:14:42 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:14:42 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:14:42 --> Utf8 Class Initialized
INFO - 2024-09-26 03:14:42 --> URI Class Initialized
DEBUG - 2024-09-26 03:14:42 --> No URI present. Default controller set.
INFO - 2024-09-26 03:14:42 --> Router Class Initialized
INFO - 2024-09-26 03:14:42 --> Output Class Initialized
INFO - 2024-09-26 03:14:42 --> Security Class Initialized
DEBUG - 2024-09-26 03:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:14:42 --> Input Class Initialized
INFO - 2024-09-26 03:14:42 --> Language Class Initialized
INFO - 2024-09-26 03:14:42 --> Loader Class Initialized
INFO - 2024-09-26 03:14:42 --> Helper loaded: url_helper
INFO - 2024-09-26 03:14:42 --> Helper loaded: file_helper
INFO - 2024-09-26 03:14:42 --> Helper loaded: security_helper
INFO - 2024-09-26 03:14:42 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:14:42 --> Database Driver Class Initialized
INFO - 2024-09-26 03:15:33 --> Config Class Initialized
INFO - 2024-09-26 03:15:33 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:15:33 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:15:33 --> Utf8 Class Initialized
INFO - 2024-09-26 03:15:33 --> URI Class Initialized
DEBUG - 2024-09-26 03:15:33 --> No URI present. Default controller set.
INFO - 2024-09-26 03:15:33 --> Router Class Initialized
INFO - 2024-09-26 03:15:33 --> Output Class Initialized
INFO - 2024-09-26 03:15:33 --> Security Class Initialized
DEBUG - 2024-09-26 03:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:15:33 --> Input Class Initialized
INFO - 2024-09-26 03:15:33 --> Language Class Initialized
INFO - 2024-09-26 03:15:33 --> Loader Class Initialized
INFO - 2024-09-26 03:15:33 --> Helper loaded: url_helper
INFO - 2024-09-26 03:15:33 --> Helper loaded: file_helper
INFO - 2024-09-26 03:15:33 --> Helper loaded: security_helper
INFO - 2024-09-26 03:15:33 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:15:33 --> Database Driver Class Initialized
INFO - 2024-09-26 03:15:44 --> Config Class Initialized
INFO - 2024-09-26 03:15:44 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:15:44 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:15:44 --> Utf8 Class Initialized
INFO - 2024-09-26 03:15:44 --> URI Class Initialized
DEBUG - 2024-09-26 03:15:44 --> No URI present. Default controller set.
INFO - 2024-09-26 03:15:44 --> Router Class Initialized
INFO - 2024-09-26 03:15:44 --> Output Class Initialized
INFO - 2024-09-26 03:15:44 --> Security Class Initialized
DEBUG - 2024-09-26 03:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:15:44 --> Input Class Initialized
INFO - 2024-09-26 03:15:44 --> Language Class Initialized
INFO - 2024-09-26 03:15:44 --> Loader Class Initialized
INFO - 2024-09-26 03:15:44 --> Helper loaded: url_helper
INFO - 2024-09-26 03:15:44 --> Helper loaded: file_helper
INFO - 2024-09-26 03:15:44 --> Helper loaded: security_helper
INFO - 2024-09-26 03:15:44 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:15:44 --> Database Driver Class Initialized
INFO - 2024-09-26 03:15:47 --> Config Class Initialized
INFO - 2024-09-26 03:15:47 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:15:47 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:15:47 --> Utf8 Class Initialized
INFO - 2024-09-26 03:15:47 --> URI Class Initialized
DEBUG - 2024-09-26 03:15:47 --> No URI present. Default controller set.
INFO - 2024-09-26 03:15:47 --> Router Class Initialized
INFO - 2024-09-26 03:15:47 --> Output Class Initialized
INFO - 2024-09-26 03:15:47 --> Security Class Initialized
DEBUG - 2024-09-26 03:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:15:47 --> Input Class Initialized
INFO - 2024-09-26 03:15:47 --> Language Class Initialized
INFO - 2024-09-26 03:15:47 --> Loader Class Initialized
INFO - 2024-09-26 03:15:47 --> Helper loaded: url_helper
INFO - 2024-09-26 03:15:47 --> Helper loaded: file_helper
INFO - 2024-09-26 03:15:47 --> Helper loaded: security_helper
INFO - 2024-09-26 03:15:47 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:15:47 --> Database Driver Class Initialized
INFO - 2024-09-26 03:15:49 --> Config Class Initialized
INFO - 2024-09-26 03:15:49 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:15:49 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:15:49 --> Utf8 Class Initialized
INFO - 2024-09-26 03:15:49 --> URI Class Initialized
DEBUG - 2024-09-26 03:15:49 --> No URI present. Default controller set.
INFO - 2024-09-26 03:15:49 --> Router Class Initialized
INFO - 2024-09-26 03:15:49 --> Output Class Initialized
INFO - 2024-09-26 03:15:49 --> Security Class Initialized
DEBUG - 2024-09-26 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:15:49 --> Input Class Initialized
INFO - 2024-09-26 03:15:49 --> Language Class Initialized
INFO - 2024-09-26 03:15:49 --> Loader Class Initialized
INFO - 2024-09-26 03:15:49 --> Helper loaded: url_helper
INFO - 2024-09-26 03:15:49 --> Helper loaded: file_helper
INFO - 2024-09-26 03:15:49 --> Helper loaded: security_helper
INFO - 2024-09-26 03:15:49 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:15:49 --> Database Driver Class Initialized
INFO - 2024-09-26 03:15:52 --> Config Class Initialized
INFO - 2024-09-26 03:15:52 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:15:52 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:15:52 --> Utf8 Class Initialized
INFO - 2024-09-26 03:15:52 --> URI Class Initialized
DEBUG - 2024-09-26 03:15:52 --> No URI present. Default controller set.
INFO - 2024-09-26 03:15:52 --> Router Class Initialized
INFO - 2024-09-26 03:15:52 --> Output Class Initialized
INFO - 2024-09-26 03:15:52 --> Security Class Initialized
DEBUG - 2024-09-26 03:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:15:52 --> Input Class Initialized
INFO - 2024-09-26 03:15:52 --> Language Class Initialized
INFO - 2024-09-26 03:15:52 --> Loader Class Initialized
INFO - 2024-09-26 03:15:52 --> Helper loaded: url_helper
INFO - 2024-09-26 03:15:52 --> Helper loaded: file_helper
INFO - 2024-09-26 03:15:52 --> Helper loaded: security_helper
INFO - 2024-09-26 03:15:52 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:15:52 --> Database Driver Class Initialized
INFO - 2024-09-26 03:17:18 --> Config Class Initialized
INFO - 2024-09-26 03:17:18 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:17:18 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:17:18 --> Utf8 Class Initialized
INFO - 2024-09-26 03:17:18 --> URI Class Initialized
DEBUG - 2024-09-26 03:17:18 --> No URI present. Default controller set.
INFO - 2024-09-26 03:17:18 --> Router Class Initialized
INFO - 2024-09-26 03:17:18 --> Output Class Initialized
INFO - 2024-09-26 03:17:18 --> Security Class Initialized
DEBUG - 2024-09-26 03:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:17:18 --> Input Class Initialized
INFO - 2024-09-26 03:17:18 --> Language Class Initialized
INFO - 2024-09-26 03:17:18 --> Loader Class Initialized
INFO - 2024-09-26 03:17:18 --> Helper loaded: url_helper
INFO - 2024-09-26 03:17:18 --> Helper loaded: file_helper
INFO - 2024-09-26 03:17:18 --> Helper loaded: security_helper
INFO - 2024-09-26 03:17:18 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:17:18 --> Database Driver Class Initialized
INFO - 2024-09-26 03:17:41 --> Config Class Initialized
INFO - 2024-09-26 03:17:41 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:17:41 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:17:41 --> Utf8 Class Initialized
INFO - 2024-09-26 03:17:41 --> URI Class Initialized
DEBUG - 2024-09-26 03:17:41 --> No URI present. Default controller set.
INFO - 2024-09-26 03:17:41 --> Router Class Initialized
INFO - 2024-09-26 03:17:41 --> Output Class Initialized
INFO - 2024-09-26 03:17:41 --> Security Class Initialized
DEBUG - 2024-09-26 03:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:17:41 --> Input Class Initialized
INFO - 2024-09-26 03:17:41 --> Language Class Initialized
INFO - 2024-09-26 03:17:41 --> Loader Class Initialized
INFO - 2024-09-26 03:17:41 --> Helper loaded: url_helper
INFO - 2024-09-26 03:17:41 --> Helper loaded: file_helper
INFO - 2024-09-26 03:17:41 --> Helper loaded: security_helper
INFO - 2024-09-26 03:17:41 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:17:41 --> Database Driver Class Initialized
INFO - 2024-09-26 03:18:12 --> Config Class Initialized
INFO - 2024-09-26 03:18:12 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:18:12 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:18:12 --> Utf8 Class Initialized
INFO - 2024-09-26 03:18:12 --> URI Class Initialized
DEBUG - 2024-09-26 03:18:12 --> No URI present. Default controller set.
INFO - 2024-09-26 03:18:12 --> Router Class Initialized
INFO - 2024-09-26 03:18:12 --> Output Class Initialized
INFO - 2024-09-26 03:18:12 --> Security Class Initialized
DEBUG - 2024-09-26 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:18:12 --> Input Class Initialized
INFO - 2024-09-26 03:18:12 --> Language Class Initialized
INFO - 2024-09-26 03:18:12 --> Loader Class Initialized
INFO - 2024-09-26 03:18:12 --> Helper loaded: url_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: file_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: security_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:18:12 --> Database Driver Class Initialized
INFO - 2024-09-26 03:18:12 --> Config Class Initialized
INFO - 2024-09-26 03:18:12 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:18:12 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:18:12 --> Utf8 Class Initialized
INFO - 2024-09-26 03:18:12 --> URI Class Initialized
DEBUG - 2024-09-26 03:18:12 --> No URI present. Default controller set.
INFO - 2024-09-26 03:18:12 --> Router Class Initialized
INFO - 2024-09-26 03:18:12 --> Output Class Initialized
INFO - 2024-09-26 03:18:12 --> Security Class Initialized
DEBUG - 2024-09-26 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:18:12 --> Input Class Initialized
INFO - 2024-09-26 03:18:12 --> Language Class Initialized
INFO - 2024-09-26 03:18:12 --> Loader Class Initialized
INFO - 2024-09-26 03:18:12 --> Helper loaded: url_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: file_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: security_helper
INFO - 2024-09-26 03:18:12 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:18:12 --> Database Driver Class Initialized
INFO - 2024-09-26 03:20:22 --> Config Class Initialized
INFO - 2024-09-26 03:20:22 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:20:22 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:20:22 --> Utf8 Class Initialized
INFO - 2024-09-26 03:20:22 --> URI Class Initialized
DEBUG - 2024-09-26 03:20:22 --> No URI present. Default controller set.
INFO - 2024-09-26 03:20:22 --> Router Class Initialized
INFO - 2024-09-26 03:20:22 --> Output Class Initialized
INFO - 2024-09-26 03:20:22 --> Security Class Initialized
DEBUG - 2024-09-26 03:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:20:22 --> Input Class Initialized
INFO - 2024-09-26 03:20:22 --> Language Class Initialized
INFO - 2024-09-26 03:20:22 --> Loader Class Initialized
INFO - 2024-09-26 03:20:22 --> Helper loaded: url_helper
INFO - 2024-09-26 03:20:22 --> Helper loaded: file_helper
INFO - 2024-09-26 03:20:22 --> Helper loaded: security_helper
INFO - 2024-09-26 03:20:22 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:20:22 --> Database Driver Class Initialized
INFO - 2024-09-26 03:25:31 --> Config Class Initialized
INFO - 2024-09-26 03:25:31 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:25:31 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:25:31 --> Utf8 Class Initialized
INFO - 2024-09-26 03:25:31 --> URI Class Initialized
DEBUG - 2024-09-26 03:25:31 --> No URI present. Default controller set.
INFO - 2024-09-26 03:25:31 --> Router Class Initialized
INFO - 2024-09-26 03:25:31 --> Output Class Initialized
INFO - 2024-09-26 03:25:31 --> Security Class Initialized
DEBUG - 2024-09-26 03:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:25:31 --> Input Class Initialized
INFO - 2024-09-26 03:25:31 --> Language Class Initialized
INFO - 2024-09-26 03:25:31 --> Loader Class Initialized
INFO - 2024-09-26 03:25:31 --> Helper loaded: url_helper
INFO - 2024-09-26 03:25:31 --> Helper loaded: file_helper
INFO - 2024-09-26 03:25:31 --> Helper loaded: security_helper
INFO - 2024-09-26 03:25:31 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:25:31 --> Database Driver Class Initialized
INFO - 2024-09-26 03:27:14 --> Config Class Initialized
INFO - 2024-09-26 03:27:14 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:27:14 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:27:14 --> Utf8 Class Initialized
INFO - 2024-09-26 03:27:14 --> URI Class Initialized
DEBUG - 2024-09-26 03:27:14 --> No URI present. Default controller set.
INFO - 2024-09-26 03:27:14 --> Router Class Initialized
INFO - 2024-09-26 03:27:14 --> Output Class Initialized
INFO - 2024-09-26 03:27:14 --> Security Class Initialized
DEBUG - 2024-09-26 03:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:27:14 --> Input Class Initialized
INFO - 2024-09-26 03:27:14 --> Language Class Initialized
INFO - 2024-09-26 03:27:14 --> Loader Class Initialized
INFO - 2024-09-26 03:27:14 --> Helper loaded: url_helper
INFO - 2024-09-26 03:27:14 --> Helper loaded: file_helper
INFO - 2024-09-26 03:27:14 --> Helper loaded: security_helper
INFO - 2024-09-26 03:27:14 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:27:14 --> Database Driver Class Initialized
INFO - 2024-09-26 03:39:55 --> Config Class Initialized
INFO - 2024-09-26 03:39:55 --> Hooks Class Initialized
DEBUG - 2024-09-26 03:39:55 --> UTF-8 Support Enabled
INFO - 2024-09-26 03:39:55 --> Utf8 Class Initialized
INFO - 2024-09-26 03:39:55 --> URI Class Initialized
DEBUG - 2024-09-26 03:39:55 --> No URI present. Default controller set.
INFO - 2024-09-26 03:39:55 --> Router Class Initialized
INFO - 2024-09-26 03:39:55 --> Output Class Initialized
INFO - 2024-09-26 03:39:55 --> Security Class Initialized
DEBUG - 2024-09-26 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 03:39:55 --> Input Class Initialized
INFO - 2024-09-26 03:39:55 --> Language Class Initialized
INFO - 2024-09-26 03:39:55 --> Loader Class Initialized
INFO - 2024-09-26 03:39:55 --> Helper loaded: url_helper
INFO - 2024-09-26 03:39:55 --> Helper loaded: file_helper
INFO - 2024-09-26 03:39:55 --> Helper loaded: security_helper
INFO - 2024-09-26 03:39:55 --> Helper loaded: wpu_helper
INFO - 2024-09-26 03:39:55 --> Database Driver Class Initialized
INFO - 2024-09-26 05:20:54 --> Config Class Initialized
INFO - 2024-09-26 05:20:54 --> Hooks Class Initialized
DEBUG - 2024-09-26 05:20:54 --> UTF-8 Support Enabled
INFO - 2024-09-26 05:20:54 --> Utf8 Class Initialized
INFO - 2024-09-26 05:20:54 --> URI Class Initialized
DEBUG - 2024-09-26 05:20:54 --> No URI present. Default controller set.
INFO - 2024-09-26 05:20:54 --> Router Class Initialized
INFO - 2024-09-26 05:20:54 --> Output Class Initialized
INFO - 2024-09-26 05:20:54 --> Security Class Initialized
DEBUG - 2024-09-26 05:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 05:20:54 --> Input Class Initialized
INFO - 2024-09-26 05:20:54 --> Language Class Initialized
INFO - 2024-09-26 05:20:54 --> Loader Class Initialized
INFO - 2024-09-26 05:20:54 --> Helper loaded: url_helper
INFO - 2024-09-26 05:20:54 --> Helper loaded: file_helper
INFO - 2024-09-26 05:20:54 --> Helper loaded: security_helper
INFO - 2024-09-26 05:20:54 --> Helper loaded: wpu_helper
INFO - 2024-09-26 05:20:54 --> Database Driver Class Initialized
INFO - 2024-09-26 05:23:44 --> Config Class Initialized
INFO - 2024-09-26 05:23:44 --> Hooks Class Initialized
DEBUG - 2024-09-26 05:23:44 --> UTF-8 Support Enabled
INFO - 2024-09-26 05:23:44 --> Utf8 Class Initialized
INFO - 2024-09-26 05:23:44 --> URI Class Initialized
DEBUG - 2024-09-26 05:23:44 --> No URI present. Default controller set.
INFO - 2024-09-26 05:23:44 --> Router Class Initialized
INFO - 2024-09-26 05:23:44 --> Output Class Initialized
INFO - 2024-09-26 05:23:44 --> Security Class Initialized
DEBUG - 2024-09-26 05:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 05:23:44 --> Input Class Initialized
INFO - 2024-09-26 05:23:44 --> Language Class Initialized
INFO - 2024-09-26 05:23:44 --> Loader Class Initialized
INFO - 2024-09-26 05:23:44 --> Helper loaded: url_helper
INFO - 2024-09-26 05:23:44 --> Helper loaded: file_helper
INFO - 2024-09-26 05:23:44 --> Helper loaded: security_helper
INFO - 2024-09-26 05:23:44 --> Helper loaded: wpu_helper
INFO - 2024-09-26 05:23:44 --> Database Driver Class Initialized
INFO - 2024-09-26 05:24:18 --> Config Class Initialized
INFO - 2024-09-26 05:24:18 --> Hooks Class Initialized
DEBUG - 2024-09-26 05:24:18 --> UTF-8 Support Enabled
INFO - 2024-09-26 05:24:18 --> Utf8 Class Initialized
INFO - 2024-09-26 05:24:18 --> URI Class Initialized
DEBUG - 2024-09-26 05:24:18 --> No URI present. Default controller set.
INFO - 2024-09-26 05:24:18 --> Router Class Initialized
INFO - 2024-09-26 05:24:18 --> Output Class Initialized
INFO - 2024-09-26 05:24:18 --> Security Class Initialized
DEBUG - 2024-09-26 05:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 05:24:18 --> Input Class Initialized
INFO - 2024-09-26 05:24:18 --> Language Class Initialized
INFO - 2024-09-26 05:24:18 --> Loader Class Initialized
INFO - 2024-09-26 05:24:18 --> Helper loaded: url_helper
INFO - 2024-09-26 05:24:18 --> Helper loaded: file_helper
INFO - 2024-09-26 05:24:18 --> Helper loaded: security_helper
INFO - 2024-09-26 05:24:18 --> Helper loaded: wpu_helper
INFO - 2024-09-26 05:24:18 --> Database Driver Class Initialized
INFO - 2024-09-26 05:25:34 --> Config Class Initialized
INFO - 2024-09-26 05:25:34 --> Hooks Class Initialized
DEBUG - 2024-09-26 05:25:34 --> UTF-8 Support Enabled
INFO - 2024-09-26 05:25:34 --> Utf8 Class Initialized
INFO - 2024-09-26 05:25:34 --> URI Class Initialized
DEBUG - 2024-09-26 05:25:34 --> No URI present. Default controller set.
INFO - 2024-09-26 05:25:34 --> Router Class Initialized
INFO - 2024-09-26 05:25:34 --> Output Class Initialized
INFO - 2024-09-26 05:25:34 --> Security Class Initialized
DEBUG - 2024-09-26 05:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 05:25:34 --> Input Class Initialized
INFO - 2024-09-26 05:25:34 --> Language Class Initialized
INFO - 2024-09-26 05:25:34 --> Loader Class Initialized
INFO - 2024-09-26 05:25:34 --> Helper loaded: url_helper
INFO - 2024-09-26 05:25:34 --> Helper loaded: file_helper
INFO - 2024-09-26 05:25:34 --> Helper loaded: security_helper
INFO - 2024-09-26 05:25:34 --> Helper loaded: wpu_helper
INFO - 2024-09-26 05:25:35 --> Database Driver Class Initialized
INFO - 2024-09-26 06:26:55 --> Config Class Initialized
INFO - 2024-09-26 06:26:55 --> Hooks Class Initialized
DEBUG - 2024-09-26 06:26:55 --> UTF-8 Support Enabled
INFO - 2024-09-26 06:26:55 --> Utf8 Class Initialized
INFO - 2024-09-26 06:26:55 --> URI Class Initialized
DEBUG - 2024-09-26 06:26:55 --> No URI present. Default controller set.
INFO - 2024-09-26 06:26:55 --> Router Class Initialized
INFO - 2024-09-26 06:26:55 --> Output Class Initialized
INFO - 2024-09-26 06:26:55 --> Security Class Initialized
DEBUG - 2024-09-26 06:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 06:26:55 --> Input Class Initialized
INFO - 2024-09-26 06:26:55 --> Language Class Initialized
INFO - 2024-09-26 06:26:55 --> Loader Class Initialized
INFO - 2024-09-26 06:26:55 --> Helper loaded: url_helper
INFO - 2024-09-26 06:26:55 --> Helper loaded: file_helper
INFO - 2024-09-26 06:26:55 --> Helper loaded: security_helper
INFO - 2024-09-26 06:26:55 --> Helper loaded: wpu_helper
INFO - 2024-09-26 06:26:55 --> Database Driver Class Initialized
INFO - 2024-09-26 07:10:14 --> Config Class Initialized
INFO - 2024-09-26 07:10:14 --> Hooks Class Initialized
DEBUG - 2024-09-26 07:10:14 --> UTF-8 Support Enabled
INFO - 2024-09-26 07:10:14 --> Utf8 Class Initialized
INFO - 2024-09-26 07:10:14 --> URI Class Initialized
DEBUG - 2024-09-26 07:10:14 --> No URI present. Default controller set.
INFO - 2024-09-26 07:10:14 --> Router Class Initialized
INFO - 2024-09-26 07:10:14 --> Output Class Initialized
INFO - 2024-09-26 07:10:14 --> Security Class Initialized
DEBUG - 2024-09-26 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 07:10:14 --> Input Class Initialized
INFO - 2024-09-26 07:10:14 --> Language Class Initialized
INFO - 2024-09-26 07:10:14 --> Loader Class Initialized
INFO - 2024-09-26 07:10:14 --> Helper loaded: url_helper
INFO - 2024-09-26 07:10:14 --> Helper loaded: file_helper
INFO - 2024-09-26 07:10:14 --> Helper loaded: security_helper
INFO - 2024-09-26 07:10:14 --> Helper loaded: wpu_helper
INFO - 2024-09-26 07:10:14 --> Database Driver Class Initialized
INFO - 2024-09-26 08:04:28 --> Config Class Initialized
INFO - 2024-09-26 08:04:28 --> Hooks Class Initialized
DEBUG - 2024-09-26 08:04:28 --> UTF-8 Support Enabled
INFO - 2024-09-26 08:04:28 --> Utf8 Class Initialized
INFO - 2024-09-26 08:04:28 --> URI Class Initialized
DEBUG - 2024-09-26 08:04:28 --> No URI present. Default controller set.
INFO - 2024-09-26 08:04:28 --> Router Class Initialized
INFO - 2024-09-26 08:04:28 --> Output Class Initialized
INFO - 2024-09-26 08:04:28 --> Security Class Initialized
DEBUG - 2024-09-26 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 08:04:28 --> Input Class Initialized
INFO - 2024-09-26 08:04:28 --> Language Class Initialized
INFO - 2024-09-26 08:04:28 --> Loader Class Initialized
INFO - 2024-09-26 08:04:28 --> Helper loaded: url_helper
INFO - 2024-09-26 08:04:28 --> Helper loaded: file_helper
INFO - 2024-09-26 08:04:28 --> Helper loaded: security_helper
INFO - 2024-09-26 08:04:28 --> Helper loaded: wpu_helper
INFO - 2024-09-26 08:04:28 --> Database Driver Class Initialized
INFO - 2024-09-26 08:07:55 --> Config Class Initialized
INFO - 2024-09-26 08:07:55 --> Hooks Class Initialized
DEBUG - 2024-09-26 08:07:55 --> UTF-8 Support Enabled
INFO - 2024-09-26 08:07:55 --> Utf8 Class Initialized
INFO - 2024-09-26 08:07:55 --> URI Class Initialized
DEBUG - 2024-09-26 08:07:55 --> No URI present. Default controller set.
INFO - 2024-09-26 08:07:55 --> Router Class Initialized
INFO - 2024-09-26 08:07:55 --> Output Class Initialized
INFO - 2024-09-26 08:07:55 --> Security Class Initialized
DEBUG - 2024-09-26 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 08:07:55 --> Input Class Initialized
INFO - 2024-09-26 08:07:55 --> Language Class Initialized
INFO - 2024-09-26 08:07:55 --> Loader Class Initialized
INFO - 2024-09-26 08:07:55 --> Helper loaded: url_helper
INFO - 2024-09-26 08:07:55 --> Helper loaded: file_helper
INFO - 2024-09-26 08:07:55 --> Helper loaded: security_helper
INFO - 2024-09-26 08:07:55 --> Helper loaded: wpu_helper
INFO - 2024-09-26 08:07:55 --> Database Driver Class Initialized
INFO - 2024-09-26 08:52:13 --> Config Class Initialized
INFO - 2024-09-26 08:52:13 --> Hooks Class Initialized
DEBUG - 2024-09-26 08:52:13 --> UTF-8 Support Enabled
INFO - 2024-09-26 08:52:13 --> Utf8 Class Initialized
INFO - 2024-09-26 08:52:13 --> URI Class Initialized
DEBUG - 2024-09-26 08:52:13 --> No URI present. Default controller set.
INFO - 2024-09-26 08:52:13 --> Router Class Initialized
INFO - 2024-09-26 08:52:13 --> Output Class Initialized
INFO - 2024-09-26 08:52:13 --> Security Class Initialized
DEBUG - 2024-09-26 08:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-26 08:52:13 --> Input Class Initialized
INFO - 2024-09-26 08:52:13 --> Language Class Initialized
INFO - 2024-09-26 08:52:13 --> Loader Class Initialized
INFO - 2024-09-26 08:52:13 --> Helper loaded: url_helper
INFO - 2024-09-26 08:52:13 --> Helper loaded: file_helper
INFO - 2024-09-26 08:52:13 --> Helper loaded: security_helper
INFO - 2024-09-26 08:52:13 --> Helper loaded: wpu_helper
INFO - 2024-09-26 08:52:13 --> Database Driver Class Initialized
