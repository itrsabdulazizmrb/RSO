<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-12 05:27:01 --> Config Class Initialized
INFO - 2024-12-12 05:27:01 --> Hooks Class Initialized
DEBUG - 2024-12-12 05:27:01 --> UTF-8 Support Enabled
INFO - 2024-12-12 05:27:01 --> Utf8 Class Initialized
INFO - 2024-12-12 05:27:01 --> URI Class Initialized
DEBUG - 2024-12-12 05:27:01 --> No URI present. Default controller set.
INFO - 2024-12-12 05:27:01 --> Router Class Initialized
INFO - 2024-12-12 05:27:01 --> Output Class Initialized
INFO - 2024-12-12 05:27:01 --> Security Class Initialized
DEBUG - 2024-12-12 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 05:27:01 --> Input Class Initialized
INFO - 2024-12-12 05:27:01 --> Language Class Initialized
INFO - 2024-12-12 05:27:01 --> Loader Class Initialized
INFO - 2024-12-12 05:27:01 --> Helper loaded: url_helper
INFO - 2024-12-12 05:27:01 --> Helper loaded: file_helper
INFO - 2024-12-12 05:27:01 --> Helper loaded: security_helper
INFO - 2024-12-12 05:27:01 --> Helper loaded: wpu_helper
INFO - 2024-12-12 05:27:01 --> Database Driver Class Initialized
INFO - 2024-12-12 05:27:01 --> Email Class Initialized
DEBUG - 2024-12-12 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-12 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 05:27:01 --> Helper loaded: form_helper
INFO - 2024-12-12 05:27:01 --> Form Validation Class Initialized
INFO - 2024-12-12 05:27:01 --> Controller Class Initialized
DEBUG - 2024-12-12 05:27:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-12 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-12 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-12 05:27:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-12 05:27:01 --> Final output sent to browser
DEBUG - 2024-12-12 05:27:01 --> Total execution time: 0.4359
INFO - 2024-12-12 10:47:18 --> Config Class Initialized
INFO - 2024-12-12 10:47:18 --> Hooks Class Initialized
DEBUG - 2024-12-12 10:47:18 --> UTF-8 Support Enabled
INFO - 2024-12-12 10:47:18 --> Utf8 Class Initialized
INFO - 2024-12-12 10:47:18 --> URI Class Initialized
INFO - 2024-12-12 10:47:18 --> Router Class Initialized
INFO - 2024-12-12 10:47:18 --> Output Class Initialized
INFO - 2024-12-12 10:47:18 --> Security Class Initialized
DEBUG - 2024-12-12 10:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 10:47:18 --> Input Class Initialized
INFO - 2024-12-12 10:47:18 --> Language Class Initialized
ERROR - 2024-12-12 10:47:18 --> 404 Page Not Found: Sitemapsxml/index
INFO - 2024-12-12 10:47:19 --> Config Class Initialized
INFO - 2024-12-12 10:47:19 --> Hooks Class Initialized
DEBUG - 2024-12-12 10:47:19 --> UTF-8 Support Enabled
INFO - 2024-12-12 10:47:19 --> Utf8 Class Initialized
INFO - 2024-12-12 10:47:19 --> URI Class Initialized
INFO - 2024-12-12 10:47:19 --> Router Class Initialized
INFO - 2024-12-12 10:47:19 --> Output Class Initialized
INFO - 2024-12-12 10:47:19 --> Security Class Initialized
DEBUG - 2024-12-12 10:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 10:47:19 --> Input Class Initialized
INFO - 2024-12-12 10:47:19 --> Language Class Initialized
ERROR - 2024-12-12 10:47:19 --> 404 Page Not Found: Sitemapxmlgz/index
INFO - 2024-12-12 10:47:58 --> Config Class Initialized
INFO - 2024-12-12 10:47:58 --> Hooks Class Initialized
DEBUG - 2024-12-12 10:47:58 --> UTF-8 Support Enabled
INFO - 2024-12-12 10:47:58 --> Utf8 Class Initialized
INFO - 2024-12-12 10:47:58 --> URI Class Initialized
INFO - 2024-12-12 10:47:58 --> Router Class Initialized
INFO - 2024-12-12 10:47:58 --> Output Class Initialized
INFO - 2024-12-12 10:47:58 --> Security Class Initialized
DEBUG - 2024-12-12 10:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 10:47:58 --> Input Class Initialized
INFO - 2024-12-12 10:47:58 --> Language Class Initialized
ERROR - 2024-12-12 10:47:58 --> 404 Page Not Found: Sitemaptxt/index
