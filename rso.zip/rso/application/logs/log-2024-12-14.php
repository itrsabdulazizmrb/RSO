<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-14 00:06:05 --> Config Class Initialized
INFO - 2024-12-14 00:06:05 --> Hooks Class Initialized
DEBUG - 2024-12-14 00:06:05 --> UTF-8 Support Enabled
INFO - 2024-12-14 00:06:05 --> Utf8 Class Initialized
INFO - 2024-12-14 00:06:05 --> URI Class Initialized
INFO - 2024-12-14 00:06:05 --> Router Class Initialized
INFO - 2024-12-14 00:06:05 --> Output Class Initialized
INFO - 2024-12-14 00:06:05 --> Security Class Initialized
DEBUG - 2024-12-14 00:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 00:06:05 --> Input Class Initialized
INFO - 2024-12-14 00:06:05 --> Language Class Initialized
ERROR - 2024-12-14 00:06:05 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-14 00:07:21 --> Config Class Initialized
INFO - 2024-12-14 00:07:21 --> Hooks Class Initialized
DEBUG - 2024-12-14 00:07:21 --> UTF-8 Support Enabled
INFO - 2024-12-14 00:07:21 --> Utf8 Class Initialized
INFO - 2024-12-14 00:07:21 --> URI Class Initialized
DEBUG - 2024-12-14 00:07:21 --> No URI present. Default controller set.
INFO - 2024-12-14 00:07:21 --> Router Class Initialized
INFO - 2024-12-14 00:07:21 --> Output Class Initialized
INFO - 2024-12-14 00:07:21 --> Security Class Initialized
DEBUG - 2024-12-14 00:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 00:07:21 --> Input Class Initialized
INFO - 2024-12-14 00:07:21 --> Language Class Initialized
INFO - 2024-12-14 00:07:21 --> Loader Class Initialized
INFO - 2024-12-14 00:07:21 --> Helper loaded: url_helper
INFO - 2024-12-14 00:07:21 --> Helper loaded: file_helper
INFO - 2024-12-14 00:07:21 --> Helper loaded: security_helper
INFO - 2024-12-14 00:07:21 --> Helper loaded: wpu_helper
INFO - 2024-12-14 00:07:21 --> Database Driver Class Initialized
INFO - 2024-12-14 00:07:21 --> Email Class Initialized
DEBUG - 2024-12-14 00:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 00:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 00:07:21 --> Helper loaded: form_helper
INFO - 2024-12-14 00:07:21 --> Form Validation Class Initialized
INFO - 2024-12-14 00:07:21 --> Controller Class Initialized
DEBUG - 2024-12-14 00:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 00:07:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 00:07:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 00:07:21 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 00:07:21 --> Final output sent to browser
DEBUG - 2024-12-14 00:07:21 --> Total execution time: 0.4287
INFO - 2024-12-14 00:07:40 --> Config Class Initialized
INFO - 2024-12-14 00:07:40 --> Hooks Class Initialized
DEBUG - 2024-12-14 00:07:40 --> UTF-8 Support Enabled
INFO - 2024-12-14 00:07:40 --> Utf8 Class Initialized
INFO - 2024-12-14 00:07:40 --> URI Class Initialized
DEBUG - 2024-12-14 00:07:40 --> No URI present. Default controller set.
INFO - 2024-12-14 00:07:40 --> Router Class Initialized
INFO - 2024-12-14 00:07:40 --> Output Class Initialized
INFO - 2024-12-14 00:07:40 --> Security Class Initialized
DEBUG - 2024-12-14 00:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 00:07:40 --> Input Class Initialized
INFO - 2024-12-14 00:07:40 --> Language Class Initialized
INFO - 2024-12-14 00:07:40 --> Loader Class Initialized
INFO - 2024-12-14 00:07:40 --> Helper loaded: url_helper
INFO - 2024-12-14 00:07:40 --> Helper loaded: file_helper
INFO - 2024-12-14 00:07:40 --> Helper loaded: security_helper
INFO - 2024-12-14 00:07:40 --> Helper loaded: wpu_helper
INFO - 2024-12-14 00:07:40 --> Database Driver Class Initialized
INFO - 2024-12-14 00:07:40 --> Email Class Initialized
DEBUG - 2024-12-14 00:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 00:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 00:07:40 --> Helper loaded: form_helper
INFO - 2024-12-14 00:07:40 --> Form Validation Class Initialized
INFO - 2024-12-14 00:07:40 --> Controller Class Initialized
DEBUG - 2024-12-14 00:07:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 00:07:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 00:07:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 00:07:40 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 00:07:40 --> Final output sent to browser
DEBUG - 2024-12-14 00:07:40 --> Total execution time: 0.4156
INFO - 2024-12-14 02:19:01 --> Config Class Initialized
INFO - 2024-12-14 02:19:01 --> Hooks Class Initialized
DEBUG - 2024-12-14 02:19:01 --> UTF-8 Support Enabled
INFO - 2024-12-14 02:19:01 --> Utf8 Class Initialized
INFO - 2024-12-14 02:19:01 --> URI Class Initialized
DEBUG - 2024-12-14 02:19:01 --> No URI present. Default controller set.
INFO - 2024-12-14 02:19:01 --> Router Class Initialized
INFO - 2024-12-14 02:19:01 --> Output Class Initialized
INFO - 2024-12-14 02:19:01 --> Security Class Initialized
DEBUG - 2024-12-14 02:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 02:19:01 --> Input Class Initialized
INFO - 2024-12-14 02:19:01 --> Language Class Initialized
INFO - 2024-12-14 02:19:01 --> Loader Class Initialized
INFO - 2024-12-14 02:19:01 --> Helper loaded: url_helper
INFO - 2024-12-14 02:19:01 --> Helper loaded: file_helper
INFO - 2024-12-14 02:19:01 --> Helper loaded: security_helper
INFO - 2024-12-14 02:19:01 --> Helper loaded: wpu_helper
INFO - 2024-12-14 02:19:01 --> Database Driver Class Initialized
INFO - 2024-12-14 02:19:01 --> Email Class Initialized
DEBUG - 2024-12-14 02:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 02:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 02:19:01 --> Helper loaded: form_helper
INFO - 2024-12-14 02:19:01 --> Form Validation Class Initialized
INFO - 2024-12-14 02:19:01 --> Controller Class Initialized
DEBUG - 2024-12-14 02:19:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 02:19:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 02:19:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 02:19:01 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 02:19:01 --> Final output sent to browser
DEBUG - 2024-12-14 02:19:01 --> Total execution time: 0.4312
INFO - 2024-12-14 02:19:42 --> Config Class Initialized
INFO - 2024-12-14 02:19:42 --> Hooks Class Initialized
DEBUG - 2024-12-14 02:19:42 --> UTF-8 Support Enabled
INFO - 2024-12-14 02:19:42 --> Utf8 Class Initialized
INFO - 2024-12-14 02:19:42 --> URI Class Initialized
DEBUG - 2024-12-14 02:19:42 --> No URI present. Default controller set.
INFO - 2024-12-14 02:19:42 --> Router Class Initialized
INFO - 2024-12-14 02:19:42 --> Output Class Initialized
INFO - 2024-12-14 02:19:43 --> Security Class Initialized
DEBUG - 2024-12-14 02:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 02:19:43 --> Input Class Initialized
INFO - 2024-12-14 02:19:43 --> Language Class Initialized
INFO - 2024-12-14 02:19:43 --> Loader Class Initialized
INFO - 2024-12-14 02:19:43 --> Helper loaded: url_helper
INFO - 2024-12-14 02:19:43 --> Helper loaded: file_helper
INFO - 2024-12-14 02:19:43 --> Helper loaded: security_helper
INFO - 2024-12-14 02:19:43 --> Helper loaded: wpu_helper
INFO - 2024-12-14 02:19:43 --> Database Driver Class Initialized
INFO - 2024-12-14 02:19:43 --> Email Class Initialized
DEBUG - 2024-12-14 02:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 02:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 02:19:43 --> Helper loaded: form_helper
INFO - 2024-12-14 02:19:43 --> Form Validation Class Initialized
INFO - 2024-12-14 02:19:43 --> Controller Class Initialized
DEBUG - 2024-12-14 02:19:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 02:19:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 02:19:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 02:19:43 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 02:19:43 --> Final output sent to browser
DEBUG - 2024-12-14 02:19:43 --> Total execution time: 0.4224
INFO - 2024-12-14 02:19:46 --> Config Class Initialized
INFO - 2024-12-14 02:19:46 --> Hooks Class Initialized
DEBUG - 2024-12-14 02:19:46 --> UTF-8 Support Enabled
INFO - 2024-12-14 02:19:46 --> Utf8 Class Initialized
INFO - 2024-12-14 02:19:46 --> URI Class Initialized
DEBUG - 2024-12-14 02:19:46 --> No URI present. Default controller set.
INFO - 2024-12-14 02:19:46 --> Router Class Initialized
INFO - 2024-12-14 02:19:46 --> Output Class Initialized
INFO - 2024-12-14 02:19:46 --> Security Class Initialized
DEBUG - 2024-12-14 02:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 02:19:46 --> Input Class Initialized
INFO - 2024-12-14 02:19:46 --> Language Class Initialized
INFO - 2024-12-14 02:19:46 --> Loader Class Initialized
INFO - 2024-12-14 02:19:46 --> Helper loaded: url_helper
INFO - 2024-12-14 02:19:46 --> Helper loaded: file_helper
INFO - 2024-12-14 02:19:46 --> Helper loaded: security_helper
INFO - 2024-12-14 02:19:46 --> Helper loaded: wpu_helper
INFO - 2024-12-14 02:19:46 --> Database Driver Class Initialized
INFO - 2024-12-14 02:19:46 --> Email Class Initialized
DEBUG - 2024-12-14 02:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 02:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 02:19:46 --> Helper loaded: form_helper
INFO - 2024-12-14 02:19:46 --> Form Validation Class Initialized
INFO - 2024-12-14 02:19:46 --> Controller Class Initialized
DEBUG - 2024-12-14 02:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 02:19:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 02:19:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 02:19:46 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 02:19:46 --> Final output sent to browser
DEBUG - 2024-12-14 02:19:46 --> Total execution time: 0.4131
INFO - 2024-12-14 11:40:46 --> Config Class Initialized
INFO - 2024-12-14 11:40:46 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:40:46 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:40:46 --> Utf8 Class Initialized
INFO - 2024-12-14 11:40:46 --> URI Class Initialized
DEBUG - 2024-12-14 11:40:46 --> No URI present. Default controller set.
INFO - 2024-12-14 11:40:46 --> Router Class Initialized
INFO - 2024-12-14 11:40:46 --> Output Class Initialized
INFO - 2024-12-14 11:40:46 --> Security Class Initialized
DEBUG - 2024-12-14 11:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:40:46 --> Input Class Initialized
INFO - 2024-12-14 11:40:46 --> Language Class Initialized
INFO - 2024-12-14 11:40:46 --> Loader Class Initialized
INFO - 2024-12-14 11:40:46 --> Helper loaded: url_helper
INFO - 2024-12-14 11:40:46 --> Helper loaded: file_helper
INFO - 2024-12-14 11:40:46 --> Helper loaded: security_helper
INFO - 2024-12-14 11:40:46 --> Helper loaded: wpu_helper
INFO - 2024-12-14 11:40:46 --> Database Driver Class Initialized
INFO - 2024-12-14 11:40:47 --> Email Class Initialized
DEBUG - 2024-12-14 11:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 11:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:40:47 --> Helper loaded: form_helper
INFO - 2024-12-14 11:40:47 --> Form Validation Class Initialized
INFO - 2024-12-14 11:40:47 --> Controller Class Initialized
DEBUG - 2024-12-14 11:40:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 11:40:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 11:40:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 11:40:47 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 11:40:47 --> Final output sent to browser
DEBUG - 2024-12-14 11:40:47 --> Total execution time: 0.4226
INFO - 2024-12-14 11:40:47 --> Config Class Initialized
INFO - 2024-12-14 11:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:40:47 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:40:47 --> Utf8 Class Initialized
INFO - 2024-12-14 11:40:47 --> URI Class Initialized
INFO - 2024-12-14 11:40:47 --> Router Class Initialized
INFO - 2024-12-14 11:40:47 --> Output Class Initialized
INFO - 2024-12-14 11:40:47 --> Security Class Initialized
DEBUG - 2024-12-14 11:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:40:47 --> Input Class Initialized
INFO - 2024-12-14 11:40:47 --> Language Class Initialized
ERROR - 2024-12-14 11:40:47 --> 404 Page Not Found: App/index
INFO - 2024-12-14 11:40:47 --> Config Class Initialized
INFO - 2024-12-14 11:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:40:47 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:40:47 --> Utf8 Class Initialized
INFO - 2024-12-14 11:40:47 --> URI Class Initialized
INFO - 2024-12-14 11:40:47 --> Router Class Initialized
INFO - 2024-12-14 11:40:47 --> Output Class Initialized
INFO - 2024-12-14 11:40:47 --> Security Class Initialized
DEBUG - 2024-12-14 11:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:40:47 --> Input Class Initialized
INFO - 2024-12-14 11:40:47 --> Language Class Initialized
ERROR - 2024-12-14 11:40:47 --> 404 Page Not Found: Login/index
INFO - 2024-12-14 13:46:09 --> Config Class Initialized
INFO - 2024-12-14 13:46:09 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:46:09 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:46:09 --> Utf8 Class Initialized
INFO - 2024-12-14 13:46:09 --> URI Class Initialized
INFO - 2024-12-14 13:46:09 --> Router Class Initialized
INFO - 2024-12-14 13:46:09 --> Output Class Initialized
INFO - 2024-12-14 13:46:09 --> Security Class Initialized
DEBUG - 2024-12-14 13:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:46:09 --> Input Class Initialized
INFO - 2024-12-14 13:46:09 --> Language Class Initialized
ERROR - 2024-12-14 13:46:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-14 13:46:22 --> Config Class Initialized
INFO - 2024-12-14 13:46:22 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:46:22 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:46:22 --> Utf8 Class Initialized
INFO - 2024-12-14 13:46:22 --> URI Class Initialized
DEBUG - 2024-12-14 13:46:22 --> No URI present. Default controller set.
INFO - 2024-12-14 13:46:22 --> Router Class Initialized
INFO - 2024-12-14 13:46:22 --> Output Class Initialized
INFO - 2024-12-14 13:46:22 --> Security Class Initialized
DEBUG - 2024-12-14 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:46:22 --> Input Class Initialized
INFO - 2024-12-14 13:46:22 --> Language Class Initialized
INFO - 2024-12-14 13:46:22 --> Loader Class Initialized
INFO - 2024-12-14 13:46:22 --> Helper loaded: url_helper
INFO - 2024-12-14 13:46:22 --> Helper loaded: file_helper
INFO - 2024-12-14 13:46:22 --> Helper loaded: security_helper
INFO - 2024-12-14 13:46:22 --> Helper loaded: wpu_helper
INFO - 2024-12-14 13:46:22 --> Database Driver Class Initialized
INFO - 2024-12-14 13:46:22 --> Email Class Initialized
DEBUG - 2024-12-14 13:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 13:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:46:22 --> Helper loaded: form_helper
INFO - 2024-12-14 13:46:22 --> Form Validation Class Initialized
INFO - 2024-12-14 13:46:22 --> Controller Class Initialized
DEBUG - 2024-12-14 13:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 13:46:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 13:46:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 13:46:22 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 13:46:22 --> Final output sent to browser
DEBUG - 2024-12-14 13:46:22 --> Total execution time: 0.4120
INFO - 2024-12-14 15:15:29 --> Config Class Initialized
INFO - 2024-12-14 15:15:29 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:15:29 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:15:29 --> Utf8 Class Initialized
INFO - 2024-12-14 15:15:29 --> URI Class Initialized
DEBUG - 2024-12-14 15:15:29 --> No URI present. Default controller set.
INFO - 2024-12-14 15:15:29 --> Router Class Initialized
INFO - 2024-12-14 15:15:29 --> Output Class Initialized
INFO - 2024-12-14 15:15:29 --> Security Class Initialized
DEBUG - 2024-12-14 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:15:29 --> Input Class Initialized
INFO - 2024-12-14 15:15:29 --> Language Class Initialized
INFO - 2024-12-14 15:15:29 --> Loader Class Initialized
INFO - 2024-12-14 15:15:29 --> Helper loaded: url_helper
INFO - 2024-12-14 15:15:29 --> Helper loaded: file_helper
INFO - 2024-12-14 15:15:29 --> Helper loaded: security_helper
INFO - 2024-12-14 15:15:29 --> Helper loaded: wpu_helper
INFO - 2024-12-14 15:15:29 --> Database Driver Class Initialized
INFO - 2024-12-14 15:15:29 --> Email Class Initialized
DEBUG - 2024-12-14 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-12-14 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:15:29 --> Helper loaded: form_helper
INFO - 2024-12-14 15:15:29 --> Form Validation Class Initialized
INFO - 2024-12-14 15:15:29 --> Controller Class Initialized
DEBUG - 2024-12-14 15:15:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-14 15:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_header.php
INFO - 2024-12-14 15:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/auth/login.php
INFO - 2024-12-14 15:15:29 --> File loaded: /home/rsud5258/public_html/antrol.rsudhabdulazizmarabahan.com/application/views/templates/auth_footer.php
INFO - 2024-12-14 15:15:29 --> Final output sent to browser
DEBUG - 2024-12-14 15:15:29 --> Total execution time: 0.4150
INFO - 2024-12-14 15:15:29 --> Config Class Initialized
INFO - 2024-12-14 15:15:29 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:15:29 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:15:29 --> Utf8 Class Initialized
INFO - 2024-12-14 15:15:29 --> URI Class Initialized
INFO - 2024-12-14 15:15:29 --> Router Class Initialized
INFO - 2024-12-14 15:15:29 --> Output Class Initialized
INFO - 2024-12-14 15:15:29 --> Security Class Initialized
DEBUG - 2024-12-14 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:15:29 --> Input Class Initialized
INFO - 2024-12-14 15:15:29 --> Language Class Initialized
ERROR - 2024-12-14 15:15:29 --> 404 Page Not Found: App/index
INFO - 2024-12-14 15:15:30 --> Config Class Initialized
INFO - 2024-12-14 15:15:30 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:15:30 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:15:30 --> Utf8 Class Initialized
INFO - 2024-12-14 15:15:30 --> URI Class Initialized
INFO - 2024-12-14 15:15:30 --> Router Class Initialized
INFO - 2024-12-14 15:15:30 --> Output Class Initialized
INFO - 2024-12-14 15:15:30 --> Security Class Initialized
DEBUG - 2024-12-14 15:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:15:30 --> Input Class Initialized
INFO - 2024-12-14 15:15:30 --> Language Class Initialized
ERROR - 2024-12-14 15:15:30 --> 404 Page Not Found: Login/index
